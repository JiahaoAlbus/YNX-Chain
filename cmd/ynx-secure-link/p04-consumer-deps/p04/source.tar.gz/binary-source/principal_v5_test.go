package binaryhttpsource

// PUBLIC loopback Root transport fixture. This tests actual TLS pinning,
// canonical relay and custody, NOT registered Root/Source signature authority.
import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func (c *Capture) BindingSHA256DATA() string { return hex.EncodeToString(c.digest[:]) }
func (c *Capture) BindingDATA() BodyBindingDATA {
	return BodyBindingDATA{strconv.FormatInt(c.size, 10), hex.EncodeToString(c.sha3Digest[:]), hex.EncodeToString(c.sha512Digest[:])}
}

func fixtureCapture(t *testing.T) (*Capture, *http.Request, *Store, []byte) {
	return fixtureCaptureSize(t, 1080000)
}
func fixtureCaptureSize(t *testing.T, size int) (*Capture, *http.Request, *Store, []byte) {
	t.Helper()
	dir, e := os.MkdirTemp("/Users/huangjiahao/.codex", "PUBLIC-binary-v5-authority-")
	if e != nil {
		t.Fatal(e)
	}
	s, e := OpenStore(dir)
	if e != nil {
		t.Fatal(e)
	}
	body := bytes.Repeat([]byte{0, 255, 128, 13, 10, 60}, size/6+1)[:size]
	r := httptest.NewRequest("POST", OriginalBinaryHTTPPath, bytes.NewReader(body))
	r.Header.Set("content-type", "multipart/form-data; boundary=PUBLICfixed")
	r.Header.Set("x-request-id", "req_public_binary_control_0001")
	r.Header.Set(proofHeader, "PUBLIC_fixture_header_no_Root_authority")
	c, e := CaptureOriginalBinaryHTTPRequest(s, r)
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() {
		_ = c.Close()
		_ = c.DrainPartial()
		_ = s.Close()
		_ = s.DrainPartial() /* retain only metadata if unexpected cleanup; never recursively delete */
		_ = os.Remove(dir)
	})
	return c, r, s, body
}
func fixtureOwner(t *testing.T, c *Capture, r *http.Request, alter func(map[string]any, string)) (*originalBinaryPrincipalV5, *atomic.Int32) {
	t.Helper()
	calls := new(atomic.Int32)
	p := BinaryPrincipalDATAV5{"PUBLIC_account", "PUBLIC_device", "PUBLIC_session", "PUBLIC_registered_current", 1, 1, time.Now().Add(20 * time.Second).UnixMilli()}
	inner, _ := json.Marshal(p)
	var largeWireSHA string
	if c.size >= 64<<20 {
		actual, _ := io.ReadAll(io.NewSectionReader(c.body.file, 0, c.size))
		wire, e := canonicalV5Transport(map[string]any{"version": "5", "operation": "authenticate", "requestId": c.snapshot.RequestID, "method": "POST", "path": OriginalBinaryHTTPPath, "bodyOriginal": base64.RawURLEncoding.EncodeToString(actual), "contentType": c.snapshot.ContentType, "proofHeader": c.snapshot.ProofHeader, "expected": OriginalDeviceExpectedV5{ProductID: "developer", Account: p.Account, DeviceID: p.DeviceID, SessionBinding: p.SessionRef}})
		if e != nil {
			t.Fatal(e)
		}
		largeWireSHA = shaV5(wire)
		clear(actual)
		clear(wire)
		p.ExpiresMS = time.Now().Add(20 * time.Second).UnixMilli()
		inner, _ = json.Marshal(p)
	}
	s := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, q *http.Request) {
		calls.Add(1)
		op := "authenticate"
		if largeWireSHA != "" {
			h := sha256.New()
			if _, e := io.Copy(h, q.Body); e != nil || hex.EncodeToString(h.Sum(nil)) != largeWireSHA {
				t.Error("large actual whole relay differs from exact canonical9 expected bytes", e)
			}
		} else {
			raw, _ := io.ReadAll(q.Body)
			var v map[string]any
			if json.Unmarshal(raw, &v) != nil {
				t.Error("relay JSON")
			}
			canonical, _ := canonicalV5Transport(v)
			if !bytes.Equal(canonical, raw) || len(v) != 9 || v["version"] != "5" || v["path"] != OriginalBinaryHTTPPath || v["bodyOriginal"] == "" {
				t.Error("sole canonical nine-field relay")
			}
			op, _ = v["operation"].(string)
		}
		out := map[string]any{"version": "YNX-ORIGINAL-DEVELOPER-HTTP-PRINCIPAL/v5", "principalOriginal": string(inner), "principalSHA256": shaV5(inner), "profileDigest": strings.Repeat("ab", 32), "currentRaw": "PUBLIC-Root-boundary-not-real-admission", "method": "POST", "path": OriginalBinaryHTTPPath, "bodyDigest": c.BindingSHA256DATA(), "contentType": c.snapshot.ContentType, "bodyBinding": c.BindingDATA(), "expiresAtMs": p.ExpiresMS, "dataOnly": true, "authorized": false, "nativeAdmission": false}
		if alter != nil {
			alter(out, op)
		}
		w.Header().Set("Content-Type", "application/json") // actual original SDK V5 handler response
		json.NewEncoder(w).Encode(out)
	}))
	t.Cleanup(s.Close)
	h := sha256.Sum256(s.Certificate().RawSubjectPublicKeyInfo)
	o := newOriginalBinaryPrincipalV5(binaryRootReleaseV5{SPKI: hex.EncodeToString(h[:]), ProfileDigest: strings.Repeat("ab", 32), Expected: OriginalDeviceExpectedV5{ProductID: "developer", Account: p.Account, DeviceID: p.DeviceID, SessionBinding: p.SessionRef}})
	ca := x509.NewCertPool()
	ca.AddCert(s.Certificate())
	o.transport.TLSClientConfig.RootCAs = ca
	o.transport.TLSClientConfig.ServerName = "example.com"
	o.endpoint = s.URL + "/v5/developer/original-http-principal"
	t.Cleanup(func() { o.closeOriginalBinaryRequestOnce() })
	return o, calls
}
func fixtureVerify(t *testing.T, c *Capture, r *http.Request, o *originalBinaryPrincipalV5) {
	t.Helper()
	v, e := verifyWithOriginalBinaryV5Owner(context.Background(), r, c, o)
	if e != nil {
		t.Fatal(e)
	}
	c.mu.Lock()
	c.verified = v
	c.verifyEntered = true
	c.mu.Unlock()
}
func TestBinaryV5ActualTLSBorrowAndInventory(t *testing.T) {
	c, r, _, body := fixtureCapture(t)
	o, calls := fixtureOwner(t, c, r, nil)
	fixtureVerify(t, c, r, o)
	p, e := c.BorrowOriginalPrincipalV5(context.Background(), r)
	if e != nil {
		t.Fatal(e)
	}
	if p.ViewOriginalDATA().Account != "PUBLIC_account" {
		t.Fatal("actual retained original")
	}
	if e = p.AssertCurrent(context.Background(), r); e != nil {
		t.Fatal(e)
	}
	pc := *p
	if pc.AssertCurrent(context.Background(), r) == nil || pc.Close() == nil {
		t.Fatal("copied principal loan accepted")
	}
	b, e := c.BorrowOriginalBinaryRequestOnce(context.Background(), r)
	if e != nil {
		t.Fatal(e)
	}
	bc := *b
	if _, e = bc.Read(make([]byte, 1)); e == nil {
		t.Fatal("copied body loan accepted")
	}
	if _, e = c.BorrowOriginalBinaryRequestOnce(context.Background(), r); e == nil {
		t.Fatal("body reborrow")
	}
	before := calls.Load()
	got, e := io.ReadAll(io.LimitReader(b, int64(len(body)+1)))
	if e != nil || !bytes.Equal(got, body) {
		t.Fatal("actual binary borrow", e)
	}
	if calls.Load() != before {
		t.Fatal("per-chunk remote reauthentication")
	}
	if c.CurrentOriginalRequest(r.Clone(r.Context())) == nil {
		t.Fatal("request clone accepted")
	}
	_ = b.Close()
	_ = p.Close()
}
func TestBinaryV5RootPinsAndPartialBeforeLateError(t *testing.T) {
	for _, mode := range []string{"pin", "profile", "binding", "role", "late"} {
		t.Run(mode, func(t *testing.T) {
			c, r, _, _ := fixtureCapture(t)
			o, _ := fixtureOwner(t, c, r, func(v map[string]any, op string) {
				switch mode {
				case "profile":
					v["profileDigest"] = strings.Repeat("cd", 32)
				case "binding":
					v["bodyDigest"] = strings.Repeat("00", 32)
				case "role":
					v["authorized"] = true
				case "late":
					if op == "recheck" {
						v["currentRaw"] = ""
					}
				}
			})
			if mode == "pin" {
				release := o.release
				release.SPKI = strings.Repeat("00", 32)
				bad := newOriginalBinaryPrincipalV5(release)
				bad.endpoint = o.endpoint
				bad.transport.TLSClientConfig.RootCAs = o.transport.TLSClientConfig.RootCAs
				bad.transport.TLSClientConfig.ServerName = o.transport.TLSClientConfig.ServerName
				o = bad
				t.Cleanup(func() { bad.closeOriginalBinaryRequestOnce() })
			}
			v, e := verifyWithOriginalBinaryV5Owner(context.Background(), r, c, o)
			if v == nil || v.original != o {
				t.Fatal("partial discarded")
			}
			if mode == "late" {
				if e != nil {
					t.Fatal(e)
				}
				c.verified = v
				c.verifyEntered = true
				if _, e = c.BorrowOriginalPrincipalV5(context.Background(), r); e == nil {
					t.Fatal("late current allowed")
				}
				if _, e = c.BorrowOriginalPrincipalV5(context.Background(), r); e == nil {
					t.Fatal("UNKNOWN re-entry")
				}
			} else if e == nil {
				t.Fatal("invalid Root reply accepted")
			}
			if mode != "pin" && len(o.raw) == 0 {
				t.Fatal("original public partial missing")
			}
		})
	}
}

func TestBinaryV5Actual64MiBSequentialChunks(t *testing.T) {
	c, r, _, body := fixtureCaptureSize(t, 64<<20)
	o, calls := fixtureOwner(t, c, r, nil)
	fixtureVerify(t, c, r, o)
	b, e := c.BorrowOriginalBinaryRequestOnce(context.Background(), r)
	if e != nil {
		t.Fatal(e)
	}
	before := calls.Load()
	h := sha256.New()
	buf := make([]byte, 32768)
	chunks := 0
	for {
		n, e := b.Read(buf)
		if n > 0 {
			h.Write(buf[:n])
			chunks++
		}
		if e == io.EOF {
			break
		}
		if e != nil {
			t.Fatal(e)
		}
	}
	if chunks != 2048 || hex.EncodeToString(h.Sum(nil)) != shaV5(body) || calls.Load() != before {
		t.Fatal("bounded multi-chunk bytes/Root calls", chunks, calls.Load(), before)
	}
	if e = c.CurrentOriginalRequest(r); e != nil {
		t.Fatal("full FD current fence", e)
	}
	_ = b.Close()
	t.Logf("actualBytes=%d chunks=%d chunkBytes=%d RootHTTPDuringRead=%d; full FD triplehash at Capture/verify/Current; sameReq+FD identity+ctime+window at every Read", len(body), chunks, len(buf), calls.Load()-before)
}
func TestBinaryV5ChunkMutationAndCloseFence(t *testing.T) {
	for _, mode := range []string{"request", "fd-mutation", "replace", "expiry", "close"} {
		t.Run(mode, func(t *testing.T) {
			c, r, s, _ := fixtureCapture(t)
			o, _ := fixtureOwner(t, c, r, nil)
			fixtureVerify(t, c, r, o)
			b, e := c.BorrowOriginalBinaryRequestOnce(context.Background(), r)
			if e != nil {
				t.Fatal(e)
			}
			switch mode {
			case "request":
				r.Header.Set("x-request-id", "req_public_other_control_0001")
			case "fd-mutation":
				path := s.directory.path + "/" + c.body.name
				if e = os.Chmod(path, 0600); e != nil {
					t.Fatal(e)
				}
				f, e := os.OpenFile(path, os.O_WRONLY, 0)
				if e != nil {
					t.Fatal(e)
				}
				_, e = f.WriteAt([]byte{3}, 0)
				_ = f.Close()
				if e != nil {
					t.Fatal(e)
				}
				if e = os.Chmod(path, 0400); e != nil {
					t.Fatal(e)
				}
			case "replace":
				path := s.directory.path + "/" + c.body.name
				if e = os.Rename(path, path+".PUBLIC-retained"); e != nil {
					t.Fatal(e)
				}
				if e = os.WriteFile(path, []byte("PUBLIC foreign replacement"), 0600); e != nil {
					t.Fatal(e)
				}
			case "expiry":
				o.expires = time.Now().UnixMilli() - 1
			case "close":
				_ = b.Close()
			}
			out := []byte{99}
			if n, e := b.Read(out); n != 0 || e == nil || out[0] != 99 {
				t.Fatal("released bytes after changed custody", n, e)
			}
			_ = b.Close()
		})
	}
}
func TestBinaryV5PendingBorrowFirstCloseAndPartialRetention(t *testing.T) {
	c, r, _, _ := fixtureCapture(t)
	o, _ := fixtureOwner(t, c, r, nil)
	fixtureVerify(t, c, r, o)
	p, e := c.BorrowOriginalPrincipalV5(context.Background(), r)
	if e != nil {
		t.Fatal(e)
	}
	partials := c.OriginalPrincipalPartialsV5DATA()
	if len(partials) != 2 {
		t.Fatal("each original public partial missing")
	}
	partials[0][0] ^= 1
	if bytes.Equal(partials[0], c.OriginalPrincipalPartialsV5DATA()[0]) {
		t.Fatal("public evidence alias")
	}
	b, e := c.BorrowOriginalBinaryRequestOnce(context.Background(), r)
	if e != nil {
		t.Fatal(e)
	}
	if e = c.Close(); e != errBorrowed {
		t.Fatal("pending reader close", e)
	}
	if _, e = b.Read(make([]byte, 1)); e == nil {
		t.Fatal("read after close entered")
	}
	_ = b.Close()
	_ = c.DrainPartial()
	if e = c.Close(); e != errBorrowed {
		t.Fatal("first close result lost", e)
	}
	if e = p.AssertCurrent(context.Background(), r); e == nil {
		t.Fatal("principal survived close")
	}
	if len(c.OriginalPrincipalPartialsV5DATA()) != 2 {
		t.Fatal("partial lost at close")
	}
}
func TestBinaryV5NormalEmptyAndCopyCapture(t *testing.T) {
	if s, e := OpenOriginalBinaryV5Store(); s != nil || e != ErrOriginalBinaryV5AuthorityUnavailable {
		t.Fatal("normal Root synthesized")
	}
	c, r, _, _ := fixtureCapture(t)
	cc := *c
	if cc.CurrentOriginalRequest(r) == nil || cc.Close() == nil {
		t.Fatal("copied capture accepted")
	}
	if e := c.VerifyOriginalBinaryRequest(context.Background(), r); e != errNotSupplied {
		t.Fatal(e)
	}
	if e := c.VerifyOriginalBinaryRequest(context.Background(), r); e == nil {
		t.Fatal("verification retry")
	}
}
