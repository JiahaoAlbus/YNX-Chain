package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"testing"
)

func TestP04PrivateHostActualCLITwoTenantsVersionsRevocationCold(t *testing.T) {
	// Real Cloud normal factory, storage and HTTP/CLI. PUBLIC Wallet verifier
	// only; these are not genuine Wallet/Root signatures or deployed accounts.
	cfg := p04PrivateHostConfig(t)
	cfg.Cloud.WalletVerifier = acceptWallet{}
	cfg.Limits = ServerLimits{MaxConcurrent: 32, RequestsPerMinute: 10000}
	h, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if h != nil {
			p04ClosePrivateHost(t, h)
		}
	}()
	service, _ := h.Service()
	token := func(account, nonce string) string {
		e := testWalletEnvelope(t, service, "cloud", nonce, []string{"files.read", "files.write", "permissions.manage"})
		if account != owner {
			e.WalletApproval.Account = account
			challenge, err := service.CreateWalletChallenge(e.AuthorizationRequest, e.WalletApproval)
			if err != nil {
				t.Fatal(err)
			}
			e.GatewayCompletion.Challenge = challenge
		}
		v, _, err := service.CreateSession(context.Background(), e)
		if err != nil {
			t.Fatal(err)
		}
		return v
	}
	ownerToken, otherToken := token(owner, "PUBLIC_CLI_OWNER"), token(viewer, "PUBLIC_CLI_OTHER")
	var mu sync.RWMutex
	handler, _ := h.Handler()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { mu.RLock(); defer mu.RUnlock(); handler.ServeHTTP(w, r) }))
	defer srv.Close()
	script, err := filepath.Abs("../../apps/cloud/client/object-cli-journey.fixture.mjs")
	if err != nil {
		t.Fatal(err)
	}
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	clientDir := t.TempDir()
	run := func(stage string, original json.RawMessage) json.RawMessage {
		t.Helper()
		input, _ := json.Marshal(map[string]any{"base": srv.URL + "/api/v1", "ownerToken": ownerToken, "otherToken": otherToken, "otherAccount": viewer, "root": clientDir, "stage": stage, "original": original})
		cmd := exec.Command(node, script)
		cmd.Stdin = bytes.NewReader(input)
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		out, err := cmd.Output()
		if err != nil {
			t.Fatalf("actual CLI %s: %v %s", stage, err, stderr.String())
		}
		if !json.Valid(out) || strings.Contains(string(out), ownerToken) || strings.Contains(string(out), otherToken) {
			t.Fatal("invalid or sensitive journey result")
		}
		return out
	}
	reopen := func() {
		t.Helper()
		p04ClosePrivateHost(t, h)
		h = nil
		next, err := OpenOriginalPrivateHost(context.Background(), cfg)
		if err != nil {
			t.Fatal(err)
		}
		newHandler, _ := next.Handler()
		mu.Lock()
		h = next
		handler = newHandler
		mu.Unlock()
		service, _ = next.Service()
	}
	original := run("initial", nil)
	reopen()
	run("cold", original)
	reopen()
	run("revoked-cold", original)
	if len(service.state.Objects) != 2 || len(service.state.ObjectOperations) != 2 {
		t.Fatal("cold CLI replay created duplicate objects/operations")
	}
	// Actual normal missing-session boundary is separate from PUBLIC admission.
	p04ClosePrivateHost(t, h)
	h = nil
	cfg.Cloud.WalletVerifier = nil
	cfg.Cloud.StatePath = filepath.Join(t.TempDir(), "state.json")
	cfg.Cloud.ObjectDir = filepath.Join(filepath.Dir(cfg.Cloud.StatePath), "objects")
	h, err = OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	handler, _ = h.Handler()
	ownerToken = "PUBLIC_UNADMITTED_NORMAL_SESSION"
	otherToken = "PUBLIC_OTHER_UNADMITTED"
	run("unadmitted", nil)
}
