//go:build cloud_auth_finite_get

package cloud

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

type publicFiniteGETMissingSource struct{ publicIDEAuthority }

func (*publicFiniteGETMissingSource) Principal(context.Context, *http.Request) (string, error) {
	return "", developerauthority.ErrFiniteGETNotSupplied
}

func TestIDEDeploymentFiniteGETNormalNotSuppliedSevenRoutes(t *testing.T) {
	s, a, e, _ := publicIDEFixture(t)
	s.ideDeployments.authority = &publicFiniteGETMissingSource{*a}
	h := s.Handler()
	for _, suffix := range []string{"", "/logs", "/runtime", "/usage", "/usage/records", "/billing/2026-11-07", "/billing/2026-11-07/native-intent"} {
		w := httptest.NewRecorder()
		h.ServeHTTP(w, httptest.NewRequest(http.MethodGet, "/api/v1/ide/deployments/req_PUBLIC_FINITE_UNAVAILABLE_0001"+suffix, nil))
		if w.Code != 503 || !strings.Contains(w.Body.String(), "IDE_DEPLOYMENT_FINITE_GET_SOURCE_UNAVAILABLE") {
			t.Fatal("V4 unavailability fell back", suffix, w.Code, w.Body.String())
		}
	}
	if e.applies != 0 || e.observes != 0 || e.logs != 0 {
		t.Fatal("unqualified finite GET entered original operation IO")
	}
}

func TestIDEDeploymentFiniteGETFailedAttachmentNeverFallsBack(t *testing.T) {
	s, _, e, h := publicIDEFixture(t)
	body, manifest, _ := ideArtifactData(t)
	id := "req_PUBLIC_EXISTING_OLD_SOURCE_0001"
	if out := publicIDESubmit(t, h, body, manifest, id); out.Code != 201 {
		t.Fatal(out.Code)
	}
	s.RefuseOriginalIDEFiniteGETReads()
	for _, suffix := range []string{"", "/logs", "/runtime", "/usage", "/usage/records", "/billing/2026-11-07", "/billing/2026-11-07/native-intent"} {
		out := publicIDERead(h, "/api/v1/ide/deployments/"+id+suffix)
		if out.Code != 503 || !strings.Contains(out.Body.String(), "IDE_DEPLOYMENT_FINITE_GET_SOURCE_UNAVAILABLE") {
			t.Fatal("failed attachment borrowed old principal", suffix, out.Code)
		}
	}
	if e.applies != 1 || e.logs != 0 || e.observes != 0 {
		t.Fatal("unqualified receiver touched old operation")
	}
}
