package cloud

import (
	"context"
	"errors"
	"testing"
)

type p04CancelAfterStore struct {
	LocalObjectStore
	cancel context.CancelFunc
}

func (s p04CancelAfterStore) PutScoped(ctx context.Context, scope, hash string, body []byte) (string, error) {
	ref, err := s.LocalObjectStore.PutScoped(ctx, scope, hash, body)
	if err == nil {
		s.cancel()
	}
	return ref, err
}

func TestP04ObjectVersionCreateLateCancellation(t *testing.T) {
	s := p04Service(t)
	old := p04File(t, s, p04Owner)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	s.cfg.ObjectStore = p04CancelAfterStore{LocalObjectStore{Root: s.cfg.ObjectDir}, cancel}
	if _, err := s.Create(ctx, p04Owner, CreateObjectRequest{Kind: KindFile, Name: "cancelled.txt", Content: []byte("stored-but-cancelled")}); !errors.Is(err, context.Canceled) {
		t.Fatalf("late cancelled create: %v", err)
	}
	if len(s.state.Objects) != 1 || len(s.state.Versions) != 1 {
		t.Fatal("late cancelled create published a version")
	}
	_, body, err := s.Content(p04Owner, old.ID, 0)
	if err != nil || string(body) != "V1" {
		t.Fatal("old current damaged")
	}
}
