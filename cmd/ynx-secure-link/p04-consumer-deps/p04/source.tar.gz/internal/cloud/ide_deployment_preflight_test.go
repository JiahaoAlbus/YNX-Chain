package cloud

import (
	"context"
	"encoding/json"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
)

func TestP04OCIReadinessActualUnixOnlyReadNoExecution(t *testing.T) {
	// Actual Unix/HTTP transport, PUBLIC daemon fixture; no real OCI admission.
	root := t.TempDir()
	if base := os.Getenv("YNX_CLOUD_UNIX_QA_TMP"); base != "" {
		var err error
		root, err = os.MkdirTemp(base, "p04-oci-")
		if err != nil {
			t.Fatal(err)
		}
		defer os.RemoveAll(root)
	}
	binary := filepath.Join(root, "cli")
	if err := os.WriteFile(binary, []byte("PUBLIC executable marker"), 0700); err != nil {
		t.Fatal(err)
	}
	socket := filepath.Join(root, "socket")
	image := "sha256:" + strings.Repeat("a", 64)
	listener, err := net.Listen("unix", socket)
	if err != nil {
		t.Fatal(err)
	}
	var mu sync.Mutex
	mode := "good"
	calls := 0
	srv := &http.Server{Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		calls++
		if r.Method != "GET" {
			t.Error("preflight used effectful method")
		}
		if r.URL.Path == "/version" {
			if mode == "empty" {
				w.Write([]byte("{}"))
				return
			}
			json.NewEncoder(w).Encode(map[string]string{"Version": "PUBLIC-1", "ApiVersion": "1.47", "Os": "linux"})
			return
		}
		if r.URL.Path != "/images/"+image+"/json" {
			t.Error("preflight accessed unselected resource")
			http.NotFound(w, r)
			return
		}
		id := image
		if mode == "mismatch" {
			id = "sha256:" + strings.Repeat("b", 64)
		}
		json.NewEncoder(w).Encode(map[string]string{"Id": id})
	})}
	go srv.Serve(listener)
	defer srv.Close()
	result, err := CheckIDEExistingOCI(context.Background(), binary, socket, image)
	if err != nil || !result.Available || result.ExecutionAuthorized || result.ApplicationRunning {
		t.Fatal("read observation became execution", result, err)
	}
	mu.Lock()
	mode = "empty"
	before := calls
	mu.Unlock()
	result, err = CheckIDEExistingOCI(context.Background(), binary, socket, image)
	if err == nil || result.Code != "OCI_SERVER_INVALID" {
		t.Fatal("empty server accepted", result, err)
	}
	mu.Lock()
	if calls != before+1 {
		t.Fatal("invalid server proceeded to image")
	}
	mode = "mismatch"
	mu.Unlock()
	result, err = CheckIDEExistingOCI(context.Background(), binary, socket, image)
	if err == nil || result.Code != "OCI_IMAGE_MISMATCH" {
		t.Fatal("different image admitted", result, err)
	}
}

func TestP04OCIReadinessBinaryAloneAndMissingDaemonNeverReady(t *testing.T) {
	root := t.TempDir()
	binary := filepath.Join(root, "cli")
	os.WriteFile(binary, []byte("#!/bin/sh\nexit 0\n"), 0700)
	r, err := CheckIDEExistingOCI(context.Background(), binary, filepath.Join(root, "absent.sock"), "sha256:"+strings.Repeat("a", 64))
	if err == nil || r.Available || r.Code != "OCI_SOCKET_UNAVAILABLE" {
		t.Fatal("CLI exit0 treated as available daemon", r, err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	r, err = CheckIDEExistingOCI(ctx, binary, filepath.Join(root, "absent.sock"), "sha256:"+strings.Repeat("a", 64))
	if err == nil || r.Code != "OCI_CHECK_CANCELLED" {
		t.Fatal("cancelled check continued", r, err)
	}
}
