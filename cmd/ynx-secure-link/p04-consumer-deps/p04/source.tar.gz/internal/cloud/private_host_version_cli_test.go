package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
)

func TestP04OriginalVersionCLILostPutRestoreColdImmutableResult(t *testing.T) {
	cfg := p04PrivateHostConfig(t)
	cfg.Cloud.WalletVerifier = acceptWallet{}
	cfg.Limits = ServerLimits{MaxConcurrent: 32, RequestsPerMinute: 10000}
	h, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if h != nil {
			p04ClosePrivateHost(t, h)
		}
	}()
	service, _ := h.Service()
	envelope := testWalletEnvelope(t, service, "cloud", "PUBLIC_ORIGINAL_VERSION_CLI", []string{"files.read", "files.write"})
	token, _, err := service.CreateSession(context.Background(), envelope)
	if err != nil {
		t.Fatal(err)
	}
	handler, _ := h.Handler()
	var mu sync.RWMutex
	var puts, restores atomic.Int32
	var dropPut, dropRestore atomic.Bool
	dropPut.Store(true)
	dropRestore.Store(true)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		lose := false
		if r.Method == "PUT" && strings.HasSuffix(r.URL.Path, "/content") {
			puts.Add(1)
			lose = dropPut.Swap(false)
		}
		if r.Method == "POST" && strings.HasSuffix(r.URL.Path, "/restore") {
			restores.Add(1)
			lose = dropRestore.Swap(false)
		}
		if lose {
			recorded := httptest.NewRecorder()
			handler.ServeHTTP(recorded, r)
			if recorded.Code < 200 || recorded.Code >= 300 {
				t.Errorf("original mutation failed before dropped response %d %s", recorded.Code, recorded.Body.String())
			}
			conn, _, e := w.(http.Hijacker).Hijack()
			if e == nil {
				_ = conn.Close()
			}
			return
		}
		handler.ServeHTTP(w, r)
	}))
	defer srv.Close()
	root := t.TempDir()
	if err = os.Chmod(root, 0700); err != nil {
		t.Fatal(err)
	}
	script, _ := filepath.Abs("../../apps/cloud/client/object-version-cli.fixture.mjs")
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	run := func(stage string, original json.RawMessage) json.RawMessage {
		t.Helper()
		in, _ := json.Marshal(map[string]any{"base": srv.URL + "/api/v1", "token": token, "root": root, "stage": stage, "original": original})
		cmd := exec.Command(node, script)
		cmd.Stdin = bytes.NewReader(in)
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		out, e := cmd.Output()
		if e != nil {
			t.Fatalf("version CLI %s %v %s", stage, e, stderr.String())
		}
		if !json.Valid(out) || strings.Contains(string(out), token) {
			t.Fatal("invalid/sensitive output")
		}
		return out
	}
	reopen := func() {
		p04ClosePrivateHost(t, h)
		h = nil
		next, e := OpenOriginalPrivateHost(context.Background(), cfg)
		if e != nil {
			t.Fatal(e)
		}
		nextHandler, _ := next.Handler()
		mu.Lock()
		h = next
		handler = nextHandler
		mu.Unlock()
		service, _ = next.Service()
	}
	original := run("initial", nil)
	reopen()
	original = run("put-cold", original)
	reopen()
	out := run("restore-cold", original)
	if puts.Load() != 3 || restores.Load() != 1 || len(service.state.ObjectOperations) != 3 || len(service.state.Objects) != 1 {
		t.Fatal("original mutation replayed", puts.Load(), restores.Load(), len(service.state.ObjectOperations))
	}
	t.Logf("sameSnapshot originals=3 puts=3(includes2freshLaterVersions) restores=1 coldOpResultsImmutable=true %s", out)
}
