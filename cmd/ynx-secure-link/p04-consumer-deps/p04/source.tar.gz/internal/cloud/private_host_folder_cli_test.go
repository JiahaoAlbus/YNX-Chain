package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
)

func TestP04FolderCLIColdOriginalImportPaginationAndInheritedACL(t *testing.T) {
	cfg := p04PrivateHostConfig(t)
	cfg.Cloud.WalletVerifier = acceptWallet{}
	cfg.Limits = ServerLimits{MaxConcurrent: 32, RequestsPerMinute: 10000}
	h, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if h != nil {
			p04ClosePrivateHost(t, h)
		}
	}()
	s, _ := h.Service()
	mint := func(account, nonce string) string {
		e := testWalletEnvelope(t, s, "cloud", nonce, []string{"files.read", "files.write", "permissions.manage"})
		if account != owner {
			e.WalletApproval.Account = account
			c, err := s.CreateWalletChallenge(e.AuthorizationRequest, e.WalletApproval)
			if err != nil {
				t.Fatal(err)
			}
			e.GatewayCompletion.Challenge = c
		}
		token, _, err := s.CreateSession(context.Background(), e)
		if err != nil {
			t.Fatal(err)
		}
		return token
	}
	tokens := map[string]string{"owner": mint(owner, "PUBLIC_FOLDER_OWNER"), "editor": mint(viewer, "PUBLIC_FOLDER_EDITOR")}
	handler, _ := h.Handler()
	var mu sync.RWMutex
	var creates atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		if r.Method == "POST" && r.URL.Path == "/api/v1/objects" && creates.Add(1) == 1 {
			reply := httptest.NewRecorder()
			handler.ServeHTTP(reply, r)
			if reply.Code != 201 {
				t.Error(reply.Code, reply.Body.String())
			}
			conn, _, e := w.(http.Hijacker).Hijack()
			if e == nil {
				_ = conn.Close()
			}
			return
		}
		handler.ServeHTTP(w, r)
	}))
	defer srv.Close()
	root := t.TempDir()
	if err = os.Chmod(root, 0700); err != nil {
		t.Fatal(err)
	}
	script, _ := filepath.Abs("../../apps/cloud/client/folder-cli.fixture.mjs")
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	run := func(stage string, original json.RawMessage) json.RawMessage {
		t.Helper()
		in, _ := json.Marshal(map[string]any{"base": srv.URL + "/api/v1", "tokens": tokens, "accounts": map[string]string{"owner": owner, "editor": viewer}, "root": root, "stage": stage, "original": original})
		cmd := exec.Command(node, script)
		cmd.Stdin = bytes.NewReader(in)
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		out, e := cmd.Output()
		if e != nil {
			t.Fatalf("folder CLI %s %v %s", stage, e, stderr.String())
		}
		if !json.Valid(out) {
			t.Fatal("invalid output")
		}
		for _, token := range tokens {
			if strings.Contains(string(out), token) {
				t.Fatal("credential output")
			}
		}
		return out
	}
	reopen := func() {
		p04ClosePrivateHost(t, h)
		h = nil
		next, e := OpenOriginalPrivateHost(context.Background(), cfg)
		if e != nil {
			t.Fatal(e)
		}
		nextHandler, _ := next.Handler()
		mu.Lock()
		h = next
		handler = nextHandler
		mu.Unlock()
		s, _ = next.Service()
	}
	original := run("initial", nil)
	reopen()
	original = run("root-cold", original)
	var selected struct{ Parent string }
	if json.Unmarshal(original, &selected) != nil {
		t.Fatal("bad selected folder")
	}
	grantBody, _ := json.Marshal(map[string]string{"principal": viewer, "role": "editor"})
	request, _ := http.NewRequest("POST", srv.URL+"/api/v1/objects/"+selected.Parent+"/grants", bytes.NewReader(grantBody))
	request.Header.Set("Authorization", "Bearer "+tokens["owner"])
	request.Header.Set("Content-Type", "application/json")
	response, e := srv.Client().Do(request)
	if e != nil {
		t.Fatal(e)
	}
	response.Body.Close()
	if response.StatusCode != 201 {
		t.Fatal("normal original grant", response.StatusCode)
	}
	original = run("import", original)
	reopen()
	result := run("final-cold", original)
	if creates.Load() != 7 || len(s.state.Objects) != 5 || len(s.state.ObjectOperations) != 9 {
		t.Fatal("folder original replayed", creates.Load(), len(s.state.Objects), len(s.state.ObjectOperations))
	}
	t.Logf("folderCreate3 fileCreate2 forbiddenCreate2 cold2 originalReplay0 childOwnerPreserved=true parentTrashBlocksShareAndWrite=true %s", result)
}
