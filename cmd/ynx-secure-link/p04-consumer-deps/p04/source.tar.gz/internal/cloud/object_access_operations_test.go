package cloud

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"sync"
	"testing"
)

func TestP04OriginalAccessSelectionPreservesDenyAndDetachedResult(t *testing.T) {
	s := p04Service(t)
	obj := p04File(t, s, p04Owner)
	ctx := context.Background()
	initialGrants := len(s.state.Grants)
	allowID, denyID := "PUBLIC_original_allow_001", "PUBLIC_original_deny_001"
	allowed, err := s.SetShareAccessOnce(ctx, p04Owner, obj.ID, p04Other, true, 1, allowID)
	if err != nil || objectRevision(allowed) != 2 {
		t.Fatal(allowed, err)
	}
	denied, err := s.SetShareAccessOnce(ctx, p04Owner, obj.ID, p04Other, false, 2, denyID)
	if err != nil || objectRevision(denied) != 3 {
		t.Fatal(denied, err)
	}
	duplicate, err := s.SetShareAccessOnce(ctx, p04Owner, obj.ID, p04Other, true, 1, allowID)
	if err != nil || objectRevision(duplicate) != 3 || len(s.state.Grants) != initialGrants+2 {
		t.Fatal("old allow reapplied", duplicate, err)
	}
	if _, _, err = s.GetObjectVersion(ctx, p04Other, obj.ID, 0); !errors.Is(err, ErrDenied) {
		t.Fatal("old allow regained access", err)
	}
	if _, err = s.SetShareAccessOnce(ctx, p04Owner, obj.ID, p04Other, false, 1, allowID); !errors.Is(err, errObjectOperationConflict) {
		t.Fatal("changed decision admitted", err)
	}
	third := "ynx1PUBLIC_THIRD_ACCOUNT_0001"
	if _, err = s.SetShareAccessOnce(ctx, p04Owner, obj.ID, third, true, 1, allowID); !errors.Is(err, errObjectOperationConflict) {
		t.Fatal("changed target admitted", err)
	}
	if _, err = s.SetShareAccessOnce(ctx, p04Other, obj.ID, third, true, 3, "PUBLIC_foreign_access_001"); !errors.Is(err, ErrDenied) {
		t.Fatal("nonowner acquired permission", err)
	}
	view, err := s.GetObjectOperation(p04Owner, "cloud", allowID)
	if err != nil || view.Revision != "2" || view.Selection.Allow == nil || !*view.Selection.Allow || view.Selection.TargetSHA256 != objectAccessTargetBinding(p04Other) {
		t.Fatal(view, err)
	}
	*view.Selection.Allow = false
	again, _ := s.GetObjectOperation(p04Owner, "cloud", allowID)
	if !*again.Selection.Allow {
		t.Fatal("observer mutated original decision")
	}
	if _, err = s.PutObjectVersionOnce(ctx, p04Owner, obj.ID, 3, allowID, strings.NewReader("V2"), nil); !errors.Is(err, errObjectOperationConflict) {
		t.Fatal("cross action reuse admitted", err)
	}
	cancelled, cancel := context.WithCancel(ctx)
	cancel()
	if _, err = s.SetShareAccessOnce(cancelled, p04Owner, obj.ID, p04Other, true, 3, "PUBLIC_cancelled_access"); !errors.Is(err, context.Canceled) {
		t.Fatal("cancellation admitted", err)
	}
	raw, _ := json.Marshal(s.state.ObjectOperations)
	if strings.Contains(string(raw), p04Other) || strings.Contains(string(raw), third) {
		t.Fatal("plaintext ACL target retained in original records")
	}
}

func TestP04OriginalAccessConcurrentExactRequestSingleGrant(t *testing.T) {
	s := p04Service(t)
	obj := p04File(t, s, p04Owner)
	baseline := len(s.state.Grants)
	var wg sync.WaitGroup
	for i := 0; i < 6; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if _, err := s.SetShareAccessOnce(context.Background(), p04Owner, obj.ID, p04Other, true, 1, "PUBLIC_concurrent_allow_001"); err != nil {
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	if len(s.state.Grants) != baseline+1 || len(s.state.ObjectOperations) != 1 || objectRevision(s.state.Objects[obj.ID]) != 2 {
		t.Fatal("concurrent original granted more than once")
	}
}
