package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// Explicit PUBLIC registered-price/current and invoice HTTP protocol fixtures.
// Neither fixture is genuine Auth/merchant approval, the native Pay producer,
// a signed invoice_terms Member, BFT finality or a paid settlement.
type p04BillingPriceSource struct {
	mu        sync.Mutex
	schedules map[string]IDEUsagePriceSchedule
	calls     int
	denied    bool
}

func (p *p04BillingPriceSource) CurrentUsagePrice(_ context.Context, _ *http.Request, op IDEDeploymentOperation, a IDEUsageAggregate) (IDEUsagePricePermit, error) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.calls++
	if p.denied {
		return IDEUsagePricePermit{}, ErrDenied
	}
	return IDEUsagePricePermit{Principal: "PUBLIC_BILL_OWNER", RequestID: op.RequestID, Period: a.Period, SampleBinding: a.SampleBinding, MaximumAtoms: "1000000", Until: time.Now().Add(time.Minute), Schedule: p.schedules[a.Period]}, nil
}
func (p *p04BillingPriceSource) RecheckUsagePrice(_ context.Context, _ *http.Request, permit IDEUsagePricePermit) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.denied || p.schedules[permit.Period] != permit.Schedule {
		return ErrDenied
	}
	return nil
}

type p04BillingHTTPPay struct {
	base    string
	client  *http.Client
	creates atomic.Int32
	queries atomic.Int32
}

func (p *p04BillingHTTPPay) CreateUsageInvoice(ctx context.Context, request IDEUsageInvoiceRequest, current func() error) (IDEUsageInvoiceResult, error) {
	if err := current(); err != nil {
		return IDEUsageInvoiceResult{}, err
	}
	p.creates.Add(1)
	raw, _ := json.Marshal(request)
	r, _ := http.NewRequestWithContext(ctx, http.MethodPost, p.base+"/PUBLIC-TEST-ONLY/invoices", bytes.NewReader(raw))
	response, err := p.client.Do(r)
	if err != nil {
		return IDEUsageInvoiceResult{}, err
	}
	defer response.Body.Close()
	var result IDEUsageInvoiceResult
	err = json.NewDecoder(response.Body).Decode(&result)
	return result, err
}
func (p *p04BillingHTTPPay) LookupUsageInvoice(ctx context.Context, request IDEUsageInvoiceRequest) (IDEUsageInvoiceResult, error) {
	p.queries.Add(1)
	r, _ := http.NewRequestWithContext(ctx, http.MethodGet, p.base+"/PUBLIC-TEST-ONLY/invoices/"+request.BillID, nil)
	response, err := p.client.Do(r)
	if err != nil {
		return IDEUsageInvoiceResult{}, err
	}
	defer response.Body.Close()
	if response.StatusCode != 200 {
		return IDEUsageInvoiceResult{}, ErrNotFound
	}
	var result IDEUsageInvoiceResult
	err = json.NewDecoder(response.Body).Decode(&result)
	return result, err
}

func p04BillingFixture(t *testing.T) (*Server, *publicIDEAuthority, IDEDeploymentOperation, *p04BillingPriceSource) {
	t.Helper()
	s, auth, _, _ := publicIDEFixture(t)
	auth.principal = "PUBLIC_BILL_OWNER"
	body := []byte("PUBLIC billed artifact")
	op := IDEDeploymentOperation{RequestID: "P04_billing_original_0001", Binding: IDEArtifactBinding{ProjectID: "PUBLIC_PROJECT", Version: "1", ContentDigest: productHash(body), PublishPurpose: "deploy", TargetEnvironment: "PUBLIC_ENV", ByteSize: int64(len(body))}, ManifestSHA256: strings.Repeat("a", 64), ApprovalSHA256: strings.Repeat("b", 64), PublisherID: "PUBLIC_PUBLISHER", ResourceID: "PUBLIC_RESOURCE", CreatedAt: time.Date(2026, 10, 28, 0, 0, 0, 0, time.UTC)}
	var err error
	op, _, err = s.ideDeployments.journal.begin(auth.principal, op)
	if err != nil {
		t.Fatal(err)
	}
	op.DeploymentID = strings.Repeat("c", 64)
	op.RuntimeURL = "https://PUBLIC-fixture.invalid/runtime"
	op.State = "completed"
	zero := 0
	op.ExitCode = &zero
	op.UpdatedAt = time.Now()
	if err = s.ideDeployments.journal.recordTerminal(auth.principal, op, func() error { return nil }); err != nil {
		t.Fatal(err)
	}
	for i, period := range []string{"2026-10-28", "2026-10-29"} {
		start, _, _ := usagePeriod(period)
		at := start.Add(12 * time.Hour)
		cpu := []string{"1000000", "3000000"}[i]
		egress := []string{"10", "40"}[i]
		sample := IDEUsageSample{InstanceID: op.DeploymentID, Period: period, SampleSeq: fmt.Sprint(at.UnixNano()), CPUNanos: cpu, CPUms: []string{"1", "3"}[i], MemoryBytes: "4096", StoredBytes: fmt.Sprint(len(body)), EgressBytes: egress, ObservedAt: at}
		if _, err = s.ideDeployments.journal.recordUsage(auth.principal, op, sample, func() error { return nil }); err != nil {
			t.Fatal(err)
		}
	}
	prices := &p04BillingPriceSource{schedules: map[string]IDEUsagePriceSchedule{}}
	for i, period := range []string{"2026-10-28", "2026-10-29"} {
		start, end, _ := usagePeriod(period)
		prices.schedules[period] = IDEUsagePriceSchedule{ID: "PUBLIC_TARIFF", Revision: fmt.Sprint(i + 1), RegistrationRef: "PUBLIC_REGISTERED_PRICE_REF", CurrentRef: "PUBLIC_CURRENT_PRICE_REF", ApprovalRef: "PUBLIC_CURRENT_USAGE_APPROVAL", Merchant: "PUBLIC_LEDGER_MERCHANT", Recipient: "PUBLIC_REGISTERED_RECIPIENT", ResourceID: op.ResourceID, ProjectID: op.Binding.ProjectID, Asset: IDEUsageAsset{Genesis: strings.Repeat("d", 64), NativeChainID: "71", AssetID: "PUBLIC_LEDGER_ASSET", UnitVersion: "7"}, EffectiveFrom: start, EffectiveUntil: end, MeterRule: "cumulative-sample-end/UTC-day/ceil-total/v1", CPUNanos: IDEUsageRate{Units: "1000000", Atoms: []string{"2", "5"}[i]}, EgressBytes: IDEUsageRate{Units: "10", Atoms: "3"}, PeakStoredBytes: IDEUsageRate{Units: "64", Atoms: "1"}}
	}
	return s, auth, op, prices
}

func TestP04BillingVersionedPeriodsLostResponseAndRestart(t *testing.T) {
	s, auth, op, prices := p04BillingFixture(t)
	remoteFile := filepath.Join(t.TempDir(), "PUBLIC-pay-originals.json")
	var remoteMu sync.Mutex
	var lose atomic.Bool
	lose.Store(true)
	remoteHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		remoteMu.Lock()
		defer remoteMu.Unlock()
		records := map[string]IDEUsageInvoiceResult{}
		raw, err := os.ReadFile(remoteFile)
		if err == nil {
			if json.Unmarshal(raw, &records) != nil {
				http.Error(w, "corrupt", 500)
				return
			}
		}
		if r.Method == http.MethodGet {
			record, ok := records[strings.TrimPrefix(r.URL.Path, "/PUBLIC-TEST-ONLY/invoices/")]
			if !ok {
				http.NotFound(w, r)
				return
			}
			json.NewEncoder(w).Encode(record)
			return
		}
		var request IDEUsageInvoiceRequest
		if json.NewDecoder(r.Body).Decode(&request) != nil {
			http.Error(w, "invalid", 400)
			return
		}
		result := IDEUsageInvoiceResult{Request: request, InvoiceID: "PUBLIC_INVOICE_" + productHash([]byte(request.BillID)), OriginalOperation: "PUBLIC_ORIGINAL_" + productHash([]byte(request.BillID)), State: "PREPARED"}
		if original, ok := records[request.BillID]; ok {
			if original.Request != request {
				http.Error(w, "conflict", 409)
				return
			}
			result = original
		} else {
			records[request.BillID] = result
			data, _ := json.Marshal(records)
			if socialAtomicGuarded(remoteFile, data, nil) != nil {
				http.Error(w, "store", 500)
				return
			}
		}
		if lose.Swap(false) {
			conn, _, _ := w.(http.Hijacker).Hijack()
			conn.Close()
			return
		}
		json.NewEncoder(w).Encode(result)
	})
	remote := httptest.NewServer(remoteHandler)
	defer remote.Close()
	pay := &p04BillingHTTPPay{base: remote.URL, client: remote.Client()}
	if err := s.EnableIDEUsageBilling(prices, pay); err != nil {
		t.Fatal(err)
	}
	cloud := httptest.NewServer(s.Handler())
	defer cloud.Close()
	call := func(method, period string) IDEUsageBill {
		t.Helper()
		request, _ := http.NewRequest(method, cloud.URL+"/api/v1/ide/deployments/"+op.RequestID+"/billing/"+period, nil)
		response, err := cloud.Client().Do(request)
		if err != nil {
			t.Fatal(err)
		}
		defer response.Body.Close()
		raw, _ := io.ReadAll(response.Body)
		var bill IDEUsageBill
		if response.StatusCode != 200 && response.StatusCode != 202 {
			t.Fatalf("billing %d %s", response.StatusCode, raw)
		}
		if json.Unmarshal(raw, &bill) != nil {
			t.Fatal("invalid bill")
		}
		return bill
	}
	first := call("POST", "2026-10-28")
	if first.State != "UNKNOWN" || first.Request.Atoms != "6" || first.Settlement != "NOT_VERIFIED" || pay.creates.Load() != 1 {
		t.Fatalf("lost response repriced or repeated %+v", first)
	}
	// Both sides cold-read the same physical originals. Change the registered
	// current tariff afterward: an original bill must keep its frozen revision.
	cloud.Close()
	remote.Close()
	remote = httptest.NewServer(remoteHandler)
	defer remote.Close()
	pay.base = remote.URL
	pay.client = remote.Client()
	reopened := NewServer(s.service)
	if err := reopened.EnableIDEDeployments(auth, s.ideDeployments.executor); err != nil {
		t.Fatal(err)
	}
	if err := reopened.EnableIDEUsageBilling(prices, pay); err != nil {
		t.Fatal(err)
	}
	s = reopened
	prices.mu.Lock()
	changed := prices.schedules["2026-10-28"]
	changed.Revision = "99"
	changed.CPUNanos.Atoms = "999"
	prices.schedules["2026-10-28"] = changed
	prices.mu.Unlock()
	cloud = httptest.NewServer(s.Handler())
	defer cloud.Close()
	recovered := call("GET", "2026-10-28")
	if recovered.State != "PREPARED" || recovered.Request != first.Request || recovered.InvoiceID == "" || pay.creates.Load() != 1 {
		t.Fatal("original invoice lost or resubmitted")
	}
	again := call("POST", "2026-10-28")
	if again.InvoiceID != recovered.InvoiceID || pay.creates.Load() != 1 {
		t.Fatal("repeat created another invoice")
	}
	second := call("POST", "2026-10-29")
	if second.State != "PREPARED" || second.Request.Atoms != "20" || second.Request.ScheduleRevision != "2" || second.Request.BillID == first.Request.BillID || pay.creates.Load() != 2 {
		t.Fatalf("cross-period revision/delta incorrect %+v", second)
	}
	prices.mu.Lock()
	priceCalls := prices.calls
	prices.mu.Unlock()
	if priceCalls != 2 {
		t.Fatal("original invoice reconciliation requoted a changed price")
	}
	// Old samples can be read/deduped, but a sealed original period cannot be
	// changed into a second payable amount by a late sample or tariff revision.
	file := s.ideDeployments.journal.file(auth.principal, op.RequestID) + ".usage"
	record, err := readIDEUsage(file)
	if err != nil {
		t.Fatal(err)
	}
	duplicate := record.Latest
	if _, err = s.ideDeployments.journal.recordUsage(auth.principal, op, duplicate, func() error { return nil }); err != nil {
		t.Fatal(err)
	}
	late := duplicate
	late.ObservedAt = late.ObservedAt.Add(time.Second)
	late.SampleSeq = fmt.Sprint(late.ObservedAt.UnixNano())
	if _, err = s.ideDeployments.journal.recordUsage(auth.principal, op, late, func() error { return nil }); !errors.Is(err, ErrIDEUsagePeriodSealed) {
		t.Fatal("sealed price period accepted new sample")
	}
	if record.BillingState != "PERIOD_BILLS" || len(record.Bills) != 2 || record.Bills["2026-10-28"].Request.Atoms != "6" {
		t.Fatal("durable bill map not retained")
	}
	// The exact production retained-record route works while this executor has
	// no usage observer at all; reconciliation must not require a live engine.
	response, err := cloud.Client().Get(cloud.URL + "/api/v1/ide/deployments/" + op.RequestID + "/usage/records")
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	var retained IDEUsageRecord
	if response.StatusCode != 200 || json.NewDecoder(response.Body).Decode(&retained) != nil || len(retained.Bills) != 2 {
		t.Fatal("offline retained meter readback unavailable")
	}
}

func TestP04BillingMissingAuthorityOpenPeriodOverflowAndRevocation(t *testing.T) {
	s, auth, op, prices := p04BillingFixture(t)
	route := "/api/v1/ide/deployments/" + op.RequestID + "/billing/2026-10-28"
	out := httptest.NewRecorder()
	s.Handler().ServeHTTP(out, httptest.NewRequest("POST", route, nil))
	if out.Code != 503 || !strings.Contains(out.Body.String(), "UNPRICED") {
		t.Fatal("missing pricing enabled charge")
	}
	pay := &p04BillingHTTPPay{}
	if err := s.EnableIDEUsageBilling(prices, pay); err != nil {
		t.Fatal(err)
	}
	prices.denied = true
	out = httptest.NewRecorder()
	s.Handler().ServeHTTP(out, httptest.NewRequest("POST", route, nil))
	if out.Code != 503 || pay.creates.Load() != 0 {
		t.Fatal("missing current approval sent invoice")
	}
	prices.denied = false
	auth.readDeny = true
	out = httptest.NewRecorder()
	s.Handler().ServeHTTP(out, httptest.NewRequest("POST", route, nil))
	if out.Code != 403 || pay.creates.Load() != 0 {
		t.Fatal("revoked account read created invoice")
	}
	_, aggregate, err := s.ideDeployments.journal.usageBill(auth.principal, op, "2026-10-28")
	if !errors.Is(err, ErrNotFound) {
		t.Fatal(err)
	}
	schedule := prices.schedules["2026-10-28"]
	schedule.CPUNanos.Atoms = "18446744073709551615"
	aggregate.CPUNanos = "2000000"
	if _, err = priceIDEUsage(aggregate, schedule); err == nil {
		t.Fatal("ledger amount overflow accepted")
	}
	schedule.Asset.Genesis = ""
	if validateUsageSchedule(schedule, op, "2026-10-28") == nil {
		t.Fatal("missing original metadata accepted")
	}
	schedule = prices.schedules["2026-10-28"]
	schedule.Asset.UnitVersion = "0"
	if validateUsageSchedule(schedule, op, "2026-10-28") != nil {
		t.Fatal("metadata unit version zero was replaced by an invented minimum")
	}
	schedule.Revision = "01"
	if validateUsageSchedule(schedule, op, "2026-10-28") == nil {
		t.Fatal("noncanonical price revision accepted")
	}
}

type p04BillingNeverSend struct {
	creates, queries int
}

func (p *p04BillingNeverSend) CreateUsageInvoice(_ context.Context, r IDEUsageInvoiceRequest, current func() error) (IDEUsageInvoiceResult, error) {
	p.creates++
	if err := current(); err != nil {
		return IDEUsageInvoiceResult{}, err
	}
	return IDEUsageInvoiceResult{}, errors.New("PUBLIC response unavailable")
}

type p04BillingInFlight struct {
	creates atomic.Int32
	queries atomic.Int32
	entered chan struct{}
	release chan struct{}
}

func (p *p04BillingInFlight) CreateUsageInvoice(ctx context.Context, r IDEUsageInvoiceRequest, current func() error) (IDEUsageInvoiceResult, error) {
	if err := current(); err != nil {
		return IDEUsageInvoiceResult{}, err
	}
	p.creates.Add(1)
	close(p.entered)
	select {
	case <-ctx.Done():
		return IDEUsageInvoiceResult{}, ctx.Err()
	case <-p.release:
	}
	return IDEUsageInvoiceResult{Request: r, InvoiceID: "PUBLIC_ONE_INVOICE", OriginalOperation: "PUBLIC_ONE_ORIGINAL", State: "PREPARED"}, nil
}
func (p *p04BillingInFlight) LookupUsageInvoice(context.Context, IDEUsageInvoiceRequest) (IDEUsageInvoiceResult, error) {
	p.queries.Add(1)
	return IDEUsageInvoiceResult{}, ErrNotFound
}

func TestP04BillingInFlightConcurrencyAndFinalCurrentFence(t *testing.T) {
	t.Run("in-flight-original", func(t *testing.T) {
		s, auth, op, prices := p04BillingFixture(t)
		pay := &p04BillingInFlight{entered: make(chan struct{}), release: make(chan struct{})}
		if err := s.EnableIDEUsageBilling(prices, pay); err != nil {
			t.Fatal(err)
		}
		r := httptest.NewRequest("POST", "/PUBLIC_BILLING_FIXTURE", nil)
		current := func() error { return nil }
		finished := make(chan error, 1)
		go func() {
			_, err := s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, "2026-10-28", true, current)
			finished <- err
		}()
		select {
		case <-pay.entered:
		case <-time.After(3 * time.Second):
			t.Fatal("original invoice call did not enter")
		}
		second, err := s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, "2026-10-28", true, current)
		if err != nil || second.State != "UNKNOWN" || pay.creates.Load() != 1 || pay.queries.Load() != 1 {
			close(pay.release)
			<-finished
			t.Fatal("concurrent prepare multiplied original invoice")
		}
		close(pay.release)
		if err := <-finished; err != nil {
			t.Fatal(err)
		}
		bill, _, err := s.ideDeployments.journal.usageBill(auth.principal, op, "2026-10-28")
		if err != nil || bill.InvoiceID != "PUBLIC_ONE_INVOICE" || bill.Settlement != "NOT_VERIFIED" {
			t.Fatal("unique original invoice not retained")
		}
	})
	t.Run("revoked-after-durable-intent", func(t *testing.T) {
		s, auth, op, prices := p04BillingFixture(t)
		pay := &p04BillingNeverSend{}
		if err := s.EnableIDEUsageBilling(prices, pay); err != nil {
			t.Fatal(err)
		}
		current := func() error {
			record, err := readIDEUsage(s.ideDeployments.journal.file(auth.principal, op.RequestID) + ".usage")
			if err == nil && len(record.Bills) > 0 {
				return ErrDenied
			}
			return nil
		}
		r := httptest.NewRequest("POST", "/PUBLIC_BILLING_FIXTURE", nil)
		bill, err := s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, "2026-10-28", true, current)
		if err != nil || bill.State != "UNKNOWN" || pay.creates != 0 {
			t.Fatal("late revoke sent payable invoice")
		}
		if _, err = s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, "2026-10-28", true, func() error { return nil }); err != nil || pay.creates != 0 || pay.queries != 1 {
			t.Fatal("post-revoke unknown created another bill")
		}
		file := s.ideDeployments.journal.file(auth.principal, op.RequestID) + ".usage"
		record, err := readIDEUsage(file)
		if err != nil {
			t.Fatal(err)
		}
		forged := record.Bills["2026-10-28"]
		forged.State = "PAID"
		record.Bills["2026-10-28"] = forged
		raw, _ := json.Marshal(record)
		if err = socialAtomicGuarded(file, raw, nil); err != nil {
			t.Fatal(err)
		}
		if _, _, err = s.ideDeployments.journal.usageBill(auth.principal, op, "2026-10-28"); err == nil {
			t.Fatal("unverified paid field accepted from stored record")
		}
	})
}
func (p *p04BillingNeverSend) LookupUsageInvoice(context.Context, IDEUsageInvoiceRequest) (IDEUsageInvoiceResult, error) {
	p.queries++
	return IDEUsageInvoiceResult{}, ErrNotFound
}

func TestP04BillingZeroPriceOpenPeriodAndCrashBeforeSend(t *testing.T) {
	s, auth, op, prices := p04BillingFixture(t)
	pay := &p04BillingNeverSend{}
	if err := s.EnableIDEUsageBilling(prices, pay); err != nil {
		t.Fatal(err)
	}
	r := httptest.NewRequest("POST", "/api/v1/ide/deployments/"+op.RequestID+"/billing/2026-10-28", nil)
	current := func() error { return nil }
	// A closed period with a registered zero tariff is a zero-charge record,
	// not an uncertain invoice or a paid receipt.
	schedule := prices.schedules["2026-10-28"]
	schedule.CPUNanos.Atoms = "0"
	schedule.EgressBytes.Atoms = "0"
	schedule.PeakStoredBytes.Atoms = "0"
	prices.schedules["2026-10-28"] = schedule
	bill, err := s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, "2026-10-28", true, current)
	if err != nil || bill.State != "NO_CHARGE" || bill.Settlement != "NOT_APPLICABLE" || pay.creates != 0 {
		t.Fatal("zero tariff sent invoice or faked paid")
	}
	if _, err = s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, "2026-10-28", false, current); err != nil || pay.queries != 0 {
		t.Fatal("zero charge queried a nonexistent invoice")
	}
	// An open day cannot be frozen into a payable invoice.
	s.ideDeployments.now = func() time.Time { return time.Date(2026, 10, 29, 13, 0, 0, 0, time.UTC) }
	if _, err = s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, "2026-10-29", true, current); !errors.Is(err, ErrIDEUsagePeriodOpen) {
		t.Fatal("open-period price created")
	}
	s.ideDeployments.now = time.Now
	// Persist the exact original bill BEFORE a send, then simulate the process
	// dying in that gap. Recovery sees absence remotely but never creates again.
	_, aggregate, err := s.ideDeployments.journal.usageBill(auth.principal, op, "2026-10-29")
	if !errors.Is(err, ErrNotFound) {
		t.Fatal(err)
	}
	schedule = prices.schedules["2026-10-29"]
	amount, err := priceIDEUsage(aggregate, schedule)
	if err != nil {
		t.Fatal(err)
	}
	request := IDEUsageInvoiceRequest{BillID: "cloud_usage_" + productHash([]byte(auth.principal+"\x00"+op.RequestID+"\x00"+op.DeploymentID+"\x00"+aggregate.Period)), RequestID: op.RequestID, InstanceID: op.DeploymentID, Period: aggregate.Period, ScheduleID: schedule.ID, ScheduleRevision: schedule.Revision, RegistrationRef: schedule.RegistrationRef, ApprovalRef: schedule.ApprovalRef, Merchant: schedule.Merchant, Recipient: schedule.Recipient, Asset: schedule.Asset, Atoms: amount, SampleBinding: aggregate.SampleBinding}
	prepared := IDEUsageBill{Request: request, Schedule: schedule, Aggregate: aggregate, State: "UNKNOWN", Settlement: "NOT_VERIFIED", CreatedAt: time.Now().UTC(), UpdatedAt: time.Now().UTC()}
	if _, claim, err := s.ideDeployments.journal.reserveUsageBill(auth.principal, op, prepared, current); err != nil || !claim {
		t.Fatal(err)
	}
	recovered, err := s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, aggregate.Period, true, current)
	if err != nil || recovered.State != "UNKNOWN" || pay.creates != 0 || pay.queries != 1 {
		t.Fatal("pre-send uncertainty retried billing")
	}
}
