package cloud

import (
	"context"
	"errors"
	"io"
	"net/http/httptest"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"
)

func p04PrivateHostConfig(t *testing.T) OriginalPrivateHostConfig {
	t.Helper()
	root := t.TempDir()
	return OriginalPrivateHostConfig{Cloud: Config{StatePath: filepath.Join(root, "state.json"), ObjectDir: filepath.Join(root, "objects")}}
}
func p04ClosePrivateHost(t *testing.T, h *OriginalPrivateHost) {
	t.Helper()
	h.Retire()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := h.Join(ctx); err != nil {
		t.Fatal(err)
	}
	if err := h.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestP04PrivateHostNormalParentsNoSourceNoJournal(t *testing.T) {
	cfg := p04PrivateHostConfig(t)
	h, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer p04ClosePrivateHost(t, h)
	service, server, reader, err := h.Parents()
	if err != nil || service == nil || server == nil || reader == nil {
		t.Fatal("normal parents missing", err)
	}
	if server.service != service || reader.journal != server.originalIDEJournal || server.ideDeployments != nil {
		t.Fatal("lookalike parents or fake execution admission")
	}
	second, err := server.OpenOriginalIDEUsageBillReader()
	if err != nil || second != reader {
		t.Fatal("second reader identity", err)
	}
	if got, _ := h.Service(); got != service {
		t.Fatal("service replaced")
	}
	if got, _ := h.Server(); got != server {
		t.Fatal("server replaced")
	}
	if got, _ := h.BillReader(); got != reader {
		t.Fatal("reader replaced")
	}
	if _, err = os.Stat(cfg.Cloud.StatePath + ".ide-deployments"); !errors.Is(err, os.ErrNotExist) {
		t.Fatal("readonly binding created journal", err)
	}
	if _, err = reader.Capture(context.Background(), "PUBLIC_OWNER", "req_missing_original_00001", "2026-10-28"); err == nil {
		t.Fatal("missing bill became provenance")
	}
	handler, err := h.Handler()
	if err != nil {
		t.Fatal(err)
	}
	for _, route := range []struct {
		method, path string
		status       int
	}{{"GET", "/health", 200}, {"POST", "/api/v1/ide/deployments", 503}, {"GET", "/api/v1/ide/deployments/req_missing_original_00001", 503}} {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, httptest.NewRequest(route.method, route.path, nil))
		if w.Code != route.status {
			t.Fatalf("normal handler %s => %d: %s", route.path, w.Code, w.Body.String())
		}
	}
	if _, err = os.Stat(cfg.Cloud.StatePath + ".ide-deployments"); !errors.Is(err, os.ErrNotExist) {
		t.Fatal("missing Source effect allocated journal", err)
	}
	if err = h.StorageRecoveryError(); err != nil {
		t.Fatal("fresh normal storage recovery failed", err)
	}
}

func TestP04PrivateHostReadColdOriginalBillWithoutExecutionSource(t *testing.T) {
	prior, owner, op, bill, pay := p04OriginalBillFixture(t)
	state := prior.service.cfg.StatePath
	objects := prior.service.cfg.ObjectDir
	prior.RetireOriginalIDEUsageBillReader() // previous PUBLIC fixture process stops
	file := prior.ideDeployments.journal.file(owner, op.RequestID) + ".usage"
	before, err := os.ReadFile(file)
	if err != nil {
		t.Fatal(err)
	}
	h, err := OpenOriginalPrivateHost(context.Background(), OriginalPrivateHostConfig{Cloud: Config{StatePath: state, ObjectDir: objects}})
	if err != nil {
		t.Fatal(err)
	}
	defer p04ClosePrivateHost(t, h)
	_, server, reader, err := h.Parents()
	if err != nil || server.ideDeployments != nil {
		t.Fatal("cold reader required fake execution Source", err)
	}
	held, err := reader.Capture(context.Background(), owner, op.RequestID, bill.Request.Period)
	if err != nil {
		t.Fatal(err)
	}
	defer held.Close()
	data, err := held.DATA()
	if err != nil || data.Bill != bill || bill.State != "UNKNOWN" || pay.creates != 1 || pay.lookups != 0 {
		t.Fatal("original cold bill changed/replayed", err)
	}
	after, err := os.ReadFile(file)
	if err != nil || string(before) != string(after) {
		t.Fatal("normal host modified bill", err)
	}
	if _, err = reader.Capture(context.Background(), "OTHER_TENANT", op.RequestID, bill.Request.Period); err == nil {
		t.Fatal("cold cross tenant original accepted")
	}
	// PUBLIC execution gate only, no effect. The admitted executor and reader
	// now share the exact same original journal object, not just equal paths.
	if err = server.EnableIDEDeployments(&publicIDEAuthority{principal: owner}, &publicIDEExecutor{}); err != nil {
		t.Fatal(err)
	}
	if server.ideDeployments.journal != reader.journal {
		t.Fatal("execution opened a second journal")
	}
}

type p04PrivateHeldBody struct {
	entered, release chan struct{}
	once             sync.Once
}

func (b *p04PrivateHeldBody) Read([]byte) (int, error) {
	b.once.Do(func() { close(b.entered) })
	<-b.release
	return 0, io.EOF
}
func (*p04PrivateHeldBody) Close() error { return nil }

func TestP04PrivateHostRetainBlockedOriginalHandlerAndFirstClose(t *testing.T) {
	h, err := OpenOriginalPrivateHost(context.Background(), p04PrivateHostConfig(t))
	if err != nil {
		t.Fatal(err)
	}
	handler, err := h.Handler()
	if err != nil {
		t.Fatal(err)
	}
	body := &p04PrivateHeldBody{entered: make(chan struct{}), release: make(chan struct{})}
	request := httptest.NewRequest("POST", "/api/v1/session", body)
	done := make(chan struct{})
	go func() { defer close(done); handler.ServeHTTP(httptest.NewRecorder(), request) }()
	select {
	case <-body.entered:
	case <-time.After(2 * time.Second):
		close(body.release)
		t.Fatal("original session handler never read its actual body")
	}
	if err = h.Close(); !errors.Is(err, ErrOriginalPrivateHostChildrenRetained) {
		close(body.release)
		t.Fatal("close discarded admitted request", err)
	}
	if h.closed || h.service == nil || h.server == nil || h.reader == nil {
		close(body.release)
		t.Fatal("live parent discarded")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err = h.Join(ctx); !errors.Is(err, context.Canceled) {
		close(body.release)
		t.Fatal("cancelled Join pretended drained", err)
	}
	w := httptest.NewRecorder()
	handler.ServeHTTP(w, httptest.NewRequest("GET", "/health", nil))
	if w.Code != 503 {
		close(body.release)
		t.Fatal("retired handler admitted new request")
	}
	if _, _, _, err = h.Parents(); err == nil {
		close(body.release)
		t.Fatal("retired host minted new parent access")
	}
	close(body.release)
	<-done
	drain, stop := context.WithTimeout(context.Background(), 2*time.Second)
	defer stop()
	if err = h.Join(drain); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 2; i++ {
		if err = h.Close(); !errors.Is(err, ErrOriginalPrivateHostChildrenRetained) || !h.closed {
			t.Fatal("cleanup lost first retained-child failure", err)
		}
	}
}

func TestP04PrivateHostPartialAndParentCancellation(t *testing.T) {
	cfg := p04PrivateHostConfig(t)
	bad := cfg
	bad.Cloud.StatePath = "relative/state.json"
	h, err := OpenOriginalPrivateHost(context.Background(), bad)
	if h == nil || !errors.Is(err, ErrInvalid) {
		t.Fatal("partial discarded", err)
	}
	if err = h.Join(context.Background()); err != nil {
		t.Fatal(err)
	}
	if err = h.Close(); !errors.Is(err, ErrInvalid) {
		t.Fatal("original constructor failure replaced", err)
	}
	if _, err = os.Stat(cfg.Cloud.StatePath); !errors.Is(err, os.ErrNotExist) {
		t.Fatal("invalid constructor touched state", err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	h, err = OpenOriginalPrivateHost(ctx, cfg)
	if err != nil {
		t.Fatal(err)
	}
	reader, _ := h.BillReader()
	cancel()
	if err = h.Join(context.Background()); err != nil {
		t.Fatal(err)
	}
	if !reader.retired.Load() {
		t.Fatal("parent cancellation did not retire actual reader")
	}
	if err = h.Close(); err != nil {
		t.Fatal(err)
	}
}
