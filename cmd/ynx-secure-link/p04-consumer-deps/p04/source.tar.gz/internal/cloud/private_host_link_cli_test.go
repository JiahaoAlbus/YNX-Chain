package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
)

func TestP04OriginalLinkCLIHashOnlyLostCreateCancelCold(t *testing.T) {
	// Actual original host/storage/HTTP. PUBLIC Wallet verifier, not admission.
	cfg := p04PrivateHostConfig(t)
	cfg.Cloud.WalletVerifier = acceptWallet{}
	cfg.Limits = ServerLimits{MaxConcurrent: 32, RequestsPerMinute: 10000}
	h, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if h != nil {
			p04ClosePrivateHost(t, h)
		}
	}()
	service, _ := h.Service()
	mint := func(account, nonce string) string {
		e := testWalletEnvelope(t, service, "cloud", nonce, []string{"files.read", "files.write", "permissions.manage"})
		if account != owner {
			e.WalletApproval.Account = account
			c, err := service.CreateWalletChallenge(e.AuthorizationRequest, e.WalletApproval)
			if err != nil {
				t.Fatal(err)
			}
			e.GatewayCompletion.Challenge = c
		}
		token, _, err := service.CreateSession(context.Background(), e)
		if err != nil {
			t.Fatal(err)
		}
		return token
	}
	tokens := map[string]string{"owner": mint(owner, "PUBLIC_LINK_OWNER"), "other": mint(viewer, "PUBLIC_LINK_OTHER")}
	handler, _ := h.Handler()
	var mu sync.RWMutex
	var creates, cancels atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		drop := false
		if r.Method == "POST" && strings.Contains(r.URL.Path, "/links/original/") {
			if strings.HasSuffix(r.URL.Path, "/cancel") {
				drop = cancels.Add(1) <= 2
			} else {
				drop = creates.Add(1) == 1
			}
		}
		if drop {
			saved := httptest.NewRecorder()
			handler.ServeHTTP(saved, r)
			if saved.Code != 200 {
				t.Errorf("before lost ACK %d %s", saved.Code, saved.Body.String())
			}
			conn, _, e := w.(http.Hijacker).Hijack()
			if e == nil {
				_ = conn.Close()
			}
			return
		}
		handler.ServeHTTP(w, r)
	}))
	defer srv.Close()
	root := t.TempDir()
	if err = os.Chmod(root, 0700); err != nil {
		t.Fatal(err)
	}
	script, _ := filepath.Abs("../../apps/cloud/client/link-cli.fixture.mjs")
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	run := func(stage string, original json.RawMessage) json.RawMessage {
		t.Helper()
		in, _ := json.Marshal(map[string]any{"base": srv.URL + "/api/v1", "tokens": tokens, "root": root, "stage": stage, "original": original})
		cmd := exec.Command(node, script)
		cmd.Stdin = bytes.NewReader(in)
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		out, e := cmd.Output()
		if e != nil {
			t.Fatalf("capability CLI %s %v %s", stage, e, stderr.String())
		}
		if !json.Valid(out) {
			t.Fatal("invalid output")
		}
		return out
	}
	reopen := func() {
		p04ClosePrivateHost(t, h)
		h = nil
		next, e := OpenOriginalPrivateHost(context.Background(), cfg)
		if e != nil {
			t.Fatal(e)
		}
		nextHandler, _ := next.Handler()
		mu.Lock()
		h = next
		handler = nextHandler
		mu.Unlock()
		service, _ = next.Service()
	}
	original := run("initial", nil)
	reopen()
	original = run("create-cold", original)
	reopen()
	result := run("cancel-cold", original)
	if creates.Load() != 2 || cancels.Load() != 2 || len(service.state.Links) != 2 || len(service.state.ObjectOperations) != 3 {
		t.Fatal("original capability replay", creates.Load(), cancels.Load(), len(service.state.Links), len(service.state.ObjectOperations))
	}
	raw, _ := json.Marshal(service.state)
	for _, name := range []string{"original.json", "prepared-cancel.json", "legacy.json"} {
		b, e := os.ReadFile(filepath.Join(root, name))
		if e != nil {
			t.Fatal(e)
		}
		var r struct{ Token string }
		if json.Unmarshal(b, &r) != nil || r.Token == "" || bytes.Contains(raw, []byte(r.Token)) || bytes.Contains(result, []byte(r.Token)) {
			t.Fatal("plaintext capability escaped custody")
		}
	}
	t.Logf("originalCreateCommitted=1 lateCancelledCreateRejected=1 cancelPOST=2 cold=2 links=2(includesLegacy1) rawSecretInServer=false %s", result)
}
