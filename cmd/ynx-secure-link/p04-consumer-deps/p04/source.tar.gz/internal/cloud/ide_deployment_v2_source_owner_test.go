//go:build cloud_auth_v2

package cloud

import (
	"context"
	"errors"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
)

// An unqualified interface is never substituted for the concrete original
// owner. Embedded methods would panic if the constructor tried to acquire it.
type p04UnqualifiedDeploymentSource struct {
	developerauthority.OriginalSource
	touched bool
}

func (s *p04UnqualifiedDeploymentSource) AssertSourceCurrent(context.Context) error {
	s.touched = true
	return developerauthority.ErrDenied
}

func TestP04DeploymentV2NormalConstructorRequiresExplicitOriginalOwner(t *testing.T) {
	foreign := &p04UnqualifiedDeploymentSource{}
	var typedNil *developerauthority.OriginalIDEPublicationSourceOwner
	orphan := &developerauthority.OriginalIDEPublicationSourceOwner{}
	cancelled, cancel := context.WithCancel(context.Background())
	cancel()
	for _, tc := range []struct {
		name    string
		ctx     context.Context
		catalog *developerauthority.Catalog
		source  developerauthority.OriginalSource
	}{
		{"missing-owner", context.Background(), &developerauthority.Catalog{}, nil},
		{"typed-nil-owner", context.Background(), &developerauthority.Catalog{}, typedNil},
		{"interface-is-not-owner", context.Background(), &developerauthority.Catalog{}, foreign},
		{"concrete-owner-not-catalog-owner", context.Background(), &developerauthority.Catalog{}, orphan},
		{"no-catalog", context.Background(), nil, orphan},
		{"no-context", nil, &developerauthority.Catalog{}, orphan},
		{"caller-cancelled", cancelled, &developerauthority.Catalog{}, orphan},
	} {
		t.Run(tc.name, func(t *testing.T) {
			opened, err := OpenAuthIDEDeploymentV2Authority(tc.ctx, tc.catalog, tc.source)
			if opened != nil || !errors.Is(err, developerauthority.ErrDenied) {
				t.Fatalf("unqualified original pair acquired authority: %T %v", opened, err)
			}
		})
	}
	if foreign.touched {
		t.Fatal("foreign interface acquired before concrete owner check")
	}
}
