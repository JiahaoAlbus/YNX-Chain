package cloud

import (
	"context"
	"errors"
	"testing"
	"time"
)

func TestP04OriginalLinkSnapshotUnknownRequiresSameCommitReconcile(t *testing.T) {
	for _, mode := range []string{"create", "cancel-unissued", "cancel-issued"} {
		t.Run(mode, func(t *testing.T) {
			cfg := p04PrivateHostConfig(t)
			h, err := OpenOriginalPrivateHost(context.Background(), cfg)
			if err != nil {
				t.Fatal(err)
			}
			defer func() { p04ClosePrivateHost(t, h) }()
			s, _ := h.Service()
			obj, err := s.Create(context.Background(), owner, CreateObjectRequest{Kind: KindFile, Name: "PUBLIC_cap.bin", Content: []byte("PUBLIC")})
			if err != nil {
				t.Fatal(err)
			}
			expiry := s.cfg.Now().Add(time.Hour).Truncate(time.Millisecond)
			digest := hashBytes([]byte("PUBLIC_client_only_secret"))
			id := "PUBLIC_unknown_capability"
			if mode == "cancel-issued" {
				if _, err = s.CreateLinkOnce(context.Background(), owner, obj.ID, id, digest, "viewer", expiry, 1); err != nil {
					t.Fatal(err)
				}
			}
			s.cfg.stateDirectorySync = func(string) error { return errors.New("PUBLIC capability directory sync failed after rename") }
			action := "link.cancel-original"
			if mode == "create" {
				_, err = s.CreateLinkOnce(context.Background(), owner, obj.ID, id, digest, "viewer", expiry, 1)
				action = "link.create"
			} else {
				err = s.CancelOriginalLink(context.Background(), owner, obj.ID, id, digest, "viewer", expiry, 1)
			}
			if !errors.Is(err, errObjectCommitUnknown) {
				t.Fatal(err)
			}
			if view, e := s.GetObjectOperation(owner, "cloud", id); e != nil || view.Outcome != "UNKNOWN" {
				t.Fatal("uncertain original promoted", view, e)
			}
			p04ClosePrivateHost(t, h)
			h, err = OpenOriginalPrivateHost(context.Background(), cfg)
			if err != nil {
				t.Fatal(err)
			}
			s, _ = h.Service()
			if view, e := s.GetObjectOperation(owner, "cloud", id); e != nil || view.Outcome != "UNKNOWN" {
				t.Fatal("cold original promoted", view, e)
			}
			observed, e := s.ReconcileObjectCommit(context.Background())
			if e != nil || observed.Action != action || observed.Outcome != "COMMITTED" {
				t.Fatal(observed, e)
			}
			view, e := s.GetObjectOperation(owner, "cloud", id)
			if e != nil {
				t.Fatal(e)
			}
			if mode == "cancel-unissued" {
				if view.Outcome != "CANCELLED" || len(s.state.Links) != 0 {
					t.Fatal(view)
				}
			} else {
				if view.Outcome != "COMMITTED" || view.Link == nil || len(s.state.Links) != 1 {
					t.Fatal(view)
				}
				if mode == "cancel-issued" && view.Link.RevokedAt == nil {
					t.Fatal("issued cancellation lost")
				}
			}
		})
	}
}
