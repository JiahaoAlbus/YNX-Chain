package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
)

func TestP04OriginalAccessCLILostAllowDenyColdNoRegrant(t *testing.T) {
	// Original normal service, disk and HTTP. Admission is a PUBLIC Wallet
	// fixture; no genuine Source/Root or user account is supplied by this test.
	cfg := p04PrivateHostConfig(t)
	cfg.Cloud.WalletVerifier = acceptWallet{}
	cfg.Limits = ServerLimits{MaxConcurrent: 32, RequestsPerMinute: 10000}
	h, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if h != nil {
			p04ClosePrivateHost(t, h)
		}
	}()
	service, _ := h.Service()
	token := func(account, nonce string, scopes []string) string {
		e := testWalletEnvelope(t, service, "cloud", nonce, scopes)
		if account != owner {
			e.WalletApproval.Account = account
			c, err := service.CreateWalletChallenge(e.AuthorizationRequest, e.WalletApproval)
			if err != nil {
				t.Fatal(err)
			}
			e.GatewayCompletion.Challenge = c
		}
		raw, _, err := service.CreateSession(context.Background(), e)
		if err != nil {
			t.Fatal(err)
		}
		return raw
	}
	tokens := map[string]string{
		"owner":  token(owner, "PUBLIC_ACL_OWNER", []string{"files.read", "files.write", "permissions.manage"}),
		"manage": token(owner, "PUBLIC_ACL_MANAGE", []string{"files.read", "permissions.manage"}),
		"write":  token(owner, "PUBLIC_ACL_WRITE", []string{"files.read", "files.write"}),
		"viewer": token(viewer, "PUBLIC_ACL_VIEWER", []string{"files.read", "files.write", "permissions.manage"}),
	}
	handler, _ := h.Handler()
	var mu sync.RWMutex
	var accessPuts atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		if r.Method == http.MethodPut && strings.Contains(r.URL.Path, "/access/") {
			number := accessPuts.Add(1)
			if number <= 2 {
				saved := httptest.NewRecorder()
				handler.ServeHTTP(saved, r)
				if saved.Code != 200 {
					t.Errorf("original ACL before lost response %d %s", saved.Code, saved.Body.String())
				}
				conn, _, err := w.(http.Hijacker).Hijack()
				if err == nil {
					_ = conn.Close()
				}
				return
			}
		}
		handler.ServeHTTP(w, r)
	}))
	defer srv.Close()
	root := t.TempDir()
	if err = os.Chmod(root, 0700); err != nil {
		t.Fatal(err)
	}
	script, _ := filepath.Abs("../../apps/cloud/client/object-access-cli.fixture.mjs")
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	run := func(stage string, original json.RawMessage) json.RawMessage {
		t.Helper()
		in, _ := json.Marshal(map[string]any{"base": srv.URL + "/api/v1", "tokens": tokens, "target": viewer, "root": root, "stage": stage, "original": original})
		cmd := exec.Command(node, script)
		cmd.Stdin = bytes.NewReader(in)
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		out, err := cmd.Output()
		if err != nil {
			t.Fatalf("ACL CLI %s: %v %s", stage, err, stderr.String())
		}
		if !json.Valid(out) {
			t.Fatal("invalid CLI result")
		}
		for _, token := range tokens {
			if strings.Contains(string(out), token) {
				t.Fatal("credential in output")
			}
		}
		return out
	}
	reopen := func() {
		p04ClosePrivateHost(t, h)
		h = nil
		next, e := OpenOriginalPrivateHost(context.Background(), cfg)
		if e != nil {
			t.Fatal(e)
		}
		nextHandler, _ := next.Handler()
		mu.Lock()
		h = next
		handler = nextHandler
		mu.Unlock()
		service, _ = next.Service()
	}
	original := run("initial", nil)
	reopen()
	original = run("allow-cold", original)
	reopen()
	result := run("deny-cold", original)
	if accessPuts.Load() != 2 || len(service.state.ObjectOperations) != 3 || len(service.state.Objects) != 1 || len(service.state.Grants) != 2 {
		t.Fatal("ACL original replayed", accessPuts.Load(), len(service.state.ObjectOperations), len(service.state.Grants))
	}
	records, _ := json.Marshal(service.state.ObjectOperations)
	if strings.Contains(string(records), viewer) {
		t.Fatal("target plaintext in retained original records")
	}
	t.Logf("normalACL PUT=2 grants=2 originalRecords=3 cold=2 manageWithoutFilesWrite=true fileWriteNotManage=true targetStillDenied=true %s", result)
}
