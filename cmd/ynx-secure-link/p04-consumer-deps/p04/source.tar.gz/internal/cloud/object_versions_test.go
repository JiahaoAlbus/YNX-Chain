package cloud

import (
	"bytes"
	"context"
	"crypto/sha3"
	"crypto/sha512"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

func p04File(t *testing.T, s *Service, actor string) Object {
	t.Helper()
	o, err := s.Create(context.Background(), actor, CreateObjectRequest{Kind: KindFile, Name: "report.txt", MIME: "text/plain", Content: []byte("V1")})
	if err != nil {
		t.Fatal(err)
	}
	return o
}

func TestP04ObjectVersionPutCAS(t *testing.T) {
	s := p04Service(t)
	a := p04File(t, s, p04Owner)
	b := p04File(t, s, p04Other)
	if s.state.Versions[a.ID][0].BlobPath == s.state.Versions[b.ID][0].BlobPath {
		t.Fatal("same bytes coupled independent owner storage")
	}
	if got, body, err := s.GetObjectVersion(context.Background(), p04Other, a.ID, 1); !errors.Is(err, ErrDenied) || got.ID != "" || len(body) != 0 {
		t.Fatal("other tenant received content or metadata")
	}
	var wg sync.WaitGroup
	var lock sync.Mutex
	wins := 0
	conflicts := 0
	for _, body := range []string{"V2-A", "V2-B"} {
		wg.Add(1)
		go func(body string) {
			defer wg.Done()
			_, err := s.PutObjectVersion(context.Background(), p04Owner, a.ID, 1, strings.NewReader(body), nil)
			lock.Lock()
			defer lock.Unlock()
			if err == nil {
				wins++
			} else {
				var conflict ConflictError
				if errors.As(err, &conflict) {
					conflicts++
				} else {
					t.Errorf("unexpected result: %v", err)
				}
			}
		}(body)
	}
	wg.Wait()
	if wins != 1 || conflicts != 1 || len(s.state.Versions[a.ID]) != 2 {
		t.Fatalf("CAS wins=%d conflicts=%d versions=%d", wins, conflicts, len(s.state.Versions[a.ID]))
	}
	current, body, err := s.GetObjectVersion(context.Background(), p04Owner, a.ID, 0)
	if err != nil || current.Binding == nil || current.Binding.Bytes != int64(len(body)) {
		t.Fatalf("binding missing: %v", err)
	}
	left, right := sha3.Sum512(body), sha512.Sum512(body)
	if current.Binding.SHA3512 != hex.EncodeToString(left[:]) || current.Binding.SHA512 != hex.EncodeToString(right[:]) {
		t.Fatal("independent double-digest mismatch")
	}
	if _, err = s.PutObjectVersion(context.Background(), p04Other, a.ID, 2, strings.NewReader("foreign"), nil); !errors.Is(err, ErrDenied) {
		t.Fatal("foreign writer accepted")
	}
}

type p04FailReader struct{}

func (p04FailReader) Read(p []byte) (int, error) { copy(p, "partial"); return 7, io.ErrUnexpectedEOF }

type p04CancelReader struct{ cancel context.CancelFunc }

func (r p04CancelReader) Read(p []byte) (int, error) { r.cancel(); copy(p, "late"); return 4, io.EOF }

func TestP04ObjectVersionFailedInputNeverAdvances(t *testing.T) {
	for _, name := range []string{"partial", "cancel", "oversize", "sha3", "sha512", "length", "metadata-save"} {
		t.Run(name, func(t *testing.T) {
			s := p04Service(t)
			o := p04File(t, s, p04Owner)
			ctx := context.Background()
			var reader io.Reader = strings.NewReader("V2")
			var expected *ObjectBinding
			switch name {
			case "partial":
				reader = p04FailReader{}
			case "cancel":
				var cancel context.CancelFunc
				ctx, cancel = context.WithCancel(ctx)
				defer cancel()
				reader = p04CancelReader{cancel}
			case "oversize":
				reader = io.LimitReader(&p04RepeatReader{}, MaxUploadBytes+1)
			case "sha3", "sha512", "length":
				binding := bindObjectBytes([]byte("V2"))
				if name == "sha3" {
					binding.SHA3512 = strings.Repeat("0", 128)
				}
				if name == "sha512" {
					binding.SHA512 = strings.Repeat("0", 128)
				}
				if name == "length" {
					binding.Bytes++
				}
				expected = &binding
			case "metadata-save":
				s.cfg.StatePath = t.TempDir()
			}
			if _, err := s.PutObjectVersion(ctx, p04Owner, o.ID, 1, reader, expected); err == nil {
				t.Fatal("failed input accepted")
			}
			if s.state.Objects[o.ID].Version != 1 || len(s.state.Versions[o.ID]) != 1 {
				t.Fatal("failed input changed authoritative current/history")
			}
			_, body, err := s.Content(p04Owner, o.ID, 0)
			if err != nil || string(body) != "V1" {
				t.Fatalf("old version damaged: %q %v", body, err)
			}
		})
	}
}

type p04RepeatReader struct{}

func (*p04RepeatReader) Read(p []byte) (int, error) {
	for i := range p {
		p[i] = 'x'
	}
	return len(p), nil
}

func TestP04ObjectVersionRestore(t *testing.T) {
	s := p04Service(t)
	o := p04File(t, s, p04Owner)
	second, err := s.PutObjectVersion(context.Background(), p04Owner, o.ID, 1, strings.NewReader("V2"), nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = s.RestoreObjectVersion(context.Background(), p04Owner, o.ID, 1, 1); err == nil {
		t.Fatal("stale restore accepted")
	}
	restored, err := s.RestoreObjectVersion(context.Background(), p04Owner, o.ID, 1, second.Revision)
	if err != nil {
		t.Fatal(err)
	}
	if restored.Version != 3 || s.state.Versions[o.ID][2].RestoredFrom != 1 {
		t.Fatal("restore did not append provenance")
	}
	reopened, err := New(s.cfg)
	if err != nil {
		t.Fatal(err)
	}
	for version, want := range map[int]string{1: "V1", 2: "V2", 3: "V1"} {
		got, body, err := reopened.Content(p04Owner, o.ID, version)
		if err != nil || string(body) != want || got.Version != version {
			t.Fatalf("reopen version%d: %q %v", version, body, err)
		}
	}
	// Crash residue is not a version and cannot overwrite a committed address.
	if err = os.WriteFile(filepath.Join(s.cfg.ObjectDir, ".cloud-blob-interrupted"), []byte("partial"), 0600); err != nil {
		t.Fatal(err)
	}
	_, body, err := reopened.Content(p04Owner, o.ID, 0)
	if err != nil || string(body) != "V1" {
		t.Fatal("temporary object damaged current")
	}
}

func TestP04ObjectVersionShareRevocation(t *testing.T) {
	s := p04Service(t)
	o := p04File(t, s, p04Owner)
	shared, err := s.SetShareAccess(context.Background(), p04Owner, o.ID, p04Other, true, 1)
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err = s.Content(p04Other, o.ID, 0); err != nil {
		t.Fatal(err)
	}
	if _, err = s.SetShareAccess(context.Background(), p04Owner, o.ID, p04Other, false, 1); err == nil {
		t.Fatal("stale ACL CAS accepted")
	}
	if _, err = s.SetShareAccess(context.Background(), p04Owner, o.ID, p04Other, false, shared.Revision); err != nil {
		t.Fatal(err)
	}
	if _, body, err := s.Content(p04Other, o.ID, 0); !errors.Is(err, ErrDenied) || len(body) != 0 {
		t.Fatal("revoked principal received bytes")
	}
	link, token, err := s.CreateLink(p04Owner, o.ID, "viewer", time.Now().Add(time.Hour))
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err = s.ResolveLinkContent(token); err != nil {
		t.Fatal(err)
	}
	if _, err = s.RevokeLink(p04Owner, o.ID, link.ID); err != nil {
		t.Fatal(err)
	}
	if _, body, err := s.ResolveLinkContent(token); err == nil || len(body) != 0 {
		t.Fatal("revoked link received bytes")
	}
	folder, err := s.Create(context.Background(), p04Owner, CreateObjectRequest{Kind: KindFolder, Name: "shared"})
	if err != nil {
		t.Fatal(err)
	}
	child, err := s.Create(context.Background(), p04Owner, CreateObjectRequest{Kind: KindFile, ParentID: folder.ID, Name: "report.txt", Content: []byte("child")})
	if err != nil {
		t.Fatal(err)
	}
	if _, err = s.Grant(p04Owner, folder.ID, p04Other, "viewer", nil); err != nil {
		t.Fatal(err)
	}
	if _, _, err = s.Content(p04Other, child.ID, 0); err != nil {
		t.Fatal(err)
	}
	if _, err = s.SetShareAccess(context.Background(), p04Owner, child.ID, p04Other, false, 1); err != nil {
		t.Fatal(err)
	}
	if _, _, err = s.Content(p04Other, child.ID, 0); !errors.Is(err, ErrDenied) {
		t.Fatal("parent grant bypassed explicit child denial")
	}
}

func TestP04ObjectVersionHTTPRoundTrip(t *testing.T) {
	// Isolated real HTTP listener + existing PUBLIC wallet verifier fixture.
	// This proves normal routing, not real account/Source admission or deployment.
	s := testService(t, nil)
	envelope := testWalletEnvelope(t, s, "cloud", "P04-J0-HTTP", []string{"files.read", "files.write", "permissions.manage"})
	token, _, err := s.CreateSession(context.Background(), envelope)
	if err != nil {
		t.Fatal(err)
	}
	server := httptest.NewServer(NewServer(s).Handler())
	defer server.Close()
	request := func(method, path string, body []byte, revision string) *http.Response {
		t.Helper()
		req, err := http.NewRequest(method, server.URL+path, bytes.NewReader(body))
		if err != nil {
			t.Fatal(err)
		}
		req.Header.Set("Authorization", "Bearer "+token)
		if revision != "" {
			req.Header.Set("X-Expected-Revision", revision)
		}
		res, err := server.Client().Do(req)
		if err != nil {
			t.Fatal(err)
		}
		return res
	}
	res := request("POST", "/api/v1/objects", []byte(`{"kind":"file","name":"report.txt","mime":"text/plain","content":"VjE="}`), "")
	var first Object
	if res.StatusCode != 201 {
		t.Fatalf("create %d", res.StatusCode)
	}
	if err = json.NewDecoder(res.Body).Decode(&first); err != nil {
		t.Fatal(err)
	}
	res.Body.Close()
	res = request("PUT", "/api/v1/objects/"+first.ID+"/content", []byte("V2"), "1")
	if res.StatusCode != 201 {
		data, _ := io.ReadAll(res.Body)
		t.Fatalf("version put %d %s", res.StatusCode, data)
	}
	res.Body.Close()
	res = request("GET", "/api/v1/objects/"+first.ID+"/content?version=1", nil, "")
	data, err := io.ReadAll(res.Body)
	res.Body.Close()
	if err != nil || res.StatusCode != 200 || string(data) != "V1" {
		t.Fatalf("download %d %q %v", res.StatusCode, data, err)
	}
	a, b := sha3.Sum512(data), sha512.Sum512(data)
	if res.Header.Get("X-Content-SHA3-512") != hex.EncodeToString(a[:]) || res.Header.Get("X-Content-SHA512") != hex.EncodeToString(b[:]) || res.Header.Get("X-Object-Version") != "1" || res.Header.Get("Content-Length") != "2" {
		t.Fatal("independent client binding/version/length mismatch")
	}
	res = request("POST", "/api/v1/objects/"+first.ID+"/versions/1/restore", []byte(`{}`), "1")
	res.Body.Close()
	if res.StatusCode != 409 {
		t.Fatalf("stale HTTP restore %d", res.StatusCode)
	}
	res = request("POST", "/api/v1/objects/"+first.ID+"/versions/1/restore", []byte(`{}`), "2")
	res.Body.Close()
	if res.StatusCode != 200 {
		t.Fatalf("HTTP restore %d", res.StatusCode)
	}
	res = request("GET", "/api/v1/objects/"+first.ID+"/content?version=bad", nil, "")
	res.Body.Close()
	if res.StatusCode != 400 {
		t.Fatal("bad version defaulted to current")
	}
	res = request("PUT", "/api/v1/objects/"+first.ID+"/content", []byte("bad"), "")
	res.Body.Close()
	if res.StatusCode != 428 {
		t.Fatal("missing expected revision accepted")
	}
	foreign := p04File(t, s, p04Other)
	res = request("GET", "/api/v1/objects/"+foreign.ID+"/content", nil, "")
	foreignBody, _ := io.ReadAll(res.Body)
	res.Body.Close()
	if res.StatusCode != 403 || bytes.Contains(foreignBody, []byte("V1")) {
		t.Fatal("normal HTTP entry leaked another owner object")
	}
	res = request("PUT", "/api/v1/objects/"+first.ID+"/access/"+p04Other, []byte(`{"allow":true}`), "3")
	res.Body.Close()
	if res.StatusCode != 200 {
		t.Fatalf("HTTP share %d", res.StatusCode)
	}
	if _, _, err = s.Content(p04Other, first.ID, 0); err != nil {
		t.Fatal(err)
	}
	res = request("PUT", "/api/v1/objects/"+first.ID+"/access/"+p04Other, []byte(`{"allow":false}`), "4")
	res.Body.Close()
	if res.StatusCode != 200 {
		t.Fatalf("HTTP revoke %d", res.StatusCode)
	}
	if _, _, err = s.Content(p04Other, first.ID, 0); !errors.Is(err, ErrDenied) {
		t.Fatal("HTTP revoke left principal readable")
	}
}
