//go:build cloud_auth_v2

package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"mime/multipart"
	"net/http/httptest"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
)

func TestP04DeploymentV2OriginalAuthNoSourceRejectsWithoutClaim(t *testing.T) {
	// The real, source-linked original Auth constructor receives a concrete
	// Catalog with no commissioned Source. No callback grants readiness.
	if opened, err := OpenAuthIDEDeploymentV2Authority(context.Background(), &developerauthority.Catalog{}, nil); opened != nil || !errors.Is(err, developerauthority.ErrDenied) {
		t.Fatalf("normal missing Source changed: %T %v", opened, err)
	}
	codec, _, payload, body := p04V2SDKFixture(t)
	m := publicIDEOCIFixture(t)
	s := NewServer(testService(t, nil))
	a := &p04V2Authority{publicIDEAuthority: publicIDEAuthority{principal: "PUBLIC_V2_NO_SOURCE"}}
	if err := s.EnableIDEDeployments(a, m.e); err != nil {
		t.Fatal(err)
	}
	if err := s.EnableIDEDeploymentV2DATA(codec); err != nil {
		t.Fatal(err)
	}
	if err := s.AttachAuthIDEDeploymentV2(context.Background(), &developerauthority.Catalog{}, nil); err == nil {
		t.Fatal("uncommissioned Catalog enabled V2")
	}
	var encoded bytes.Buffer
	writer := multipart.NewWriter(&encoded)
	for _, part := range []struct {
		name string
		body []byte
	}{{"manifest", payload}, {"approval", []byte("PUBLIC_RAW_MEMBER_NOT_EXECUTE_APPROVAL")}, {"artifact", body}} {
		p, err := writer.CreateFormField(part.name)
		if err != nil {
			t.Fatal(err)
		}
		p.Write(part.body)
	}
	writer.Close()
	id := "P04_V2_actual_source_missing_01"
	r := httptest.NewRequest("POST", "/api/v1/ide/deployments", &encoded)
	r.Header.Set("Content-Type", writer.FormDataContentType())
	r.Header.Set("X-Deployment-Manifest-Version", "2")
	r.Header.Set("Idempotency-Key", id)
	r.Header.Set("X-Expected-Deployment-Revision", "0")
	out := httptest.NewRecorder()
	s.Handler().ServeHTTP(out, r)
	var failure map[string]any
	json.Unmarshal(out.Body.Bytes(), &failure)
	if out.Code != 503 || failure["error"] != "IDE_DEPLOYMENT_V2_AUTHORITY_UNAVAILABLE" || a.legacyAuthorize != 0 || m.creates != 0 || m.starts != 0 {
		t.Fatalf("actual missing Source crossed effect boundary: %d %s", out.Code, out.Body.String())
	}
	if _, err := s.ideDeployments.journal.lookup(a.principal, id); !errors.Is(err, ErrNotFound) {
		t.Fatal("missing original Source claimed deployment journal")
	}
	if err := s.CloseIDEDeploymentV2Authority(); err != nil {
		t.Fatal(err)
	}
	if err := s.CloseIDEDeploymentV2Authority(); err != nil {
		t.Fatal(err)
	}
	if s.ideDeployments.authority != a || s.ideDeployments.executor != m.e {
		t.Fatal("missing V2 replaced original runtime")
	}
}
