package cloud

import (
	"context"
	"os"
	"path/filepath"
	"testing"
)

const p04Owner = "ynx1publiccloudowner000000000001"
const p04Other = "ynx1publiccloudowner000000000002"

func p04Service(t *testing.T) *Service {
	t.Helper()
	dir := t.TempDir()
	s, err := New(Config{StatePath: filepath.Join(dir, "state.json"), ObjectDir: filepath.Join(dir, "objects")})
	if err != nil {
		t.Fatal(err)
	}
	return s
}

func TestP04ObjectVersionDownloadMetadata(t *testing.T) {
	s := p04Service(t)
	first, err := s.Create(context.Background(), p04Owner, CreateObjectRequest{Kind: KindDoc, Name: "report.txt", Content: []byte("version-one")})
	if err != nil {
		t.Fatal(err)
	}
	if _, err = s.SaveDocument(context.Background(), p04Owner, first.ID, SaveDocumentRequest{BaseVersion: 1, Content: []byte("second-version-longer")}); err != nil {
		t.Fatal(err)
	}
	got, body, err := s.Content(p04Owner, first.ID, 1)
	if err != nil {
		t.Fatal(err)
	}
	if string(body) != "version-one" || got.Version != 1 || got.Size != int64(len(body)) || got.Hash != hashBytes(body) {
		t.Fatalf("historical bytes returned with another version metadata: version=%d size=%d actual=%d hash=%s", got.Version, got.Size, len(body), got.Hash)
	}
}

func TestP04ObjectVersionRestoreCorruptOriginal(t *testing.T) {
	s := p04Service(t)
	first, err := s.Create(context.Background(), p04Owner, CreateObjectRequest{Kind: KindDoc, Name: "report.txt", Content: []byte("original")})
	if err != nil {
		t.Fatal(err)
	}
	if _, err = s.SaveDocument(context.Background(), p04Owner, first.ID, SaveDocumentRequest{BaseVersion: 1, Content: []byte("current")}); err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(s.state.Versions[first.ID][0].BlobPath, []byte("damaged!"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err = s.RestoreVersion(p04Owner, first.ID, 1); err == nil {
		t.Fatal("corrupt historical bytes promoted without verification")
	}
	if s.state.Objects[first.ID].Version != 2 || len(s.state.Versions[first.ID]) != 2 {
		t.Fatal("failed restore advanced current/history")
	}
}

func TestP04ObjectVersionDownloadLengthMismatch(t *testing.T) {
	s := p04Service(t)
	o, err := s.Create(context.Background(), p04Owner, CreateObjectRequest{Kind: KindFile, Name: "report.txt", Content: []byte("complete")})
	if err != nil {
		t.Fatal(err)
	}
	s.state.Versions[o.ID][0].Size++
	if _, body, err := s.Content(p04Owner, o.ID, 1); err == nil || len(body) != 0 {
		t.Fatal("download released bytes despite recorded length mismatch")
	}
}

func TestP04ObjectVersionBlobRejectsWrongAddress(t *testing.T) {
	root := t.TempDir()
	hash := hashBytes([]byte("expected"))
	if _, err := writeBlob(root, hash, []byte("different")); err == nil {
		t.Fatal("object accepted bytes under an unrelated content address")
	}
	if _, err := os.Stat(filepath.Join(root, hash[:2], hash)); !os.IsNotExist(err) {
		t.Fatal("wrong-address content was published")
	}
}
