package cloud

import (
	"context"
	"errors"
	"net/http"
	"sync"
	"testing"
)

// PUBLIC cleanup-port controls only. This fixture cannot supply a principal,
// validate V4, consume a nonce or grant any Source/runtime authority.
type publicIDEReadRelease struct {
	call func(context.Context, *http.Request) (bool, error)
}

func (p *publicIDEReadRelease) ReleaseOriginalFiniteGETRequest(c context.Context, r *http.Request) (bool, error) {
	return p.call(c, r)
}

func TestIDEReadCleanupOriginalCancelledDebtAndFirstCause(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	r, _ := http.NewRequestWithContext(ctx, "GET", "https://public.invalid/api/v1/ide/deployments/PUBLIC_request_0001", nil)
	first := errors.New("PUBLIC original child close unknown")
	calls := 0
	ready := false
	a := &publicIDEReadRelease{call: func(actual context.Context, actualRequest *http.Request) (bool, error) {
		calls++
		if actual != ctx || actualRequest != r {
			t.Fatal("original request/context replaced")
		}
		if ready {
			return true, nil
		}
		return false, first
	}}
	var debts originalIDEReadRequestDebts
	debts.capture(r, a)
	cancel()
	debts.release(r)
	if closed, err := debts.drain(); closed || err != first {
		t.Fatal("unconfirmed child forgotten", closed, err)
	}
	ready = true
	if closed, err := debts.drain(); !closed || err != first {
		t.Fatal("physical close erased first cause", closed, err)
	}
	before := calls
	debts.release(r)
	if closed, err := debts.drain(); !closed || err != first || calls != before {
		t.Fatal("closed child re-entered")
	}
}

func TestIDEReadCleanupDeniedPartialAndNoAttempt(t *testing.T) {
	for _, cause := range []error{nil, errors.New("PUBLIC denied partial")} {
		r, _ := http.NewRequest("GET", "https://public.invalid/", nil)
		calls := 0
		var debts originalIDEReadRequestDebts
		a := &publicIDEReadRelease{call: func(c context.Context, actual *http.Request) (bool, error) {
			calls++
			if c != r.Context() || actual != r {
				t.Fatal("request replaced")
			}
			return true, cause
		}}
		debts.capture(r, a)
		debts.release(r)
		closed, err := debts.drain()
		if !closed || err != cause || calls != 1 {
			t.Fatal("closed denied/no-attempt child lost", closed, err, calls)
		}
	}
}

func TestIDEReadCleanupConcurrentDrainReleasesOnceAndDoesNotHoldInventory(t *testing.T) {
	var debts originalIDEReadRequestDebts
	var wg sync.WaitGroup
	r, _ := http.NewRequest("GET", "https://public.invalid/", nil)
	other, _ := http.NewRequest("POST", "https://public.invalid/", nil)
	entered, leave := make(chan struct{}), make(chan struct{})
	calls := 0
	a := &publicIDEReadRelease{call: func(context.Context, *http.Request) (bool, error) {
		calls++
		debts.capture(other, nil)
		close(entered)
		<-leave
		return true, nil
	}}
	debts.capture(r, a)
	wg.Add(2)
	go func() { defer wg.Done(); debts.release(r) }()
	<-entered
	go func() { defer wg.Done(); debts.drain() }()
	close(leave)
	wg.Wait()
	if closed, err := debts.drain(); !closed || err != nil || calls != 1 {
		t.Fatal("duplicate release or lost physical debt", closed, err, calls)
	}
}
