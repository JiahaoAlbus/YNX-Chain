package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
)

func TestP04PrivateHostSessionCLIOriginalCredentialColdAndLostRevoke(t *testing.T) {
	// Real original host/HTTP/storage and separate CLI processes. PUBLIC Wallet
	// verifier only, never genuine Wallet or Root admission.
	cfg := p04PrivateHostConfig(t)
	cfg.Cloud.WalletVerifier = acceptWallet{}
	cfg.Limits = ServerLimits{MaxConcurrent: 32, RequestsPerMinute: 10000}
	h, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if h != nil {
			p04ClosePrivateHost(t, h)
		}
	}()
	service, _ := h.Service()
	makeToken := func(nonce, account string) string {
		e := testWalletEnvelope(t, service, "cloud", nonce, []string{"files.read", "files.write", "permissions.manage"})
		if account != owner {
			e.WalletApproval.Account = account
			challenge, err := service.CreateWalletChallenge(e.AuthorizationRequest, e.WalletApproval)
			if err != nil {
				t.Fatal(err)
			}
			e.GatewayCompletion.Challenge = challenge
		}
		token, _, err := service.CreateSession(context.Background(), e)
		if err != nil {
			t.Fatal(err)
		}
		return token
	}
	token, otherToken := makeToken("PUBLIC_PROFILE_ORIGINAL", owner), makeToken("PUBLIC_PROFILE_OTHER", owner)
	foreignToken := makeToken("PUBLIC_PROFILE_FOREIGN", viewer)
	var mu sync.RWMutex
	handler, _ := h.Handler()
	var deletes atomic.Int32
	var creates atomic.Int32
	var drop atomic.Bool
	drop.Store(true)
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		if strings.HasPrefix(r.URL.Path, "/api/v1/shares/") && r.Header.Get("Authorization") != "" {
			t.Error("anonymous capability forwarded account credential")
		}
		if r.Method == http.MethodPost && r.URL.Path == "/api/v1/objects" {
			creates.Add(1)
		}
		if r.Method == http.MethodDelete && r.URL.Path == "/api/v1/session" {
			deletes.Add(1)
			if drop.Swap(false) {
				original := httptest.NewRecorder()
				handler.ServeHTTP(original, r)
				if original.Code != 204 {
					t.Errorf("original revoke status %d", original.Code)
				}
				conn, _, err := w.(http.Hijacker).Hijack()
				if err == nil {
					_ = conn.Close()
				}
				return
			}
		}
		handler.ServeHTTP(w, r)
	}))
	defer srv.Close()
	root := t.TempDir()
	if err := os.Chmod(root, 0700); err != nil {
		t.Fatal(err)
	}
	script, err := filepath.Abs("../../apps/cloud/client/session-cli-journey.fixture.mjs")
	if err != nil {
		t.Fatal(err)
	}
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	run := func(stage string, original json.RawMessage) json.RawMessage {
		t.Helper()
		input, _ := json.Marshal(map[string]any{"base": srv.URL + "/api/v1", "token": token, "otherToken": otherToken, "foreignToken": foreignToken, "root": root, "stage": stage, "original": original})
		cmd := exec.Command(node, script)
		cmd.Stdin = bytes.NewReader(input)
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		out, err := cmd.Output()
		if err != nil {
			t.Fatalf("session CLI %s: %v %s", stage, err, stderr.String())
		}
		if !json.Valid(out) || strings.Contains(string(out), token) || strings.Contains(string(out), otherToken) {
			t.Fatal("sensitive/invalid CLI result")
		}
		return out
	}
	reopen := func() {
		t.Helper()
		p04ClosePrivateHost(t, h)
		h = nil
		next, err := OpenOriginalPrivateHost(context.Background(), cfg)
		if err != nil {
			t.Fatal(err)
		}
		nextHandler, _ := next.Handler()
		mu.Lock()
		h = next
		handler = nextHandler
		mu.Unlock()
		service, _ = next.Service()
	}
	original := run("initial", nil)
	reopen()
	run("cold", original)
	reopen()
	run("revoked-cold", original)
	if deletes.Load() != 1 || creates.Load() != 1 || len(service.state.Objects) != 1 || len(service.state.ObjectOperations) != 1 || len(service.state.Sessions) != 2 {
		t.Fatal("session/object original replayed", deletes.Load(), len(service.state.Objects), len(service.state.Sessions))
	}
	// Fresh normal host without session or Wallet admission must refuse401 and
	// must not create a private credential file from an unadmitted token.
	p04ClosePrivateHost(t, h)
	h = nil
	cfg.Cloud.WalletVerifier = nil
	cfg.Cloud.StatePath = filepath.Join(t.TempDir(), "state.json")
	cfg.Cloud.ObjectDir = filepath.Join(filepath.Dir(cfg.Cloud.StatePath), "objects")
	h, err = OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	handler, _ = h.Handler()
	token = "PUBLIC_NOT_ADMITTED"
	otherToken = "PUBLIC_OTHER_NOT_ADMITTED"
	run("unadmitted", nil)
	t.Log("actualCLI separateProcesses=true sameSessionCold=true objectOriginals=1 sessionDELETE=1 lostReplyGETonly=true otherSessionRetained=true normalUnadmitted=401 PUBLICWalletOnly=true")
}
