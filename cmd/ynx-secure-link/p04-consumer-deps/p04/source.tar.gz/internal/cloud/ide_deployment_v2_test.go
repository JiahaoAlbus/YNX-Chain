package cloud

import (
	"bytes"
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

type p04V2Fixture struct {
	ActualHex  string        `json:"actualHex"`
	PayloadHex string        `json:"payloadHex"`
	Binding    ObjectBinding `json:"binding"`
}

func p04V2SDKFixture(t *testing.T) (*IDEDeploymentV2Codec, p04V2Fixture, []byte, []byte) {
	t.Helper()
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal("Node SDK dependency required")
	}
	node, err = filepath.Abs(node)
	if err != nil {
		t.Fatal(err)
	}
	bridge, err := filepath.Abs("../../apps/cloud/client/deployment-v2-bridge.mjs")
	if err != nil {
		t.Fatal(err)
	}
	codec, err := NewIDEDeploymentV2Codec(node, bridge)
	if err != nil {
		t.Fatal(err)
	}
	raw, err := os.ReadFile("../../apps/cloud/client/node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json")
	if err != nil {
		t.Fatal("run offline npm ci in apps/cloud/client before V2 consumer tests: ", err)
	}
	var fixture p04V2Fixture
	if json.Unmarshal(raw, &fixture) != nil {
		t.Fatal("invalid upstream fixture")
	}
	payload, err := hex.DecodeString(fixture.PayloadHex)
	if err != nil {
		t.Fatal(err)
	}
	artifact, err := hex.DecodeString(fixture.ActualHex)
	if err != nil {
		t.Fatal(err)
	}
	return codec, fixture, payload, artifact
}

func TestP04DeploymentV2HeldOriginalAndActualSDKReadback(t *testing.T) {
	codec, fixture, payload, artifact := p04V2SDKFixture(t)
	held, err := ReadIDEDeploymentArtifactV2(context.Background(), codec, bytes.NewReader(payload), bytes.NewReader(artifact), &fixture.Binding, MaxMultipartBytes)
	if err != nil {
		t.Fatal(err)
	}
	if held.Binding() != bindObjectBytes(payload) || held.Binding() != fixture.Binding || held.ContentBinding() != bindObjectBytes(artifact) {
		t.Fatal("actual standard-Go and sole-SDK double bindings differ")
	}
	manifest := held.Manifest()
	if manifest.Publisher.Rev != "7" || manifest.PublisherEpoch != "3" || manifest.Issuer.Rev != "29" || manifest.IssuerEpoch != "11" || manifest.Issuer.Realm == manifest.Realm || manifest.Project.ID != "project/original" {
		t.Fatal("fullRef or explicit epoch was inferred/replaced")
	}
	payload[0] ^= 255
	artifact[0] ^= 255
	if held.Binding() != bindObjectBytes(held.ManifestBytes()) {
		t.Fatal("caller mutation changed held original")
	}
	readback, err := io.ReadAll(held.OpenContent())
	if err != nil || bindObjectBytes(readback) != held.ContentBinding() {
		t.Fatal("held artifact readback changed")
	}
	copy := held.ManifestBytes()
	copy[0] ^= 255
	if held.ManifestBytes()[0] == copy[0] {
		t.Fatal("accessor exposed mutable payload")
	}
	validPayload, _ := hex.DecodeString(fixture.PayloadHex)
	validArtifact, _ := hex.DecodeString(fixture.ActualHex)
	if _, err = ReadIDEDeploymentArtifactV2(context.Background(), codec, bytes.NewReader(validPayload), bytes.NewReader(artifact), &fixture.Binding, MaxMultipartBytes); !errors.Is(err, ErrIDEArtifactInput) {
		t.Fatal("tampered actual artifact accepted")
	}
	wrong := fixture.Binding
	wrong.SHA512 = held.ContentBinding().SHA512
	if _, err = ReadIDEDeploymentArtifactV2(context.Background(), codec, bytes.NewReader(validPayload), bytes.NewReader(validArtifact), &wrong, MaxMultipartBytes); !errors.Is(err, ErrIDEArtifactInput) {
		t.Fatal("artifact bind substituted for manifest bind")
	}
	if _, err = ReadIDEDeploymentArtifactV2(context.Background(), codec, bytes.NewReader([]byte(`{"projectId":"old"}`)), bytes.NewReader(validArtifact), nil, MaxMultipartBytes); !errors.Is(err, ErrIDEArtifactInput) {
		t.Fatal("legacy JSON accepted as V2")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err = ReadIDEDeploymentArtifactV2(ctx, codec, bytes.NewReader(validPayload), bytes.NewReader(validArtifact), nil, MaxMultipartBytes); !errors.Is(err, context.Canceled) {
		t.Fatal("cancelled V2 decode continued")
	}
}

type p04V2Authority struct {
	publicIDEAuthority
	legacyAuthorize int
	captureOriginal func(*http.Request) error
}

func (a *p04V2Authority) Principal(ctx context.Context, r *http.Request) (string, error) {
	if a.captureOriginal != nil {
		if err := a.captureOriginal(r); err != nil {
			return "", err
		}
	}
	return a.publicIDEAuthority.Principal(ctx, r)
}

func (a *p04V2Authority) Authorize(ctx context.Context, r *http.Request, p string, m, b []byte) (IDEDeploymentPermit, error) {
	a.legacyAuthorize++
	return a.publicIDEAuthority.Authorize(ctx, r, p, m, b)
}

func TestP04DeploymentV2NormalClientHTTPNeverUsesLegacyGrant(t *testing.T) {
	codec, _, payload, artifact := p04V2SDKFixture(t)
	s := NewServer(testService(t, nil))
	authority := &p04V2Authority{publicIDEAuthority: publicIDEAuthority{principal: "PUBLIC_V2_CALLER"}}
	executor := &publicIDEExecutor{}
	if err := s.EnableIDEDeployments(authority, executor); err != nil {
		t.Fatal(err)
	}
	if err := s.EnableIDEDeploymentV2DATA(codec); err != nil {
		t.Fatal(err)
	}
	server := httptest.NewServer(s.Handler())
	defer server.Close()
	script, err := filepath.Abs("../../apps/cloud/client/deployment-v2-workflow.fixture.mjs")
	if err != nil {
		t.Fatal(err)
	}
	input, _ := json.Marshal(map[string]string{"endpoint": server.URL + "/api/v1"})
	command := exec.Command(codec.node, script)
	command.Stdin = bytes.NewReader(input)
	if out, err := command.CombinedOutput(); err != nil {
		t.Fatalf("normal actual V2 SDK client: %v %s", err, out)
	}
	if authority.legacyAuthorize != 0 || executor.applies != 0 {
		t.Fatal("V2 DATA called legacy signer/authority or executed")
	}
	entries, err := os.ReadDir(s.ideDeployments.journal.original.root)
	if err != nil || len(entries) != 0 {
		t.Fatal("unsigned/unadmitted V2 DATA claimed a durable resource operation")
	}
	// Go sends another real request to the same production entry. Actual SDK
	// artifact mismatch is rejected before the absent V2 authority boundary.
	var body bytes.Buffer
	writer := multipart.NewWriter(&body)
	artifact[0] ^= 255
	for _, part := range []struct {
		name string
		body []byte
	}{{"manifest", payload}, {"approval", []byte("PUBLIC_NOT_V2_APPROVAL")}, {"artifact", artifact}} {
		field, _ := writer.CreateFormField(part.name)
		field.Write(part.body)
	}
	writer.Close()
	request, _ := http.NewRequest("POST", server.URL+"/api/v1/ide/deployments", &body)
	request.Header.Set("Content-Type", writer.FormDataContentType())
	request.Header.Set("Idempotency-Key", "P04_v2_tampered_original_02")
	request.Header.Set("X-Deployment-Manifest-Version", "2")
	request.Header.Set("X-Expected-Deployment-Revision", "0")
	response, err := server.Client().Do(request)
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	if response.StatusCode != 400 || authority.legacyAuthorize != 0 || executor.applies != 0 {
		t.Fatal("tampered V2 reached legacy authority/effect")
	}
}
