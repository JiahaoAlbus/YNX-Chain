package cloud

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
)

// PUBLIC handler lifetime seam only; no verifier, signer, nonce or Source.
type publicIDEReadHandlerRelease struct {
	publicIDEAuthority
	t                        *testing.T
	deny, ready              bool
	principalCalls, releases int
	request                  *http.Request
	ctx                      context.Context
	first                    error
}

func (a *publicIDEReadHandlerRelease) Principal(ctx context.Context, r *http.Request) (string, error) {
	a.principalCalls++
	a.ctx = ctx
	a.request = r
	if a.deny {
		return "", ErrDenied
	}
	return a.principal, nil
}
func (a *publicIDEReadHandlerRelease) AuthorizeV2(context.Context, *http.Request, string, IDEDeploymentV2Request) (IDEDeploymentV2Permit, error) {
	return nil, ErrDenied
}
func (a *publicIDEReadHandlerRelease) AuthorizeV2Read(context.Context, *http.Request, IDEDeploymentOperation) error {
	return ErrDenied
}
func (a *publicIDEReadHandlerRelease) ReleaseOriginalFiniteGETRequest(ctx context.Context, r *http.Request) (bool, error) {
	a.releases++
	if ctx != a.ctx || r != a.request {
		a.t.Fatal("cleanup replaced original request/context")
	}
	if a.ready {
		return true, nil
	}
	return false, a.first
}

func TestIDEReadCleanupSevenHandlersRetainDeniedAndNormalOriginalChild(t *testing.T) {
	paths := []string{"", "/logs", "/runtime", "/usage", "/usage/records", "/billing/2026-11-08", "/billing/2026-11-08/native-intent"}
	for _, denied := range []bool{false, true} {
		for _, suffix := range paths {
			name := "normal"
			if denied {
				name = "denied"
			}
			t.Run(name+suffix, func(t *testing.T) {
				s, _, executor, _ := publicIDEFixture(t)
				a := &publicIDEReadHandlerRelease{publicIDEAuthority: publicIDEAuthority{principal: "PUBLIC_TEST_ACCOUNT"}, t: t, deny: denied, first: errors.New("PUBLIC original child release unknown")}
				s.ideDeployments.authority = a
				s.ideDeployments.v2Authority = a
				r := httptest.NewRequest("GET", "/api/v1/ide/deployments/PUBLIC_original_request_001"+suffix, nil)
				w := httptest.NewRecorder()
				s.Handler().ServeHTTP(w, r)
				if a.principalCalls != 1 || a.releases != 1 || s.OriginalIDEReadCleanupComplete() {
					t.Fatal("handler skipped original partial cleanup", a.principalCalls, a.releases, w.Code)
				}
				if denied && w.Code != 403 {
					t.Fatal("denied partial exposed data", w.Code)
				}
				if w.Code == 200 {
					t.Fatal("PUBLIC missing operation became successful")
				}
				if closed, err := s.DrainOriginalIDEReadRequests(); closed || err != a.first {
					t.Fatal("unclosed child forgotten", closed, err)
				}
				a.ready = true
				if closed, err := s.DrainOriginalIDEReadRequests(); !closed || err != a.first || !s.OriginalIDEReadCleanupComplete() {
					t.Fatal("same child drain erased first cause", closed, err)
				}
				if a.principalCalls != 1 || executor.applies != 0 {
					t.Fatal("cleanup reauthenticated or executed")
				}
			})
		}
	}
}
