package cloud

import (
	"bytes"
	"context"
	"crypto/sha3"
	"crypto/sha512"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"mime/multipart"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

type p04DeploymentAuthority struct {
	publicIDEAuthority
	resource, publisher string
}

func TestP04DeploymentHeldDualBindingAndLegacyOriginal(t *testing.T) {
	m := publicIDEOCIFixture(t)
	manifest, _ := json.Marshal(m.p.Binding)
	artifact, err := ReadIDEDeploymentArtifact(context.Background(), bytes.NewReader(manifest), bytes.NewReader(m.body), m.p.Binding, MaxMultipartBytes)
	if err != nil {
		t.Fatal(err)
	}
	left, right := sha3.Sum512(m.body), sha512.Sum512(m.body)
	expected := ObjectBinding{Bytes: int64(len(m.body)), SHA3512: hex.EncodeToString(left[:]), SHA512: hex.EncodeToString(right[:])}
	if artifact.ContentBinding() != expected {
		t.Fatal("held bytes not independently dual-bound")
	}
	m.p.contentBinding = &expected
	wrong := expected
	wrong.SHA3512 = strings.Repeat("0", 128)
	m.p.contentBinding = &wrong
	if _, err = m.e.ApplyExisting(context.Background(), m.p, bytes.NewReader(m.body), func() error { return nil }); !errors.Is(err, ErrIDEArtifactInput) || m.creates != 0 || m.starts != 0 {
		t.Fatal("wrong dual binding dispatched")
	}
	j, err := newIDEDeploymentJournal(filepath.Join(t.TempDir(), "legacy"))
	if err != nil {
		t.Fatal(err)
	}
	op := m.operation()
	op.CreatedAt = time.Now()
	op.ContentBinding = nil
	prior, claim, err := j.begin(m.p.Principal, op)
	if err != nil || !claim {
		t.Fatal(err)
	}
	op.ContentBinding = &expected
	got, claim, err := j.begin(m.p.Principal, op)
	if err != nil || claim || got.ContentBinding != nil || got.RequestID != prior.RequestID {
		t.Fatal("legacy original was replayed or silently upgraded to new evidence")
	}
}

func (a *p04DeploymentAuthority) Authorize(c context.Context, r *http.Request, p string, m, b []byte) (IDEDeploymentPermit, error) {
	permit, err := a.publicIDEAuthority.Authorize(c, r, p, m, b)
	permit.ResourceID = a.resource
	permit.PublisherID = a.publisher
	return permit, err
}

func TestP04DeploymentReservationUsageRollbackAndOriginalRecovery(t *testing.T) {
	// PUBLIC Auth and OCI engine-protocol fixtures, with real private files,
	// locks, journal restart and HTTP over a Unix socket. NOT an actual container,
	// publisher signature, public runtime, tariff or paid settlement.
	m := publicIDEOCIFixture(t)
	a := &p04DeploymentAuthority{publicIDEAuthority: publicIDEAuthority{principal: m.p.Principal}, resource: m.p.ResourceID, publisher: m.p.PublisherID}
	rows := map[string]ideOCIInspection{}
	unknownStart := false
	m.e.run = func(_ context.Context, args ...string) ([]byte, error) {
		switch args[0] {
		case "image":
			return json.Marshal([]map[string]string{{"Id": m.e.cfg.ImageDigest}})
		case "create":
			m.creates++
			row := m.row
			row.ID = fmt.Sprintf("%064x", m.creates)
			row.Config.Labels = map[string]string{}
			for i, arg := range args {
				if arg == "--label" {
					kv := strings.SplitN(args[i+1], "=", 2)
					row.Config.Labels[kv[0]] = kv[1]
				}
				if arg == "--mount" {
					for _, v := range strings.Split(args[i+1], ",") {
						if strings.HasPrefix(v, "src=") {
							row.Mounts = append([]struct {
								Type, Source, Destination string
								RW                        bool
							}(nil), m.row.Mounts...)
							row.Mounts[0].Source = strings.TrimPrefix(v, "src=")
						}
					}
				}
			}
			row.Config.Cmd = append([]string(nil), args[len(args)-5:]...)
			row.State.Running = false
			row.State.Status = "created"
			rows[row.ID] = row
			return []byte(row.ID), nil
		case "inspect":
			row, ok := rows[args[len(args)-1]]
			if !ok {
				return nil, ErrNotFound
			}
			return json.Marshal([]ideOCIInspection{row})
		case "start":
			m.starts++
			row := rows[args[1]]
			row.State.Running = true
			row.State.Status = "running"
			rows[args[1]] = row
			if unknownStart {
				return nil, context.DeadlineExceeded
			}
			return []byte(args[1]), nil
		case "logs":
			return []byte("PUBLIC engine protocol fixture log, not executed application output"), nil
		}
		return nil, ErrInvalid
	}
	service := testService(t, nil)
	var server *Server
	var handler http.Handler
	restart := func() {
		t.Helper()
		server = NewServer(service)
		if err := server.EnableIDEDeployments(a, m.e); err != nil {
			t.Fatal(err)
		}
		handler = server.Handler()
	}
	restart()
	submit := func(body []byte, version, id, revision, target string) IDEDeploymentOperation {
		t.Helper()
		manifest, _ := json.Marshal(IDEArtifactBinding{ProjectID: m.p.Binding.ProjectID, Version: version, ContentDigest: productHash(body), PublishPurpose: "deploy", TargetEnvironment: m.e.cfg.TargetEnvironment, ByteSize: int64(len(body))})
		var encoded bytes.Buffer
		writer := multipart.NewWriter(&encoded)
		for _, v := range []struct {
			name string
			data []byte
		}{{"manifest", manifest}, {"approval", []byte("PUBLIC_FIXTURE_NOT_REAL_SIGNATURE")}, {"artifact", body}} {
			part, err := writer.CreateFormField(v.name)
			if err != nil {
				t.Fatal(err)
			}
			part.Write(v.data)
		}
		writer.Close()
		r := httptest.NewRequest(http.MethodPost, "/api/v1/ide/deployments", &encoded)
		r.Header.Set("Content-Type", writer.FormDataContentType())
		r.Header.Set("Idempotency-Key", id)
		r.Header.Set("X-Expected-Deployment-Revision", revision)
		if target != "" {
			r.Header.Set("X-Rollback-To", target)
		}
		out := httptest.NewRecorder()
		handler.ServeHTTP(out, r)
		var op IDEDeploymentOperation
		if json.Unmarshal(out.Body.Bytes(), &op) != nil || op.RequestID != id {
			t.Fatalf("normal deployment route rejected %d %s", out.Code, out.Body.String())
		}
		return op
	}
	first := submit(m.body, "1", "P04_deployment_original_01", "0", "")
	if first.State != "running" || first.SlotRevision != "1" || first.ContentBinding == nil || *first.ContentBinding != bindObjectBytes(m.body) || m.creates != 1 {
		t.Fatalf("first claim %+v", first)
	}
	// A stable engine sample reaches the production observer over a real local
	// Unix HTTP connection, not a caller-supplied usage JSON body.
	socketDir, err := os.MkdirTemp("/tmp", "p04-usage-")
	if err != nil {
		t.Fatal(err)
	}
	defer os.RemoveAll(socketDir)
	socket := filepath.Join(socketDir, "engine.sock")
	listener, err := net.Listen("unix", socket)
	if err != nil {
		t.Fatal(err)
	}
	observedAt := time.Now().UTC()
	cpu := uint64(12_000_000)
	engine := &http.Server{Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/containers/"+first.DeploymentID+"/stats" {
			http.NotFound(w, r)
			return
		}
		json.NewEncoder(w).Encode(map[string]any{"id": first.DeploymentID, "read": observedAt, "cpu_stats": map[string]any{"cpu_usage": map[string]any{"total_usage": cpu}}, "memory_stats": map[string]any{"usage": 4096}, "networks": map[string]any{"lo": map[string]any{"tx_bytes": 32}}})
	})}
	go engine.Serve(listener)
	defer engine.Close()
	m.e.cfg.Socket = socket
	usage := publicIDERead(handler, "/api/v1/ide/deployments/"+first.RequestID+"/usage")
	if usage.Code != 200 {
		t.Fatal(usage.Body.String())
	}
	var record IDEUsageRecord
	if json.Unmarshal(usage.Body.Bytes(), &record) != nil || len(record.Samples) != 1 || record.Latest.CPUms != "12" || record.Latest.StoredBytes != fmt.Sprint(len(m.body)) || record.BillingState != "UNPRICED" {
		t.Fatal("actual observed units not retained")
	}
	restart()
	usage = publicIDERead(handler, "/api/v1/ide/deployments/"+first.RequestID+"/usage")
	if usage.Code != 200 {
		t.Fatal(usage.Body.String())
	}
	json.Unmarshal(usage.Body.Bytes(), &record)
	if len(record.Samples) != 1 {
		t.Fatal("same sample charged/recorded twice after restart")
	}
	// End the fixture engine request before changing its fixed counters.
	engine.Close()
	listener.Close()
	row := rows[first.DeploymentID]
	row.State.Running = false
	row.State.Status = "exited"
	row.State.ExitCode = 0
	rows[first.DeploymentID] = row
	if out := publicIDERead(handler, "/api/v1/ide/deployments/"+first.RequestID); out.Code != 200 || !strings.Contains(out.Body.String(), `"state":"completed"`) {
		t.Fatal("original terminal observation missing")
	}
	secondBody := []byte("console.log('PUBLIC second artifact');\n")
	second := submit(secondBody, "2", "P04_deployment_second_002", "1", "")
	if second.State != "running" || second.SlotRevision != "2" || m.creates != 2 {
		t.Fatal("next revision not allocated once")
	}
	row = rows[second.DeploymentID]
	row.State.Running = false
	row.State.Status = "exited"
	row.State.ExitCode = 7
	rows[second.DeploymentID] = row
	publicIDERead(handler, "/api/v1/ide/deployments/"+second.RequestID)
	rollback := submit(m.body, "1", "P04_deployment_rollback_3", "2", first.RequestID)
	if rollback.State != "running" || rollback.SlotRevision != "3" || rollback.RollbackTarget != first.RequestID || rollback.Binding.Version != "1" || m.creates != 3 {
		t.Fatalf("rollback was not forward revision %+v", rollback)
	}
	row = rows[rollback.DeploymentID]
	row.State.Running = false
	row.State.Status = "exited"
	row.State.ExitCode = 0
	rows[rollback.DeploymentID] = row
	publicIDERead(handler, "/api/v1/ide/deployments/"+rollback.RequestID)
	stale := submit(m.body, "1", "P04_deployment_stale_0004", "2", first.RequestID)
	if stale.State != "failed" || m.creates != 3 || m.starts != 3 {
		t.Fatal("stale slot generation overwrote a newer revision")
	}
	unknownStart = true
	unknown := submit(secondBody, "2", "P04_deployment_unknown_05", "3", "")
	if unknown.State != "unknown" || m.creates != 4 || m.starts != 4 {
		t.Fatal("lost acknowledgment became a definite result")
	}
	restart()
	recovered := publicIDERead(handler, "/api/v1/ide/deployments/"+unknown.RequestID)
	if recovered.Code != 200 || !strings.Contains(recovered.Body.String(), `"slotRevision":"4"`) || !strings.Contains(recovered.Body.String(), `"state":"running"`) || m.creates != 4 || m.starts != 4 {
		t.Fatalf("original recovery replayed: %s", recovered.Body.String())
	}
	logs := publicIDERead(handler, "/api/v1/ide/deployments/"+unknown.RequestID+"/logs")
	if logs.Code != 200 || !strings.Contains(logs.Body.String(), `"runtimeLogSource":"original-resource"`) {
		t.Fatal("original log observation missing")
	}
	// Rollback selection remains owner scoped and cannot use failed/tampered
	// originals, reuse old approval IDs, or change its six signed manifest fields.
	permit := m.p
	permit.RequestID = "P04_rollback_negative_0006"
	permit.Binding = first.Binding
	b := bindObjectBytes(m.body)
	permit.contentBinding = &b
	r := httptest.NewRequest("POST", "/api/v1/ide/deployments", nil)
	r.Header.Set("X-Expected-Deployment-Revision", "4")
	r.Header.Set("X-Rollback-To", first.RequestID)
	if err := server.ideDeployments.selectResourceTransition(r, "PUBLIC_OTHER_ACCOUNT", &permit); err == nil {
		t.Fatal("cross-account rollback admitted")
	}
	r.Header.Set("X-Rollback-To", second.RequestID)
	if err := server.ideDeployments.selectResourceTransition(r, a.principal, &permit); err == nil {
		t.Fatal("failed deployment treated as last healthy")
	}
	r.Header.Set("X-Rollback-To", first.RequestID)
	permit.Binding.TargetEnvironment = "OTHER"
	if err := server.ideDeployments.selectResourceTransition(r, a.principal, &permit); err == nil {
		t.Fatal("rollback target environment substitution admitted")
	}
}

func TestP04DeploymentUsageConflictsAndCurrentFence(t *testing.T) {
	server, authority, _, handler := publicIDEFixture(t)
	body, manifest, _ := ideArtifactData(t)
	out := publicIDESubmit(t, handler, body, manifest, "P04_usage_original_000001")
	if out.Code != 201 {
		t.Fatal(out.Body.String())
	}
	op, err := server.ideDeployments.journal.lookup(authority.principal, "P04_usage_original_000001")
	if err != nil {
		t.Fatal(err)
	}
	// This pure record test uses a syntactically valid PUBLIC engine identity.
	op.RequestID = "P04_usage_record_00000002"
	op, _, err = server.ideDeployments.journal.begin(authority.principal, op)
	if err != nil {
		t.Fatal(err)
	}
	op.DeploymentID = strings.Repeat("b", 64)
	op.RuntimeURL = "https://public-fixture.invalid/original"
	op.State = "completed"
	code := 0
	op.ExitCode = &code
	op.UpdatedAt = time.Now()
	if err = server.ideDeployments.journal.recordTerminal(authority.principal, op, func() error { return nil }); err != nil {
		t.Fatal(err)
	}
	now := time.Now().UTC()
	sample := IDEUsageSample{InstanceID: op.DeploymentID, Period: now.Format("2006-01-02"), SampleSeq: fmt.Sprint(now.UnixNano()), CPUNanos: "10000000", CPUms: "10", MemoryBytes: "4096", StoredBytes: fmt.Sprint(len(body)), EgressBytes: "20", ObservedAt: now}
	j := server.ideDeployments.journal
	if _, err = j.recordUsage(authority.principal, op, sample, func() error { return nil }); err != nil {
		t.Fatal(err)
	}
	conflict := sample
	conflict.MemoryBytes = "4097"
	if _, err = j.recordUsage(authority.principal, op, conflict, func() error { return nil }); err == nil {
		t.Fatal("same sequence accepted another body")
	}
	conflict = sample
	conflict.ObservedAt = now.Add(time.Second)
	conflict.SampleSeq = fmt.Sprint(conflict.ObservedAt.UnixNano())
	conflict.CPUNanos = "1000000"
	conflict.CPUms = "1"
	if _, err = j.recordUsage(authority.principal, op, conflict, func() error { return nil }); err == nil {
		t.Fatal("cumulative CPU reset silently rebilled")
	}
	if _, err = j.recordUsage(authority.principal, op, sample, func() error { return ErrDenied }); err == nil {
		t.Fatal("revoked current read bypassed")
	}
	if _, err = j.recordUsage("PUBLIC_OTHER", op, sample, func() error { return nil }); err == nil {
		t.Fatal("cross-owner usage read/write admitted")
	}
}
