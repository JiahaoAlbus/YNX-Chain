package cloud

import (
	"context"
	"errors"
	"strings"
	"testing"
)

func TestP04OriginalVersionRequestsConflictAndNeverReplay(t *testing.T) {
	s := p04Service(t)
	obj := p04File(t, s, p04Owner)
	ctx := context.Background()
	requestID := "PUBLIC_original_put_001"
	put, err := s.PutObjectVersionOnce(ctx, p04Owner, obj.ID, 1, requestID, strings.NewReader("V2"), nil)
	if err != nil || put.Version != 2 {
		t.Fatal(put, err)
	}
	current, err := s.PutObjectVersion(ctx, p04Owner, obj.ID, 2, strings.NewReader("V3"), nil)
	if err != nil {
		t.Fatal(err)
	}
	duplicate, err := s.PutObjectVersionOnce(ctx, p04Owner, obj.ID, 1, requestID, strings.NewReader("V2"), nil)
	if err != nil || duplicate.Version != 3 || len(s.state.Versions[obj.ID]) != 3 {
		t.Fatal("duplicate changed original", duplicate, err)
	}
	if _, err = s.PutObjectVersionOnce(ctx, p04Owner, obj.ID, 1, requestID, strings.NewReader("DIFFERENT"), nil); !errors.Is(err, errObjectOperationConflict) {
		t.Fatal("changed original admitted", err)
	}
	if _, err = s.RestoreObjectVersionOnce(ctx, p04Owner, obj.ID, 1, objectRevision(current), requestID); !errors.Is(err, errObjectOperationConflict) {
		t.Fatal("cross-action request admitted", err)
	}
	original, err := s.GetObjectOperation(p04Owner, "cloud", requestID)
	if err != nil || original.Version != 2 || original.Revision != "2" || original.Selection.Action != "put" || original.Binding == nil || *original.Binding != bindObjectBytes([]byte("V2")) {
		t.Fatal("original result drifted", original, err)
	}
	original.Selection.ContentBinding.Bytes = 999
	again, _ := s.GetObjectOperation(p04Owner, "cloud", requestID)
	if again.Selection.ContentBinding.Bytes != 2 {
		t.Fatal("observation aliased authoritative selection")
	}
	if _, err = s.GetObjectOperation(p04Other, "cloud", requestID); !errors.Is(err, ErrNotFound) {
		t.Fatal("another actor observed private original", err)
	}
	cancelled, cancel := context.WithCancel(ctx)
	cancel()
	if _, err = s.RestoreObjectVersionOnce(cancelled, p04Owner, obj.ID, 1, 3, "PUBLIC_cancelled_restore"); !errors.Is(err, context.Canceled) {
		t.Fatal("cancelled restore admitted", err)
	}
	s.objectWriteErr = errObjectCommitUnknown
	if view, err := s.GetObjectOperation(p04Owner, "cloud", requestID); err != nil || view.Outcome != "UNKNOWN" {
		t.Fatal("unknown snapshot promoted", view, err)
	}
}
