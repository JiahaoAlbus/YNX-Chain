package cloud

import (
	"bytes"
	"context"
	"errors"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"
	"time"
)

// PUBLIC pricing/invoice port only; native Pay's actual producer/HTTP/Store
// evidence is reused from J6. This exercises V2 scope through real bill files.
type p04V2BillProducer struct {
	creates, queries int
	original         IDEUsageInvoiceResult
}

func (p *p04V2BillProducer) CreateUsageInvoice(_ context.Context, r IDEUsageInvoiceRequest, current func() error) (IDEUsageInvoiceResult, error) {
	if err := current(); err != nil {
		return IDEUsageInvoiceResult{}, err
	}
	p.creates++
	p.original = IDEUsageInvoiceResult{Request: r, InvoiceID: "PUBLIC_V2_ORIGINAL_INVOICE", OriginalOperation: "PUBLIC_V2_ORIGINAL_OPERATION", State: "PREPARED"}
	return p.original, nil
}
func (p *p04V2BillProducer) LookupUsageInvoice(_ context.Context, r IDEUsageInvoiceRequest) (IDEUsageInvoiceResult, error) {
	p.queries++
	if r != p.original.Request {
		return IDEUsageInvoiceResult{}, ErrDenied
	}
	return p.original, nil
}

func TestP04BillingV2FullProjectScopeSealAndColdOriginal(t *testing.T) {
	codec, _, payload, body := p04V2SDKFixture(t)
	held, err := ReadIDEDeploymentArtifactV2(context.Background(), codec, bytes.NewReader(payload), bytes.NewReader(body), nil, MaxMultipartBytes)
	if err != nil {
		t.Fatal(err)
	}
	s, auth, _, _ := publicIDEFixture(t)
	auth.principal = "PUBLIC_BILL_OWNER"
	manifest, binding, content := held.Manifest(), held.Binding(), held.ContentBinding()
	op := IDEDeploymentOperation{ManifestVersion: "2", CatalogProjectID: "PUBLIC_DISTINCT_CATALOG_PROJECTION", ManifestV2: &manifest, ManifestBinding: &binding, ContentBinding: &content, ArtifactSHA256: productHash(body), RequestID: "req_v2_billing_scope_000001", ManifestSHA256: productHash(payload), ApprovalSHA256: strings.Repeat("b", 64), PublisherID: "PUBLIC_V2_PUBLISHER", ResourceID: "PUBLIC_RESOURCE", CreatedAt: time.Date(2026, 10, 28, 0, 0, 0, 0, time.UTC)}
	op, _, err = s.ideDeployments.journal.begin(auth.principal, op)
	if err != nil {
		t.Fatal(err)
	}
	op.State = "completed"
	op.DeploymentID = strings.Repeat("c", 64)
	op.RuntimeURL = "https://public-fixture.invalid/runtime"
	zero := 0
	op.ExitCode = &zero
	op.UpdatedAt = time.Now()
	if err = s.ideDeployments.journal.recordTerminal(auth.principal, op, func() error { return nil }); err != nil {
		t.Fatal(err)
	}
	period := "2026-10-28"
	start, end, _ := usagePeriod(period)
	observed := start.Add(12 * time.Hour)
	_, err = s.ideDeployments.journal.recordUsage(auth.principal, op, IDEUsageSample{InstanceID: op.DeploymentID, Period: period, SampleSeq: strconv.FormatInt(observed.UnixNano(), 10), CPUNanos: "1000000", CPUms: "1", MemoryBytes: "4096", StoredBytes: strconv.Itoa(len(body)), EgressBytes: "0", ObservedAt: observed}, func() error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	schedule := IDEUsagePriceSchedule{ManifestVersion: "2", ProjectRef: manifest.Project, ProjectID: op.CatalogProjectID, ResourceID: op.ResourceID, ID: "PUBLIC_V2_TARIFF", Revision: "1", RegistrationRef: "PUBLIC_REGISTERED_PRICE", CurrentRef: "PUBLIC_PRICE_CURRENT", ApprovalRef: "PUBLIC_APPROVAL", Merchant: "PUBLIC_MERCHANT", Recipient: "PUBLIC_RECIPIENT", Asset: IDEUsageAsset{Genesis: strings.Repeat("d", 64), NativeChainID: "71", AssetID: "PUBLIC_ASSET", UnitVersion: "0"}, EffectiveFrom: start, EffectiveUntil: end, MeterRule: "cumulative-sample-end/UTC-day/ceil-total/v1", CPUNanos: IDEUsageRate{Units: "1000000", Atoms: "100"}, EgressBytes: IDEUsageRate{Units: "1", Atoms: "0"}, PeakStoredBytes: IDEUsageRate{Units: "1", Atoms: "0"}}
	prices := &p04BillingPriceSource{schedules: map[string]IDEUsagePriceSchedule{period: schedule}}
	pay := &p04V2BillProducer{}
	if err = s.EnableIDEUsageBilling(prices, pay); err != nil {
		t.Fatal(err)
	}
	r := httptest.NewRequest("POST", "/api/v1/ide/deployments/"+op.RequestID+"/billing/"+period, nil)
	for _, change := range []func(*IDEUsagePriceSchedule){func(p *IDEUsagePriceSchedule) { p.ManifestVersion = ""; p.ProjectRef = IDEDeploymentV2Ref{} }, func(p *IDEUsagePriceSchedule) { p.ProjectRef.Tenant = "OTHER_TENANT" }, func(p *IDEUsagePriceSchedule) { p.ProjectRef.Rev = "999" }, func(p *IDEUsagePriceSchedule) { p.ProjectID = manifest.Project.ID }} {
		wrong := schedule
		change(&wrong)
		prices.schedules[period] = wrong
		if _, err = s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, period, true, func() error { return nil }); !errors.Is(err, ErrIDEUsageUnpriced) || pay.creates != 0 {
			t.Fatal("V2 tariff ID projection/cross-scope created an invoice", err)
		}
	}
	prices.schedules[period] = schedule
	bill, err := s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, period, true, func() error { return nil })
	if err != nil || bill.State != "PREPARED" || bill.Request.Atoms != "100" || bill.Schedule.ProjectRef != manifest.Project || bill.Settlement != "NOT_VERIFIED" || pay.creates != 1 {
		t.Fatalf("V2 original tariff seal: %#v %v", bill, err)
	}
	reader, err := s.OpenOriginalIDEUsageBillReader()
	if err != nil {
		t.Fatal(err)
	}
	h, err := reader.Capture(context.Background(), auth.principal, op.RequestID, period)
	if err != nil {
		t.Fatal(err)
	}
	defer h.Close()
	provenance, err := h.DATA()
	if err != nil || provenance.ProjectRef != manifest.Project || provenance.ProjectID != op.CatalogProjectID || provenance.ProjectID == manifest.Project.ID || provenance.Bill != bill {
		t.Fatal("V2 provenance lost full ref/catalog/sealed bill", err)
	}
	cold, err := newIDEDeploymentJournal(s.ideDeployments.journal.original.root)
	if err != nil {
		t.Fatal(err)
	}
	s.ideDeployments.journal = cold
	changed := schedule
	changed.ProjectRef.Tenant = "OTHER_TENANT"
	prices.schedules[period] = changed
	recovered, err := s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, period, true, func() error { return nil })
	if err != nil || recovered.Request != bill.Request || recovered.Schedule != bill.Schedule || recovered.InvoiceID != bill.InvoiceID || pay.creates != 1 || pay.queries != 1 {
		t.Fatal("cold original bill changed scope or created again", err)
	}
}
