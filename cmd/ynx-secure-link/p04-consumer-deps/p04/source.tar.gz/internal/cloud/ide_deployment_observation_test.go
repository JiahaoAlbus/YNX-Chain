package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// PUBLIC protocol fixtures at the production adapter ports. Actual service,
// files, HTTP and independent CLI processes run; no OCI or genuine admission.
type p04ObservationExecutor struct {
	publicIDEExecutor
	unavailable, swapped atomic.Bool
	samples              atomic.Int32
}

func (*p04ObservationExecutor) revisionedIDEResource() {}
func (e *p04ObservationExecutor) ApplyExisting(ctx context.Context, p IDEDeploymentPermit, r io.Reader, current func() error) (IDEDeploymentResult, error) {
	result, err := e.publicIDEExecutor.ApplyExisting(ctx, p, r, current)
	result.SlotRevision = "1"
	result.DeploymentID = strings.Repeat("a", 64)
	result.RuntimeKind = "bounded-node-job"
	e.observed = result
	return result, err
}
func (e *p04ObservationExecutor) ObserveOriginal(ctx context.Context, op IDEDeploymentOperation) (IDEDeploymentResult, error) {
	if e.unavailable.Load() {
		return IDEDeploymentResult{}, ErrIDEExistingRuntimeUnavailable
	}
	result, err := e.publicIDEExecutor.ObserveOriginal(ctx, op)
	if e.swapped.Load() {
		result.DeploymentID = "PUBLIC_OTHER_INSTANCE"
	}
	return result, err
}
func (e *p04ObservationExecutor) ObserveUsage(_ context.Context, op IDEDeploymentOperation) (IDEUsageSample, error) {
	e.samples.Add(1)
	at := time.Date(2026, 11, 1, 0, 0, 0, 0, time.UTC)
	return IDEUsageSample{InstanceID: op.DeploymentID, Period: "2026-11-01", SampleSeq: strconv.FormatInt(at.UnixNano(), 10), CPUNanos: "1000000", CPUms: "1", MemoryBytes: "4096", StoredBytes: strconv.FormatInt(op.Binding.ByteSize, 10), EgressBytes: "0", ObservedAt: at}, nil
}

func TestP04DeploymentRuntimeObservationColdCLIAndNoSamplingReplay(t *testing.T) {
	cfg := p04PrivateHostConfig(t)
	a := &publicIDEAuthority{principal: "PUBLIC_OBSERVATION_OWNER"}
	e := &p04ObservationExecutor{publicIDEExecutor: publicIDEExecutor{logBytes: []byte("PUBLIC original instance log")}}
	var host *OriginalPrivateHost
	var handler http.Handler
	var mu sync.RWMutex
	open := func() {
		t.Helper()
		h, err := OpenOriginalPrivateHost(context.Background(), cfg)
		if err != nil {
			t.Fatal(err)
		}
		s, _ := h.Server()
		if err = s.EnableIDEDeployments(a, e); err != nil {
			t.Fatal(err)
		}
		next, _ := h.Handler()
		mu.Lock()
		host, handler = h, next
		mu.Unlock()
	}
	open()
	defer func() { p04ClosePrivateHost(t, host) }()
	var posts atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		if r.Method == http.MethodPost && posts.Add(1) == 1 {
			reply := httptest.NewRecorder()
			handler.ServeHTTP(reply, r)
			if reply.Code != 201 {
				t.Errorf("original deployment %d %s", reply.Code, reply.Body.String())
			}
			conn, _, err := w.(http.Hijacker).Hijack()
			if err == nil {
				_ = conn.Close()
			}
			return
		}
		handler.ServeHTTP(w, r)
	}))
	defer srv.Close()
	root := t.TempDir()
	if err := os.Chmod(root, 0700); err != nil {
		t.Fatal(err)
	}
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	script, _ := filepath.Abs("../../apps/cloud/client/deployment-observation-cli.fixture.mjs")
	run := func(stage string) {
		t.Helper()
		in, _ := json.Marshal(map[string]string{"base": srv.URL + "/api/v1", "root": root, "stage": stage})
		cmd := exec.Command(node, script)
		cmd.Stdin = bytes.NewReader(in)
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		out, err := cmd.Output()
		if err != nil {
			t.Fatalf("%s %v %s", stage, err, stderr.String())
		}
		if !json.Valid(out) {
			t.Fatal("invalid original observation output")
		}
	}
	run("lost")
	p04ClosePrivateHost(t, host)
	open()
	run("cold")
	if e.samples.Load() != 1 {
		t.Fatal("explicit meter observation missing")
	}
	e.unavailable.Store(true)
	run("unavailable")
	e.unavailable.Store(false)
	e.swapped.Store(true)
	run("unavailable")
	e.swapped.Store(false)
	p04ClosePrivateHost(t, host)
	open()
	run("records-cold")
	if e.applies != 1 || posts.Load() != 1 || e.samples.Load() != 1 {
		t.Fatal("replayed deployment or usage sample", e.applies, posts.Load(), e.samples.Load())
	}
	t.Log("PUBLIC resource protocol: actual host/HTTP/CLI cold2 POST1 apply1 explicitSample1; runtime failure and swapped instance503; historical status preserved; inspect GET-only")
}
