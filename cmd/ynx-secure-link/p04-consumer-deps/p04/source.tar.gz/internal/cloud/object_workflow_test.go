package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestP04ObjectWorkflowIndependentClientAndRestart(t *testing.T) {
	// Normal authenticated HTTP routes, physical snapshots/blobs and an independent
	// Node platform-crypto client. PUBLIC Wallet verifier fixture, never live auth.
	s := testService(t, nil)
	envelope := testWalletEnvelope(t, s, "cloud", "P04-WORKFLOW", []string{"files.read", "files.write", "permissions.manage"})
	token, _, err := s.CreateSession(context.Background(), envelope)
	if err != nil {
		t.Fatal(err)
	}
	var mu sync.RWMutex
	var handler http.Handler = NewServerWithLimits(s, ServerLimits{MaxConcurrent: 16, RequestsPerMinute: 1000}).Handler()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		handler.ServeHTTP(w, r)
	}))
	defer server.Close()
	script, err := filepath.Abs("../../apps/cloud/client/object-workflow.fixture.mjs")
	if err != nil {
		t.Fatal(err)
	}
	nodePath, err := exec.LookPath("node")
	if err != nil {
		t.Fatal("independent Cloud client workflow requires Node on PATH")
	}
	run := func(stage string, original json.RawMessage) json.RawMessage {
		t.Helper()
		input, err := json.Marshal(map[string]any{"base": server.URL + "/api/v1", "token": token, "stage": stage, "original": original})
		if err != nil {
			t.Fatal(err)
		}
		command := exec.CommandContext(context.Background(), nodePath, script)
		command.Stdin = bytes.NewReader(input)
		var stderr bytes.Buffer
		command.Stderr = &stderr
		out, err := command.Output()
		if err != nil {
			t.Fatalf("independent client %s: %v\n%s", stage, err, stderr.String())
		}
		if !json.Valid(out) {
			t.Fatal("invalid independent client result")
		}
		return json.RawMessage(out)
	}
	reopen := func() {
		t.Helper()
		next, err := New(s.cfg)
		if err != nil {
			t.Fatal(err)
		}
		mu.Lock()
		s = next
		handler = NewServerWithLimits(next, ServerLimits{MaxConcurrent: 16, RequestsPerMinute: 1000}).Handler()
		mu.Unlock()
	}
	original := run("create", nil)
	if len(s.state.Objects) != 1 || len(s.state.ObjectOperations) != 1 {
		t.Fatal("duplicate created a second object/operation")
	}
	reopen()
	run("restart", original)
	reopen()
	run("revokedRestart", original)
	fault := errors.New("PUBLIC post-rename fault in full independent upload flow")
	s.cfg.stateDirectorySync = func(string) error { return fault }
	run("unknown", nil)
	if len(s.state.Objects) != 2 || len(s.state.ObjectOperations) != 2 {
		t.Fatal("UNKNOWN lost original or repeated create")
	}
	reopen()
	if _, err = s.ReconcileObjectCommit(context.Background()); !errors.Is(err, fault) {
		t.Fatal("reopened original unexpectedly released")
	}
	s.cfg.stateDirectorySync = syncObjectDirectory
	if observation, err := s.ReconcileObjectCommit(context.Background()); err != nil || observation.Outcome != "COMMITTED" {
		t.Fatalf("original reconcile: %+v %v", observation, err)
	}
	run("reconciled", nil)
	run("cli", nil)
}

func TestP04ObjectWorkflowShareFailureRecovery(t *testing.T) {
	s := p04Service(t)
	object := p04File(t, s, p04Owner)
	link, secret, err := s.CreateLink(p04Owner, object.ID, "viewer", time.Now().Add(time.Minute))
	if err != nil {
		t.Fatal(err)
	}
	// A real filesystem rename failure before the metadata commit. Preserve the
	// original snapshot, temporarily occupy its filename with a directory, then
	// restore that exact original. No user state is involved.
	originalPath := s.cfg.StatePath + ".PUBLIC-before"
	if err = os.Rename(s.cfg.StatePath, originalPath); err != nil {
		t.Fatal(err)
	}
	if err = os.Mkdir(s.cfg.StatePath, 0700); err != nil {
		t.Fatal(err)
	}
	if _, err = s.RevokeLink(p04Owner, object.ID, link.ID); err == nil || errors.Is(err, errObjectCommitUnknown) {
		t.Fatalf("expected known precommit rejection: %v", err)
	}
	if _, err = s.ResolveLink(secret); err != nil {
		t.Fatal("failed revoke changed current access")
	}
	if _, _, err = s.CreateLink(p04Owner, object.ID, "viewer", time.Now().Add(time.Minute)); err == nil || errors.Is(err, errObjectCommitUnknown) {
		t.Fatalf("expected known failed create: %v", err)
	}
	if len(s.state.Links) != 1 || len(s.state.LinkTokenHashes) != 1 {
		t.Fatal("failed share creation left a phantom link/digest")
	}
	if err = os.Remove(s.cfg.StatePath); err != nil {
		t.Fatal(err)
	}
	if err = os.Rename(originalPath, s.cfg.StatePath); err != nil {
		t.Fatal(err)
	}
	fault := errors.New("PUBLIC revoke post-rename directory sync failure")
	s.cfg.stateDirectorySync = func(string) error { return fault }
	if _, err = s.RevokeLink(p04Owner, object.ID, link.ID); !errors.Is(err, errObjectCommitUnknown) {
		t.Fatal("unknown revoke mislabeled")
	}
	if _, err = s.ResolveLink(secret); !errors.Is(err, ErrDenied) {
		t.Fatal("observed revoked original released content")
	}
	reopened, err := New(s.cfg)
	if err != nil {
		t.Fatal(err)
	}
	s = reopened
	if _, _, err = s.CreateLink(p04Owner, object.ID, "viewer", time.Now().Add(time.Minute)); !errors.Is(err, errObjectCommitUnknown) {
		t.Fatal("restart bypassed pending original revoke")
	}
	s.cfg.stateDirectorySync = syncObjectDirectory
	if observation, err := s.ReconcileObjectCommit(context.Background()); err != nil || observation.Outcome != "COMMITTED" {
		t.Fatalf("original revoke reconcile: %+v %v", observation, err)
	}
	if _, err = s.ResolveLink(secret); !errors.Is(err, ErrDenied) {
		t.Fatal("reconcile reset revoke")
	}
}

func TestP04ObjectWorkflowDeletionAndScopedRecovery(t *testing.T) {
	s := p04Service(t)
	ctx := context.Background()
	req := CreateObjectRequest{Kind: KindFile, Name: "scoped.txt", Content: []byte("PUBLIC scope-bound bytes")}
	id := "P04-scoped-public-upload-0003"
	first, err := s.CreateObjectOnce(ctx, p04Owner, id, req)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = s.GetObjectOperation(p04Other, "cloud", id); !errors.Is(err, ErrNotFound) {
		t.Fatal("other account observed request")
	}
	if _, err = s.GetObjectOperation(p04Owner, "docs", id); !errors.Is(err, ErrNotFound) {
		t.Fatal("other product observed request")
	}
	if _, err = s.SetShareAccess(ctx, p04Owner, first.ID, p04Other, true, 1); err != nil {
		t.Fatal(err)
	}
	if _, body, err := s.GetObjectVersion(ctx, p04Other, first.ID, 1); err != nil || string(body) != string(req.Content) {
		t.Fatal("grant did not authorize original read")
	}
	if _, err = s.SetShareAccess(ctx, p04Owner, first.ID, p04Other, false, 2); err != nil {
		t.Fatal(err)
	}
	reopened, err := New(s.cfg)
	if err != nil {
		t.Fatal(err)
	}
	s = reopened
	if _, _, err = s.GetObjectVersion(ctx, p04Other, first.ID, 1); !errors.Is(err, ErrDenied) {
		t.Fatal("revocation lost at restart")
	}
	if _, err = s.SetTrash(p04Owner, first.ID, true); err != nil {
		t.Fatal(err)
	}
	if err = s.DeleteObject(p04Owner, first.ID); err != nil {
		t.Fatal(err)
	}
	if _, err = s.CreateObjectOnce(ctx, p04Owner, id, req); !errors.Is(err, errObjectOperationRetired) {
		t.Fatal("old deleted upload recreated")
	}
	observation, err := s.GetObjectOperation(p04Owner, "cloud", id)
	if err != nil || !observation.Deleted || observation.Outcome != "COMMITTED" {
		t.Fatal("deleted original lost its tombstone")
	}
	if _, err = s.CreateObjectOnce(ctx, p04Owner, "P04-erasure-upload-0004", req); err != nil {
		t.Fatal(err)
	}
	receipt, err := s.EraseProductData(ctx, p04Owner, "cloud")
	if err != nil {
		t.Fatal(err)
	}
	if receipt.Retained["objectRequestTombstones"] == "" {
		t.Fatal("retained replay tombstones not disclosed")
	}
	if _, err = s.CreateObjectOnce(ctx, p04Owner, "P04-erasure-upload-0004", req); !errors.Is(err, errObjectOperationRetired) {
		t.Fatal("erased original upload recreated")
	}
	// Share digests are private snapshot data and never appear in returned links.
	other := p04File(t, s, p04Other)
	link, secret, err := s.CreateLink(p04Other, other.ID, "viewer", time.Now().Add(time.Minute))
	if err != nil {
		t.Fatal(err)
	}
	raw, _ := json.Marshal(link)
	if strings.Contains(string(raw), secret) || strings.Contains(string(raw), "tokenHash") {
		t.Fatal("share response leaked verification material")
	}
}
