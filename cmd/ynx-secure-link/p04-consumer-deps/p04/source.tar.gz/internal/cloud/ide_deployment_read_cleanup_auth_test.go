//go:build cloud_auth_v2

package cloud

import (
	"context"
	"net/http/httptest"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
)

func TestIDEReadCleanupOriginalAuthNormalNoAttemptCaller(t *testing.T) {
	// An unadmitted zero Source has no child to discharge. Exercise the ACTUAL
	// Auth callee, not a replacement callback; this creates no Source authority.
	source := &developerauthority.OriginalIDEPublicationSourceOwner{}
	adapter := &AuthIDEDeploymentV2Authority{source: source}
	ctx, cancel := context.WithCancel(context.Background())
	r := httptest.NewRequest("GET", "/api/v1/ide/deployments/PUBLIC_original_request_001", nil).WithContext(ctx)
	cancel()
	for i := 0; i < 2; i++ {
		if closed, err := adapter.ReleaseOriginalFiniteGETRequest(ctx, r); !closed || err != nil {
			t.Fatal("same canceled no-attempt cleanup failed", closed, err)
		}
	}
	if closed, err := adapter.ReleaseOriginalFiniteGETRequest(context.Background(), r); closed || err == nil {
		t.Fatal("foreign context accepted", closed, err)
	}
}
