package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
)

func TestP04OriginalNativeIntentNormalRouteRetainsBillAndNeverQueriesPay(t *testing.T) {
	// Real original Cloud journal/router; Source/pricing/Pay are PUBLIC fixtures.
	s, auth, op, prices := p04BillingFixture(t)
	period := "2026-10-28"
	schedule := prices.schedules[period]
	schedule.Merchant = "0x" + strings.Repeat("a", 40)
	schedule.Recipient = "0x" + strings.Repeat("b", 40)
	schedule.Asset.AssetID = "YNXT"
	schedule.Asset.UnitVersion = "1"
	prices.schedules[period] = schedule
	pay := &p04ProvenanceLostPay{}
	if err := s.EnableIDEUsageBilling(prices, pay); err != nil {
		t.Fatal(err)
	}
	bill, err := s.ideDeployments.billUsage(context.Background(), httptest.NewRequest("POST", "/PUBLIC", nil), auth.principal, op, period, true, func() error { return nil })
	if err != nil || bill.State != "UNKNOWN" {
		t.Fatal(bill, err)
	}
	reader, err := s.OpenOriginalIDEUsageBillReader()
	if err != nil {
		t.Fatal(err)
	}
	file := reader.journal.file(auth.principal, op.RequestID) + ".usage"
	before, err := os.ReadFile(file)
	if err != nil {
		t.Fatal(err)
	}
	h, err := reader.Capture(context.Background(), auth.principal, op.RequestID, period)
	if err != nil {
		t.Fatal(err)
	}
	defer h.Close()
	intent, err := h.NativeInvoiceIntentDATA("cloud.ide-usage", bill.Request.BillID)
	if err != nil || intent.StoreID != "" || intent.SourceOrder != bill.Request.BillID || intent.AmountAtoms != bill.Request.Atoms {
		t.Fatal(intent, err)
	}
	want, _ := json.Marshal(bill.Request)
	if !bytes.Equal(intent.DomainData, want) {
		t.Fatal("original Request byte contract changed")
	}
	intent.DomainData[0] = '!'
	again, err := h.NativeInvoiceIntentDATA("cloud.ide-usage", bill.Request.BillID)
	if err != nil || !bytes.Equal(again.DomainData, want) {
		t.Fatal("returned DATA aliased original")
	}
	for _, ref := range [][2]string{{"shop.order", bill.Request.BillID}, {"cloud.ide-usage", "another-original"}} {
		if _, err = h.NativeInvoiceIntentDATA(ref[0], ref[1]); err == nil {
			t.Fatal("changed reference admitted")
		}
	}
	path := "/api/v1/ide/deployments/" + op.RequestID + "/billing/" + period + "/native-intent"
	response := publicIDERead(s.Handler(), path)
	if response.Code != 200 {
		t.Fatal(response.Code, response.Body.String())
	}
	var view struct {
		Request        IDEUsageNativeInvoiceIntentDATA
		Original       IDEUsageBillProvenanceDATA
		OriginalSHA256 string
	}
	if json.Unmarshal(response.Body.Bytes(), &view) != nil || view.Original.Bill != bill || view.OriginalSHA256 == "" || !bytes.Equal(view.Request.DomainData, want) {
		t.Fatal("original version not retained", response.Body.String())
	}
	for _, bad := range []string{path + "?owner=other", strings.Replace(path, period, "2026-10-27", 1)} {
		if r := publicIDERead(s.Handler(), bad); r.Code == 200 {
			t.Fatal("invalid original read accepted", bad)
		}
	}
	after, _ := os.ReadFile(file)
	if !bytes.Equal(before, after) || pay.creates != 1 || pay.lookups != 0 {
		t.Fatal("read mutated original or contacted Pay")
	}
	reader.Retire()
	if _, err = h.NativeInvoiceIntentDATA("cloud.ide-usage", bill.Request.BillID); err == nil {
		t.Fatal("retired holder admitted")
	}
	if response = publicIDERead(s.Handler(), path); response.Code == 200 {
		t.Fatal("retired route admitted")
	}
}

func TestP04OriginalNativeIntentRejectsUnsupportedOriginalAsset(t *testing.T) {
	s, owner, op, bill, _ := p04OriginalBillFixture(t)
	reader, _ := s.OpenOriginalIDEUsageBillReader()
	h, err := reader.Capture(context.Background(), owner, op.RequestID, bill.Request.Period)
	if err != nil {
		t.Fatal(err)
	}
	defer h.Close()
	if _, err = h.NativeInvoiceIntentDATA("cloud.ide-usage", bill.Request.BillID); err == nil {
		t.Fatal("non-native original fields fabricated")
	}
}
