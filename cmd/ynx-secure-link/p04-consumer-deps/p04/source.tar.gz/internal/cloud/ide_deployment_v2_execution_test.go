package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

// Explicit PUBLIC independent Source/engine protocol fixtures. Actual sole SDK,
// Cloud HTTP, inode/digest fences, resource/journal files and cold-open paths
// are exercised. This is not genuine Auth, cryptographic or OCI acceptance.
type p04V2ExecutionSource struct {
	expected                        *IDEDeploymentV2Artifact
	approved                        map[string]IDEDeploymentV2Grant
	body                            []byte
	hasExecutionApproval            bool
	deny, swap                      bool
	denyAtCreate                    int
	creates                         *int
	reads, borrows, closes          int
	bodies                          map[*http.Request][]byte
	bodyMarkers                     map[*http.Request]io.ReadCloser
	activeBodyBorrows, bodyCloses   int
	bodyCloseError, bodyBorrowError error
}
type p04V2ExecutionPermit struct {
	source *p04V2ExecutionSource
	grant  IDEDeploymentV2Grant
	closed bool
}

// PUBLIC custody protocol fixture. Principal already consumed Body; only the
// SAME original request and marker may borrow the retained bytes. Not Source
// admission, Root transport or cryptographic HTTP authentication.
type p04V2OriginalBodyBorrow struct {
	io.Reader
	source *p04V2ExecutionSource
	closed bool
}

func (b *p04V2OriginalBodyBorrow) Close() error {
	if !b.closed {
		b.closed = true
		b.source.activeBodyBorrows--
		b.source.bodyCloses++
	}
	return b.source.bodyCloseError
}
func (a *p04V2ExecutionSource) BorrowOriginalBodyV5(_ context.Context, r *http.Request) (io.ReadCloser, error) {
	body, ok := a.bodies[r]
	if !ok || r.Body != a.bodyMarkers[r] {
		return nil, ErrDenied
	}
	a.activeBodyBorrows++
	return &p04V2OriginalBodyBorrow{Reader: bytes.NewReader(body), source: a}, a.bodyBorrowError
}

func (p *p04V2ExecutionPermit) Selection() IDEDeploymentV2Grant { return p.grant }
func (p *p04V2ExecutionPermit) Recheck(context.Context) error {
	if p.closed || p.source.deny || p.source.denyAtCreate > 0 && *p.source.creates >= p.source.denyAtCreate {
		return ErrDenied
	}
	return nil
}
func (p *p04V2ExecutionPermit) BorrowArtifactOriginal(ctx context.Context) (io.Reader, error) {
	if err := p.Recheck(ctx); err != nil {
		return nil, err
	}
	p.source.borrows++
	return bytes.NewReader(bytes.Clone(p.source.body)), nil
}
func (p *p04V2ExecutionPermit) Close() error {
	if !p.closed {
		p.source.closes++
		p.closed = true
	}
	return nil
}
func (a *p04V2ExecutionSource) AuthorizeV2(ctx context.Context, r *http.Request, principal string, in IDEDeploymentV2Request) (IDEDeploymentV2Permit, error) {
	grant, ok := a.approved[in.RequestID]
	if !ok || a.activeBodyBorrows != 0 || a.deny || !a.hasExecutionApproval || principal != grant.Principal || in.ExpectedSlotRevision != grant.ExpectedSlotRevision || in.RollbackTarget != grant.RollbackTarget || !bytes.Equal(in.MemberOriginal, []byte("PUBLIC_E11_MEMBER_FIXTURE")) || !bytes.Equal(in.Artifact.ManifestBytes(), a.expected.ManifestBytes()) || in.Artifact.ContentBinding() != a.expected.ContentBinding() {
		return nil, ErrDenied
	}
	if a.swap {
		grant.Manifest.IssuerEpoch = "999"
	}
	return &p04V2ExecutionPermit{source: a, grant: grant}, nil
}
func (a *p04V2ExecutionSource) AuthorizeV2Read(ctx context.Context, r *http.Request, op IDEDeploymentOperation) error {
	a.reads++
	if a.deny || op.ManifestVersion != "2" || op.ManifestV2 == nil || op.ManifestBinding == nil || *op.ManifestBinding != a.expected.Binding() {
		return ErrDenied
	}
	return nil
}

func TestP04DeploymentV2SourceBoundOriginalLifecycle(t *testing.T) {
	codec, _, payload, body := p04V2SDKFixture(t)
	held, err := ReadIDEDeploymentArtifactV2(context.Background(), codec, bytes.NewReader(payload), bytes.NewReader(body), nil, MaxMultipartBytes)
	if err != nil {
		t.Fatal(err)
	}
	m := publicIDEOCIFixture(t)
	m.e.cfg.TargetEnvironment = held.Manifest().Environment
	rows := map[string]ideOCIInspection{}
	loseStart := true
	m.e.run = func(_ context.Context, args ...string) ([]byte, error) {
		switch args[0] {
		case "image":
			return json.Marshal([]map[string]string{{"Id": m.e.cfg.ImageDigest}})
		case "create":
			m.creates++
			row := m.row
			row.ID = fmt.Sprintf("%064x", m.creates)
			row.Config.Labels = map[string]string{}
			row.Mounts = append(row.Mounts[:0:0], m.row.Mounts...)
			for i, arg := range args {
				if arg == "--label" {
					kv := strings.SplitN(args[i+1], "=", 2)
					row.Config.Labels[kv[0]] = kv[1]
				}
				if arg == "--mount" {
					for _, v := range strings.Split(args[i+1], ",") {
						if strings.HasPrefix(v, "src=") {
							row.Mounts[0].Source = strings.TrimPrefix(v, "src=")
						}
					}
				}
			}
			row.Config.Cmd = append([]string(nil), args[len(args)-5:]...)
			row.State.Running = false
			row.State.Status = "created"
			rows[row.ID] = row
			return []byte(row.ID), nil
		case "inspect":
			row, ok := rows[args[len(args)-1]]
			if !ok {
				return nil, ErrNotFound
			}
			return json.Marshal([]ideOCIInspection{row})
		case "start":
			m.starts++
			row := rows[args[1]]
			row.State.Running = true
			row.State.Status = "running"
			rows[args[1]] = row
			if loseStart {
				return nil, context.DeadlineExceeded
			}
			return []byte(args[1]), nil
		case "logs":
			return []byte("PUBLIC V2 protocol log; not executed application output"), nil
		}
		return nil, ErrInvalid
	}
	source := &p04V2ExecutionSource{expected: held, body: body, approved: map[string]IDEDeploymentV2Grant{}, creates: &m.creates}
	approve := func(id, revision, rollback string) {
		source.approved[id] = IDEDeploymentV2Grant{CatalogProjectID: "PUBLIC_CATALOG_PROJECT_PROJECTION", RequestID: id, Principal: m.p.Principal, PublisherID: "PUBLIC_REGISTERED_V2_PUBLISHER", ResourceID: m.p.ResourceID, ResourceApprovalRef: "PUBLIC_SEPARATE_V2_RESOURCE_APPROVAL", ExpectedSlotRevision: revision, RollbackTarget: rollback, Manifest: held.Manifest(), ManifestBinding: held.Binding(), ContentBinding: held.ContentBinding(), RuntimeSeconds: 30, ExpiresAt: time.Now().Add(time.Hour)}
	}
	service := testService(t, nil)
	legacy := &p04V2Authority{publicIDEAuthority: publicIDEAuthority{principal: m.p.Principal}}
	source.bodies = make(map[*http.Request][]byte)
	source.bodyMarkers = make(map[*http.Request]io.ReadCloser)
	legacy.captureOriginal = func(r *http.Request) error {
		if r.Method != "POST" {
			return nil
		}
		body, err := io.ReadAll(r.Body)
		if err != nil {
			return err
		}
		source.bodies[r] = body
		source.bodyMarkers[r] = r.Body
		return nil // original Body remains consumed and unchanged
	}
	var server *Server
	var handler http.Handler
	var httpFlight sync.Mutex
	dropNextResponse := false
	restart := func() {
		t.Helper()
		cold, err := New(service.cfg)
		if err != nil {
			t.Fatal(err)
		}
		server = NewServer(cold)
		if err = server.EnableIDEDeployments(legacy, m.e); err != nil {
			t.Fatal(err)
		}
		if err = server.EnableIDEDeploymentV2DATA(codec); err != nil {
			t.Fatal(err)
		}
		if err = server.EnableIDEDeploymentV2Authority(source); err != nil {
			t.Fatal(err)
		}
		handler = server.Handler()
	}
	restart()

	request := func(id, rev, rollback string, approval []byte) (int, IDEDeploymentOperation) {
		t.Helper()
		var encoded bytes.Buffer
		writer := multipart.NewWriter(&encoded)
		for _, part := range []struct {
			name string
			body []byte
		}{{"manifest", payload}, {"approval", approval}, {"artifact", body}} {
			p, err := writer.CreateFormField(part.name)
			if err != nil {
				t.Fatal(err)
			}
			p.Write(part.body)
		}
		writer.Close()
		r := httptest.NewRequest("POST", "/api/v1/ide/deployments", &encoded)
		r.Header.Set("Content-Type", writer.FormDataContentType())
		r.Header.Set("X-Deployment-Manifest-Version", "2")
		r.Header.Set("Idempotency-Key", id)
		r.Header.Set("X-Expected-Deployment-Revision", rev)
		if rollback != "" {
			r.Header.Set("X-Rollback-To", rollback)
		}
		if dropNextResponse {
			dropNextResponse = false
			// Real HTTP response loss after the original handler has durably
			// claimed/attempted its operation. PUBLIC authority/engine only.
			endpoint := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, in *http.Request) {
				httpFlight.Lock()
				defer httpFlight.Unlock()
				out := httptest.NewRecorder()
				handler.ServeHTTP(out, in)
				connection, _, err := w.(http.Hijacker).Hijack()
				if err == nil {
					connection.Close()
				}
			}))
			defer endpoint.Close()
			r.URL.Scheme = "http"
			r.URL.Host = strings.TrimPrefix(endpoint.URL, "http://")
			r.RequestURI = ""
			result, err := endpoint.Client().Do(r)
			if result != nil {
				result.Body.Close()
			}
			httpFlight.Lock()
			httpFlight.Unlock()
			if err == nil {
				t.Fatal("actual lost HTTP response was fabricated as success")
			}
			return 0, IDEDeploymentOperation{}
		}
		out := httptest.NewRecorder()
		handler.ServeHTTP(out, r)
		var op IDEDeploymentOperation
		json.Unmarshal(out.Body.Bytes(), &op)
		return out.Code, op
	}
	query := func(id, suffix string) (int, []byte) {
		out := httptest.NewRecorder()
		handler.ServeHTTP(out, httptest.NewRequest("GET", "/api/v1/ide/deployments/"+id+suffix, nil))
		return out.Code, out.Body.Bytes()
	}
	id := "P04_V2_original_execute_0001"
	approve(id, "0", "")
	good := []byte("PUBLIC_E11_MEMBER_FIXTURE")
	source.bodyBorrowError = errors.New("PUBLIC original borrow returned owned partial")
	if code, _ := request(id, "0", "", good); code != 503 || source.activeBodyBorrows != 0 || source.bodyCloses != 1 || m.creates != 0 {
		t.Fatal("nonnull body partial was lost before error")
	}
	source.bodyBorrowError = nil
	source.bodyCloseError = errors.New("PUBLIC original body close UNKNOWN")
	if code, _ := request(id, "0", "", good); code != 503 || source.activeBodyBorrows != 0 || source.bodyCloses != 2 || m.creates != 0 {
		t.Fatal("body close UNKNOWN reached execution approval")
	}
	source.bodyCloseError = nil
	if code, _ := request(id, "0", "", good); code != 403 || m.creates != 0 {
		t.Fatal("E11 member became execution approval")
	}
	source.hasExecutionApproval = true
	source.swap = true
	if code, _ := request(id, "0", "", good); code != 403 || m.creates != 0 {
		t.Fatal("Source fullRef/epoch selection mismatch was not checked")
	}
	source.swap = false
	dropNextResponse = true
	code, _ := request(id, "0", "", good)
	op, originalErr := server.ideDeployments.journal.lookup(m.p.Principal, id)
	if code != 0 || originalErr != nil || op.State != "unknown" || op.ManifestVersion != "2" || op.Binding != (IDEArtifactBinding{}) || op.ManifestBinding == nil || *op.ManifestBinding != held.Binding() || m.creates != 1 || m.starts != 1 {
		t.Fatalf("original V2 lost start response: %d %#v creates=%d starts=%d", code, op, m.creates, m.starts)
	}
	restart()
	code, raw := query(id, "")
	json.Unmarshal(raw, &op)
	if code != 200 || op.State != "running" || op.SlotRevision != "1" || m.creates != 1 || m.starts != 1 {
		t.Fatalf("cold V2 original was replayed/lost: %d %s", code, raw)
	}
	if code, prior := request(id, "0", "", good); code != 201 || prior.DeploymentID != op.DeploymentID || m.creates != 1 || m.starts != 1 {
		t.Fatal("repeat original submission dispatched")
	}
	if code, raw := query(id, "/logs"); code != 200 || !bytes.Contains(raw, []byte("PUBLIC V2 protocol log")) {
		t.Fatalf("original V2 logs unavailable: %d %s", code, raw)
	}
	source.deny = true
	if code, _ := query(id, "/logs"); code != 403 {
		t.Fatal("V2 logs bypassed current Source")
	}
	source.deny = false
	row := rows[op.DeploymentID]
	row.State.Running = false
	row.State.Status = "exited"
	row.State.ExitCode = 0
	rows[op.DeploymentID] = row
	code, raw = query(id, "")
	json.Unmarshal(raw, &op)
	if code != 200 || op.State != "completed" || op.ExitCode == nil || *op.ExitCode != 0 {
		t.Fatalf("V2 completed observation: %s", raw)
	}
	loseStart = false
	next := "P04_V2_fresh_rollback_0002"
	approve(next, "1", id)
	code, rollback := request(next, "1", id, good)
	if code != 201 || rollback.SlotRevision != "2" || rollback.RollbackTarget != id || m.creates != 2 || m.starts != 2 {
		t.Fatalf("fresh V2 rollback: %d %#v", code, rollback)
	}
	// A live original slot remains occupied even with a fresh authenticated ID.
	busy := "P04_V2_busy_resource_0003"
	approve(busy, "2", "")
	if code, busyOp := request(busy, "2", "", good); code != 409 || busyOp.State != "failed" || m.creates != 2 || m.starts != 2 {
		t.Fatal("V2 multiplied running resource")
	}
	row = rows[rollback.DeploymentID]
	row.State.Running = false
	row.State.Status = "exited"
	row.State.ExitCode = 0
	rows[rollback.DeploymentID] = row
	query(next, "")
	stale := "P04_V2_stale_CAS_0004"
	approve(stale, "0", "")
	if code, staleOp := request(stale, "0", "", good); code != 409 || staleOp.State != "failed" || m.creates != 2 {
		t.Fatal("V2 stale resource CAS dispatched")
	}
	revoked := "P04_V2_revoked_before_start_0005"
	approve(revoked, "2", "")
	source.denyAtCreate = 3
	code, unknown := request(revoked, "2", "", good)
	if code != 202 || unknown.State != "unknown" || m.creates != 3 || m.starts != 2 {
		t.Fatalf("V2 final fence dispatched revoked start: %d %#v", code, unknown)
	}
	restart()
	query(revoked, "")
	if m.creates != 3 || m.starts != 2 {
		t.Fatal("cold UNKNOWN retried V2 start")
	}
	if legacy.legacyAuthorize != 0 || source.borrows != 5 || source.closes != 7 || source.reads == 0 {
		t.Fatalf("wrong V2 path legacy=%d borrows=%d closes=%d reads=%d", legacy.legacyAuthorize, source.borrows, source.closes, source.reads)
	}
	dir := filepath.Join(m.e.cfg.StorageRoot, m.e.name(id, productHash(good)))
	actual, err := os.ReadFile(filepath.Join(dir, "artifact.mjs"))
	if err != nil || !bytes.Equal(actual, body) {
		t.Fatal("V2 held/staged actual bytes changed")
	}
}
