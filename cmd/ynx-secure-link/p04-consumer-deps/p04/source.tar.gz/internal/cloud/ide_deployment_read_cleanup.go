package cloud

import (
	"context"
	"net/http"
	"sync"
)

// Cleanup only. The concrete original Auth adapter supplies this port; it
// cannot authenticate, consume a nonce, reopen a Source or stop a deployment.
type originalIDEReadRequestReleaser interface {
	ReleaseOriginalFiniteGETRequest(context.Context, *http.Request) (bool, error)
}

type originalIDEReadRequestDebt struct {
	mu      sync.Mutex
	owner   originalIDEReadRequestReleaser
	request *http.Request
	ctx     context.Context
	closed  bool
	first   error
}

func (d *originalIDEReadRequestDebt) release() (bool, error) {
	d.mu.Lock()
	defer d.mu.Unlock()
	if !d.closed {
		closed, err := d.owner.ReleaseOriginalFiniteGETRequest(d.ctx, d.request)
		if d.first == nil {
			d.first = err
		}
		d.closed = closed
	}
	return d.closed, d.first
}

type originalIDEReadRequestDebts struct {
	mu      sync.Mutex
	pending map[*http.Request]*originalIDEReadRequestDebt
	first   error
}

func (s *originalIDEReadRequestDebts) capture(r *http.Request, authority any) {
	owner, ok := authority.(originalIDEReadRequestReleaser)
	if !ok || r == nil || r.Method != http.MethodGet {
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.pending == nil {
		s.pending = make(map[*http.Request]*originalIDEReadRequestDebt)
	}
	if s.pending[r] == nil {
		s.pending[r] = &originalIDEReadRequestDebt{owner: owner, request: r, ctx: r.Context()}
	}
}

func (s *originalIDEReadRequestDebts) release(r *http.Request) {
	s.mu.Lock()
	d := s.pending[r]
	s.mu.Unlock()
	if d == nil {
		return
	}
	closed, err := d.release() // no Auth call while inventory mutex is held
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.first == nil {
		s.first = err
	}
	if closed && s.pending[r] == d {
		delete(s.pending, r)
	}
}

func (s *originalIDEReadRequestDebts) drain() (bool, error) {
	s.mu.Lock()
	requests := make([]*http.Request, 0, len(s.pending))
	for r := range s.pending {
		requests = append(requests, r)
	}
	s.mu.Unlock()
	for _, r := range requests {
		s.release(r)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.pending) == 0, s.first
}
