package cloud

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestIDEDeploymentReadWireDefaultAndNoQueryRewrite(t *testing.T) {
	s := &Server{}
	mux := http.NewServeMux()
	s.mountIDEDeployments(mux)
	base := "/api/v1/ide/deployments/req_PUBLIC_READ_ORIGINAL_00001"
	for _, suffix := range []string{"", "/logs", "/runtime", "/usage", "/usage/records", "/billing/2026-11-01", "/billing/2026-11-01/native-intent"} {
		t.Run(suffix, func(t *testing.T) {
			for _, query := range []string{"", "?", "?limit=10", "?operation=other&operation=original"} {
				r := httptest.NewRequest(http.MethodGet, base+suffix+query, nil)
				before, uri := *r.URL, r.RequestURI
				w := httptest.NewRecorder()
				mux.ServeHTTP(w, r)
				want := 400
				if query == "" {
					want = 503 // Actual normal dependency absence, never success.
				}
				if w.Code != want || *r.URL != before || r.RequestURI != uri {
					t.Fatalf("query=%q code=%d want=%d URL/URI preserved=%v/%v", query, w.Code, want, *r.URL == before, r.RequestURI == uri)
				}
				if query != "" && !strings.Contains(w.Body.String(), "IDE_DEPLOYMENT_READ_TARGET_INVALID") {
					t.Fatal("query was not rejected at product boundary", w.Body.String())
				}
			}
		})
	}
}

func TestIDEDeploymentReadWireRejectsBodyAndAmbiguousTarget(t *testing.T) {
	base := "/api/v1/ide/deployments/req_PUBLIC_READ_ORIGINAL_00001"
	for _, mode := range []string{"body", "unknown-length", "transfer", "trailer", "encoded-path", "wrong-operation", "invalid-day", "head", "stripped-query", "rewritten-path", "empty-target"} {
		t.Run(mode, func(t *testing.T) {
			r := httptest.NewRequest(http.MethodGet, base, nil)
			r.Pattern = "GET /api/v1/ide/deployments/{request}"
			r.SetPathValue("request", "req_PUBLIC_READ_ORIGINAL_00001")
			switch mode {
			case "body":
				r = httptest.NewRequest(http.MethodGet, base, strings.NewReader("PUBLIC_NOT_SIGNED_BODY"))
				r.Pattern = "GET /api/v1/ide/deployments/{request}"
				r.SetPathValue("request", "req_PUBLIC_READ_ORIGINAL_00001")
			case "unknown-length":
				r.ContentLength = -1
			case "transfer":
				r.TransferEncoding = []string{"chunked"}
			case "trailer":
				r.Trailer = http.Header{"X-Public": []string{"not-authority"}}
			case "encoded-path":
				r.URL.RawPath = "/api/v1/ide/deployments/%72eq_PUBLIC_READ_ORIGINAL_00001"
			case "wrong-operation":
				r.SetPathValue("request", "req_OTHER_READ_ORIGINAL_00001")
			case "invalid-day":
				r.Pattern = "GET /api/v1/ide/deployments/{request}/billing/{period}"
				r.SetPathValue("period", "2026-02-30")
				r.URL.Path += "/billing/2026-02-30"
			case "head":
				r.Method = http.MethodHead
			case "stripped-query":
				r.RequestURI += "?original=PUBLIC"
			case "rewritten-path":
				r.RequestURI = "/api/v1/ide/deployments/req_OTHER_READ_ORIGINAL_00001"
			case "empty-target":
				r.RequestURI = ""
			}
			if originalIDEDeploymentReadTarget(r) {
				t.Fatal("ambiguous/body request admitted")
			}
		})
	}
}
