package cloud

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"testing"
	"time"
)

func TestP04ObjectFenceLegacyMutation(t *testing.T) {
	cases := map[string]func(*Service, Object) error{
		"star":  func(s *Service, o Object) error { _, e := s.SetStar(p04Owner, o.ID, true); return e },
		"trash": func(s *Service, o Object) error { _, e := s.SetTrash(p04Owner, o.ID, true); return e },
		"grant": func(s *Service, o Object) error { _, e := s.Grant(p04Owner, o.ID, p04Other, "viewer", nil); return e },
		"link": func(s *Service, o Object) error {
			_, _, e := s.CreateLink(p04Owner, o.ID, "viewer", time.Now().Add(time.Hour))
			return e
		},
		"create": func(s *Service, o Object) error {
			_, e := s.Create(context.Background(), p04Owner, CreateObjectRequest{Kind: KindFile, Name: "blocked", Content: []byte("new")})
			return e
		},
		"put": func(s *Service, o Object) error {
			_, e := s.PutObjectVersion(context.Background(), p04Owner, o.ID, 1, strings.NewReader("new"), nil)
			return e
		},
		"restore": func(s *Service, o Object) error {
			_, e := s.RestoreObjectVersion(context.Background(), p04Owner, o.ID, 1, 1)
			return e
		},
		"share": func(s *Service, o Object) error {
			_, e := s.SetShareAccess(context.Background(), p04Owner, o.ID, p04Other, true, 1)
			return e
		},
		"comment":  func(s *Service, o Object) error { _, e := s.AddComment(p04Owner, o.ID, 1, "blocked", nil); return e },
		"presence": func(s *Service, o Object) error { _, e := s.Presence(p04Owner, o.ID, "blocked"); return e },
		"egress":   func(s *Service, o Object) error { return s.RecordEgress(p04Owner, "cloud", o.ID, 1, "session") },
		"persist": func(s *Service, o Object) error {
			s.mu.Lock()
			defer s.mu.Unlock()
			return s.persist("blocked", p04Owner, o.ID, nil)
		},
	}
	for name, call := range cases {
		t.Run(name, func(t *testing.T) {
			s := p04Service(t)
			o := p04File(t, s, p04Owner)
			s.objectWriteErr = errObjectCommitUnknown
			before, _ := json.Marshal(s.state)
			if err := call(s, o); !errors.Is(err, errObjectCommitUnknown) {
				t.Fatalf("UNKNOWN fence bypass: %v", err)
			}
			after, _ := json.Marshal(s.state)
			if string(before) != string(after) {
				t.Fatal("fenced call changed original snapshot")
			}
			if _, body, err := s.Content(p04Owner, o.ID, 0); err != nil || string(body) != "V1" {
				t.Fatalf("read-only blocked: %q %v", body, err)
			}
		})
	}
}
