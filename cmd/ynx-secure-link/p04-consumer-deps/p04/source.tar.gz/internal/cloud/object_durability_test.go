package cloud

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestP04ObjectDurabilityPostRenameFenceAndReconcile(t *testing.T) {
	s := p04Service(t)
	o := p04File(t, s, p04Owner)
	failure := errors.New("PUBLIC injected post-rename directory sync failure")
	calls := 0
	fail := true
	s.cfg.stateDirectorySync = func(path string) error {
		calls++
		if fail {
			return failure
		}
		return syncObjectDirectory(path)
	}
	_, err := s.PutObjectVersion(context.Background(), p04Owner, o.ID, 1, strings.NewReader("V2"), nil)
	if !errors.Is(err, errObjectCommitUnknown) || !errors.Is(err, failure) {
		t.Fatalf("original first cause lost: %v", err)
	}
	if s.objectPending == nil || s.objectPending.objectID != o.ID || s.objectPending.action != "object.version.put" {
		t.Fatal("original operation not retained")
	}
	original, _ := json.Marshal(s.state)
	disk, err := os.ReadFile(s.cfg.StatePath)
	if err != nil {
		t.Fatal(err)
	}
	var stored persistentState
	if err = json.Unmarshal(disk, &stored); err != nil || stored.Objects[o.ID].Version != 2 {
		t.Fatal("fault was not after real rename")
	}
	if _, err = s.SetStar(p04Owner, o.ID, true); !errors.Is(err, errObjectCommitUnknown) {
		t.Fatal("old writer bypassed UNKNOWN")
	}
	if _, err = s.SetTrash(p04Owner, o.ID, true); !errors.Is(err, errObjectCommitUnknown) {
		t.Fatal("trash bypassed UNKNOWN")
	}
	if _, err = s.PutObjectVersion(context.Background(), p04Owner, o.ID, 2, strings.NewReader("V3"), nil); !errors.Is(err, errObjectCommitUnknown) {
		t.Fatal("new writer bypassed UNKNOWN")
	}
	after, _ := json.Marshal(s.state)
	currentDisk, _ := os.ReadFile(s.cfg.StatePath)
	if string(original) != string(after) || string(currentDisk) != string(disk) || calls != 1 {
		t.Fatal("fenced writer changed original memory/disk or synced a new commit")
	}
	if _, body, err := s.Content(p04Owner, o.ID, 0); err != nil || string(body) != "V2" {
		t.Fatal("legitimate read unavailable")
	}
	reopened, openErr := New(s.cfg)
	if openErr != nil {
		t.Fatal(openErr)
	}
	if _, openErr = reopened.SetStar(p04Owner, o.ID, true); !errors.Is(openErr, errObjectCommitUnknown) {
		t.Fatal("restart bypassed the original UNKNOWN intent")
	}
	if _, _, err = s.ExportOwnedData(context.Background(), p04Owner, "cloud"); err != nil {
		t.Fatal("read-only export blocked by write fence")
	}
	if _, err = s.ReconcileObjectCommit(context.Background()); !errors.Is(err, errObjectCommitUnknown) || s.objectPending == nil {
		t.Fatal("failing original readback cleared fence")
	}
	fail = false
	observed, err := s.ReconcileObjectCommit(context.Background())
	if err != nil || observed.ObjectID != o.ID || observed.Integrity != stored.IntegrityHash {
		t.Fatalf("original reconciliation: %#v %v", observed, err)
	}
	if s.objectWriteErr != nil || s.objectPending != nil {
		t.Fatal("confirmed original did not release fence")
	}
	if _, err = s.PutObjectVersion(context.Background(), p04Owner, o.ID, 2, strings.NewReader("V3"), nil); err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	writeServiceError(rr, errors.Join(errObjectCommitUnknown, failure))
	if rr.Code != http.StatusServiceUnavailable || !strings.Contains(rr.Body.String(), `"outcome":"UNKNOWN"`) {
		t.Fatal("HTTP reported definite failure instead of UNKNOWN")
	}
}

func TestP04ObjectDurabilityLegacyRollbackRetainsOriginal(t *testing.T) {
	s := p04Service(t)
	s.cfg.stateDirectorySync = func(string) error { return errors.New("PUBLIC sync failure") }
	_, err := s.InitiateMultipart(p04Owner, CreateObjectRequest{Kind: KindFile, Name: "original.txt"}, 2, hashBytes([]byte("V1")))
	if !errors.Is(err, errObjectCommitUnknown) || len(s.state.MultipartUploads) != 1 || s.objectPending == nil || s.objectPending.action != "multipart.initiate" {
		t.Fatal("legacy error cleanup erased original post-rename operation")
	}
}

func TestP04ObjectDurabilityChangedOriginalCannotUnfreeze(t *testing.T) {
	s := p04Service(t)
	o := p04File(t, s, p04Owner)
	s.cfg.stateDirectorySync = func(string) error { return errors.New("PUBLIC sync failure") }
	if _, err := s.SetStar(p04Owner, o.ID, true); !errors.Is(err, errObjectCommitUnknown) {
		t.Fatal(err)
	}
	changed := s.state
	changed.Objects = map[string]Object{o.ID: s.state.Objects[o.ID]}
	copy := changed.Objects[o.ID]
	copy.Starred = false
	changed.Objects[o.ID] = copy
	if err := saveState(s.cfg.StatePath, &changed); err != nil {
		t.Fatal(err)
	}
	s.cfg.stateDirectorySync = syncObjectDirectory
	if _, err := s.ReconcileObjectCommit(context.Background()); !errors.Is(err, errObjectCommitUnknown) || s.objectPending == nil {
		t.Fatal("another result reset original fence")
	}
	if _, err := s.SetTrash(p04Owner, o.ID, true); !errors.Is(err, errObjectCommitUnknown) {
		t.Fatal("changed result admitted writer")
	}
}

func TestP04BlobDurabilityRetryCannotPublishUnsyncedAddress(t *testing.T) {
	s := p04Service(t)
	o := p04File(t, s, p04Owner)
	body := []byte("post-link-original")
	leaf := filepath.Join(s.cfg.ObjectDir, "scoped", objectStorageScope(p04Owner, "cloud"), hashBytes(body)[:2])
	failure := errors.New("PUBLIC post-link sync failure")
	fail := true
	leafSyncs := 0
	store := LocalObjectStore{Root: s.cfg.ObjectDir, directorySync: func(path string) error {
		if path == leaf {
			leafSyncs++
			if fail {
				return failure
			}
		}
		return syncObjectDirectory(path)
	}}
	s.cfg.ObjectStore = store
	for attempt := 0; attempt < 2; attempt++ {
		if _, err := s.PutObjectVersion(context.Background(), p04Owner, o.ID, 1, strings.NewReader(string(body)), nil); !errors.Is(err, failure) {
			t.Fatalf("unsynced attempt%d: %v", attempt, err)
		}
		if s.state.Objects[o.ID].Version != 1 || len(s.state.Versions[o.ID]) != 1 {
			t.Fatal("unsynced blob entered authoritative version")
		}
	}
	if leafSyncs != 2 {
		t.Fatalf("existing-address retry skipped original sync: %d", leafSyncs)
	}
	if _, err := os.Stat(filepath.Join(leaf, hashBytes(body))); err != nil {
		t.Fatal("test did not leave a real linked original")
	}
	fail = false
	if _, err := s.PutObjectVersion(context.Background(), p04Owner, o.ID, 1, strings.NewReader(string(body)), nil); err != nil {
		t.Fatal(err)
	}
	if leafSyncs != 3 || s.state.Objects[o.ID].Version != 2 {
		t.Fatal("same-address durability recovery failed")
	}
}

func TestP04BlobDurabilityDirectoryParents(t *testing.T) {
	for _, stage := range []string{"root", "scoped", "owner", "shard"} {
		t.Run(stage, func(t *testing.T) {
			parent := t.TempDir()
			root := filepath.Join(parent, "objects")
			scope := objectStorageScope(p04Owner, "cloud")
			body := []byte("directory-original")
			hash := hashBytes(body)
			failAt := map[string]string{"root": parent, "scoped": root, "owner": filepath.Join(root, "scoped"), "shard": filepath.Join(root, "scoped", scope)}[stage]
			failure := errors.New("PUBLIC directory entry sync failure")
			fail := true
			calls := map[string]int{}
			syncDirectory := func(path string) error {
				calls[path]++
				if fail && path == failAt {
					return failure
				}
				return syncObjectDirectory(path)
			}
			for retry := 0; retry < 2; retry++ {
				if _, err := writeObjectBlob(root, scope, hash, body, syncDirectory); !errors.Is(err, failure) {
					t.Fatalf("directory retry%d: %v", retry, err)
				}
			}
			if calls[failAt] != 2 {
				t.Fatal("existing directory bypassed unfinished parent sync")
			}
			fail = false
			if _, err := writeObjectBlob(root, scope, hash, body, syncDirectory); err != nil {
				t.Fatal(err)
			}
			for _, dir := range []string{parent, root, filepath.Join(root, "scoped"), filepath.Join(root, "scoped", scope), filepath.Join(root, "scoped", scope, hash[:2])} {
				if calls[dir] == 0 {
					t.Fatalf("directory entry not synced: %s", dir)
				}
			}
		})
	}
}
