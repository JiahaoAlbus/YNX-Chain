package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
)

func TestP04OriginalTrashCLIColdLostTrashRestorePreservesVersions(t *testing.T) {
	cfg := p04PrivateHostConfig(t)
	cfg.Cloud.WalletVerifier = acceptWallet{}
	cfg.Limits = ServerLimits{MaxConcurrent: 32, RequestsPerMinute: 10000}
	h, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if h != nil {
			p04ClosePrivateHost(t, h)
		}
	}()
	s, _ := h.Service()
	e := testWalletEnvelope(t, s, "cloud", "PUBLIC_TRASH_CLI", []string{"files.read", "files.write", "permissions.manage"})
	token, _, err := s.CreateSession(context.Background(), e)
	if err != nil {
		t.Fatal(err)
	}
	handler, _ := h.Handler()
	var mu sync.RWMutex
	var trashWrites, hardDeletes atomic.Int32
	var stripProtocol atomic.Bool
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		if stripProtocol.Load() && r.Method == "GET" && r.URL.Path == "/api/v1/session" {
			response := httptest.NewRecorder()
			handler.ServeHTTP(response, r)
			for key, values := range response.Header() {
				if strings.EqualFold(key, "X-Cloud-Object-Protocols") {
					continue
				}
				for _, value := range values {
					w.Header().Add(key, value)
				}
			}
			w.WriteHeader(response.Code)
			_, _ = w.Write(response.Body.Bytes())
			return
		}
		if r.Method == "DELETE" && strings.HasPrefix(r.URL.Path, "/api/v1/objects/") {
			hardDeletes.Add(1)
		}
		if r.Method == "POST" && (strings.HasSuffix(r.URL.Path, "/trash") || strings.HasSuffix(r.URL.Path, "/restore")) {
			n := trashWrites.Add(1)
			if n <= 2 {
				reply := httptest.NewRecorder()
				handler.ServeHTTP(reply, r)
				if reply.Code != 200 {
					t.Errorf("before lost trash ACK %d %s", reply.Code, reply.Body.String())
				}
				conn, _, err := w.(http.Hijacker).Hijack()
				if err == nil {
					_ = conn.Close()
				}
				return
			}
		}
		handler.ServeHTTP(w, r)
	}))
	defer srv.Close()
	root := t.TempDir()
	if err = os.Chmod(root, 0700); err != nil {
		t.Fatal(err)
	}
	script, _ := filepath.Abs("../../apps/cloud/client/trash-cli.fixture.mjs")
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	run := func(stage string, original json.RawMessage) json.RawMessage {
		t.Helper()
		in, _ := json.Marshal(map[string]any{"base": srv.URL + "/api/v1", "token": token, "root": root, "stage": stage, "original": original})
		cmd := exec.Command(node, script)
		cmd.Stdin = bytes.NewReader(in)
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		out, err := cmd.Output()
		if err != nil {
			t.Fatalf("trash CLI %s %v %s", stage, err, stderr.String())
		}
		if !json.Valid(out) || strings.Contains(string(out), token) {
			t.Fatal("invalid/sensitive output")
		}
		return out
	}
	reopen := func() {
		p04ClosePrivateHost(t, h)
		h = nil
		next, err := OpenOriginalPrivateHost(context.Background(), cfg)
		if err != nil {
			t.Fatal(err)
		}
		nextHandler, _ := next.Handler()
		mu.Lock()
		h = next
		handler = nextHandler
		mu.Unlock()
		s, _ = next.Service()
	}
	original := run("initial", nil)
	reopen()
	run("trash-cold", original)
	reopen()
	out := run("restored-cold", original)
	stripProtocol.Store(true)
	run("unsupported", original)
	if trashWrites.Load() != 2 || hardDeletes.Load() != 0 || len(s.state.Objects) != 1 || len(s.state.ObjectOperations) != 4 || len(s.state.BlobDeletions) != 0 {
		t.Fatal("trash original replayed or deleted data", trashWrites.Load(), hardDeletes.Load(), len(s.state.ObjectOperations))
	}
	t.Logf("normalTrash writes2 recoveryReplay0 hardDelete0 blobJobs0 cold2 allVersionsRetained %s", out)
}
