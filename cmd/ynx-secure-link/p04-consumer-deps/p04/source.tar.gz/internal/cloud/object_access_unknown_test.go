package cloud

import (
	"context"
	"errors"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestP04OriginalAccessUnknownSnapshotColdReconcilesSameRecord(t *testing.T) {
	cfg := p04PrivateHostConfig(t)
	cfg.Cloud.WalletVerifier = acceptWallet{}
	h, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer func() { p04ClosePrivateHost(t, h) }()
	service, _ := h.Service()
	server, _ := h.Server()
	obj, err := service.Create(context.Background(), owner, CreateObjectRequest{Kind: KindFile, Name: "PUBLIC_acl.bin", Content: []byte("PUBLIC bytes")})
	if err != nil {
		t.Fatal(err)
	}
	e := testWalletEnvelope(t, service, "cloud", "PUBLIC_ACL_PENDING", []string{"permissions.manage"})
	token, _, err := service.CreateSession(context.Background(), e)
	if err != nil {
		t.Fatal(err)
	}
	id := "PUBLIC_original_unknown_acl"
	observe := func() *httptest.ResponseRecorder {
		r := httptest.NewRequest("GET", "/api/v1/object-operations/"+id, nil)
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		server.Handler().ServeHTTP(w, r)
		return w
	}
	service.cfg.stateDirectorySync = func(string) error { return errors.New("PUBLIC ACL directory sync failure after rename") }
	if _, err = service.SetShareAccessOnce(context.Background(), owner, obj.ID, viewer, true, 1, id); !errors.Is(err, errObjectCommitUnknown) {
		t.Fatal("unknown commit not retained", err)
	}
	if w := observe(); w.Code != 200 || !strings.Contains(w.Body.String(), `"UNKNOWN"`) {
		t.Fatal("uncertain ACL promoted", w.Code, w.Body.String())
	}
	if _, err = service.SetShareAccessOnce(context.Background(), owner, obj.ID, viewer, true, 1, id); !errors.Is(err, errObjectCommitUnknown) {
		t.Fatal("pending original replayed", err)
	}
	p04ClosePrivateHost(t, h)
	h, err = OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	service, _ = h.Service()
	server, _ = h.Server()
	if w := observe(); w.Code != 200 || !strings.Contains(w.Body.String(), `"UNKNOWN"`) {
		t.Fatal("cold original promoted before reconciliation", w.Code, w.Body.String())
	}
	original, err := service.ReconcileObjectCommit(context.Background())
	if err != nil || original.Action != "permission.set" || original.ObjectID != obj.ID || original.Outcome != "COMMITTED" {
		t.Fatal(original, err)
	}
	if w := observe(); w.Code != 200 || !strings.Contains(w.Body.String(), `"allow":true`) || !strings.Contains(w.Body.String(), `"revision":"2"`) {
		t.Fatal("same original not read", w.Code, w.Body.String())
	}
	if len(service.state.Grants) != 1 || len(service.state.ObjectOperations) != 1 || objectRevision(service.state.Objects[obj.ID]) != 2 {
		t.Fatal("original reconciliation created another grant")
	}
}
