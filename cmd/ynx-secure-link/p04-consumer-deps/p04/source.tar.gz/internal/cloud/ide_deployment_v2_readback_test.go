package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

type p04V2ReadbackSource struct {
	denied          atomic.Bool
	reads, executes atomic.Int32
}

func (s *p04V2ReadbackSource) AuthorizeV2(context.Context, *http.Request, string, IDEDeploymentV2Request) (IDEDeploymentV2Permit, error) {
	s.executes.Add(1)
	return nil, ErrDenied
}
func (s *p04V2ReadbackSource) AuthorizeV2Read(_ context.Context, r *http.Request, op IDEDeploymentOperation) error {
	s.reads.Add(1)
	if s.denied.Load() || r.Header.Get("X-P04-Public-Read") != "PUBLIC_V2_ORIGINAL_READER" || op.ManifestVersion != "2" || op.CatalogProjectID != "PUBLIC_DISTINCT_CATALOG_PROJECTION" {
		return ErrDenied
	}
	return nil
}

type p04V2ReadbackExecutor struct {
	publicIDEExecutor
	sample  IDEUsageSample
	applies atomic.Int32
}

func (e *p04V2ReadbackExecutor) ApplyExistingV2(context.Context, IDEDeploymentOperation, string, time.Time, io.Reader, func() error) (IDEDeploymentResult, error) {
	e.applies.Add(1)
	return IDEDeploymentResult{}, ErrDenied
}
func (e *p04V2ReadbackExecutor) Logs(context.Context, IDEDeploymentOperation, int64) ([]byte, error) {
	return []byte("PUBLIC_ORIGINAL_LOG_READBACK_NOT_EXECUTION"), nil
}
func (e *p04V2ReadbackExecutor) ObserveUsage(context.Context, IDEDeploymentOperation) (IDEUsageSample, error) {
	return e.sample, nil
}

func TestP04V2NormalReadbackOriginalLogsUsageBillColdAndRevoke(t *testing.T) {
	p04V2NormalReadback(t, false)
}

func TestP04V2NativeIntentNormalClientColdAndRevoke(t *testing.T) {
	p04V2NormalReadback(t, true)
}

func TestP04V2DurableReceiptNormalBillingColdAndRevoke(t *testing.T) {
	p04V2NormalReadback(t, true, true)
}

func p04V2NormalReadback(t *testing.T, nativeIntent bool, receiptCLI ...bool) {
	// New production caller path over real normal Cloud/HTTP/journal. Only
	// Source, pricing and runtime ports are PUBLIC fixtures, not real admission.
	codec, _, payload, body := p04V2SDKFixture(t)
	held, err := ReadIDEDeploymentArtifactV2(context.Background(), codec, bytes.NewReader(payload), bytes.NewReader(body), nil, MaxMultipartBytes)
	if err != nil {
		t.Fatal(err)
	}
	cfg := p04PrivateHostConfig(t)
	cfg.Limits = ServerLimits{MaxConcurrent: 16, RequestsPerMinute: 10000}
	host, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer func() { p04ClosePrivateHost(t, host) }()
	server, _ := host.Server()
	owner := "PUBLIC_BILL_OWNER"
	base := &publicIDEAuthority{principal: owner}
	source := &p04V2ReadbackSource{}
	engine := &p04V2ReadbackExecutor{}
	if err = server.EnableIDEDeployments(base, engine); err != nil {
		t.Fatal(err)
	}
	if err = server.EnableIDEDeploymentV2Authority(source); err != nil {
		t.Fatal(err)
	}
	manifest, bind, content := held.Manifest(), held.Binding(), held.ContentBinding()
	period := "2026-10-28"
	start, end, _ := usagePeriod(period)
	observed := start.Add(12 * time.Hour)
	op := IDEDeploymentOperation{ManifestVersion: "2", CatalogProjectID: "PUBLIC_DISTINCT_CATALOG_PROJECTION", ManifestV2: &manifest, ManifestBinding: &bind, ContentBinding: &content, ArtifactSHA256: productHash(body), RequestID: "req_p04_original_v2_readback_000001", ManifestSHA256: productHash(payload), ApprovalSHA256: strings.Repeat("b", 64), PublisherID: "PUBLIC_PUBLISHER", ResourceID: "PUBLIC_RESOURCE", CreatedAt: start, ExpectedSlotRevision: "0", SlotRevision: "1"}
	op, _, err = server.ideDeployments.journal.begin(owner, op)
	if err != nil {
		t.Fatal(err)
	}
	zero := 0
	op.State = "completed"
	op.ExitCode = &zero
	op.DeploymentID = strings.Repeat("c", 64)
	op.RuntimeURL = "https://public-readback.invalid/original"
	op.UpdatedAt = time.Now()
	if err = server.ideDeployments.journal.recordTerminal(owner, op, func() error { return nil }); err != nil {
		t.Fatal(err)
	}
	engine.sample = IDEUsageSample{InstanceID: op.DeploymentID, Period: period, SampleSeq: strconv.FormatInt(observed.UnixNano(), 10), CPUNanos: "1000000", CPUms: "1", MemoryBytes: "4096", StoredBytes: strconv.Itoa(len(body)), EgressBytes: "10", ObservedAt: observed}
	if _, err = server.ideDeployments.journal.recordUsage(owner, op, engine.sample, func() error { return nil }); err != nil {
		t.Fatal(err)
	}
	schedule := IDEUsagePriceSchedule{ManifestVersion: "2", ProjectRef: manifest.Project, ProjectID: op.CatalogProjectID, ResourceID: op.ResourceID, ID: "PUBLIC_TARIFF", Revision: "1", RegistrationRef: "PUBLIC_REGISTERED", CurrentRef: "PUBLIC_CURRENT", ApprovalRef: "PUBLIC_APPROVAL", Merchant: "PUBLIC_MERCHANT", Recipient: "PUBLIC_RECIPIENT", Asset: IDEUsageAsset{Genesis: strings.Repeat("d", 64), NativeChainID: "71", AssetID: "PUBLIC_ASSET", UnitVersion: "0"}, EffectiveFrom: start, EffectiveUntil: end, MeterRule: "cumulative-sample-end/UTC-day/ceil-total/v1", CPUNanos: IDEUsageRate{Units: "1000000", Atoms: "2"}, EgressBytes: IDEUsageRate{Units: "10", Atoms: "3"}, PeakStoredBytes: IDEUsageRate{Units: "64", Atoms: "1"}}
	prices := &p04BillingPriceSource{schedules: map[string]IDEUsagePriceSchedule{period: schedule}}
	if nativeIntent {
		schedule.Merchant = "0x" + strings.Repeat("a", 40)
		schedule.Recipient = "0x" + strings.Repeat("b", 40)
		schedule.Asset.AssetID = "YNXT"
		schedule.Asset.UnitVersion = "1"
		prices.schedules[period] = schedule
	}
	pay := &p04V2BillProducer{}
	if err = server.EnableIDEUsageBilling(prices, pay); err != nil {
		t.Fatal(err)
	}
	bill, err := server.ideDeployments.billUsage(context.Background(), httptest.NewRequest("POST", "/PUBLIC-SETUP", nil), owner, op, period, true, func() error { return nil })
	if err != nil || pay.creates != 1 || bill.Request.Atoms != "6" {
		t.Fatal("PUBLIC original setup", err)
	}
	var mu sync.RWMutex
	handler, _ := host.Handler()
	var posts atomic.Int32
	httpServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "GET" {
			posts.Add(1)
			http.Error(w, "no writes in this journey", 405)
			return
		}
		mu.RLock()
		defer mu.RUnlock()
		handler.ServeHTTP(w, r)
	}))
	defer httpServer.Close()
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	script, err := filepath.Abs("../../apps/cloud/client/deployment-v2-service-readback.fixture.mjs")
	if len(receiptCLI) > 0 && receiptCLI[0] {
		script, err = filepath.Abs("../../apps/cloud/client/deployment-v2-receipt-cli.fixture.mjs")
	}
	if err != nil {
		t.Fatal(err)
	}
	selection := map[string]any{"requestId": op.RequestID, "manifestVersion": "2", "domain": "YNX-CLOUD-DEPLOYMENT-MANIFEST/v2", "expectedSlotRevision": "0", "rollbackTo": "", "manifestBinding": bind, "contentBinding": content, "manifest": manifest}
	receiptRoot := t.TempDir()
	if err := os.Chmod(receiptRoot, 0700); err != nil {
		t.Fatal(err)
	}
	run := func(denied bool) json.RawMessage {
		t.Helper()
		input, _ := json.Marshal(map[string]any{"base": httpServer.URL + "/api/v1", "selection": selection, "period": period, "denied": denied, "nativeIntent": nativeIntent, "sourceOrder": bill.Request.BillID, "receiptRoot": receiptRoot})
		cmd := exec.Command(node, script)
		cmd.Stdin = bytes.NewReader(input)
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		out, err := cmd.Output()
		if err != nil {
			t.Fatalf("original V2 client: %v %s", err, stderr.String())
		}
		if !json.Valid(out) {
			t.Fatal("bad V2 readback result")
		}
		return out
	}
	first := run(false)
	p04ClosePrivateHost(t, host)
	host, err = OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	server, _ = host.Server()
	if err = server.EnableIDEDeployments(base, engine); err != nil {
		t.Fatal(err)
	}
	if err = server.EnableIDEDeploymentV2Authority(source); err != nil {
		t.Fatal(err)
	}
	if err = server.EnableIDEUsageBilling(prices, pay); err != nil {
		t.Fatal(err)
	}
	next, _ := host.Handler()
	mu.Lock()
	handler = next
	mu.Unlock()
	second := run(false)
	if !bytes.Equal(first, second) || pay.creates != 1 || pay.queries != 2 || source.executes.Load() != 0 || engine.applies.Load() != 0 || posts.Load() != 0 {
		t.Fatal("cold original read created/replayed execution or invoice", pay.creates, pay.queries, string(first), string(second))
	}
	source.denied.Store(true)
	run(true)
	if source.reads.Load() == 0 || posts.Load() != 0 {
		t.Fatal("read Source not enforced")
	}
	t.Logf("V2_NORMAL_READ request=%s fullProject=%+v catalog=%s originalBill=%s invoiceCreatesBefore=1 after=%d lookup=%d execution=%d post=%d coldStable=true revokedDenied=true", op.RequestID, manifest.Project, op.CatalogProjectID, bill.Request.BillID, pay.creates, pay.queries, engine.applies.Load(), posts.Load())
}
