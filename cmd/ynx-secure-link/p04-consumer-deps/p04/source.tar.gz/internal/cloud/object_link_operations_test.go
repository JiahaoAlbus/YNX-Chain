package cloud

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"testing"
	"time"
)

func TestP04OriginalLinkHashCustodyCancelPreventsLateCreate(t *testing.T) {
	s := p04Service(t)
	obj := p04File(t, s, p04Owner)
	ctx := context.Background()
	expiry := s.cfg.Now().Add(time.Hour).Truncate(time.Millisecond)
	secret := "PUBLIC_256BIT_CAPABILITY_CLIENT_ONLY"
	digest := hashBytes([]byte(secret))
	id := "PUBLIC_original_link_001"
	link, err := s.CreateLinkOnce(ctx, p04Owner, obj.ID, id, digest, "viewer", expiry, 1)
	if err != nil {
		t.Fatal(err)
	}
	if _, body, err := s.ResolveLinkContent(secret); err != nil || string(body) != "V1" {
		t.Fatal("hash-only capability did not resolve", err)
	}
	raw, _ := json.Marshal(s.state)
	if strings.Contains(string(raw), secret) {
		t.Fatal("server persisted plaintext capability")
	}
	if err = s.CancelOriginalLink(ctx, p04Owner, obj.ID, id, digest, "viewer", expiry, 1); err != nil {
		t.Fatal(err)
	}
	again, err := s.CreateLinkOnce(ctx, p04Owner, obj.ID, id, digest, "viewer", expiry, 1)
	if err != nil || again.ID != link.ID || again.RevokedAt == nil || len(s.state.Links) != 1 {
		t.Fatal("original revoked link renewed", again, err)
	}
	*again.RevokedAt = time.Time{}
	if s.state.Links[link.ID].RevokedAt.IsZero() {
		t.Fatal("returned revoked link aliases original snapshot")
	}
	if _, _, err = s.ResolveLinkContent(secret); !errors.Is(err, ErrDenied) {
		t.Fatal("revoked capability accepted", err)
	}
	digest2 := hashBytes([]byte("PUBLIC_CANCEL_BEFORE_CREATE"))
	id2 := "PUBLIC_cancel_before_create"
	if err = s.CancelOriginalLink(ctx, p04Owner, obj.ID, id2, digest2, "viewer", expiry, 1); err != nil {
		t.Fatal(err)
	}
	if _, err = s.CreateLinkOnce(ctx, p04Owner, obj.ID, id2, digest2, "viewer", expiry, 1); !errors.Is(err, errOriginalLinkCancelled) {
		t.Fatal("late create bypassed cancellation", err)
	}
	if _, err = s.CreateLinkOnce(ctx, p04Owner, obj.ID, "PUBLIC_new_id_same_hash", digest2, "viewer", expiry, 1); !errors.Is(err, errObjectOperationConflict) {
		t.Fatal("cancelled hash reused", err)
	}
	if _, err = s.CreateLinkOnce(ctx, p04Owner, obj.ID, id, hashBytes([]byte("CHANGED")), "viewer", expiry, 1); !errors.Is(err, errObjectOperationConflict) {
		t.Fatal("changed original digest admitted", err)
	}
	if _, err = s.CreateLinkOnce(ctx, p04Other, obj.ID, "PUBLIC_foreign_capability", digest2, "viewer", expiry, 1); !errors.Is(err, ErrDenied) {
		t.Fatal("nonowner issued link", err)
	}
	view, err := s.GetObjectOperation(p04Owner, "cloud", id2)
	if err != nil || view.Outcome != "CANCELLED" || view.Link != nil || len(s.state.Links) != 1 {
		t.Fatal(view, err)
	}
	cancelled, cancel := context.WithCancel(ctx)
	cancel()
	if err = s.CancelOriginalLink(cancelled, p04Owner, obj.ID, id, digest, "viewer", expiry, 1); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}
