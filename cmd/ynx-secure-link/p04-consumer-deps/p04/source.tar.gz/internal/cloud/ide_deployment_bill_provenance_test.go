package cloud

import (
	"context"
	"encoding/json"
	"errors"
	"net/http/httptest"
	"os"
	"path/filepath"
	"reflect"
	"testing"
	"time"

	"golang.org/x/sys/unix"
)

// PUBLIC pricing/Pay ports only. The production callee below reads the actual
// canonical private operation/usage files, not these fixture-returned values.
type p04ProvenanceLostPay struct{ creates, lookups int }

func (p *p04ProvenanceLostPay) CreateUsageInvoice(context.Context, IDEUsageInvoiceRequest, func() error) (IDEUsageInvoiceResult, error) {
	p.creates++
	return IDEUsageInvoiceResult{}, errors.New("PUBLIC lost response")
}
func (p *p04ProvenanceLostPay) LookupUsageInvoice(context.Context, IDEUsageInvoiceRequest) (IDEUsageInvoiceResult, error) {
	p.lookups++
	return IDEUsageInvoiceResult{}, ErrNotFound
}
func p04OriginalBillFixture(t *testing.T) (*Server, string, IDEDeploymentOperation, IDEUsageBill, *p04ProvenanceLostPay) {
	t.Helper()
	s, auth, op, prices := p04BillingFixture(t)
	p := &p04ProvenanceLostPay{}
	if err := s.EnableIDEUsageBilling(prices, p); err != nil {
		t.Fatal(err)
	}
	r := httptest.NewRequest("POST", "/PUBLIC", nil)
	bill, err := s.ideDeployments.billUsage(context.Background(), r, auth.principal, op, "2026-10-28", true, func() error { return nil })
	if err != nil || bill.State != "UNKNOWN" || p.creates != 1 {
		t.Fatal("original durable unknown", err)
	}
	return s, auth.principal, op, bill, p
}

func TestP04OriginalBillProvenanceReadOnlyAndColdUNKNOWN(t *testing.T) {
	s, owner, op, bill, pay := p04OriginalBillFixture(t)
	reader, err := s.OpenOriginalIDEUsageBillReader()
	if err != nil {
		t.Fatal(err)
	}
	file := reader.journal.file(owner, op.RequestID) + ".usage"
	before, err := os.ReadFile(file)
	if err != nil {
		t.Fatal(err)
	}
	info, _ := os.Stat(file)
	entries, _ := os.ReadDir(filepath.Dir(file))
	h, err := reader.Capture(context.Background(), owner, op.RequestID, bill.Request.Period)
	if err != nil {
		t.Fatal(err)
	}
	defer h.Close()
	data, err := h.DATA()
	if err != nil || data.Bill != bill || data.ProjectID != op.Binding.ProjectID || data.Owner != owner {
		t.Fatal("original complete bill not retained", err)
	}
	digest, _ := h.SHA256()
	raw, _ := json.Marshal(data)
	if digest != productHash(raw) {
		t.Fatal("snapshot digest")
	}
	data.Bill.Request.Atoms = "999"
	again, _ := h.DATA()
	if again.Bill != bill {
		t.Fatal("DATA copy mutated original")
	}
	// An exclusive original billing writer lock cannot deadlock/reenter from
	// Current: it is safe even where another caller already holds Pay Store.
	fd, err := unix.Open(file+".lock", unix.O_RDONLY|unix.O_CLOEXEC, 0)
	if err != nil {
		t.Fatal(err)
	}
	if err = unix.Flock(fd, unix.LOCK_EX|unix.LOCK_NB); err != nil {
		t.Fatal(err)
	}
	if err = h.Current(); err != nil {
		t.Fatal(err)
	}
	if _, err = reader.Capture(context.Background(), owner, op.RequestID, bill.Request.Period); !errors.Is(err, ErrIDEResourceBusy) {
		t.Fatal("capture ignored writer lock", err)
	}
	unix.Flock(fd, unix.LOCK_UN)
	unix.Close(fd)
	// Cold reader uses the same original directory. No reconciliation/POST.
	cold, err := newIDEDeploymentJournal(reader.journal.original.root)
	if err != nil {
		t.Fatal(err)
	}
	coldReader := &IDEUsageBillReader{journal: cold}
	coldReader.self = coldReader
	h2, err := coldReader.Capture(context.Background(), owner, op.RequestID, bill.Request.Period)
	if err != nil {
		t.Fatal(err)
	}
	defer h2.Close()
	coldData, _ := h2.DATA()
	if coldData != again || pay.creates != 1 || pay.lookups != 0 {
		t.Fatal("cold capture replayed or changed original")
	}
	after, _ := os.ReadFile(file)
	afterInfo, _ := os.Stat(file)
	afterEntries, _ := os.ReadDir(filepath.Dir(file))
	if string(before) != string(after) || !os.SameFile(info, afterInfo) || !info.ModTime().Equal(afterInfo.ModTime()) || len(entries) != len(afterEntries) {
		t.Fatal("readonly capture wrote journal")
	}
}

func TestP04OriginalBillProvenanceRejectsCloneContextRetireAndTamper(t *testing.T) {
	s, owner, op, bill, _ := p04OriginalBillFixture(t)
	reader, _ := s.OpenOriginalIDEUsageBillReader()
	for _, input := range []struct{ owner, id, period string }{{"OTHER_TENANT", op.RequestID, bill.Request.Period}, {owner, "req_other_original", bill.Request.Period}, {owner, op.RequestID, "2026-10-29"}, {owner, op.RequestID, "2999-01-01"}} {
		if h, err := reader.Capture(context.Background(), input.owner, input.id, input.period); err == nil || h != nil {
			t.Fatal("cross owner/original/period minted", err)
		}
	}
	ctx, cancel := context.WithCancel(context.Background())
	h, err := reader.Capture(ctx, owner, op.RequestID, bill.Request.Period)
	if err != nil {
		t.Fatal(err)
	}
	var clone IDEUsageBillProvenance
	reflect.ValueOf(&clone).Elem().Set(reflect.ValueOf(h).Elem())
	if clone.Current() == nil {
		t.Fatal("copied holder admitted")
	}
	var dto IDEUsageBillProvenance
	_ = json.Unmarshal([]byte(`{}`), &dto)
	if dto.Current() == nil {
		t.Fatal("DTO minted holder")
	}
	cancel()
	if !errors.Is(h.Current(), context.Canceled) || !errors.Is(h.Current(), context.Canceled) {
		t.Fatal("first cancellation lost")
	}
	if !errors.Is(h.Close(), context.Canceled) || !errors.Is(h.Close(), context.Canceled) {
		t.Fatal("close lost original cancellation")
	}
	h2, err := reader.Capture(context.Background(), owner, op.RequestID, bill.Request.Period)
	if err != nil {
		t.Fatal(err)
	}
	if err = h2.Close(); err != nil {
		t.Fatal(err)
	}
	if h2.Current() == nil {
		t.Fatal("closed holder revived")
	}
	if err = h2.Close(); err != nil {
		t.Fatal("successful close changed after denied read", err)
	}
	short, cancelShort := context.WithTimeout(context.Background(), 50*time.Millisecond)
	defer cancelShort()
	h3, err := reader.Capture(short, owner, op.RequestID, bill.Request.Period)
	if err != nil {
		t.Fatal(err)
	}
	deadline, _ := short.Deadline()
	if h3.Until().After(deadline) {
		t.Fatal("capture extends caller deadline")
	}
	<-short.Done()
	if h3.Current() == nil {
		t.Fatal("expired capture admitted")
	}
	if h3.Current() == nil {
		t.Fatal("expired capture revived")
	}
	file := reader.journal.file(owner, op.RequestID) + ".usage"
	record, err := readIDEUsage(file)
	if err != nil {
		t.Fatal(err)
	}
	corrupt := record.Bills[bill.Request.Period]
	corrupt.Request.Atoms = "999"
	record.Bills[bill.Request.Period] = corrupt
	raw, _ := json.Marshal(record)
	if err = os.WriteFile(file, raw, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err = reader.Capture(context.Background(), owner, op.RequestID, bill.Request.Period); err == nil {
		t.Fatal("copied aggregate amount accepted")
	}
	// Restore only this PUBLIC fixture file, never production data.
	record.Bills[bill.Request.Period] = bill
	raw, _ = json.Marshal(record)
	if err = os.WriteFile(file, raw, 0600); err != nil {
		t.Fatal(err)
	}
	h4, err := reader.Capture(context.Background(), owner, op.RequestID, bill.Request.Period)
	if err != nil {
		t.Fatal(err)
	}
	s.RetireOriginalIDEUsageBillReader()
	if h4.Current() == nil {
		t.Fatal("retired parent admitted")
	}
	if _, err = reader.Capture(context.Background(), owner, op.RequestID, bill.Request.Period); err == nil {
		t.Fatal("retired reader reopened")
	}
	if _, err = s.OpenOriginalIDEUsageBillReader(); err == nil {
		t.Fatal("server replaced retired reader")
	}
	s2, _, _, _, _ := p04OriginalBillFixture(t)
	s2.RetireOriginalIDEUsageBillReader()
	if _, err = s2.OpenOriginalIDEUsageBillReader(); err == nil {
		t.Fatal("shutdown before first capture allowed a fresh reader")
	}
}
