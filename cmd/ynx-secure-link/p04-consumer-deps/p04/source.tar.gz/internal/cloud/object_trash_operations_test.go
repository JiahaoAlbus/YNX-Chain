package cloud

import (
	"context"
	"errors"
	"strings"
	"testing"
)

func TestP04OriginalTrashImmutableOutcomeAndLegacyRevisionFence(t *testing.T) {
	s := p04Service(t)
	obj := p04File(t, s, p04Owner)
	ctx := context.Background()
	trashed, err := s.SetTrashOnce(ctx, p04Owner, obj.ID, true, 1, "PUBLIC_original_trash_001")
	if err != nil || trashed.TrashedAt == nil || objectRevision(trashed) != 2 {
		t.Fatal(trashed, err)
	}
	restored, err := s.SetTrashOnce(ctx, p04Owner, obj.ID, false, 2, "PUBLIC_original_restore_001")
	if err != nil || restored.TrashedAt != nil || objectRevision(restored) != 3 {
		t.Fatal(restored, err)
	}
	duplicate, err := s.SetTrashOnce(ctx, p04Owner, obj.ID, true, 1, "PUBLIC_original_trash_001")
	if err != nil || duplicate.TrashedAt != nil || objectRevision(duplicate) != 3 {
		t.Fatal("old trash reapplied", duplicate, err)
	}
	original, err := s.GetObjectOperation(p04Owner, "cloud", "PUBLIC_original_trash_001")
	if err != nil || original.Revision != "2" || original.Version != 1 {
		t.Fatal(original, err)
	}
	if _, err = s.SetTrashOnce(ctx, p04Owner, obj.ID, false, 1, "PUBLIC_original_trash_001"); !errors.Is(err, errObjectOperationConflict) {
		t.Fatal("changed original action admitted", err)
	}
	if _, err = s.SetTrash(p04Owner, obj.ID, true); err != nil {
		t.Fatal(err)
	}
	if _, err = s.SetTrash(p04Owner, obj.ID, false); err != nil {
		t.Fatal(err)
	}
	if objectRevision(s.state.Objects[obj.ID]) != 5 {
		t.Fatal("legacy trash/restore did not fence stale CAS")
	}
	var conflict ConflictError
	if _, err = s.PutObjectVersion(ctx, p04Owner, obj.ID, 3, strings.NewReader("STALE"), nil); !errors.As(err, &conflict) {
		t.Fatal("pre-trash stale version write admitted", err)
	}
	if _, err = s.SetTrashOnce(ctx, p04Other, obj.ID, true, 5, "PUBLIC_foreign_trash_001"); !errors.Is(err, ErrDenied) {
		t.Fatal(err)
	}
	cancelled, cancel := context.WithCancel(ctx)
	cancel()
	if _, err = s.SetTrashOnce(cancelled, p04Owner, obj.ID, true, 5, "PUBLIC_cancelled_trash_001"); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	if len(s.state.ObjectOperations) != 2 || len(s.state.Versions[obj.ID]) != 1 || len(s.state.BlobDeletions) != 0 {
		t.Fatal("trash modified bytes/history or scheduled physical deletion")
	}
}

func TestP04OriginalTrashSnapshotUnknownColdSameCommit(t *testing.T) {
	for _, trash := range []bool{true, false} {
		t.Run(map[bool]string{true: "trash", false: "restore"}[trash], func(t *testing.T) {
			cfg := p04PrivateHostConfig(t)
			h, err := OpenOriginalPrivateHost(context.Background(), cfg)
			if err != nil {
				t.Fatal(err)
			}
			defer func() { p04ClosePrivateHost(t, h) }()
			s, _ := h.Service()
			obj, err := s.Create(context.Background(), owner, CreateObjectRequest{Kind: KindFile, Name: "PUBLIC_trash.bin", Content: []byte("PUBLIC")})
			if err != nil {
				t.Fatal(err)
			}
			expected := uint64(1)
			if !trash {
				if _, err = s.SetTrash(owner, obj.ID, true); err != nil {
					t.Fatal(err)
				}
				expected = 2
			}
			id := "PUBLIC_original_unknown_trash"
			s.cfg.stateDirectorySync = func(string) error { return errors.New("PUBLIC trash directory sync failed after rename") }
			if _, err = s.SetTrashOnce(context.Background(), owner, obj.ID, trash, expected, id); !errors.Is(err, errObjectCommitUnknown) {
				t.Fatal(err)
			}
			if view, e := s.GetObjectOperation(owner, "cloud", id); e != nil || view.Outcome != "UNKNOWN" {
				t.Fatal("uncertain trash promoted", view, e)
			}
			p04ClosePrivateHost(t, h)
			h, err = OpenOriginalPrivateHost(context.Background(), cfg)
			if err != nil {
				t.Fatal(err)
			}
			s, _ = h.Service()
			if view, e := s.GetObjectOperation(owner, "cloud", id); e != nil || view.Outcome != "UNKNOWN" {
				t.Fatal(view, e)
			}
			observed, e := s.ReconcileObjectCommit(context.Background())
			if e != nil || observed.Outcome != "COMMITTED" {
				t.Fatal(observed, e)
			}
			if current := s.state.Objects[obj.ID]; (current.TrashedAt != nil) != trash || objectRevision(current) != expected+1 {
				t.Fatal("original trash state lost")
			}
			if len(s.state.Versions[obj.ID]) != 1 || len(s.state.BlobDeletions) != 0 {
				t.Fatal("trash recovery deleted versions")
			}
		})
	}
}
