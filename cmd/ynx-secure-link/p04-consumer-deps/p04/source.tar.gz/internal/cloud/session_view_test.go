package cloud

import (
	"context"
	"errors"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestP04SessionStatusRetainsUnknownCommitInsteadOfRevocation401(t *testing.T) {
	cfg := p04PrivateHostConfig(t)
	cfg.Cloud.WalletVerifier = acceptWallet{}
	h, err := OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer func() { p04ClosePrivateHost(t, h) }()
	s, _ := h.Service()
	server, _ := h.Server()
	e := testWalletEnvelope(t, s, "cloud", "PUBLIC_REVOKE_SYNC_FAIL", []string{"files.read"})
	token, _, err := s.CreateSession(context.Background(), e)
	if err != nil {
		t.Fatal(err)
	}
	request := func() *httptest.ResponseRecorder {
		r := httptest.NewRequest("GET", "/api/v1/session", nil)
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		server.Handler().ServeHTTP(w, r)
		return w
	}
	if w := request(); w.Code != 200 || w.Header().Get("Cache-Control") != "no-store" {
		t.Fatal(w.Code)
	}
	s.cfg.stateDirectorySync = func(string) error { return errors.New("PUBLIC directory sync failure after rename") }
	if err = s.RevokeSession(token); !errors.Is(err, errObjectCommitUnknown) {
		t.Fatal("lost durable outcome not retained", err)
	}
	if w := request(); w.Code != 503 || !strings.Contains(w.Body.String(), `"UNKNOWN"`) {
		t.Fatal("uncertain revocation became missing-session fact", w.Code, w.Body.String())
	}
	// Reopen the original persisted snapshot normally; no second DELETE or
	// session creation. Only then can original status truthfully report401.
	p04ClosePrivateHost(t, h)
	h, err = OpenOriginalPrivateHost(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	server, _ = h.Server()
	if w := request(); w.Code != 503 {
		t.Fatal("cold pending intent lost", w.Code)
	}
	s, _ = h.Service()
	observation, err := s.ReconcileObjectCommit(context.Background())
	if err != nil || observation.Action != "session.revoke" || observation.Outcome != "COMMITTED" {
		t.Fatal("same original commit reconciliation", observation, err)
	}
	if w := request(); w.Code != 401 || w.Header().Get("Cache-Control") != "no-store" {
		t.Fatal("cold original read", w.Code, w.Body.String())
	}
}
