package cloud

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"
)

// PUBLIC authority/executor seams at real product handlers. No signature,
// Native/Root admission, public deployment or Auth durable nonce is simulated
// as production success by these tests.
type p04ReadFenceExecutor struct {
	*publicIDEExecutor
	during func(context.Context)
}

func (e *p04ReadFenceExecutor) Logs(ctx context.Context, _ IDEDeploymentOperation, _ int64) ([]byte, error) {
	e.during(ctx)
	return []byte("PUBLIC_PRIVATE_LOG_MUST_NOT_LEAK_LATE"), nil
}

func TestIDEDeploymentReadFenceLateOriginalMutation(t *testing.T) {
	for _, mode := range []string{"header", "request-target", "operation", "resource", "manifest", "deleted"} {
		t.Run(mode, func(t *testing.T) {
			s, a, original, h := publicIDEFixture(t)
			body, manifest, _ := ideArtifactData(t)
			id := "req_PUBLIC_LATE_READ_000001"
			if out := publicIDESubmit(t, h, body, manifest, id); out.Code != 201 {
				t.Fatal(out.Code, out.Body.String())
			}
			r := httptest.NewRequest(http.MethodGet, "/api/v1/ide/deployments/"+id+"/logs", nil)
			s.ideDeployments.executor = &p04ReadFenceExecutor{original, func(context.Context) {
				switch mode {
				case "header":
					r.Header.Set("X-Public-Credential", "REPLACEMENT")
				case "request-target":
					r.RequestURI += "?late=foreign"
				case "deleted":
					if err := os.Remove(s.ideDeployments.journal.file(a.principal, id)); err != nil {
						t.Fatal(err)
					}
				default:
					file := s.ideDeployments.journal.file(a.principal, id)
					raw, err := os.ReadFile(file)
					if err != nil {
						t.Fatal(err)
					}
					var record ideDeploymentRecord
					if json.Unmarshal(raw, &record) != nil {
						t.Fatal("record")
					}
					switch mode {
					case "operation":
						record.Operation.DeploymentID = "PUBLIC_FOREIGN_INSTANCE"
					case "resource":
						record.Operation.ResourceID = "PUBLIC_FOREIGN_RESOURCE"
					case "manifest":
						record.Operation.ManifestSHA256 = strings.Repeat("f", 64)
					}
					raw, err = json.Marshal(record)
					if err != nil {
						t.Fatal(err)
					}
					if err = os.WriteFile(file, raw, 0600); err != nil {
						t.Fatal(err)
					}
				}
			}}
			w := httptest.NewRecorder()
			h.ServeHTTP(w, r)
			if w.Code != 403 || strings.Contains(w.Body.String(), "PUBLIC_PRIVATE_LOG") {
				t.Fatalf("late result escaped: %d %s", w.Code, w.Body.String())
			}
			if original.applies != 1 {
				t.Fatal("read resubmitted original operation")
			}
		})
	}
}

func TestIDEDeploymentReadFenceCancellationRetainsHandlerDebt(t *testing.T) {
	s, _, original, h := publicIDEFixture(t)
	body, manifest, _ := ideArtifactData(t)
	id := "req_PUBLIC_READ_DEBT_000001"
	if out := publicIDESubmit(t, h, body, manifest, id); out.Code != 201 {
		t.Fatal(out.Code)
	}
	entered, release, done := make(chan struct{}), make(chan struct{}), make(chan struct{})
	s.ideDeployments.executor = &p04ReadFenceExecutor{original, func(context.Context) { close(entered); <-release }}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	r := httptest.NewRequest(http.MethodGet, "/api/v1/ide/deployments/"+id+"/logs", nil).WithContext(ctx)
	w := httptest.NewRecorder()
	go func() { defer close(done); h.ServeHTTP(w, r) }()
	<-entered
	cancel()
	select {
	case <-done:
		t.Fatal("handler released an undrained executor")
	default:
	}
	close(release)
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("handler did not drain")
	}
	if w.Code == 200 || strings.Contains(w.Body.String(), "PUBLIC_PRIVATE_LOG") {
		t.Fatal("canceled late response escaped", w.Code)
	}
	if original.applies != 1 {
		t.Fatal("read resubmitted original operation")
	}
}

type p04ReadFenceAuthority struct {
	*publicIDEAuthority
	onRead func()
}

func (a *p04ReadFenceAuthority) AuthorizeRead(context.Context, *http.Request, IDEDeploymentOperation) error {
	if a.onRead != nil {
		a.onRead()
	}
	return nil
}

func TestIDEDeploymentReadFenceSevenViewsAndFinalSourceMutation(t *testing.T) {
	s, a, _, h := publicIDEFixture(t)
	body, manifest, _ := ideArtifactData(t)
	id := "req_PUBLIC_SEVEN_FENCE_000001"
	if out := publicIDESubmit(t, h, body, manifest, id); out.Code != 201 {
		t.Fatal(out.Code)
	}
	op, err := s.ideDeployments.journal.lookup(a.principal, id)
	if err != nil {
		t.Fatal(err)
	}
	for _, route := range []struct{ suffix, pattern string }{
		{"", "GET /api/v1/ide/deployments/{request}"},
		{"/logs", "GET /api/v1/ide/deployments/{request}/logs"},
		{"/runtime", "GET /api/v1/ide/deployments/{request}/runtime"},
		{"/usage", "GET /api/v1/ide/deployments/{request}/usage"},
		{"/usage/records", "GET /api/v1/ide/deployments/{request}/usage/records"},
		{"/billing/2026-11-07", "GET /api/v1/ide/deployments/{request}/billing/{period}"},
		{"/billing/2026-11-07/native-intent", "GET /api/v1/ide/deployments/{request}/billing/{period}/native-intent"},
	} {
		t.Run(route.suffix, func(t *testing.T) {
			r := httptest.NewRequest(http.MethodGet, "/api/v1/ide/deployments/"+id+route.suffix, nil)
			r.Pattern = route.pattern
			r.SetPathValue("request", id)
			if strings.Contains(route.suffix, "billing") {
				r.SetPathValue("period", "2026-11-07")
			}
			authority := &p04ReadFenceAuthority{publicIDEAuthority: a}
			s.ideDeployments.authority = authority
			fence := s.ideDeployments.originalReadFence(r, a.principal, op)
			if err := fence(op); err != nil {
				t.Fatal("original current selection refused", err)
			}
			// Mutation occurs INSIDE the original current callee, after the first
			// request/journal check. It cannot escape via successful Auth return.
			authority.onRead = func() { r.Header.Set("X-Public-Original", "late replacement") }
			if err := fence(op); err == nil {
				t.Fatal("post-Source mutation accepted")
			}
			authority.onRead = nil
			r.Header.Del("X-Public-Original")
			if err := fence(op); err == nil {
				t.Fatal("retired request revived after restoration")
			}
		})
	}
}

func TestIDEDeploymentReadFenceDetachedOriginalAndTerminal(t *testing.T) {
	s, a, _, h := publicIDEFixture(t)
	body, manifest, _ := ideArtifactData(t)
	id := "req_PUBLIC_DETACHED_FENCE_000001"
	if out := publicIDESubmit(t, h, body, manifest, id); out.Code != 201 {
		t.Fatal(out.Code)
	}
	op, err := s.ideDeployments.journal.lookup(a.principal, id)
	if err != nil || op.ContentBinding == nil {
		t.Fatal("fixture missing original binding", err)
	}
	r := httptest.NewRequest(http.MethodGet, "/api/v1/ide/deployments/"+id, nil)
	r.Pattern = "GET /api/v1/ide/deployments/{request}"
	r.SetPathValue("request", id)
	fence := s.ideDeployments.originalReadFence(r, a.principal, op)
	before := *op.ContentBinding
	op.ContentBinding.Bytes++
	if err := fence(op); err == nil {
		t.Fatal("aliased executor mutation changed immutable original")
	}
	*op.ContentBinding = before
	if err := fence(op); err == nil {
		t.Fatal("failed original fence revived")
	}
}
