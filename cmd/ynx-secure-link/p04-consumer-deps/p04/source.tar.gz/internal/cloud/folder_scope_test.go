package cloud

import (
	"context"
	"errors"
	"testing"
	"time"
)

func TestP04FolderOwnerInheritancePreservesChildOwnerAndDeny(t *testing.T) {
	s := p04Service(t)
	ctx := context.Background()
	parent, err := s.Create(ctx, p04Owner, CreateObjectRequest{Kind: KindFolder, Name: "PUBLIC parent"})
	if err != nil {
		t.Fatal(err)
	}
	if _, err = s.Grant(p04Owner, parent.ID, p04Other, "editor", nil); err != nil {
		t.Fatal(err)
	}
	child, err := s.CreateObjectOnce(ctx, p04Other, "PUBLIC_folder_child_001", CreateObjectRequest{Kind: KindFile, Name: "PUBLIC child", ParentID: parent.ID, Content: []byte("PUBLIC")})
	if err != nil {
		t.Fatal(err)
	}
	if child.Owner != p04Other || s.role(p04Owner, child) != "owner" {
		t.Fatal("parent owner lost inherited authority or child owner changed")
	}
	if _, _, err = s.GetObjectVersion(ctx, p04Owner, child.ID, 1); err != nil {
		t.Fatal(err)
	}
	if _, err = s.SetShareAccess(ctx, p04Other, child.ID, p04Owner, false, 1); err != nil {
		t.Fatal(err)
	}
	if _, err = s.Get(p04Owner, child.ID); !errors.Is(err, ErrDenied) {
		t.Fatal("ancestor owner bypassed child deny", err)
	}
	original, err := s.GetObjectOperation(p04Other, "cloud", "PUBLIC_folder_child_001")
	if err != nil || original.ParentID != parent.ID || original.Kind != KindFile {
		t.Fatal("original parent not retained", original, err)
	}
	_, capability, err := s.CreateLink(p04Other, child.ID, "viewer", s.cfg.Now().Add(time.Hour))
	if err != nil {
		t.Fatal(err)
	}
	if _, err = s.SetTrash(p04Owner, parent.ID, true); err != nil {
		t.Fatal(err)
	}
	if _, _, err = s.ResolveLinkContent(capability); err == nil {
		t.Fatal("child share bypassed ancestor trash")
	}
	if _, err = s.Create(ctx, p04Other, CreateObjectRequest{Kind: KindFile, Name: "hidden child", ParentID: parent.ID}); !errors.Is(err, ErrDenied) {
		t.Fatal("new child under trashed tree", err)
	}
	if _, err = s.SetTrash(p04Owner, parent.ID, false); err != nil {
		t.Fatal(err)
	}
	if _, _, err = s.ResolveLinkContent(capability); err != nil {
		t.Fatal("restored ancestor did not preserve original capability", err)
	}
	// Negative legacy-data controls, not fabricated grants or normal admission.
	legacy := s.state.Objects[parent.ID]
	legacy.Product = "PUBLIC_OTHER_PRODUCT"
	s.state.Objects[parent.ID] = legacy
	if _, err = s.Create(ctx, p04Other, CreateObjectRequest{Kind: KindFile, Name: "cross-product", ParentID: parent.ID}); !errors.Is(err, ErrDenied) {
		t.Fatal("cross-product parent admitted", err)
	}
	a := Object{ID: "PUBLIC_cycle_a", Product: "cloud", Owner: p04Other, Kind: KindFolder, ParentID: "PUBLIC_cycle_b"}
	b := a
	b.ID = "PUBLIC_cycle_b"
	b.ParentID = a.ID
	s.state.Objects[a.ID] = a
	s.state.Objects[b.ID] = b
	if s.role("ynx1PUBLIC_UNRELATED_0001", a) != "" {
		t.Fatal("cyclic inherited grant")
	}
}
