package authservertls

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"net"
	"os"
	"path/filepath"
	"sync/atomic"
	"testing"
	"time"
)

// PUBLIC physical seam only: no real certificate/key/Root/Source qualification.
func publicRow(t *testing.T) reviewedServerRelease {
	t.Helper()
	home, e := os.UserHomeDir()
	if e != nil {
		t.Fatal(e)
	}
	dir, e := os.MkdirTemp(home, "PUBLIC-auth-listener-")
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() { _ = os.RemoveAll(dir) })
	pins := make([]reviewedFile, 6)
	for i, name := range []string{"issuer.public", "source.public", "current.public", "cert.public", "key.PUBLIC", "ca.public"} {
		path := filepath.Join(dir, name)
		raw := []byte("PUBLIC-ONLY-" + name)
		if e = os.WriteFile(path, raw, 0600); e != nil {
			t.Fatal(e)
		}
		fi, e := os.Lstat(path)
		if e != nil {
			t.Fatal(e)
		}
		v, ok := id(fi)
		if !ok {
			t.Fatal("stat")
		}
		h := sha256.Sum256(raw)
		pins[i] = reviewedFile{Path: path, Identity: v, SHA256: hex.EncodeToString(h[:])}
	}
	pins[4].Private = true
	pins[4].SHA256 = ""
	reserve, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	addr := reserve.Addr().String()
	_ = reserve.Close()
	now := time.Now().UnixMilli()
	return reviewedServerRelease{"PUBLIC-source", "PUBLIC-instance", "PUBLIC-issuer", "PUBLIC-credential", "7", "public.invalid", "PUBLIC-peer", addr, now - 1000, now + 60000, pins[0], pins[1], pins[2], pins[3], pins[4], pins[5], "https://public.invalid", pins[3].SHA256, pins[5].SHA256}
}
func openPublic(t *testing.T) (*ReviewedServerTLSLease, reviewedServerRelease) {
	t.Helper()
	row := publicRow(t)
	l, e := openReviewedServerTLS(context.Background(), []reviewedServerRelease{row}, uint32(os.Getuid()))
	if e != nil {
		if l != nil {
			_, _ = l.Close()
		}
		t.Fatal(e)
	}
	t.Cleanup(func() { l.Retire(); _, _ = l.Close() })
	return l, row
}
func TestEmptyNormalReturnsOwnedPartial(t *testing.T) {
	l, e := OpenOriginalServerTLSLease(context.Background())
	if l == nil || !errors.Is(e, ErrNotSupplied) {
		t.Fatal(l, e)
	}
	if l.Current(context.Background()) == nil {
		t.Fatal("Root0 current")
	}
	if done, _ := l.Close(); !done {
		t.Fatal("cleanup partial")
	}
}
func TestPhysicalBorrowListenerAndDrain(t *testing.T) {
	l, _ := openPublic(t)
	ctx := context.Background()
	b, e := l.BorrowOriginal(ctx)
	if e != nil {
		t.Fatal(e)
	}
	copied := *b
	v, e := b.OriginalCredentials(ctx)
	if e != nil {
		t.Fatal(e)
	}
	offset, e := l.state.files[4].file.Seek(0, 1)
	if e != nil || offset != 0 {
		t.Fatal("Auth read private bytes", offset, e)
	}
	if v.PrivateKeyFD < 0 || v.CertificateFD == v.PrivateKeyFD {
		t.Fatal("FD association")
	}
	listener, e := b.OriginalListener(ctx)
	if e != nil {
		t.Fatal(e)
	}
	accepted := make(chan error, 1)
	go func() {
		c, e := listener.Accept()
		if c != nil {
			_ = c.Close()
		}
		accepted <- e
	}()
	c, e := net.DialTimeout("tcp", listener.Addr().String(), time.Second)
	if e != nil {
		t.Fatal(e)
	}
	_ = c.Close()
	if e = <-accepted; e != nil {
		t.Fatal(e)
	}
	if done, e := l.Close(); done || !errors.Is(e, ErrPending) {
		t.Fatal(done, e)
	}
	if ok, e := b.Release(); !ok || e != nil {
		t.Fatal(ok, e)
	}
	if ok, e := copied.Release(); !ok || e != nil {
		t.Fatal(ok, e)
	}
	if l.state.borrows != 0 {
		t.Fatal("copy double release")
	}
	if e = l.Join(ctx); e != nil {
		t.Fatal(e)
	}
	if done, e := l.Close(); !done || e != nil {
		t.Fatal(done, e)
	}
	if b.Current(ctx) == nil {
		t.Fatal("released current")
	}
}
func TestRetireUnblocksAcceptAndPreservesParent(t *testing.T) {
	l, _ := openPublic(t)
	b, _ := l.BorrowOriginal(context.Background())
	listener, _ := b.OriginalListener(context.Background())
	result := make(chan error, 1)
	go func() { _, e := listener.Accept(); result <- e }()
	l.Retire()
	select {
	case e := <-result:
		if e == nil {
			t.Fatal("accept after retire")
		}
	case <-time.After(time.Second):
		t.Fatal("accept stuck")
	}
	if done, _ := l.Close(); done {
		t.Fatal("closed under borrow")
	}
	if l.state.files[4].file == nil {
		t.Fatal("key parent closed")
	}
	_, _ = b.Release()
	if done, _ := l.Close(); !done {
		t.Fatal("not drained")
	}
}
func TestReplacementAndContextAreSticky(t *testing.T) {
	for _, kind := range []string{"replace", "context", "keymutation"} {
		t.Run(kind, func(t *testing.T) {
			l, row := openPublic(t)
			ctx := context.Background()
			if kind == "replace" {
				path := row.CurrentOriginal.Path
				if e := os.Rename(path, path+".old"); e != nil {
					t.Fatal(e)
				}
				if e := os.WriteFile(path, []byte("PUBLIC-replacement"), 0600); e != nil {
					t.Fatal(e)
				}
			}
			if kind == "context" {
				c, cancel := context.WithCancel(ctx)
				cancel()
				ctx = c
			}
			if kind == "keymutation" {
				if e := os.WriteFile(row.PrivateKey.Path, []byte("PUBLIC-mutated"), 0600); e != nil {
					t.Fatal(e)
				}
			}
			if l.Current(ctx) == nil {
				t.Fatal("late current accepted")
			}
			// Cancellation refuses this call; physical failure permanently retires.
			if kind != "context" && l.Current(context.Background()) == nil {
				t.Fatal("resurrection")
			}
			if kind == "context" && l.Current(context.Background()) != nil {
				t.Fatal("request cancel retired listener")
			}
		})
	}
}

type lateCancelContext struct {
	context.Context
	calls atomic.Int32
}

func (c *lateCancelContext) Err() error {
	if c.calls.Add(1) >= 2 {
		return context.Canceled
	}
	return nil
}
func TestLateRequestCancellationDoesNotRevokeIssuer(t *testing.T) {
	l, _ := openPublic(t)
	b, e := l.BorrowOriginal(context.Background())
	if e != nil {
		t.Fatal(e)
	}
	defer b.Release()
	if e = l.Current(&lateCancelContext{Context: context.Background()}); !errors.Is(e, context.Canceled) {
		t.Fatal(e)
	}
	if e = l.Current(context.Background()); e != nil {
		t.Fatal("late request canceled entire issuer", e)
	}
	if e = b.Current(&lateCancelContext{Context: context.Background()}); !errors.Is(e, context.Canceled) {
		t.Fatal(e)
	}
	if e = b.Current(context.Background()); e != nil {
		t.Fatal("late borrow cancel retired listener", e)
	}
}
func TestAmbiguousChildCloseNeverClosesParentsOrRetries(t *testing.T) {
	l, _ := openPublic(t)
	last := l.state.files[len(l.state.files)-1]
	_ = last.file.Close()
	done, e := l.Close()
	if done || e == nil {
		t.Fatal(done, e)
	}
	if last.parents[len(last.parents)-1].closeSelected || l.state.files[4].closeSelected {
		t.Fatal("closed ancestor after child failure")
	}
	if done, e = l.Close(); done || !errors.Is(e, ErrUnknown) {
		t.Fatal(done, e)
	}
	if last.parents[len(last.parents)-1].closeSelected {
		t.Fatal("retry crossed child debt")
	}
	// Test-only reclaim untouched fixture FDs; production keeps original debt.
	for _, h := range l.state.files {
		if h.file != nil {
			_ = h.file.Close()
		}
		for _, p := range h.parents {
			if p.file != nil {
				_ = p.file.Close()
			}
		}
	}
}
