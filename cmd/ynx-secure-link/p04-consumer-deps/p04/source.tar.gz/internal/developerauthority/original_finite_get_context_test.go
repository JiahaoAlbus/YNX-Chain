//go:build (linux || darwin) && securelink_openssl && cgo && securelink_public_server_tls_test

package developerauthority

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	batch "github.com/JiahaoAlbus/YNX-Chain/internal/ynxbatch"
	"os"
	"strings"
	"testing"
	"time"
)

// Two fresh real N1 members share one RAM-only PUBLIC mathematical device
// pair and registration. Neither Scope/Root signatures nor DB are authentic.
func contextProofs(t *testing.T) ([]string, finiteDeviceExpected, string, string) {
	t.Helper()
	key, pub, e := batch.KeyGen()
	if e != nil {
		t.Fatal(e)
	}
	defer key.Destroy()
	raw, e := os.ReadFile(os.Getenv("YNX_PUBLIC_R5_VECTOR"))
	if e != nil {
		t.Fatal(e)
	}
	var vector struct{ DeviceUnsigned map[string]any }
	if e = json.Unmarshal(raw, &vector); e != nil {
		t.Fatal(e)
	}
	u := vector.DeviceUnsigned
	now := time.Now().UTC().Truncate(time.Millisecond)
	until := now.Add(28 * time.Second)
	network := strings.Repeat("3", 64)
	expiry := now.Add(2 * time.Minute).Format("2006-01-02T15:04:05.000Z")
	reg := map[string]any{"version": "4", "registrationId": u["deviceRegistrationId"], "networkId": network, "canonicalOwner": u["canonicalOwner"], "productId": u["productId"], "clientId": u["clientId"], "platform": "macos", "applicationId": u["applicationId"], "bundleId": u["bundleId"], "packageId": nil, "origin": u["origin"], "callback": u["callback"], "deviceId": u["deviceId"], "generation": "11", "revision": u["deviceRegistrationRevision"], "pkA": hex.EncodeToString(pub.PKA), "pkB": hex.EncodeToString(pub.PKB), "registeredAt": now.Add(-time.Hour).Format("2006-01-02T15:04:05.000Z"), "expiresAt": expiry, "revokedAt": nil}
	regRaw := string(r5JSON(t, reg))
	u["deviceRegistrationDigest"] = hash([]byte(regRaw))
	u["issuedAt"] = now.Format("2006-01-02T15:04:05.000Z")
	u["expiresAt"] = until.Format("2006-01-02T15:04:05.000Z")
	n, _ := hex.DecodeString(network)
	binding := batch.ProductSessionHTTPBinding{NetworkID: n, Owner: u["canonicalOwner"].(string), PKA: pub.PKA, PKB: pub.PKB}
	headers := []string{}
	for i, suffix := range []string{"", "/logs"} {
		u["path"] = "/api/v1/ide/deployments/PUBLIC_original_operation_0001" + suffix
		u["nonce"] = base64.RawURLEncoding.EncodeToString(bytes.Repeat([]byte{byte(7 + i)}, 32))
		message, e := batch.BuildProductSessionHTTPMessage(r5JSON(t, u), binding)
		if e != nil {
			t.Fatal(e)
		}
		signed, e := batch.BatchSign(key, batch.Metadata{ChainID: n, Owner: binding.Owner, Purpose: batch.ProductSessionHTTPPurpose}, [][]byte{message}, batch.SignOptions{Optimized: true})
		if e != nil {
			t.Fatal(e)
		}
		m, e := batch.Extract(signed, 0)
		if e != nil {
			signed.Discard()
			t.Fatal(e)
		}
		member, e := batch.EncodeMember(m)
		signed.Discard()
		if e != nil {
			t.Fatal(e)
		}
		packet := map[string]any{}
		for k, v := range u {
			packet[k] = v
		}
		packet["member"] = base64.RawURLEncoding.EncodeToString(member)
		headers = append(headers, base64.RawURLEncoding.EncodeToString(r5JSON(t, packet)))
	}
	bundle := u["bundleId"].(string)
	expected := finiteDeviceExpected{network, binding.Owner, u["account"].(string), u["sessionBinding"].(string), u["productId"].(string), u["clientId"].(string), "macos", u["applicationId"].(string), &bundle, nil, u["origin"].(string), u["callback"].(string), u["deviceId"].(string), "11", u["deviceRegistrationId"].(string), u["deviceRegistrationRevision"].(string), u["deviceRegistrationDigest"].(string)}
	session := string(r5JSON(t, map[string]any{"sessionBinding": expected.SessionBinding, "scopes": []string{"project.read"}, "expiresAt": expiry}))
	return headers, expected, regRaw, session
}
func TestContextBoundRealServerSequentialRequests(t *testing.T) {
	headers, expected, reg, session := contextProofs(t)
	f := r5FixtureOpen(t, headers[0], expected, reg, session)
	for i := range headers {
		requestLoan := f.requestLoan
		if i == 1 {
			requestLoan = f.transport.BeginOriginalLogsGET(t, headers[i])
		}
		r := requestLoan.OriginalRequest()
		p, e := f.o.CurrentExistingPrincipal(r.Context(), r)
		if e != nil {
			t.Fatal("actual same native server authenticate", e)
		}
		foreign, cancel := context.WithCancel(context.Background())
		f.o.mu.Lock()
		foreignError := f.s.currentPrincipalLocked(foreign, p)
		f.o.mu.Unlock()
		cancel()
		if foreignError == nil {
			t.Fatal("unbound context borrowed a different request")
		}
		if e = f.o.AssertPrincipalCurrent(r.Context(), p); e != nil {
			t.Fatal("this live original principal", e)
		}
		if _, e = f.o.borrowOriginalDeploymentV2Principal(r.Context(), r); e != nil {
			t.Fatal(e)
		}
		requestContext := r.Context()
		if e = requestLoan.Close(); e != nil {
			t.Fatal("actual response/client physical drain", e)
		}
		select {
		case <-requestContext.Done():
		case <-time.After(time.Second):
			t.Fatal("actual response did not cancel its own request context")
		}
	}
	if f.state.calls != 2 || len(f.state.nonces) != 2 {
		t.Fatal("sequential requests reused or reconsumed an original nonce", f.state.calls)
	}

}
