//go:build (linux || darwin) && securelink_openssl && cgo && securelink_public_server_tls_test

package developerauthority

// Integration controls: genuine FD/pinned-process/current/CAS/nonce-store/
// Core N1 bodies, but Source signatures, registry DB and server TLS are PUBLIC
// seams. Temporary mathematical keys are RAM-only; never Root/real custody.
import (
	"bytes"
	"context"
	"crypto/sha256"
	"database/sql"
	"database/sql/driver"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"github.com/JiahaoAlbus/YNX-Chain/internal/securelink"
	batch "github.com/JiahaoAlbus/YNX-Chain/internal/ynxbatch"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

type r5DB struct {
	source  *ideSourceFixtureDB
	mu      sync.Mutex
	nonces  map[string][]driver.Value
	calls   int
	unknown bool
	late    func()
}
type r5Connector struct{ state *r5DB }
type r5Driver struct{}
type r5Conn struct{ state *r5DB }

func (r5Driver) Open(string) (driver.Conn, error)                  { return nil, errors.New("PUBLIC connector only") }
func (c r5Connector) Connect(context.Context) (driver.Conn, error) { return &r5Conn{c.state}, nil }
func (r5Connector) Driver() driver.Driver                          { return r5Driver{} }
func (*r5Conn) Prepare(string) (driver.Stmt, error)                { return nil, errors.New("PUBLIC no prepare") }
func (*r5Conn) Close() error                                       { return nil }
func (*r5Conn) Begin() (driver.Tx, error)                          { return nil, errors.New("PUBLIC original CAS only") }
func (c *r5Conn) QueryContext(ctx context.Context, q string, a []driver.NamedValue) (driver.Rows, error) {
	if q == originalFiniteGETNonceObserveSQL {
		c.state.mu.Lock()
		defer c.state.mu.Unlock()
		key := a[0].Value.(string) + "/" + a[1].Value.(string) + "/" + a[2].Value.(string)
		v := c.state.nonces[key]
		if len(v) == 0 || v[0] != a[3].Value {
			return &ideSourceRows{done: true}, nil
		}
		return &ideSourceRows{values: append([]driver.Value(nil), v...)}, nil
	}
	if q == "SELECT revision FROM public.auth_ide_http_read_nonce_schema WHERE singleton=1" {
		return &ideSourceRows{values: []driver.Value{int64(1)}}, nil
	}
	if q != originalReadNonceConsumeSQL {
		return (&ideSourceConn{c.state.source}).QueryContext(ctx, q, a)
	}
	c.state.mu.Lock()
	defer c.state.mu.Unlock()
	c.state.calls++
	key := a[0].Value.(string) + "/" + a[1].Value.(string) + "/" + a[2].Value.(string)
	if _, ok := c.state.nonces[key]; ok {
		return &ideSourceRows{done: true}, nil
	}
	receipt := []driver.Value{a[3].Value, a[4].Value, a[5].Value, a[6].Value, a[7].Value, a[8].Value, a[9].Value}
	c.state.nonces[key] = receipt
	if c.state.late != nil {
		c.state.late()
	}
	if c.state.unknown {
		return nil, errors.New("PUBLIC lost original SQL acknowledgement")
	}
	return &ideSourceRows{values: receipt}, nil
}

const r5SourceChild = `import{createHash}from'node:crypto';let raw='';for await(const b of process.stdin)raw+=b;const x=JSON.parse(raw),p=JSON.parse(x.profileRaw),now=Date.now();process.stdout.write(JSON.stringify({projection:{selection:p.selection,principalId:'PUBLIC_ACCOUNT',subjectOwner:'0x'+'1'.repeat(40),subjectKeyVersion:'1',generation:1,sequence:1,floor:0,head:'1'.repeat(64),status:'active',timeFloor:now,expiresAtMs:p.expires,profileDigest:createHash('sha256').update(x.profileRaw).digest('hex'),sourceId:p.sourceId,instanceId:'PUBLIC_INSTANCE',executionHeight:'0',dataOnly:true,nativeAdmission:false},currentRaw:'PUBLIC_NOT_SIGNED_SOURCE'})+'\n');`

type r5Fixture struct {
	o              *OriginalIDEPublicationSourceOwner
	s              *OriginalIDEFiniteGETPrincipalSource
	state          *r5DB
	row            finiteReceiverRelease
	tls            *securelink.OriginalServerTLS
	transport      *securelink.PUBLICOriginalServerTLSFixture
	requestLoan    *securelink.PUBLICOriginalServerTLSRequest
	p              Principal
	request        *http.Request
	profileProject string
	profileDevice  string
}

func r5JSON(t *testing.T, x any) []byte {
	t.Helper()
	b, e := originalIDEJSON(x)
	if e != nil {
		t.Fatal(e)
	}
	return b
}
func r5FixtureOpen(t *testing.T, header string, expected finiteDeviceExpected, registration, session string) *r5Fixture {
	t.Helper()
	ctx := context.Background()
	sdk := os.Getenv("YNX_PUBLIC_R5_FACTORY_SDK")
	node := os.Getenv("YNX_IDE_TEST_NODE")
	cfg := OriginalSourceVerifierConfig{SDKRoot: sdk, Node: fixturePin(t, node)}
	filepath.WalkDir(sdk, func(p string, d os.DirEntry, e error) error {
		if e != nil {
			return e
		}
		if !d.IsDir() {
			pin := fixturePin(t, p)
			rel, _ := filepath.Rel(sdk, p)
			pin.Path = filepath.ToSlash(rel)
			cfg.SDKFiles = append(cfg.SDKFiles, pin)
		}
		return nil
	})
	verifier, e := OpenOriginalSourceVerifier(cfg)
	if e != nil {
		t.Fatal("PUBLIC runtime verifier", e)
	}
	state := &r5DB{source: &ideSourceFixtureDB{records: map[string][]byte{}, heads: map[string][]byte{}, approvals: map[string][]byte{}}, nonces: map[string][]driver.Value{}}
	db := sql.OpenDB(r5Connector{state})
	t.Cleanup(func() { db.Close() })
	publicTLS := securelink.NewPUBLICOriginalServerTLSFixture(t)
	actualTLS := publicTLS.OriginalServerTLS()
	tlsIdentity, e := actualTLS.Identity(ctx)
	if e != nil {
		t.Fatal("PUBLIC actual TLS identity", e)
	}
	spki := sha256.Sum256(tlsIdentity.SPKIDER)
	until := time.Now().Add(time.Minute).UnixMilli()
	p := Principal{expected.Account, expected.DeviceID, "PUBLIC-root-session-ref", "PUBLIC-root-current-ref", 3, 5, until}
	row := finiteReceiverRelease{SourceID: "PUBLIC_BROKER", InstanceID: "PUBLIC_INSTANCE", ParentSourceID: "PUBLIC_PARENT", ProjectSourceID: "PUBLIC_PROJECT", DeviceSourceID: "PUBLIC_DEVICE", ProjectSubject: p.Account, ProjectBinding: objectHash(p), DeviceSubject: p.Account, DeviceBinding: expected.RegistrationDigest, TargetOrigin: "https://public-cloud.example", ServerName: "public-cloud.example", SPKI: hex.EncodeToString(spki[:]), CertificateSHA256: tlsIdentity.CertificateSHA256, TLSSourceID: tlsIdentity.SourceID, TLSInstanceID: tlsIdentity.InstanceID, TLSCredentialEpoch: strconv.FormatUint(tlsIdentity.CredentialEpoch, 10), TLSRuntimeVersion: tlsIdentity.RuntimeVersion, CatalogProjectID: "PUBLIC-project", ResourceApprovalRef: "PUBLIC-resource-approval", Cloud: finiteFullRef{"PUBLIC-realm", "PUBLIC-tenant", "cloud", "PUBLIC-cloud", "9007199254740993"}, RequiredScopes: []string{"project.read"}, Selectors: []string{"deployment", "logs", "runtime", "usage", "usage.records", "billing", "billing.native-intent"}}
	cap := finiteTargetCap{Version: 1, ParentSourceID: row.ParentSourceID, ProjectSourceID: row.ProjectSourceID, DeviceSourceID: row.DeviceSourceID, Account: p.Account, DeviceID: p.DeviceID, SessionBinding: expected.SessionBinding, RegistrationDigest: expected.RegistrationDigest, CatalogProjectID: row.CatalogProjectID, Cloud: row.Cloud, ResourceApprovalRef: row.ResourceApprovalRef, TargetOrigin: row.TargetOrigin, ServerName: row.ServerName, Port: 443, SPKI: row.SPKI, ProductOrigin: expected.Origin, RequiredScopes: row.RequiredScopes, Selectors: row.Selectors, PublicCredentialRef: "PUBLIC-credential", LocalSAN: "PUBLIC-ide-client", PeerSAN: row.ServerName, RootCertSHA: strings.Repeat("a", 64), ClientCertSHA: strings.Repeat("b", 64), NotBefore: time.Now().Add(-time.Second).UnixMilli(), Expires: until, RootEpoch: "7", RootUntil: until, CredentialEpoch: "9", CredentialUntil: until}
	principal := map[string]any{"account": p.Account, "deviceId": p.DeviceID, "sessionRef": p.SessionRef, "currentRef": p.CurrentRef, "accountGeneration": p.AccountGeneration, "sessionGeneration": p.SessionGeneration, "expiresMS": p.ExpiresMS}
	projectSelection := map[string]any{"projectAuthority": map[string]any{"principal": principal, "project": map[string]any{"projectId": row.CatalogProjectID, "read": true, "expiresMS": until}}, "ideFiniteGETTargetV1": cap}
	deviceSelection := map[string]any{"productSessionDeviceV4": finiteDeviceScope{Version: "4", Expected: expected, Context: json.RawMessage(`{}`), Registration: registration, Session: session}}
	put := func(kind, subject, binding, sourceID string, selection any) string {
		profile := r5JSON(t, map[string]any{"selection": selection, "sourceId": sourceID, "expires": until})
		raw := r5JSON(t, originalIDESourceInput{Root: "PUBLIC-ROOT", Enrollment: "PUBLIC-ENROLLMENT", Profile: string(profile), Head: "PUBLIC-HEAD", Attachment: json.RawMessage(`{}`)})
		state.source.records[kind+"/"+subject+"/"+binding] = raw
		state.source.heads[hash(profile)] = []byte(`{"sequence":1,"floor":0,"head":"` + strings.Repeat("1", 64) + `","timeFloor":0,"executionHeight":"0"}`)
		return string(profile)
	}
	profileProject := put("project", row.ProjectSubject, row.ProjectBinding, row.ProjectSourceID, projectSelection)
	profileDevice := put("device-v4", row.DeviceSubject, row.DeviceBinding, row.DeviceSourceID, deviceSelection)
	ownedRoot := os.Getenv("YNX_IDE_TEST_OWNED_ROOT")
	if e := verifierDirectory(ownedRoot); e != nil {
		t.Fatal("explicit protected test artifact root required", e)
	}
	releaseDir, e := os.MkdirTemp(ownedRoot, "PUBLIC-r5-receiver-release-")
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() { os.RemoveAll(releaseDir) })
	releasePath := filepath.Join(releaseDir, "release.public")
	if e = os.WriteFile(releasePath, []byte("PUBLIC independent release seam, not Root approval"), 0600); e != nil {
		t.Fatal(e)
	}
	held, e := verifierOpen(fixturePin(t, releasePath))
	if e != nil {
		t.Fatal(e)
	}
	template := func(id, purpose string) originalIDETemplate {
		return originalIDETemplate{SourceID: id, InstanceID: "PUBLIC_INSTANCE", Policy: r5JSON(t, map[string]any{"signatureContract": map[string]string{"purpose": purpose}}), Node: json.RawMessage(`{}`)}
	}
	o := &OriginalIDEPublicationSourceOwner{db: db, release: held, config: originalIDERelease{Version: "YNX-IDE-PUBLICATION-SOURCE/v3", SourceID: row.SourceID, InstanceID: row.InstanceID, Templates: map[string]originalIDETemplate{"project": template(row.ProjectSourceID, "ide-project-authority-v1"), "device-v4": template(row.DeviceSourceID, "product-session-device-source-v4")}}, principal: &OriginalDeveloperHTTPAuthority{transport: &http.Transport{}}, verifier: verifier}
	t.Cleanup(func() { o.Close() })
	partial, zeroErr := OpenOriginalIDEFiniteGETPrincipalSource(ctx, o, actualTLS)
	if partial == nil || zeroErr != ErrFiniteGETNotSupplied || o.finiteGET != nil {
		t.Fatal("Root empty normal constructor did not fail closed", zeroErr)
	}
	partial.Close()
	supplier, e := openOriginalIDEFiniteGETPrincipalSource(ctx, o, actualTLS, []finiteReceiverRelease{row})
	if e != nil {
		t.Fatal("PUBLIC boundary supplier", e)
	}
	requestLoan := publicTLS.BeginOriginalGET(t, header)
	return &r5Fixture{o: o, s: supplier, state: state, row: row, tls: actualTLS, transport: publicTLS, requestLoan: requestLoan, p: p, request: requestLoan.OriginalRequest(), profileProject: profileProject, profileDevice: profileDevice}
}
func r5FreshProof(t *testing.T) (string, finiteDeviceExpected, string, string) {
	t.Helper()
	key, pub, e := batch.KeyGen()
	if e != nil {
		t.Fatal(e)
	}
	defer key.Destroy()
	raw, e := os.ReadFile(os.Getenv("YNX_PUBLIC_R5_VECTOR"))
	if e != nil {
		t.Fatal(e)
	}
	var vector struct{ DeviceUnsigned map[string]any }
	json.Unmarshal(raw, &vector)
	u := vector.DeviceUnsigned
	now := time.Now().UTC().Truncate(time.Millisecond)
	end := now.Add(28 * time.Second)
	expiry := now.Add(2 * time.Minute).Format("2006-01-02T15:04:05.000Z")
	network := strings.Repeat("3", 64)
	reg := map[string]any{"version": "4", "registrationId": u["deviceRegistrationId"], "networkId": network, "canonicalOwner": u["canonicalOwner"], "productId": u["productId"], "clientId": u["clientId"], "platform": "macos", "applicationId": u["applicationId"], "bundleId": u["bundleId"], "packageId": nil, "origin": u["origin"], "callback": u["callback"], "deviceId": u["deviceId"], "generation": "11", "revision": u["deviceRegistrationRevision"], "pkA": hex.EncodeToString(pub.PKA), "pkB": hex.EncodeToString(pub.PKB), "registeredAt": now.Add(-time.Hour).Format("2006-01-02T15:04:05.000Z"), "expiresAt": expiry, "revokedAt": nil}
	regRaw := string(r5JSON(t, reg))
	u["deviceRegistrationDigest"] = hash([]byte(regRaw))
	u["issuedAt"] = now.Format("2006-01-02T15:04:05.000Z")
	u["expiresAt"] = end.Format("2006-01-02T15:04:05.000Z")
	u["nonce"] = base64.RawURLEncoding.EncodeToString(bytes.Repeat([]byte{7}, 32))
	unsigned := r5JSON(t, u)
	n, _ := hex.DecodeString(network)
	binding := batch.ProductSessionHTTPBinding{NetworkID: n, Owner: u["canonicalOwner"].(string), PKA: pub.PKA, PKB: pub.PKB}
	message, e := batch.BuildProductSessionHTTPMessage(unsigned, binding)
	if e != nil {
		t.Fatal(e)
	}
	signed, e := batch.BatchSign(key, batch.Metadata{ChainID: n, Owner: binding.Owner, Purpose: batch.ProductSessionHTTPPurpose}, [][]byte{message}, batch.SignOptions{Optimized: true})
	if e != nil {
		t.Fatal(e)
	}
	defer signed.Discard()
	m, e := batch.Extract(signed, 0)
	if e != nil {
		t.Fatal(e)
	}
	member, e := batch.EncodeMember(m)
	if e != nil {
		t.Fatal(e)
	}
	packet := map[string]any{}
	for k, v := range u {
		packet[k] = v
	}
	packet["member"] = base64.RawURLEncoding.EncodeToString(member)
	header := base64.RawURLEncoding.EncodeToString(r5JSON(t, packet))
	bundle := u["bundleId"].(string)
	expected := finiteDeviceExpected{network, binding.Owner, u["account"].(string), u["sessionBinding"].(string), u["productId"].(string), u["clientId"].(string), "macos", u["applicationId"].(string), &bundle, nil, u["origin"].(string), u["callback"].(string), u["deviceId"].(string), "11", u["deviceRegistrationId"].(string), u["deviceRegistrationRevision"].(string), u["deviceRegistrationDigest"].(string)}
	session := string(r5JSON(t, map[string]any{"sessionBinding": expected.SessionBinding, "scopes": []string{"project.read"}, "expiresAt": expiry}))
	return header, expected, regRaw, session
}
func TestR5FiniteGETPrincipalFactory(t *testing.T) {
	header, expected, reg, session := r5FreshProof(t)
	f := r5FixtureOpen(t, header, expected, reg, session)
	ctx := f.request.Context()
	p, e := f.o.CurrentExistingPrincipal(ctx, f.request)
	if e != nil || p != f.p {
		t.Fatal("actual normal principal", e, p)
	}
	if p.SessionRef == expected.SessionBinding || p.AccountGeneration == 11 || p.SessionGeneration == 11 {
		t.Fatal("Root principal refs/generations confused with DEVICE")
	}
	if _, e = f.o.CurrentExistingPrincipal(ctx, f.request); e != nil {
		t.Fatal("same request reborrow", e)
	}
	if _, e = f.o.borrowOriginalDeploymentV2Principal(ctx, f.request); e != nil {
		t.Fatal("normal Deployment principal reborrow", e)
	}
	if e = f.o.AssertPrincipalCurrent(ctx, p); e != nil {
		t.Fatal(e)
	}
	if f.state.calls != 1 {
		t.Fatal("nonce consumed twice", f.state.calls)
	}
	clone := f.request.Clone(ctx)
	if _, e = f.o.CurrentExistingPrincipal(ctx, clone); e == nil {
		t.Fatal("clone replay")
	}
	if len(f.state.nonces) != 1 {
		t.Fatal("second nonce row")
	}
	saved := f.state.source.records["device-v4/"+f.row.DeviceSubject+"/"+f.row.DeviceBinding]
	delete(f.state.source.records, "device-v4/"+f.row.DeviceSubject+"/"+f.row.DeviceBinding)
	if _, e = f.o.CurrentExistingPrincipal(ctx, f.request); e == nil {
		t.Fatal("revoked Source reborrow")
	}
	f.state.source.records["device-v4/"+f.row.DeviceSubject+"/"+f.row.DeviceBinding] = saved
	if _, e = f.o.CurrentExistingPrincipal(ctx, f.request); e == nil {
		t.Fatal("retired same original revived")
	}
	if f.state.calls != 2 {
		t.Fatal("unexpected replay", f.state.calls)
	}
	if err := f.requestLoan.Close(); err != nil {
		t.Fatal("main original response/client physical drain", err)
	}
	// The main fixture's revoke/UNKNOWN assertions above finish before fresh
	// field tests, so their work cannot expire its original short proof window.
	for _, kind := range []string{"otherHost", "query", "rawAlias", "contextSwap", "headerChanged"} {
		t.Run(kind, func(t *testing.T) {
			header, expected, registration, session := r5FreshProof(t)
			isolated := r5FixtureOpen(t, header, expected, registration, session)
			original := isolated.request
			request := original
			ctx := original.Context()
			host, target, originalURL, headers := original.Host, original.RequestURI, *original.URL, original.Header.Clone()
			restore := func() {
				original.Host, original.RequestURI = host, target
				*original.URL = originalURL
				original.Header = headers
			}
			defer restore()
			switch kind {
			case "otherHost":
				original.Host = "other-cloud.example"
			case "query":
				original.URL.RawQuery = "tenant=foreign"
				original.RequestURI += "?tenant=foreign"
			case "rawAlias":
				original.URL.RawPath = original.URL.Path + "%2f"
			case "contextSwap":
				foreign, cancel := context.WithCancel(ctx)
				defer cancel()
				ctx = foreign
				// Prove the context argument fence independently of Clone branding.
				if _, err := isolated.o.CurrentExistingPrincipal(foreign, original); err == nil {
					t.Fatal("foreign context borrowed the SAME original request")
				}
				request = original.Clone(foreign)
			case "headerChanged":
				original.Header = original.Header.Clone()
				original.Header["X-Ynx-Product-Session-Proof-V4"] = []string{header + "A"}
			}
			if isolated.state.calls != 0 || len(isolated.state.nonces) != 0 {
				t.Fatal("fresh field fixture already consumed a nonce")
			}
			if _, err := isolated.o.CurrentExistingPrincipal(ctx, request); err == nil {
				t.Fatal("accepted invalid original request field/context")
			}
			if isolated.state.calls != 0 || len(isolated.state.nonces) != 0 {
				t.Fatal("invalid request reached nonce consumption")
			}
			restore()
			attempt := isolated.s.records[original]
			if kind == "contextSwap" {
				// A foreign argument/clone must not retire the genuine original
				// request, which has not entered its own child or nonce attempt.
				if attempt != nil || isolated.s.requestChildren[original] != nil {
					t.Fatal("foreign context selected the genuine original child")
				}
				p, err := isolated.o.CurrentExistingPrincipal(original.Context(), original)
				if err != nil || p != isolated.p || isolated.state.calls != 1 || len(isolated.state.nonces) != 1 {
					t.Fatal("genuine original after foreign context did not verify once", err, isolated.state.calls)
				}
				if _, err = isolated.o.CurrentExistingPrincipal(original.Context(), original); err != nil || isolated.state.calls != 1 || len(isolated.state.nonces) != 1 {
					t.Fatal("genuine original reborrow consumed again", err, isolated.state.calls)
				}
				return
			}
			// R13 acquires this exact child before LINK/capture. Any failed
			// observation retains its first cause even when SQL was not entered.
			child := isolated.s.requestChildren[original]
			if child == nil || child.first == nil || child.active != 0 {
				t.Fatal("failed SAME-original observation lost its child/first cause")
			}
			first := child.first
			var attemptFirst error
			var attemptPhase string
			if kind == "headerChanged" {
				if attempt == nil || attempt.first == nil || attempt.phase != "failed" || attempt.nonce != nil {
					t.Fatal("bad original header lost its pre-SQL failed Auth attempt")
				}
				attemptFirst, attemptPhase = attempt.first, attempt.phase
			} else if attempt != nil {
				t.Fatal("transport/capture rejection selected an Auth nonce attempt")
			}
			if _, err := isolated.o.CurrentExistingPrincipal(original.Context(), original); err == nil {
				t.Fatal("restored DATA revived the failed SAME-original child")
			}
			if isolated.s.requestChildren[original] != child || child.first != first || child.active != 0 || isolated.s.records[original] != attempt || isolated.state.calls != 0 || len(isolated.state.nonces) != 0 {
				t.Fatal("failed child/attempt changed or retried SQL")
			}
			if attempt != nil && (attempt.first != attemptFirst || attempt.phase != attemptPhase || attempt.nonce != nil) {
				t.Fatal("failed Auth attempt lost its original cause/phase")
			}
			if closed, err := isolated.o.ReleaseOriginalFiniteGETRequest(original.Context(), original); !closed || err != first || !child.retired || !child.closed {
				t.Fatal("same failed child did not physically drain with original cause", closed, err)
			}
			if closed, err := isolated.o.ReleaseOriginalFiniteGETRequest(original.Context(), original); !closed || err != first || isolated.state.calls != 0 || len(isolated.state.nonces) != 0 {
				t.Fatal("same-child cleanup retried nonce or erased first cause", closed, err)
			}
		})
	}
}
func TestR5FiniteGETUnknownAndLate(t *testing.T) {
	header, expected, reg, session := r5FreshProof(t)
	for _, kind := range []string{"unknownSQL", "lateRevoke"} {
		t.Run(kind, func(t *testing.T) {
			f := r5FixtureOpen(t, header, expected, reg, session)
			f.state.unknown = kind == "unknownSQL"
			if kind == "lateRevoke" {
				f.state.late = func() { delete(f.state.source.records, "device-v4/"+f.row.DeviceSubject+"/"+f.row.DeviceBinding) }
			}
			if _, e := f.o.CurrentExistingPrincipal(f.request.Context(), f.request); e == nil {
				t.Fatal("late/unknown returned principal")
			}
			a := f.s.records[f.request]
			if a == nil || a.nonce == nil || !a.nonce.entered || len(f.state.nonces) != 1 {
				t.Fatal("original SQL partial lost")
			}
			f.state.unknown = false
			if _, e := f.o.CurrentExistingPrincipal(f.request.Context(), f.request); e == nil {
				t.Fatal("UNKNOWN retried")
			}
			if f.state.calls != 1 {
				t.Fatal("SQL retried")
			}
			f.s.Retire()
			if !f.s.Join() {
				t.Fatal("actual synchronous drain")
			}
			f.s.Close()
			if f.o.closeSelected {
				t.Fatal("child closed Source parent")
			}
		})
	}
}
func TestR5ObservationAndV3(t *testing.T) {
	header, expected, reg, session := r5FreshProof(t)
	f := r5FixtureOpen(t, header, expected, reg, session)
	f.state.unknown = true
	if _, e := f.o.CurrentExistingPrincipal(f.request.Context(), f.request); e == nil {
		t.Fatal("unknown principal")
	}
	originalCause := f.s.records[f.request].first
	observed, e := f.s.ObserveOriginalRequest(f.request.Context(), f.request)
	if e != nil || !observed.DataOnly || observed.ExecutionID == "" || observed.Phase != "failed" {
		t.Fatal("original readonly observation", e, observed)
	}
	if f.s.records[f.request].first != originalCause || f.state.calls != 1 {
		t.Fatal("observation changed first cause or consumed again")
	}
	f.state.unknown = false
	if _, e = f.o.CurrentExistingPrincipal(f.request.Context(), f.request); e == nil {
		t.Fatal("observed UNKNOWN became authority")
	}
	clone := f.request.Clone(f.request.Context())
	if _, e = f.s.ObserveOriginalRequest(clone.Context(), clone); e == nil {
		t.Fatal("foreign request queried original slot")
	}
	// New config is opt-in only; legacy exact template counts remain unchanged.
	config := originalIDERelease{Version: "YNX-IDE-PUBLICATION-SOURCE/v3", SourceID: "PUBLIC", InstanceID: "PUBLIC", CallerIdentity: "PUBLIC", PrincipalSPKI: strings.Repeat("1", 64), CatalogBinding: strings.Repeat("2", 64), Templates: map[string]originalIDETemplate{}}
	for k, purpose := range map[string]string{"catalog": "ide-project-authority-v1", "project": "ide-project-authority-v1", "control": "ide-project-control-authority-v1", "artifact": "ide-publication-approval-authority-v1", "resource": "ide-publication-approval-authority-v1", "deployment-v2": DeploymentV2ExecutionSourcePurpose, "deployment-v2-read": DeploymentV2RecoverySourcePurpose, "device-v4": "product-session-device-source-v4"} {
		config.Templates[k] = originalIDETemplate{SourceID: "PUBLIC", InstanceID: "PUBLIC", Policy: r5JSON(t, map[string]any{"signatureContract": map[string]string{"purpose": purpose}}), Node: json.RawMessage(`{}`)}
	}
	if _, e := originalIDEParseRelease(r5JSON(t, config)); e != nil {
		t.Fatal("v3 exact eight", e)
	}
	config.Version = "YNX-IDE-PUBLICATION-SOURCE/v2"
	if _, e := originalIDEParseRelease(r5JSON(t, config)); e == nil {
		t.Fatal("v2 silently gained DEVICE")
	}
	config.Version = "YNX-IDE-PUBLICATION-SOURCE/v3"
	wrong := config.Templates["device-v4"]
	wrong.Policy = r5JSON(t, map[string]any{"signatureContract": map[string]string{"purpose": "product-session-http-proof-source-v5"}})
	config.Templates["device-v4"] = wrong
	if _, e := originalIDEParseRelease(r5JSON(t, config)); e == nil {
		t.Fatal("wrong purpose DEVICE")
	}
	// The original Deployment constructor may accept config v3, but its actual
	// pinned execute verifier/Source requirements are NOT bypassed for reads.
	f.o.config.Templates["deployment-v2"] = originalIDETemplate{SourceID: "PUBLIC-execute"}
	f.o.config.Templates["deployment-v2-read"] = originalIDETemplate{SourceID: "PUBLIC-read"}
	authority, e := OpenOriginalDeploymentV2Authority(context.Background(), &Catalog{source: f.o})
	if authority != nil {
		defer authority.Close()
	}
	if e == nil || authority == nil || authority.approvalVerifier == nil {
		t.Fatal("v3 composition rejected before retained original verifier, or skipped missing execute pin", e)
	}
}
