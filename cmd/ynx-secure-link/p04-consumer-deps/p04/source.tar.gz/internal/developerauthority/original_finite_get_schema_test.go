package developerauthority

// Portable schema controls remain in the default package; native request
// tests require the explicitly selected PUBLIC OpenSSL test fixture.
import (
	"encoding/json"
	"strings"
	"testing"
)

func r5DefaultJSON(t *testing.T, value any) []byte {
	t.Helper()
	raw, err := originalIDEJSON(value)
	if err != nil {
		t.Fatal(err)
	}
	return raw
}
func TestR5DefaultV3ReleaseSchema(t *testing.T) {
	// New config is opt-in only; legacy exact template counts remain unchanged.
	config := originalIDERelease{Version: "YNX-IDE-PUBLICATION-SOURCE/v3", SourceID: "PUBLIC", InstanceID: "PUBLIC", CallerIdentity: "PUBLIC", PrincipalSPKI: strings.Repeat("1", 64), CatalogBinding: strings.Repeat("2", 64), Templates: map[string]originalIDETemplate{}}
	for k, purpose := range map[string]string{"catalog": "ide-project-authority-v1", "project": "ide-project-authority-v1", "control": "ide-project-control-authority-v1", "artifact": "ide-publication-approval-authority-v1", "resource": "ide-publication-approval-authority-v1", "deployment-v2": DeploymentV2ExecutionSourcePurpose, "deployment-v2-read": DeploymentV2RecoverySourcePurpose, "device-v4": "product-session-device-source-v4"} {
		config.Templates[k] = originalIDETemplate{SourceID: "PUBLIC", InstanceID: "PUBLIC", Policy: r5DefaultJSON(t, map[string]any{"signatureContract": map[string]string{"purpose": purpose}}), Node: json.RawMessage(`{}`)}
	}
	if _, e := originalIDEParseRelease(r5DefaultJSON(t, config)); e != nil {
		t.Fatal("v3 exact eight", e)
	}
	config.Version = "YNX-IDE-PUBLICATION-SOURCE/v2"
	if _, e := originalIDEParseRelease(r5DefaultJSON(t, config)); e == nil {
		t.Fatal("v2 silently gained DEVICE")
	}
	config.Version = "YNX-IDE-PUBLICATION-SOURCE/v3"
	wrong := config.Templates["device-v4"]
	wrong.Policy = r5DefaultJSON(t, map[string]any{"signatureContract": map[string]string{"purpose": "product-session-http-proof-source-v5"}})
	config.Templates["device-v4"] = wrong
	if _, e := originalIDEParseRelease(r5DefaultJSON(t, config)); e == nil {
		t.Fatal("wrong purpose DEVICE")
	}
}
