package developerauthority

import "context"

// OpenOriginalDeploymentV2AuthorityForSource is the original normal V2
// constructor with an explicit SAME Source13 owner operand. It does not create
// another controller, Source, Root, pool or approval issuer. In particular the
// owner authenticating/holding the binary request body must be the very owner
// borrowed by the Catalog and the independent execution approval authority.
//
// A nonnil partial from the original constructor is returned unchanged and
// must be adopted before the error. Identity mismatch is rejected before any
// pinner/current/network/approval acquisition; no fallback to old publication.
func OpenOriginalDeploymentV2AuthorityForSource(ctx context.Context, catalog *Catalog, source *OriginalIDEPublicationSourceOwner) (*DeploymentV2Authority, error) {
	if ctx == nil || ctx.Err() != nil || catalog == nil || source == nil {
		return nil, ErrDenied
	}
	actual, ok := catalog.source.(*OriginalIDEPublicationSourceOwner)
	if !ok || actual != source {
		return nil, ErrDenied
	}
	return OpenOriginalDeploymentV2Authority(ctx, catalog)
}
