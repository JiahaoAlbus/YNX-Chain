package developerauthority

import (
	"context"
	"net/http"
)

// Owns only an in-process borrow of this exact incoming request. This is not
// another Principal, listener, nonce consume, Source or TLS credential owner.
// All fields are protected by the existing publication Source mutex.
type finiteGETRequestChildState struct {
	request         *http.Request
	context         context.Context
	active          uint64
	retired, closed bool
	first           error
}

func (s *OriginalIDEFiniteGETPrincipalSource) requestChildLocked(ctx context.Context, r *http.Request, create bool) (*finiteGETRequestChildState, error) {
	if s == nil || s.source == nil || r == nil || !sameFiniteContext(ctx, r.Context()) {
		return nil, ErrDenied
	}
	c := s.requestChildren[r]
	if c == nil && create {
		for _, releasedContext := range s.releasedRequests {
			if sameFiniteContext(releasedContext, ctx) {
				return nil, ErrDenied
			}
		}
		if s.requestChildren == nil {
			s.requestChildren = make(map[*http.Request]*finiteGETRequestChildState)
		}
		c = &finiteGETRequestChildState{request: r, context: ctx}
		s.requestChildren[r] = c
	}
	if c == nil || c.request != r || !sameFiniteContext(c.context, ctx) {
		return nil, ErrDenied
	}
	return c, nil
}

func (s *OriginalIDEFiniteGETPrincipalSource) beginOriginalRequest(ctx context.Context, r *http.Request) (*finiteGETRequestChildState, error) {
	if s == nil || s.source == nil {
		return nil, ErrDenied
	}
	s.source.mu.Lock()
	defer s.source.mu.Unlock()
	if s.retired || s.closed || s.first != nil || ctx == nil || ctx.Err() != nil {
		return nil, ErrDenied
	}
	c, e := s.requestChildLocked(ctx, r, true)
	if e != nil {
		return nil, e
	}
	if c.retired || c.closed || c.first != nil || c.active == ^uint64(0) {
		return nil, ErrDenied
	}
	c.active++
	return c, nil
}

func (s *OriginalIDEFiniteGETPrincipalSource) endOriginalRequest(c *finiteGETRequestChildState, result error) {
	s.source.mu.Lock()
	defer s.source.mu.Unlock()
	if c == nil || s.requestChildren[c.request] != c || c.active == 0 {
		return
	}
	c.active--
	if result != nil && c.first == nil {
		c.first = result
	}
}

// A panic remains the original panic, not a success/cleanup instruction. The
// already selected attempt/nonce stays retained with an UNKNOWN child cause.
func (s *OriginalIDEFiniteGETPrincipalSource) finishOriginalRequest(c *finiteGETRequestChildState, result *error) {
	if original := recover(); original != nil {
		s.endOriginalRequest(c, ErrUnknown)
		panic(original)
	}
	s.endOriginalRequest(c, *result)
}

// Cleanup matches identity, not freshness: a canceled original request is
// still allowed to discharge its own borrow. A foreign ctx/request cannot.
func (s *OriginalIDEFiniteGETPrincipalSource) RetireOriginalRequest(ctx context.Context, r *http.Request) error {
	if s == nil || s.source == nil {
		return ErrDenied
	}
	s.source.mu.Lock()
	defer s.source.mu.Unlock()
	c, e := s.requestChildLocked(ctx, r, false)
	if e != nil {
		return e
	}
	c.retired = true
	return finiteRequestChildFirst(c, s.records[r])
}

func finiteRequestChildFirst(c *finiteGETRequestChildState, a *finitePrincipalAttempt) error {
	// The selected authentication attempt already owns its first cause; a
	// concurrent reborrow's ErrUnknown must not replace that durable lineage.
	if a != nil && a.first != nil {
		return a.first
	}
	return c.first
}

// joined/closed are physical completion of this child only, independent of
// first cause. Neither method waits under a lock or closes LINK/Source parents.
func (s *OriginalIDEFiniteGETPrincipalSource) JoinOriginalRequest(ctx context.Context, r *http.Request) (joined bool, first error) {
	if s == nil || s.source == nil {
		return false, ErrDenied
	}
	s.source.mu.Lock()
	defer s.source.mu.Unlock()
	c, e := s.requestChildLocked(ctx, r, false)
	if e != nil {
		return false, e
	}
	return c.retired && c.active == 0, finiteRequestChildFirst(c, s.records[r])
}

func (s *OriginalIDEFiniteGETPrincipalSource) CloseOriginalRequest(ctx context.Context, r *http.Request) (closed bool, first error) {
	if s == nil || s.source == nil {
		return false, ErrDenied
	}
	s.source.mu.Lock()
	defer s.source.mu.Unlock()
	c, e := s.requestChildLocked(ctx, r, false)
	if e != nil {
		return false, e
	}
	if !c.retired || c.active != 0 {
		return false, finiteRequestChildFirst(c, s.records[r])
	}
	c.closed = true
	// Preserve the attempt, nonce and context tombstones. They cannot be
	// authenticated again, even after cancellation, a late error or UNKNOWN.
	return true, finiteRequestChildFirst(c, s.records[r])
}

// Handler defer entry. false means keep SAME Source/request child reachable
// and drain after its already entered observations settle; never reauthenticate.
func (s *OriginalIDEFiniteGETPrincipalSource) ReleaseOriginalRequest(ctx context.Context, r *http.Request) (closed bool, first error) {
	if s == nil || s.source == nil || r == nil || !sameFiniteContext(ctx, r.Context()) {
		return false, ErrDenied
	}
	s.source.mu.Lock()
	if s.requestChildren[r] == nil && s.records[r] == nil {
		// A handler can fail before Auth selects any child at all. There is
		// nothing physical to retire; never manufacture a cleanup child.
		foreign := s.requestContexts[ctx] != nil
		for original, releasedContext := range s.releasedRequests {
			if original != r && sameFiniteContext(releasedContext, ctx) {
				foreign = true
				break
			}
		}
		for _, c := range s.requestChildren {
			if sameFiniteContext(c.context, ctx) {
				foreign = true
				break
			}
		}
		if foreign {
			s.source.mu.Unlock()
			return false, ErrDenied
		}
		if s.releasedRequests == nil {
			s.releasedRequests = make(map[*http.Request]context.Context)
		}
		s.releasedRequests[r] = ctx // denial-only tombstone, not a request child/nonce
		s.source.mu.Unlock()
		return true, nil
	}
	s.source.mu.Unlock()
	e := s.RetireOriginalRequest(ctx, r)
	done, last := s.CloseOriginalRequest(ctx, r)
	if e != nil {
		return done, e
	}
	return done, last
}

// Normal Cloud adapter entry on the already retained publication Source.
// It never opens another Source or consumes/re-verifies another nonce.
func (o *OriginalIDEPublicationSourceOwner) ReleaseOriginalFiniteGETRequest(ctx context.Context, r *http.Request) (closed bool, first error) {
	if o == nil || r == nil || !sameFiniteContext(ctx, r.Context()) {
		return false, ErrDenied
	}
	o.mu.Lock()
	s := o.finiteGET
	o.mu.Unlock()
	if s == nil {
		return true, nil // no selected finite Source or request child; cleanup only
	}
	return s.ReleaseOriginalRequest(ctx, r)
}
