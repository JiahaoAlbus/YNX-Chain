package developerauthority

// Fixed private adaptation of SOLE SDK's V4 header parser, then original Core
// E5/N1 AND. No Source/Principal constructor accepts this mathematical result.
import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	batch "github.com/JiahaoAlbus/YNX-Chain/internal/ynxbatch"
	"time"
)

const originalFiniteGETOriginalsEntry = "native/original-ide-finite-get-receiver-originals.mjs"

type originalFiniteGETOriginals struct{ unsigned, member []byte }

func decodeOriginalFiniteGETOriginals(raw []byte) (originalFiniteGETOriginals, error) {
	var version, unsigned, member string
	var data, authorized bool
	if !bytes.HasSuffix(raw, []byte("\n")) || decodeExactObject(bytes.TrimSuffix(raw, []byte("\n")), 262144, map[string]any{"version": &version, "unsignedOriginal": &unsigned, "memberOriginal": &member, "dataOnly": &data, "authorized": &authorized}) != nil || version != "IDE-FINITE-GET-V4-ORIGINALS-DATA/v1" || !data || authorized {
		return originalFiniteGETOriginals{}, ErrDenied
	}
	u, e := base64.RawURLEncoding.Strict().DecodeString(unsigned)
	if e != nil || len(u) == 0 || len(u) > 16384 || base64.RawURLEncoding.EncodeToString(u) != unsigned {
		return originalFiniteGETOriginals{}, ErrDenied
	}
	m, e := base64.RawURLEncoding.Strict().DecodeString(member)
	if e != nil || len(m) == 0 || len(m) > 98304 || base64.RawURLEncoding.EncodeToString(m) != member {
		return originalFiniteGETOriginals{}, ErrDenied
	}
	return originalFiniteGETOriginals{bytes.Clone(u), bytes.Clone(m)}, nil
}
func checkOriginalFiniteGETOriginals(raw []byte, _ time.Time) string {
	if _, e := decodeOriginalFiniteGETOriginals(raw); e != nil {
		return "FINITE_GET_ORIGINALS_OUTPUT"
	}
	return ""
}

// This unexported method is available only to the owning normal supplier. The
// expected full pair MUST come from independently current registered DEVICE
// Source originals, never from header claims. The result remains public DATA.
func (o *OriginalSourceVerifierOwner) inspectOriginalFiniteGETV4(ctx context.Context, header string, expected batch.ProductSessionHTTPBinding) (batch.ProductSessionHTTPMessage, error) {
	var zero batch.ProductSessionHTTPMessage
	expected = batch.ProductSessionHTTPBinding{NetworkID: bytes.Clone(expected.NetworkID), Owner: expected.Owner, PKA: bytes.Clone(expected.PKA), PKB: bytes.Clone(expected.PKB)}
	if ctx == nil || ctx.Err() != nil || len(header) == 0 || len(header) > 196608 {
		return zero, ErrDenied
	}
	for _, c := range []byte(header) {
		if !(c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '_' || c == '-') {
			return zero, ErrDenied
		}
	}
	input, e := json.Marshal(map[string]string{"operation": "ide-finite-get-v4-originals-data/v1", "header": header})
	if e != nil {
		return zero, e
	}
	raw, e := o.invokePinnedOriginalDATA(ctx, input, 262144, false, checkOriginalFiniteGETOriginals, originalFiniteGETOriginalsEntry)
	if e != nil {
		return zero, e
	}
	originals, e := decodeOriginalFiniteGETOriginals(raw)
	if e != nil {
		return zero, e
	}
	result, e := batch.InspectProductSessionHTTPMember(originals.member, expected, originals.unsigned)
	if e != nil {
		return result, e
	}
	if e = ctx.Err(); e != nil {
		return result, e
	}
	return result, nil
}
