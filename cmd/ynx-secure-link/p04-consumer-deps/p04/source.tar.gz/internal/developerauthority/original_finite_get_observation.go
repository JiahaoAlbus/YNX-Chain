package developerauthority

import (
	"context"
	"net/http"
)

// Private-process DATA only. Observing the exact durable nonce does not
// resolve an UNKNOWN request into a Principal, replay HTTP, or reset once.
type OriginalFiniteGETReadObservation struct {
	Phase, ExecutionID, ProofSHA256, RequestSHA256, PrincipalSHA256 string
	IssuedMS, ExpiresMS, ConsumedMS                                 int64
	DataOnly                                                        bool
}

const originalFiniteGETNonceObserveSQL = `SELECT execution_id,proof_sha256,request_sha256,principal_sha256,issued_ms,expires_ms,consumed_ms FROM public.auth_ide_http_read_nonces WHERE source_id=$1 AND instance_id=$2 AND nonce=$3 AND execution_id=$4`

// The exact original in-process request/owner is required; no ref/JSON lookup
// or new authentication occurs. Cleanup/query context may outlive the expired
// request, but this method never returns authority or private proof bytes.
func (s *OriginalIDEFiniteGETPrincipalSource) ObserveOriginalRequest(ctx context.Context, r *http.Request) (OriginalFiniteGETReadObservation, error) {
	var result OriginalFiniteGETReadObservation
	if s == nil || s.source == nil || ctx == nil || ctx.Err() != nil || r == nil {
		return result, ErrDenied
	}
	s.source.mu.Lock()
	defer s.source.mu.Unlock()
	a := s.records[r]
	if a == nil || a.nonce == nil || !a.nonce.entered || a.nonce.execution == "" || s.source.db == nil {
		return result, ErrDenied
	}
	c := a.nonce.claim
	result.Phase = a.phase
	result.DataOnly = true
	e := s.source.db.QueryRowContext(ctx, originalFiniteGETNonceObserveSQL, c.sourceID, c.instanceID, c.nonce, a.nonce.execution).Scan(&result.ExecutionID, &result.ProofSHA256, &result.RequestSHA256, &result.PrincipalSHA256, &result.IssuedMS, &result.ExpiresMS, &result.ConsumedMS)
	// Return actual partial DATA before late context/status, with no state reset.
	if e != nil {
		return result, e
	}
	if e = ctx.Err(); e != nil {
		return result, e
	}
	if result.ExecutionID != a.nonce.execution || result.ProofSHA256 != c.proofSHA256 || result.RequestSHA256 != c.requestSHA256 || result.PrincipalSHA256 != c.principalSHA256 || result.IssuedMS != c.issuedMS || result.ExpiresMS != c.expiresMS || result.ConsumedMS < c.issuedMS || result.ConsumedMS >= c.expiresMS {
		return result, ErrUnknown
	}
	return result, nil
}
