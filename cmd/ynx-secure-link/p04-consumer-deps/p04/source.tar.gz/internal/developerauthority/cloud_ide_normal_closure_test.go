package developerauthority

// These NEW composition controls do not mint a Source. Empty/invalid private
// structural owners below are PUBLIC identity/lifetime seams only. Normal
// successful Source/PS/Root/E11/approval authority is not supplied here.
import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strings"
	"testing"
)

func TestCloudIDENormalSameOwnerBoundary(t *testing.T) {
	a, b := &OriginalIDEPublicationSourceOwner{}, &OriginalIDEPublicationSourceOwner{}
	c := &Catalog{source: a}
	for name, test := range map[string]struct {
		ctx     context.Context
		catalog *Catalog
		source  *OriginalIDEPublicationSourceOwner
	}{"different-original-source": {context.Background(), c, b}, "nil-source": {context.Background(), c, nil}, "nil-catalog": {context.Background(), nil, a}, "nil-context": {nil, c, a}, "nil-concrete-catalog-source": {context.Background(), &Catalog{source: (*OriginalIDEPublicationSourceOwner)(nil)}, a}} {
		t.Run(name, func(t *testing.T) {
			owner, e := OpenOriginalDeploymentV2AuthorityForSource(test.ctx, test.catalog, test.source)
			if owner != nil || !errors.Is(e, ErrDenied) {
				t.Fatal("foreign/absent same owner was accepted", e)
			}
		})
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if owner, e := OpenOriginalDeploymentV2AuthorityForSource(ctx, c, a); owner != nil || !errors.Is(e, ErrDenied) {
		t.Fatal("cancel bypass", e)
	}
}

func TestCloudIDENormalOriginalPartialPreserved(t *testing.T) {
	source := &OriginalIDEPublicationSourceOwner{}
	owner, e := OpenOriginalDeploymentV2AuthorityForSource(context.Background(), &Catalog{source: source}, source)
	if owner == nil || !errors.Is(e, ErrDenied) || owner.source != source || owner.catalog.source != source {
		t.Fatal("lost original errored partial", e)
	}
	if owner.approvalVerifier != nil || len(owner.permits) != 0 || len(owner.approvals) != 0 {
		t.Fatal("missing v2 config acquired children")
	}
	_ = owner.Close()
	if source.closeSelected || source.first != nil {
		t.Fatal("V2 failure poisoned borrowed old Source")
	}
}

func closureRelease(t *testing.T) originalIDERelease {
	t.Helper()
	templates := map[string]originalIDETemplate{}
	for kind, purpose := range map[string]string{"catalog": "ide-project-authority-v1", "project": "ide-project-authority-v1", "control": "ide-project-control-authority-v1", "artifact": "ide-publication-approval-authority-v1", "resource": "ide-publication-approval-authority-v1", "deployment-v2": DeploymentV2ExecutionSourcePurpose, "deployment-v2-read": DeploymentV2RecoverySourcePurpose} {
		policy, e := json.Marshal(map[string]any{"signatureContract": map[string]string{"purpose": purpose}})
		if e != nil {
			t.Fatal(e)
		}
		templates[kind] = originalIDETemplate{SourceID: "PUBLIC-" + kind, InstanceID: "PUBLIC-instance-" + kind, Policy: policy, Node: json.RawMessage(`{"PUBLIC":"not a real node"}`)}
	}
	return originalIDERelease{Version: "YNX-IDE-PUBLICATION-SOURCE/v2", SourceID: "PUBLIC-parent", InstanceID: "PUBLIC-parent-instance", CallerIdentity: "PUBLIC-service-not-admitted", PrincipalSPKI: strings.Repeat("a", 64), CatalogBinding: strings.Repeat("b", 64), Templates: templates}
}
func TestCloudIDENormalDistinctPurposeComposition(t *testing.T) {
	c := closureRelease(t)
	raw, e := originalIDEJSON(c)
	if e != nil {
		t.Fatal(e)
	}
	parsed, e := originalIDEParseRelease(raw)
	if e != nil || len(parsed.Templates) != 7 {
		t.Fatal("actual v2 release parser not composed", e)
	}
	for _, kind := range []string{"deployment-v2", "deployment-v2-read"} {
		for _, purpose := range []string{"ide-deployment-authority-v2", "ide-project-authority-v1", "pay-root-v1", DeploymentV2ExecutionSourcePurpose, DeploymentV2RecoverySourcePurpose} {
			want := DeploymentV2ExecutionSourcePurpose
			if kind == "deployment-v2-read" {
				want = DeploymentV2RecoverySourcePurpose
			}
			if purpose == want {
				continue
			}
			t.Run(kind+"-reject-"+purpose, func(t *testing.T) {
				bad := closureRelease(t)
				v := bad.Templates[kind]
				v.Policy = json.RawMessage(`{"signatureContract":{"purpose":"` + purpose + `"}}`)
				bad.Templates[kind] = v
				b, _ := originalIDEJSON(bad)
				if _, e := originalIDEParseRelease(b); !errors.Is(e, ErrDenied) {
					t.Fatal("purpose promotion", e)
				}
			})
		}
	}
	for _, kind := range []string{"deployment-v2", "deployment-v2-read"} {
		bad := closureRelease(t)
		delete(bad.Templates, kind)
		b, _ := originalIDEJSON(bad)
		if _, e := originalIDEParseRelease(b); !errors.Is(e, ErrDenied) {
			t.Fatal("missing distinct role silently admitted")
		}
	}
}

func TestCloudIDENormalV1Isolation(t *testing.T) {
	c := closureRelease(t)
	c.Version = "YNX-IDE-PUBLICATION-SOURCE/v1"
	delete(c.Templates, "deployment-v2")
	delete(c.Templates, "deployment-v2-read")
	raw, _ := originalIDEJSON(c)
	if _, e := originalIDEParseRelease(raw); e != nil {
		t.Fatal("old catalog release retired", e)
	}
	source := &OriginalIDEPublicationSourceOwner{config: c}
	owner, e := OpenOriginalDeploymentV2AuthorityForSource(context.Background(), &Catalog{source: source}, source)
	if owner == nil || !errors.Is(e, ErrDenied) {
		t.Fatal("old release upgraded to V2", e)
	}
	_ = owner.Close()
	if source.closeSelected {
		t.Fatal("old service closed by unavailable V2")
	}
}

// Compile the real complete call shape, not an installer/interface injection.
// Functions below are deliberately not executed without actual admitted Root.
func cloudIDENormalTypedCall(ctx context.Context, dbSource *OriginalIDEPublicationSourceOwner, catalog *Catalog, request *http.Request, input DeploymentV2ExecutionRequest) error {
	a, e := OpenOriginalDeploymentV2AuthorityForSource(ctx, catalog, dbSource)
	if a != nil {
		defer a.Close()
	}
	if e != nil {
		return e
	}
	body, e := dbSource.BorrowOriginalBinaryHTTPRequestV5(ctx, request)
	if body != nil {
		defer body.Close()
	}
	if e != nil {
		return e
	}
	handoff, e := a.AcquireOriginalDeploymentV2ExecuteApproval(ctx, request, input)
	if handoff != nil {
		defer handoff.Close()
	}
	if e != nil {
		return e
	}
	input.ExecuteApprovalOriginal = handoff.Original()
	permit, e := a.AuthorizeExecutionV2(ctx, request, input)
	if permit != nil {
		defer permit.Close()
	}
	if e != nil {
		return e
	}
	return permit.Recheck(ctx)
}
