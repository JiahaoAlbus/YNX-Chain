package developerauthority

import (
	"context"
	"database/sql"
	"github.com/JiahaoAlbus/YNX-Chain/internal/securelink"
)

// Normal P04 composition entry, not a second Source/DB/provider. Adopt BOTH
// nonnil owners before examining error; receiver cleanup never closes Source.
// The caller calls SAME actualServerTLS.Serve(existingServer); no GoTLS substitute.
// Root0 may keep unrelated health/service paths alive, but finite-seven GET
// stays unavailable and cannot fall back to old V2 authentication.
func OpenOriginalIDEPublicationSourceWithFiniteGET(ctx context.Context, db *sql.DB, config OriginalIDEPublicationSourceConfig, actualServerTLS *securelink.OriginalServerTLS) (*OriginalIDEPublicationSourceOwner, *OriginalIDEFiniteGETPrincipalSource, error) {
	source, e := OpenOriginalIDEPublicationSource(ctx, db, config)
	if e != nil {
		return source, nil, e
	}
	receiver, e := OpenOriginalIDEFiniteGETPrincipalSource(ctx, source, actualServerTLS)
	return source, receiver, e
}
