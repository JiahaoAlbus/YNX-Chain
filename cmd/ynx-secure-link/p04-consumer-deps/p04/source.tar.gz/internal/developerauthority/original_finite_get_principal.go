package developerauthority

// Normal finite-seven GET principal supplier. All public proof parsing stays
// in the SOLE SDK; the original Core performs E5/N1 AND. Independent reviewed
// receiver identity, registered Project/DEVICE Sources, and the SAME existing
// nonce DB are additional mandatory gates. Nothing here accepts a provider.
import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"github.com/JiahaoAlbus/YNX-Chain/internal/securelink"
	batch "github.com/JiahaoAlbus/YNX-Chain/internal/ynxbatch"
	"net/http"
	"net/url"
	"reflect"
	"regexp"
	"strconv"
	"strings"
	"time"
)

var ErrFiniteGETNotSupplied = errors.New("IDE_FINITE_GET_RECEIVER_NOT_SUPPLIED")

type finiteFullRef struct {
	Realm  string `json:"realm"`
	Tenant string `json:"tenant"`
	Kind   string `json:"kind"`
	ID     string `json:"id"`
	Rev    string `json:"rev"`
}

// PRIVATE stable independent Root/A reviewed code selection, not an install
// format or signed domain. No runtime setter/ENV or received-cap self-pinning.
type finiteReceiverRelease struct {
	SourceID, InstanceID, ParentSourceID, ProjectSourceID, DeviceSourceID string
	ProjectSubject, ProjectBinding, DeviceSubject, DeviceBinding          string
	TargetOrigin, ServerName, SPKI, CatalogProjectID, ResourceApprovalRef string
	CertificateSHA256, TLSSourceID, TLSInstanceID, TLSCredentialEpoch     string
	// Exact independent Root/A reviewed runtime text; never filled from
	// observed Identity, a request, local openssl output, or ENV.
	TLSRuntimeVersion         string
	Cloud                     finiteFullRef
	RequiredScopes, Selectors []string
}

func originalFiniteGETReceiverReleases() []finiteReceiverRelease { return nil }

// Concrete LINK identity observation: called ONLY outside Source/Store mutex.
// Private reviewed fields are independent of received V4 cap/header/Host.
type originalLINKReceiverObservation struct {
	identity securelink.ServerTLSIdentity
}

func observeOriginalLINKReceiver(ctx context.Context, actual *securelink.OriginalServerTLS, request *http.Request) (*originalLINKReceiverObservation, error) {
	if ctx == nil || ctx.Err() != nil || actual == nil {
		return nil, ErrDenied
	}
	if request != nil {
		if !sameFiniteContext(ctx, request.Context()) {
			return nil, ErrDenied
		}
		if e := actual.CurrentOriginalRequest(request); e != nil {
			return nil, e
		}
	}
	v, e := actual.Identity(ctx)
	if e != nil {
		return nil, e
	}
	if ctx.Err() != nil {
		return nil, ctx.Err()
	}
	return &originalLINKReceiverObservation{identity: v}, nil
}
func finiteReviewedTLSRuntime(s string) bool {
	const prefix = "OpenSSL 3.6.4 "
	if !strings.HasPrefix(s, prefix) {
		return false
	}
	date := strings.TrimPrefix(s, prefix)
	d, err := time.Parse("2 Jan 2006", date)
	return err == nil && d.Format("2 Jan 2006") == date
}
func matchOriginalLINKReceiver(r finiteReceiverRelease, v securelink.ServerTLSIdentity, now int64) error {
	u, e := url.Parse(r.TargetOrigin)
	if e != nil || u.Scheme != "https" || u.User != nil || u.Path != "" || u.RawQuery != "" || u.ForceQuery || u.Fragment != "" || u.Hostname() != r.ServerName || u.String() != r.TargetOrigin || v.TargetOrigin != r.TargetOrigin || v.ServerName != r.ServerName || v.SourceID != r.TLSSourceID || v.InstanceID != r.TLSInstanceID || r.TLSSourceID == "" || r.TLSInstanceID == "" || !finiteDecimal(r.TLSCredentialEpoch) || strconv.FormatUint(v.CredentialEpoch, 10) != r.TLSCredentialEpoch {
		return ErrDenied
	}
	cert, spki := sha256.Sum256(v.CertificateDER), sha256.Sum256(v.SPKIDER)
	if !finiteReviewedTLSRuntime(r.TLSRuntimeVersion) || len(v.CertificateDER) == 0 || len(v.CertificateDER) > 65536 || len(v.SPKIDER) == 0 || len(v.SPKIDER) > 16384 || !readNonceHex.MatchString(r.CertificateSHA256) || !readNonceHex.MatchString(r.SPKI) || hex.EncodeToString(cert[:]) != r.CertificateSHA256 || hex.EncodeToString(spki[:]) != r.SPKI || v.CertificateSHA256 != r.CertificateSHA256 || v.SPKISHA256 != r.SPKI || now < v.NotBefore.UnixMilli() || now >= v.NotAfter.UnixMilli() || now >= v.CredentialUntil.UnixMilli() || !v.ServerAuth || v.Protocol != "TLSv1.3" || v.Group != securelink.Group || v.Cipher != securelink.Cipher || v.Signature != "mldsa87" || v.RuntimeVersion != r.TLSRuntimeVersion {
		return ErrDenied
	}
	found := false
	for _, name := range v.DNSNames {
		found = found || name == r.ServerName
	}
	if !found {
		return ErrDenied
	}
	return nil
}

// No exported DATA constructor. SAME original listener remains independently
// held by normal startup; receiver cleanup never closes this parent.
type OriginalFiniteGETReceiverIdentity struct {
	source    *OriginalIDEPublicationSourceOwner
	row       finiteReceiverRelease
	actualTLS *securelink.OriginalServerTLS
	observed  *originalLINKReceiverObservation
	expires   int64
	first     error
}

func receiverIdentity(ctx context.Context, source *OriginalIDEPublicationSourceOwner, actual *securelink.OriginalServerTLS, rows []finiteReceiverRelease, observed *originalLINKReceiverObservation) (*OriginalFiniteGETReceiverIdentity, error) {
	out := &OriginalFiniteGETReceiverIdentity{source: source, actualTLS: actual, observed: observed}
	fail := func(e error) (*OriginalFiniteGETReceiverIdentity, error) { out.first = e; return out, e }
	if source == nil || source.check(ctx) != nil || actual == nil || observed == nil {
		return fail(ErrDenied)
	}
	found := false
	for _, r := range rows {
		if r.SourceID == source.config.SourceID && r.InstanceID == source.config.InstanceID {
			if found {
				return fail(ErrDenied)
			}
			out.row = r
			out.row.RequiredScopes = append([]string(nil), r.RequiredScopes...)
			out.row.Selectors = append([]string(nil), r.Selectors...)
			found = true
		}
	}
	if !found {
		return fail(ErrFiniteGETNotSupplied)
	}
	out.expires = min(observed.identity.NotAfter.UnixMilli(), observed.identity.CredentialUntil.UnixMilli())
	if e := out.currentLocked(ctx); e != nil {
		return fail(e)
	}
	return out, nil
}
func (i *OriginalFiniteGETReceiverIdentity) currentLocked(ctx context.Context) error {
	if i == nil || i.first != nil || i.source == nil || i.source.check(ctx) != nil || i.actualTLS == nil || i.observed == nil {
		return ErrDenied
	}
	r := i.row
	if matchOriginalLINKReceiver(r, i.observed.identity, time.Now().UnixMilli()) != nil || r.CatalogProjectID == "" || r.ResourceApprovalRef == "" || r.Cloud.Realm == "" || r.Cloud.Tenant == "" || r.Cloud.Kind == "" || r.Cloud.ID == "" || !finiteDecimal(r.Cloud.Rev) || len(r.RequiredScopes) == 0 || len(r.Selectors) == 0 {
		return ErrDenied
	}
	return nil
}
func (i *OriginalFiniteGETReceiverIdentity) observe(ctx context.Context, r *http.Request) error {
	if i == nil || i.actualTLS == nil {
		return ErrDenied
	}
	v, e := observeOriginalLINKReceiver(ctx, i.actualTLS, r)
	if e != nil {
		return e
	}
	return matchOriginalLINKReceiver(i.row, v.identity, time.Now().UnixMilli())
}
func OpenOriginalIDEFiniteGETReceiverIdentity(ctx context.Context, source *OriginalIDEPublicationSourceOwner, actual *securelink.OriginalServerTLS) (*OriginalFiniteGETReceiverIdentity, error) {
	observation, e := observeOriginalLINKReceiver(ctx, actual, nil)
	if source == nil {
		return nil, ErrDenied
	}
	source.mu.Lock()
	defer source.mu.Unlock()
	if e != nil {
		return &OriginalFiniteGETReceiverIdentity{source: source, actualTLS: actual, first: e}, e
	}
	return receiverIdentity(ctx, source, actual, originalFiniteGETReceiverReleases(), observation)
}
func (i *OriginalFiniteGETReceiverIdentity) Current(ctx context.Context) error {
	if i == nil || i.source == nil {
		return ErrDenied
	}
	if e := i.observe(ctx, nil); e != nil {
		return e
	}
	i.source.mu.Lock()
	e := i.currentLocked(ctx)
	i.source.mu.Unlock()
	if e != nil {
		return e
	}
	return i.observe(ctx, nil)
}

func finiteDecimal(s string) bool {
	n, e := strconv.ParseUint(s, 10, 64)
	return e == nil && n > 0 && strconv.FormatUint(n, 10) == s
}

type finiteHTTPRequest struct{ Path, Host, Header, Operation, Selector string }

var finiteOperation = regexp.MustCompile(`^[A-Za-z0-9_-]{16,128}$`)

func finiteGETRequest(r *http.Request) bool {
	if r == nil {
		return false
	}
	if r.URL != nil && strings.HasPrefix(r.URL.Path, "/api/v1/ide/deployments/") && r.Method == "GET" {
		return true
	}
	for k := range r.Header {
		if strings.EqualFold(k, "x-ynx-product-session-proof-v4") {
			return true
		}
	}
	return false
}
func captureFiniteHTTPRequest(r *http.Request) (finiteHTTPRequest, error) {
	var v finiteHTTPRequest
	if r == nil || r.URL == nil || r.Method != "GET" || r.ContentLength != 0 || r.Body != nil && r.Body != http.NoBody || len(r.TransferEncoding) != 0 || len(r.Trailer) != 0 || r.URL.Scheme != "" || r.URL.Host != "" || r.URL.User != nil || r.URL.RawQuery != "" || r.URL.ForceQuery || r.URL.Fragment != "" || r.URL.RawFragment != "" || r.URL.Opaque != "" || r.URL.EscapedPath() != r.URL.Path || r.URL.RawPath != "" || r.RequestURI != r.URL.Path || len(r.RequestURI) > 256 || strings.ContainsAny(r.RequestURI, "%\\\x00\r\n?#") {
		return v, ErrDenied
	}
	const prefix = "/api/v1/ide/deployments/"
	if !strings.HasPrefix(r.RequestURI, prefix) {
		return v, ErrDenied
	}
	p := strings.Split(strings.TrimPrefix(r.RequestURI, prefix), "/")
	if !finiteOperation.MatchString(p[0]) {
		return v, ErrDenied
	}
	v = finiteHTTPRequest{Path: r.RequestURI, Host: r.Host, Operation: p[0]}
	switch {
	case len(p) == 1:
		v.Selector = "deployment"
	case len(p) == 2 && (p[1] == "logs" || p[1] == "runtime" || p[1] == "usage"):
		v.Selector = p[1]
	case len(p) == 3 && p[1] == "usage" && p[2] == "records":
		v.Selector = "usage.records"
	case (len(p) == 3 || len(p) == 4 && p[3] == "native-intent") && p[1] == "billing":
		d, e := time.Parse("2006-01-02", p[2])
		if e != nil || d.Format("2006-01-02") != p[2] {
			return v, ErrDenied
		}
		v.Selector = "billing"
		if len(p) == 4 {
			v.Selector = "billing.native-intent"
		}
	default:
		return v, ErrDenied
	}
	count, total := 0, 0
	for k, values := range r.Header {
		if strings.ContainsAny(k, "\x00\r\n") {
			return v, ErrDenied
		}
		for _, x := range values {
			total += len(k) + len(x) + 4
			if total > 262144 || strings.ContainsAny(x, "\x00\r\n") {
				return v, ErrDenied
			}
			switch strings.ToLower(k) {
			case "trailer", "transfer-encoding":
				return v, ErrDenied
			case "x-ynx-product-session-proof-v2", "x-ynx-product-session-proof-v5":
				return v, ErrDenied
			case "x-ynx-product-session-proof-v4":
				count++
				v.Header = x
			}
		}
	}
	if count != 1 || len(v.Header) == 0 || len(v.Header) > 196608 || v.Host == "" || strings.ContainsAny(v.Host, "/@?#\\\x00\r\n") {
		return v, ErrDenied
	}
	return v, nil
}

type finiteTargetCap struct {
	Version             int           `json:"version"`
	ParentSourceID      string        `json:"parentSourceId"`
	ProjectSourceID     string        `json:"projectSourceId"`
	DeviceSourceID      string        `json:"deviceSourceId"`
	Account             string        `json:"account"`
	DeviceID            string        `json:"deviceId"`
	SessionBinding      string        `json:"sessionBinding"`
	RegistrationDigest  string        `json:"registrationDigest"`
	CatalogProjectID    string        `json:"catalogProjectId"`
	Cloud               finiteFullRef `json:"registeredCloudFullRef"`
	ResourceApprovalRef string        `json:"resourceApprovalRef"`
	TargetOrigin        string        `json:"targetOrigin"`
	ServerName          string        `json:"serverName"`
	Port                uint16        `json:"port"`
	SPKI                string        `json:"spkiSHA256"`
	ProductOrigin       string        `json:"productOrigin"`
	RequiredScopes      []string      `json:"requiredScopes"`
	Selectors           []string      `json:"permittedSelectors"`
	PublicCredentialRef string        `json:"publicCredentialRef"`
	LocalSAN            string        `json:"localSAN"`
	PeerSAN             string        `json:"peerSAN"`
	RootCertSHA         string        `json:"rootCertificateSHA256"`
	ClientCertSHA       string        `json:"clientCertificateSHA256"`
	NotBefore           int64         `json:"notBeforeMs"`
	Expires             int64         `json:"expiresMs"`
	RootEpoch           string        `json:"rootEpoch"`
	RootUntil           int64         `json:"rootUntilMs"`
	CredentialEpoch     string        `json:"credentialEpoch"`
	CredentialUntil     int64         `json:"credentialUntilMs"`
}
type finiteDeviceExpected struct {
	NetworkID          string  `json:"networkId"`
	CanonicalOwner     string  `json:"canonicalOwner"`
	Account            string  `json:"account"`
	SessionBinding     string  `json:"sessionBinding"`
	ProductID          string  `json:"productId"`
	ClientID           string  `json:"clientId"`
	Platform           string  `json:"platform"`
	ApplicationID      string  `json:"applicationId"`
	BundleID           *string `json:"bundleId"`
	PackageID          *string `json:"packageId"`
	Origin             string  `json:"origin"`
	Callback           string  `json:"callback"`
	DeviceID           string  `json:"deviceId"`
	Generation         string  `json:"generation"`
	RegistrationID     string  `json:"registrationId"`
	Revision           string  `json:"revision"`
	RegistrationDigest string  `json:"registrationDigest"`
}
type finiteDeviceScope struct {
	Version      string               `json:"version"`
	Expected     finiteDeviceExpected `json:"expected"`
	Context      json.RawMessage      `json:"context"`
	Registration string               `json:"registrationOriginal"`
	Session      string               `json:"sessionOriginal"`
}
type finiteSourceSnapshot struct {
	principal             Principal
	cap                   finiteTargetCap
	device                finiteDeviceScope
	project, deviceRecord *originalIDESourceRecord
	binding               batch.ProductSessionHTTPBinding
	expires               int64
	proofUntil            int64
}
type finitePrincipalAttempt struct {
	request         *http.Request
	originalContext context.Context
	captured        finiteHTTPRequest
	snapshot        *finiteSourceSnapshot
	principal       Principal
	nonce           *originalReadNonceAttempt
	first           error
	phase           string
}
type OriginalIDEFiniteGETPrincipalSource struct {
	source           *OriginalIDEPublicationSourceOwner
	identity         *OriginalFiniteGETReceiverIdentity
	nonce            *originalReadNonceStore
	records          map[*http.Request]*finitePrincipalAttempt
	requestChildren  map[*http.Request]*finiteGETRequestChildState
	releasedRequests map[*http.Request]context.Context
	requestContexts  map[context.Context]*finitePrincipalAttempt
	retired, closed  bool
	first            error
}

func containsFinite(a []string, s string) bool {
	for _, x := range a {
		if x == s {
			return true
		}
	}
	return false
}
func sourcePurpose(t originalIDETemplate) string {
	var p struct {
		S struct {
			Purpose string `json:"purpose"`
		} `json:"signatureContract"`
	}
	if json.Unmarshal(t.Policy, &p) != nil {
		return ""
	}
	return p.S.Purpose
}
func readPrincipalOriginal(raw json.RawMessage) (Principal, error) {
	var p Principal
	if decodeExactObject(raw, 16384, map[string]any{"account": &p.Account, "deviceId": &p.DeviceID, "sessionRef": &p.SessionRef, "currentRef": &p.CurrentRef, "accountGeneration": &p.AccountGeneration, "sessionGeneration": &p.SessionGeneration, "expiresMS": &p.ExpiresMS}) != nil || p.Account == "" || p.DeviceID == "" || p.SessionRef == "" || p.CurrentRef == "" || p.AccountGeneration == 0 || p.SessionGeneration == 0 || time.Now().UnixMilli() >= p.ExpiresMS {
		return p, ErrDenied
	}
	return p, nil
}
func (s *OriginalIDEFiniteGETPrincipalSource) snapshotLocked(ctx context.Context, request finiteHTTPRequest) (*finiteSourceSnapshot, error) {
	if s == nil || s.retired || s.closed || s.first != nil || s.identity == nil || s.identity.currentLocked(ctx) != nil {
		return nil, ErrDenied
	}
	o := s.source
	r := s.identity.row
	selectedTarget, targetError := url.Parse(r.TargetOrigin)
	if targetError != nil || request.Host != selectedTarget.Host {
		return nil, ErrDenied
	}
	if sourcePurpose(o.config.Templates["project"]) != "ide-project-authority-v1" || sourcePurpose(o.config.Templates["device-v4"]) != "product-session-device-source-v4" {
		return nil, ErrFiniteGETNotSupplied
	}
	project, e := o.record(ctx, "project", r.ProjectSubject, r.ProjectBinding)
	if e != nil {
		return nil, e
	}
	if e = o.current(ctx, project); e != nil {
		return nil, e
	}
	var selection struct {
		Project struct {
			Principal json.RawMessage `json:"principal"`
			Project   struct {
				ID      string `json:"projectId"`
				Read    bool   `json:"read"`
				Expires int64  `json:"expiresMS"`
			} `json:"project"`
		} `json:"projectAuthority"`
		Cap finiteTargetCap `json:"ideFiniteGETTargetV1"`
	}
	if json.Unmarshal(project.projection.Selection, &selection) != nil {
		return nil, ErrDenied
	}
	p, e := readPrincipalOriginal(selection.Project.Principal)
	if e != nil {
		return nil, e
	}
	c := selection.Cap
	device, e := o.record(ctx, "device-v4", r.DeviceSubject, r.DeviceBinding)
	if e != nil {
		return nil, e
	}
	if e = o.current(ctx, device); e != nil {
		return nil, e
	}
	var ds struct {
		Device finiteDeviceScope `json:"productSessionDeviceV4"`
	}
	if json.Unmarshal(device.projection.Selection, &ds) != nil {
		return nil, ErrDenied
	}
	d := ds.Device
	expected := d.Expected
	now := time.Now().UnixMilli()
	target, e := url.Parse(r.TargetOrigin)
	if e != nil || request.Host != target.Host || c.Version != 1 || project.projection.SourceID != r.ProjectSourceID || c.ProjectSourceID != r.ProjectSourceID || device.projection.SourceID != r.DeviceSourceID || c.DeviceSourceID != r.DeviceSourceID || c.ParentSourceID == "" || c.Cloud != r.Cloud || c.TargetOrigin != r.TargetOrigin || c.ServerName != r.ServerName || c.SPKI != r.SPKI || c.CatalogProjectID != r.CatalogProjectID || c.ResourceApprovalRef != r.ResourceApprovalRef || selection.Project.Project.ID != r.CatalogProjectID || !selection.Project.Project.Read || now >= selection.Project.Project.Expires || c.Account != p.Account || c.DeviceID != p.DeviceID || expected.Account != p.Account || expected.DeviceID != p.DeviceID || d.Version != "4" || expected.ProductID != "developer" || expected.Platform != "macos" || c.SessionBinding != expected.SessionBinding || c.RegistrationDigest != expected.RegistrationDigest || c.ProductOrigin != expected.Origin || !reflect.DeepEqual(c.RequiredScopes, r.RequiredScopes) || !containsFinite(c.Selectors, request.Selector) || !containsFinite(r.Selectors, request.Selector) || now < c.NotBefore || now >= c.Expires || c.Expires > c.RootUntil || c.Expires > c.CredentialUntil || !finiteDecimal(c.RootEpoch) || !finiteDecimal(c.CredentialEpoch) {
		return nil, ErrDenied
	}
	// DEVICE originals were checked by the original dedicated Source verifier,
	if r.ParentSourceID == "" || c.ParentSourceID != r.ParentSourceID {
		return nil, ErrDenied
	}
	if !reflect.DeepEqual(c.Selectors, r.Selectors) {
		return nil, ErrDenied
	}
	// including exact registration20/session4, root/role current and account
	// registered pair. These internal projections do not invent another codec.
	var registration struct {
		NetworkID string  `json:"networkId"`
		Owner     string  `json:"canonicalOwner"`
		PKA       string  `json:"pkA"`
		PKB       string  `json:"pkB"`
		Expires   string  `json:"expiresAt"`
		Revoked   *string `json:"revokedAt"`
	}
	var session struct {
		Binding string   `json:"sessionBinding"`
		Scopes  []string `json:"scopes"`
		Expires string   `json:"expiresAt"`
	}
	if json.Unmarshal([]byte(d.Registration), &registration) != nil || json.Unmarshal([]byte(d.Session), &session) != nil || hash([]byte(d.Registration)) != expected.RegistrationDigest || registration.Revoked != nil || registration.NetworkID != expected.NetworkID || registration.Owner != expected.CanonicalOwner || session.Binding != expected.SessionBinding {
		return nil, ErrDenied
	}
	for _, scope := range c.RequiredScopes {
		if !containsFinite(session.Scopes, scope) {
			return nil, ErrDenied
		}
	}
	a, ae := hex.DecodeString(registration.PKA)
	b, be := hex.DecodeString(registration.PKB)
	network, ne := hex.DecodeString(expected.NetworkID)
	regUntil, re := time.Parse("2006-01-02T15:04:05.000Z", registration.Expires)
	sessionUntil, se := time.Parse("2006-01-02T15:04:05.000Z", session.Expires)
	if ae != nil || be != nil || ne != nil || len(a) != 2592 || len(b) != 64 || len(network) != 32 || re != nil || se != nil {
		return nil, ErrDenied
	}
	until := min(p.ExpiresMS, c.Expires, project.projection.Expires, device.projection.Expires, selection.Project.Project.Expires, regUntil.UnixMilli(), sessionUntil.UnixMilli(), s.identity.expires)
	if time.Now().UnixMilli() < now || time.Now().UnixMilli() >= until || s.identity.currentLocked(ctx) != nil || ctx.Err() != nil {
		return nil, ErrDenied
	}
	return &finiteSourceSnapshot{p, c, d, project, device, batch.ProductSessionHTTPBinding{NetworkID: network, Owner: registration.Owner, PKA: a, PKB: b}, until, min(regUntil.UnixMilli(), sessionUntil.UnixMilli())}, nil
}
func sameFiniteSnapshot(a, b *finiteSourceSnapshot) bool {
	return a != nil && b != nil && a.principal == b.principal && reflect.DeepEqual(a.cap, b.cap) && reflect.DeepEqual(a.device, b.device) && a.project.digest == b.project.digest && a.deviceRecord.digest == b.deviceRecord.digest && a.expires == b.expires
}
func sameFiniteRequest(a *finitePrincipalAttempt, r *http.Request) bool {
	if a == nil || r == nil || a.request != r || r.Context().Err() != nil || a.originalContext == nil || !reflect.TypeOf(a.originalContext).Comparable() || !reflect.TypeOf(r.Context()).Comparable() || a.originalContext != r.Context() {
		return false
	}
	v, e := captureFiniteHTTPRequest(r)
	return e == nil && v == a.captured
}

// The only normal entry: SAME existing Source/pool and actual listener TLS.
// Root release rows remain empty until independent release; no runtime config.
func OpenOriginalIDEFiniteGETPrincipalSource(ctx context.Context, o *OriginalIDEPublicationSourceOwner, actualServerTLS *securelink.OriginalServerTLS) (*OriginalIDEFiniteGETPrincipalSource, error) {
	return openOriginalIDEFiniteGETPrincipalSource(ctx, o, actualServerTLS, originalFiniteGETReceiverReleases())
}
func openOriginalIDEFiniteGETPrincipalSource(ctx context.Context, o *OriginalIDEPublicationSourceOwner, actualServerTLS *securelink.OriginalServerTLS, rows []finiteReceiverRelease) (*OriginalIDEFiniteGETPrincipalSource, error) {
	out := &OriginalIDEFiniteGETPrincipalSource{source: o, records: map[*http.Request]*finitePrincipalAttempt{}, requestContexts: map[context.Context]*finitePrincipalAttempt{}}
	if o == nil {
		return out, ErrDenied
	}
	observation, observationErr := observeOriginalLINKReceiver(ctx, actualServerTLS, nil)
	o.mu.Lock()
	defer o.mu.Unlock()
	if observationErr != nil {
		out.first = observationErr
		return out, observationErr
	}
	if o.finiteGET != nil {
		return out, ErrConflict
	}
	identity, e := receiverIdentity(ctx, o, actualServerTLS, rows, observation)
	out.identity = identity
	if e != nil {
		out.first = e
		return out, e
	}
	out.nonce, e = openOriginalReadNonceStore(ctx, o.db)
	if e != nil {
		out.first = e
		return out, e
	}
	selectedURL, _ := url.Parse(identity.row.TargetOrigin)
	if _, e = out.snapshotLocked(ctx, finiteHTTPRequest{Host: selectedURL.Host, Selector: identity.row.Selectors[0]}); e != nil {
		out.first = e
		return out, e
	}
	o.finiteGET = out
	return out, nil
}
func (s *OriginalIDEFiniteGETPrincipalSource) Current(ctx context.Context) error {
	if s == nil || s.source == nil || s.identity == nil {
		return ErrDenied
	}
	if e := s.identity.observe(ctx, nil); e != nil {
		return e
	}
	e := func() error {
		s.source.mu.Lock()
		defer s.source.mu.Unlock()
		u, e := url.Parse(s.identity.row.TargetOrigin)
		if e != nil || len(s.identity.row.Selectors) == 0 {
			return ErrDenied
		}
		_, e = s.snapshotLocked(ctx, finiteHTTPRequest{Host: u.Host, Selector: s.identity.row.Selectors[0]})
		return e
	}()
	if e != nil {
		return e
	}
	return s.identity.observe(ctx, nil)
}
func (s *OriginalIDEFiniteGETPrincipalSource) currentRequestLocked(ctx context.Context, r *http.Request) (Principal, error) {
	var zero Principal
	if s == nil || s.retired || s.closed || s.first != nil || ctx == nil || ctx.Err() != nil || r == nil || r.Context().Err() != nil {
		return zero, ErrDenied
	}
	if !sameFiniteContext(ctx, r.Context()) {
		return zero, ErrDenied
	}
	child, childErr := s.requestChildLocked(ctx, r, true)
	if childErr != nil || child.retired || child.closed || child.first != nil {
		return zero, ErrDenied
	}
	captured, e := captureFiniteHTTPRequest(r)
	if e != nil {
		return zero, e
	}
	if a := s.records[r]; a != nil {
		if s.requestContexts[ctx] != a {
			return zero, ErrDenied
		}
		if a.first != nil || a.phase != "verified" || a.captured != captured || a.nonce == nil || time.Now().UnixMilli() >= a.nonce.claim.expiresMS || !sameFiniteRequest(a, r) {
			return zero, ErrUnknown
		}
		now, e := s.snapshotLocked(ctx, captured)
		if e != nil || !sameFiniteSnapshot(a.snapshot, now) {
			a.first = ErrDenied
			return zero, ErrDenied
		}
		return a.principal, nil
	}
	// An incoming HTTP request context is not the reusable outbound Host
	// logical-read context. Only this actual server request may own its entry.
	if _, alreadyBound := s.requestContexts[ctx]; alreadyBound {
		return zero, ErrDenied
	}
	a := &finitePrincipalAttempt{request: r, originalContext: r.Context(), captured: captured, phase: "selected"}
	s.records[r] = a // selected before any Source/math/nonce IO; never retry this request
	s.requestContexts[ctx] = a
	fail := func(e error) (Principal, error) {
		if a.first == nil {
			a.first = e
		}
		a.phase = "failed"
		return zero, e
	}
	snap, e := s.snapshotLocked(ctx, captured)
	a.snapshot = snap
	if e != nil {
		return fail(e)
	}
	proof, e := s.source.verifier.inspectOriginalFiniteGETV4(ctx, captured.Header, snap.binding)
	if e != nil {
		return fail(e)
	}
	var u struct {
		Method, Path, Account, DeviceID, Origin, Nonce, IssuedAt, ExpiresAt, SessionBinding, DeviceRegistrationDigest, DeviceRegistrationID, DeviceRegistrationRevision, ProductID, ClientID, ApplicationID, Callback string
		BundleID, PackageID                                                                                                                                                                                           *string
	}
	if json.Unmarshal(proof.UnsignedOriginal, &u) != nil {
		return fail(ErrDenied)
	}
	d := snap.device.Expected
	if u.Method != "GET" || u.Path != captured.Path || u.Account != snap.principal.Account || u.DeviceID != snap.principal.DeviceID || u.Origin != snap.cap.ProductOrigin || u.SessionBinding != d.SessionBinding || u.DeviceRegistrationDigest != d.RegistrationDigest || u.DeviceRegistrationID != d.RegistrationID || u.DeviceRegistrationRevision != d.Revision || u.ProductID != d.ProductID || u.ClientID != d.ClientID || u.ApplicationID != d.ApplicationID || u.Callback != d.Callback || !reflect.DeepEqual(u.BundleID, d.BundleID) || !reflect.DeepEqual(u.PackageID, d.PackageID) {
		return fail(ErrDenied)
	}
	issued, ie := time.Parse("2006-01-02T15:04:05.000Z", u.IssuedAt)
	expires, ee := time.Parse("2006-01-02T15:04:05.000Z", u.ExpiresAt)
	now := time.Now().UnixMilli()
	// Signature expiry is the SOLE V4 session/registration window. A short
	// Source observation is independently rechecked at each gate; it is not
	// silently extended, nor mislabelled the proof's signed expiresAt.
	if ie != nil || ee != nil || now < issued.UnixMilli() || now >= expires.UnixMilli() || expires.UnixMilli() > snap.proofUntil {
		return fail(ErrDenied)
	}
	before, e := s.snapshotLocked(ctx, captured)
	if e != nil || !sameFiniteSnapshot(snap, before) || !sameFiniteRequest(a, r) {
		return fail(ErrDenied)
	}
	a.nonce, e = newOriginalReadNonceAttempt(originalReadNonceClaim{snap.project.projection.SourceID, snap.project.projection.InstanceID, u.Nonce, hash([]byte(captured.Header)), objectHash(struct {
		Request finiteHTTPRequest
		Cloud   finiteFullRef
	}{captured, s.identity.row.Cloud}), objectHash(snap.principal), issued.UnixMilli(), expires.UnixMilli()})
	if e != nil {
		return fail(e)
	}
	a.phase = "nonce-entered"
	e = s.nonce.consume(ctx, a.nonce)
	if e != nil {
		return fail(e)
	}
	after, e := s.snapshotLocked(ctx, captured)
	if e != nil || !sameFiniteSnapshot(snap, after) || ctx.Err() != nil || time.Now().UnixMilli() >= expires.UnixMilli() || !sameFiniteRequest(a, r) {
		return fail(ErrUnknown)
	}
	a.principal = snap.principal
	a.phase = "verified"
	return a.principal, nil
}
func (s *OriginalIDEFiniteGETPrincipalSource) currentPrincipalLocked(ctx context.Context, p Principal) error {
	if s == nil || s.retired || s.closed || ctx == nil || ctx.Err() != nil || !reflect.TypeOf(ctx).Comparable() {
		return ErrDenied
	}
	a := s.requestContexts[ctx]
	if a == nil || a.principal != p || a.phase != "verified" || a.first != nil || a.nonce == nil || time.Now().UnixMilli() >= a.nonce.claim.expiresMS || !sameFiniteContext(a.originalContext, ctx) {
		return ErrDenied
	}
	_, e := s.currentRequestLocked(ctx, a.request)
	return e
}
func sameFiniteContext(a, b context.Context) bool {
	return a != nil && b != nil && reflect.TypeOf(a).Comparable() && reflect.TypeOf(b).Comparable() && a == b
}
func (s *OriginalIDEFiniteGETPrincipalSource) hasOriginalContextLocked(ctx context.Context) bool {
	return s != nil && ctx != nil && reflect.TypeOf(ctx).Comparable() && s.requestContexts[ctx] != nil
}
func (s *OriginalIDEFiniteGETPrincipalSource) Retire() {
	if s != nil && s.source != nil {
		s.source.mu.Lock()
		s.retired = true
		s.source.mu.Unlock()
	}
}
func (s *OriginalIDEFiniteGETPrincipalSource) Join() bool {
	if s == nil || s.source == nil {
		return true
	}
	s.source.mu.Lock()
	defer s.source.mu.Unlock()
	return s.retired
}
func (s *OriginalIDEFiniteGETPrincipalSource) Close() error {
	if s == nil || s.source == nil {
		return nil
	}
	s.source.mu.Lock()
	defer s.source.mu.Unlock()
	s.retired = true
	s.closed = true
	return s.first
}

// FULL LINK identity and genuine request-origin calls run outside source.mu.
// A late failure after nonce consumption retains the SAME failed attempt and
// never exposes its principal. This is read-only pre/post fencing, NOT a claim
// of global Auth/LINK revocation atomicity across external resources.
func (s *OriginalIDEFiniteGETPrincipalSource) currentOriginalRequest(ctx context.Context, r *http.Request) (result Principal, resultErr error) {
	var zero Principal
	child, childErr := s.beginOriginalRequest(ctx, r)
	if childErr != nil {
		return zero, childErr
	}
	defer s.finishOriginalRequest(child, &resultErr)
	if s == nil || s.source == nil || s.identity == nil {
		return zero, ErrDenied
	}
	if e := s.identity.observe(ctx, r); e != nil {
		return zero, e
	}
	s.source.mu.Lock()
	p, e := s.currentRequestLocked(ctx, r)
	s.source.mu.Unlock()
	if e != nil {
		return zero, e
	}
	if e = s.identity.observe(ctx, r); e != nil {
		s.source.mu.Lock()
		if a := s.records[r]; a != nil {
			if a.first == nil {
				a.first = e
			}
			a.phase = "failed"
		}
		s.source.mu.Unlock()
		return zero, e
	}
	s.source.mu.Lock()
	defer s.source.mu.Unlock()
	if s.retired || s.closed || child.retired || child.closed || s.source.check(ctx) != nil {
		return zero, ErrDenied
	}
	return p, nil
}
func (s *OriginalIDEFiniteGETPrincipalSource) assertOriginalPrincipal(ctx context.Context, p Principal, catalog bool) (resultErr error) {
	if s == nil || s.source == nil || s.identity == nil || ctx == nil || !reflect.TypeOf(ctx).Comparable() {
		return ErrDenied
	}
	s.source.mu.Lock()
	a := s.requestContexts[ctx]
	var r *http.Request
	if a != nil {
		r = a.request
	}
	s.source.mu.Unlock()
	if r == nil {
		return ErrDenied
	}
	child, childErr := s.beginOriginalRequest(ctx, r)
	if childErr != nil {
		return childErr
	}
	defer s.finishOriginalRequest(child, &resultErr)
	original, e := s.currentOriginalRequest(ctx, r)
	if e != nil {
		return e
	}
	if original != p {
		return ErrDenied
	}
	s.source.mu.Lock()
	e = s.currentPrincipalLocked(ctx, p)
	if e == nil && catalog {
		e = s.source.assertSourceLocked(ctx)
	}
	s.source.mu.Unlock()
	if e != nil {
		return e
	}
	if e := s.identity.observe(ctx, r); e != nil {
		return e
	}
	s.source.mu.Lock()
	defer s.source.mu.Unlock()
	if child.retired || child.closed || s.retired || s.closed || s.source.check(ctx) != nil {
		return ErrDenied
	}
	return nil
}
