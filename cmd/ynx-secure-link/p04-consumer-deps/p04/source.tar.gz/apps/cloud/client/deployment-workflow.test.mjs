import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {mkdtemp,readFile,writeFile,symlink,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {YNXCloudClient,YNXCloudDeploymentUnknownError} from '../sdk/index.js';
import {CloudDeploymentClient} from './deployment-client.mjs';
import {submitDeploymentReceipt,reconcileDeploymentReceipt} from './deployment-workflow.mjs';

test('durable receipt precedes original POST and cold receipt rejects changed selection or symlink without replay',async()=>{
 const root=await mkdtemp(join(tmpdir(),'p04-deploy-receipt-'));const receipt=join(root,'operation.json');
 let posts=0,gets=0,operation;const server=createServer(async(req,res)=>{
  if(req.method==='POST'){
   posts++;for await(const _ of req){}
   const disk=JSON.parse(await readFile(receipt,'utf8'));assert.equal(disk.state,'UNKNOWN');
   assert.equal('approval'in disk,false);assert.equal('artifact'in disk,false);
   res.destroy();return;
  }
  gets++;res.setHeader('Content-Type','application/json');res.end(JSON.stringify(operation));
 });server.listen(0,'127.0.0.1');await once(server,'listening');
 try{
  const endpoint=`http://127.0.0.1:${server.address().port}/api/v1`;
  const make=()=>new CloudDeploymentClient(new YNXCloudClient({endpoint,product:'cloud',maxRetries:0,getDeploymentRequestHeaders:async()=>({'X-Public-Fixture':'not-authority'})}));
  const artifact=Buffer.from('PUBLIC original bytes');
  const input={requestId:'request_receipt_original_0001',manifest:Buffer.from(JSON.stringify({projectId:'PUBLIC_PROJECT',version:'1',contentDigest:createHash('sha256').update(artifact).digest('hex'),publishPurpose:'deploy',targetEnvironment:'PUBLIC_ENV',byteSize:artifact.length})),artifact,approval:Buffer.from('PUBLIC approval not signature'),expectedSlotRevision:'0'};
  const client=make(),prepared=client.prepare(input);
  operation={requestId:input.requestId,state:'running',deploymentId:'PUBLIC_INSTANCE',runtimeUrl:'https://public.invalid/',manifestSHA256:prepared.selection.manifestSHA256,approvalSHA256:prepared.selection.approvalSHA256,contentBinding:prepared.selection.contentBinding,expectedSlotRevision:'0',slotRevision:'1'};
  await assert.rejects(submitDeploymentReceipt(client,prepared,receipt),e=>e instanceof YNXCloudDeploymentUnknownError);
  assert.equal(posts,1);assert.equal(JSON.parse(await readFile(receipt,'utf8')).state,'UNKNOWN');
  const cold=make();assert.equal((await reconcileDeploymentReceipt(cold,receipt)).deploymentId,'PUBLIC_INSTANCE');
  assert.equal((await submitDeploymentReceipt(cold,cold.prepare(input),receipt)).deploymentId,'PUBLIC_INSTANCE');assert.equal(posts,1);
  const before=gets;await assert.rejects(submitDeploymentReceipt(cold,cold.prepare({...input,expectedSlotRevision:'1'}),receipt),/selection changed/);assert.equal(gets,before);
  const alias=join(root,'alias.json');await symlink(receipt,alias);await assert.rejects(reconcileDeploymentReceipt(cold,alias));assert.equal(gets,before);
  const foreign=join(root,'foreign.json');const data=JSON.parse(await readFile(receipt,'utf8'));data.endpoint='https://other.invalid/api/v1';await writeFile(foreign,JSON.stringify(data),{mode:0o600});await assert.rejects(reconcileDeploymentReceipt(cold,foreign),/original Cloud endpoint/);assert.equal(gets,before);
 }finally{await new Promise(resolve=>server.close(resolve));await rm(root,{recursive:true,force:true});}
});
