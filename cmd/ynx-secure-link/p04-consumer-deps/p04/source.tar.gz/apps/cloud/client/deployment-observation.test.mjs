import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {readFile} from 'node:fs/promises';
import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentClient} from './deployment-client.mjs';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';

for(const version of ['legacy','v2'])test(`${version} runtime inspection rejects stale/swapped observations and never samples or posts`,async()=>{
 let op,mode='good',runtimeReads=0;const routes=[];
 const server=createServer((req,res)=>{
  routes.push(`${req.method} ${req.url}`);assert.equal(req.method,'GET');assert.equal(req.headers['x-public-observation'],'PUBLIC_PROTOCOL_ONLY');
  res.setHeader('Content-Type','application/json');let value=structuredClone(op);
  if(req.url.endsWith('/runtime')){
   runtimeReads++;
   if(mode==='unavailable'){res.writeHead(503).end('{"error":"original runtime unavailable"}');return;}
   if(mode==='url')value.runtimeUrl='https://someone:secret@other.invalid/';
   if(mode==='state-change'&&runtimeReads>1){value.state='completed';value.exitCode=0;}
  }else if(req.url.endsWith('/logs')){
   value={requestId:op.requestId,deploymentId:op.deploymentId,resourceId:op.resourceId,slotRevision:op.slotRevision,contentBinding:op.contentBinding,operationLogs:[],runtimeLogs:'PUBLIC resource log',runtimeLogSource:'original-resource'};
   if(mode==='log-instance')value.deploymentId='OTHER_INSTANCE';
   if(mode==='log-resource')value.resourceId='OTHER_RESOURCE';
   if(mode==='log-slot')value.slotRevision='999';
   if(mode==='log-binding')value.contentBinding={...value.contentBinding,bytes:'999'};
   if(mode==='log-old')delete value.deploymentId;
  }else if(req.url.endsWith('/usage/records')){
   const sample={instanceId:op.deploymentId,period:'2026-11-01',sampleSeq:'1',cpuNanos:'1000000',cpuMs:'1',memoryBytes:'4096',storedBytes:op.contentBinding.bytes,egressBytes:'0',observedAt:'2026-11-01T00:00:00Z'};
   value={requestId:op.requestId,instanceId:op.deploymentId,billingState:'UNPRICED',samples:{'2026-11-01/1':sample},latest:sample};
  }
  res.end(JSON.stringify(value));
 });server.listen(0,'127.0.0.1');await once(server,'listening');
 try{
  const original=new YNXCloudClient({endpoint:`http://127.0.0.1:${server.address().port}/api/v1`,product:'cloud',maxRetries:0,getDeploymentRequestHeaders:async()=>({'X-Public-Observation':'PUBLIC_PROTOCOL_ONLY'})});
  let client,prepared;
  if(version==='v2'){
   const fixture=JSON.parse(await readFile(new URL('./node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8'));
   client=new CloudDeploymentV2Client(original);prepared=client.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:'req_observe_v2_readonly_00001',expectedSlotRevision:'0'});
   const s=prepared.selection;op={requestId:s.requestId,manifestVersion:'2',manifestV2:s.manifest,manifestBinding:s.manifestBinding,contentBinding:s.contentBinding,expectedSlotRevision:'0'};
  }else{
   client=new CloudDeploymentClient(original);prepared=client.prepare({requestId:'req_observe_legacy_readonly_01',manifest:Buffer.from('PUBLIC manifest'),artifact:Buffer.from('PUBLIC artifact'),approval:Buffer.from('PUBLIC NOT_SIGNATURE'),expectedSlotRevision:'0'});
   const s=prepared.selection;op={requestId:s.requestId,manifestSHA256:s.manifestSHA256,approvalSHA256:s.approvalSHA256,contentBinding:s.contentBinding,expectedSlotRevision:'0'};
  }
  Object.assign(op,{state:'running',runtimeKind:'bounded-node-job',runtimeUrl:'https://public.invalid/runtime',deploymentId:'PUBLIC_INSTANCE',resourceId:'PUBLIC_RESOURCE',catalogProjectId:'PUBLIC_DISTINCT_CATALOG_MAPPING',slotRevision:'1'});
  const s=prepared.selection;const result=await client.inspect(s);assert.equal(result.operation.deploymentId,op.deploymentId);assert.equal(result.publicReadiness,'NOT_ASSERTED');assert.equal(result.SourceAdmission,false);
  for(const m of ['log-instance','log-resource','log-slot','log-binding','log-old']){mode=m;await assert.rejects(client.logs(s),undefined,m);}
  mode='state-change';runtimeReads=0;await assert.rejects(client.inspect(s));
  mode='url';await assert.rejects(client.runtime(s));
  mode='unavailable';assert.equal((await client.lookupOriginal(s)).state,'running');await assert.rejects(client.runtime(s),e=>e.status===503);
  const controller=new AbortController(),reason=Error('PUBLIC original caller cancelled');controller.abort(reason);
  const before=routes.length;await assert.rejects(client.inspect(s,{signal:controller.signal}),e=>e===reason);assert.equal(routes.length,before);
  assert.equal(routes.some(r=>r.endsWith('/usage')),false);assert.equal(routes.some(r=>!r.startsWith('GET ')),false);
 }finally{await new Promise(resolve=>server.close(resolve));}
});
