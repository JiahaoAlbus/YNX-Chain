import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFile,writeFile,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {CloudObjectClient} from './object-client.mjs';
let input='';for await(const b of process.stdin)input+=b;
const {base,tokens,root,stage,original}=JSON.parse(input),path=n=>join(root,n),cli=fileURLToPath(new URL('./cloud.mjs',import.meta.url));
let secrets=[];for(const name of ['original.json','prepared-cancel.json','legacy.json'])try{secrets.push(JSON.parse(await readFile(path(name),'utf8')).token);}catch{}
const run=(args,{failure=false,who='owner'}={})=>{
 const env={PATH:process.env.PATH,TMPDIR:process.env.TMPDIR,YNX_CLOUD_API:base,YNX_CLOUD_LOCAL_HTTP:'1'};if(who!=='anonymous')env.YNX_CLOUD_TOKEN=tokens[who];
 const r=spawnSync(process.execPath,[cli,...args],{env,encoding:'utf8',timeout:30000});assert.equal(r.status,failure?1:0,r.stderr);
 for(const secret of [...Object.values(tokens),...secrets])if(secret)assert.equal((r.stdout+r.stderr).includes(secret),false);
 return JSON.parse(failure?r.stderr:r.stdout);
};
let result;
if(stage==='initial'){
 await writeFile(path('source.bin'),'PUBLIC original capability bytes\0');
 const made=run(['upload',path('source.bin'),path('upload.json')]);const expiry=new Date(Date.now()+600000).toISOString();
 run(['link-create',made.objectID,expiry,path('legacy.json')]);secrets.push(JSON.parse(await readFile(path('legacy.json'),'utf8')).token);
 assert.equal(run(['link-prepare-original',made.objectID,expiry,path('original.json')]).outcome,'PREPARED');
 const before=JSON.parse(await readFile(path('original.json'),'utf8'));secrets.push(before.token);
 const lost=run(['link-create-original',made.objectID,expiry,path('original.json')],{failure:true});assert.equal(lost.outcome,'UNKNOWN');
 const after=JSON.parse(await readFile(path('original.json'),'utf8'));assert.equal(after.token,before.token);assert.equal(after.requestID,before.requestID);assert.equal(after.state,'UNKNOWN');
 run(['link-download',path('original.json'),path('unconfirmed.bin')],{who:'anonymous',failure:true});await assert.rejects(stat(path('unconfirmed.bin')),{code:'ENOENT'});
 result={id:made.objectID,expiry,requestID:before.requestID};
}else if(stage==='create-cold'){
 const recovered=run(['link-reconcile-original',path('original.json')]);assert.equal(recovered.outcome,'COMMITTED');
 assert.equal(run(['link-create-original',original.id,original.expiry,path('original.json')]).linkID,recovered.linkID);
 run(['link-download',path('original.json'),path('verified.bin')],{who:'anonymous'});assert.equal(await readFile(path('verified.bin'),'utf8'),'PUBLIC original capability bytes\0');
 const before=await readFile(path('original.json'));assert.match(run(['link-create-original',original.id,new Date(Date.parse(original.expiry)+1).toISOString(),path('original.json')],{failure:true}).error,/another original/);assert.deepEqual(await readFile(path('original.json')),before);
 assert.match(run(['link-reconcile-original',path('original.json')],{who:'other',failure:true}).error,/another original/);assert.deepEqual(await readFile(path('original.json')),before);
 run(['link-prepare-original',original.id,original.expiry,path('prepared-cancel.json')]);secrets.push(JSON.parse(await readFile(path('prepared-cancel.json'),'utf8')).token);
 assert.equal(run(['link-cancel-original',path('prepared-cancel.json')],{failure:true}).outcome,'UNKNOWN');
 assert.equal(run(['link-cancel-original',path('original.json')],{failure:true}).outcome,'UNKNOWN');
 run(['link-download',path('original.json'),path('pending-revoke.bin')],{who:'anonymous',failure:true});await assert.rejects(stat(path('pending-revoke.bin')),{code:'ENOENT'});
 result={...original,linkID:recovered.linkID};
}else if(stage==='cancel-cold'){
 assert.equal(run(['link-reconcile-original',path('prepared-cancel.json')]).outcome,'CANCELLED');
 const cancelled=JSON.parse(await readFile(path('prepared-cancel.json'),'utf8'));
 const client=new CloudObjectClient(base,tokens.owner,{allowLoopbackHTTP:true});await assert.rejects(client.createOriginalLink(cancelled.requestID,cancelled.selection),e=>e.status===409);
 assert.equal(run(['link-reconcile-original',path('original.json')]).outcome,'REVOKED');
 assert.equal(run(['link-create-original',original.id,original.expiry,path('original.json')]).outcome,'REVOKED');
 assert.equal(run(['link-cancel-original',path('original.json')]).outcome,'REVOKED');
 const revoked=JSON.parse(await readFile(path('original.json'),'utf8'));
 await writeFile(path('revoked-copy.json'),JSON.stringify({schemaVersion:1,endpoint:base,token:revoked.token,objectID:revoked.objectID,version:revoked.version,binding:revoked.binding}),{mode:0o600});
 const denied=run(['link-download',path('revoked-copy.json'),path('revoked.bin')],{who:'anonymous',failure:true});assert.ok([403,404].includes(denied.status));await assert.rejects(stat(path('revoked.bin')),{code:'ENOENT'});
 run(['link-download',path('legacy.json'),path('legacy-cold.bin')],{who:'anonymous'});assert.equal(await readFile(path('legacy-cold.bin'),'utf8'),'PUBLIC original capability bytes\0');
 const legacyBefore=await readFile(path('legacy.json'));run(['link-reconcile-original',path('legacy.json')],{failure:true});assert.deepEqual(await readFile(path('legacy.json')),legacyBefore);
 result={...original,originalRevoked:true,cancelBeforeCreateRetained:true,legacyRetained:true,noSecondSecret:true};
}else throw Error('Unknown stage');
process.stdout.write(JSON.stringify(result));
