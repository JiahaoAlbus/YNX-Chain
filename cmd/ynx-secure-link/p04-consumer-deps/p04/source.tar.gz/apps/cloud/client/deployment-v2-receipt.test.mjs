import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {mkdtemp,readFile,mkdir,chmod,stat,symlink,unlink,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentClient} from './deployment-client.mjs';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';
import {submitDeploymentReceipt,reconcileDeploymentReceipt,recoverDeploymentReceipt,runDeploymentCommand} from './deployment-workflow.mjs';

test('V2 durable original survives unavailable Native and cold404 without reacquiring or resubmitting',async()=>{
 const root=await mkdtemp(join(tmpdir(),'cloud-v2-receipt-')),file=join(root,'original.json');let ready=false,op,gets=0,posts=0;
 const server=createServer((req,res)=>{if(req.method!=='GET'){posts++;res.writeHead(405).end();return;}gets++;res.setHeader('Content-Type','application/json');if(!ready){res.writeHead(404).end('{"error":"original missing"}');return;}res.end(JSON.stringify(op));});server.listen(0,'127.0.0.1');await once(server,'listening');
 try{
  const fixture=JSON.parse(await readFile(new URL('./node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8'));
  const endpoint=`http://127.0.0.1:${server.address().port}/api/v1`;
  const original=()=>new YNXCloudClient({endpoint,product:'cloud',maxRetries:0,getDeploymentRequestHeaders:async()=>({'X-Public-Fixture':'PUBLIC_NOT_AUTHORITY'})});
  const make=()=>new CloudDeploymentV2Client(original());const client=make();
  const prepare=c=>c.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:'req_v2_durable_original_00001',expectedSlotRevision:'0'});
  const prepared=prepare(client),s=prepared.selection;
  client.captureOriginalE11Result(prepared,{phase:'RETURNED',payloadOriginal:client.payloadOriginal(prepared).toString('base64url'),payloadBinding:s.manifestBinding,artifactBinding:s.contentBinding,sourceCurrentOriginal:'PUBLIC_ONLY_SOURCE_BYTES',reservationOriginal:'PUBLIC_ONLY_RESERVATION',memberOriginal:Buffer.from('PUBLIC_NOT_A_SIGNATURE').toString('base64url'),coreStatus:0,cleanupStatus:2,reportedStatus:0,signed:true,sourceGranted:false,nativeAdmission:false,deployed:false});
  await assert.rejects(submitDeploymentReceipt(client,prepared,file),e=>e.status===503&&e.retryAllowed===false);
  const bytes=await readFile(file),saved=JSON.parse(bytes);assert.equal(saved.schema,'cloud-original-deployment-receipt/2');assert.equal(saved.state,'UNKNOWN');assert.deepEqual(saved.selection,s);assert.equal(bytes.includes('PUBLIC_NOT_A_SIGNATURE'),false);assert.equal(bytes.includes('PUBLIC_ONLY_RESERVATION'),false);
  assert.equal(client.originalNativeTransportStatus().acquisitionEntered,true);
  if(process.env.YNX_CLOUD_EXPECT_NORMAL_SDK==='1')assert.notEqual(client.originalNativeTransportStatus().acquisitionFailureCode,'ERR_MODULE_NOT_FOUND');
  const cold=make();await assert.rejects(submitDeploymentReceipt(cold,prepare(cold),file),e=>e.status===404);assert.deepEqual(await readFile(file),bytes);assert.equal(cold.originalNativeTransportStatus().acquisitionEntered,false);
  const recoveredFile=join(root,'existing-IDE-operation.json');await assert.rejects(recoverDeploymentReceipt(cold,s,recoveredFile),e=>e.status===404);assert.equal(JSON.parse(await readFile(recoveredFile)).state,'UNKNOWN');assert.equal(cold.originalNativeTransportStatus().acquisitionEntered,false);
  const reordered=Object.fromEntries(Object.entries(s).reverse());reordered.manifest=Object.fromEntries(Object.entries(s.manifest).reverse());await assert.rejects(recoverDeploymentReceipt(cold,reordered,recoveredFile),e=>e.status===404);
  const before=gets;await assert.rejects(reconcileDeploymentReceipt(new CloudDeploymentClient(original()),file),/operation version/);assert.equal(gets,before);
  const changed=structuredClone(fixture.manifest);changed.issuerEpoch=String(BigInt(changed.issuerEpoch)+1n);
  await assert.rejects(submitDeploymentReceipt(cold,cold.prepare(changed,Buffer.from(fixture.actualHex,'hex'),{requestId:s.requestId,expectedSlotRevision:'0'}),file),/selection changed/);assert.equal(gets,before);
  ready=true;op={requestId:s.requestId,manifestVersion:'2',manifestV2:s.manifest,manifestBinding:s.manifestBinding,contentBinding:s.contentBinding,expectedSlotRevision:'0',slotRevision:'1',state:'completed',exitCode:0,deploymentId:'PUBLIC_INSTANCE',resourceId:'PUBLIC_RESOURCE',catalogProjectId:'PUBLIC_CATALOG',runtimeUrl:'https://public.invalid/original',logs:[{message:'PUBLIC '.repeat(12000)}]};
  const result=await runDeploymentCommand(cold,['reconcile',file]);assert.equal(result.logs[0].message.length,84000);
  const stored=JSON.parse(await readFile(file));assert.equal(stored.state,'OBSERVED');assert.equal(stored.operation.deploymentId,op.deploymentId);assert.equal(stored.operation.logs,undefined);assert.equal(stored.operation.manifestV2,undefined);assert.ok((await stat(file)).size<32768);
  const secondCold=make();assert.equal((await submitDeploymentReceipt(secondCold,prepare(secondCold),file)).deploymentId,op.deploymentId);assert.equal(secondCold.originalNativeTransportStatus().acquisitionEntered,false);
  assert.equal(posts,0);await client.closeOriginalNativeTransport();
 }finally{await new Promise(resolve=>server.close(resolve));await rm(root,{recursive:true,force:true});}
});

test('deployment receipts reject shared or symlink parents and pre-entry cancellation without effects',async()=>{
 const root=await mkdtemp(join(tmpdir(),'cloud-receipt-boundary-'));
 try{
  let foreign=0;const sdk=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>{foreign++;throw Error('must not acquire');}}),client=new CloudDeploymentClient(sdk);
  const prepared=client.prepare({requestId:'req_private_receipt_00001',manifest:Buffer.from('PUBLIC manifest'),artifact:Buffer.from('PUBLIC artifact'),approval:Buffer.from('PUBLIC NOT_SIGNATURE'),expectedSlotRevision:'0'});
  const shared=join(root,'shared');await mkdir(shared);await chmod(shared,0o755);
  await assert.rejects(submitDeploymentReceipt(client,prepared,join(shared,'receipt.json')),/Private original deployment directory/);await assert.rejects(stat(join(shared,'receipt.json')),{code:'ENOENT'});
  const alias=join(root,'alias');await symlink(root,alias);await assert.rejects(submitDeploymentReceipt(client,prepared,join(alias,'receipt.json')),/Private original deployment directory/);
  const cancelled=new AbortController(),reason=Error('PUBLIC caller cancelled');cancelled.abort(reason);const file=join(root,'cancelled.json');await assert.rejects(submitDeploymentReceipt(client,prepared,file,{signal:cancelled.signal}),e=>e===reason);await assert.rejects(stat(file),{code:'ENOENT'});assert.equal(foreign,0);
 }finally{await rm(root,{recursive:true,force:true});}
});

test('V2 late running response cannot replace terminal observation or rearm a surviving terminal record',async()=>{
 const root=await mkdtemp(join(tmpdir(),'cloud-v2-terminal-')),file=join(root,'original.json');let mode='running',op,late,arrived,raceReads=0,posts=0;
 const seen=new Promise(resolve=>{arrived=resolve;});
 const server=createServer((req,res)=>{
  if(req.method!=='GET'){posts++;res.writeHead(405).end();return;}
  res.setHeader('Content-Type','application/json');
  if(mode==='race'&&++raceReads===1){late=res;arrived();return;}
  const value=mode==='running'?op:{...op,state:mode==='contradiction'?'failed':'completed',exitCode:mode==='contradiction'?1:0};res.end(JSON.stringify(value));
 });server.listen(0,'127.0.0.1');await once(server,'listening');
 try{
  const fixture=JSON.parse(await readFile(new URL('./node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8'));
  const make=()=>new CloudDeploymentV2Client(new YNXCloudClient({endpoint:`http://127.0.0.1:${server.address().port}/api/v1`,product:'cloud',maxRetries:0,getDeploymentRequestHeaders:async()=>({'X-Public-Fixture':'PUBLIC_PROTOCOL_ONLY'})}));
  const client=make(),prepared=client.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:'req_v2_terminal_original_001',expectedSlotRevision:'0'}),s=prepared.selection;
  op={requestId:s.requestId,manifestVersion:'2',manifestV2:s.manifest,manifestBinding:s.manifestBinding,contentBinding:s.contentBinding,expectedSlotRevision:'0',slotRevision:'1',state:'running',runtimeKind:'bounded-node-job',deploymentId:'PUBLIC_INSTANCE',resourceId:'PUBLIC_RESOURCE',catalogProjectId:'PUBLIC_CATALOG',runtimeUrl:'https://public.invalid/original'};
  await recoverDeploymentReceipt(client,s,file);
  mode='race';const pending=reconcileDeploymentReceipt(client,file);const rejected=assert.rejects(pending,e=>e.state==='unknown');await seen;
  await reconcileDeploymentReceipt(make(),file);late.end(JSON.stringify(op));await rejected;
  assert.equal(JSON.parse(await readFile(file)).operation.state,'completed');const terminal=await readFile(file+'.terminal');
  await unlink(file);mode='completed';const cold=make(),again=cold.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:s.requestId,expectedSlotRevision:'0'});
  assert.equal((await submitDeploymentReceipt(cold,again,file)).state,'completed');assert.equal(cold.originalNativeTransportStatus().acquisitionEntered,false);assert.deepEqual(await readFile(file+'.terminal'),terminal);
  const before=await readFile(file);mode='contradiction';await assert.rejects(reconcileDeploymentReceipt(cold,file),e=>e.state==='unknown');assert.deepEqual(await readFile(file),before);assert.deepEqual(await readFile(file+'.terminal'),terminal);assert.equal(posts,0);
 }finally{if(late&&!late.writableEnded)late.destroy();await new Promise(resolve=>server.close(resolve));await rm(root,{recursive:true,force:true});}
});
