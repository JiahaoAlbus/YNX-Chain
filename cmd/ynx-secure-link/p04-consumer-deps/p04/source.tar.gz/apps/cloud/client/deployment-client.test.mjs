import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {createHash} from 'node:crypto';
import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentClient} from './deployment-client.mjs';

test('original SDK caller binds revision, original artifact, recovery, logs and unpriced usage',async()=>{
  // PUBLIC HTTP protocol fixture only. No source admission/signature/runtime.
  const artifact=Buffer.from("console.log('PUBLIC fixture');\n"),approval=Buffer.from('PUBLIC_NOT_SIGNATURE');
  const sha=(algorithm,bytes)=>createHash(algorithm).update(bytes).digest('hex');
  const binding={projectId:'PUBLIC_PROJECT',version:'1',contentDigest:sha('sha256',artifact),publishPurpose:'deploy',targetEnvironment:'PUBLIC_ENV',byteSize:artifact.length};
  const manifest=Buffer.from(JSON.stringify(binding)),requestId='P04_node_original_deploy_01';
  let operation,posts=0,proofs=0,tamper=false,billPosts=0,billTamper=false,billPaid=false;
  const sampleBinding={bytes:'12',sha3_512:sha('sha3-512',Buffer.from('PUBLIC meter')),sha512:sha('sha512',Buffer.from('PUBLIC meter'))};
  const asset={genesis:'d'.repeat(64),nativeChainId:'71',assetId:'PUBLIC_LEDGER_ASSET',unitVersion:'7'};
  const schedule={id:'PUBLIC_TARIFF',revision:'1',resourceId:'PUBLIC_RESOURCE',projectId:binding.projectId,merchant:'PUBLIC_MERCHANT',recipient:'PUBLIC_RECIPIENT',registrationRef:'PUBLIC_REGISTERED_REF',approvalRef:'PUBLIC_CURRENT_APPROVAL',asset,cpuNanos:{units:'1000000',atoms:'2'},egressBytes:{units:'10',atoms:'3'},peakStoredBytes:{units:'64',atoms:'1'}};
  const bill={request:{requestId,instanceId:'PUBLIC_INSTANCE',period:'2026-10-28',billId:'PUBLIC_STABLE_BILL',scheduleId:schedule.id,scheduleRevision:schedule.revision,merchant:schedule.merchant,recipient:schedule.recipient,registrationRef:schedule.registrationRef,approvalRef:schedule.approvalRef,asset,atoms:'6',sampleBinding},aggregate:{period:'2026-10-28',cpuNanos:'1000000',egressBytes:'10',peakStoredBytes:String(artifact.length),sampleBinding},schedule,state:'PREPARED',settlement:'NOT_VERIFIED',invoiceId:'PUBLIC_INVOICE',originalOperation:'PUBLIC_ORIGINAL'};
  const server=createServer(async(req,res)=>{
    assert.equal(req.headers['x-public-proof'],'PUBLIC_PROTOCOL_FIXTURE');
    if(req.url.includes('/billing/')){
      if(req.method==='POST'){billPosts++;res.destroy();return;}
      res.setHeader('Content-Type','application/json');res.end(JSON.stringify({...bill,state:billPaid?'PAID':bill.state,request:{...bill.request,atoms:billTamper?'7':'6'}}));return;
    }
    if(req.method==='POST'){
      posts++;for await(const _ of req){}
      assert.equal(req.headers['x-expected-deployment-revision'],'0');
      operation={requestId,state:'running',resourceId:'PUBLIC_RESOURCE',binding,manifestSHA256:sha('sha256',manifest),approvalSHA256:sha('sha256',approval),contentBinding:{bytes:String(artifact.length),sha3_512:sha('sha3-512',artifact),sha512:sha('sha512',artifact)},expectedSlotRevision:'0',slotRevision:'1',deploymentId:'PUBLIC_INSTANCE',runtimeUrl:'https://public-runtime.invalid/'};
    }
    res.setHeader('Content-Type','application/json');
    if(req.url.endsWith('/logs'))return res.end(JSON.stringify({requestId,deploymentId:operation.deploymentId,resourceId:operation.resourceId,slotRevision:operation.slotRevision,contentBinding:operation.contentBinding,operationLogs:[],runtimeLogs:'PUBLIC not executed app log',runtimeLogSource:'original-resource'}));
    if(req.url.endsWith('/usage')||req.url.endsWith('/usage/records')){const sample={instanceId:'PUBLIC_INSTANCE',period:'2026-10-31',sampleSeq:'1793426400000000000',cpuNanos:'1000000',cpuMs:'1',memoryBytes:'4096',storedBytes:String(artifact.length),egressBytes:'0'};return res.end(JSON.stringify({requestId,instanceId:'PUBLIC_INSTANCE',billingState:'UNPRICED',samples:{[`${sample.period}/${sample.sampleSeq}`]:sample},latest:sample}));}
    res.end(JSON.stringify(tamper?{...operation,slotRevision:'2'}:operation));
  });
  server.listen(0,'127.0.0.1');await once(server,'listening');
  try{
    const original=new YNXCloudClient({endpoint:`http://127.0.0.1:${server.address().port}/api/v1`,product:'cloud',getDeploymentRequestHeaders:async()=>{proofs++;return{'X-Public-Proof':'PUBLIC_PROTOCOL_FIXTURE'};}});
    const client=new CloudDeploymentClient(original);
    const result=await client.submit({requestId,manifest,artifact,approval,expectedSlotRevision:'0'});
    assert.equal(result.operation.slotRevision,'1');
    assert.equal((await client.lookupOriginal(result.selection)).deploymentId,'PUBLIC_INSTANCE');
    assert.equal((await client.logs(result.selection)).runtimeLogSource,'original-resource');
    assert.equal((await client.usage(result.selection)).billingState,'UNPRICED');
    assert.equal((await client.usage(result.selection,{observe:false})).billingState,'UNPRICED');
    await assert.rejects(client.bill(result.selection,'2026-10-28',{prepare:true}));
    assert.equal(billPosts,1,'billing POST automatically retried after lost response');
    const recovered=await client.bill(result.selection,'2026-10-28');
    assert.equal(recovered.request.atoms,'6');assert.equal(recovered.settlement,'NOT_VERIFIED');
    billTamper=true;await assert.rejects(client.bill(result.selection,'2026-10-28'));billTamper=false;
    billPaid=true;await assert.rejects(client.bill(result.selection,'2026-10-28'));billPaid=false;
    assert.equal(billPosts,1,'original bill read created another invoice');
    tamper=true;await assert.rejects(client.lookupOriginal(result.selection));
    await assert.rejects(client.submit({requestId,manifest,artifact,approval,expectedSlotRevision:'0'}));
    assert.equal(posts,1,'lookup/retry submitted the original again');assert.ok(proofs>=5);
    assert.throws(()=>new CloudDeploymentClient(new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getAccessToken:async()=>'PUBLIC_SESSION'})),/proof provider/);
  }finally{await new Promise(resolve=>server.close(resolve));}
});
