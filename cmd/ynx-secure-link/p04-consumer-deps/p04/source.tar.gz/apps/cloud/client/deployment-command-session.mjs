import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';
import {runDeploymentCommand} from './deployment-workflow.mjs';

const commands=new Set(['status','reconcile','runtime','logs','usage','usage-records','inspect','bill-original','native-intent-original']);

// Same-process command entry for the original admitted SDK caller. No token,
// header file, provider module or ordinary object session becomes a GET proof.
// Closing cancels local waits only: it does not stop a deployment or revoke it.
class OriginalDeploymentCommandSession {
  #client;#pending=new Map();#retired=false;#closing=null;#next=0;
  constructor(original){this.#client=new CloudDeploymentV2Client(original);}
  async run(args,{signal}={}){
    if(this.#retired)throw Error('Original deployment command session retired');
    if(!Array.isArray(args)||!commands.has(args[0])||args.some(v=>typeof v!=='string'))throw Error('Original read-only deployment command required');
    if(signal?.aborted)throw signal.reason;
    const selected=[...args],controller=new AbortController(),id=++this.#next;
    const cancel=()=>controller.abort(signal.reason);
    signal?.addEventListener('abort',cancel,{once:true});
    // Defer entry until the owned wait is registered, so immediate close cannot
    // miss a command between selection and the first asynchronous receipt read.
    const promise=Promise.resolve().then(()=>runDeploymentCommand(this.#client,selected,{signal:controller.signal}));
    this.#pending.set(id,{controller,promise});
    try{return await promise;}
    finally{signal?.removeEventListener('abort',cancel);this.#pending.delete(id);}
  }
  close(){
    if(!this.#closing){
      this.#retired=true;
      const pending=[...this.#pending.values()];
      const reason=Error('Original deployment command wait cancelled');
      for(const task of pending)task.controller.abort(reason);
      this.#closing=Promise.allSettled(pending.map(task=>task.promise)).then(()=>undefined);
    }
    return this.#closing;
  }
  statusDATA(){return {retired:this.#retired,pendingWaits:this.#pending.size,NativeAcquired:false,remoteCancellation:false,SourceAdmission:false};}
}

export function openOriginalCloudDeploymentCommandSession(original){
  if(!(original instanceof YNXCloudClient)||original.product!=='cloud'||typeof original.getDeploymentRequestHeaders!=='function')throw Error('Original Cloud SDK deployment read caller required');
  return new OriginalDeploymentCommandSession(original);
}

export async function runOriginalCloudDeploymentCommand(original,args,options){
  const owner=openOriginalCloudDeploymentCommandSession(original);
  try{return await owner.run(args,options);}finally{await owner.close();}
}
