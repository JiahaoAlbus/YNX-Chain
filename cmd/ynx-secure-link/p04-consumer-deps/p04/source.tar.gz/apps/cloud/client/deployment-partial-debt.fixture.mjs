// PUBLIC fixed-import stand-in only; no Source, Native or crypto qualification.
import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {YNXCloudClient} from '../sdk/index.js';
const mode=process.argv[2],stage=mode.split('-')[0],value=mode.endsWith('-undefined')?undefined:mode.endsWith('-null')?null:false;
let opens=0,joins=0,closes=0,requests=0;
const partial={retire(){if(stage==='retire')throw value;},join(){joins++;if(stage==='join'&&joins===1)throw value;},close(){closes++;if(stage==='close')throw value;}};
const acquisition=stage==='acquire'?value:Object.assign(Error('PUBLIC acquisition partial'),{partial});
globalThis.__cloudPartialDebt={open(){opens++;throw acquisition;}};
const hook=registerHooks({resolve(specifier,ctx,next){return specifier==='@ynx-chain/wallet-auth/original-http-binary-v5-client'?{url:'cloud-partial-debt:fixed',shortCircuit:true}:next(specifier,ctx);},load(url,ctx,next){return url==='cloud-partial-debt:fixed'?{format:'module',source:'export async function openOriginalHTTPBinaryClientV5(){return globalThis.__cloudPartialDebt.open()}',shortCircuit:true}:next(url,ctx);}});
try{
  const {CloudDeploymentV2Client}=await import('./deployment-v2-client.mjs');
  const sdk=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>{requests++;throw Error('must not enter');}}),client=new CloudDeploymentV2Client(sdk);
  await assert.rejects(client.openOriginalNativeTransport(),e=>e===acquisition);
  assert.equal(client.originalNativeTransportStatus().acquisitionFailed,true);
  if(stage==='acquire'){await client.closeOriginalNativeTransport();assert.equal(closes,0);}
  else{
    await assert.rejects(client.closeOriginalNativeTransport(),e=>e===value);
    if(stage==='join')assert.equal(closes,0);
    const before=closes;
    await assert.rejects(client.drainOriginalNativeTransport(),e=>e===value);
    assert.equal(client.originalNativeTransportStatus().partialFirstCausePresent,true);
    if(stage==='close'){assert.equal(closes,before);assert.equal(client.originalNativeTransportStatus().partialPhysicallyClosed,false);}
    else assert.equal(client.originalNativeTransportStatus().partialPhysicallyClosed,true);
    await assert.rejects(client.closeOriginalNativeTransport(),e=>e===value);
  }
  assert.equal(opens,1);assert.equal(requests,0);
  console.log(JSON.stringify({mode,opens,joins,closes,requests,PUBLICStandIn:true,RootAdmission:false}));
}finally{hook.deregister();delete globalThis.__cloudPartialDebt;}
