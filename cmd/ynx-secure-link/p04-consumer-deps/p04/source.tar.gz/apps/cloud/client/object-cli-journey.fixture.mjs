// Isolated normal-host integration only. PUBLIC Wallet admission is supplied
// by the Go test, never by this client or the production Cloud host.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFile,writeFile,chmod,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
let input='';for await(const part of process.stdin)input+=part;
const {base,ownerToken,otherToken,otherAccount,root,stage,original}=JSON.parse(input);
const cliPath=fileURLToPath(new URL('./cloud.mjs',import.meta.url));
const run=(token,args,{failure=false}={})=>{
 const p=spawnSync(process.execPath,[cliPath,...args],{env:{...process.env,YNX_CLOUD_API:base,YNX_CLOUD_TOKEN:token,YNX_CLOUD_LOCAL_HTTP:'1'},encoding:'utf8',timeout:30000});
 assert.equal(p.status,failure?1:0,p.stderr);
 assert.equal((p.stdout+p.stderr).includes(ownerToken),false);assert.equal((p.stdout+p.stderr).includes(otherToken),false);
 return JSON.parse(failure?p.stderr:p.stdout);
};
const owner=(...args)=>run(ownerToken,args),other=(...args)=>run(otherToken,args);
const refused=async(token,args,path)=>{const e=run(token,args,{failure:true});assert.ok([403,404].includes(e.status),JSON.stringify(e));if(path)await assert.rejects(stat(path),{code:'ENOENT'});};
const bytes=Buffer.concat([Buffer.from('PUBLIC independent cross-end binary\n'),Buffer.from([0,255,128,10])]);
let result;
if(stage==='initial'){
 const source=join(root,'source.bin'),receipt=join(root,'receipt.json');await writeFile(source,bytes);
 const created=owner('upload',source,receipt);const id=created.objectID;
 const otherPath=join(root,'other-denied.bin');await refused(otherToken,['download',id,otherPath],otherPath);
 assert.equal(JSON.stringify(other('list')).includes(id),false);
 const secondSource=join(root,'tenant-b.txt');await writeFile(secondSource,'PUBLIC isolated tenant B');
 const tenantB=other('upload',secondSource,join(root,'tenant-b-receipt.json'));
 assert.equal(JSON.stringify(owner('list')).includes(tenantB.objectID),false);
 const output=join(root,'other-end-first.bin');owner('download',id,output);assert.deepEqual(await readFile(output),bytes);
 const next=join(root,'replacement.bin');await writeFile(next,'PUBLIC replacement version');
 const updated=owner('put',id,created.revision,next);const restored=owner('restore',id,'1',updated.revision);
 assert.equal(restored.version,3);const restoredPath=join(root,'restored.bin');owner('download',id,restoredPath);assert.deepEqual(await readFile(restoredPath),bytes);
 const allowed=owner('access',id,otherAccount,'allow',restored.revision);
 const shared=join(root,'tenant-b-granted.bin');other('download',id,shared);assert.deepEqual(await readFile(shared),bytes);
 const denied=owner('access',id,otherAccount,'deny',allowed.revision);
 await refused(otherToken,['get',id]);
 const cap=join(root,'private-link.json');const link=owner('link-create',id,new Date(Date.now()+120000).toISOString(),cap);
 const capability=JSON.parse(await readFile(cap,'utf8'));assert.equal((await stat(cap)).mode&0o077,0);
 const viaLink=join(root,'tenant-b-link.bin');other('link-download',cap,viaLink);assert.deepEqual(await readFile(viaLink),bytes);
 assert.equal(JSON.stringify(link).includes(capability.token),false);
 const nonprivate=join(root,'nonprivate-link.json');await writeFile(nonprivate,JSON.stringify(capability),{mode:0o644});await chmod(nonprivate,0o644);
 const privateError=run(otherToken,['link-download',nonprivate,join(root,'must-not-exist.bin')],{failure:true});assert.match(privateError.error,/Private capability/);
 const foreign=join(root,'foreign-endpoint.json');await writeFile(foreign,JSON.stringify({...capability,endpoint:'https://other.invalid/api/v1'}),{mode:0o600});
 const foreignError=run(otherToken,['link-download',foreign,join(root,'foreign-output.bin')],{failure:true});assert.match(foreignError.error,/another endpoint/);
 result={id,receipt,source,cap,linkID:link.id,revision:denied.revision,tenantB:tenantB.objectID,version:3};
}else if(stage==='cold'){
 const replay=owner('upload',original.source,original.receipt);assert.equal(replay.objectId,original.id);
 const output=join(root,'cold-verified.bin');owner('download',original.id,output);assert.deepEqual(await readFile(output),bytes);
 await refused(otherToken,['get',original.id]);
 const linkOutput=join(root,'cold-link.bin');other('link-download',original.cap,linkOutput);assert.deepEqual(await readFile(linkOutput),bytes);
 owner('link-revoke',original.id,original.linkID);
 await refused(otherToken,['link-download',original.cap,join(root,'revoked.bin')],join(root,'revoked.bin'));
 result={coldOriginal:true,revoked:true};
}else if(stage==='revoked-cold'){
 await refused(otherToken,['download',original.id,join(root,'cold-denied.bin')],join(root,'cold-denied.bin'));
 await refused(otherToken,['link-download',original.cap,join(root,'cold-revoked.bin')],join(root,'cold-revoked.bin'));
 assert.equal(owner('versions',original.id).length,3);
 const again=owner('upload',original.source,original.receipt);assert.equal(again.objectId,original.id);
 result={accessAndCapabilityRevocationRetained:true,noRepeatedUpload:true};
}else if(stage==='unadmitted'){
 const response=run(ownerToken,['list'],{failure:true});assert.equal(response.status,401);result={normalUnavailableSessionRejected:true};
}else throw Error('Unknown stage');
process.stdout.write(JSON.stringify(result));
