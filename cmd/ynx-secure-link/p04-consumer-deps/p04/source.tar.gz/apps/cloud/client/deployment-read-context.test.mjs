import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';

// PUBLIC transport/DTO controls. The real caller creates each context; Cloud
// must pass that same object. No Native Source, signature or TLS claim follows.
test('original read context reaches actual Cloud client callbacks for all finite views',async()=>{
 const fixture=JSON.parse(await readFile(new URL('./node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8').catch(()=>readFile(new URL('../../../node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8')));
 let expected,op,s,proofs=0;const paths=new Set(),contexts=new Set(),stop=Error('PUBLIC reached original billing context');
 const sdk=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async(request,context)=>{
  proofs++;assert.equal(context,expected);assert.equal(context.signal,expected.signal);assert.deepEqual(Object.keys(request),['method','path','url','operationRequestId']);paths.add(request.path);
  if(request.path.includes('/billing/'))throw stop;
  return {'X-Public-Fixture':'NOT_A_SIGNATURE'};
 },fetch:async(url,options)=>{
  assert.equal(options.signal,expected.signal);const pathname=new URL(url).pathname;
  if(pathname.endsWith('/logs'))return Response.json({requestId:s.requestId,deploymentId:op.deploymentId,resourceId:op.resourceId,slotRevision:op.slotRevision,contentBinding:op.contentBinding,operationLogs:[],runtimeLogs:'PUBLIC log DATA',runtimeLogSource:'original-resource'});
  if(pathname.endsWith('/usage')||pathname.endsWith('/usage/records')){
   const sample={instanceId:op.deploymentId,period:'2026-11-07',sampleSeq:'1',cpuNanos:'1000000',cpuMs:'1',memoryBytes:'4096',storedBytes:s.contentBinding.bytes,egressBytes:'0',observedAt:'2026-11-07T00:00:00Z'};
   return Response.json({requestId:s.requestId,instanceId:op.deploymentId,billingState:'UNPRICED',samples:{[`${sample.period}/${sample.sampleSeq}`]:sample},latest:sample});
  }
  return Response.json(op);
 }});
 const client=new CloudDeploymentV2Client(sdk);s=client.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:'req_PUBLIC_CONTEXT_000001',expectedSlotRevision:'0'}).selection;
 op={requestId:s.requestId,manifestVersion:'2',manifestV2:s.manifest,manifestBinding:s.manifestBinding,contentBinding:s.contentBinding,expectedSlotRevision:'0',slotRevision:'1',state:'completed',exitCode:0,deploymentId:'PUBLIC_INSTANCE',resourceId:'PUBLIC_RESOURCE',catalogProjectId:'PUBLIC_CATALOG',runtimeUrl:'https://public.invalid/app'};
 const run=async callback=>{const controller=new AbortController();expected=Object.freeze({signal:controller.signal});contexts.add(expected);return callback({signal:controller.signal,originalRequestContext:expected});};
 await run(o=>client.lookupOriginal(s,o));await run(o=>client.logs(s,o));await run(o=>client.runtime(s,o));
 await run(o=>client.usage(s,o));await run(o=>client.usage(s,{...o,observe:false}));await run(o=>client.inspect(s,o));
 await run(o=>assert.rejects(client.billOriginal(s,'2026-11-07',o),e=>e===stop));
 await run(o=>assert.rejects(client.nativeInvoiceIntentOriginal(s,'2026-11-07',{...o,productId:'cloud.ide-usage',sourceOrder:'cloud_usage_'+'b'.repeat(64)}),e=>e===stop));
 assert.equal(contexts.size,8);assert.equal(paths.size,7);assert.ok(proofs>8);
 assert.equal(client.originalNativeTransportStatus().acquisitionEntered,false);assert.equal(sdk.deploymentRequests.size,0);
});

test('read context mismatch, mutable context and accessors refuse before proof',async()=>{
 let proofs=0,getters=0;
 const sdk=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>{proofs++;throw Error('must not enter');}});
 const a=new AbortController(),b=new AbortController(),id='req_PUBLIC_BAD_CONTEXT_000001';
 const accessor=Object.freeze(Object.defineProperty({},'signal',{enumerable:true,get(){getters++;return a.signal;}}));
 for(const context of [{signal:a.signal},Object.freeze({signal:b.signal}),accessor,Object.freeze({signal:{aborted:false}}),Object.freeze({signal:a.signal,authority:true})])await assert.rejects(sdk.getIDEDeploymentStatus(id,{signal:a.signal,originalRequestContext:context}),/context changed/);
 assert.equal(proofs,0);assert.equal(getters,0);
});

test('caller abort false retains its same context and cannot dispatch after a late header',async()=>{
 const controller=new AbortController(),context=Object.freeze({signal:controller.signal});let entered,release,fetches=0;
 const started=new Promise(r=>{entered=r;}),wait=new Promise(r=>{release=r;});
 const sdk=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async(_request,actual)=>{assert.equal(actual,context);entered();await wait;return {'X-Public-Fixture':'NOT_AUTHORITY'};},fetch:async()=>{fetches++;throw Error('must not dispatch');}});
 const pending=sdk.getIDEDeploymentStatus('req_PUBLIC_CANCEL_CONTEXT_000001',{signal:controller.signal,originalRequestContext:context}),rejected=assert.rejects(pending,e=>e===false);
 await started;controller.abort(false);await rejected;release();await new Promise(r=>setImmediate(r));assert.equal(fetches,0);assert.equal(context.signal,controller.signal);
});

test('legacy read caller is not given a newly manufactured context',async()=>{
 const sdk=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async function(){assert.equal(arguments.length,1);return {'X-Public-Fixture':'NOT_AUTHORITY'};},fetch:async()=>Response.json({requestId:'req_PUBLIC_NO_CONTEXT_000001',state:'unknown'})});
 await sdk.getIDEDeploymentStatus('req_PUBLIC_NO_CONTEXT_000001');
});
