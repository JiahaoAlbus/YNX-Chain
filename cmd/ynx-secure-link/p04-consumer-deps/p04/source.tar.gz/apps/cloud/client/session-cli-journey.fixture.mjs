// Real normal Cloud service/HTTP; original Wallet admission is a PUBLIC fixture
// owned by the Go integration. No signing, manufactured token or Root here.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFile,writeFile,mkdir,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
let input='';for await(const b of process.stdin)input+=b;
const {base,token,otherToken,foreignToken,root,stage,original}=JSON.parse(input);
const cli=fileURLToPath(new URL('./cloud.mjs',import.meta.url));
const profile=join(root,'session.json'),otherProfile=join(root,'other-session.json');
const run=(args,{source='file',failure=false}={})=>{
 const env={PATH:process.env.PATH,TMPDIR:process.env.TMPDIR,YNX_CLOUD_API:base,YNX_CLOUD_LOCAL_HTTP:'1'};
 if(source==='env')env.YNX_CLOUD_TOKEN=token;
 else if(source==='other-env')env.YNX_CLOUD_TOKEN=otherToken;
 else if(source==='foreign-env')env.YNX_CLOUD_TOKEN=foreignToken;
 else if(source==='anonymous'){}
 else env.YNX_CLOUD_SESSION_FILE=source==='other'?otherProfile:profile;
 const p=spawnSync(process.execPath,[cli,...args],{env,encoding:'utf8',timeout:30000});
 assert.equal(p.status,failure?1:0,p.stderr);
 for(const secret of [token,otherToken,foreignToken])if(secret)assert.equal((p.stdout+p.stderr).includes(secret),false);
 return JSON.parse(failure?p.stderr:p.stdout);
};
const bytes=Buffer.concat([Buffer.from('PUBLIC credential-file cross-process file\n'),Buffer.from([255,0,128])]);
let result;
if(stage==='initial'){
 const saved=run(['session-save',profile],{source:'env'});assert.equal(saved.outcome,'SAVED');
 assert.equal((await stat(profile)).mode&0o077,0);
 const status=run(['session-status']);assert.equal(status.outcome,'ACTIVE');assert.equal(status.session.product,'cloud');
 for(const key of ['token','tokenHash','sessionBinding','requestDigest','deviceKey','callback'])assert.equal(Object.hasOwn(status.session,key),false);
 run(['session-save',otherProfile],{source:'other-env'});
 const source=join(root,'payload.bin'),receipt=join(root,'upload.json');await writeFile(source,bytes);
 const created=run(['upload',source,receipt]);const output=join(root,'second-process.bin');run(['download',created.objectID,output]);assert.deepEqual(await readFile(output),bytes);
 const committed=JSON.parse(await readFile(receipt,'utf8'));assert.equal(committed.schemaVersion,2);assert.equal(committed.account,status.session.account);
 const pending=join(root,'pending-original.json');await writeFile(pending,JSON.stringify({...committed,requestID:'PUBLIC_pending_original_001',state:'PREPARED',objectID:undefined}),{mode:0o600});
 const pendingBefore=await readFile(pending);const switched=run(['upload',source,pending],{source:'foreign-env',failure:true});assert.match(switched.error,/another original Cloud account/);assert.deepEqual(await readFile(pending),pendingBefore);
 const legacy=join(root,'legacy-prepared.json');await writeFile(legacy,JSON.stringify({...committed,schemaVersion:1,account:undefined,product:undefined,state:'PREPARED'}),{mode:0o600});
 const legacyBefore=await readFile(legacy);assert.match(run(['upload',source,legacy],{failure:true}).error,/Legacy prepared receipt/);assert.deepEqual(await readFile(legacy),legacyBefore);
 const oldSubmitted=join(root,'legacy-submitted.json');await writeFile(oldSubmitted,JSON.stringify({...committed,schemaVersion:1,account:undefined,product:undefined}),{mode:0o600});assert.equal(run(['upload',source,oldSubmitted]).objectId,created.objectID);
 const output2=join(root,'another-session.bin');run(['download',created.objectID,output2],{source:'other'});assert.deepEqual(await readFile(output2),bytes);
 const cap=join(root,'share.json');const shared=run(['link-create',created.objectID,new Date(Date.now()+120000).toISOString(),cap]);
 const anonymous=join(root,'anonymous.bin');run(['link-download',cap,anonymous],{source:'anonymous'});assert.deepEqual(await readFile(anonymous),bytes);
 const foreign=join(root,'foreign');await mkdir(foreign,{mode:0o700});const record=JSON.parse(await readFile(profile,'utf8'));await writeFile(join(foreign,'session.json'),JSON.stringify({...record,endpoint:'https://foreign.invalid/api/v1'}),{mode:0o600});
 result={id:created.objectID,receipt,source,account:status.session.account,version:1,cap,linkID:shared.id};
}else if(stage==='cold'){
 assert.equal(run(['session-status']).outcome,'ACTIVE');
 const replay=run(['upload',original.source,original.receipt]);assert.equal(replay.objectId,original.id);
 const output=join(root,'cold.bin');run(['download',original.id,output]);assert.deepEqual(await readFile(output),bytes);
 const anonymous=join(root,'anonymous-cold.bin');run(['link-download',original.cap,anonymous],{source:'anonymous'});assert.deepEqual(await readFile(anonymous),bytes);
 run(['link-revoke',original.id,original.linkID]);
 // The real server commits DELETE, then deliberately loses only its response.
 const lost=run(['session-revoke'],{failure:true});assert.equal(lost.outcome,'REVOKE_UNKNOWN');
 assert.equal(JSON.parse(await readFile(profile,'utf8')).state,'REVOKE_UNKNOWN');
 const blocked=run(['list'],{failure:true});assert.equal(blocked.outcome,'REVOKE_UNKNOWN');
 result=original;
}else if(stage==='revoked-cold'){
 const reconciled=run(['session-revoke']);assert.equal(reconciled.outcome,'UNAVAILABLE');
 const file=JSON.parse(await readFile(profile,'utf8'));assert.equal(file.token,undefined);
 assert.equal(run(['session-status']).outcome,'UNAVAILABLE');
 run(['list'],{failure:true});
 const deniedFile=join(root,'anonymous-revoked.bin');const denied=run(['link-download',original.cap,deniedFile],{source:'anonymous',failure:true});assert.ok([403,404].includes(denied.status));await assert.rejects(stat(deniedFile),{code:'ENOENT'});
 assert.equal(run(['session-status'],{source:'other'}).outcome,'ACTIVE');
 const output=join(root,'other-session-after-revoke.bin');run(['download',original.id,output],{source:'other'});assert.deepEqual(await readFile(output),bytes);
 result={sameOriginal:true,otherSessionRetained:true,originalSessionUnavailable:true};
}else if(stage==='unadmitted'){
 const error=run(['session-save',join(root,'never-saved.json')],{source:'env',failure:true});assert.equal(error.status,401);await assert.rejects(stat(join(root,'never-saved.json')),{code:'ENOENT'});result={unadmitted401:true};
}else throw Error('Unknown stage');
process.stdout.write(JSON.stringify(result));
