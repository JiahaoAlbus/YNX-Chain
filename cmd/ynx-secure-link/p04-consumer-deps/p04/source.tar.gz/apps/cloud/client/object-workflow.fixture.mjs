// Invoked only by the isolated Go HTTP workflow test. All identities are PUBLIC
// fixtures; this script is not an account admission or deployed runtime proof.
import assert from 'node:assert/strict';
import {CloudObjectClient, CloudHTTPError, CloudUnknownOutcome, bindBytes} from './object-client.mjs';
import {spawnSync} from 'node:child_process';
import {mkdtemp, writeFile, readFile, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
let text = ''; for await (const chunk of process.stdin) text += chunk;
const {base, token, stage, original} = JSON.parse(text);
const client = new CloudObjectClient(base, token, {allowLoopbackHTTP:true});
const requestID = 'P04-public-original-upload-0001';
const bytes = Buffer.from('PUBLIC original object bytes\n');
let result;
if (stage === 'create') {
  const first = await client.create(requestID, {name:'public.txt', bytes});
  assert.equal((await client.create(requestID, {name:'public.txt', bytes})).id, first.id);
  await assert.rejects(client.create(requestID, {name:'changed.txt', bytes}), error => error instanceof CloudHTTPError && error.status === 409);
  assert.deepEqual(await client.download(first.id), bytes);
  const updated = await client.put(first.id, first.revision, Buffer.from('PUBLIC replacement\n'));
  assert.deepEqual(await client.download(first.id, 1), bytes);
  await assert.rejects(client.restore(first.id, 1, first.revision), error => error instanceof CloudHTTPError && error.status === 409);
  const restored = await client.restore(first.id, 1, updated.revision);
  assert.equal(restored.version, 3);
  assert.deepEqual(await client.download(first.id), bytes);
  const shared = await client.createLink(first.id, new Date(Date.now()+60_000).toISOString());
  assert.equal('tokenHash' in shared.link, false);
  result = {id:first.id, requestID, revision:restored.revision, version:restored.version, binding:bindBytes(bytes), linkID:shared.link.id, linkToken:shared.token};
} else if (stage === 'restart') {
  const observed = await client.lookupOriginal(original.requestID);
  assert.equal(observed.outcome, 'COMMITTED');
  assert.equal(observed.objectId, original.id);
  assert.deepEqual(observed.binding, original.binding);
  assert.deepEqual(await client.download(original.id, 1), bytes);
  assert.deepEqual(await client.downloadLink(original.linkToken, original.binding, original.version), bytes);
  await client.revokeLink(original.id, original.linkID);
  await assert.rejects(client.downloadLink(original.linkToken, original.binding, original.version), error => error instanceof CloudHTTPError && error.status === 403);
  result = {recovered:true};
} else if (stage === 'revokedRestart') {
  await assert.rejects(client.downloadLink(original.linkToken, original.binding, original.version), error => error instanceof CloudHTTPError && error.status === 403);
  result = {revocationRetained:true};
} else if (stage === 'unknown') {
  await assert.rejects(client.create('P04-public-unknown-upload-0002', {name:'unknown.txt', bytes}), error => error instanceof CloudUnknownOutcome && error.outcome === 'UNKNOWN');
  assert.equal((await client.lookupOriginal('P04-public-unknown-upload-0002')).outcome, 'UNKNOWN');
  result = {unknown:true};
} else if (stage === 'reconciled') {
  const observed = await client.lookupOriginal('P04-public-unknown-upload-0002');
  assert.equal(observed.outcome, 'COMMITTED');
  assert.deepEqual(observed.binding, bindBytes(bytes));
  assert.deepEqual(await client.download(observed.objectId), bytes);
  result = {originalRecovered:true};
} else if (stage === 'cli') {
  const root = await mkdtemp(join(tmpdir(),'p04-client-'));
  try {
    const source = join(root,'input.txt'), receipt = join(root,'receipt.json'), output = join(root,'verified.txt');
    await writeFile(source,bytes);
    const cli = (...args) => {
      const result = spawnSync(process.execPath,[fileURLToPath(new URL('./cloud.mjs',import.meta.url)),...args],{env:{...process.env,YNX_CLOUD_API:base,YNX_CLOUD_TOKEN:token,YNX_CLOUD_LOCAL_HTTP:'1'},encoding:'utf8',timeout:30_000});
      assert.equal(result.status,0,result.stderr); return JSON.parse(result.stdout);
    };
    const first = cli('upload',source,receipt);
    const again = cli('upload',source,receipt);
    assert.equal(first.objectID,again.objectId);
    cli('download',first.objectID,output);
    assert.deepEqual(await readFile(output),bytes);
    const saved = JSON.parse(await readFile(receipt,'utf8'));
    assert.equal(saved.state,'COMMITTED');
    assert.equal(JSON.stringify(saved).includes(token),false);
    result = {cliUploadQueryVerifiedFile:true};
  } finally { await rm(root,{recursive:true,force:true}); }
} else throw Error('Unknown test stage');
process.stdout.write(JSON.stringify(result));
