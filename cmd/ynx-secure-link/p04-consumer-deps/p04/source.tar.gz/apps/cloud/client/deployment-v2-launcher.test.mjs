import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {YNXCloudClient} from '../sdk/index.js';
import {openOriginalCloudDeploymentV2Launcher} from './deployment-v2-launcher.mjs';

test('normal Cloud async launcher retains Root0 partial and closes without a Native getter or request',async()=>{
 let requests=0;const sdk=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>{requests++;throw Error('must not acquire');},fetch:async()=>{requests++;throw Error('must not send');}});
 const result=await openOriginalCloudDeploymentV2Launcher(sdk);assert.ok(result.owner);assert.ok(result.error);
 const expected=process.env.YNX_CLOUD_CURRENT_SDK==='1'?'AUTH_RUNTIME_IMAGE_ADMISSION_NOT_SUPPLIED':undefined;
 if(expected)assert.equal(result.error.code,expected);
 else assert.ok(['AUTH_RUNTIME_IMAGE_ADMISSION_NOT_SUPPLIED','ERR_MODULE_NOT_FOUND'].includes(result.error.code));
 const initial=result.owner.statusDATA();assert.equal(initial.clientCreated,false);assert.equal(initial.SourceAdmission,false);
 assert.throws(()=>result.owner.client(),e=>e===result.error);
 await result.owner.close();await result.owner.close();assert.equal(result.owner.statusDATA().closed,true);assert.equal(result.owner.statusDATA().retired,true);
 await assert.rejects(result.owner.open(),e=>e===result.error);assert.equal(requests,0);assert.equal(sdk.deploymentRequests.size,0);
});

test('Cloud close drains child before parent and prevents a submit crossing retirement (test stand-ins)',()=>{
 const result=spawnSync(process.execPath,[fileURLToPath(new URL('./deployment-v2-launcher-lifecycle.fixture.mjs',import.meta.url))],{encoding:'utf8',timeout:15000});
 assert.equal(result.status,0,result.stderr||result.stdout);
 const observation=JSON.parse(result.stdout.trim());assert.equal(observation.testStandIns,true);assert.equal(observation.requests,0);assert.equal(observation.RootAdmission,false);
});

for(const mode of ['native-false','child-false','parent-join-false','parent-retire-false'])test(`Cloud original lifecycle retains ${mode} without admitting or releasing an uncertain parent (test stand-ins)`,()=>{
 const result=spawnSync(process.execPath,[fileURLToPath(new URL('./deployment-v2-launcher-lifecycle.fixture.mjs',import.meta.url)),mode],{encoding:'utf8',timeout:15000});
 assert.equal(result.status,0,result.stderr||result.stdout);
 const observation=JSON.parse(result.stdout.trim());assert.equal(observation.requests,0);assert.equal(observation.RootAdmission,false);
});

for(const mode of ['continue-before-close','continue-child','continue-child-unconfirmed','continue-child-join','continue-join','continue-join-undefined','continue-parent-close'])test(`Cloud cleanup continuation ${mode} keeps the original owner, debt and first cause (test stand-ins)`,()=>{
 const result=spawnSync(process.execPath,[fileURLToPath(new URL('./deployment-v2-launcher-lifecycle.fixture.mjs',import.meta.url)),mode],{encoding:'utf8',timeout:15000});
 assert.equal(result.status,0,result.stderr||result.stdout);
 const observation=JSON.parse(result.stdout.trim());assert.equal(observation.requests,0);assert.equal(observation.RootAdmission,false);
});
