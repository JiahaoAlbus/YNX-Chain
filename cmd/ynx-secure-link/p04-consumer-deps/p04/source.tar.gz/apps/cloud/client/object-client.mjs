import { createHash } from 'node:crypto';

const MAX_BYTES = 8 * 1024 * 1024;
const HEX = /^[0-9a-f]{128}$/;
const UINT = /^(0|[1-9][0-9]*)$/;
const KEY = /^[A-Za-z0-9_-]{16,128}$/;
const part = value => {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,160}$/.test(value)) throw Error('Invalid resource identifier');
  return encodeURIComponent(value);
};
const revision = value => {
  if (typeof value !== 'string' || !UINT.test(value) || BigInt(value) < 1n || BigInt(value) > 18446744073709551615n) throw Error('Invalid revision');
  return value;
};
const version = value => {
  if (!Number.isSafeInteger(value) || value < 1) throw Error('Invalid version');
  return String(value);
};
export function bindBytes(input) {
  if (!(input instanceof Uint8Array) || input.byteLength > MAX_BYTES || input.buffer instanceof SharedArrayBuffer) throw Error('Invalid object bytes');
  const bytes = Buffer.from(input);
  return Object.freeze({ bytes: String(bytes.byteLength), sha3_512: createHash('sha3-512').update(bytes).digest('hex'), sha512: createHash('sha512').update(bytes).digest('hex') });
}
// Product DATA identity only, not a grant. No plaintext target is retained in
// the original operation tombstone; the real ACL still stores/validates it.
export function bindShareTarget(target){
  part(target);return createHash('sha256').update('cloud.object.access.target/v1\0'+target).digest('hex');
}
function binding(value) {
  if (!value || typeof value.bytes !== 'string' || !UINT.test(value.bytes) || BigInt(value.bytes) > BigInt(MAX_BYTES) || !HEX.test(value.sha3_512) || !HEX.test(value.sha512)) throw Error('Missing or invalid object binding');
  return {bytes:value.bytes, sha3_512:value.sha3_512, sha512:value.sha512};
}
function same(a, b) { a = binding(a); b = binding(b); return a.bytes === b.bytes && a.sha3_512 === b.sha3_512 && a.sha512 === b.sha512; }

export class CloudHTTPError extends Error {
  constructor(status, body) { super(body?.error || `Cloud HTTP ${status}`); this.status = status; this.outcome = body?.outcome; }
}
export class CloudUnknownOutcome extends Error {
  constructor(requestID, cause) { super('Original upload outcome is UNKNOWN; query the same request without submitting another upload', {cause}); this.requestID = requestID; this.outcome = 'UNKNOWN'; }
}

// Independent Node client. Hashes actual received bytes using the platform crypto
// implementation. No expected-digest callback, SDK authority or browser mock.
export class CloudObjectClient {
  #base; #token;
  constructor(base, token, {allowLoopbackHTTP = false, allowAnonymousLinks = false} = {}) {
    const url = new URL(base);
    if (url.username || url.password || url.search || url.hash || url.pathname.replace(/\/$/, '') !== '/api/v1') throw Error('Invalid Cloud API endpoint');
    const loopback = ['127.0.0.1', '[::1]', 'localhost'].includes(url.hostname);
    if (url.protocol !== 'https:' && !(allowLoopbackHTTP && loopback && url.protocol === 'http:')) throw Error('HTTPS Cloud endpoint required');
    if (token===undefined&&allowAnonymousLinks) { /* only #request(anonymous:true) may proceed */ }
    else if (typeof token !== 'string' || token.length < 1 || /[\r\n\x00]/.test(token)) throw Error('Current Wallet session required');
    this.#base = url.href.replace(/\/$/, ''); this.#token = token;
  }
  async #request(path, {method = 'GET', headers = {}, body, anonymous = false} = {}) {
    if(!anonymous&&!this.#token)throw Error('Current Wallet session required');
    const response = await fetch(this.#base + path, {method, headers:{...(anonymous ? {} : {Authorization:`Bearer ${this.#token}`}), ...headers}, body, redirect:'error', signal:AbortSignal.timeout(30_000)});
    return response;
  }
  async #json(path, options) {
    const response = await this.#request(path, options);
    const bytes = await readBounded(response, 1024 * 1024);
    let data;
    try { data = bytes.length ? JSON.parse(bytes.toString('utf8')) : null; } catch { throw Error('Invalid Cloud response'); }
    if (!response.ok) throw new CloudHTTPError(response.status, data);
    return data;
  }
  async currentSession() {
    const value=await this.#json('/session');
    if(value?.schemaVersion!==1||value.product!=='cloud'||typeof value.account!=='string'||!value.account||!Array.isArray(value.scopes)||value.scopes.some(s=>typeof s!=='string')||!Number.isFinite(Date.parse(value.issuedAt))||!Number.isFinite(Date.parse(value.expiresAt))||Date.parse(value.expiresAt)<=Date.parse(value.issuedAt))throw Error('Invalid current Cloud session response');
    return {schemaVersion:1,account:value.account,product:value.product,scopes:[...value.scopes],issuedAt:value.issuedAt,expiresAt:value.expiresAt};
  }
  async revokeSession() {
    const response=await this.#request('/session',{method:'DELETE'});
    if(response.status!==204){await response.body?.cancel();throw new CloudHTTPError(response.status,null);}
  }
  get(id) { return this.#json(`/objects/${part(id)}`); }
  list({parentId='',cursor='',limit=200}={}) {
    if(parentId)part(parentId);if(cursor)part(cursor);if(!Number.isSafeInteger(limit)||limit<1||limit>1000)throw Error('Bounded listing limit required');
    const query=new URLSearchParams({limit:String(limit)});if(parentId)query.set('parentId',parentId);if(cursor)query.set('cursor',cursor);
    return this.#json('/objects?'+query);
  }
  listTrash(){return this.#json('/objects?view=trash');}
  deletionStatus(){return this.#json('/deletions');}
  async requireOriginalTrashProtocol(){
    const response=await this.#request('/session');
    await response.body?.cancel();
    if(!response.ok)throw new CloudHTTPError(response.status,null);
    if(!response.headers.get('x-cloud-object-protocols')?.split(/\s+/).includes('trash-once-v1'))throw Error('Matching normal Cloud original-trash protocol unavailable; no mutation sent');
  }
  setTrashOriginal(id,trash,expectedRevision,requestID){
    if(typeof trash!=='boolean'||!KEY.test(requestID))throw Error('Exact original trash selection required');
    return this.#json(`/objects/${part(id)}/${trash?'trash':'restore'}`,{method:'POST',headers:{'X-Expected-Revision':revision(expectedRevision),'Idempotency-Key':requestID}});
  }
  versions(id) { return this.#json(`/objects/${part(id)}/versions`); }
  lookupOriginal(requestID) {
    if (!KEY.test(requestID)) throw Error('Invalid upload request identity');
    return this.#json(`/object-operations/${requestID}`);
  }
  async create(requestID, {name, mime = 'application/octet-stream', bytes, parentId = ''}) {
    if (!KEY.test(requestID)) throw Error('Invalid upload request identity');
    const owned = Buffer.from(bytes), expected = bindBytes(owned);
    try {
      const object = await this.#json('/objects', {method:'POST', headers:{'Content-Type':'application/json', 'Idempotency-Key':requestID}, body:JSON.stringify({kind:'file', name, mime, parentId, content:owned.toString('base64'), encryption:{clientSide:false}})});
      // A duplicate may return the current object after later edits. The immutable
      // original observation must still bind to the bytes originally submitted.
      const original = await this.lookupOriginal(requestID);
      if (original.outcome !== 'COMMITTED' || original.selection!==undefined || (original.parentId??'')!==parentId || (object.parentId??'')!==parentId || original.objectId !== object.id || original.deleted || !same(original.binding, expected)) throw Error('Original upload has no matching committed binding');
      return object;
    } catch (cause) {
      if (cause instanceof CloudHTTPError && cause.status >= 400 && cause.status < 500) throw cause;
      throw new CloudUnknownOutcome(requestID, cause);
    }
  }
  async createFolder(requestID,name,parentId=''){
    if(!KEY.test(requestID)||typeof name!=='string'||!name.trim())throw Error('Original folder request required');if(parentId)part(parentId);
    const object=await this.#json('/objects',{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':requestID},body:JSON.stringify({kind:'folder',name,parentId,content:'',encryption:{clientSide:false}})});
    const original=await this.lookupOriginal(requestID);
    if(original.outcome!=='COMMITTED'||original.selection!==undefined||original.deleted||original.objectId!==object.id||original.kind!=='folder'||object.kind!=='folder'||(object.parentId??'')!==parentId)throw Error('Original folder result differs');
    return object;
  }
  async put(id, expectedRevision, bytes, {requestID}={}) {
    if(requestID!==undefined&&!KEY.test(requestID))throw Error('Invalid upload request identity');
    const owned = Buffer.from(bytes), expected = bindBytes(owned);
    const object = await this.#json(`/objects/${part(id)}/content`, {method:'PUT', headers:{'Content-Type':'application/octet-stream', 'X-Expected-Revision':revision(expectedRevision), 'X-Content-SHA3-512':expected.sha3_512, 'X-Content-SHA512':expected.sha512,...(requestID?{'Idempotency-Key':requestID}:{})}, body:owned});
    if (!same(object.binding, expected)) throw Error('Version response binding mismatch; query the original object');
    return object;
  }
  async download(id, number) {
    // Pin a specific version before the content fetch; never silently follow a
    // concurrent current-version change or release unchecked bytes to disk.
    const object = await this.get(id);
    const selected = number === undefined ? object.version : Number(version(number));
    let expected = object.binding;
    if (selected !== object.version) {
      const history = await this.versions(id);
      expected = history.find(item => item.number === selected)?.binding;
    }
    binding(expected);
    const response = await this.#request(`/objects/${part(id)}/content?version=${version(selected)}`);
    return this.#verified(response, expected, selected);
  }
  async #verified(response, expected, selected) {
    if (!response.ok) throw new CloudHTTPError(response.status, null);
    if (response.status !== 200 || response.headers.has('content-range')) throw Error('Full object response required');
    const claimed = binding({bytes:response.headers.get('x-object-bytes'), sha3_512:response.headers.get('x-content-sha3-512'), sha512:response.headers.get('x-content-sha512')});
    if (!same(claimed, expected) || response.headers.get('x-object-version') !== String(selected)) throw Error('Object metadata changed');
    const bytes = await readBounded(response, MAX_BYTES);
    if (!same(bindBytes(bytes), expected)) throw Error('Downloaded object failed independent dual-digest verification');
    return bytes;
  }
  restore(id, number, expectedRevision,{requestID}={}) {
    if(requestID!==undefined&&!KEY.test(requestID))throw Error('Invalid upload request identity');
    return this.#json(`/objects/${part(id)}/versions/${version(number)}/restore`, {method:'POST', headers:{'X-Expected-Revision':revision(expectedRevision),...(requestID?{'Idempotency-Key':requestID}:{})}});
  }
  setShareAccess(id, target, allow, expectedRevision,{requestID}={}) {
    if (typeof allow !== 'boolean') throw Error('Explicit access decision required');
    if(requestID!==undefined&&!KEY.test(requestID))throw Error('Invalid original access request identity');
    return this.#json(`/objects/${part(id)}/access/${part(target)}`, {method:'PUT', headers:{'Content-Type':'application/json', 'X-Expected-Revision':revision(expectedRevision),...(requestID?{'Idempotency-Key':requestID}:{})}, body:JSON.stringify({allow})});
  }
  createLink(id, expiresAt) {
    return this.#json(`/objects/${part(id)}/links`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({role:'viewer', expiresAt})});
  }
  createOriginalLink(requestID,selection){return this.#originalLink(requestID,selection,false);}
  cancelOriginalLink(requestID,selection){return this.#originalLink(requestID,selection,true);}
  #originalLink(requestID,s,cancel){
    if(!KEY.test(requestID)||s?.action!=='link-create'||s.role!=='viewer'||!/^[0-9a-f]{64}$/.test(s.tokenSHA256))throw Error('Exact original capability selection required');
    const path=`/objects/${part(s.objectId)}/links/original/${requestID}${cancel?'/cancel':''}`;
    return this.#json(path,{method:'POST',headers:{'Content-Type':'application/json','X-Expected-Revision':revision(s.expectedRevision)},body:JSON.stringify({tokenSHA256:s.tokenSHA256,role:s.role,expiresAt:s.expiresAt})});
  }
  revokeLink(id, linkID) { return this.#json(`/objects/${part(id)}/links/${part(linkID)}`, {method:'DELETE'}); }
  async downloadLink(token, expected, number) {
    // The link is a bearer capability. A caller must supply the independently
    // selected version/binding; it is never obtained from an untrusted redirect.
    binding(expected); version(number);
    const response = await this.#request(`/shares/${part(token)}/content`, {anonymous:true});
    return this.#verified(response, expected, number);
  }
}

async function readBounded(response, maximum) {
  const length = response.headers.get('content-length');
  if (length !== null && (!UINT.test(length) || BigInt(length) > BigInt(maximum))) { await response.body?.cancel(); throw Error('Object response exceeds bound'); }
  if (!response.body) return Buffer.alloc(0);
  const reader = response.body.getReader(), chunks = []; let total = 0;
  try {
    while (true) {
      const {done, value} = await reader.read(); if (done) break;
      total += value.byteLength;
      if (total > maximum) throw Error('Object response exceeds bound');
      chunks.push(Buffer.from(value));
    }
  } catch (error) { await reader.cancel().catch(() => {}); throw error; }
  finally { reader.releaseLock(); }
  return Buffer.concat(chunks, total);
}
