import {constants} from 'node:fs';
import {open,lstat,rename,unlink} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';

const fail=()=>{throw Error('Private endpoint-bound Cloud session file required');};
const endpoint=value=>{const u=new URL(value);if(u.username||u.password||u.search||u.hash||u.pathname.replace(/\/$/,'')!=='/api/v1')fail();return u.href.replace(/\/$/,'');};
const privateStat=s=>s.isFile()&&(s.mode&0o077)===0&&s.nlink===1&&(!process.getuid||s.uid===process.getuid());
const tokenValid=t=>typeof t==='string'&&t.length>0&&t.length<=4096&&!/[\r\n\x00]/.test(t);
const parse=bytes=>{try{return JSON.parse(bytes);}catch{fail();}};
function visibleSession(value){
 const fields=['schemaVersion','account','product','scopes','issuedAt','expiresAt'];
 if(!value||Object.keys(value).some(k=>!fields.includes(k))||value.schemaVersion!==1||value.product!=='cloud'||typeof value.account!=='string'||!value.account||!Array.isArray(value.scopes)||value.scopes.some(x=>typeof x!=='string')||!Number.isFinite(Date.parse(value.issuedAt))||!Number.isFinite(Date.parse(value.expiresAt))||Date.parse(value.expiresAt)<=Date.parse(value.issuedAt))fail();
 return {schemaVersion:1,account:value.account,product:'cloud',scopes:[...value.scopes],issuedAt:value.issuedAt,expiresAt:value.expiresAt};
}
const revokeClaim=record=>({schemaVersion:1,endpoint:record.endpoint,tokenSHA256:createHash('sha256').update(record.token).digest('hex')});
async function existingClaim(path,record){
 let f;try{f=await open(path+'.revoke',constants.O_RDONLY|constants.O_NOFOLLOW);}catch(e){if(e.code==='ENOENT')return false;throw e;}
 try{const s=await f.stat();if(!privateStat(s)||s.size>1024)fail();const b=Buffer.alloc(1025);const {bytesRead}=await f.read(b,0,b.length,0);if(bytesRead>1024)fail();const saved=parse(b.subarray(0,bytesRead).toString('utf8'));if(JSON.stringify(saved)!==JSON.stringify(revokeClaim(record)))fail();return true;}
 finally{await f.close();}
}
async function parent(path){
 const p=dirname(resolve(path)),s=await lstat(p);
 if(!s.isDirectory()||s.isSymbolicLink()||(s.mode&0o077)!==0||process.getuid&&s.uid!==process.getuid())fail();
 return p;
}
async function syncParent(path){const f=await open(await parent(path),constants.O_RDONLY|constants.O_NOFOLLOW);try{await f.sync();}finally{await f.close();}}
async function writeNew(path,bytes){
 await parent(path);const f=await open(path,constants.O_CREAT|constants.O_EXCL|constants.O_WRONLY|constants.O_NOFOLLOW,0o600);
 try{await f.writeFile(bytes);await f.sync();}finally{await f.close();}await syncParent(path);
}
export async function readCloudSessionFile(path,base){
 await parent(path);const f=await open(path,constants.O_RDONLY|constants.O_NOFOLLOW);
 try{
  const s=await f.stat();if(!privateStat(s)||s.size>16384)fail();
  const buf=Buffer.alloc(16385);let size=0;
  while(size<buf.length){const r=await f.read(buf,size,buf.length-size,null);if(!r.bytesRead)break;size+=r.bytesRead;}
  if(size>16384)fail();const after=await lstat(path);
  if(after.dev!==s.dev||after.ino!==s.ino||!privateStat(after))fail();
  const record=parse(buf.subarray(0,size).toString('utf8'));
  if(!record||Object.keys(record).some(k=>!['schemaVersion','endpoint','state','token','session'].includes(k)))fail();
  if(record.schemaVersion!==1||record.endpoint!==endpoint(base)||!['ACTIVE','REVOKE_UNKNOWN','REVOKED','UNAVAILABLE'].includes(record.state)||!record.session||record.session.product!=='cloud')fail();
  if(['ACTIVE','REVOKE_UNKNOWN'].includes(record.state)&&!tokenValid(record.token))fail();
  if(['REVOKED','UNAVAILABLE'].includes(record.state)&&record.token!==undefined)fail();
  record.session=visibleSession(record.session);
  if(record.state==='ACTIVE'&&await existingClaim(path,record))return {...record,state:'REVOKE_UNKNOWN'};
  return record;
 }finally{await f.close();}
}
export async function saveCloudSessionFile(path,base,token,session){
 if(!tokenValid(token))fail();
 const record={schemaVersion:1,endpoint:endpoint(base),state:'ACTIVE',token,session:visibleSession(session)};
 await writeNew(path,JSON.stringify(record)+'\n');return record;
}
export async function replaceCloudSessionFile(path,record){
 // Existing path must remain a private original owned file. A temporary file
 // is fsynced before same-directory publication; capabilities never go to stdout.
 await readCloudSessionFile(path,record.endpoint);
 const temp=resolve(path)+'.'+randomUUID()+'.tmp';
 try{await writeNew(temp,JSON.stringify(record)+'\n');await rename(temp,path);await syncParent(path);}
 finally{await unlink(temp).catch(e=>{if(e.code!=='ENOENT')throw e;});}
}
export async function claimCloudSessionRevoke(path,record){
 const claim=revokeClaim(record);
 try{await writeNew(path+'.revoke',JSON.stringify(claim)+'\n');return true;}
 catch(error){if(error.code!=='EEXIST')throw error;}
 // Never delete/re-arm a surviving original claim, even after process death.
 // A preexisting claim permits only GET reconciliation of this same session.
 if(!await existingClaim(path,record))fail();
 return false;
}
