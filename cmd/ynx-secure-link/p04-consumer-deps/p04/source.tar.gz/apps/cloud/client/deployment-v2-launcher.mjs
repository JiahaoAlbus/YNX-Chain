import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';

// One dedicated Cloud Node launch lifetime. Embedded IDE consumers borrow
// their existing parent's admitted runtime instead of opening this launcher.
class OriginalCloudV2LaunchOwner {
  #original;#admission=null;#client=null;#first=null;#firstPresent=false;#retired=false;#childClose=null;#closing=null;#closed=false;#opening=null;#parentJoined=false;#parentClose=null;#continuing=null;
  constructor(original){this.#original=original;}
  remember(error){if(!this.#firstPresent){this.#firstPresent=true;this.#first=error;}return error;}
  open(){if(!this.#opening)this.#opening=this.#openOnce();return this.#opening;}
  async #openOnce(){
    if(this.#retired)throw this.remember(Error('Original Cloud launch retired'));
    const api=await import('@ynx-chain/wallet-auth/auth-runtime-image-source');
    if(this.#retired)throw this.remember(Error('Original Cloud launch retired before admission'));
    const result=await api.acquireOriginalAuthRuntimeImageAdmissionV1();
    this.#admission=result?.owner??null; // Own the original partial BEFORE error.
    if(!result||result.error!==null||!this.#admission)throw this.remember(result?.error??Error('Original runtime image admission not returned'));
    api.assertOriginalAuthRuntimeImageAdmissionOwnerV1(this.#admission);
    if(this.#retired)throw this.remember(Error('Original Cloud launch retired during admission'));
    await this.#admission.recheck();
    if(this.#retired)throw this.remember(Error('Original Cloud launch retired during recheck'));
    this.#admission.assertPreLoadCurrent();
    // Admission qualifies loading only. The original Native V5 source still
    // independently enforces HTTP scope; no JSON purpose becomes permission.
    this.#client=new CloudDeploymentV2Client(this.#original);
    await this.#client.openOriginalNativeTransport();
    if(this.#retired)throw this.remember(Error('Original Cloud launch retired during Native acquisition'));
  }
  client(){if(this.#firstPresent)throw this.#first;if(this.#retired||!this.#client)throw Error('Original Cloud launch is not ready');return this.#client;}
  async submitOriginalE11(prepared,options){
    const client=this.client();await this.#admission.recheck();this.#admission.assertPreLoadCurrent();
    if(this.#retired)throw Error('Original Cloud launch retired');
    return client.submitOriginalE11(prepared,options);
  }
  retire(){
    this.#retired=true;
    if(this.#client&&!this.#childClose){this.#childClose=this.#client.closeOriginalNativeTransport();this.#childClose.catch(error=>this.remember(error));}
    try{this.#admission?.retire();}catch(error){throw this.remember(error);}
  }
  async #closeParent(){
    if(!this.#parentJoined){await this.#admission?.join();this.#parentJoined=true;}
    // Select the same original close exactly once, even if it throws a falsy
    // cause synchronously. Further cleanup only awaits that retained result.
    if(!this.#parentClose)this.#parentClose=Promise.resolve().then(()=>this.#admission?.close());
    await this.#parentClose;
    this.#closed=true;
  }
  async close(){
    if(!this.#closing)this.#closing=(async()=>{
      this.retire();
      // Acquisition may still return an original partial after retirement.
      // Adopt it before the second retire and drain; never close the parent
      // while its original Native acquisition is still in flight.
      try{await this.#opening;}catch{}
      this.retire();
      try{await this.#childClose;}catch(error){throw this.remember(error);}
      // Keep the parent alive until its actual transport children have drained.
      try{await this.#closeParent();}catch(error){throw this.remember(error);}
    })();
    return this.#closing;
  }
  #childPhysicallyClosed(){
    if(!this.#client)return true;
    const state=this.#client.originalNativeTransportStatus();
    if(state.ownerAcquired)return state.nativeStatus?.physicalSourceClosed===true&&state.nativeStatus?.cleanupDebt===false;
    if(state.acquisitionPartialRetained)return state.partialPhysicallyClosed===true;
    return state.ownerAcquired===false&&state.acquisitionPartialRetained===false;
  }
  continueClose(){
    if(!this.#closing)return Promise.reject(Error('Close the original Cloud launch before continuing cleanup'));
    if(!this.#continuing){
      const pending=(async()=>{
        let failed=false,cause;
        try{await this.#closing;}catch(error){failed=true;cause=error;}
        if(!this.#closed){
          try{
            this.retire();
            if(this.#client){
              try{await this.#client.drainOriginalNativeTransport();}
              catch(error){this.remember(error);if(!this.#childPhysicallyClosed())throw error;}
              if(!this.#childPhysicallyClosed())throw Error('Original Cloud transport cleanup remains unconfirmed');
            }
            await this.#closeParent();
          }catch(error){this.remember(error);throw failed?cause:error;}
        }
        // Physical completion does not erase the original close failure.
        if(failed)throw cause;
      })();
      this.#continuing=pending;
      pending.then(()=>{if(this.#continuing===pending)this.#continuing=null;},()=>{if(this.#continuing===pending)this.#continuing=null;});
    }
    return this.#continuing;
  }
  statusDATA(){return {retired:this.#retired,closed:this.#closed,firstCausePresent:this.#firstPresent,firstCauseCode:this.#first?.code??null,admissionPartialRetained:!!this.#admission,clientCreated:!!this.#client,parentJoinCompleted:this.#parentJoined,parentCloseSelected:this.#parentClose!==null,SourceAdmission:false,NativeAdmission:false};}
}

export async function openOriginalCloudDeploymentV2Launcher(original){
  if(!(original instanceof YNXCloudClient)||original.product!=='cloud'||typeof original.getDeploymentRequestHeaders!=='function')throw Error('Original Cloud SDK deployment caller required');
  const owner=new OriginalCloudV2LaunchOwner(original);
  try{await owner.open();return {owner,error:null};}catch(error){owner.remember(error);return {owner,error};}
}
