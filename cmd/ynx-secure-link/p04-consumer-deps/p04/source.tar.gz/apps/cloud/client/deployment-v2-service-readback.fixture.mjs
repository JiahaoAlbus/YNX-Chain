// New normal-service read integration only. Go supplies PUBLIC Source/price
// fixtures; this client never acquires Native, signs, prepares an invoice or POSTs.
import assert from 'node:assert/strict';
import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';
let input='';for await(const b of process.stdin)input+=b;
const {base,selection,period,denied,nativeIntent,sourceOrder}=JSON.parse(input);
const sdk=new YNXCloudClient({endpoint:base,product:'cloud',getDeploymentRequestHeaders:async()=>({'X-P04-Public-Read':'PUBLIC_V2_ORIGINAL_READER'})});
const client=new CloudDeploymentV2Client(sdk);
if(denied){
 if(nativeIntent){
  await assert.rejects(client.nativeInvoiceIntentOriginal(selection,period,{productId:'cloud.ide-usage',sourceOrder}),e=>e.status===403);
  const path=`/ide/deployments/${selection.requestId}/billing/${period}/native-intent`;
  const headers=await sdk.deploymentHeaders('GET',path,selection.requestId,{});
  await assert.rejects(sdk.request(path,{headers,originalAuthorizationHeaders:headers,retry:1}),e=>e.status===403);
 }
 for(const action of [()=>client.lookupOriginal(selection),()=>client.logs(selection),()=>client.usage(selection),()=>client.billOriginal(selection,period)])await assert.rejects(action(),e=>e.status===403);
 process.stdout.write(JSON.stringify({revokedReadDenied:true,nativeAcquisition:client.originalNativeTransportStatus().acquisitionEntered}));
}else{
 const operation=await client.lookupOriginal(selection);
 if(nativeIntent){
  const original=await client.nativeInvoiceIntentOriginal(selection,period,{productId:'cloud.ide-usage',sourceOrder});
  assert.equal(original.request.sourceOrder,sourceOrder);assert.equal(original.original.manifestVersion,'2');
  assert.equal(original.request.amountAtoms,'6');assert.equal(original.request.storeId,undefined);
  assert.deepEqual(original.request.domainData,original.original.bill.request);
  await assert.rejects(client.nativeInvoiceIntentOriginal(selection,period,{productId:'cloud.ide-usage',sourceOrder:'cloud_usage_'+'0'.repeat(64)}));
 }
 const logs=await client.logs(selection);assert.equal(logs.runtimeLogs,'PUBLIC_ORIGINAL_LOG_READBACK_NOT_EXECUTION');
 const usage=await client.usage(selection);const stored=await client.usage(selection,{observe:false});assert.equal(stored.instanceId,operation.deploymentId);assert.equal(stored.latest.cpuMs,'1');
 const bill=await client.billOriginal(selection,period);
 assert.equal(bill.request.atoms,'6');assert.equal(bill.state,'PREPARED');assert.equal(bill.settlement,'NOT_VERIFIED');assert.notEqual(bill.schedule.projectId,selection.manifest.project.id);
 assert.equal(usage.instanceId,operation.deploymentId);assert.equal(client.originalNativeTransportStatus().acquisitionEntered,false);
 process.stdout.write(JSON.stringify({requestId:operation.requestId,manifestV2:operation.manifestV2,projectProjection:operation.catalogProjectId,instance:operation.deploymentId,bill:bill.request.billId,invoice:bill.invoiceId,atoms:bill.request.atoms,logsSource:logs.runtimeLogSource,usageSamples:Object.keys(stored.samples).length,nativeAcquisition:false}));
}
