import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {readFile} from 'node:fs/promises';
import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';

test('V2 original reads bind full manifest, Catalog mapping and actual units without acquiring Native or writing',async()=>{
 const fixture=JSON.parse(await readFile(new URL('./node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8'));
 let mode='good',op,record,bill,posts=0,gets=0;
 const server=createServer((req,res)=>{
  if(req.method!=='GET'){posts++;res.writeHead(405).end();return;}gets++;
  assert.equal(req.headers['x-public-read'],'PUBLIC_PROTOCOL_ONLY');
  let value=structuredClone(op);
  if(req.url.endsWith('/logs'))value={requestId:op.requestId,deploymentId:op.deploymentId,resourceId:op.resourceId,slotRevision:op.slotRevision,contentBinding:op.contentBinding,operationLogs:[],runtimeLogs:'PUBLIC original readback, not executed app log',runtimeLogSource:'original-resource'};
  else if(req.url.endsWith('/usage')||req.url.endsWith('/usage/records')){
   value=structuredClone(record);
   if(mode==='usage-instance')value.latest.instanceId='OTHER_INSTANCE';
   if(mode==='usage-stored')value.latest.storedBytes='999';
   if(mode==='usage-overflow')value.samples[Object.keys(value.samples)[0]].cpuNanos='18446744073709551616';
  }else if(req.url.includes('/billing/')){
   value=structuredClone(bill);
   if(mode.startsWith('bill-ref-'))value.schedule.projectRef[mode.slice(9)]='OTHER_VALUE';
   if(mode==='bill-catalog')value.schedule.projectId=op.manifestV2.project.id;
   if(mode==='bill-paid')value.state='PAID';
   if(mode==='bill-atoms')value.request.atoms='7';
   if(mode==='bill-window')value.schedule.effectiveUntil='2026-10-28T01:00:00Z';
   if(mode==='bill-asset')value.request.asset={...value.request.asset,unitVersion:'999'};
  }else{
   if(mode==='operation-tenant')value.manifestV2.project.tenant='OTHER_TENANT';
   if(mode==='operation-artifact')value.manifestV2.artifact.objectKey='OTHER_KEY';
  }
  res.setHeader('Content-Type','application/json');res.end(JSON.stringify(value));
 });server.listen(0,'127.0.0.1');await once(server,'listening');
 try{
  const original=new YNXCloudClient({endpoint:`http://127.0.0.1:${server.address().port}/api/v1`,product:'cloud',getDeploymentRequestHeaders:async()=>({'X-Public-Read':'PUBLIC_PROTOCOL_ONLY'})});
  const client=new CloudDeploymentV2Client(original),prepared=client.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:'req_p04_v2_original_readback_000001',expectedSlotRevision:'0'}),s=prepared.selection;
  op={requestId:s.requestId,manifestVersion:'2',manifestV2:structuredClone(s.manifest),manifestBinding:s.manifestBinding,contentBinding:s.contentBinding,expectedSlotRevision:'0',slotRevision:'1',state:'completed',exitCode:0,deploymentId:'PUBLIC_ORIGINAL_INSTANCE',resourceId:'PUBLIC_RESOURCE',catalogProjectId:'PUBLIC_DISTINCT_CATALOG_PROJECTION',runtimeUrl:'https://public-only.invalid/original'};
  const sample={instanceId:op.deploymentId,period:'2026-10-28',sampleSeq:'1793188800000000000',cpuNanos:'1000000',cpuMs:'1',memoryBytes:'4096',storedBytes:s.contentBinding.bytes,egressBytes:'10',observedAt:'2026-10-28T12:00:00Z'};
  record={requestId:s.requestId,instanceId:op.deploymentId,billingState:'PERIOD_BILLS',samples:{[`${sample.period}/${sample.sampleSeq}`]:sample},latest:sample};
  const asset={genesis:'d'.repeat(64),nativeChainId:'71',assetId:'PUBLIC_ASSET',unitVersion:'0'};
  const schedule={manifestVersion:'2',projectRef:s.manifest.project,projectId:op.catalogProjectId,resourceId:op.resourceId,id:'PUBLIC_TARIFF',revision:'1',registrationRef:'PUBLIC_REGISTERED',approvalRef:'PUBLIC_APPROVAL',merchant:'PUBLIC_MERCHANT',recipient:'PUBLIC_RECIPIENT',asset,effectiveFrom:'2026-10-28T00:00:00Z',effectiveUntil:'2026-10-29T00:00:00Z',meterRule:'cumulative-sample-end/UTC-day/ceil-total/v1',cpuNanos:{units:'1000000',atoms:'2'},egressBytes:{units:'10',atoms:'3'},peakStoredBytes:{units:'64',atoms:'1'}};
  bill={state:'PREPARED',settlement:'NOT_VERIFIED',invoiceId:'PUBLIC_ORIGINAL_INVOICE',originalOperation:'PUBLIC_ORIGINAL_OPERATION',request:{requestId:s.requestId,instanceId:op.deploymentId,period:sample.period,billId:'cloud_usage_'+'b'.repeat(64),scheduleId:schedule.id,scheduleRevision:schedule.revision,registrationRef:schedule.registrationRef,approvalRef:schedule.approvalRef,merchant:schedule.merchant,recipient:schedule.recipient,asset,atoms:'6',sampleBinding:s.contentBinding},schedule,aggregate:{period:sample.period,cpuNanos:'1000000',egressBytes:'10',peakStoredBytes:s.contentBinding.bytes,sampleBinding:s.contentBinding}};
  assert.equal((await client.logs(s)).runtimeLogSource,'original-resource');
  assert.equal((await client.usage(s)).instanceId,op.deploymentId);
  assert.equal((await client.usage(s,{observe:false})).latest.cpuMs,'1');
  assert.equal((await client.billOriginal(s,sample.period)).request.atoms,'6');
  const mutable=structuredClone(s),pending=client.lookupOriginal(mutable);mutable.manifest.project.tenant='MUTATED_DURING_READ';assert.equal((await pending).manifestV2.project.tenant,s.manifest.project.tenant);
  for(const next of ['operation-tenant','operation-artifact']){mode=next;await assert.rejects(client.lookupOriginal(s));}
  for(const next of ['usage-instance','usage-stored','usage-overflow']){mode=next;await assert.rejects(client.usage(s));}
  for(const next of ['bill-ref-realm','bill-ref-tenant','bill-ref-kind','bill-ref-id','bill-ref-rev','bill-catalog','bill-paid','bill-atoms','bill-window','bill-asset']){mode=next;await assert.rejects(client.billOriginal(s,sample.period),undefined,next);}
  const before=gets;await assert.rejects(client.billOriginal(s,sample.period,{prepare:true}),/read-only/);assert.equal(gets,before);
  assert.equal(posts,0);assert.equal(client.originalNativeTransportStatus().acquisitionEntered,false);assert.equal(client.originalNativeTransportStatus().SourceAdmission,false);
 }finally{await new Promise(resolve=>server.close(resolve));}
});
