// Real normal Cloud journal/HTTP + independent CLI. The upstream Go setup is
// explicitly PUBLIC Source/price/original-record data, not a real deployment.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';
import {recoverDeploymentReceipt,runDeploymentCommand} from './deployment-workflow.mjs';
let input='';for await(const b of process.stdin)input+=b;
const {base,selection,period,sourceOrder,denied,receiptRoot}=JSON.parse(input),file=join(receiptRoot,'original-v2.json');
const client=new CloudDeploymentV2Client(new YNXCloudClient({endpoint:base,product:'cloud',maxRetries:0,getDeploymentRequestHeaders:async()=>({'X-P04-Public-Read':'PUBLIC_V2_ORIGINAL_READER'})}));
const commands=[['status',file],['runtime',file],['logs',file],['usage-records',file],['inspect',file],['bill-original',file,period],['native-intent-original',file,period,'cloud.ide-usage',sourceOrder]];
if(denied){
 const before=await readFile(file);for(const args of commands)await assert.rejects(runDeploymentCommand(client,args),e=>e.status===403);
 assert.deepEqual(await readFile(file),before);assert.equal(client.originalNativeTransportStatus().acquisitionEntered,false);
 process.stdout.write(JSON.stringify({revokedReadDenied:true,receiptPreserved:true}));
}else{
 let first=false;try{await readFile(file);}catch(e){if(e.code!=='ENOENT')throw e;first=true;}
 if(first){
  await recoverDeploymentReceipt(client,selection,file);
 }
 const operation=await runDeploymentCommand(client,commands[0]);assert.equal(operation.state,'completed');
 const before=await readFile(file);
 const runtime=await runDeploymentCommand(client,commands[1]);assert.equal(runtime.deploymentId,operation.deploymentId);
 const logs=await runDeploymentCommand(client,commands[2]);assert.equal(logs.deploymentId,operation.deploymentId);
 const usage=await runDeploymentCommand(client,commands[3]);assert.equal(usage.instanceId,operation.deploymentId);
 const inspected=await runDeploymentCommand(client,commands[4]);assert.equal(inspected.operation.deploymentId,operation.deploymentId);
 const bill=await runDeploymentCommand(client,commands[5]);assert.equal(bill.request.atoms,'6');assert.equal(bill.settlement,'NOT_VERIFIED');
 const native=await runDeploymentCommand(client,commands[6]);assert.equal(native.request.sourceOrder,sourceOrder);assert.equal(native.request.amountAtoms,'6');
 assert.deepEqual(await readFile(file),before);
 const saved=JSON.parse(before);assert.equal(saved.schema,'cloud-original-deployment-receipt/2');assert.deepEqual(saved.selection,selection);assert.equal(saved.operation.manifestV2,undefined);assert.equal(saved.operation.logs,undefined);
 assert.equal(client.originalNativeTransportStatus().acquisitionEntered,false);
 await client.closeOriginalNativeTransport();
 process.stdout.write(JSON.stringify({requestId:operation.requestId,instance:operation.deploymentId,bill:bill.request.billId,atoms:bill.request.atoms,receiptVersion:2,readOnly:true}));
}
