#!/usr/bin/env node
import {constants} from 'node:fs';
import {open, rename, unlink} from 'node:fs/promises';
import {basename, dirname, resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {CloudObjectClient, bindBytes, bindShareTarget} from './object-client.mjs';
import {readCloudSessionFile,saveCloudSessionFile,replaceCloudSessionFile,claimCloudSessionRevoke} from './session-file.mjs';
import {originalLinkWorkflow,readOriginalLinkFile} from './link-workflow.mjs';

// Session stays in the process environment, never argv, receipt, output or logs.
const base = process.env.YNX_CLOUD_API;
const token = process.env.YNX_CLOUD_TOKEN;
const sessionFile = process.env.YNX_CLOUD_SESSION_FILE;
const [command, ...args] = process.argv.slice(2);
const MAX_BYTES = 8 * 1024 * 1024;

async function syncDirectory(path) { const dir = await open(dirname(resolve(path)), 'r'); try { await dir.sync(); } finally { await dir.close(); } }
async function exclusiveWrite(path, bytes) {
  const file = await open(path, constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY, 0o600);
  try { await file.writeFile(bytes); await file.sync(); } finally { await file.close(); }
  await syncDirectory(path);
}
async function replaceReceipt(path, value) {
  const temporary = `${path}.${randomUUID()}.tmp`;
  try { await exclusiveWrite(temporary, JSON.stringify(value)+'\n'); await rename(temporary,path); await syncDirectory(path); }
  finally { await unlink(temporary).catch(error => { if (error.code !== 'ENOENT') throw error; }); }
}
async function readFileBounded(path, limit, privateOwned=false) {
  const file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const stat = await file.stat();
    if (!stat.isFile() || stat.size > limit) throw Error('Regular file within size limit required');
    if(privateOwned&&((stat.mode&0o077)!==0||stat.nlink!==1||process.getuid&&stat.uid!==process.getuid()))throw Error('Private original upload receipt required');
    const body = Buffer.alloc(limit + 1); let size = 0;
    while (size < body.length) { const {bytesRead} = await file.read(body, size, body.length-size, null); if (!bytesRead) break; size += bytesRead; }
    if (size > limit) throw Error('File exceeds size limit');
    return body.subarray(0,size);
  } finally { await file.close(); }
}
async function readPrivateCapability(path) {
  const file = await open(path,constants.O_RDONLY|constants.O_NOFOLLOW);
  try {
    const stat=await file.stat();
    if(!stat.isFile() || stat.size>8192 || (stat.mode&0o077)!==0 || stat.nlink!==1 || (process.getuid && stat.uid!==process.getuid())) throw Error('Private capability file required');
    const buffer=Buffer.alloc(8193);let size=0;
    while(size<buffer.length){const {bytesRead}=await file.read(buffer,size,buffer.length-size,null);if(!bytesRead)break;size+=bytesRead;}
    if(size>8192)throw Error('Capability file exceeds bound');const bytes=buffer.subarray(0,size);
    let value;try{value=JSON.parse(bytes.toString('utf8'));}catch{throw Error('Invalid private capability file');}
    if(value.schemaVersion!==1 || value.endpoint!==new URL(base).href.replace(/\/$/,'') || typeof value.token!=='string' || !value.binding || !Number.isSafeInteger(value.version) || value.version<1)throw Error('Pinned capability belongs to another endpoint or version');
    if(value.kind==='original-link-capability'){
      const original=await readOriginalLinkFile(path);if(original.state!=='COMMITTED'||original.cancelRequested)throw Error('Original capability is unconfirmed or retired');
    }
    return value;
  } finally {await file.close();}
}
const print = data => process.stdout.write(JSON.stringify(data)+'\n');
const required = count => { if (args.length !== count) throw Error('Invalid arguments; see apps/cloud/client/README.md'); };
try {
  const linkOnly=command==='link-download';
  if(!linkOnly&&sessionFile&&token)throw Error('Choose the original session environment or its private file, not both');
  let saved=!linkOnly&&sessionFile?await readCloudSessionFile(sessionFile,base):undefined;
  const terminal=saved&&['REVOKED','UNAVAILABLE'].includes(saved.state);
  if(saved?.state==='REVOKE_UNKNOWN'&&!['session-status','session-revoke'].includes(command))throw Object.assign(Error('Reconcile the original session revocation before another file operation'),{outcome:'REVOKE_UNKNOWN'});
  if(terminal&&!['session-status','session-revoke'].includes(command))throw Error('Original Cloud session is unavailable');
  const client=terminal?undefined:new CloudObjectClient(base,linkOnly?undefined:saved?.token??token,{allowLoopbackHTTP:process.env.YNX_CLOUD_LOCAL_HTTP==='1',allowAnonymousLinks:linkOnly});
  const finishSession=async state=>{
    const {token:discard,...retained}=saved;
    saved={...retained,state};await replaceCloudSessionFile(sessionFile,saved);
    print({outcome:state,session:saved.session});
  };
  if(command==='session-save'){
    required(1);if(saved)throw Error('Session save requires the original session environment');
    const session=await client.currentSession();await saveCloudSessionFile(args[0],base,token,session);
    print({outcome:'SAVED',sessionFile:resolve(args[0]),session});
  }else if(command==='session-status'){
    required(0);
    if(terminal)print({outcome:saved.state,session:saved.session});
    else try{print({outcome:saved?.state==='REVOKE_UNKNOWN'?'REVOKE_UNKNOWN':'ACTIVE',session:await client.currentSession()});}
    catch(error){if(error.status===401&&saved)await finishSession('UNAVAILABLE');else throw error;}
  }else if(command==='session-revoke'){
    required(0);if(!saved)throw Error('A private session file is required to preserve original revocation outcome');
    if(terminal)print({outcome:saved.state,session:saved.session});
    else {
      const first=await claimCloudSessionRevoke(sessionFile,saved);
      if(first&&saved.state==='ACTIVE'){
        saved={...saved,state:'REVOKE_UNKNOWN'};await replaceCloudSessionFile(sessionFile,saved);
        try{await client.revokeSession();await finishSession('REVOKED');}
        catch(error){if(error.status===401)await finishSession('UNAVAILABLE');else throw Object.assign(Error('Original session revocation outcome is UNKNOWN; repeat only to query the same session'),{outcome:'REVOKE_UNKNOWN'});}
      }else{
        try{await client.currentSession();throw Object.assign(Error('Original session remains available; revocation outcome UNKNOWN and no DELETE was replayed'),{outcome:'REVOKE_UNKNOWN'});}
        catch(error){if(error.status===401)await finishSession('UNAVAILABLE');else throw error;}
      }
    }
  }else if(command==='list') {
    if(args.length>3)throw Error('list [PARENT_ID] [CURSOR] [LIMIT]');print(await client.list({parentId:args[0]??'',cursor:args[1]??'',limit:args[2]===undefined?200:Number(args[2])}));
  }else if(command==='trash-list'){
    required(0);print(await client.listTrash());
  }else if(command==='deletions'){
    required(0);print(await client.deletionStatus());
  } else if(command==='get') {
    required(1);print(await client.get(args[0]));
  } else if (command === 'upload') {
    if(args.length!==2&&args.length!==3)throw Error('upload FILE PRIVATE_RECEIPT [PARENT_ID]');
    const [source, receiptPath] = args, bytes = await readFileBounded(source,MAX_BYTES);
    const parentId=args[2]??'';
    const session=await client.currentSession();
    const intent = {schemaVersion:2, account:session.account, product:session.product, endpoint:new URL(base).href.replace(/\/$/, ''), name:basename(source), binding:bindBytes(bytes),parentId};
    let receipt;
    try { receipt = JSON.parse((await readFileBounded(receiptPath,8192,true)).toString('utf8')); }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      receipt = {...intent, requestID:randomUUID(), state:'PREPARED'};
      await exclusiveWrite(receiptPath,JSON.stringify(receipt)+'\n');
    }
    if (JSON.stringify(receipt.binding) !== JSON.stringify(intent.binding) || receipt.endpoint !== intent.endpoint || receipt.name !== intent.name || ![1,2].includes(receipt.schemaVersion)) throw Error('Receipt belongs to different upload bytes or endpoint');
    if(receipt.schemaVersion===2&&(receipt.account!==session.account||receipt.product!==session.product))throw Error('Receipt belongs to another original Cloud account or product');
    if((receipt.parentId??'')!==parentId)throw Error('Receipt belongs to another original parent folder');
    if(!['PREPARED','SUBMITTED','COMMITTED'].includes(receipt.state))throw Error('Invalid original upload receipt state');
    if(receipt.schemaVersion===1&&receipt.state==='PREPARED')throw Error('Legacy prepared receipt has no original account binding; preserve it for reconciliation');
    if (receipt.state !== 'PREPARED') {
      // Query only, including after connection loss, process death or restart.
      // A 404 is an observation, never authority to submit another operation.
      const observation = await client.lookupOriginal(receipt.requestID);
      if(observation.selection!==undefined)throw Error('Original request is a version mutation, not this upload');
      if((observation.parentId??'')!==parentId)throw Error('Original upload parent folder differs');
      if (observation.outcome === 'COMMITTED' && !observation.deleted) {
        if (JSON.stringify(observation.binding) !== JSON.stringify(intent.binding)) throw Error('Original result binding differs');
        await replaceReceipt(receiptPath,{...receipt,state:'COMMITTED',objectID:observation.objectId});
      }
      print(observation);
    } else {
      // This durable transition happens BEFORE any HTTP write. If interrupted,
      // the next invocation observes this same request instead of re-uploading.
      receipt.state = 'SUBMITTED'; await replaceReceipt(receiptPath,receipt);
      const object = await client.create(receipt.requestID,{name:intent.name,bytes,parentId});
      await replaceReceipt(receiptPath,{...receipt,state:'COMMITTED',objectID:object.id});
      print({outcome:'COMMITTED',requestID:receipt.requestID,objectID:object.id,revision:object.revision});
    }
  } else if(command==='folder-original'){
    if(args.length!==2&&args.length!==3)throw Error('folder-original NAME PRIVATE_RECEIPT [PARENT_ID]');
    const [name,receiptPath]=args,parentId=args[2]??'',session=await client.currentSession(),endpoint=new URL(base).href.replace(/\/$/,'');
    if(!name.trim()||/[\/\0]/.test(name))throw Error('Explicit folder name required');
    let receipt;
    try{receipt=JSON.parse((await readFileBounded(receiptPath,8192,true)).toString('utf8'));}catch(e){if(e.code!=='ENOENT')throw e;receipt={schemaVersion:1,kind:'folder-create',account:session.account,product:session.product,endpoint,name,parentId,requestID:randomUUID(),state:'PREPARED'};await exclusiveWrite(receiptPath,JSON.stringify(receipt)+'\n');}
    if(receipt.schemaVersion!==1||receipt.kind!=='folder-create'||receipt.account!==session.account||receipt.product!==session.product||receipt.endpoint!==endpoint||receipt.name!==name||receipt.parentId!==parentId||!['PREPARED','UNKNOWN','COMMITTED'].includes(receipt.state))throw Error('Receipt belongs to another original folder');
    if(receipt.state==='PREPARED'){receipt={...receipt,state:'UNKNOWN'};await replaceReceipt(receiptPath,receipt);try{await client.createFolder(receipt.requestID,name,parentId);}catch{throw Object.assign(Error('Original folder outcome UNKNOWN; query same request without recreating it'),{outcome:'UNKNOWN',requestID:receipt.requestID});}}
    const original=await client.lookupOriginal(receipt.requestID);if(original.outcome!=='COMMITTED'||original.selection!==undefined||original.kind!=='folder'||(original.parentId??'')!==parentId)throw Object.assign(Error('Original folder result unconfirmed'),{outcome:'UNKNOWN',requestID:receipt.requestID});
    if(!original.deleted){const object=await client.get(original.objectId);if(object.kind!=='folder'||(object.parentId??'')!==parentId)throw Error('Original folder scope changed');}
    await replaceReceipt(receiptPath,{...receipt,state:'COMMITTED',objectID:original.objectId});print(original);
  } else if (command === 'operation') {
    required(1); print(await client.lookupOriginal(args[0]));
  } else if (command === 'download') {
    if (args.length !== 2 && args.length !== 3) throw Error('download OBJECT_ID NEW_FILE [VERSION]');
    const bytes = await client.download(args[0], args[2] === undefined ? undefined : Number(args[2]));
    await exclusiveWrite(args[1],bytes); print({outcome:'VERIFIED',binding:bindBytes(bytes)});
  } else if (command === 'versions') {
    required(1); print(await client.versions(args[0]));
  } else if(command==='put-original'||command==='restore-original'){
    required(4);
    const put=command==='put-original',id=args[0],receiptPath=args[3];
    const expectedRevision=put?args[1]:args[2];
    if(!/^[1-9][0-9]*$/.test(expectedRevision)||BigInt(expectedRevision)>=18446744073709551615n)throw Error('Invalid expected original revision');
    const body=put?await readFileBounded(args[2],MAX_BYTES):undefined;
    const historical=put?undefined:Number(args[1]);
    if(!put&&(!Number.isSafeInteger(historical)||historical<1))throw Error('Invalid historical version');
    const selection={action:put?'put':'restore',objectId:id,expectedRevision,...(put?{contentBinding:bindBytes(body)}:{historicalVersion:historical})};
    const session=await client.currentSession(),endpoint=new URL(base).href.replace(/\/$/,'');
    let receipt;
    try{receipt=JSON.parse((await readFileBounded(receiptPath,8192,true)).toString('utf8'));}
    catch(error){
      if(error.code!=='ENOENT')throw error;
      const object=await client.get(id);
      if(object.revision!==expectedRevision)throw Error('Original expected revision is stale');
      const resultBinding=put?selection.contentBinding:(await client.versions(id)).find(v=>v.number===historical)?.binding;
      if(!resultBinding)throw Error('Original historical binding unavailable');
      receipt={schemaVersion:1,kind:'object-version-mutation',endpoint,account:session.account,product:session.product,selection,resultBinding,requestID:randomUUID(),state:'PREPARED'};
      await exclusiveWrite(receiptPath,JSON.stringify(receipt)+'\n');
    }
    if(receipt.schemaVersion!==1||receipt.kind!=='object-version-mutation'||receipt.endpoint!==endpoint||receipt.account!==session.account||receipt.product!==session.product||JSON.stringify(receipt.selection)!==JSON.stringify(selection)||!['PREPARED','UNKNOWN','COMMITTED'].includes(receipt.state))throw Error('Receipt belongs to another original version operation');
    if(receipt.state==='PREPARED'){
      receipt={...receipt,state:'UNKNOWN'};await replaceReceipt(receiptPath,receipt);
      try{if(put)await client.put(id,expectedRevision,body,{requestID:receipt.requestID});else await client.restore(id,historical,expectedRevision,{requestID:receipt.requestID});}
      catch{throw Object.assign(Error('Original version operation outcome UNKNOWN; query this same request without another mutation'),{outcome:'UNKNOWN',requestID:receipt.requestID});}
    }
    // Every entered original, including404 or UNKNOWN, is GET-only. Content
    // equality/current revision alone never proves which request committed.
    const observation=await client.lookupOriginal(receipt.requestID);
    if(observation.outcome!=='COMMITTED'||observation.objectId!==id||JSON.stringify(observation.selection)!==JSON.stringify(selection)||observation.revision!==String(BigInt(expectedRevision)+1n)||JSON.stringify(observation.binding)!==JSON.stringify(receipt.resultBinding))throw Object.assign(Error('Original version result remains UNKNOWN or differs from selection'),{outcome:'UNKNOWN',requestID:receipt.requestID});
    await replaceReceipt(receiptPath,{...receipt,state:'COMMITTED',originalVersion:observation.version,originalRevision:observation.revision});print(observation);
  } else if(command==='access-original'){
    required(5);
    const [id,target,decision,expectedRevision,receiptPath]=args;
    if(!['allow','deny'].includes(decision))throw Error('Explicit allow or deny required');
    if(!/^[1-9][0-9]*$/.test(expectedRevision)||BigInt(expectedRevision)>=18446744073709551615n)throw Error('Invalid expected original revision');
    const selection={action:'access',objectId:id,expectedRevision,targetSHA256:bindShareTarget(target),allow:decision==='allow'};
    const session=await client.currentSession(),endpoint=new URL(base).href.replace(/\/$/,'');
    if(!session.scopes.includes('permissions.manage'))throw Error('Current original permissions.manage scope required');
    let receipt;
    try{receipt=JSON.parse((await readFileBounded(receiptPath,8192,true)).toString('utf8'));}
    catch(error){
      if(error.code!=='ENOENT')throw error;
      const object=await client.get(id);if(object.revision!==expectedRevision)throw Error('Original expected revision is stale');
      receipt={schemaVersion:1,kind:'object-access-mutation',endpoint,account:session.account,product:session.product,selection,resultVersion:object.version??0,...(object.binding?{resultBinding:object.binding}:{}),requestID:randomUUID(),state:'PREPARED'};
      await exclusiveWrite(receiptPath,JSON.stringify(receipt)+'\n');
    }
    if(receipt.schemaVersion!==1||receipt.kind!=='object-access-mutation'||receipt.endpoint!==endpoint||receipt.account!==session.account||receipt.product!==session.product||JSON.stringify(receipt.selection)!==JSON.stringify(selection)||!['PREPARED','UNKNOWN','COMMITTED'].includes(receipt.state))throw Error('Receipt belongs to another original access operation');
    if(receipt.state==='PREPARED'){
      receipt={...receipt,state:'UNKNOWN'};await replaceReceipt(receiptPath,receipt);
      try{await client.setShareAccess(id,target,selection.allow,expectedRevision,{requestID:receipt.requestID});}
      catch{throw Object.assign(Error('Original access operation outcome UNKNOWN; query this same request without reapplying access'),{outcome:'UNKNOWN',requestID:receipt.requestID});}
    }
    const observation=await client.lookupOriginal(receipt.requestID);
    if(observation.outcome!=='COMMITTED'||observation.objectId!==id||JSON.stringify(observation.selection)!==JSON.stringify(selection)||observation.revision!==String(BigInt(expectedRevision)+1n)||(observation.version??0)!==receipt.resultVersion||JSON.stringify(observation.binding)!==JSON.stringify(receipt.resultBinding))throw Object.assign(Error('Original access result remains UNKNOWN or differs from selection'),{outcome:'UNKNOWN',requestID:receipt.requestID});
    await replaceReceipt(receiptPath,{...receipt,state:'COMMITTED',originalRevision:observation.revision});print({...observation,currentAccess:'NOT_ASSERTED'});
  } else if(command==='trash-original'||command==='restore-trash-original'){
    required(3);const [id,expectedRevision,receiptPath]=args;
    if(!/^[1-9][0-9]*$/.test(expectedRevision)||BigInt(expectedRevision)>=18446744073709551615n)throw Error('Invalid original trash revision');
    const session=await client.currentSession(),endpoint=new URL(base).href.replace(/\/$/,'');
    const selection={action:command==='trash-original'?'trash':'restore-trash',objectId:id,expectedRevision};
    let receipt,protocolChecked=false;
    try{receipt=JSON.parse((await readFileBounded(receiptPath,8192,true)).toString('utf8'));}catch(error){
      if(error.code!=='ENOENT')throw error;
      await client.requireOriginalTrashProtocol();protocolChecked=true;
      const object=await client.get(id);if(object.revision!==expectedRevision)throw Error('Original expected revision is stale');
      receipt={schemaVersion:1,kind:'object-trash-mutation',endpoint,account:session.account,product:session.product,selection,resultVersion:object.version??0,...(object.binding?{resultBinding:object.binding}:{}),requestID:randomUUID(),state:'PREPARED'};
      await exclusiveWrite(receiptPath,JSON.stringify(receipt)+'\n');
    }
    if(receipt.schemaVersion!==1||receipt.kind!=='object-trash-mutation'||receipt.endpoint!==endpoint||receipt.account!==session.account||receipt.product!==session.product||JSON.stringify(receipt.selection)!==JSON.stringify(selection)||!['PREPARED','UNKNOWN','COMMITTED'].includes(receipt.state))throw Error('Receipt belongs to another original trash operation');
    if(receipt.state==='PREPARED'){
      if(!protocolChecked)await client.requireOriginalTrashProtocol();
      receipt={...receipt,state:'UNKNOWN'};await replaceReceipt(receiptPath,receipt);
      try{await client.setTrashOriginal(id,selection.action==='trash',expectedRevision,receipt.requestID);}catch{throw Object.assign(Error('Original trash outcome UNKNOWN; query same request without replay'),{outcome:'UNKNOWN',requestID:receipt.requestID});}
    }
    const observation=await client.lookupOriginal(receipt.requestID);
    if(observation.outcome!=='COMMITTED'||observation.objectId!==id||JSON.stringify(observation.selection)!==JSON.stringify(selection)||observation.revision!==String(BigInt(expectedRevision)+1n)||(observation.version??0)!==receipt.resultVersion||JSON.stringify(observation.binding)!==JSON.stringify(receipt.resultBinding))throw Object.assign(Error('Original trash result remains UNKNOWN or differs'),{outcome:'UNKNOWN',requestID:receipt.requestID});
    await replaceReceipt(receiptPath,{...receipt,state:'COMMITTED',originalRevision:observation.revision});print({...observation,currentTrashState:'NOT_ASSERTED'});
  } else if (command === 'put') {
    required(3); print(await client.put(args[0],args[1],await readFileBounded(args[2],MAX_BYTES)));
  } else if (command === 'restore') {
    required(3); print(await client.restore(args[0],Number(args[1]),args[2]));
  } else if (command === 'access') {
    required(4); if (!['allow','deny'].includes(args[2])) throw Error('Explicit allow or deny required');
    print(await client.setShareAccess(args[0],args[1],args[2] === 'allow',args[3]));
  } else if (command === 'link-revoke') {
    required(2); const link = await client.revokeLink(args[0],args[1]); print({id:link.id,revokedAt:link.revokedAt});
  } else if(['link-prepare-original','link-create-original'].includes(command)){
    required(3);print(await originalLinkWorkflow(client,base,command==='link-prepare-original'?'prepare':'create',args[2],{objectID:args[0],expiresAt:args[1]}));
  } else if(['link-reconcile-original','link-cancel-original'].includes(command)){
    required(1);print(await originalLinkWorkflow(client,base,command==='link-cancel-original'?'cancel':'reconcile',args[0]));
  } else if (command === 'link-create') {
    // Capability token goes only to a new private file, never terminal output.
    required(3);
    const reserved = await open(args[2],constants.O_CREAT|constants.O_EXCL|constants.O_WRONLY,0o600);
    try {
      const object=await client.get(args[0]);
      const result = await client.createLink(args[0],args[1]);
      const capability={schemaVersion:1,endpoint:new URL(base).href.replace(/\/$/,''),objectID:object.id,version:object.version,binding:object.binding,...result};
      await reserved.writeFile(JSON.stringify(capability)+'\n'); await reserved.sync(); print({id:result.link.id,tokenFile:resolve(args[2]),version:object.version,binding:object.binding});
    }
    finally { await reserved.close(); await syncDirectory(args[2]); }
  } else if(command==='link-download') {
    required(2);const capability=await readPrivateCapability(args[0]);
    const bytes=await client.downloadLink(capability.token,capability.binding,capability.version);
    await exclusiveWrite(args[1],bytes);print({outcome:'VERIFIED',version:capability.version,binding:bindBytes(bytes)});
  } else throw Error('Commands: session-save, session-status, session-revoke, list, get, upload, operation, download, versions, put, put-original, restore, restore-original, access, access-original, link-create, link-download, link-revoke. See apps/cloud/client/README.md');
} catch (error) {
  // Do not serialize nested fetch errors, session headers or bearer link tokens.
  process.stderr.write(JSON.stringify({error:error.message,outcome:error.outcome,requestID:error.requestID,status:error.status})+'\n');
  process.exitCode = 1;
}
