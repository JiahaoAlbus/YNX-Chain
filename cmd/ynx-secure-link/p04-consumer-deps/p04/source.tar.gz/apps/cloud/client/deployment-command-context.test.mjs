import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,chmod,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';
import {runDeploymentCommand,recoverDeploymentReceipt} from './deployment-workflow.mjs';

test('normal command entry preserves the same caller context through status, runtime and logs',async t=>{
  const controller=new AbortController(),context=Object.freeze({signal:controller.signal});
  let operation,selection,proofs=0,requests=0;const billingStop=Error('PUBLIC billing context reached');
  const original=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async(request,actual)=>{
    proofs++;assert.equal(actual,context);assert.equal(actual.signal,controller.signal);
    if(request.path.includes('/billing/'))throw billingStop;
    return {'X-Public-Fixture':'NOT_AUTHORITY'};
  },fetch:async(url,options)=>{
    requests++;assert.equal(options.signal,controller.signal);
    if(new URL(url).pathname.endsWith('/logs'))return Response.json({requestId:selection.requestId,deploymentId:operation.deploymentId,resourceId:operation.resourceId,slotRevision:operation.slotRevision,contentBinding:operation.contentBinding,operationLogs:[],runtimeLogs:'PUBLIC DATA',runtimeLogSource:'original-resource'});
    if(new URL(url).pathname.endsWith('/usage')||new URL(url).pathname.endsWith('/usage/records')){
      const sample={instanceId:operation.deploymentId,period:'2026-11-07',sampleSeq:'1',cpuNanos:'1000000',cpuMs:'1',memoryBytes:'4096',storedBytes:selection.contentBinding.bytes,egressBytes:'0',observedAt:'2026-11-07T00:00:00Z'};
      return Response.json({requestId:selection.requestId,instanceId:operation.deploymentId,billingState:'UNPRICED',samples:{[`${sample.period}/${sample.sampleSeq}`]:sample},latest:sample});
    }
    return Response.json(operation);
  }});
  const fixture=JSON.parse(await readFile(new URL('./node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8'));
  const client=new CloudDeploymentV2Client(original);
  selection=client.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:'req_PUBLIC_COMMAND_CONTEXT_000001',expectedSlotRevision:'0'}).selection;
  operation={requestId:selection.requestId,manifestVersion:'2',manifestV2:selection.manifest,manifestBinding:selection.manifestBinding,contentBinding:selection.contentBinding,expectedSlotRevision:'0',slotRevision:'1',state:'completed',exitCode:0,deploymentId:'PUBLIC_INSTANCE',resourceId:'PUBLIC_RESOURCE',catalogProjectId:'PUBLIC_CATALOG',runtimeUrl:'https://public.invalid/app'};
  const dir=await mkdtemp(join(tmpdir(),'cloud-command-context-'));await chmod(dir,0o700);t.after(()=>rm(dir,{recursive:true,force:true}));
  const file=join(dir,'original.json');await writeFile(file,JSON.stringify({schema:'cloud-original-deployment-receipt/2',endpoint:client.endpoint,selection,state:'UNKNOWN'})+'\n',{mode:0o600});
  const options={signal:controller.signal,originalRequestContext:context};
  for(const command of ['status','reconcile','runtime','logs','inspect','usage','usage-records'])await runDeploymentCommand(client,[command,file],options);
  await recoverDeploymentReceipt(client,selection,join(dir,'recovered.json'),options);
  assert.ok(proofs>=4);assert.equal(proofs,requests);assert.equal(original.deploymentRequests.size,0);
  await assert.rejects(runDeploymentCommand(client,['bill-original',file,'2026-11-07'],options),e=>e===billingStop);
  await assert.rejects(runDeploymentCommand(client,['native-intent-original',file,'2026-11-07','cloud.ide-usage','cloud_usage_'+'b'.repeat(64)],options),e=>e===billingStop);
  const before=await readFile(file),entered=proofs;
  await assert.rejects(runDeploymentCommand(client,['status',file],{signal:controller.signal,originalRequestContext:Object.freeze({signal:new AbortController().signal})}),/context changed/);
  assert.equal(proofs,entered);assert.deepEqual(await readFile(file),before);
});
