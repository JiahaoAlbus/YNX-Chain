import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,chmod,readFile,writeFile,symlink,link,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {readCloudSessionFile,saveCloudSessionFile,claimCloudSessionRevoke,replaceCloudSessionFile} from './session-file.mjs';
import {CloudObjectClient} from './object-client.mjs';

test('anonymous capability mode cannot enter account or write APIs',async()=>{
 const client=new CloudObjectClient('https://cloud.example.invalid/api/v1',undefined,{allowAnonymousLinks:true});
 await assert.rejects(client.list(),/Current Wallet session required/);
 await assert.rejects(client.currentSession(),/Current Wallet session required/);
 await assert.rejects(client.revokeSession(),/Current Wallet session required/);
 assert.throws(()=>new CloudObjectClient('https://cloud.example.invalid/api/v1'),/Current Wallet session required/);
});

test('private session persistence binds endpoint, preserves surviving revoke claim and erases only acknowledged credential',async()=>{
 const root=await mkdtemp(join(tmpdir(),'p04-session-'));await chmod(root,0o700);
 const path=join(root,'current.json'),base='https://cloud.example.invalid/api/v1';
 const session={schemaVersion:1,account:'0x'+'a'.repeat(40),product:'cloud',scopes:['files.read'],issuedAt:'2026-11-01T00:00:00Z',expiresAt:'2026-11-01T01:00:00Z'};
 await saveCloudSessionFile(path,base,'PUBLIC_NOT_A_SESSION',session);
 assert.equal((await stat(path)).mode&0o077,0);
 await assert.rejects(saveCloudSessionFile(path,base,'PUBLIC_DIFFERENT',session),{code:'EEXIST'});
 await assert.rejects(readCloudSessionFile(path,'https://other.example.invalid/api/v1'));
 const original=await readCloudSessionFile(path,base);
 assert.equal(await claimCloudSessionRevoke(path,original),true);
 // Crash immediately after claim, before writing REVOKE_UNKNOWN or HTTP.
 const surviving=await readCloudSessionFile(path,base);assert.equal(surviving.state,'REVOKE_UNKNOWN');
 assert.equal(await claimCloudSessionRevoke(path,surviving),false);
 const {token,...terminal}=surviving;await replaceCloudSessionFile(path,{...terminal,state:'UNAVAILABLE'});
 assert.equal((await readCloudSessionFile(path,base)).token,undefined);
 assert.equal((await readFile(path,'utf8')).includes(token),false);
 const unsafe=join(root,'unsafe.json');await saveCloudSessionFile(unsafe,base,'PUBLIC_OTHER',session);await chmod(unsafe,0o644);
 await assert.rejects(readCloudSessionFile(unsafe,base));await chmod(unsafe,0o600);
 const sym=join(root,'symlink.json');await symlink(unsafe,sym);await assert.rejects(readCloudSessionFile(sym,base));
 const hard=join(root,'hardlink.json');await link(unsafe,hard);await assert.rejects(readCloudSessionFile(unsafe,base));
 const publicDir=join(root,'public');await mkdir(publicDir,{mode:0o755});await chmod(publicDir,0o755);
 await assert.rejects(saveCloudSessionFile(join(publicDir,'session.json'),base,'PUBLIC_OTHER',session));
 const large=join(root,'oversize.json');await writeFile(large,'x'.repeat(16385),{mode:0o600});await assert.rejects(readCloudSessionFile(large,base));
 const malformed=join(root,'malformed.json');await writeFile(malformed,'{"token":"PUBLIC_SECRET_FRAGMENT" "broken":}',{mode:0o600});
 await assert.rejects(readCloudSessionFile(malformed,base),e=>!e.message.includes('PUBLIC_SECRET_FRAGMENT')&&/Private endpoint/.test(e.message));
 const extra=join(root,'extra.json');await writeFile(extra,JSON.stringify({schemaVersion:1,endpoint:base,state:'UNAVAILABLE',session:{...session,tokenHash:'PUBLIC_NOT_ALLOWED'}}),{mode:0o600});await assert.rejects(readCloudSessionFile(extra,base));
});
