import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';
import {createDeploymentManifestV2DATA,decodeDeploymentV2Bind} from '@ynx-chain/open-protocol/deployment-v2';

test('actual sole SDK constructs and reads held V2 bytes without epoch/ref or legacy substitutions',async()=>{
  const fixture=JSON.parse(await readFile(new URL('./node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8'));
  const artifact=Buffer.from(fixture.actualHex,'hex'),input=structuredClone(fixture.manifest);
  const original=new YNXCloudClient({endpoint:'https://public-fixture.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>({'X-Public-Fixture':'NOT_REAL_PROOF'}),fetch:async()=>{throw Error('No network expected');}});
  const client=new CloudDeploymentV2Client(original);
  const prepared=client.prepare(input,artifact,{requestId:'req_p04_v2_original_fixture_0001',expectedSlotRevision:'0'});
  const payload=client.payloadOriginal(prepared);
  assert.equal(payload.toString('hex'),fixture.payloadHex);
  assert.equal(prepared.selection.manifest.publisherEpoch,'3');assert.equal(prepared.selection.manifest.publisher.rev,'7');
  assert.equal(prepared.selection.manifest.issuerEpoch,'11');assert.equal(prepared.selection.manifest.issuer.rev,'29');
  assert.notEqual(prepared.selection.manifest.issuer.realm,prepared.selection.manifest.realm);
  const hash=algorithm=>createHash(algorithm).update(payload).digest('hex');
  assert.deepEqual(prepared.selection.manifestBinding,{bytes:String(payload.length),sha3_512:hash('sha3-512'),sha512:hash('sha512')});
  input.env='other';artifact.fill(88);payload.fill(0);
  const restored=client.payloadOriginal(prepared);
  assert.equal(restored.toString('hex'),fixture.payloadHex);
  client.verifyReadback(prepared.selection,restored,Buffer.from(fixture.actualHex,'hex'));
  assert.throws(()=>client.verifyReadback(prepared.selection,restored,Buffer.from('X'.repeat(27))));
  assert.throws(()=>client.verifyReadback(prepared.selection,Buffer.from(JSON.stringify({projectId:'legacy',version:'1',contentDigest:'0'.repeat(64),publishPurpose:'deploy',targetEnvironment:'old',byteSize:27})),Buffer.from(fixture.actualHex,'hex')));
  const swapped=structuredClone(fixture.manifest);swapped.tenant='租户-B';for(const ref of [swapped.project,swapped.artifact.ref,swapped.publisher])ref.tenant=swapped.tenant;
  const other=createDeploymentManifestV2DATA(swapped,Buffer.from(fixture.actualHex,'hex'));
  assert.throws(()=>client.verifyReadback(prepared.selection,other.payloadOriginal,Buffer.from(fixture.actualHex,'hex')));
  const issuerSwap=structuredClone(fixture.manifest);issuerSwap.issuerEpoch='12';
  const changedIssuer=createDeploymentManifestV2DATA(issuerSwap,Buffer.from(fixture.actualHex,'hex'));
  assert.throws(()=>client.verifyReadback(prepared.selection,changedIssuer.payloadOriginal,Buffer.from(fixture.actualHex,'hex')));
  await assert.rejects(client.submitPrepared(prepared,new Uint8Array()),/approval bytes required/);
  assert.equal(original.deploymentRequests.size,0,'missing actual V2 approval submitted an operation');
  const actual=client.callerActualDATA(prepared);
  assert.equal(actual.payloadOriginal.toString('hex'),fixture.payloadHex);
  assert.equal(actual.actualArtifact.toString('hex'),fixture.actualHex);
  assert.equal(actual.actualPayloadBindE3.byteLength,152);assert.equal(actual.actualArtifactBindE3.byteLength,152);
  assert.deepEqual(decodeDeploymentV2Bind(actual.actualPayloadBindE3),prepared.selection.manifestBinding);
  assert.deepEqual(decodeDeploymentV2Bind(actual.actualArtifactBindE3),prepared.selection.contentBinding);
  assert.equal(Object.hasOwn(actual,'expectedPayloadOriginal'),false,'caller DATA impersonated independent Auth Source');
  actual.actualArtifact.fill(0);assert.equal(client.actualArtifactOriginal(prepared).toString('hex'),fixture.actualHex);
  const falseServer=new YNXCloudClient({endpoint:'https://public-fixture.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>({'X-Public-Fixture':'NOT_REAL_PROOF','x-ynx-product-session-proof-v5':'PUBLIC_PROTOCOL_FIXTURE_NOT_AUTHENTIC'}),fetch:async()=>Response.json({requestId:'req_p04_v2_wrong_receipt_0002',state:'running',binding:{projectId:'legacy'}})});
  const falseClient=new CloudDeploymentV2Client(falseServer);
  const pending=falseClient.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:'req_p04_v2_wrong_receipt_0002',expectedSlotRevision:'0'});
  await assert.rejects(falseClient.submitPrepared(pending,Buffer.from('PUBLIC_NOT_REAL_V2_APPROVAL')),error=>error.operationRequestId===pending.selection.requestId);
});

test('normal SDK E11 public result consumption retains partials and exact originals without signer custody',async()=>{
  if(process.env.YNX_CLOUD_EXPECT_NORMAL_SDK==='1')assert.equal(typeof(await import('@ynx-chain/wallet-auth/original-http-binary-v5-client')).openOriginalHTTPBinaryClientV5,'function','actual sole normal SDK package was not supplied');
  const fixture=JSON.parse(await readFile(new URL('./node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8'));
  const fixtureMember=Buffer.concat([Buffer.from('PUBLIC_NOT_A_REAL_SIGNATURE'),Buffer.from([0,255])]);
  let posts=0,proofs=0;
  const original=new YNXCloudClient({endpoint:'https://public-fixture.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>{proofs++;return {'x-ynx-product-session-proof-v5':'PUBLIC_HEADER_IS_NOT_A_NATIVE_SOURCE'};},fetch:async()=>{posts++;throw Error('Direct JS sender must not run');}});
  const client=new CloudDeploymentV2Client(original);
  const prepare=id=>client.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:id,expectedSlotRevision:'0'});
  assert.throws(()=>prepare('HISTORICAL_OPERATION_00001'),/New V2 request identity/);
  assert.equal(client.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:'req_new_rollback_000001',expectedSlotRevision:'7',rollbackTo:'HISTORICAL_OPERATION_00001'}).selection.rollbackTo,'HISTORICAL_OPERATION_00001');
  const result=prepared=>({phase:'RETURNED',payloadOriginal:client.payloadOriginal(prepared).toString('base64url'),payloadBinding:structuredClone(prepared.selection.manifestBinding),artifactBinding:structuredClone(prepared.selection.contentBinding),sourceCurrentOriginal:'PUBLIC_SOURCE_ORIGINAL_BYTES',reservationOriginal:'PUBLIC_ORIGINAL_RESERVATION',memberOriginal:fixtureMember.toString('base64url'),coreStatus:0,cleanupStatus:2,reportedStatus:0,signed:true,sourceGranted:false,nativeAdmission:false,deployed:false});
  // This fixture exercises transport DATA only; it cannot prove a signature.
  for(const [name,change] of [
    ['cleanup-none',r=>{r.cleanupStatus=0;}],['native-unknown',r=>{r.reportedStatus=8;}],
    ['late-fence',r=>{r.phase='TERMINAL_PUBLIC_PARTIAL';r.signed=false;}],
    ['payload-swap',r=>{r.payloadOriginal=Buffer.from('other').toString('base64url');}],
    ['artifact-swap',r=>{r.artifactBinding.sha512='0'.repeat(128);}],
    ['claimed-admission',r=>{r.sourceGranted=true;}],['missing-source',r=>{r.sourceCurrentOriginal='';}],
    ['oversized-member',r=>{r.memberOriginal=Buffer.alloc(98305,255).toString('base64url');}],
  ]){
    const prepared=prepare('req_p04_native_partial_'+name.replaceAll('-','_')),partial=result(prepared);change(partial);
    assert.throws(()=>client.captureOriginalE11Result(prepared,partial),error=>error.retryAllowed===false&&error.operationRequestId===prepared.selection.requestId&&error.partial.phase===partial.phase);
    const retained=client.originalE11Result(prepared);
    assert.deepEqual(retained.publicResult,partial);assert.equal(retained.readyForTransport,false);
    retained.publicResult.sourceCurrentOriginal='MUTATED';assert.equal(client.originalE11Result(prepared).publicResult.sourceCurrentOriginal,partial.sourceCurrentOriginal);
    await assert.rejects(client.submitOriginalE11(prepared),/final result required/);
    assert.throws(()=>client.captureOriginalE11Result(prepared,result(prepared)),/already retained/);
  }
  assert.equal(posts,0);assert.equal(proofs,0);assert.equal(original.deploymentRequests.size,0);
  const prepared=prepare('req_p04_native_transport_original_01'),publicResult=result(prepared);
  let getterCalls=0;const accessor={...publicResult};Object.defineProperty(accessor,'signed',{enumerable:true,get(){getterCalls++;return true;}});
  assert.throws(()=>client.captureOriginalE11Result(prepared,accessor),/schema/);assert.equal(getterCalls,0);
  const captured=client.captureOriginalE11Result(prepared,publicResult);
  publicResult.payloadOriginal='changed';publicResult.payloadBinding.bytes='0';
  assert.equal(captured.readyForTransport,true);assert.equal(captured.independentlyVerifiedByCloud,false);assert.equal(captured.sourceGranted,false);
  const member=fixtureMember;
  const [firstWire,secondWire]=await Promise.all([client.captureMultipartOriginal(prepared,member),client.captureMultipartOriginal(prepared,member)]);
  assert.equal(firstWire.contentType,secondWire.contentType);assert.ok(firstWire.bodyOriginal.equals(secondWire.bodyOriginal));
  firstWire.bodyOriginal.fill(0);assert.ok((await client.captureMultipartOriginal(prepared,member)).bodyOriginal.equals(secondWire.bodyOriginal));
  await assert.rejects(client.captureMultipartOriginal(prepared,Buffer.from('OTHER_MEMBER')),/Member changed/);
  const parsed=await new Response(secondWire.bodyOriginal,{headers:{'Content-Type':secondWire.contentType}}).formData();
  assert.ok(Buffer.from(await parsed.get('approval').arrayBuffer()).equals(member),'binary raw Member converted to text');
  assert.equal(parsed.get('manifest').size,Buffer.from(fixture.payloadHex,'hex').length);
  await assert.rejects(client.submitOriginalE11(prepared),error=>error.status===503&&error.retryAllowed===false&&error.operationRequestId===prepared.selection.requestId);
  const nativeStatus=client.originalNativeTransportStatus();
  assert.equal(nativeStatus.acquisitionEntered,true);assert.equal(nativeStatus.acquisitionFailed,true);assert.equal(nativeStatus.ownerAcquired,false);
  if(process.env.YNX_CLOUD_EXPECT_NORMAL_SDK==='1')assert.notEqual(nativeStatus.acquisitionFailureCode,'ERR_MODULE_NOT_FOUND','normal public module failed before Native source acquisition');
  await assert.rejects(client.submitOriginalE11(prepared),error=>error.status===503&&error.retryAllowed===false);
  assert.equal(posts,0,'JS/header callback bypassed the original Native peer');assert.equal(proofs,0);assert.equal(original.deploymentRequests.size,0);
  assert.equal(client.originalNativeRequestDATA(prepared),null);
  await client.closeOriginalNativeTransport();await client.closeOriginalNativeTransport();
  assert.equal(client.originalNativeTransportStatus().retired,true);
  await assert.rejects(client.submitOriginalE11(prepared),error=>error.status===503);

});
