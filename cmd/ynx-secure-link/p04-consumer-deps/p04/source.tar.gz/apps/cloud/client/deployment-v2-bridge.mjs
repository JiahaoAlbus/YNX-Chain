// Private DATA bridge invoked by Cloud's existing Go service. This does not
// execute uploaded artifact code, verify signatures, read accounts or allocate.
import {decodeDeploymentManifestV2DATA,assertDeploymentArtifactV2DATA,bindDeploymentV2Bytes} from '@ynx-chain/open-protocol/deployment-v2';
const max=90*1024*1024;let size=0;const chunks=[];
try{
  for await(const chunk of process.stdin){size+=chunk.length;if(size>max)throw Error('DATA input bound');chunks.push(chunk);}
  const input=JSON.parse(Buffer.concat(chunks).toString('utf8'));
  const payload=Buffer.from(input.payloadOriginal,'base64'),artifact=Buffer.from(input.artifact,'base64');
  if(payload.toString('base64')!==input.payloadOriginal||artifact.toString('base64')!==input.artifact)throw Error('Noncanonical DATA bytes');
  const manifest=decodeDeploymentManifestV2DATA(payload,input.expectedBinding);
  const contentBinding=assertDeploymentArtifactV2DATA(payload,artifact);
  process.stdout.write(JSON.stringify({manifest,manifestBinding:bindDeploymentV2Bytes(payload),contentBinding}));
}catch{
  // Do not echo manifest, source identifiers, artifact, approval or environment.
  process.stderr.write('V2 deployment DATA rejected\n');process.exitCode=1;
}
