import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,chmod,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createServer} from 'node:http';
import {YNXCloudClient} from '../sdk/index.js';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';
import {openOriginalCloudDeploymentCommandSession,runOriginalCloudDeploymentCommand} from './deployment-command-session.mjs';

async function selected(t,original){
 const root=await mkdtemp(join(tmpdir(),'cloud-command-session-'));await chmod(root,0o700);t.after(()=>rm(root,{recursive:true,force:true}));
 const fixture=JSON.parse(await readFile(new URL('./node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8').catch(()=>readFile(new URL('../../../node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8')));
 const c=new CloudDeploymentV2Client(original),prepared=c.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:'req_command_session_000001',expectedSlotRevision:'0'});
 const selection=prepared.selection,file=join(root,'receipt.json');
 await writeFile(file,JSON.stringify({schema:'cloud-original-deployment-receipt/2',endpoint:c.endpoint,selection,state:'UNKNOWN'})+'\n',{mode:0o600});
 const op={requestId:selection.requestId,manifestVersion:'2',manifestV2:selection.manifest,manifestBinding:selection.manifestBinding,contentBinding:selection.contentBinding,expectedSlotRevision:'0',slotRevision:'1',state:'running',deploymentId:'PUBLIC_INSTANCE',resourceId:'PUBLIC_RESOURCE',catalogProjectId:'PUBLIC_CATALOG',runtimeUrl:'https://public.invalid/original'};
 return {file,op};
}

test('normal same-process command entry selects original receipt and cold reopens with GET only',async t=>{
 let op;const methods=[];
 const server=createServer((req,res)=>{methods.push(req.method);res.setHeader('Content-Type','application/json');res.end(JSON.stringify(op));});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>server.close(r)));
 let proofs=0;
 const original=new YNXCloudClient({endpoint:`http://127.0.0.1:${server.address().port}/api/v1`,product:'cloud',getDeploymentRequestHeaders:async request=>{proofs++;assert.equal(request.method,'GET');return {'X-Public-Fixture':'NOT_AUTHORITY'};}});
 const input=await selected(t,original);op=input.op;
 const owner=openOriginalCloudDeploymentCommandSession(original),args=['status',input.file],pending=owner.run(args);args[0]='submit';
 assert.equal((await pending).requestId,op.requestId);await owner.close();
 assert.equal(owner.statusDATA().NativeAcquired,false);assert.equal(owner.statusDATA().pendingWaits,0);
 assert.equal((await runOriginalCloudDeploymentCommand(original,['reconcile',input.file])).requestId,op.requestId);
 assert.equal(JSON.parse(await readFile(input.file)).state,'OBSERVED');assert.deepEqual(methods,['GET','GET']);assert.equal(proofs,2);
 assert.equal(original.deploymentRequests.size,0);
});

test('close cancels a waiting original proof without changing the receipt or entering HTTP',async t=>{
 let entered,release,fetches=0;
 const reached=new Promise(r=>{entered=r;}),wait=new Promise(r=>{release=r;});
 const original=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>{entered();await wait;return {'X-Public-Fixture':'NOT_AUTHORITY'};},fetch:async()=>{fetches++;throw Error('must not enter');}});
 const {file}=await selected(t,original),before=await readFile(file),owner=openOriginalCloudDeploymentCommandSession(original);
 const pending=owner.run(['status',file]),rejected=assert.rejects(pending,/wait cancelled/);
 await reached;await owner.close();await owner.close();await rejected;release();await new Promise(r=>setImmediate(r));
 assert.deepEqual(await readFile(file),before);assert.equal(fetches,0);assert.equal(owner.statusDATA().remoteCancellation,false);assert.equal(owner.statusDATA().pendingWaits,0);
 await assert.rejects(owner.run(['status',file]),/retired/);
});

test('immediate close and pre-aborted caller cannot enter a receipt or proof',async()=>{
 let entered=0;
 const original=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>{entered++;throw Error('must not enter');}});
 const owner=openOriginalCloudDeploymentCommandSession(original),pending=owner.run(['status','/no-receipt-needed']),rejected=assert.rejects(pending,/wait cancelled/);
 await owner.close();await rejected;
 const other=openOriginalCloudDeploymentCommandSession(original),controller=new AbortController(),reason=Error('PUBLIC cancelled');controller.abort(reason);
 await assert.rejects(other.run(['status','/no-receipt-needed'],{signal:controller.signal}),e=>e===reason);await other.close();assert.equal(entered,0);
});

test('ordinary object authentication and submission commands cannot enter the read command session',async()=>{
 const ordinary=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getAccessToken:async()=>'PUBLIC_NOT_AUTHORITY'});
 assert.throws(()=>openOriginalCloudDeploymentCommandSession(ordinary),/deployment read caller/);
 const original=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>{throw Error('must not enter');}}),owner=openOriginalCloudDeploymentCommandSession(original);
 await assert.rejects(owner.run(['submit','/no-receipt-needed']),/read-only/);await owner.close();
});
