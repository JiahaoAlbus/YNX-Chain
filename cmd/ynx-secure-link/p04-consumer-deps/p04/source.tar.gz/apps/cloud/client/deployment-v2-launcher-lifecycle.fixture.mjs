// Test-only admission/transport stand-ins. This verifies Cloud close ordering,
// never Root qualification, signing, independent verification or deployment.
import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {YNXCloudClient} from '../sdk/index.js';
const mode=process.argv[2]??'normal';
const calls=[];let checks=0,release,entered,childClosed=false,childPending=true,joinPending=true;
const firstJoinCause=mode==='continue-join-undefined'?undefined:false;
const waiting=new Promise(r=>{release=r;});
const reached=new Promise(r=>{entered=r;});
const admission={async recheck(){calls.push('recheck');if(++checks===2){entered();await waiting;}},assertPreLoadCurrent(){calls.push('preload');},retire(){calls.push('parent-retire');if(mode==='parent-retire-false')throw false;},async join(){calls.push('parent-join');if(mode==='parent-join-false')throw false;if(mode==='continue-child-join'&&joinPending)throw Error('PUBLIC later join cause');if(mode.startsWith('continue-join')&&joinPending)throw firstJoinCause;},async close(){calls.push('parent-close');if(mode==='continue-parent-close')throw false;}};
const native={status(){return {closed:childClosed,physicalSourceClosed:childClosed,cleanupDebt:!childClosed};},async close(){calls.push('child-close');if(mode==='child-false'||mode.startsWith('continue-child'))throw false;childClosed=true;},async drainOriginal(){calls.push('child-drain');if(mode.startsWith('continue-child')&&mode!=='continue-child-unconfirmed'){if(!childPending)childClosed=true;throw false;}}};
globalThis.__cloudLauncherLifecycleTest={admission,native,failNative:mode==='native-false',opens:0};
const sources=new Map([
 ['@ynx-chain/wallet-auth/auth-runtime-image-source',`const a=globalThis.__cloudLauncherLifecycleTest.admission;export async function acquireOriginalAuthRuntimeImageAdmissionV1(){return {owner:a,error:null}};export function assertOriginalAuthRuntimeImageAdmissionOwnerV1(o){if(o!==a)throw Error('wrong test owner')}`],
 ['@ynx-chain/wallet-auth/original-http-binary-v5-client',`export async function openOriginalHTTPBinaryClientV5(){globalThis.__cloudLauncherLifecycleTest.opens++;if(globalThis.__cloudLauncherLifecycleTest.failNative)throw false;return globalThis.__cloudLauncherLifecycleTest.native}`],
]);
const hook=registerHooks({resolve(specifier,context,next){if(sources.has(specifier))return {url:'cloud-test:'+specifier,shortCircuit:true};return next(specifier,context);},load(url,context,next){if(url.startsWith('cloud-test:'))return {format:'module',source:sources.get(url.slice(11)),shortCircuit:true};return next(url,context);}});
try{
 const {openOriginalCloudDeploymentV2Launcher}=await import('./deployment-v2-launcher.mjs');
 let requests=0;
 const sdk=new YNXCloudClient({endpoint:'https://public.invalid/api/v1',product:'cloud',getDeploymentRequestHeaders:async()=>{requests++;throw Error('must not call');},fetch:async()=>{requests++;throw Error('must not call');}});
 const result=await openOriginalCloudDeploymentV2Launcher(sdk);
 if(mode.startsWith('continue-')){
  assert.equal(result.error,null);
  if(mode==='continue-before-close'){
   await assert.rejects(result.owner.continueClose(),/Close the original/);assert.equal(calls.includes('parent-retire'),false);
   await result.owner.close();await result.owner.continueClose();
  }else{
   const expected=mode.startsWith('continue-join')?firstJoinCause:false;
   await assert.rejects(result.owner.close(),e=>e===expected);assert.equal(result.owner.statusDATA().closed,false);
   const first=result.owner.continueClose(),same=result.owner.continueClose();assert.equal(first,same);
   if(mode==='continue-child-unconfirmed'){
    await assert.rejects(first,e=>e===false);await assert.rejects(result.owner.continueClose(),e=>e===false);
    assert.equal(result.owner.statusDATA().closed,false);assert.equal(calls.includes('parent-join'),false);
   }else if(mode==='continue-child'||mode==='continue-child-join'){
    await assert.rejects(first,e=>e===false);assert.equal(calls.includes('parent-join'),false);
    childPending=false;await assert.rejects(result.owner.continueClose(),e=>e===false);
    if(mode==='continue-child-join'){
     assert.equal(result.owner.statusDATA().closed,false);assert.equal(calls.includes('parent-close'),false);
     joinPending=false;await assert.rejects(result.owner.continueClose(),e=>e===false);
    }
    assert.equal(result.owner.statusDATA().closed,true);
   }else if(mode.startsWith('continue-join')){
    await assert.rejects(first,e=>e===expected);assert.equal(calls.includes('parent-close'),false);
    joinPending=false;await assert.rejects(result.owner.continueClose(),e=>e===expected);assert.equal(result.owner.statusDATA().closed,true);
   }else{
    await assert.rejects(first,e=>e===false);await assert.rejects(result.owner.continueClose(),e=>e===false);assert.equal(result.owner.statusDATA().closed,false);
   }
   assert.equal(result.owner.statusDATA().firstCausePresent,true);
   assert.throws(()=>result.owner.client(),e=>e===expected);
   await assert.rejects(result.owner.close(),e=>e===expected);
  }
  assert.equal(globalThis.__cloudLauncherLifecycleTest.opens,1);assert.equal(calls.filter(c=>c==='child-close').length,1);
  assert.equal(calls.filter(c=>c==='parent-close').length,mode==='continue-child-unconfirmed'?0:1);assert.equal(requests,0);
 }else if(mode==='native-false'){
  assert.equal(result.error,false);assert.equal(result.owner.statusDATA().firstCausePresent,true);
  assert.throws(()=>result.owner.client(),e=>e===false);await result.owner.close();
 }else if(mode!=='normal'){
  assert.equal(result.error,null);
  await assert.rejects(result.owner.close(),e=>e===false);
  await assert.rejects(result.owner.close(),e=>e===false);
  assert.equal(result.owner.statusDATA().firstCausePresent,true);assert.equal(result.owner.statusDATA().closed,false);
  assert.throws(()=>result.owner.client(),e=>e===false);
  assert.equal(calls.includes('parent-close'),false);
  if(mode==='child-false')assert.equal(calls.includes('parent-join'),false);
 }else{
 assert.equal(result.error,null);
 const pending=result.owner.submitOriginalE11({});
 const rejected=assert.rejects(pending,/retired/);
 await reached;await result.owner.close();release();await rejected;
 await result.owner.close();
 assert.equal(requests,0);assert.equal(sdk.deploymentRequests.size,0);
 assert.equal(calls.filter(c=>c==='child-close').length,1);
 assert.equal(calls.filter(c=>c==='parent-close').length,1);
 assert.ok(calls.indexOf('child-close')<calls.indexOf('parent-close'));
 assert.equal(result.owner.statusDATA().closed,true);
 assert.throws(()=>result.owner.client(),/not ready/);
 }
 console.log(JSON.stringify({testStandIns:true,calls,requests,RootAdmission:false,SourceAdmission:false,realSignature:false,deployed:false}));
}finally{hook.deregister();delete globalThis.__cloudLauncherLifecycleTest;}
