import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {CloudObjectClient} from './object-client.mjs';

test('independent download rejects corrupt, partial, oversized and redirected content before returning bytes', async () => {
  const bytes = Buffer.from('PUBLIC verified bytes');
  const expected = {bytes:String(bytes.length),sha3_512:createHash('sha3-512').update(bytes).digest('hex'),sha512:createHash('sha512').update(bytes).digest('hex')};
  let mode = 'good', forwarded = 0;
  const target = createServer((req,res) => { forwarded++; res.end('unexpected'); });
  target.listen(0,'127.0.0.1'); await once(target,'listening');
  const server = createServer((req,res) => {
    if (req.url === '/api/v1/objects/public_object') {
      res.setHeader('Content-Type','application/json'); res.end(JSON.stringify({id:'public_object',version:1,revision:'1',binding:expected})); return;
    }
    if (mode === 'redirect') { res.writeHead(302,{Location:`http://127.0.0.1:${target.address().port}/capture`}); res.end(); return; }
    res.setHeader('X-Object-Bytes',mode === 'noncanonical' ? '000'+expected.bytes : expected.bytes);
    res.setHeader('X-Content-SHA3-512',mode === 'wrongSHA3' ? '0'.repeat(128) : expected.sha3_512);
    res.setHeader('X-Content-SHA512',expected.sha512);
    res.setHeader('X-Object-Version',mode === 'wrongVersion' ? '2' : '1');
    if (mode === 'partial') res.writeHead(206,{'Content-Range':`bytes 0-2/${bytes.length}`});
    if (mode === 'oversized') { res.setHeader('Content-Length',String(8*1024*1024+1)); res.end(); return; }
    res.end(mode === 'corrupt' ? Buffer.alloc(bytes.length,88) : bytes);
  });
  server.listen(0,'127.0.0.1'); await once(server,'listening');
  try {
    const client = new CloudObjectClient(`http://127.0.0.1:${server.address().port}/api/v1`,'PUBLIC_fixture_session',{allowLoopbackHTTP:true});
    assert.deepEqual(await client.download('public_object'),bytes);
    for (const failure of ['corrupt','wrongSHA3','wrongVersion','noncanonical','partial','oversized','redirect']) {
      mode = failure;
      await assert.rejects(client.download('public_object'),undefined,failure);
    }
    assert.equal(forwarded,0,'redirect forwarded a session or fetched unselected bytes');
    await assert.rejects(client.put('public_object','01',bytes),/Invalid revision/);
    assert.throws(() => new CloudObjectClient('https://example.invalid/api/v1?token=leak','PUBLIC_fixture_session'),/Invalid Cloud API/);
  } finally {
    await new Promise(resolve => server.close(resolve));
    await new Promise(resolve => target.close(resolve));
  }
});
