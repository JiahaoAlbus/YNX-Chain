import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFile,writeFile,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
let input='';for await(const b of process.stdin)input+=b;
const {base,tokens,accounts,root,stage,original}=JSON.parse(input),path=n=>join(root,n),cli=fileURLToPath(new URL('./cloud.mjs',import.meta.url));
const run=(who,args,failure=false)=>{const env={PATH:process.env.PATH,TMPDIR:process.env.TMPDIR,YNX_CLOUD_API:base,YNX_CLOUD_LOCAL_HTTP:'1'};if(who!=='anonymous')env.YNX_CLOUD_TOKEN=tokens[who];const r=spawnSync(process.execPath,[cli,...args],{env,encoding:'utf8',timeout:30000});assert.equal(r.status,failure?1:0,r.stderr);for(const token of Object.values(tokens))assert.equal((r.stdout+r.stderr).includes(token),false);return JSON.parse(failure?r.stderr:r.stdout);};
let result;
if(stage==='initial'){
 const lost=run('owner',['folder-original','PUBLIC root',path('root.json')],true);assert.equal(lost.outcome,'UNKNOWN');const saved=JSON.parse(await readFile(path('root.json'),'utf8'));assert.equal(saved.state,'UNKNOWN');result={rootRequest:saved.requestID};
}else if(stage==='root-cold'){
 const recovered=run('owner',['folder-original','PUBLIC root',path('root.json')]);assert.equal(recovered.kind,'folder');assert.equal(recovered.version,undefined);
 const nested=run('owner',['folder-original','PUBLIC nested',path('nested.json'),recovered.objectId]);const other=run('owner',['folder-original','PUBLIC other',path('other.json')]);
 result={...original,parent:recovered.objectId,nested:nested.objectId,other:other.objectId};
}else if(stage==='import'){
 await writeFile(path('file1'),'PUBLIC editor child1\0');await writeFile(path('file2'),'PUBLIC editor child2\0');
 const one=run('editor',['upload',path('file1'),path('file1.json'),original.nested]);const two=run('editor',['upload',path('file2'),path('file2.json'),original.nested]);
 assert.equal(run('owner',['get',one.objectID]).owner,accounts.editor);
 const page=run('owner',['list',original.nested,'','1']);assert.equal(page.items.length,1);assert.ok(page.nextCursor);const next=run('owner',['list',original.nested,page.nextCursor,'1']);assert.equal(next.items.length,1);assert.notEqual(page.items[0].id,next.items[0].id);assert.equal(next.nextCursor,undefined);
 assert.equal(run('owner',['list',original.other,page.nextCursor,'1'],true).status,400);
 const output=path('parent-owner-download');run('owner',['download',one.objectID,output]);assert.equal(await readFile(output,'utf8'),'PUBLIC editor child1\0');
 const receipt=await readFile(path('file1.json'));assert.match(run('editor',['upload',path('file1'),path('file1.json'),original.other],true).error,/another original parent/);assert.deepEqual(await readFile(path('file1.json')),receipt);
 assert.equal(run('editor',['upload',path('file1'),path('forbidden.json'),original.other],true).status,403);
 run('editor',['access-original',one.objectID,accounts.owner,'deny','1',path('deny.json')]);assert.equal(run('owner',['get',one.objectID],true).status,403);
 result={...original,one:one.objectID,two:two.objectID};
}else if(stage==='final-cold'){
 const owned=run('owner',['list',original.nested]);assert.deepEqual(owned.items.map(x=>x.id),[original.two]);const editor=run('editor',['list',original.nested]);assert.equal(editor.items.length,2);
 assert.equal(run('owner',['get',original.one],true).status,403);
 const queried=run('editor',['upload',path('file1'),path('file1.json'),original.nested]);assert.equal(queried.objectId,original.one);assert.equal(queried.parentId,original.nested);
 assert.equal(run('owner',['folder-original','PUBLIC root',path('root.json')]).objectId,original.parent);
 const cap=path('child-cap.json');run('editor',['link-create-original',original.two,new Date(Date.now()+600000).toISOString(),cap]);
 run('owner',['trash-original',original.parent,'1',path('parent-trash.json')]);
 assert.deepEqual(run('owner',['list',original.nested]).items,[]);
 assert.equal(run('editor',['upload',path('file2'),path('hidden-upload.json'),original.nested],true).status,403);
 const hidden=path('hidden-share.bin');assert.ok([403,404].includes(run('anonymous',['link-download',cap,hidden],true).status));await assert.rejects(stat(hidden),{code:'ENOENT'});
 run('owner',['restore-trash-original',original.parent,'2',path('parent-restore.json')]);
 const restored=path('restored-share.bin');run('anonymous',['link-download',cap,restored]);assert.equal(await readFile(restored,'utf8'),'PUBLIC editor child2\0');
 assert.equal(run('owner',['get',original.one],true).status,403);
 result={...original,parentOwnerInheritance:true,explicitDenyRetained:true,pagesBoundToFolder:true,noReplay:true};
}else throw Error('Unknown stage');process.stdout.write(JSON.stringify(result));
