// Actual normal SDK client/constructor/decoder/HTTP consumer. Request proof and
// approval below are explicitly PUBLIC fixtures; no real V2 authority exists.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {YNXCloudClient,YNXCloudDeploymentUnknownError} from '../sdk/index.js';
import {CloudDeploymentV2Client} from './deployment-v2-client.mjs';
let input='';for await(const chunk of process.stdin)input+=chunk;
const {endpoint}=JSON.parse(input);
const fixture=JSON.parse(await readFile(new URL('./node_modules/@ynx-chain/open-protocol/test/fixtures/deployment-v2-manifest.json',import.meta.url),'utf8'));
const original=new YNXCloudClient({endpoint,product:'cloud',getDeploymentRequestHeaders:async()=>({'X-Public-Fixture':'NOT_REAL_SOURCE_PROOF','x-ynx-product-session-proof-v5':'PUBLIC_PROTOCOL_FIXTURE_NOT_AUTHENTIC'})});
const client=new CloudDeploymentV2Client(original);
const prepared=client.prepare(fixture.manifest,Buffer.from(fixture.actualHex,'hex'),{requestId:'req_p04_v2_normal_original_0001',expectedSlotRevision:'0'});
client.verifyReadback(prepared.selection,client.payloadOriginal(prepared),Buffer.from(fixture.actualHex,'hex'));
assert.equal(client.payloadOriginal(prepared).toString('hex'),fixture.payloadHex);
const approval=Buffer.from('PUBLIC_NOT_A_V2_SIGNATURE_OR_APPROVAL');
await assert.rejects(client.submitPrepared(prepared,approval),error=>error.status===503&&error.retryAllowed===false&&error.message.includes('Native V5 transport Source unavailable'));
await assert.rejects(client.submitPrepared(prepared,approval),error=>error.status===503&&error.retryAllowed===false&&error.operationRequestId===prepared.selection.requestId);
await client.closeOriginalNativeTransport();
process.stdout.write(JSON.stringify({actualSDK:true,sourceGate:'NATIVE_V5_UNAVAILABLE',acquisitionRetained:client.originalNativeTransportStatus().acquisitionFailed,directJSPost:false,requestId:prepared.selection.requestId}));
