// New original-version lifecycle only; PUBLIC Wallet admission comes from Go.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {bindBytes} from './object-client.mjs';
let input='';for await(const b of process.stdin)input+=b;
const {base,token,root,stage,original}=JSON.parse(input);
const cli=fileURLToPath(new URL('./cloud.mjs',import.meta.url));
const run=(args,failure=false)=>{
 const r=spawnSync(process.execPath,[cli,...args],{env:{PATH:process.env.PATH,TMPDIR:process.env.TMPDIR,YNX_CLOUD_API:base,YNX_CLOUD_LOCAL_HTTP:'1',YNX_CLOUD_TOKEN:token},encoding:'utf8',timeout:30000});
 assert.equal(r.status,failure?1:0,r.stderr);assert.equal((r.stdout+r.stderr).includes(token),false);
 return JSON.parse(failure?r.stderr:r.stdout);
};
const path=n=>join(root,n),contents=['PUBLIC historical v1\0','PUBLIC original put v2\0','PUBLIC later v3\0','PUBLIC later v5\0'];
let result;
if(stage==='initial'){
 for(let i=0;i<contents.length;i++)await writeFile(path('v'+i),contents[i]);
 const created=run(['upload',path('v0'),path('create.json')]);
 const lost=run(['put-original',created.objectID,created.revision,path('v1'),path('put.json')],true);assert.equal(lost.outcome,'UNKNOWN');
 const pending=JSON.parse(await readFile(path('put.json'),'utf8'));assert.equal(pending.state,'UNKNOWN');
 result={id:created.objectID,putID:pending.requestID};
}else if(stage==='put-cold'){
 const observed=run(['put-original',original.id,'1',path('v1'),path('put.json')]);assert.equal(observed.version,2);assert.equal(observed.revision,'2');
 const upload=JSON.parse(await readFile(path('create.json'),'utf8'));const wrongKind=path('wrong-upload.json');await writeFile(wrongKind,JSON.stringify({...upload,name:'v1',binding:bindBytes(Buffer.from(contents[1])),requestID:original.putID,state:'SUBMITTED'}),{mode:0o600});
 const wrongBefore=await readFile(wrongKind);assert.match(run(['upload',path('v1'),wrongKind],true).error,/version mutation, not this upload/);assert.deepEqual(await readFile(wrongKind),wrongBefore);
 run(['put',original.id,'2',path('v2')]);
 const stillOriginal=run(['put-original',original.id,'1',path('v1'),path('put.json')]);assert.equal(stillOriginal.version,2);assert.equal(stillOriginal.revision,'2');
 const receiptBefore=await readFile(path('put.json'));assert.match(run(['put-original',original.id,'1',path('v2'),path('put.json')],true).error,/another original version operation/);assert.deepEqual(await readFile(path('put.json')),receiptBefore);
 const lost=run(['restore-original',original.id,'1','3',path('restore.json')],true);assert.equal(lost.outcome,'UNKNOWN');
 const pending=JSON.parse(await readFile(path('restore.json'),'utf8'));assert.equal(pending.state,'UNKNOWN');result={...original,restoreID:pending.requestID};
}else if(stage==='restore-cold'){
 const restored=run(['restore-original',original.id,'1','3',path('restore.json')]);assert.equal(restored.version,4);assert.equal(restored.selection.historicalVersion,1);
 run(['put',original.id,'4',path('v3')]);
 const originalRestore=run(['restore-original',original.id,'1','3',path('restore.json')]);assert.equal(originalRestore.version,4);assert.equal(originalRestore.revision,'4');
 const history=run(['versions',original.id]);assert.deepEqual(history.map(v=>v.number),[5,4,3,2,1]);
 for(const [number,text]of [[1,contents[0]],[2,contents[1]],[3,contents[2]],[4,contents[0]],[5,contents[3]]]){const output=path('download-'+number);run(['download',original.id,output,String(number)]);assert.equal(await readFile(output,'utf8'),text);}
 result={...original,versions:history.length,originalPutVersion:2,originalRestoreVersion:4,noReplay:true};
}else throw Error('Unknown stage');
process.stdout.write(JSON.stringify(result));
