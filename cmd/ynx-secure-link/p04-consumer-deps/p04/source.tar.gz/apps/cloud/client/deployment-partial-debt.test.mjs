import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
for(const mode of ['acquire-null','retire-false','join-undefined','join-null','close-false','close-undefined'])test(`original partial cleanup retains ${mode} and same-owner debt`,()=>{
  const r=spawnSync(process.execPath,[fileURLToPath(new URL('./deployment-partial-debt.fixture.mjs',import.meta.url)),mode],{encoding:'utf8',timeout:10000});
  assert.equal(r.status,0,r.stderr||r.stdout);
  const result=JSON.parse(r.stdout);assert.equal(result.opens,1);assert.equal(result.requests,0);assert.equal(result.RootAdmission,false);
});
