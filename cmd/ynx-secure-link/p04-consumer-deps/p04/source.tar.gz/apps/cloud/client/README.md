# Cloud independent client

Requires Node 22 or newer. Account commands require a current original Wallet Cloud session; `link-download` uses only its private sharing capability. No package install is required. Set `YNX_CLOUD_API` to the admitted Cloud `/api/v1` endpoint and supply either `YNX_CLOUD_TOKEN` through your session environment or an endpoint-bound `YNX_CLOUD_SESSION_FILE`. See `../CLI_PRIVATE_SESSION.md` for save/status/revoke and UNKNOWN recovery. HTTPS is required. For an isolated loopback development service only, set `YNX_CLOUD_LOCAL_HTTP=1`.

Run `node apps/cloud/client/cloud.mjs` followed by one command:

| Command | Arguments |
| --- | --- |
| `session-save` | `NEW_PRIVATE_FILE`; validate the original environment session against the normal service, then save it with its endpoint |
| `session-status` | No arguments; read current account/scopes/expiry, without token hashes, device keys or bindings |
| `session-revoke` | No arguments; requires `YNX_CLOUD_SESSION_FILE`; revoke only the original session, preserve UNKNOWN before DELETE |
| `upload` | `FILE PRIVATE_RECEIPT_FILE [PARENT_ID]`; original receipt retains exact parent |
| `folder-original` | `NAME PRIVATE_RECEIPT_FILE [PARENT_ID]`; original folder creation and GET-only recovery |
| `list` | `[PARENT_ID] [CURSOR] [LIMIT]`; bounded normal page, limit1..1000; use returned nextCursor in the same folder |
| `trash-list` | No arguments; existing normal `view=trash` listing |
| `deletions` | No arguments; readonly physical-deletion job status, no retry or delete |
| `get` | `OBJECT_ID`; current visible metadata and revision |
| `operation` | `ORIGINAL_REQUEST_ID` |
| `download` | `OBJECT_ID NEW_OUTPUT_FILE [VERSION]` |
| `versions` | `OBJECT_ID` |
| `put` | `OBJECT_ID EXPECTED_REVISION FILE` |
| `put-original` | `OBJECT_ID EXPECTED_REVISION FILE PRIVATE_RECEIPT`; durable original request, GET-only after entry |
| `restore` | `OBJECT_ID VERSION EXPECTED_REVISION` |
| `restore-original` | `OBJECT_ID VERSION EXPECTED_REVISION PRIVATE_RECEIPT`; restore to a new version, preserve all later history |
| `trash-original` | `OBJECT_ID EXPECTED_REVISION PRIVATE_RECEIPT`; reversible trash, durable original result |
| `restore-trash-original` | `OBJECT_ID EXPECTED_REVISION PRIVATE_RECEIPT`; return the same object and all history from trash |
| `access` | `OBJECT_ID ACCOUNT allow\|deny EXPECTED_REVISION` |
| `access-original` | `OBJECT_ID ACCOUNT allow\|deny EXPECTED_REVISION PRIVATE_RECEIPT`; durable original ACL result, GET-only recovery |
| `link-create` | `OBJECT_ID ISO_EXPIRY NEW_PRIVATE_TOKEN_FILE` |
| `link-prepare-original` | `OBJECT_ID ISO_EXPIRY NEW_PRIVATE_CUSTODY`; durable random capability only, no link creation |
| `link-create-original` | `OBJECT_ID ISO_EXPIRY PRIVATE_CUSTODY`; one original create, recovery GET-only |
| `link-reconcile-original` | `PRIVATE_CUSTODY`; observe original create/cancel/revocation without another grant |
| `link-cancel-original` | `PRIVATE_CUSTODY`; retire the original request, including a create that has not arrived yet |
| `link-download` | `PRIVATE_TOKEN_FILE NEW_FILE`; verifies pinned version and both digests before creating the output |
| `link-revoke` | `OBJECT_ID LINK_ID` |

Upload persists a stable request receipt before sending. Repeating the same command after an interrupted submission queries the original request only. Preserve that receipt. An UNKNOWN result or a missing original observation does not trigger another upload. Receipt digests and original object IDs remain after object deletion to prevent old retries recreating erased content; the erasure receipt discloses this retention.

Downloads pin an immutable version and verify the decimal byte length, SHA3-512 and SHA-512 against metadata and actual received bytes before creating the output file. Existing output files are never overwritten. Revision values are decimal strings. A stale revision fails; fetch the current object/version and make a fresh explicit decision.

The exported `CloudObjectClient` also supports verified bearer-link downloads with an independently selected version/binding. Link tokens are capabilities: the CLI writes newly created tokens only into a new private file together with the selected endpoint, version and dual digest. `link-download` rejects a different endpoint, a symlink, another OS owner's file, a multiply linked file or group/world access. Transfer this capability only through the original approved private channel. A changed current version causes verification to fail; it does not silently accept different bytes. Revoking the original link stops future downloads, including after a service restart; bytes already downloaded remain with the recipient.

`list` and `get` do not confer sharing rights. A second tenant cannot discover or download an owner's private object merely by knowing its ID. `access` requires the current owner's revision; after an explicit grant the other session can download, and an explicit deny takes effect on subsequent reads. The CLI does not cache that grant. The actual normal private-host journey exercises these commands in separate Node processes with disk-backed state, historical restore, capability revoke and two cold reopens. Its authenticated positive cases use explicitly PUBLIC Wallet fixtures; a fresh normal host with no admitted session returns 401. No real account or Wallet authorization is fabricated for a successful-looking journey.

This source candidate has been exercised against isolated real HTTP with PUBLIC Wallet verifier fixtures, persistent disk snapshots and an independent platform-crypto client. It does not establish a real Wallet/Source admission, public deployment, mobile installation or production availability. Existing website and mobile login remain separate delivery gates.

## Deployment caller

The same-process deployment command entry is
`runOriginalCloudDeploymentCommand(originalCloudSDK, argv, {signal})` from
`deployment-command-session.mjs`. Long-lived clients can instead open
`openOriginalCloudDeploymentCommandSession(originalCloudSDK)`, call `run`, and
close the owner when their window/process exits. Arguments are the existing
`status`, `reconcile`, `runtime`, `logs`, `usage`, `usage-records`, `inspect`,
`bill-original` or `native-intent-original` command followed by its original
private receipt and existing arguments. It uses the original SDK deployment
read proof callback; the ordinary object CLI's bearer/session file cannot
authorize deployment reads. No arbitrary provider module is loaded.

The session owns its local waits. Caller abort or owner close cancels those
waits and prevents new commands; neither action cancels a remote deployment,
rewrites its original operation nor creates a new submission. Every later
process reopens the same private receipt and queries the original operation.
The read entry never opens the runtime-image launcher or a Native signer.

`CloudDeploymentV2Client` uses its own exact V2 observation path. `logs(selection)`, `usage(selection, {observe})` and `billOriginal(selection, utcDay)` reconcile the original request before reading. Every observation retains the full manifest, all five fields of each selected Ref, both byte bindings, expected/observed slot and original instance. The approved Catalog projection is a separate server observation; it is never derived from `ProjectRef.ID`. A caller-side selection is copied before awaiting transport, so caller mutation cannot change an in-flight read's selected identity.

`billOriginal` reads only the original sealed bill. It checks full V2 project scope, tariff registration/revision/resource, original sample binding, native asset metadata, exact integer units and ceil-total arithmetic, and the original non-payment state. Passing a prepare option is rejected before HTTP. PAID, invented atoms, another tenant/revision, a guessed Catalog ID or a price window that does not cover the original day is rejected. These checks bind observed DATA; they do not replace the server's genuine registered price, Pay merchant Source, signature or settlement verification. Normal reads use the original SDK's per-request proof provider and never acquire Native or submit another deployment/invoice.

The normal `ynx-cloudd` command now accepts paired `-ide-v2-data-node` and `-ide-v2-data-bridge` paths from the original installed normal package. They select DATA parsing code only, after the original Source/runtime startup has succeeded. Both paths must be supplied together, cannot replace an existing typed DATA supplier, and do not construct a Source/authority from JSON. The exact original Source, Catalog, runtime and optional authority pointers are preserved. Without an original Source, supplying code paths fails before a Cloud state or deployment is created. Default startup without either flag keeps its existing behavior. Source commissioning actions reject these unrelated flags.

The DATA bridge and the original independent Cloud execution/recovery Source have distinct roles. Use the original Cloud purpose and fixed Auth contract; Pay purpose, CloudPrincipal strings or DATA flags cannot enable execution. The paired code paths still require the normal installed sole OpenProtocol dependency. Supplying the bridge does not qualify Root, release.sign, Native, publisher, deployment approval or public runtime access.

The original `CloudDeploymentClient` now exposes `prepare(input)` and `submitPrepared(prepared)` so the caller can preserve the exact selection before any transport. The prepared object retains copied manifest, artifact and approval bytes inside the client; it is not a JSON approval constructor. `prepareRollback(successfulOriginalSelection, freshInput)` reads the original result and requires completed/exit-0 provenance, the same original manifest/artifact, a new request ID, a different fresh approval and an explicit current slot revision. Rollback creates a new forward generation; it does not restart the historical container or roll back account/chain/billing state. The server still independently authorizes every new request and validates the target/slot.

`deployment-workflow.mjs` exports `submitDeploymentReceipt`, `reconcileDeploymentReceipt`, and the normal same-process `runDeploymentCommand(client, args)` entry. It accepts the original legacy or V2 client without upgrading an old receipt. `recoverDeploymentReceipt` adopts an existing IDE/original selection for GET-only recovery. Commands are `status`, `reconcile`, `runtime`, `logs`, `usage`, `usage-records` or `inspect` followed by the original private receipt path; `bill-original` additionally takes a UTC day, and V2 `native-intent-original` also requires the exact product/source-order reference. See `../V2_ORIGINAL_DEPLOYMENT_RECEIPTS.md`. `runtime` refuses unavailable fresh observations; `inspect` binds the same instance/version across runtime, logs and existing meter records using GET only. `usage` explicitly samples; `usage-records` never samples. See `../ORIGINAL_DEPLOYMENT_OBSERVATION.md`. The original IDE/Wallet bootstrap must pass its real `CloudDeploymentClient` over the original SDK proof provider. This entry does not load arbitrary provider modules, manufacture a Source, or convert a bearer session into deployment authority.

The direct `runDeploymentCommand`, `reconcileDeploymentReceipt` and
`recoverDeploymentReceipt` entries accept `{signal, originalRequestContext}`
for the original V2 caller. They forward that same context object through all
read operations, including the sequential reads inside `inspect`. The SDK
still checks its frozen shape and original signal; Cloud does not create a
context or infer Source authority from it. The separate owned command-session
entry retains its existing local cancellation lifecycle.

Native acquisition failure and partial-cleanup failure are tracked by presence,
including a thrown `null`, `false` or `undefined`. Partial drain retains the
first original cause after later physical completion. A failed or ambiguous
close is selected once and stays unresolved; cleanup continuation uses the
same partial and never reopens a Source or retries that close effect.

The receipt file is created exclusively with private owner permissions and synchronized before the transport. UNKNOWN is durable before the original Source/HTTP invocation. Every existing receipt, including a crash-left PREPARED receipt, is query-only. Endpoint or selection changes are rejected; 404/UNKNOWN never authorize another submission. Cold recovery uses the same request/slot/original instance and atomically updates only the local observed DATA. Raw approval, manifest/artifact bytes, session tokens and Source handles are not stored in the receipt. Preserve both the receipt and the original immutable artifact until its lifecycle is resolved.

This workflow is the existing legacy publication domain only. It does not downgrade V2/E11 or bypass the original Native V5 transport if that Source is unavailable. V2 prepared objects and original sensitive action approvals remain in their original SDK/Native owner lifecycle. The real hosted OCI rollback/reconcile test uses expressly PUBLIC legacy approval fixtures at the production service port, and must not be represented as a real publisher/Root signature or public runtime admission.

`deployment-client.mjs` exports `CloudDeploymentClient`. Construct it with the existing `YNXCloudClient` carrying the original `getDeploymentRequestHeaders` producer. An ordinary Wallet token cannot construct this deployment caller. `submit` takes actual manifest/artifact/approval byte arrays, a new request ID, and `expectedSlotRevision` as a decimal string; optional `rollbackTo` selects an original successful request. Preserve the returned `selection` in the IDE's existing durable request record. `lookupOriginal`, `logs` and `usage` rebind to that exact selection and never resubmit it.

Rollback still requires a fresh original publication and resource approval for the exact historical artifact. It advances the existing resource slot revision; it does not roll back chain state, charges or old grants. The previous instance must have a confirmed terminal observation before another reservation can replace it. A running/uncertain original remains occupied.

Cloud persists actual byte dual bindings separately from the unchanged six-field signing contract. Usage reads the exact original instance's Docker engine counters, verifies the held staged artifact, and persists canonical sample IDs without summing cumulative counters twice. `usage(selection, {observe:false})` reads retained records independently of engine availability.

`bill(selection, 'YYYY-MM-DD', {prepare:true})` requests one invoice intent for a closed UTC period; its default GET mode only reconciles the original intent. The normal proof provider is used for every route. No amount, destination, price, approval or Member can be inserted through a request body. Original registered pricing/current approval and a normal native Pay producer must be supplied in the in-process startup composition; runtime JSON cannot enable these dependencies. The fixed native producer is integrated below; genuine registered pricing, merchant Source and qualified service transport are **not supplied** in the production candidate, so normal charges remain `UNPRICED`.

The registered tariff must explicitly select `cumulative-sample-end/UTC-day/ceil-total/v1`: CPU/network increments belong to their observing sample's UTC day, storage is that day's observed peak staged bytes, and rates round up once on each period total. Rates use actual ledger atoms with supplied genesis, native chain ID, asset ID and unit version; no display decimal scale is assumed. Each instance/period freezes one price revision and stable bill ID before sending. A lost response, pre-send crash, later tariff revision or restart cannot create another invoice. Zero price records `NO_CHARGE` without contacting Pay.

Cloud invoice states `PREPARED` and `ISSUED` remain `NOT_VERIFIED` for settlement. They never mean paid. The fixed original Pay adapter consumes the merchant's normal invoice-terms producer, preserving original terms/invoice/native operation identity. The complete signed Member must still come through actual merchant approval. Genuine registered tariff/current approvals, native metadata and protected approval remain production gates. The earlier invoice HTTP protocol fixture is superseded for native integration by the actual fixed P06 service and Store exercised below.

The deployment lifecycle regressions use explicit PUBLIC authority/engine protocol fixtures plus actual private files, locks, journal restarts and local Unix HTTP. **Actual OCI execution is NOT_SUPPLIED** on this machine; no container, public runtime URL or executed application output has been verified in this round. The original Auth Source/publisher/resource factory and actual V2 signature/current-Source integration remain required for their corresponding protected effects.

## V2 manifest DATA caller

Install the exact self-contained SDK archive offline with `npm ci --prefix apps/cloud/client --offline --ignore-scripts --no-audit --no-fund`. Only the V2 consumer needs this dependency; the existing object CLI still uses platform crypto. `deployment-v2-supplier.json` pins upstream commit `a7bfd7800a1e1f30f7bcb358ccb069249a545c1d`, tree and archive SHA-256. The product package lock retains npm's integrity; there is no shared lock/module change or local fork of the E11 codec.

`CloudDeploymentV2Client` consumes the actual `@ynx-chain/open-protocol/deployment-v2` public export. `prepare(exactTenKeyDTO, actualBytes, originalRequestSelection)` constructs and decodes exact canonical payload bytes, asserts the artifact binding and holds owned snapshots. Preserve `prepared.selection` in the IDE's existing durable original operation. `payloadOriginal(prepared)` gives a copy for the actual Auth V2 signer; no signer is provided here. `verifyReadback(selection, payloadOriginal, actualArtifactBytes)` checks the independently selected full manifest binding and actual artifact separately. Publisher/issuer epochs are explicit and never inferred from Ref.rev. An issuer fullRef is a claim, not trusted registration.

`submitPrepared(prepared, actualApprovalBytes)` uses the original POST `/api/v1/ide/deployments`, per-request proof provider, idempotency key, slot CAS and optional rollback selection, with `X-Deployment-Manifest-Version: 2`. It never sends V2 through the old six-field transport/signing domain. The Go service uses `ReadIDEDeploymentArtifactV2` and the same installed SDK DATA bridge, then independently checks actual standard-Go dual hashes. Codec processes are serialized and do not inherit service secrets or execute artifact code.

The normal E11 signer implementation is supplied by SDK commit `737ae6c46f6353c0c3e9330ae3a421bcfa483e91`, public Node export `@ynx-chain/wallet-auth/original-ide-deployment-v2`: original Native acquires its zero-argument owner and signs the approved payload/artifact. Cloud never acquires that signer. The matching formal Core component is 11,358,000 bytes, SHA-256 `7eafad13541e632f8560dd578cc409bea319c2b312135d497566cca2804057c0`. Implementation supply does not mean genuine Root/profile/approval admission or an installed product.

Cloud's original server now has a separate V2 authority port and a matching-source adapter (`cloud_auth_v2` build tag). It calls original Auth `AcquireOriginalDeploymentV2ExecuteApproval` for the SAME authenticated request, retains that opaque handoff, and then calls `AuthorizeExecutionV2`. The original Auth permit supplies immutable selection, original artifact borrowing and effect-time rechecks. Cloud compares actual payload/artifact binds and full manifest, then uses the existing journal, resource CAS, staging inode/digest fences, create/start, observations and logs. It never constructs an old six-field authorization or legacy `PublicationPermit` for V2. Missing matching Auth/Core composition or actual Source admission keeps V2 at `IDE_DEPLOYMENT_V2_AUTHORITY_UNAVAILABLE` without claiming a new journal operation or executing. The original deployment runtime remains available. The concrete adapter is currently source work awaiting the original Auth frozen closure for matching compilation; no production admission is claimed.

V2 operations retain their version, full manifest and both bindings in the ORIGINAL operation/resource records. UNKNOWN/cold recovery only observes the original immutable container ID. Reads require the V2 Source recovery authority; a legacy catalog ID does not grant V2 read/runtime access. Rollback requires a fresh permit and an already completed successful original artifact with matching full project/artifact references, content and environment; it advances the same resource slot. Public protocol fixtures cover this whole consumer flow, while genuine Source/Native proof and actual OCI execution remain separate acceptance gates.

`callerActualDATA(prepared)` supplies owned copies of the proposal payload/artifact and actual BindE3 bytes for the new Core V2 ABI. These are caller DATA. It supplies no independent expected Source payload/binds, network/subject context, registered public pair, approval or private material. The original Auth/Native owner must supply those independently and perform the same-process private loan. The new Core purpose is `CLOUD-DEPLOYMENT-MANIFEST-V2`; it cannot use the old artifact-release signer.

`captureOriginalE11Result(prepared, sdkPublicResult)` consumes the original SDK public result. It retains the first well-formed public partial before interpreting status. Only exact selected bytes/binds, `RETURNED`, signed=true, Core OK=0 and cleanup LOGICAL_COMPLETE=2 become `readyForTransport`; this flag is DATA and is never independent verification or a Source grant. UNKNOWN, late-fence partials, swapped bytes and incomplete cleanup remain retained with `retryAllowed:false`. `originalE11Result(prepared)` returns an independent readback copy. Preserve this result in the IDE's original durable outbox; Cloud's in-memory snapshot is not a new durable signing journal.

`submitOriginalE11(prepared, {signal})` sends the retained original raw Member in the existing multipart `approval` slot. It does not send SDK publicPartial JSON or require the client to invent an execute approval. Original server Auth independently produces that approval from protected Source/Catalog. `captureMultipartOriginal(prepared, rawMember)` returns copies of the single cached final multipart serialization and exact Content-Type, including boundary. Concurrent capture of the same Member uses identical bytes; a changed Member requires reconciliation.

The original Cloud SDK `getDeploymentRequestHeaders` hook retains its existing method/path/url/operationRequestId and additionally receives `bodyOriginal` (an independent Uint8Array copy) and `contentType` for V2 submission. The same frozen bytes/type are sent once, after proof acquisition; no UTF-8 conversion or FormData reconstruction occurs. V2 requires `x-ynx-product-session-proof-v5` and refuses old V2/V4 proof fallback. The sole SDK contract limits the COMPLETE body to 68,288,512 bytes; the artifact limit remains 64 MiB. This hook supplies public DATA to the original Native provider. The actual versioned Native capture/Source/held transport factory is still in implementation, and caller JS bytes or a header name do not qualify it. Missing V5 proof produces zero POSTs. Public proof fixtures in tests are explicitly not authentic signatures.

## Fixed native invoice composition

P06 commit `7afa0ee56a439f2771def57a9ce1a4663b90b360` supplies the actual `CloudNativeInvoiceProducer`, private HTTP client and normal intent service. With matching `pay_pq pay_cloud` source composition, Cloud's normal startup now constructs `NewNativeInvoiceIntentClient` then `NewCloudNativeInvoiceProducer` from private typed `UsageBilling.NativePay.{Origin,Client}` inputs. The qualified original transport and genuine pricing authority must come from original composition; runtime JSON cannot instantiate them. Uncomposed/partial builds keep charges UNPRICED, without a legacy invoice fallback or stopping the original deployment runtime.

Cloud retains its existing sealed bill and stable Pay intent `OriginalOperation`; P06 owns CORE invoice/session identity, merchant review, captured Member and reconcile. Cloud never signs. Native `PREPARED` means awaiting original merchant approval or original-operation recovery; `ISSUED` is proof-gated terms registration and still not paid.

`apps/cloud/scripts/compose-native-pay.mjs CLOUD_WT P06_WT PREPARED_CORE_COMPOSITION FRESH_OUTPUT` creates an owned source composition from this Cloud snapshot and fixed P06 Git source, preserving supplier trees. Output must be outside the input trees. It reuses the exact P06 CORE codec and original supplier fixture; `CLOUD_COMPOSITION.json` records the fixed Pay commit/tree, copied source/module SHA-256 pins and toolchain. Unchanged CORE dependency directories remain linked to the original supplied composition, so this record is not an independent CORE release bundle.

The included integration driver verifies actual Cloud billing HTTP → fixed P06 private HTTP/registered adapter/Store → response loss → both stores reopened → same native intent, no second create/sign/broadcast. After restart, actual Source denial and an untrusted `PAID` reply must retain UNKNOWN with no invoice or settlement promotion; restoring the original supplier permits lookup of the same PREPARED intent. Cloud authority, meter and joint Source remain explicit PUBLIC fixtures; no real Source, Native approval, runtime or funds are claimed. Exact toolchain is Go 1.26.10. In the owned composition, run `go test -race -p 1 -count=1 -timeout=90s -tags 'pay_pq pay_cloud cloud_consumer_integration' -run '^TestCloudOwnerFixedNativeProducerSealedBillColdRecovery$' ./internal/payproduct`. The normal startup constructor check uses tags `pay_pq pay_cloud` and `-run '^TestIDERuntimeNativePayUsesFixedSupplierConstructor$' ./apps/cloud/cmd/ynx-cloudd`; do not run the full supplier suite.
