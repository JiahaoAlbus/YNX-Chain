// Actual normal Cloud/HTTP/CLI journey; Wallet admission is PUBLIC in Go.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFile,writeFile,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
let input='';for await(const b of process.stdin)input+=b;
const {base,tokens,target,root,stage,original}=JSON.parse(input);
const cli=fileURLToPath(new URL('./cloud.mjs',import.meta.url)),path=n=>join(root,n);
const run=(who,args,failure=false)=>{
 const r=spawnSync(process.execPath,[cli,...args],{env:{PATH:process.env.PATH,TMPDIR:process.env.TMPDIR,YNX_CLOUD_API:base,YNX_CLOUD_LOCAL_HTTP:'1',YNX_CLOUD_TOKEN:tokens[who]},encoding:'utf8',timeout:30000});
 assert.equal(r.status,failure?1:0,r.stderr);for(const token of Object.values(tokens))assert.equal((r.stdout+r.stderr).includes(token),false);
 return JSON.parse(failure?r.stderr:r.stdout);
};
const access=(id,decision,rev,receipt,failure=false)=>run('manage',['access-original',id,target,decision,rev,path(receipt)],failure);
const denied=async(id,name)=>{const output=path(name),e=run('viewer',['download',id,output],true);assert.ok([403,404].includes(e.status));await assert.rejects(stat(output),{code:'ENOENT'});};
let result;
if(stage==='initial'){
 await writeFile(path('source.bin'),'PUBLIC original ACL bytes\0');
 const created=run('owner',['upload',path('source.bin'),path('upload.json')]);
 await denied(created.objectID,'before-grant.bin');
 const lost=access(created.objectID,'allow','1','allow.json',true);assert.equal(lost.outcome,'UNKNOWN');
 const saved=JSON.parse(await readFile(path('allow.json'),'utf8'));assert.equal(saved.state,'UNKNOWN');assert.equal(JSON.stringify(saved).includes(target),false);
 run('viewer',['download',created.objectID,path('granted.bin')]);assert.equal(await readFile(path('granted.bin'),'utf8'),'PUBLIC original ACL bytes\0');
 result={id:created.objectID,allowID:saved.requestID};
}else if(stage==='allow-cold'){
 const allowed=access(original.id,'allow','1','allow.json');assert.equal(allowed.revision,'2');assert.equal(allowed.selection.allow,true);assert.equal(allowed.currentAccess,'NOT_ASSERTED');
 const wrongScope=run('write',['operation',original.allowID],true);assert.equal(wrongScope.status,403);
 const copy=await readFile(path('allow.json'));assert.match(access(original.id,'deny','1','allow.json',true).error,/another original access/);assert.deepEqual(await readFile(path('allow.json')),copy);
 assert.ok([403,404].includes(run('viewer',['operation',original.allowID],true).status));
 const foreign=JSON.parse(copy);foreign.endpoint='https://foreign.invalid/api/v1';await writeFile(path('foreign.json'),JSON.stringify(foreign),{mode:0o600});assert.match(access(original.id,'allow','1','foreign.json',true).error,/another original access/);
 const lost=access(original.id,'deny','2','deny.json',true);assert.equal(lost.outcome,'UNKNOWN');await denied(original.id,'after-deny.bin');
 const saved=JSON.parse(await readFile(path('deny.json'),'utf8'));assert.equal(saved.state,'UNKNOWN');result={...original,denyID:saved.requestID};
}else if(stage==='deny-cold'){
 const deniedOriginal=access(original.id,'deny','2','deny.json');assert.equal(deniedOriginal.revision,'3');assert.equal(deniedOriginal.selection.allow,false);
 const oldAllow=access(original.id,'allow','1','allow.json');assert.equal(oldAllow.revision,'2');assert.equal(oldAllow.selection.allow,true);await denied(original.id,'old-allow-cannot-regrant.bin');
 await writeFile(path('later.bin'),'PUBLIC later content after ACL');run('owner',['put',original.id,'3',path('later.bin')]);
 const stillOriginal=access(original.id,'deny','2','deny.json');assert.equal(stillOriginal.revision,'3');assert.equal(stillOriginal.version,1);
 await denied(original.id,'later-content-denied.bin');
 const changedAccount=run('viewer',['access-original',original.id,target,'deny','2',path('deny.json')],true);assert.match(changedAccount.error,/another original access/);
 assert.equal(run('owner',['get',original.id]).revision,'4');
 result={...original,currentRevision:'4',originalAllowRevision:'2',originalDenyRevision:'3',laterVersion:2,noRegrant:true};
}else throw Error('Unknown stage');
process.stdout.write(JSON.stringify(result));
