import {assertOriginalDeploymentLogs,readOriginalDeploymentRuntime,inspectOriginalDeployment} from './deployment-observation.mjs';
import {YNXCloudClient, YNXCloudError, YNXCloudDeploymentUnknownError} from '../sdk/index.js';
import {types} from 'node:util';
import {
  createDeploymentManifestV2DATA,
  decodeDeploymentManifestV2DATA,
  assertDeploymentArtifactV2DATA,
  bindDeploymentV2Bytes,
  encodeDeploymentV2Bind,
  DEPLOYMENT_MANIFEST_V2_DOMAIN,
} from '@ynx-chain/open-protocol/deployment-v2';

const requestID=value=>{if(typeof value!=='string'||!/^[A-Za-z0-9_-]{16,128}$/.test(value))throw Error('Invalid original request identity');return value;};
const newRequestID=value=>{requestID(value);if(!/^req_[A-Za-z0-9_-]{12,80}$/.test(value))throw Error('New V2 request identity must match the original Native req_ contract');return value;};
const slotRevision=value=>{if(typeof value!=='string'||!/^(0|[1-9][0-9]*)$/.test(value)||BigInt(value)>=18446744073709551615n)throw Error('Invalid expected slot revision');return value;};
const equalBind=(a,b)=>a?.bytes===b?.bytes&&a?.sha3_512===b?.sha3_512&&a?.sha512===b?.sha512;
const sameRef=(a,b)=>!!a&&!!b&&['realm','tenant','kind','id','rev'].every(key=>typeof a[key]==='string'&&a[key]===b[key]);
const sameManifest=(a,b)=>!!a&&!!b&&['realm','tenant','version','env','publisherEpoch','issuerEpoch'].every(key=>a[key]===b[key])&&sameRef(a.project,b.project)&&sameRef(a.publisher,b.publisher)&&sameRef(a.issuer,b.issuer)&&sameRef(a.artifact?.ref,b.artifact?.ref)&&equalBind(a.artifact?.content,b.artifact?.content)&&['size','mime','objectKey'].every(key=>a.artifact?.[key]===b.artifact?.[key]);
const U64=18446744073709551615n;
function observedUint(value){if(typeof value!=='string'||!/^(0|[1-9][0-9]*)$/.test(value)||BigInt(value)>U64)throw Error('Invalid original observation integer');return BigInt(value);}
function readSelection(selection){
  const copy=structuredClone(selection);requestID(copy?.requestId);slotRevision(copy?.expectedSlotRevision);
  if(copy.rollbackTo)requestID(copy.rollbackTo);
  if(copy.manifestVersion!=='2'||copy.domain!==DEPLOYMENT_MANIFEST_V2_DOMAIN||!copy.manifest||Buffer.byteLength(JSON.stringify(copy))>32768)throw Error('Original V2 selection required');
  for(const [binding,limit]of [[copy.manifestBinding,16384n],[copy.contentBinding,67108864n]])if(!binding||observedUint(binding.bytes)>limit||!['sha3_512','sha512'].every(key=>typeof binding[key]==='string'&&/^[0-9a-f]{128}$/.test(binding[key])))throw Error('Original V2 byte binding required');
  return copy;
}
const originalE11Keys=['phase','payloadOriginal','payloadBinding','artifactBinding','sourceCurrentOriginal','reservationOriginal','memberOriginal','coreStatus','cleanupStatus','reportedStatus','signed','sourceGranted','nativeAdmission','deployed'];
function copyExactDATA(value,keys){
  if(types.isProxy(value)||!value||Object.getPrototypeOf(value)!==Object.prototype)throw Error('Original E11 public result DATA required');
  const descriptors=Object.getOwnPropertyDescriptors(value);
  if(Reflect.ownKeys(descriptors).length!==keys.length||keys.some(key=>!descriptors[key]||!Object.hasOwn(descriptors[key],'value')||!descriptors[key].enumerable))throw Error('Original E11 public result schema');
  return Object.fromEntries(keys.map(key=>[key,descriptors[key].value]));
}
function copyOriginalE11DATA(value){
  const copy=copyExactDATA(value,originalE11Keys);
  for(const key of ['payloadBinding','artifactBinding'])copy[key]=copyExactDATA(copy[key],['bytes','sha3_512','sha512']);
  for(const key of ['phase','payloadOriginal','sourceCurrentOriginal','reservationOriginal','memberOriginal'])if(typeof copy[key]!=='string'||copy[key].length>1048576)throw Error('Original E11 bounded string DATA required');
  for(const key of ['signed','sourceGranted','nativeAdmission','deployed'])if(typeof copy[key]!=='boolean')throw Error('Original E11 status DATA required');
  for(const key of ['coreStatus','cleanupStatus','reportedStatus'])if(copy[key]!==null&&!Number.isSafeInteger(copy[key]))throw Error('Original E11 native status DATA required');
  for(const binding of [copy.payloadBinding,copy.artifactBinding])if(Object.values(binding).some(value=>typeof value!=='string'))throw Error('Original E11 binding DATA required');
  if(Buffer.byteLength(JSON.stringify(copy))>1048576)throw Error('Original E11 public result too large');
  return copy;
}
function originalBytes(value,max){
  if(!value||value.length>Math.ceil(max*4/3)||!/^[A-Za-z0-9_-]+$/.test(value))throw Error('Original E11 canonical bytes required');
  const bytes=Buffer.from(value,'base64url');
  if(bytes.length>max||bytes.toString('base64url')!==value)throw Error('Original E11 canonical bytes required');
  return bytes;
}

// This normal caller consumes the sole published SDK export. It does not own an
// E11 codec or a signer, reinterpret ARTIFACT-RELEASE, or grant trusted issuer
// status to a manifest. Keep selection in the IDE's ORIGINAL durable operation.
export class CloudDeploymentV2Client {
  #original; #held=new WeakMap(); #e11Results=new WeakMap(); #native=null; #nativeOpening=null; #nativeError=null; #nativeFailurePresent=false; #nativePartial=null; #nativePackets=new WeakMap(); #nativeClosing=null; #nativeRetired=false; #partialDrain={retired:false,closeSelected:false,closed:false,first:null,firstPresent:false};
  constructor(original){
    if(!(original instanceof YNXCloudClient)||original.product!=='cloud'||typeof original.getDeploymentRequestHeaders!=='function')throw Error('Original Cloud SDK request proof producer required');
    this.#original=original;
  }
  get endpoint(){return this.#original.endpoint.replace(/\/$/,'');}
  prepare(manifest,actualArtifact,{requestId,expectedSlotRevision,rollbackTo=''}={}){
    newRequestID(requestId);slotRevision(expectedSlotRevision);if(rollbackTo){requestID(rollbackTo);if(rollbackTo===requestId)throw Error('Rollback requires a different original request');}
    // The SDK takes the only capture before hashing; decoder and artifact
    // assertion use the actual resulting payload, not reconstructed JSON.
    const made=createDeploymentManifestV2DATA(manifest,actualArtifact);
    const decoded=decodeDeploymentManifestV2DATA(made.payloadOriginal,made.binding);
    const contentBinding=assertDeploymentArtifactV2DATA(made.payloadOriginal,actualArtifact);
    const artifact=Buffer.from(actualArtifact);
    assertDeploymentArtifactV2DATA(made.payloadOriginal,artifact);
    const selection=Object.freeze({requestId,expectedSlotRevision,rollbackTo,manifestVersion:'2',domain:DEPLOYMENT_MANIFEST_V2_DOMAIN,manifestBinding:made.binding,contentBinding,manifest:decoded});
    const prepared=Object.freeze({selection});
    this.#held.set(prepared,{payload:Buffer.from(made.payloadOriginal),artifact,selection});
    return prepared;
  }
  payloadOriginal(prepared){const held=this.#held.get(prepared);if(!held)throw Error('Unknown prepared V2 artifact');return Buffer.from(held.payload);}
  actualArtifactOriginal(prepared){const held=this.#held.get(prepared);if(!held)throw Error('Unknown prepared V2 artifact');return Buffer.from(held.artifact);}
  callerActualDATA(prepared){
    const held=this.#held.get(prepared);if(!held)throw Error('Unknown prepared V2 artifact');
    // Only caller ACTUAL data. Auth must independently supply expected E11,
    // expected E3 binds, network/owner/public pair and private same-process loan.
    // These bytes cannot populate the C ABI's independently selected fields.
    return {payloadOriginal:Buffer.from(held.payload),actualArtifact:Buffer.from(held.artifact),actualPayloadBindE3:encodeDeploymentV2Bind(held.selection.manifestBinding),actualArtifactBindE3:encodeDeploymentV2Bind(held.selection.contentBinding)};
  }
  captureOriginalE11Result(prepared,publicResult){
    const held=this.#held.get(prepared);if(!held)throw Error('Unknown prepared V2 artifact');
    if(this.#e11Results.has(prepared))throw Error('Original E11 result already retained; reconcile original operation');
    const copy=copyOriginalE11DATA(publicResult);
    // Retain the original public partial BEFORE interpreting native/final fence
    // status. This is transport DATA, never a trusted verifier or Source grant.
    const retained={copy,ready:false};this.#e11Results.set(prepared,retained);
    try{
      const payload=originalBytes(copy.payloadOriginal,16384);
      if(!payload.equals(held.payload)||!equalBind(copy.payloadBinding,held.selection.manifestBinding)||!equalBind(copy.artifactBinding,held.selection.contentBinding))throw Error('Original E11 selected bytes changed');
      this.verifyReadback(held.selection,payload,held.artifact);
      originalBytes(copy.memberOriginal,98304);
      // Formal Core header: OK=0 and CLEANUP_LOGICAL_COMPLETE=2. A zero
      // cleanup is NONE, not completion, even when a public Member is present.
      if(copy.phase!=='RETURNED'||copy.signed!==true||copy.coreStatus!==0||copy.cleanupStatus!==2||copy.reportedStatus!==0||!copy.sourceCurrentOriginal||!copy.reservationOriginal||copy.sourceGranted!==false||copy.nativeAdmission!==false||copy.deployed!==false)throw Error('Original E11 final result unconfirmed');
      retained.ready=true;
      return this.originalE11Result(prepared);
    }catch(cause){
      throw Object.assign(Error('Original E11 result requires original-operation reconciliation'),{cause,operationRequestId:held.selection.requestId,retryAllowed:false,partial:structuredClone(copy)});
    }
  }
  originalE11Result(prepared){
    if(!this.#held.has(prepared))throw Error('Unknown prepared V2 artifact');
    const retained=this.#e11Results.get(prepared);if(!retained)return null;
    return {publicResult:structuredClone(retained.copy),readyForTransport:retained.ready,sourceGranted:false,independentlyVerifiedByCloud:false,deployed:false};
  }
  async captureMultipartOriginal(prepared,memberOriginal){
    const held=this.#held.get(prepared);if(!held)throw Error('Unknown prepared V2 artifact');
    if(!(memberOriginal instanceof Uint8Array)||memberOriginal.length<1||memberOriginal.length>98304)throw Error('Original raw E11 Member bytes required');
    const member=Buffer.from(memberOriginal);
    if(held.multipart){
      if(!held.multipart.member.equals(member))throw Error('Original multipart Member changed; reconcile original operation');
    }else{
      const form=new FormData();form.append('manifest',new Blob([held.payload]),'manifest.e11');form.append('approval',new Blob([member]),'approval.wire');form.append('artifact',new Blob([held.artifact]),'artifact.bin');
      // Store the single serialization promise before yielding. A concurrent
      // proof/submit cannot choose a second random boundary for the same op.
      held.multipart={member,promise:(async()=>{
        const request=new Request('https://multipart.capture.invalid/',{method:'POST',body:form});
        const contentType=request.headers.get('content-type');
        const bodyOriginal=Buffer.from(await request.arrayBuffer());
        if(bodyOriginal.length>67108864+1048576+131072||!contentType?.startsWith('multipart/form-data; boundary='))throw Error('Original whole multipart bounds');
        return {bodyOriginal,contentType};
      })()};
    }
    const snapshot=await held.multipart.promise;
    return {bodyOriginal:Buffer.from(snapshot.bodyOriginal),contentType:snapshot.contentType,operationRequestId:held.selection.requestId};
  }
  async submitOriginalE11(prepared,{signal}={}){
    const retained=this.#e11Results.get(prepared);
    if(!retained?.ready)throw Error('Retained original E11 final result required');
    // Normal primary approval part is raw MemberOriginal, never the SDK
    // public partial JSON. The original server Auth independently acquires
    // execute approval from protected Source for the same authenticated req.
    return this.submitPrepared(prepared,originalBytes(retained.copy.memberOriginal,98304),{signal});
  }
  verifyReadback(selection,payloadOriginal,actualArtifact){
    if(selection?.manifestVersion!=='2'||selection.domain!==DEPLOYMENT_MANIFEST_V2_DOMAIN)throw Error('Independent V2 selection required');
    const manifest=decodeDeploymentManifestV2DATA(payloadOriginal,selection.manifestBinding);
    const content=assertDeploymentArtifactV2DATA(payloadOriginal,actualArtifact);
    if(!equalBind(content,selection.contentBinding)||JSON.stringify(manifest)!==JSON.stringify(selection.manifest))throw Error('V2 selected manifest or artifact changed');
    return {manifest,manifestBinding:bindDeploymentV2Bytes(payloadOriginal),contentBinding:content};
  }
  async #originalNative(){
    if(this.#nativeRetired)throw Error('Original Native transport retired');
    if(!this.#nativeOpening)this.#nativeOpening=(async()=>{
      try{
        // Only the sole fixed public factory may acquire the private peer.
        // There is no caller provider/URL/Source/native-module argument.
        const {openOriginalHTTPBinaryClientV5}=await import('@ynx-chain/wallet-auth/original-http-binary-v5-client');
        this.#native=await openOriginalHTTPBinaryClientV5();return this.#native;
      }catch(error){
        this.#nativeFailurePresent=true;
        this.#nativeError=error;
        if(error&&!types.isProxy(error)&&['object','function'].includes(typeof error)){
          const d=Object.getOwnPropertyDescriptor(error,'partial');if(d&&Object.hasOwn(d,'value'))this.#nativePartial=d.value;
        }
        throw error;
      }
    })();
    return this.#nativeOpening;
  }
  async openOriginalNativeTransport(){await this.#originalNative();return this.originalNativeTransportStatus();}
  originalNativeRequestDATA(prepared){
    if(!this.#held.has(prepared))throw Error('Unknown prepared V2 artifact');
    const packet=this.#nativePackets.get(prepared);
    return packet&&this.#native?this.#native.readOriginalRequestDATA(packet.original):null;
  }
  originalNativeTransportStatus(){
    const native=this.#native?.status();
    const code=this.#nativeError&&typeof this.#nativeError==='object'&&!types.isProxy(this.#nativeError)?Object.getOwnPropertyDescriptor(this.#nativeError,'code')?.value:null;
    return {retired:this.#nativeRetired,acquisitionEntered:this.#nativeOpening!==null,ownerAcquired:this.#native!==null,acquisitionPartialRetained:this.#nativePartial!==null,acquisitionFailed:this.#nativeFailurePresent,acquisitionFailureCode:typeof code==='string'?code:null,partialPhysicallyClosed:this.#partialDrain.closed,partialFirstCausePresent:this.#partialDrain.firstPresent,nativeStatus:native?{closed:native.closed,physicalSourceClosed:native.physicalSourceClosed,cleanupDebt:native.cleanupDebt,firstCausePresent:native.firstCausePresent}:null,SourceAdmission:false,NativeAdmission:false};
  }
  async #drainAcquisitionPartial(){
    if(!this.#nativePartial)return;
    const state=this.#partialDrain;
    const remember=e=>{if(!state.firstPresent){state.firstPresent=true;state.first=e;}};
    if(state.closed){if(state.firstPresent)throw state.first;return;}
    const call=async name=>{
      if(types.isProxy(this.#nativePartial))throw Error('Original Native acquisition partial requires owner drain');
      const d=Object.getOwnPropertyDescriptor(this.#nativePartial,name);
      if(!d||!Object.hasOwn(d,'value')||typeof d.value!=='function')throw Error('Original Native acquisition partial requires owner drain');
      if(await d.value.call(this.#nativePartial)!==undefined)throw Error('Original Native acquisition partial drain unconfirmed');
    };
    if(!state.retired){state.retired=true;try{await call('retire');}catch(e){remember(e);}}
    try{await call('join');}catch(e){remember(e);throw state.first;}
    if(!state.closeSelected){state.closeSelected=true;try{await call('close');state.closed=true;}catch(e){remember(e);}}
    if(state.firstPresent)throw state.first;
  }
  async closeOriginalNativeTransport(){
    this.#nativeRetired=true;
    if(!this.#nativeClosing)this.#nativeClosing=(async()=>{
      if(this.#nativeOpening)try{await this.#nativeOpening;}catch{}
      if(this.#native)await this.#native.close();else await this.#drainAcquisitionPartial();
    })();
    return this.#nativeClosing;
  }
  async drainOriginalNativeTransport(){
    if(!this.#nativeClosing)throw Error('Retire original Native transport before drain');
    if(this.#native)return this.#native.drainOriginal();
    return this.#drainAcquisitionPartial();
  }
  #sameNativeDATA(data,selection,snapshot){
    const target=new URL(this.#original.endpoint.replace(/\/$/,'')+'/ide/deployments').toString();
    if(data?.requestId!==selection.requestId||data.method!=='POST'||data.path!=='/api/v1/ide/deployments'||data.url!==target||data.expectedSlotRevision!==selection.expectedSlotRevision||data.rollbackTarget!==selection.rollbackTo||data.contentType!==snapshot.contentType||!(data.bodyOriginal instanceof Uint8Array)||!Buffer.from(data.bodyOriginal).equals(snapshot.bodyOriginal)||data.dataOnly!==true||data.SourceAdmission!==false||data.NativeAdmission!==false)throw Error('Original Native transport selection changed');
  }
  async submitPrepared(prepared,approvalOriginal,{signal}={}){
    const held=this.#held.get(prepared);if(!held)throw Error('Unknown prepared V2 artifact');
    const {selection}=held;this.verifyReadback(selection,held.payload,held.artifact);
    if(!(approvalOriginal instanceof Uint8Array)||approvalOriginal.length<1||approvalOriginal.length>98304)throw Error('Original Auth V2 approval bytes required');
    if(this.#original.deploymentRequests.has(selection.requestId))throw new YNXCloudDeploymentUnknownError(selection.requestId);
    const snapshot=await this.captureMultipartOriginal(prepared,approvalOriginal);
    if(signal?.aborted)throw signal.reason;
    let native;
    try{native=await this.#originalNative();}catch(cause){throw Object.assign(new YNXCloudError('Original Native V5 transport Source unavailable',{status:503,cause}),{operationRequestId:selection.requestId,retryAllowed:false});}
    if(this.#nativeRetired)throw Error('Original Native transport retired');
    if(this.#original.deploymentRequests.has(selection.requestId))throw new YNXCloudDeploymentUnknownError(selection.requestId);
    if(signal?.aborted)throw signal.reason;
    const abortContext=Object.freeze({signal:signal??new AbortController().signal});
    // Enter before the first foreign resource/proof call. Every uncertain
    // Native attempt remains original-query-only; no new boundary or proof.
    this.#original.deploymentRequests.add(selection.requestId);
    try{
      const original=native.prepareOriginalRequest({requestId:selection.requestId,expectedSlotRevision:selection.expectedSlotRevision,rollbackTarget:selection.rollbackTo,bodySnapshot:{bodyOriginal:snapshot.bodyOriginal,contentType:snapshot.contentType},abortContext});
      this.#nativePackets.set(prepared,{original,abortContext});
      this.#sameNativeDATA(native.readOriginalRequestDATA(original),selection,snapshot);
      const proof=await native.produceOriginalProof(original);this.#sameNativeDATA(proof,selection,snapshot);
      if(proof.proofHeaderName!=='x-ynx-product-session-proof-v5'||typeof proof.proofHeader!=='string'||!proof.proofHeader||proof.proofHeader.length>196608||proof.unknown)throw Error('Original V5 whole-body request proof unconfirmed');
      const returned=await native.submitPrepared(original,abortContext);this.#sameNativeDATA(returned,selection,snapshot);
      const response=returned.responseOriginal;
      if(returned.unknown||!returned.httpEntered||!response?.complete||!(response.bodyOriginal instanceof Uint8Array)||response.bodyOriginal.length>1048576||!Number.isInteger(response.status))throw Error('Original Native response unconfirmed');
      if(response.status<200||response.status>=300)throw new YNXCloudError('Original Cloud deployment request returned HTTP '+response.status,{status:response.status});
      const decoded=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(response.bodyOriginal));
      return this.#check(decoded,selection);
    }catch(cause){
      if(cause instanceof YNXCloudDeploymentUnknownError)throw cause;
      throw Object.assign(new YNXCloudError('Original Native V5 deployment requires original-operation reconciliation',{status:Number.isInteger(cause?.status)?cause.status:0,cause}),{operationRequestId:selection.requestId,retryAllowed:false});
    }
  }
  #check(op,selection){
    const unknown=()=>{throw new YNXCloudDeploymentUnknownError(selection.requestId);};
    if(op?.requestId!==selection.requestId||op.manifestVersion!=='2'||!sameManifest(op.manifestV2,selection.manifest)||!equalBind(op.manifestBinding,selection.manifestBinding)||!equalBind(op.contentBinding,selection.contentBinding)||op.expectedSlotRevision!==selection.expectedSlotRevision||(op.rollbackTarget||'')!==selection.rollbackTo||!['unknown','running','completed','failed'].includes(op.state))unknown();
    if(op.slotRevision!==undefined&&op.slotRevision!==String(BigInt(selection.expectedSlotRevision)+1n))unknown();
    if(op.state==='completed'&&op.exitCode!==0)unknown();
    if(['running','completed'].includes(op.state)){
      if(!op.slotRevision||!op.deploymentId||!op.resourceId||typeof op.catalogProjectId!=='string'||!op.catalogProjectId)unknown();
      let url;try{url=new URL(op.runtimeUrl);}catch{unknown();}
      if(!['https:','http:'].includes(url.protocol)||!url.host||url.username||url.password||url.search||url.hash)unknown();
    }
    return op;
  }
  async lookupOriginal(selection,{signal,originalRequestContext}={}){
    const captured=readSelection(selection);
    const op=await this.#original.getIDEDeploymentStatus(captured.requestId,{signal,originalRequestContext});
    // The V2 operation DTO must be supplied by the original service/authority
    // integration. A legacy six-field receipt is never upgraded by its shape.
    return this.#check(op,captured);
  }
  async logs(selection,{signal,originalRequestContext}={}){
    const captured=readSelection(selection),op=await this.lookupOriginal(captured,{signal,originalRequestContext});
    return assertOriginalDeploymentLogs(op,await this.#original.getIDEDeploymentLogs(captured.requestId,{signal,originalRequestContext}));
  }
  async runtime(selection,options){return readOriginalDeploymentRuntime(this.#original,readSelection(selection),(op,s)=>this.#check(op,s),options);}
  async inspect(selection,options){return inspectOriginalDeployment(this,readSelection(selection),options);}
  async usage(selection,{signal,originalRequestContext,observe=true}={}){
    const captured=readSelection(selection),op=await this.lookupOriginal(captured,{signal,originalRequestContext});
    if(!op.deploymentId)throw new YNXCloudDeploymentUnknownError(captured.requestId);
    const path=`/ide/deployments/${captured.requestId}/usage${observe?'':'/records'}`;
    const headers=await this.#original.deploymentHeaders('GET',path,captured.requestId,{},signal,undefined,originalRequestContext);
    const record=await this.#original.request(path,{headers,originalAuthorizationHeaders:headers,signal,retry:1,redirect:'error'});
    const unknown=()=>{throw new YNXCloudDeploymentUnknownError(captured.requestId);};
    if(record?.requestId!==captured.requestId||record.instanceId!==op.deploymentId||!['UNPRICED','PERIOD_BILLS'].includes(record.billingState)||!record.samples||!record.latest)unknown();
    const samples=Object.entries(record.samples);if(!samples.length||samples.length>1024)unknown();
    try{for(const [key,sample]of samples){
      if(sample.instanceId!==op.deploymentId||key!==`${sample.period}/${sample.sampleSeq}`||sample.storedBytes!==captured.contentBinding.bytes)unknown();
      for(const field of ['sampleSeq','cpuNanos','cpuMs','memoryBytes','storedBytes','egressBytes'])observedUint(sample[field]);
      if(BigInt(sample.cpuMs)!==BigInt(sample.cpuNanos)/1000000n||!/^\d{4}-\d{2}-\d{2}$/.test(sample.period)||!Number.isFinite(Date.parse(sample.observedAt))||new Date(sample.observedAt).toISOString().slice(0,10)!==sample.period)unknown();
    }}catch{unknown();}
    const latest=record.samples[`${record.latest.period}/${record.latest.sampleSeq}`];
    if(!latest||['instanceId','period','sampleSeq','cpuNanos','cpuMs','memoryBytes','storedBytes','egressBytes','observedAt'].some(key=>latest[key]!==record.latest[key]))unknown();
    return record;
  }
  // Detached original product DATA over the normal protected reader. This
  // route never enters billUsage/Pay lookup. Source owns the locator; callers
  // retain and compare their original productId/sourceOrder before use.
  async nativeInvoiceIntentOriginal(selection,period,{productId,sourceOrder,signal,originalRequestContext}={}){
    if(productId!=='cloud.ide-usage'||!/^cloud_usage_[0-9a-f]{64}$/.test(sourceOrder??'')||typeof period!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(period)||!Number.isFinite(Date.parse(period+'T00:00:00Z'))||new Date(period+'T00:00:00Z').toISOString().slice(0,10)!==period)throw Error('Exact original Cloud invoice reference required');
    const captured=readSelection(selection),op=await this.lookupOriginal(captured,{signal,originalRequestContext});
    const path=`/ide/deployments/${captured.requestId}/billing/${period}/native-intent`;
    const headers=await this.#original.deploymentHeaders('GET',path,captured.requestId,{},signal,undefined,originalRequestContext);
    const view=await this.#original.request(path,{headers,originalAuthorizationHeaders:headers,signal,retry:1,redirect:'error'});
    const unknown=()=>{throw new YNXCloudDeploymentUnknownError(captured.requestId);};
    const i=view?.request,d=view?.original,r=d?.bill?.request;
    if(!i||!r||i.productId!==productId||i.sourceOrder!==sourceOrder||i.storeId!==undefined||r.billId!==sourceOrder||r.requestId!==captured.requestId||r.period!==period||r.instanceId!==op.deploymentId||d.manifestVersion!=='2'||d.projectId!==op.catalogProjectId||!sameRef(d.projectRef,captured.manifest.project)||d.resourceId!==op.resourceId||d.manifestSHA256!==op.manifestSHA256||d.artifactSHA256!==op.artifactSHA256||!/^[0-9a-f]{64}$/.test(view.originalSHA256??''))unknown();
    for(const [key,value]of Object.entries({merchant:r.merchant,recipient:r.recipient,genesis:r.asset?.genesis,nativeChainId:r.asset?.nativeChainId,assetId:r.asset?.assetId,unitVersion:r.asset?.unitVersion,amountAtoms:r.atoms}))if(i[key]!==value)unknown();
    if(!/^0x[0-9a-f]{40}$/.test(i.merchant)||!/^0x[0-9a-f]{40}$/.test(i.recipient)||i.assetId!=='YNXT'||i.unitVersion!=='1'||!equalBind(r.sampleBinding,d.bill.aggregate?.sampleBinding)||!['UNKNOWN','PREPARED','ISSUED'].includes(d.bill.state)||d.bill.settlement!=='NOT_VERIFIED')unknown();
    try{if(observedUint(i.amountAtoms)===0n||observedUint(i.nativeChainId)===0n)unknown();}catch{unknown();}
    if(JSON.stringify(i.domainData)!==JSON.stringify(r))unknown();
    return view;
  }
  // GET the original sealed bill only. No preparation/invoice/sign/settlement
  // path is added; the registered pricing and current Source remain server-owned.
  async billOriginal(selection,period,options={}){
    if(Object.hasOwn(options,'prepare'))throw Error('Original V2 billing observation is read-only');
    if(typeof period!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(period)||!Number.isFinite(Date.parse(period+'T00:00:00Z'))||new Date(period+'T00:00:00Z').toISOString().slice(0,10)!==period)throw Error('Canonical UTC billing day required');
    const {signal,originalRequestContext}=options,captured=readSelection(selection),op=await this.lookupOriginal(captured,{signal,originalRequestContext});
    const path=`/ide/deployments/${captured.requestId}/billing/${period}`;
    const headers=await this.#original.deploymentHeaders('GET',path,captured.requestId,{},signal,undefined,originalRequestContext);
    const bill=await this.#original.request(path,{headers,originalAuthorizationHeaders:headers,signal,retry:1,redirect:'error'});
    const unknown=()=>{throw new YNXCloudDeploymentUnknownError(captured.requestId);};
    const r=bill?.request,s=bill?.schedule,a=bill?.aggregate;
    if(!r||!s||!a||r.requestId!==captured.requestId||!op.deploymentId||r.instanceId!==op.deploymentId||r.period!==period||a.period!==period||!/^cloud_usage_[0-9a-f]{64}$/.test(r.billId)||!equalBind(r.sampleBinding,a.sampleBinding))unknown();
    if(s.manifestVersion!=='2'||!sameRef(s.projectRef,captured.manifest.project)||s.projectId!==op.catalogProjectId||s.resourceId!==op.resourceId||s.meterRule!=='cumulative-sample-end/UTC-day/ceil-total/v1')unknown();
    for(const [left,right]of [['id','scheduleId'],['revision','scheduleRevision'],['registrationRef','registrationRef'],['approvalRef','approvalRef'],['merchant','merchant'],['recipient','recipient']])if(typeof s[left]!=='string'||!s[left]||s[left]!==r[right])unknown();
    const start=Date.parse(period+'T00:00:00Z'),from=Date.parse(s.effectiveFrom),until=Date.parse(s.effectiveUntil);
    if(!Number.isFinite(from)||!Number.isFinite(until)||from>start||until<start+86400000)unknown();
    if(!r.asset||!s.asset||!/^[0-9a-f]{64}$/.test(r.asset.genesis)||!r.asset.assetId||['genesis','nativeChainId','assetId','unitVersion'].some(key=>r.asset[key]!==s.asset[key]))unknown();
    let total=0n;
    try{
      if(observedUint(s.revision)===0n||observedUint(r.asset.nativeChainId)===0n||BigInt(r.asset.nativeChainId)>9223372036854775807n)unknown();observedUint(r.asset.unitVersion);
      for(const [metric,rate]of [['cpuNanos',s.cpuNanos],['egressBytes',s.egressBytes],['peakStoredBytes',s.peakStoredBytes]]){
        const units=observedUint(rate?.units);if(!units)unknown();total+=(observedUint(a[metric])+units-1n)/units*observedUint(rate.atoms);if(total>U64)unknown();
      }
      if(total!==observedUint(r.atoms))unknown();
    }catch{unknown();}
    if(!['UNKNOWN','PREPARED','ISSUED','NO_CHARGE'].includes(bill.state))unknown();
    if(bill.state==='NO_CHARGE'){if(total!==0n||bill.settlement!=='NOT_APPLICABLE'||bill.invoiceId||bill.originalOperation)unknown();}
    else if(total===0n||bill.settlement!=='NOT_VERIFIED'||(['PREPARED','ISSUED'].includes(bill.state)&&(!bill.invoiceId||!bill.originalOperation)))unknown();
    return bill;
  }
}
