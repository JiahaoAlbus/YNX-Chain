import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFile,writeFile,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
let input='';for await(const b of process.stdin)input+=b;
const {base,token,root,stage,original}=JSON.parse(input),path=n=>join(root,n),cli=fileURLToPath(new URL('./cloud.mjs',import.meta.url));
const run=(args,failure=false,anonymous=false)=>{const env={PATH:process.env.PATH,TMPDIR:process.env.TMPDIR,YNX_CLOUD_API:base,YNX_CLOUD_LOCAL_HTTP:'1'};if(!anonymous)env.YNX_CLOUD_TOKEN=token;const r=spawnSync(process.execPath,[cli,...args],{env,encoding:'utf8',timeout:30000});assert.equal(r.status,failure?1:0,r.stderr);assert.equal((r.stdout+r.stderr).includes(token),false);return JSON.parse(failure?r.stderr:r.stdout);};
let result;
if(stage==='initial'){
 await writeFile(path('v1'),'PUBLIC trash historical1');await writeFile(path('v2'),'PUBLIC trash current2');
 const created=run(['upload',path('v1'),path('upload.json')]);run(['put',created.objectID,'1',path('v2')]);
 const expiry=new Date(Date.now()+600000).toISOString();run(['link-create-original',created.objectID,expiry,path('cap.json')]);
 const lost=run(['trash-original',created.objectID,'2',path('trash.json')],true);assert.equal(lost.outcome,'UNKNOWN');
 const before=JSON.parse(await readFile(path('trash.json'),'utf8'));assert.equal(before.state,'UNKNOWN');
 const denied=run(['link-download',path('cap.json'),path('must-not-read-trash')],true,true);assert.ok([403,404].includes(denied.status));await assert.rejects(stat(path('must-not-read-trash')),{code:'ENOENT'});
 result={id:created.objectID};
}else if(stage==='trash-cold'){
 assert.equal(JSON.stringify(run(['list'])).includes(original.id),false);assert.equal(JSON.stringify(run(['trash-list'])).includes(original.id),true);assert.deepEqual(run(['deletions']),[]);
 const historical=run(['trash-original',original.id,'2',path('trash.json')]);assert.equal(historical.revision,'3');assert.equal(historical.currentTrashState,'NOT_ASSERTED');
 run(['link-cancel-original',path('cap.json')]);
 const lost=run(['restore-trash-original',original.id,'3',path('restore.json')],true);assert.equal(lost.outcome,'UNKNOWN');result=original;
}else if(stage==='restored-cold'){
 const restored=run(['restore-trash-original',original.id,'3',path('restore.json')]);assert.equal(restored.revision,'4');
 const old=run(['trash-original',original.id,'2',path('trash.json')]);assert.equal(old.revision,'3');
 const current=run(['get',original.id]);assert.equal(current.revision,'4');assert.equal(current.trashedAt,undefined);assert.equal(current.version,2);
 assert.equal(JSON.stringify(run(['list'])).includes(original.id),true);assert.equal(JSON.stringify(run(['trash-list'])).includes(original.id),false);assert.deepEqual(run(['deletions']),[]);
 for(const [version,text]of [[1,'PUBLIC trash historical1'],[2,'PUBLIC trash current2']]){const dest=path('download'+version);run(['download',original.id,dest,String(version)]);assert.equal(await readFile(dest,'utf8'),text);}
 assert.equal(run(['link-reconcile-original',path('cap.json')]).outcome,'REVOKED');
 run(['link-download',path('cap.json'),path('must-not-unrevoke')],true,true);await assert.rejects(stat(path('must-not-unrevoke')),{code:'ENOENT'});
 result={...original,versionCount:2,restoredRevision:'4',oldTrashDidNotReapply:true,revokedCapabilityRetained:true,noPermanentDeletion:true};
}else if(stage==='unsupported'){
 const receipt=path('unsupported-receipt.json');const e=run(['trash-original',original.id,'4',receipt],true);assert.match(e.error,/protocol unavailable/);await assert.rejects(stat(receipt),{code:'ENOENT'});result={oldServerNoWrite:true};
}else throw Error('Unknown stage');process.stdout.write(JSON.stringify(result));
