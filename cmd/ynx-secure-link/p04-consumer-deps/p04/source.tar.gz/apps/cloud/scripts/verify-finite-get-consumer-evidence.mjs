import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

export const consumerPackage='github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority';
export const requiredTops=Object.freeze(['TestR5FiniteGETPrincipalFactory','TestR5FiniteGETUnknownAndLate','TestR5ObservationAndV3','TestContextBoundRealServerSequentialRequests','TestR5DefaultV3ReleaseSchema']);
export const requiredSubtests=Object.freeze([
  ...['otherHost','query','rawAlias','contextSwap','headerChanged'].map(n=>'TestR5FiniteGETPrincipalFactory/'+n),
  ...['unknownSQL','lateRevoke'].map(n=>'TestR5FiniteGETUnknownAndLate/'+n),
]);

// Evidence structure only, never a Source/Root or signature verifier. The sole
// CI collector retains the original command, inputs, stdout and process exit.
export function verifyFiniteGETConsumerEvidence(raw){
  const records=new Map();let packageStarts=0,packagePasses=0;
  for(const line of raw.split('\n')){
    if(!line.trim())continue;
    const event=JSON.parse(line);
    if(['fail','skip','build-fail'].includes(event.Action))throw Error('Failed or skipped execution retained');
    if(event.Package&&event.Package!==consumerPackage)throw Error('Unexpected package');
    if(event.Test){
      if(packageStarts!==1||packagePasses)throw Error('Test outside original package lifetime');
      if(event.Package!==consumerPackage||!requiredTops.includes(event.Test.split('/')[0]))throw Error('Unexpected test/package');
      const state=records.get(event.Test)??{run:0,pass:0};
      if(event.Action==='run'){if(packagePasses||state.run||state.pass)throw Error('Duplicate or late RUN');state.run++;}
      if(event.Action==='pass'){if(state.run!==1||state.pass||packagePasses)throw Error('PASS without unique prior RUN');state.pass++;}
      records.set(event.Test,state);
    }else if(event.Package===consumerPackage){
      if(event.Action==='start'){if(packageStarts++||packagePasses)throw Error('Duplicate package start');}
      if(event.Action==='pass'){
        if(packageStarts!==1||packagePasses++)throw Error('Duplicate or unstarted package PASS');
        for(const name of [...requiredTops,...requiredSubtests])if(records.get(name)?.pass!==1)throw Error('Missing required RUN/PASS: '+name);
        for(const state of records.values())if(state.run!==1||state.pass!==1)throw Error('Unfinished actual test');
      }
    }
  }
  if(packagePasses!==1||packageStarts!==1)throw Error('Actual package RUN/PASS required');
  return {package:consumerPackage,topPassed:requiredTops.length,requiredRejectionSubtestsPassed:requiredSubtests.length,skipped:0,failed:0,evidenceOnly:true,RootAdmission:false,SourceAdmission:false,deployed:false};
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  if(process.argv.length!==3)throw Error('Original full-package Go JSON stdout required');
  process.stdout.write(JSON.stringify(verifyFiniteGETConsumerEvidence(await readFile(process.argv[2],'utf8')))+'\n');
}
