package main

import (
	"net/http"
	"sync"
)

// HTTP ownership only, not authentication. Server.Close does not wait for an
// ignoring handler; retain its original Auth/DB parent until actual return.
type ideRequestDrain struct {
	mu      sync.Mutex
	active  int
	retired bool
	done    chan struct{}
}

func newIDERequestDrain() *ideRequestDrain { return &ideRequestDrain{done: make(chan struct{})} }
func (d *ideRequestDrain) wrap(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		d.mu.Lock()
		if d.retired {
			d.mu.Unlock()
			w.Header().Set("Cache-Control", "no-store")
			http.Error(w, "original IDE runtime retiring", http.StatusServiceUnavailable)
			return
		}
		d.active++
		d.mu.Unlock()
		defer func() {
			d.mu.Lock()
			defer d.mu.Unlock()
			d.active--
			if d.retired && d.active == 0 {
				close(d.done)
			}
		}()
		next.ServeHTTP(w, r)
	})
}
func (d *ideRequestDrain) Retire() {
	d.mu.Lock()
	defer d.mu.Unlock()
	if !d.retired {
		d.retired = true
		if d.active == 0 {
			close(d.done)
		}
	}
}
func (d *ideRequestDrain) Join() bool {
	d.mu.Lock()
	defer d.mu.Unlock()
	return d.retired && d.active == 0
}
