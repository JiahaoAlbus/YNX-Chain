//go:build !cloud_link_finite_get

package main

import (
	"context"
	"net/http"
)

// Old builds have no protected listener slot or LINK activation path.
type ideListenerBinding struct{}
type ideRuntimeListener struct{}

func retainOriginalIDEListener(context.Context, *ideRuntimeOwner, *ideDeploymentStartupInputs) error {
	return nil
}
func retireOriginalIDEListener(*ideRuntimeOwner)              {}
func closeOriginalIDEListener(*ideRuntimeOwner) (bool, error) { return true, nil }
func originalIDEListenerComplete(*ideRuntimeOwner) bool       { return true }
func serveOriginalIDEHTTP(server *http.Server, _ *ideRuntimeOwner) error {
	return server.ListenAndServe()
}
