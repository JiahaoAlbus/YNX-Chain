//go:build cloud_auth_finite_get && cloud_link_finite_get

package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
)

func openOriginalIDEFiniteGETReceiver(ctx context.Context, source developerauthority.OriginalSource, runtime *ideRuntimeOwner) (ideFiniteGETReceiverOwner, error) {
	concrete, ok := source.(*developerauthority.OriginalIDEPublicationSourceOwner)
	if !ok || concrete == nil || ctx == nil || ctx.Err() != nil || runtime == nil || runtime.listener == nil {
		return nil, errIDEFiniteGETUnavailable
	}
	// This exact concrete Auth successor independently qualifies the actual
	// same-context LINK listener/request identity outside Source/Store locks.
	owner, err := developerauthority.OpenOriginalIDEFiniteGETPrincipalSource(ctx, concrete, runtime.listener)
	if owner == nil {
		return nil, errIDEFiniteGETUnavailable
	}
	if err != nil {
		return owner, errIDEFiniteGETUnavailable
	}
	return owner, nil
}
