package main

import (
	"context"
	"net/http"
	"os/exec"
	"path/filepath"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/cloud"
)

type publicV2StartupAuthority struct{}

func (*publicV2StartupAuthority) AuthorizeV2(context.Context, *http.Request, string, cloud.IDEDeploymentV2Request) (cloud.IDEDeploymentV2Permit, error) {
	return nil, cloud.ErrDenied
}
func (*publicV2StartupAuthority) AuthorizeV2Read(context.Context, *http.Request, cloud.IDEDeploymentOperation) error {
	return cloud.ErrDenied
}

func TestIDERuntimeV2DATAIsTypedAndSeparateFromProtectedJSON(t *testing.T) {
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	node, err = filepath.Abs(node)
	if err != nil {
		t.Fatal(err)
	}
	bridge, err := filepath.Abs("../../client/deployment-v2-bridge.mjs")
	if err != nil {
		t.Fatal(err)
	}
	codec, err := cloud.NewIDEDeploymentV2Codec(node, bridge)
	if err != nil {
		t.Fatal(err)
	}
	source := &publicIDEConfigSource{}
	authority := &publicV2StartupAuthority{}
	original := &ideDeploymentStartupInputs{Source: source, V2DATA: codec, V2Authority: authority}
	assembled, err := resolveIDEDeploymentStartup(context.Background(), publicIDEConfigFile(t, publicIDEConfigRaw()), original)
	if err != nil || assembled.V2DATA != codec || original.V2DATA != codec || assembled.V2Authority != authority || original.V2Authority != authority {
		t.Fatal("original V2 dependency identity changed")
	}
	raw := publicIDEConfigRaw()
	raw = append([]byte(`{"v2DATA":{"approved":true},`), raw[1:]...)
	if _, err = parseIDEProtectedConfig(raw); err == nil {
		t.Fatal("JSON granted V2 deployment capability")
	}
	raw = publicIDEConfigRaw()
	raw = append([]byte(`{"v2Authority":{"approved":true},`), raw[1:]...)
	if _, err = parseIDEProtectedConfig(raw); err == nil {
		t.Fatal("JSON created V2 execution authority")
	}
}
