package main

import (
	"context"
	"errors"

	"github.com/JiahaoAlbus/YNX-Chain/internal/cloud"
)

var errIDEV2DATAStartup = errors.New("original IDE V2 DATA startup requires one explicit Node/bridge pair and the original Source startup")

// Operator code paths configure DATA parsing only, not a Source/approval
// constructor. Normal source/runtime configuration previously lost this input,
// leaving V2 DATA reachable only through the private in-process test slot.
// Preserve the exact original Source, Catalog, runtime and authority pointers.
func resolveIDEV2DATANormalStartup(ctx context.Context, original *ideDeploymentStartupInputs, node, bridge string) (*ideDeploymentStartupInputs, error) {
	if node == "" && bridge == "" {
		return original, nil
	}
	if ctx == nil || ctx.Err() != nil || node == "" || bridge == "" || original == nil || missingIDEValue(original.Source) || original.V2DATA != nil {
		return nil, errIDEV2DATAStartup
	}
	codec, err := cloud.NewIDEDeploymentV2Codec(node, bridge)
	if err != nil {
		return nil, errIDEV2DATAStartup
	}
	if ctx.Err() != nil {
		return nil, errIDEV2DATAStartup
	}
	copy := *original
	copy.V2DATA = codec
	return &copy, nil
}
