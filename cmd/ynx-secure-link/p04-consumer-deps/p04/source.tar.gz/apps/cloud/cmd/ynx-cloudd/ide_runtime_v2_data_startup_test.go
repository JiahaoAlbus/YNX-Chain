package main

import (
	"context"
	"os/exec"
	"path/filepath"
	"testing"
)

func TestIDEV2DATANormalStartupActualConstructorPreservesSource(t *testing.T) {
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	node, err = filepath.Abs(node)
	if err != nil {
		t.Fatal(err)
	}
	bridge, err := filepath.Abs("../../client/deployment-v2-bridge.mjs")
	if err != nil {
		t.Fatal(err)
	}
	source := &publicIDEConfigSource{}
	authority := &publicV2StartupAuthority{}
	original := &ideDeploymentStartupInputs{Source: source, V2Authority: authority}
	selected, err := resolveIDEV2DATANormalStartup(context.Background(), original, node, bridge)
	if err != nil || selected == nil || selected == original || selected.V2DATA == nil || original.V2DATA != nil || selected.Source != source || selected.V2Authority != authority || selected.Catalog != original.Catalog || selected.Runtime != original.Runtime {
		t.Fatal("normal DATA pair changed original authority/ownership", err)
	}
	for _, pair := range [][2]string{{node, ""}, {"", bridge}, {"/PUBLIC/missing-node", bridge}, {node, "/PUBLIC/missing-bridge"}} {
		if _, err = resolveIDEV2DATANormalStartup(context.Background(), original, pair[0], pair[1]); err == nil {
			t.Fatal("partial/missing normal DATA code admitted")
		}
	}
	if _, err = resolveIDEV2DATANormalStartup(context.Background(), nil, node, bridge); err == nil {
		t.Fatal("DATA paths created a Source")
	}
	if _, err = resolveIDEV2DATANormalStartup(context.Background(), selected, node, bridge); err == nil {
		t.Fatal("duplicate DATA supplier silently replaced")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err = resolveIDEV2DATANormalStartup(ctx, original, node, bridge); err == nil {
		t.Fatal("cancelled startup admitted")
	}
	if absent, err := resolveIDEV2DATANormalStartup(context.Background(), nil, "", ""); err != nil || absent != nil {
		t.Fatal("optional DATA flags changed normal no-Source startup", err)
	}
}
