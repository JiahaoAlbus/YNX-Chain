//go:build !cloud_auth_finite_get || !cloud_link_finite_get

package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
)

// Old compositions cannot silently reinterpret their V2 Principal as V4.
func openOriginalIDEFiniteGETReceiver(context.Context, developerauthority.OriginalSource, *ideRuntimeOwner) (ideFiniteGETReceiverOwner, error) {
	return nil, errIDEFiniteGETUnavailable
}
