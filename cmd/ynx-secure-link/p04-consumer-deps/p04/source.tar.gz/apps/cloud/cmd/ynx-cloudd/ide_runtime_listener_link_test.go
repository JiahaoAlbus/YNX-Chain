//go:build cloud_link_finite_get

package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
	"github.com/JiahaoAlbus/YNX-Chain/internal/securelink"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestIDERuntimeLINKZeroOwnerCannotServeOrQualifyRequest(t *testing.T) {
	actual := &securelink.OriginalServerTLS{}
	if actual.Current(context.Background()) == nil {
		t.Fatal("zero owner qualified")
	}
	if _, e := actual.Identity(context.Background()); e == nil {
		t.Fatal("zero owner supplied identity")
	}
	if actual.CurrentOriginalRequest(httptest.NewRequest("GET", "https://public.invalid/status", nil)) == nil {
		t.Fatal("HTTP DATA minted original connection")
	}
	entered := 0
	server := &http.Server{Handler: http.HandlerFunc(func(http.ResponseWriter, *http.Request) { entered++ })}
	inputs := &ideDeploymentStartupInputs{ideListenerBinding: ideListenerBinding{ServerTLS: actual}}
	runtime := &ideRuntimeOwner{ideRuntimeListener: ideRuntimeListener{listener: inputs.ServerTLS}}
	if e := serveOriginalIDEHTTP(server, runtime); e == nil || entered != 0 {
		t.Fatal("invalid LINK owner fell back to plain/Go TLS server")
	}
}
func TestIDERuntimeLINKUnconfirmedPhysicalCloseHoldsParent(t *testing.T) {
	actual := &securelink.OriginalServerTLS{}
	pool := &publicCatalogPool{}
	owner := &ideRuntimeOwner{pool: pool}
	inputs := &ideDeploymentStartupInputs{ideListenerBinding: ideListenerBinding{ServerTLS: actual}}
	if retainOriginalIDEListener(context.Background(), owner, inputs) == nil || owner.listener != actual {
		t.Fatal("original invalid partial dropped before status")
	}
	if owner.Close() == nil || pool.closes != 0 || owner.finiteCleanupComplete() {
		t.Fatal("Join error interpreted as physical release")
	}
	if owner.ContinueClose() == nil || pool.closes != 0 {
		t.Fatal("cleanup retried a replacement or released unresolved parent")
	}
}
func TestIDERuntimeLINKProtectedAssemblyRetainsExactConcreteOwner(t *testing.T) {
	actual := &securelink.OriginalServerTLS{}
	inputs := &ideDeploymentStartupInputs{ideListenerBinding: ideListenerBinding{ServerTLS: actual}, Source: &publicIDEConfigSource{}}
	got, e := resolveIDEDeploymentStartup(context.Background(), publicIDEConfigFile(t, publicIDEConfigRaw()), inputs)
	if e != nil || got == nil || got.ServerTLS != actual {
		t.Fatal("normal config replaced original typed owner", e)
	}
	if got.ServerTLS.Current(context.Background()) == nil {
		t.Fatal("assembly turned a pointer into authority")
	}
}

func TestIDERuntimeLINKActualAuthFactoryRetainsUnqualifiedPartial(t *testing.T) {
	inputs := &ideDeploymentStartupInputs{ideListenerBinding: ideListenerBinding{ServerTLS: &securelink.OriginalServerTLS{}}}
	runtime := &ideRuntimeOwner{ideRuntimeListener: ideRuntimeListener{listener: inputs.ServerTLS}}
	child, e := openOriginalIDEFiniteGETReceiver(context.Background(), &developerauthority.OriginalIDEPublicationSourceOwner{}, runtime)
	if child == nil || e == nil {
		t.Fatal("actual concrete receiver factory lost partial or admitted zero listener")
	}
	child.Retire()
	if !child.Join() {
		t.Fatal("actual rejected receiver did not drain")
	}
	if child.Close() == nil {
		t.Fatal("original failed acquisition cause cleared")
	}
}

func TestIDERuntimeLINKNormalZeroInputProducerCannotGrantFromEmptySelection(t *testing.T) {
	owner := &ideRuntimeOwner{}
	inputs := &ideDeploymentStartupInputs{}
	if e := retainOriginalIDEListener(context.Background(), owner, inputs); e == nil {
		t.Fatal("empty reviewed issuer selection qualified normal listener")
	}
	// The same partial, if any, stays owned. The normal fallback build may
	// return nil/unavailable; the actual native issuer returns a cleanup owner.
	if inputs.ServerTLS != nil {
		t.Fatal("constructor mutated caller startup selection")
	}
	if owner.listener != nil {
		owner.listener.Retire()
		closed, e := closeOriginalIDEListener(owner)
		if !closed || e == nil {
			t.Fatal("original failed Root0 partial did not close physically with sticky cause", e)
		}
	}
}
