package main

import (
	"context"
	"errors"
	"io"
	"net/http"
	"path/filepath"
	"testing"
	"time"

	"github.com/JiahaoAlbus/YNX-Chain/internal/cloud"
)

// PUBLIC lifecycle-only fixture: no approval, signer, Source or engine works.
type publicV2CloseBaseAuthority struct{ cloud.IDEDeploymentAuthority }

func (publicV2CloseBaseAuthority) AssertCurrent(context.Context) error { return nil }

type publicV2CloseExecutor struct{ cloud.IDEDeploymentExecutor }

func (publicV2CloseExecutor) ApplyExistingV2(context.Context, cloud.IDEDeploymentOperation, string, time.Time, io.Reader, func() error) (cloud.IDEDeploymentResult, error) {
	return cloud.IDEDeploymentResult{}, cloud.ErrDenied
}

type publicV2CloseAuthority struct {
	closes int
	first  error
}

func (*publicV2CloseAuthority) AuthorizeV2(context.Context, *http.Request, string, cloud.IDEDeploymentV2Request) (cloud.IDEDeploymentV2Permit, error) {
	return nil, cloud.ErrDenied
}
func (*publicV2CloseAuthority) AuthorizeV2Read(context.Context, *http.Request, cloud.IDEDeploymentOperation) error {
	return cloud.ErrDenied
}
func (a *publicV2CloseAuthority) Close() error { a.closes++; return a.first }

type publicV2OrderedPool struct {
	publicCatalogPool
	child  *publicV2CloseAuthority
	server *cloud.Server
}

func (p *publicV2OrderedPool) Close() error {
	if _, err := p.server.OpenOriginalIDEUsageBillReader(); err == nil {
		return errors.New("bill reader must retire before borrowed pool")
	}
	if p.child.closes != 1 {
		return errors.New("V2 child must close before borrowed pool")
	}
	p.closes++
	return nil
}

func TestIDERuntimeV2CloseOwnedAuthorityBeforeBorrowedPoolAndRetainFailure(t *testing.T) {
	for _, failed := range []bool{false, true} {
		dir := t.TempDir()
		service, err := cloud.New(cloud.Config{StatePath: filepath.Join(dir, "state.json"), ObjectDir: filepath.Join(dir, "objects")})
		if err != nil {
			t.Fatal(err)
		}
		server := cloud.NewServer(service)
		if err = server.EnableIDEDeployments(publicV2CloseBaseAuthority{}, publicV2CloseExecutor{}); err != nil {
			t.Fatal(err)
		}
		child := &publicV2CloseAuthority{}
		if failed {
			child.first = errors.New("PUBLIC original close UNKNOWN")
		}
		if err = server.EnableIDEDeploymentV2Authority(child); err != nil {
			t.Fatal(err)
		}
		if _, err = server.OpenOriginalIDEUsageBillReader(); err != nil {
			t.Fatal(err)
		}
		pool := &publicV2OrderedPool{child: child, server: server}
		owner := &ideRuntimeOwner{server: server, pool: pool}
		for i := 0; i < 3; i++ {
			err = owner.Close()
			if failed && !errors.Is(err, errIDEClose) || !failed && err != nil {
				t.Fatal("original child close first cause lost", err)
			}
		}
		if pool.closes != 1 || child.closes != 1 {
			t.Fatal("repeated close IO or parent escaped child ownership")
		}
	}
}
