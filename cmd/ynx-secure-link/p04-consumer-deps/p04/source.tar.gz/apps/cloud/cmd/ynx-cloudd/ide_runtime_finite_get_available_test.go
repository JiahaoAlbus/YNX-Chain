//go:build cloud_auth_finite_get

package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
	"testing"
)

func TestIDERuntimeFiniteGETGoTLSOnlyFactoryCannotActivateNormalListener(t *testing.T) {
	// The old Auth factory only accepts Go TLS config. It cannot substitute
	// for the reviewed LINK listener/Native Context.Server owner. No dummy
	// config, certificate or unqualified partial is installed in normal code.
	borrowed := &developerauthority.OriginalIDEPublicationSourceOwner{}
	child, e := openOriginalIDEFiniteGETReceiver(context.Background(), borrowed, nil)
	if child != nil || e == nil {
		t.Fatal("old Go TLS-only factory qualified a normal LINK receiver")
	}
}
