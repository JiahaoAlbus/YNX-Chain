package main

import (
	"github.com/JiahaoAlbus/YNX-Chain/internal/cloud"
	"net/http"
)

// Only the original in-process composition may supply approved pricing and the
// normal native Pay producer. Protected runtime JSON contains neither prices
// nor signer callbacks and cannot instantiate this capability. Nil means that
// deployment/storage remain usable while every charge stays UNPRICED.
// Concrete Source/merchant-native adapters are still an explicit supplier gate.
type ideUsageBillingStartupInputs struct {
	Prices    cloud.IDEUsagePricingAuthority
	Pay       cloud.IDEUsageInvoiceProducer
	NativePay *ideNativePayClientInputs
}

// Private composition only. The client/transport comes from the original LINK
// service identity. This does not accept JSON credentials, create a Source or
// select another origin from a response.
type ideNativePayClientInputs struct {
	Origin string
	Client *http.Client
}

func attachOriginalIDEUsageBilling(server *cloud.Server, inputs *ideUsageBillingStartupInputs) error {
	if inputs == nil || missingIDEValue(inputs.Prices) {
		return nil
	}
	producer := inputs.Pay
	if inputs.NativePay != nil {
		// Ambiguous suppliers never silently replace the original producer.
		if !missingIDEValue(producer) {
			return nil
		}
		var err error
		producer, err = newOriginalNativePayUsageProducer(inputs.NativePay)
		if err != nil {
			return nil
		} // Only charges stay UNPRICED; original runtime survives.
	}
	if missingIDEValue(producer) {
		return nil
	}
	return server.EnableIDEUsageBilling(inputs.Prices, producer)
}
