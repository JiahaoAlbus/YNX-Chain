//go:build pay_pq && pay_cloud

package main

import (
	"github.com/JiahaoAlbus/YNX-Chain/internal/cloud"
	"github.com/JiahaoAlbus/YNX-Chain/internal/payproduct"
)

// The fixed P06 normal producer owns intent IDs, CORE terms, merchant review,
// original Member capture and reconcile. Cloud only composes its real client.
func newOriginalNativePayUsageProducer(inputs *ideNativePayClientInputs) (cloud.IDEUsageInvoiceProducer, error) {
	if inputs == nil {
		return nil, cloud.ErrIDEUsageUnpriced
	}
	client, err := payproduct.NewNativeInvoiceIntentClient(inputs.Origin, inputs.Client)
	if err != nil {
		return nil, err
	}
	return payproduct.NewCloudNativeInvoiceProducer(client)
}
