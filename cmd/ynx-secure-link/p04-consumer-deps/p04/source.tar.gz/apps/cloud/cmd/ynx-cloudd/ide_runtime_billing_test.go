package main

import (
	"context"
	"errors"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/cloud"
	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
)

func TestIDERuntimeBillingPartialKeepsOriginalRuntimeAndCannotEnableFromJSON(t *testing.T) {
	inputs := publicStartupInputs()
	inputs.UsageBilling = &ideUsageBillingStartupInputs{}
	opened := 0
	installed := 0
	owner, err := attachIDEDeploymentRuntime(context.Background(), &cloud.Server{}, inputs, func(context.Context, developerauthority.PostgresCatalogConfig, developerauthority.OriginalSource) (ideCatalogPool, error) {
		opened++
		return &publicCatalogPool{catalog: &developerauthority.Catalog{}}, nil
	}, func(*cloud.Server, *developerauthority.Catalog, cloud.IDEExistingOCIConfig) error {
		installed++
		return nil
	})
	if owner == nil || err != nil || opened != 1 || installed != 1 {
		t.Fatal("missing pricing blocked the original runtime")
	}
	if err = owner.Close(); err != nil {
		t.Fatal(err)
	}
	if err = (&cloud.Server{}).EnableIDEUsageBilling(nil, nil); !errors.Is(err, cloud.ErrIDEUsageUnpriced) {
		t.Fatal("partial pricing enabled a charge")
	}
	raw := publicIDEConfigRaw()
	raw = append([]byte(`{"usageBilling":{"price":"1","approved":true},`), raw[1:]...)
	if _, err = parseIDEProtectedConfig(raw); err == nil {
		t.Fatal("runtime JSON created pricing authority")
	}
}

func TestIDERuntimeBillingTypedInputsSurviveProtectedAssembly(t *testing.T) {
	source := &publicIDEConfigSource{}
	// Empty pointer is retained as a partial to be refused by the real install,
	// never silently dropped into a free/default authority during configuration.
	billing := &ideUsageBillingStartupInputs{}
	original := &ideDeploymentStartupInputs{Source: source, UsageBilling: billing}
	got, err := resolveIDEDeploymentStartup(context.Background(), publicIDEConfigFile(t, publicIDEConfigRaw()), original)
	if err != nil || got == nil || got.UsageBilling != billing || original.UsageBilling != billing {
		t.Fatal("original typed billing ownership lost")
	}
}
