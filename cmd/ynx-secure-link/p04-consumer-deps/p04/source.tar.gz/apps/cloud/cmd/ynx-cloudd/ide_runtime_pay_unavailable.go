//go:build !pay_pq || !pay_cloud

package main

import "github.com/JiahaoAlbus/YNX-Chain/internal/cloud"

// No legacy invoice or default HTTP/signing fallback in an uncomposed build.
func newOriginalNativePayUsageProducer(*ideNativePayClientInputs) (cloud.IDEUsageInvoiceProducer, error) {
	return nil, cloud.ErrIDEUsageUnpriced
}
