//go:build pay_pq && pay_cloud

package main

import (
	"errors"
	"net/http"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/payproduct"
)

type p04NativeNoHTTP struct{ calls int }

func (t *p04NativeNoHTTP) RoundTrip(*http.Request) (*http.Response, error) {
	t.calls++
	return nil, errors.New("PUBLIC no business HTTP expected")
}
func TestIDERuntimeNativePayUsesFixedSupplierConstructor(t *testing.T) {
	transport := &p04NativeNoHTTP{}
	producer, err := newOriginalNativePayUsageProducer(&ideNativePayClientInputs{Origin: "https://private-pay.public-fixture.invalid", Client: &http.Client{Transport: transport}})
	if err != nil {
		t.Fatal(err)
	}
	if _, ok := producer.(*payproduct.CloudNativeInvoiceProducer); !ok {
		t.Fatal("normal native supplier was replaced")
	}
	if transport.calls != 0 {
		t.Fatal("construction created an invoice")
	}
	if _, err = newOriginalNativePayUsageProducer(&ideNativePayClientInputs{Origin: "https://private-pay.public-fixture.invalid", Client: &http.Client{}}); err == nil {
		t.Fatal("missing qualified transport used a default")
	}
}
