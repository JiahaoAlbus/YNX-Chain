package main

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"
)

// PUBLIC lifecycle controls only. These objects never authenticate a request
// and are not a Source factory, Native sender or Root release.
type publicFiniteGETChild struct {
	retire, join, close int
	ready               bool
	closeErr            error
}

func (c *publicFiniteGETChild) Retire()      { c.retire++ }
func (c *publicFiniteGETChild) Join() bool   { c.join++; return c.ready }
func (c *publicFiniteGETChild) Close() error { c.close++; return c.closeErr }

type publicFiniteOrderedPool struct {
	publicCatalogPool
	child *publicFiniteGETChild
}

func (p *publicFiniteOrderedPool) Close() error {
	if p.child.retire != 1 || p.child.close != 1 || !p.child.ready {
		return errors.New("PUBLIC parent escaped original receiver")
	}
	p.closes++
	return nil
}

func TestIDERuntimeFiniteGETOriginalChildBeforeParentAndStickyFailure(t *testing.T) {
	for _, acquireFailed := range []bool{false, true} {
		child := &publicFiniteGETChild{ready: true}
		if acquireFailed {
			child.closeErr = errors.New("PUBLIC original acquisition UNKNOWN")
		}
		pool := &publicFiniteOrderedPool{child: child}
		owner := &ideRuntimeOwner{pool: pool, finiteGET: child}
		var wg sync.WaitGroup
		for i := 0; i < 8; i++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				e := owner.Close()
				if (e != nil) != acquireFailed {
					t.Errorf("first acquisition cause changed: %v", e)
				}
			}()
		}
		wg.Wait()
		if child.retire != 1 || child.close != 1 || pool.closes != 1 || !owner.finiteCleanupComplete() {
			t.Fatal("original child was retried or lost")
		}
		if e := owner.ContinueClose(); (e != nil) != acquireFailed || child.close != 1 || pool.closes != 1 {
			t.Fatal("continuation repeated closed resources")
		}
	}
}
func TestIDERuntimeFiniteGETUndrainedOriginalRetainsParentAndContinuesCleanup(t *testing.T) {
	child := &publicFiniteGETChild{}
	pool := &publicFiniteOrderedPool{child: child}
	owner := &ideRuntimeOwner{pool: pool, finiteGET: child}
	if owner.ContinueClose() == nil || child.retire != 0 {
		t.Fatal("cleanup continuation entered before close")
	}
	if owner.Close() == nil || child.retire != 1 || child.close != 0 || pool.closes != 0 || owner.finiteCleanupComplete() {
		t.Fatal("undrained receiver released its parent")
	}
	child.ready = true
	if owner.Close() == nil || pool.closes != 0 {
		t.Fatal("Close retried unknown receiver instead of retaining cause")
	}
	if owner.ContinueClose() == nil || child.close != 1 || pool.closes != 1 || !owner.finiteCleanupComplete() {
		t.Fatal("original cleanup debt not drained or cause cleared")
	}
	if owner.ContinueClose() == nil || child.close != 1 || pool.closes != 1 {
		t.Fatal("cleanup replayed parent")
	}
}
func TestIDERuntimeFiniteGETConcreteFactoryRejectsForeignSource(t *testing.T) {
	for _, source := range []*publicStartupSource{nil, {}} {
		owner, e := openOriginalIDEFiniteGETReceiver(context.Background(), source, nil)
		if owner != nil || !errors.Is(e, errIDEFiniteGETUnavailable) {
			t.Fatal("foreign or typed nil Source admitted")
		}
	}
}
func TestIDERuntimeFiniteGETProtectedConfigCannotSupplyTLSGrant(t *testing.T) {
	raw := strings.Replace(string(publicIDEConfigRaw()), `{"catalog":`, `{"serverTLS":{"approved":true},"catalog":`, 1)
	if _, e := parseIDEProtectedConfig([]byte(raw)); !errors.Is(e, errIDEConfig) {
		t.Fatal("JSON granted a replacement listener")
	}
}

func TestIDERuntimeFiniteGETCanceledHandlerHoldsOriginalParentUntilReturn(t *testing.T) {
	requests := newIDERequestDrain()
	child := &publicFiniteGETChild{ready: true}
	pool := &publicFiniteOrderedPool{child: child}
	owner := &ideRuntimeOwner{requests: requests, pool: pool, finiteGET: child}
	entered, release, returned := make(chan struct{}), make(chan struct{}), make(chan struct{})
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	handler := requests.wrap(http.HandlerFunc(func(_ http.ResponseWriter, r *http.Request) {
		if r.Context() != ctx {
			t.Error("original HTTP context replaced")
		}
		close(entered)
		<-release
	}))
	go func() {
		defer close(returned)
		handler.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest("GET", "/api/v1/ide/deployments/req_PUBLIC_DRAIN_000001/logs", nil).WithContext(ctx))
	}()
	<-entered
	cancel()
	if owner.Close() == nil || child.retire != 0 || pool.closes != 0 || owner.finiteCleanupComplete() {
		t.Fatal("cancellation/closed socket was treated as physical handler return")
	}
	rejected := httptest.NewRecorder()
	handler.ServeHTTP(rejected, httptest.NewRequest("GET", "/health", nil))
	if rejected.Code != 503 {
		t.Fatal("retired server entered a new handler")
	}
	select {
	case <-requests.done:
		t.Fatal("original handler debt disappeared")
	default:
	}
	close(release)
	<-returned
	<-requests.done
	if owner.ContinueClose() == nil || child.close != 1 || pool.closes != 1 || !owner.finiteCleanupComplete() {
		t.Fatal("same original handler did not drain before parent, or first cause cleared")
	}
}

func TestIDERuntimeFiniteGETActualServerCloseKeepsHandlerDebt(t *testing.T) {
	requests := newIDERequestDrain()
	child := &publicFiniteGETChild{ready: true}
	pool := &publicFiniteOrderedPool{child: child}
	owner := &ideRuntimeOwner{requests: requests, pool: pool, finiteGET: child}
	entered, canceled, release, returned := make(chan struct{}), make(chan struct{}), make(chan struct{}), make(chan struct{})
	var releaseOnce sync.Once
	server := httptest.NewServer(requests.wrap(http.HandlerFunc(func(_ http.ResponseWriter, r *http.Request) {
		defer close(returned)
		close(entered)
		<-r.Context().Done()
		close(canceled)
		<-release
	})))
	t.Cleanup(func() { releaseOnce.Do(func() { close(release) }); server.Close() })
	clientDone := make(chan struct{})
	go func() {
		defer close(clientDone)
		res, _ := server.Client().Get(server.URL + "/api/v1/ide/deployments/req_PUBLIC_HTTP_DRAIN_000001/logs")
		if res != nil {
			res.Body.Close()
		}
	}()
	select {
	case <-entered:
	case <-time.After(2 * time.Second):
		t.Fatal("actual HTTP handler not entered")
	}
	if err := server.Config.Close(); err != nil {
		t.Fatal(err)
	}
	select {
	case <-canceled:
	case <-time.After(2 * time.Second):
		t.Fatal("actual socket close did not cancel request")
	}
	if owner.Close() == nil || pool.closes != 0 || child.retire != 0 {
		t.Fatal("closed real HTTP socket prematurely released original parent")
	}
	select {
	case <-returned:
		t.Fatal("ignoring handler falsely returned")
	default:
	}
	releaseOnce.Do(func() { close(release) })
	<-returned
	<-clientDone
	<-requests.done
	if owner.ContinueClose() == nil || pool.closes != 1 || child.close != 1 {
		t.Fatal("physical HTTP return not followed by original child/parent close, or cause cleared")
	}
}
