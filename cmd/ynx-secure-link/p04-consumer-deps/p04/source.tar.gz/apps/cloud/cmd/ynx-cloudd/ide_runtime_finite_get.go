package main

import "errors"

var errIDEFiniteGETUnavailable = errors.New("original IDE finite GET receiver unavailable")

// Lifecycle only. Production construction accepts the concrete original Auth
// Source, not a callback/provider implementation of request authentication.
type ideFiniteGETReceiverOwner interface {
	Retire()
	Join() bool
	Close() error
}
