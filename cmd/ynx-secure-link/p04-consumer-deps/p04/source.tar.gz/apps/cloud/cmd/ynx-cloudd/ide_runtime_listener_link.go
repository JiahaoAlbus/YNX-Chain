//go:build cloud_link_finite_get

package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/securelink"
	"net/http"
	"time"
)

// Private startup accepts the concrete original LINK owner, never a substitute
// listener, TLSConfig, cert/key DATA, URL, public provider or caller-ready bit.
type ideListenerBinding struct{ ServerTLS *securelink.OriginalServerTLS }
type ideRuntimeListener struct{ listener *securelink.OriginalServerTLS }

func retainOriginalIDEListener(ctx context.Context, owner *ideRuntimeOwner, inputs *ideDeploymentStartupInputs) error {
	if inputs == nil || inputs.ServerTLS == nil {
		if inputs == nil {
			return nil
		}
		actual, err := securelink.OpenOriginalServerTLS(ctx)
		owner.listener = actual
		if err != nil {
			return err
		}
		if actual == nil {
			return errIDEFiniteGETUnavailable
		}
		return actual.Current(ctx)
	}
	owner.listener = inputs.ServerTLS // retain original partial before status
	return owner.listener.Current(ctx)
}
func retireOriginalIDEListener(owner *ideRuntimeOwner) {
	if owner.listener != nil {
		owner.listener.Retire()
	}
}
func closeOriginalIDEListener(owner *ideRuntimeOwner) (bool, error) {
	if owner.listener == nil {
		return true, nil
	}
	// Separate cleanup wait only; no renewed business context or approval.
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := owner.listener.Join(ctx); err != nil {
		return false, err
	}
	err := owner.listener.Close()
	return owner.listener.Lifetime().PhysicalComplete, err
}
func originalIDEListenerComplete(owner *ideRuntimeOwner) bool {
	return owner.listener == nil || owner.listener.Lifetime().PhysicalComplete
}
func serveOriginalIDEHTTP(server *http.Server, owner *ideRuntimeOwner) error {
	if owner != nil && owner.listener != nil {
		return owner.listener.Serve(server)
	}
	// Existing unrelated plain health/service; not a finite GET/PQ fallback.
	return server.ListenAndServe()
}
