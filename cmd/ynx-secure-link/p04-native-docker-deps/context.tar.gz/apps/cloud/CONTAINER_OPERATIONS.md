# YNX Cloud container operations

## Scope and truth boundary

`infra/docker/ynx-cloudd.Dockerfile` packages the bounded Cloud control plane and the Cloud/Docs static clients. It is a local and CI container-delivery candidate. Its existence does not prove production object-store durability, public deployment, hosted downloads, production signing, or central Wallet registration.

The image runs as numeric user `10001:10001`, keeps the root filesystem read-only in the supplied Compose profile, drops all Linux capabilities, enables `no-new-privileges`, and persists mutable state only in `/var/lib/ynx-cloud`. The production runtime never enables the local development Wallet verifier.

## Build and start

```sh
docker compose -f infra/docker/cloud-compose.yml build
docker compose -f infra/docker/cloud-compose.yml up -d
curl --fail http://127.0.0.1:8092/health/live
```

Public liveness proves only that the process is running. Traffic admission must still use the authenticated readiness endpoint and must fail closed while central Wallet or configured providers are unavailable.

## Protected deployment release

The Linux native image uses the original Cloud, Auth and LINK source composition, Go 1.26.11, and the same checksum-pinned OpenSSL 3.6.4 source as LINK CI. Set `YNX_CLOUD_NATIVE_GO_BASE` and `YNX_CLOUD_NATIVE_RUNTIME_BASE` to the reviewed Linux base image references including their OCI digests. Build it through the existing Dockerfile with the native Compose override:

```sh
docker compose -f infra/docker/cloud-compose.yml -f infra/docker/cloud-native-compose.yml build
```

Set `YNX_CLOUD_NATIVE_SOURCE_DIR` to the verified source directory with its module descriptors and suppliers. Set `YNX_CLOUD_RELEASE_COMMIT` to the Cloud source commit, and mount the existing protected inputs and installed Linux client using `YNX_CLOUD_PROTECTED_DIR` and `YNX_CLOUD_CLIENT_DIR`. Set `YNX_CLOUD_IDE_AUTH_CONFIG`, `YNX_CLOUD_IDE_RUNTIME_CONFIG`, `YNX_CLOUD_IDE_V2_NODE` and `YNX_CLOUD_IDE_V2_BRIDGE` to the corresponding absolute paths. Preserve the paths expected by the original owner, including any paths referenced within the protected configuration.

The native profile uses the reviewed LINK listener address on the Linux host network. Its entrypoint requires the original Auth Source, V2 deployment authority and V4 receiver before serving. The original mTLS caller should verify readiness through the reviewed listener. On a native systemd host, the supplied `ynx-cloudd.service.d/protected-deployment.conf` selects the same startup mode with the installed native binary and its pinned OpenSSL libraries.

## Stop and remove

```sh
docker compose -f infra/docker/cloud-compose.yml down
```

Do not add `--volumes` during an ordinary rollback or restart. The named volume contains Cloud metadata and bounded local object bytes. Delete it only after a verified export, backup, retention review, and explicit operator approval.

## Backup and restore

Stop writers before the drill. Use a one-off container against the same named volume to create a recovery bundle in an operator-mounted destination, then restore into a new empty volume or directory. Verify manifest hashes before cutover and retain the previous volume read-only until the rollback window closes.

## CI evidence

The Cloud security workflow builds the exact Dockerfile, cold-starts the container with the same least-privilege controls, checks `/health/live`, verifies the configured numeric user, scans the exact image for Critical and High OS/library vulnerabilities including unfixed findings, and preserves the JSON report even when the scan fails. GitHub Actions run `30279314603` completed successfully for source commit `76f5c92cee7f5105f9e84059d0ae8fed75337e2c`; Trivy 0.70.0 reported zero configured-scope Critical/High findings and uploaded Artifact `8658138768`, whose report SHA-256 is `a4dedb64da62978c03264526d74767b83cdbf835a69a38f2274618864c96a97b`. This evidence is bound to that image, scanner database, time and severity scope. It is not immutable image hosting, continuous monitoring, public deployment, reproducible provenance, production attestation, or signing.
