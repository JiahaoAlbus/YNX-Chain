ARG CLOUD_NATIVE_GO_BASE=golang:1.26.11-bookworm@sha256:79ecd0a7157c7a4cf3b281ced8465350591bf54fedab540e75374a003e1fde7e
ARG CLOUD_NATIVE_RUNTIME_BASE=debian:bookworm-slim@sha256:c67e92c8099ba22853ab4cfda7cfb494d253d6012ca82dee98ba8976772af018
FROM ${CLOUD_NATIVE_GO_BASE} AS native-build

RUN apt-get update && apt-get install -y --no-install-recommends ca-certificates curl perl pkg-config \
    && rm -rf /var/lib/apt/lists/*
WORKDIR /tmp/openssl-build
RUN curl --fail --silent --show-error --location \
      https://github.com/openssl/openssl/releases/download/openssl-3.6.4/openssl-3.6.4.tar.gz -o openssl.tar.gz \
    && echo "9bffaa1ad1e07b354c21bd3324ec02fa15579f45a7d0494b3e74bc449b7333ef  openssl.tar.gz" | sha256sum --check --strict \
    && tar -xzf openssl.tar.gz --strip-components=1 \
    && ./config --release shared --prefix=/opt/ynx/openssl --openssldir=/opt/ynx/openssl/ssl --libdir=lib \
    && make -j2 && make install_sw

WORKDIR /src
COPY --from=cloud_release_source / ./
ENV GOTOOLCHAIN=local GOWORK=off CGO_ENABLED=1 \
    PKG_CONFIG_PATH=/opt/ynx/openssl/lib/pkgconfig \
    PKG_CONFIG_LIBDIR=/opt/ynx/openssl/lib/pkgconfig \
    LD_LIBRARY_PATH=/opt/ynx/openssl/lib
RUN test "$(go env GOVERSION)" = go1.26.11 \
    && test "$(pkg-config --modversion openssl)" = 3.6.4 \
    && go build -mod=readonly -p=2 -trimpath \
      -tags=cloud_auth_v2,cloud_http_v5,cloud_auth_finite_get,cloud_link_finite_get,securelink_openssl,securelink_reviewed_server_tls \
      -o /out/ynx-cloudd ./apps/cloud/cmd/ynx-cloudd

FROM ${CLOUD_NATIVE_RUNTIME_BASE} AS native
RUN apt-get update && apt-get install -y --no-install-recommends ca-certificates \
    && rm -rf /var/lib/apt/lists/* \
    && mkdir -p /var/lib/ynx-cloud && chown 10001:10001 /var/lib/ynx-cloud
COPY --from=native-build /opt/ynx/openssl/lib/libssl.so.3 /opt/ynx/openssl/lib/
COPY --from=native-build /opt/ynx/openssl/lib/libcrypto.so.3 /opt/ynx/openssl/lib/
COPY --from=native-build /out/ynx-cloudd /usr/local/bin/ynx-cloudd
COPY apps/cloud/web /opt/ynx/cloud-web
COPY apps/docs/web /opt/ynx/docs-web
ENV LD_LIBRARY_PATH=/opt/ynx/openssl/lib
USER 10001:10001
WORKDIR /var/lib/ynx-cloud
ENTRYPOINT ["/usr/local/bin/ynx-cloudd", "-require-ide-deployment"]
CMD ["-data", "/var/lib/ynx-cloud", "-cloud-ui", "/opt/ynx/cloud-web", "-docs-ui", "/opt/ynx/docs-web"]

FROM golang:1.25-alpine AS build

WORKDIR /src

COPY go.mod go.sum ./
RUN go mod download

COPY internal/cloud ./internal/cloud
COPY internal/developerauthority ./internal/developerauthority
COPY apps/cloud/cmd/ynx-cloudd ./apps/cloud/cmd/ynx-cloudd

RUN CGO_ENABLED=0 go build \
    -trimpath \
    -ldflags="-s -w" \
    -o /out/ynx-cloudd \
    ./apps/cloud/cmd/ynx-cloudd

FROM alpine:3.22

RUN apk add --no-cache ca-certificates \
    && addgroup -S -g 10001 ynx \
    && adduser -S -D -H -u 10001 -G ynx ynx \
    && mkdir -p /var/lib/ynx-cloud /opt/ynx/cloud-web /opt/ynx/docs-web \
    && chown -R 10001:10001 /var/lib/ynx-cloud /opt/ynx

COPY --from=build /out/ynx-cloudd /usr/local/bin/ynx-cloudd
COPY --chown=10001:10001 apps/cloud/web /opt/ynx/cloud-web
COPY --chown=10001:10001 apps/docs/web /opt/ynx/docs-web

USER 10001:10001
WORKDIR /var/lib/ynx-cloud

EXPOSE 8092
VOLUME ["/var/lib/ynx-cloud"]

HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD ["wget", "-qO-", "http://127.0.0.1:8092/health/live"]

ENTRYPOINT ["/usr/local/bin/ynx-cloudd"]
CMD ["-addr", "0.0.0.0:8092", "-data", "/var/lib/ynx-cloud", "-cloud-ui", "/opt/ynx/cloud-web", "-docs-ui", "/opt/ynx/docs-web"]
