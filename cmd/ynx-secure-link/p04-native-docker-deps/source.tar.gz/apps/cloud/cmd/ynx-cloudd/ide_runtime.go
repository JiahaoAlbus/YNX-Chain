package main

import (
	"context"
	"errors"
	"reflect"
	"sync"

	"github.com/JiahaoAlbus/YNX-Chain/internal/cloud"
	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
)

var errIDEStartup = errors.New("original IDE deployment runtime startup unconfirmed")
var errIDEClose = errors.New("original IDE deployment catalog close unconfirmed")

// Dedicated original Auth/config input, not the legacy file-session producer.
// No HTTP, renderer, environment grant or default Source populates this slot.
// Until the original producer is supplied, normal deployment stays disabled.
var originalIDEDeploymentStartup *ideDeploymentStartupInputs

type ideDeploymentStartupInputs struct {
	ideListenerBinding
	V2Authority  cloud.IDEDeploymentV2Authority
	V2DATA       *cloud.IDEDeploymentV2Codec
	UsageBilling *ideUsageBillingStartupInputs
	Source       developerauthority.OriginalSource
	Catalog      developerauthority.PostgresCatalogConfig
	Runtime      cloud.IDEExistingOCIConfig
}

type ideCatalogPool interface {
	Catalog() (*developerauthority.Catalog, error)
	Close() error
}

type ideRuntimeOwner struct {
	ideRuntimeListener
	server                                              *cloud.Server
	pool                                                ideCatalogPool
	once                                                sync.Once
	closeErr                                            error
	closeMu                                             sync.Mutex
	finiteGET                                           ideFiniteGETReceiverOwner
	finiteGETError                                      error
	v2AuthorityError                                    error
	requests                                            *ideRequestDrain
	finiteRetired, finiteClosed, closing, parentsClosed bool
}

func (*ideRuntimeOwner) String() string {
	return "original IDE runtime owner (private inputs redacted)"
}
func (o *ideRuntimeOwner) Close() error {
	if o == nil {
		return errIDEClose
	}
	o.once.Do(func() {
		o.closeMu.Lock()
		defer o.closeMu.Unlock()
		o.closing = true
		o.closeOriginalChildrenLocked()
	})
	o.closeMu.Lock()
	defer o.closeMu.Unlock()
	return o.closeErr
}

func (o *ideRuntimeOwner) closeOriginalChildrenLocked() {
	retireOriginalIDEListener(o)
	if o.requests != nil {
		o.requests.Retire()
		if !o.requests.Join() {
			o.closeErr = errIDEClose
			return
		}
	}
	if o.server != nil {
		closed, err := o.server.DrainOriginalIDEReadRequests()
		if err != nil {
			o.closeErr = errIDEClose
		}
		if !closed {
			o.closeErr = errIDEClose
			return
		}
	}
	if o.finiteGET != nil && !o.finiteClosed {
		if !o.finiteRetired {
			o.finiteGET.Retire()
			o.finiteRetired = true
		}
		if !o.finiteGET.Join() {
			o.closeErr = errIDEClose
			return
		}
		// The HTTP handlers and their original request children have drained
		// before this parent retirement. Close retains the original acquisition
		// cause independently of physical completion.
		if o.finiteGET.Close() != nil {
			o.closeErr = errIDEClose
		}
		o.finiteClosed = true
	}
	closed, err := closeOriginalIDEListener(o)
	if err != nil {
		o.closeErr = errIDEClose
	}
	if !closed {
		o.closeErr = errIDEClose
		return
	}
	if o.parentsClosed {
		return
	}
	o.parentsClosed = true
	if o.server != nil {
		o.server.RetireOriginalIDEUsageBillReader()
	}
	if o.server != nil && o.server.CloseIDEDeploymentV2Authority() != nil {
		o.closeErr = errIDEClose
	}
	if o.pool == nil || o.pool.Close() != nil {
		o.closeErr = errIDEClose
	}
}

// Cleanup only, on the original partial. Never reopen Source, authenticate,
// consume another nonce or replace the original failed Close result.
func (o *ideRuntimeOwner) ContinueClose() error {
	if o == nil {
		return errIDEClose
	}
	o.closeMu.Lock()
	defer o.closeMu.Unlock()
	if !o.closing {
		return errIDEClose
	}
	o.closeOriginalChildrenLocked()
	return o.closeErr
}
func (o *ideRuntimeOwner) finiteCleanupComplete() bool {
	if o == nil {
		return true
	}
	o.closeMu.Lock()
	defer o.closeMu.Unlock()
	return (o.requests == nil || o.requests.Join()) && (o.server == nil || o.server.OriginalIDEReadCleanupComplete()) && (o.finiteGET == nil || o.finiteClosed) && originalIDEListenerComplete(o)
}

func missingIDEValue(v any) bool {
	if v == nil {
		return true
	}
	value := reflect.ValueOf(v)
	switch value.Kind() {
	case reflect.Pointer, reflect.Interface, reflect.Func, reflect.Map, reflect.Slice, reflect.Chan:
		return value.IsNil()
	}
	return false
}

func attachOriginalIDEDeploymentRuntime(ctx context.Context, server *cloud.Server, inputs *ideDeploymentStartupInputs) (*ideRuntimeOwner, error) {
	var v2AuthorityError error
	owner, err := attachIDEDeploymentRuntime(ctx, server, inputs, func(ctx context.Context, cfg developerauthority.PostgresCatalogConfig, source developerauthority.OriginalSource) (ideCatalogPool, error) {
		owner, err := developerauthority.OpenPostgresCatalog(ctx, cfg, source)
		if owner == nil {
			return nil, err
		}
		return owner, err
	}, func(server *cloud.Server, catalog *developerauthority.Catalog, cfg cloud.IDEExistingOCIConfig) error {
		authority, err := cloud.NewAuthIDEDeploymentAuthority(catalog)
		if err != nil {
			return err
		}
		executor, err := cloud.NewOCIIDEDeploymentExecutor(cfg)
		if err != nil {
			return err
		}
		if err := server.EnableIDEDeployments(authority, executor); err != nil {
			return err
		}
		if inputs.V2DATA != nil {
			if err := server.EnableIDEDeploymentV2DATA(inputs.V2DATA); err != nil {
				return err
			}
		}
		if inputs.V2Authority != nil {
			if err := server.EnableIDEDeploymentV2Authority(inputs.V2Authority); err != nil {
				return err
			}
		} else if inputs.V2DATA != nil {
			// Only V2 effects remain unavailable when the matching Auth/Core
			// source composition or genuine Source admission is missing. The
			// concrete constructor retains any opening partial in the server.
			v2AuthorityError = server.AttachAuthIDEDeploymentV2(ctx, catalog, inputs.Source)
		}
		return attachOriginalIDEUsageBilling(server, inputs.UsageBilling)
	})
	if err != nil || owner == nil {
		return owner, err
	}
	owner.v2AuthorityError = v2AuthorityError
	if err := retainOriginalIDEListener(ctx, owner, inputs); err != nil {
		_ = owner.Close()
		return owner, errIDEStartup
	}
	// Adopt the actual receiver partial before inspecting its constructor
	// result. An unavailable V4 receiver does not grant old V2 fallback.
	owner.finiteGET, owner.finiteGETError = openOriginalIDEFiniteGETReceiver(ctx, inputs.Source, owner)
	if owner.finiteGETError != nil || missingIDEValue(owner.finiteGET) {
		server.RefuseOriginalIDEFiniteGETReads()
	}
	return owner, nil
}

// These private seams test ownership failures only. Production always calls
// the fixed original Auth opener and the original real authority/executor.
func attachIDEDeploymentRuntime(ctx context.Context, server *cloud.Server, inputs *ideDeploymentStartupInputs, open func(context.Context, developerauthority.PostgresCatalogConfig, developerauthority.OriginalSource) (ideCatalogPool, error), install func(*cloud.Server, *developerauthority.Catalog, cloud.IDEExistingOCIConfig) error) (*ideRuntimeOwner, error) {
	if inputs == nil {
		return nil, nil
	}
	if ctx == nil || ctx.Err() != nil || server == nil || missingIDEValue(inputs.Source) || open == nil || install == nil || inputs.Runtime.RuntimeOrigin == "" || inputs.Runtime.HTTPPort < 1024 || inputs.Runtime.HTTPPort > 65535 {
		return nil, errIDEStartup
	}
	if _, ok := inputs.Source.(developerauthority.OriginalPublicationSource); !ok {
		return nil, errIDEStartup
	}
	if _, ok := inputs.Source.(developerauthority.OriginalPublicationSelector); !ok {
		return nil, errIDEStartup
	}
	pool, err := open(ctx, inputs.Catalog, inputs.Source)
	if missingIDEValue(pool) {
		return nil, errIDEStartup
	}
	// Capture even an errored partial before checking status. Failed startup
	// cannot discard an allocated pool or replace close-UNKNOWN with nil/ready.
	owner := &ideRuntimeOwner{pool: pool, server: server}
	fail := func() (*ideRuntimeOwner, error) { _ = owner.Close(); return owner, errIDEStartup }
	if err != nil || ctx.Err() != nil {
		return fail()
	}
	catalog, err := pool.Catalog()
	if err != nil || catalog == nil {
		return fail()
	}
	if err = install(server, catalog, inputs.Runtime); err != nil || ctx.Err() != nil {
		return fail()
	}
	return owner, nil
}
