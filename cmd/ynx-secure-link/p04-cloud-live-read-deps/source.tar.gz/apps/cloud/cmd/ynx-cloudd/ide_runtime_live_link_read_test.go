//go:build (linux || darwin) && cgo && cloud_auth_finite_get && cloud_link_finite_get && securelink_openssl && securelink_public_server_tls_test

package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/cloud"
	"github.com/JiahaoAlbus/YNX-Chain/internal/securelink"
)

func TestIDERuntimeLINKOriginalRequestReachesCloudReadRoutesWithoutGrant(t *testing.T) {
	ctx := context.Background()
	fixture := securelink.NewPUBLICOriginalServerTLSFixture(t)
	actual := fixture.OriginalServerTLS()
	inputs := &ideDeploymentStartupInputs{ideListenerBinding: ideListenerBinding{ServerTLS: actual}}
	owner := &ideRuntimeOwner{}
	if err := retainOriginalIDEListener(ctx, owner, inputs); err != nil || owner.listener != actual {
		t.Fatalf("normal Cloud listener retention: %v", err)
	}
	service, err := cloud.New(cloud.Config{StatePath: filepath.Join(t.TempDir(), "state.json")})
	if err != nil {
		t.Fatal(err)
	}
	server := cloud.NewServer(service)
	owner.requests = newIDERequestDrain()
	handler := owner.requests.wrap(server.WrapIDEProjectRuntime(server.Handler()))
	for _, route := range []struct {
		name  string
		begin func(testing.TB, string) *securelink.PUBLICOriginalServerTLSRequest
	}{
		{"status", fixture.BeginOriginalGET},
		{"logs", fixture.BeginOriginalLogsGET},
	} {
		t.Run(route.name, func(t *testing.T) {
			loan := route.begin(t, "PUBLIC-proof-placeholder-not-an-approval")
			request := loan.OriginalRequest()
			before, err := owner.listener.OriginalRequestIdentity(request)
			if err != nil {
				t.Fatal(err)
			}
			// The fixture holds the actual mTLS handler open. Give the
			// original request pointer to the Cloud handler and inspect its
			// response locally while the original connection remains live.
			response := httptest.NewRecorder()
			handler.ServeHTTP(response, request)
			var body struct{ Code string }
			if err := json.Unmarshal(response.Body.Bytes(), &body); err != nil {
				t.Fatal(err)
			}
			if response.Code != http.StatusServiceUnavailable || body.Code != "IDE_DEPLOYMENT_AUTHORITY_UNAVAILABLE" ||
				response.Header().Get("Cache-Control") != "no-store" || request.PathValue("request") != "PUBLIC_original_operation_0001" {
				t.Fatalf("Cloud %s route without admission: status=%d code=%s", route.name, response.Code, body.Code)
			}
			after, err := owner.listener.OriginalRequestIdentity(request)
			if err != nil || before.InstanceID != after.InstanceID || before.CertificateSHA256 != after.CertificateSHA256 {
				t.Fatalf("Cloud handler changed the original listener selection: %v", err)
			}
			if !server.OriginalIDEReadCleanupComplete() {
				t.Fatal("unadmitted request retained a Cloud read child")
			}
			if err := loan.Close(); err != nil {
				t.Fatal(err)
			}
			if _, err := owner.listener.OriginalRequestIdentity(request); err == nil {
				t.Fatal("closed original request retained live identity")
			}
		})
	}
}
