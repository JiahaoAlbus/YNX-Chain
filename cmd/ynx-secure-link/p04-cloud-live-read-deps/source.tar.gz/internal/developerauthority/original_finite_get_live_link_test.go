//go:build (linux || darwin) && cgo && securelink_openssl && securelink_public_server_tls_test

package developerauthority

import (
	"context"
	"net/http"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/securelink"
)

func TestAuthReceiverRefusesUnboundLINKRequest(t *testing.T) {
	o := new(securelink.OriginalServerTLS)
	r, err := http.NewRequest(http.MethodGet, "https://public-cloud.example/PUBLIC", nil)
	if err != nil {
		t.Fatal(err)
	}
	if got, err := observeOriginalLINKReceiver(r.Context(), o, r); got != nil || err == nil {
		t.Fatal("unbound request obtained identity")
	}
	if got, err := observeOriginalLINKReceiver(r.Context(), o, nil); got != nil || err == nil {
		t.Fatal("unbound listener obtained startup identity")
	}
}

func TestAuthReceiverUsesLiveLINKRequestIdentity(t *testing.T) {
	first := securelink.NewPUBLICOriginalServerTLSFixture(t)
	replacement := securelink.NewPUBLICOriginalServerTLSFixture(t)
	o := first.OriginalServerTLS()
	startup, err := observeOriginalLINKReceiver(context.Background(), o, nil)
	if err != nil || startup == nil {
		t.Fatal("startup original listener", err)
	}
	request := first.BeginOriginalGET(t, "PUBLIC-proof-placeholder-not-an-approval")
	r := request.OriginalRequest()
	live, err := observeOriginalLINKReceiver(r.Context(), o, r)
	if err != nil || live == nil || live.identity.InstanceID != startup.identity.InstanceID ||
		live.identity.CertificateSHA256 != startup.identity.CertificateSHA256 {
		t.Fatal("same live listener request", err)
	}
	if _, err = observeOriginalLINKReceiver(r.Context(), replacement.OriginalServerTLS(), r); err == nil {
		t.Fatal("replacement listener accepted")
	}
	if _, err = observeOriginalLINKReceiver(r.Context(), o, r.Clone(r.Context())); err == nil {
		t.Fatal("clone accepted")
	}
	if _, err = observeOriginalLINKReceiver(context.Background(), o, r); err == nil {
		t.Fatal("replacement context accepted")
	}
	if err = request.Close(); err != nil {
		t.Fatal(err)
	}
	if _, err = observeOriginalLINKReceiver(r.Context(), o, r); err == nil {
		t.Fatal("closed request returned identity")
	}
}
