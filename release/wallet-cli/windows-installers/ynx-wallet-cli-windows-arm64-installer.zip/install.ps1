param([string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'YNX Wallet CLI'))
$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'ynx-wallet-cli.exe'
$manifest = Get-Content (Join-Path $PSScriptRoot 'manifest.json') -Raw | ConvertFrom-Json
$actual = (Get-FileHash $source -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $manifest.binarySha256) { throw 'installer payload hash mismatch' }
New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
$target = Join-Path $InstallRoot 'ynx-wallet-cli.exe'
$temporary = Join-Path $InstallRoot 'ynx-wallet-cli.exe.new'
Copy-Item $source $temporary -Force
Move-Item $temporary $target -Force
Copy-Item (Join-Path $PSScriptRoot 'manifest.json') (Join-Path $InstallRoot 'manifest.json') -Force
Write-Output $target
