param([string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'YNX Wallet CLI'))
$ErrorActionPreference = 'Stop'
$allowed = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'YNX Wallet CLI'))
$target = [IO.Path]::GetFullPath($InstallRoot)
if ($target -ne $allowed) { throw 'refusing to uninstall outside the canonical user directory' }
if (Test-Path $target) { Remove-Item $target -Recurse -Force }
if (Test-Path $target) { throw 'uninstall failed' }
Write-Output $target
