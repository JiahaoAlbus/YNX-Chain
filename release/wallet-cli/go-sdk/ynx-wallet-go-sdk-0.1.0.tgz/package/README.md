# YNX Wallet Go SDK

Frozen Product Session HTTP proof consumer for YNX Wallet integrations. This module does not define a new Auth protocol, persist keys, claim balances, or create transactions. Requires Go 1.25.0 or later.
