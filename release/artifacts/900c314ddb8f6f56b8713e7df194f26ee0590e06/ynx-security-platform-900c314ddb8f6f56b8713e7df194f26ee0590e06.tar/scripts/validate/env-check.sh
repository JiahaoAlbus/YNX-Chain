#!/usr/bin/env bash
set -euo pipefail

templates=(.env.example .env.testnet.example .env.website.example .env.ai.example .env.pay.example .env.trust.example .env.resource.example .env.indexer.example .env.explorer.example .env.faucet.example .env.ide.example .env.monitoring.example .env.deploy.example)
for f in "${templates[@]}"; do
  test -f "$f" || { echo "missing env template: $f"; exit 1; }
done
grep -q '^CHAIN_ID=' .env.testnet.example
grep -q '^NATIVE_SYMBOL=' .env.testnet.example

if [[ -n "${ENV_FILE:-}" || -f .env.deploy || -f .env ]]; then
  # shellcheck source=../deploy/lib.sh
  source "$(dirname "$0")/../deploy/lib.sh"
  ynx_load_env
  YNX_BRIDGE_DEPLOY_ENABLED="${YNX_BRIDGE_DEPLOY_ENABLED:-false}"
  YNX_STABLECOIN_DEPLOY_ENABLED="${YNX_STABLECOIN_DEPLOY_ENABLED:-false}"
  YNX_CHAT_DEPLOY_ENABLED="${YNX_CHAT_DEPLOY_ENABLED:-false}"
  YNX_SQUARE_DEPLOY_ENABLED="${YNX_SQUARE_DEPLOY_ENABLED:-false}"
  YNX_APP_GATEWAY_DEPLOY_ENABLED="${YNX_APP_GATEWAY_DEPLOY_ENABLED:-false}"
  required=(
    TESTNET_DOMAIN WEBSITE_DOMAIN EXPLORER_DOMAIN REST_DOMAIN INDEXER_DOMAIN RPC_DOMAIN EVM_RPC_DOMAIN
    FAUCET_DOMAIN API_DOMAIN AI_GATEWAY_DOMAIN TRUST_API_DOMAIN RESOURCE_API_DOMAIN PAY_API_DOMAIN IDE_DOMAIN
    SERVER_HOST SERVER_USER SSH_KEY_PATH DEPLOY_TARGET CHAIN_ID CHAIN_NAME
    NATIVE_COIN_NAME NATIVE_SYMBOL GENESIS_VALIDATOR_NAME VALIDATOR_KEY_PATH
    FAUCET_PRIVATE_KEY DEPLOYER_PRIVATE_KEY TREASURY_ADDRESS FOUNDATION_ADDRESS
    TEAM_VESTING_ADDRESS POSTGRES_URL REDIS_URL WEBHOOK_SECRET JWT_SECRET
    SESSION_SECRET RATE_LIMIT_SECRET PAY_MERCHANT_SECRET TRUST_REPORT_SIGNING_KEY
    OBJECT_STORAGE_ENDPOINT OBJECT_STORAGE_BUCKET OBJECT_STORAGE_ACCESS_KEY OBJECT_STORAGE_SECRET_KEY
    OPENAI_API_KEY AI_MODEL_NAME YNX_AI_GATEWAY_API_KEY YNX_AI_GATEWAY_UPSTREAM_KEY YNX_AI_PROVIDER_URL YNX_AI_GATEWAY_HTTP_ADDR
    YNX_AI_GATEWAY_CHAIN_URL YNX_AI_GATEWAY_AUDIT_LOG YNX_AI_GATEWAY_RATE_LIMIT_WINDOW YNX_AI_GATEWAY_RATE_LIMIT_MAX
    YNX_PAY_MERCHANT_ID YNX_PAY_API_KEY YNX_PAY_GATEWAY_UPSTREAM_KEY YNX_PAY_WEBHOOK_SIGNING_KEY YNX_PAY_GATEWAY_HTTP_ADDR
    YNX_PAY_GATEWAY_CHAIN_URL YNX_PAY_GATEWAY_AUDIT_LOG YNX_PAY_GATEWAY_RATE_LIMIT_WINDOW YNX_PAY_GATEWAY_RATE_LIMIT_MAX
    YNX_TRUST_API_KEY YNX_TRUST_GATEWAY_UPSTREAM_KEY YNX_TRUST_GATEWAY_HTTP_ADDR YNX_TRUST_GATEWAY_CHAIN_URL
    YNX_TRUST_GATEWAY_AUDIT_LOG YNX_TRUST_GATEWAY_RATE_LIMIT_WINDOW YNX_TRUST_GATEWAY_RATE_LIMIT_MAX
    YNX_RESOURCE_API_KEY YNX_RESOURCE_GATEWAY_UPSTREAM_KEY YNX_RESOURCE_GATEWAY_HTTP_ADDR YNX_RESOURCE_GATEWAY_CHAIN_URL
    YNX_RESOURCE_GATEWAY_AUDIT_LOG YNX_RESOURCE_GATEWAY_RATE_LIMIT_WINDOW YNX_RESOURCE_GATEWAY_RATE_LIMIT_MAX
    EMAIL_PROVIDER EMAIL_API_KEY MONITORING_ADMIN_PASSWORD
    BACKUP_STORAGE_PATH SSL_EMAIL NGINX_SERVER_NAME GITHUB_REPO_TOKEN
    PRIMARY_NODE_HOST PRIMARY_NODE_USER PRIMARY_NODE_SSH_KEY SG_NODE_HOST SG_NODE_USER SG_NODE_SSH_KEY
    SG_OBSERVER_FILE SILICON_VALLEY_NODE_HOST SILICON_VALLEY_NODE_USER SILICON_VALLEY_NODE_SSH_KEY
    SEOUL_NODE_HOST SEOUL_NODE_USER SEOUL_NODE_SSH_KEY PUBLIC_RPC_URL PUBLIC_EVM_RPC_URL
    PUBLIC_EVM_WS_URL PUBLIC_REST_URL PUBLIC_GRPC_HOST PUBLIC_FAUCET_URL PUBLIC_INDEXER_URL
    PUBLIC_EXPLORER_URL PUBLIC_AI_URL PUBLIC_PAY_URL PUBLIC_TRUST_URL PUBLIC_RESOURCE_URL PUBLIC_WEB4_URL YNX_COSMOS_CHAIN_ID YNX_EVM_CHAIN_ID
    YNX_EVM_CHAIN_ID_HEX YNX_NATIVE_COIN_NAME YNX_NATIVE_COIN_SYMBOL YNX_VALIDATOR_SET YNX_BOOTSTRAP_PEERS YNX_EXPECTED_VALIDATOR_COUNT YNX_NODE_HTTP_ADDR
    YNX_REPLICATION_KEY YNX_REPLICATION_INTERVAL
  )
  ynx_require_env "${required[@]}"
  ynx_reject_unsafe_env_values "${required[@]}"
  case "$YNX_BRIDGE_DEPLOY_ENABLED" in
    true | false) ;;
    *) echo "YNX_BRIDGE_DEPLOY_ENABLED must be true or false"; exit 1 ;;
  esac
  if [[ "$YNX_BRIDGE_DEPLOY_ENABLED" == "true" ]]; then
    bridge_required=(YNX_BRIDGE_API_KEY YNX_BRIDGE_RELAYERS_JSON YNX_BRIDGE_ROUTE_POLICIES_JSON YNX_BRIDGE_RELAYER_THRESHOLD YNX_BRIDGE_HTTP_ADDR)
    ynx_require_env "${bridge_required[@]}"
    ynx_reject_unsafe_env_values "${bridge_required[@]}"
  fi
  case "$YNX_STABLECOIN_DEPLOY_ENABLED" in
    true | false) ;;
    *) echo "YNX_STABLECOIN_DEPLOY_ENABLED must be true or false"; exit 1 ;;
  esac
  if [[ "$YNX_STABLECOIN_DEPLOY_ENABLED" == "true" ]]; then
    stablecoin_required=(YNX_STABLECOIN_API_KEY YNX_STABLECOIN_HTTP_ADDR)
    ynx_require_env "${stablecoin_required[@]}"
    ynx_reject_unsafe_env_values "${stablecoin_required[@]}"
  fi
  case "$YNX_CHAT_DEPLOY_ENABLED" in
    true | false) ;;
    *) echo "YNX_CHAT_DEPLOY_ENABLED must be true or false"; exit 1 ;;
  esac
  if [[ "$YNX_CHAT_DEPLOY_ENABLED" == "true" ]]; then
    chat_required=(YNX_CHAT_API_KEY YNX_CHAT_HTTP_ADDR)
    ynx_require_env "${chat_required[@]}"
    ynx_reject_unsafe_env_values "${chat_required[@]}"
  fi
  case "$YNX_SQUARE_DEPLOY_ENABLED" in
    true | false) ;;
    *) echo "YNX_SQUARE_DEPLOY_ENABLED must be true or false"; exit 1 ;;
  esac
  if [[ "$YNX_SQUARE_DEPLOY_ENABLED" == "true" ]]; then
    square_required=(YNX_SQUARE_API_KEY YNX_SQUARE_HTTP_ADDR)
    ynx_require_env "${square_required[@]}"
    ynx_reject_unsafe_env_values "${square_required[@]}"
  fi
  case "$YNX_APP_GATEWAY_DEPLOY_ENABLED" in
    true | false) ;;
    *) echo "YNX_APP_GATEWAY_DEPLOY_ENABLED must be true or false"; exit 1 ;;
  esac
  if [[ "$YNX_APP_GATEWAY_DEPLOY_ENABLED" == "true" ]]; then
    [[ "$YNX_CHAT_DEPLOY_ENABLED" == "true" && "$YNX_SQUARE_DEPLOY_ENABLED" == "true" ]] || { echo "App Gateway requires Chat and Square deployment"; exit 1; }
    app_gateway_required=(YNX_APP_GATEWAY_HTTP_ADDR YNX_APP_GATEWAY_ALLOWED_ORIGINS)
    ynx_require_env "${app_gateway_required[@]}"
    ynx_reject_unsafe_env_values "${app_gateway_required[@]}"
  fi
  [[ "$NATIVE_SYMBOL" == "YNXT" ]] || { echo "NATIVE_SYMBOL must be YNXT"; exit 1; }
  [[ "$NATIVE_COIN_NAME" == "YNXT" ]] || { echo "NATIVE_COIN_NAME must be YNXT"; exit 1; }
  [[ "$CHAIN_NAME" == "YNX Testnet" || "$CHAIN_NAME" == "YNX Devnet" || "$CHAIN_NAME" == "YNX Mainnet" ]] || { echo "CHAIN_NAME must be a YNX network name"; exit 1; }
  [[ "$CHAIN_ID" =~ ^[0-9]+$ ]] || { echo "CHAIN_ID must be numeric"; exit 1; }
  [[ "${#YNX_REPLICATION_KEY}" -ge 32 ]] || { echo "YNX_REPLICATION_KEY must contain at least 32 characters"; exit 1; }
  [[ "$YNX_REPLICATION_INTERVAL" =~ ^[1-9][0-9]*(ms|s|m)$ ]] || { echo "YNX_REPLICATION_INTERVAL must be a positive duration"; exit 1; }
  echo "real deployment env validation passed for ${ENV_FILE:-auto-detected env file}"
else
  echo "env templates present; real deployment env values must be supplied via ENV_INTAKE_FORM.md"
fi
