import { readFile, writeFile, readdir } from 'node:fs/promises';

const root = new URL('../', import.meta.url);
const res = new URL('android/app/src/main/res/', root);
const catalogURL = new URL('ios/YNXShop/Localizable.xcstrings', root);
const locales = {
  values: 'en',
  'values-zh-rCN': 'zh-Hans',
  'values-zh-rTW': 'zh-Hant',
  'values-ja': 'ja',
  'values-ko': 'ko',
  'values-es': 'es',
  'values-fr': 'fr',
  'values-de': 'de',
  'values-pt': 'pt',
  'values-ru': 'ru',
  'values-ar': 'ar',
  'values-in': 'id',
};
const parse = xml => Object.fromEntries(
  [...xml.matchAll(/<string name="([^"]+)">([^<]+)<\/string>/g)]
    .map(match => [match[1], match[2].replaceAll('&amp;', '&').replaceAll("\\'", "'")]),
);
const readLocale = async dir => {
  const values = {};
  const files = (await readdir(new URL(`${dir}/`, res))).filter(name => name.endsWith('.xml')).sort();
  for (const file of files) Object.assign(values, parse(await readFile(new URL(`${dir}/${file}`, res), 'utf8')));
  return values;
};

const catalog = JSON.parse(await readFile(catalogURL, 'utf8'));
for (const [dir, lang] of Object.entries(locales)) {
  const values = await readLocale(dir);
  for (const [key, value] of Object.entries(values)) {
    catalog.strings[key] ??= {};
    catalog.strings[key].localizations ??= {};
    catalog.strings[key].localizations[lang] = { stringUnit: { state: 'translated', value } };
  }
}
const extra = {
  trust_evidence: ['Trust evidence', 'Trust 证据', 'Trust 證據', 'Trustの証拠', 'Trust 증거', 'Evidencia de Trust', 'Preuves Trust', 'Trust-Nachweise', 'Evidências do Trust', 'Доказательства Trust', 'دليل Trust', 'Bukti Trust'],
  no_fake_records: ['No products, sales, tax, or logistics are fabricated.', '不虚构商品、销量、税务或物流。', '不虛構商品、銷量、稅務或物流。', '商品、販売数、税務、物流を捏造しません。', '상품, 판매량, 세금 또는 물류를 조작하지 않습니다.', 'No se inventan productos, ventas, impuestos ni logística.', 'Aucun produit, vente, taxe ou suivi logistique n’est inventé.', 'Produkte, Verkäufe, Steuern oder Logistik werden nicht erfunden.', 'Produtos, vendas, impostos ou logística não são inventados.', 'Товары, продажи, налоги и логистика не выдумываются.', 'لا يتم اختلاق منتجات أو مبيعات أو ضرائب أو خدمات لوجستية.', 'Produk, penjualan, pajak, atau logistik tidak dibuat-buat.'],
  trust_boundary: ['Only submitted Trust case evidence is shown; Trust cannot move payment.', '仅显示已提交的 Trust 案件证据；Trust 不能划转付款。', '僅顯示已提交的 Trust 案件證據；Trust 不能移轉付款。', '提出済みのTrust証拠のみ表示し、Trustは支払いを移動できません。', '제출된 Trust 사건 증거만 표시되며 Trust는 결제를 이동할 수 없습니다.', 'Solo se muestra evidencia enviada a Trust; Trust no puede mover pagos.', 'Seules les preuves soumises à Trust sont affichées ; Trust ne peut déplacer aucun paiement.', 'Nur eingereichte Trust-Nachweise werden gezeigt; Trust kann keine Zahlung bewegen.', 'Apenas evidências enviadas ao Trust são exibidas; o Trust não pode mover pagamentos.', 'Показаны только переданные в Trust доказательства; Trust не может переводить платежи.', 'يُعرض فقط دليل قضية Trust المرسل؛ ولا يمكن لـ Trust نقل المدفوعات.', 'Hanya bukti kasus Trust yang dikirim ditampilkan; Trust tidak dapat memindahkan pembayaran.'],
  reason: ['Reason and explanation', '原因与说明', '原因與說明', '理由と説明', '사유 및 설명', 'Motivo y explicación', 'Motif et explication', 'Grund und Erläuterung', 'Motivo e explicação', 'Причина и пояснение', 'السبب والشرح', 'Alasan dan penjelasan'],
  order_actions: ['Order actions', '订单操作', '訂單操作', '注文操作', '주문 작업', 'Acciones del pedido', 'Actions de la commande', 'Bestellaktionen', 'Ações do pedido', 'Действия с заказом', 'إجراءات الطلب', 'Tindakan pesanan'],
  service_boundaries: ['Service boundaries', '服务边界', '服務邊界', 'サービス境界', '서비스 경계', 'Límites de servicio', 'Limites des services', 'Dienstgrenzen', 'Limites dos serviços', 'Границы сервисов', 'حدود الخدمات', 'Batas layanan'],
};
const languages = Object.values(locales);
for (const [key, values] of Object.entries(extra)) {
  catalog.strings[key] ??= {};
  catalog.strings[key].localizations = Object.fromEntries(
    languages.map((language, index) => [language, { stringUnit: { state: 'translated', value: values[index] } }]),
  );
}
// The YNX brand name is identical in every supported language.
if (catalog.strings.ynx_logo) for (const language of languages) catalog.strings.ynx_logo.localizations[language] = { stringUnit: { state: 'translated', value: 'YNX' } };
catalog.sourceLanguage = 'en';
catalog.version = '1.0';
await writeFile(catalogURL, `${JSON.stringify(catalog, null, 2)}\n`);
console.log('Synchronized iOS catalog from audited Android translations.');
