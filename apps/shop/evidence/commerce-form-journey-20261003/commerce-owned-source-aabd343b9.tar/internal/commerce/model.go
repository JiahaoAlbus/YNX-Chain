package commerce

import (
	"encoding/json"
	"time"
)

type BusinessEffect struct {
	ID, Actor, Role, Kind, Target, RequestHash, Phase, Admission string
	Input, Result, Response                                      json.RawMessage
	CreatedAt, UpdatedAt                                         time.Time
	Steps                                                        []BusinessEffectStep
}

type BusinessEffectStep struct {
	Method, Origin, Path, RequestDigest, Phase string
	Request, Response                          []byte
	Status                                     int
}

const (
	ChainID      = 6423
	ChainName    = "ynx_6423-1"
	NativeSymbol = "YNXT"
)

type StoreProfile struct {
	ID, Owner, Name, Description, Policy, TrustURL, SettlementAccount string
	Status                                                            string
	CreatedAt, UpdatedAt                                              time.Time
}

type PublicStore struct {
	ID, Name, Description, Policy, TrustURL, Status string
}

type BuyerProfile struct {
	Account, DisplayName string
	Addresses            []Address
	UpdatedAt            time.Time
}

type BuyerDataExport struct {
	SchemaVersion   int              `json:"schemaVersion"`
	ExportedAt      time.Time        `json:"exportedAt"`
	Account         string           `json:"account"`
	Profile         BuyerProfile     `json:"profile"`
	Cart            Cart             `json:"cart"`
	Orders          []Order          `json:"orders"`
	AIJobs          []AIJob          `json:"aiJobs"`
	AuditEvents     []AuditEvent     `json:"auditEvents"`
	BusinessEffects []BusinessEffect `json:"businessEffects"`
	RetentionNotice string           `json:"retentionNotice"`
}

type BuyerDataDeletionReceipt struct {
	ReceiptID                string    `json:"receiptId"`
	DeletedAt                time.Time `json:"deletedAt"`
	ProfileDeleted           bool      `json:"profileDeleted"`
	CartDeleted              bool      `json:"cartDeleted"`
	AIJobsDeleted            int       `json:"aiJobsDeleted"`
	BusinessEffectsDeleted   int       `json:"businessEffectsDeleted"`
	IdempotencyDeleted       int       `json:"idempotencyDeleted"`
	RateWindowsDeleted       int       `json:"rateWindowsDeleted"`
	OrdersPseudonymized      int       `json:"ordersPseudonymized"`
	AuditEventsPseudonymized int       `json:"auditEventsPseudonymized"`
	RetainedRecords          []string  `json:"retainedRecords"`
	RetiredIntentsVersion    int       `json:"retiredIntentsVersion"`
	RetiredIntentsCount      int       `json:"retiredIntentsCount"`
	DeletionRequestID        string    `json:"deletionRequestId,omitempty"`
}

// A client can retire an admitted request whose outcome is still unknown,
// without sending its body or an identity other than the authenticated buyer.
type RetiredIntent struct {
	Route string `json:"route"`
	Key   string `json:"key"`
}

type BuyerDeletionRecord struct {
	RequestDigest string
	Receipt       BuyerDataDeletionReceipt
}

type Cart struct {
	Revision  string
	Buyer     string
	Items     []CartItem
	UpdatedAt time.Time
}

type Variant struct {
	ID, Name, SKU string
	PriceYNXT     int64
	Inventory     int64
	Reserved      int64
}

type MediaAsset struct {
	URL, AltText, Kind string
}

type ProductRevision struct {
	Revision                     int64
	Actor, Action, RequestHash   string
	Title, Description, Category string
	Media                        []MediaAsset
	Variants                     []Variant
	Published                    bool
	At                           time.Time
}

type Product struct {
	ID, StoreID, Title, Description, Category string
	Published                                 bool
	Media                                     []MediaAsset
	Variants                                  []Variant
	Revision                                  int64
	EditHistory                               []ProductRevision
	CreatedAt, UpdatedAt                      time.Time
}

type CartItem struct {
	ProductID, VariantID string
	Quantity             int64
}

type Address struct {
	Recipient, Line1, City, Region, PostalCode, Country string
}

type OrderLine struct {
	ProductID, VariantID, Title, VariantName string
	Quantity, UnitPriceYNXT                  int64
}

type Shipment struct {
	Carrier, TrackingNumber, Status string
	UpdatedAt                       time.Time
}

type Resolution struct {
	Kind, Status, Reason, Explanation string
	RequestedAt, UpdatedAt            time.Time
}

type Review struct {
	Rating    int
	Body      string
	CreatedAt time.Time
}

type TrustCaseEvidence struct {
	CaseID, Status, EvidenceURL, AppealURL, Source string
	SubmittedAt                                    time.Time
}

type SettlementEvidence struct {
	InvoiceID, IntentID, Merchant, PayoutAddress, TransactionHash, Status, Payer, Currency, AuditHash string
	AmountYNXT                                                                                        int64
	BlockHeight                                                                                       uint64
	ConfirmedAt                                                                                       time.Time
}

type RefundEvidence struct {
	ID, Signer, Merchant, IntentID, Currency, Reason, Status, IdempotencyKey, RequestHash, TransactionHash, AuditHash string
	AmountYNXT                                                                                                        int64
	BlockHeight                                                                                                       uint64
	RecordedAt                                                                                                        time.Time
}

type CartConsumption struct{ PreviousRevision, Revision string }

type Order struct {
	CartConsumption                                                                             *CartConsumption `json:",omitempty"`
	ID, Buyer, StoreID, Status, Currency, InvoiceID, PayIntentID, PayMerchant, PayPayoutAddress string
	Lines                                                                                       []OrderLine
	Address                                                                                     Address
	SubtotalYNXT, ShippingYNXT, TaxYNXT, TotalYNXT                                              int64
	TaxStatus, LogisticsStatus, RefundStatus, TrustStatus                                       string
	ReservationExpiresAt                                                                        time.Time
	Settlement                                                                                  *SettlementEvidence
	Refund                                                                                      *RefundEvidence
	Shipment                                                                                    *Shipment
	Resolution                                                                                  *Resolution
	Review                                                                                      *Review
	TrustCase                                                                                   *TrustCaseEvidence
	Timeline                                                                                    []OrderEvent
	CreatedAt, UpdatedAt                                                                        time.Time
}

type OrderEvent struct {
	ID, Actor, Role, Action, Status, Detail string
	At                                      time.Time
}

type AuditEvent struct {
	ID, Actor, Role, Action, ObjectType, ObjectID, Outcome, Detail string
	At                                                             time.Time
}

type IdempotencyRecord struct {
	Actor, Route, Key, RequestHash, ObjectID string
	CreatedAt                                time.Time
}

type AIJob struct {
	ID, Actor, Workflow, Status, ProviderStatus, ContextSummary string
	ContextClasses, AllowedActions                              []string
	EstimateUnits                                               int64
	PermissionGranted                                           bool
	Result, Failure                                             string
	Applied, Rejected, Cancelled                                bool
	CreatedAt, UpdatedAt                                        time.Time
	RunAttemptID                                                string
}

type SellerRoleRevocation struct {
	ID, StoreID, Account, PreviousRole, Reason    string
	SessionStatus, SessionRevocationID, LastError string
	SessionCount                                  int
	RequestedAt, UpdatedAt                        time.Time
}

type SellerInvitation struct {
	ID, StoreID, Account, Role, CreatedBy, Status string
	Reason                                        string
	CreatedAt, ExpiresAt, UpdatedAt               time.Time
	AcceptedAt, CancelledAt                       time.Time
}

type SellerIntegrationEvent struct {
	ID, EventName, Source, StoreID, Account, Actor  string
	RevocationID, PreviousRole, SessionStatus       string
	SessionRevocationID, InvitationID, Role, Status string
	SchemaVersion, SessionCount                     int
	ExpiresAt, OccurredAt                           time.Time
}

type ProviderConfig struct {
	StoreID, Kind, Mode, Endpoint, AccessRef, Health, LastError string
	Capabilities                                                []string
	Revision, TestGeneration                                    int64
	CreatedAt, UpdatedAt, LastTestAt, LastHealthyAt             time.Time
	LastRotationAt                                              time.Time
}

type ProviderView struct {
	StoreID, Kind, Mode, Endpoint, Health, LastError string
	Capabilities                                     []string
	HasAccessReference                               bool
	Revision, TestGeneration                         int64
	CreatedAt, UpdatedAt, LastTestAt, LastHealthyAt  time.Time
	LastRotationAt                                   time.Time
}

type Snapshot struct {
	Version                 int
	Stores                  map[string]StoreProfile
	Products                map[string]Product
	Orders                  map[string]Order
	Idempotency             map[string]IdempotencyRecord
	RetiredIdempotency      map[string]struct{}
	BusinessNonces          map[string]struct{}
	BusinessBrowserBindings map[string]string
	BusinessActorNamespaces map[string]string
	BusinessEffects         map[string]BusinessEffect
	RetiredBusinessEffects  map[string]struct{}
	BuyerDeletions          map[string]BuyerDeletionRecord
	PrivacyDeletionBoundary string
	Audits                  []AuditEvent
	AIJobs                  map[string]AIJob
	BuyerProfiles           map[string]BuyerProfile
	Carts                   map[string]Cart
	SellerRoles             map[string]map[string]string
	SellerRevocations       map[string]SellerRoleRevocation
	SellerInvitations       map[string]SellerInvitation
	SellerEvents            []SellerIntegrationEvent
	ProviderConfigs         map[string]ProviderConfig
	RequestWindow           map[string][]time.Time
}

// Detach response collections from the store lock so HTTP serialization and
// caller edits cannot race with inventory/reservation changes.
func cloneProduct(product Product) Product {
	product.Media = append([]MediaAsset(nil), product.Media...)
	product.Variants = append([]Variant(nil), product.Variants...)
	product.EditHistory = append([]ProductRevision(nil), product.EditHistory...)
	for i := range product.EditHistory {
		product.EditHistory[i].Media = append([]MediaAsset(nil), product.EditHistory[i].Media...)
		product.EditHistory[i].Variants = append([]Variant(nil), product.EditHistory[i].Variants...)
	}
	return product
}

// Orders contain mutable evidence pointers as well as line and timeline slices.
// Keep stored records and response snapshots independent after releasing the lock.
func cloneOrder(order Order) Order {
	if order.CartConsumption != nil {
		v := *order.CartConsumption
		order.CartConsumption = &v
	}
	order.Lines = append([]OrderLine(nil), order.Lines...)
	order.Timeline = append([]OrderEvent(nil), order.Timeline...)
	if order.Settlement != nil {
		evidence := *order.Settlement
		order.Settlement = &evidence
	}
	if order.Refund != nil {
		evidence := *order.Refund
		order.Refund = &evidence
	}
	if order.Shipment != nil {
		shipment := *order.Shipment
		order.Shipment = &shipment
	}
	if order.Resolution != nil {
		resolution := *order.Resolution
		order.Resolution = &resolution
	}
	if order.Review != nil {
		review := *order.Review
		order.Review = &review
	}
	if order.TrustCase != nil {
		evidence := *order.TrustCase
		order.TrustCase = &evidence
	}
	return order
}
