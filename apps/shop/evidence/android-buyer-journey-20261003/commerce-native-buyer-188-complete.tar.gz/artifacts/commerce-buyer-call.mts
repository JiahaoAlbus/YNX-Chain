import {createNativeProductSessionClient,ProductSessionGatewayFetchAdapter} from './wallet-auth-native-consumer.mjs';
import type {NativeProductRuntime,NativeProductSessionAdapter} from './types/product-session-native.js';
import registry from './product-session-registry.json' with {type:'json'};

// Existing approved private Buyer capability; never use this as identity consent.
export const SHOP_BUYER_SCOPES=Object.freeze(['account:read','shop:orders:write','shop:profile:write']);
export const SHOP_GATEWAY_BASE='https://wallet-auth.ynxweb4.com';
export async function createShopBuyerForCurrentContext(runtime:NativeProductRuntime,ports:Readonly<{fetch:typeof fetch;walletInstalled:()=>Promise<boolean>;schemeRegistered:()=>Promise<boolean>;clock:()=>Date}>):Promise<NativeProductSessionAdapter>{
  // Both constructors come from the same original188 immutable artifact.
  const gateway=new ProductSessionGatewayFetchAdapter({endpoint:SHOP_GATEWAY_BASE,fetch:ports.fetch,walletInstalled:ports.walletInstalled,schemeRegistered:ports.schemeRegistered,timeoutMs:5000});
  return createNativeProductSessionClient({registry,productId:'shop',platform:'android',scopes:SHOP_BUYER_SCOPES,purpose:'YNX Shop Buyer private account, profile and orders',gateway,runtime,clock:ports.clock});
}
// Caller invokes client.connect(), then routes ONLY the actual OS callback to
// client.handleReturn(url). opened=true is not approval. If runtime account or
// generation changes, close the old client and create a fresh one; do not move
// pending/return/session records into its new constructor-generated namespace.
