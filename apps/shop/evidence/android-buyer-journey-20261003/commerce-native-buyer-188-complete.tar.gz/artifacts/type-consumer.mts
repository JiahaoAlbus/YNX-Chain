import {createNativeProductSessionClient,ProductSessionGatewayFetchAdapter} from "./wallet-auth-native-consumer.mjs";
type NativeProductSessionConfig=Parameters<typeof createNativeProductSessionClient>[0];
declare const config: NativeProductSessionConfig;
const client=await createNativeProductSessionClient(config);
const launch=await client.connect();
const neverApproval:false=launch.approved;
const gateway=new ProductSessionGatewayFetchAdapter({endpoint:"https://wallet-auth.ynxweb4.com",fetch:async()=>({}),walletInstalled:()=>true,schemeRegistered:()=>true,timeoutMs:5000});
void gateway;void neverApproval;await client.restore();await client.disconnect();
