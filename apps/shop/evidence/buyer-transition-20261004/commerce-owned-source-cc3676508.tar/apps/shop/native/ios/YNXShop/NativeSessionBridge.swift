import Foundation
import CryptoKit
import WebKit
#if canImport(AppKit)
import AppKit
#endif

// A private, unattached view loads only pinned product assets. It cannot become
// a browser for remote content. Synchronous ports remain on the owner actor;
// only Gateway HTTP awaits run asynchronously through a separate reply channel.
@MainActor final class AppleNativeEngine:NSObject,WKURLSchemeHandler,WKUIDelegate,WKNavigationDelegate,WKScriptMessageHandler,WKScriptMessageHandlerWithReply {
    static let base="ynx-commerce-native://engine/native-session/",index=base+"index.html"
    static let sdkSHA="a7d0f2a8bac2780f3b4db39a904245947cf5ed7a20ea62933b18e7e5369c8f82"
    private let assets:URL,port:(String,[String:Any])throws->Any
    private let gateway:([String:Any])async throws->[String:Any]
    private let completion:(String,[String:Any])->Void
    private var view:WKWebView!
    private var stopped=false
    init(assets:URL,port:@escaping (String,[String:Any])throws->Any,gateway:@escaping ([String:Any])async throws->[String:Any],completion:@escaping (String,[String:Any])->Void)throws {
        self.assets=assets;self.port=port;self.gateway=gateway;self.completion=completion;super.init()
        let sdk=try Data(contentsOf:assets.appendingPathComponent("wallet-auth-native-consumer.mjs"));guard SHA256.hash(data:sdk).map({String(format:"%02x",$0)}).joined()==Self.sdkSHA else{throw ShopError.security}
        let configuration=WKWebViewConfiguration();configuration.websiteDataStore = .nonPersistent();configuration.preferences.javaScriptCanOpenWindowsAutomatically=false;configuration.setURLSchemeHandler(self,forURLScheme:"ynx-commerce-native");configuration.userContentController.add(self,name:"completion");configuration.userContentController.addScriptMessageHandler(self,contentWorld:.page,name:"gateway")
        view=WKWebView(frame:.zero,configuration:configuration);view.uiDelegate=self;view.navigationDelegate=self;view.load(URLRequest(url:URL(string:Self.index)!))
    }
    func dispatch(_ id:String,_ method:String,_ args:[String:Any])throws {guard !stopped else{throw ShopError.contextChanged};let script="NativeClient.dispatch("+NativeWire.quote(id)+","+NativeWire.quote(method)+","+(try NativeWire.canonical(args))+");void 0";view.evaluateJavaScript(script){[weak self] _,error in if error != nil{self?.completion(id,["ok":false,"code":"NATIVE_ENGINE_DISPATCH_FAILED"])}}}
    func close(){guard !stopped else{return};stopped=true;view.stopLoading();view.configuration.userContentController.removeScriptMessageHandler(forName:"completion");view.configuration.userContentController.removeScriptMessageHandler(forName:"gateway",contentWorld:.page);view.uiDelegate=nil;view.navigationDelegate=nil;view=nil}
    private func trusted(_ frame:WKFrameInfo)->Bool {!stopped && frame.isMainFrame && frame.request.url?.absoluteString==Self.index}
    func webView(_ webView:WKWebView,start urlSchemeTask:WKURLSchemeTask){do{guard !stopped,urlSchemeTask.request.httpMethod=="GET",let url=urlSchemeTask.request.url,let name=url.pathComponents.last,["index.html","client.mjs","wallet-auth-native-consumer.mjs"].contains(name),url.absoluteString==Self.base+name else{throw ShopError.security};let data=try Data(contentsOf:assets.appendingPathComponent(name));guard data.count<=2_097_152 else{throw ShopError.security};let response=URLResponse(url:url,mimeType:name.hasSuffix("html") ? "text/html":"text/javascript",expectedContentLength:data.count,textEncodingName:"utf-8");urlSchemeTask.didReceive(response);urlSchemeTask.didReceive(data);urlSchemeTask.didFinish()}catch{urlSchemeTask.didFailWithError(error)}}
    func webView(_ webView:WKWebView,stop urlSchemeTask:WKURLSchemeTask){}
    func webView(_ webView:WKWebView,decidePolicyFor navigationAction:WKNavigationAction,decisionHandler:@escaping (WKNavigationActionPolicy)->Void){decisionHandler(!stopped && navigationAction.request.url?.absoluteString==Self.index ? .allow:.cancel)}
    func webView(_ webView:WKWebView,runJavaScriptTextInputPanelWithPrompt prompt:String,defaultText:String?,initiatedByFrame frame:WKFrameInfo,completionHandler:@escaping (String?)->Void){do{guard trusted(frame),prompt.hasPrefix("YNX_NATIVE_PORT:"),let raw=defaultText,raw.utf8.count<=2_097_152 else{throw ShopError.security};let value=try port(String(prompt.dropFirst("YNX_NATIVE_PORT:".count)),NativeWire.object(raw));completionHandler(try NativeWire.canonical(["ok":true,"value":value]))}catch{completionHandler("{\"ok\":false,\"code\":\"NATIVE_PORT_REJECTED\",\"message\":\"Original Native context unavailable\"}")}}
    func userContentController(_ userContentController:WKUserContentController,didReceive message:WKScriptMessage){guard trusted(message.frameInfo),message.webView===view,let body=message.body as? [String:Any],body.count==2,let id=body["id"] as? String,let raw=body["raw"] as? String,raw.utf8.count<=131072,let response=try? NativeWire.object(raw) else{return};completion(id,response)}
    func userContentController(_ userContentController:WKUserContentController,didReceive message:WKScriptMessage,replyHandler:@escaping (Any?,String?)->Void){guard trusted(message.frameInfo),message.webView===view,let args=message.body as? [String:Any] else{replyHandler(nil,"Protected Gateway port unavailable");return};Task{do{let result=try await gateway(args);guard !stopped else{throw ShopError.contextChanged};replyHandler(result,nil)}catch{replyHandler(nil,"Original Gateway operation unavailable")}}}
}

@MainActor final class AppleNativeSessionBridge:AppleNativeAuthority {
    static let gatewayURL="https://wallet-auth.ynxweb4.com"
    private let runtime:AppleNativeProtectedRuntime,registry:[String:Any]
    private let http:URLSession={let configuration=URLSessionConfiguration.ephemeral;configuration.httpShouldSetCookies=false;configuration.httpCookieStorage=nil;return URLSession(configuration:configuration,delegate:ShopRedirectPolicy(),delegateQueue:nil)}()
    private var engine:AppleNativeEngine!
    private var ready=false,bootFailure:Error?,closed=false,denied=true,revision=0
    private var active:ShopSession?
    private struct Waiter {let revision:Int;let continuation:CheckedContinuation<[String:Any],Error>}
    private var waits:[String:Waiter]=[:]
    var changed:(()->Void)?
    init(bundle:Bundle = .main)throws {guard let assets=bundle.url(forResource:"native-session",withExtension:nil),let registry=try JSONSerialization.jsonObject(with:Data(contentsOf:assets.appendingPathComponent("registry.json"))) as? [String:Any] else{throw ShopError.security};let sdk=try Data(contentsOf:assets.appendingPathComponent("wallet-auth-native-consumer.mjs"));guard SHA256.hash(data:sdk).map({String(format:"%02x",$0)}).joined()==AppleNativeEngine.sdkSHA else{throw ShopError.security};runtime=try AppleNativeProtectedRuntime(bundle:bundle);self.registry=registry;engine=try AppleNativeEngine(assets:assets,port:{[weak self] method,args in guard let self else{throw ShopError.contextChanged};return try self.port(method,args)},gateway:{[weak self] args in guard let self else{throw ShopError.contextChanged};return try await self.fetch(args)},completion:{[weak self] id,response in self?.complete(id,response)});Task{[weak self] in try? await Task.sleep(nanoseconds:15_000_000_000);guard let self,!ready,!closed else{return};bootFailure=ShopError.unavailable}}
    var current:ShopSession? {guard !closed,!denied,let active,let context=try? runtime.readContext(),let generation=context["generation"] as? Int,active.nativeGeneration==generation,ShopSession.parse(try? JSONEncoder().encode(active)) != nil else{return nil};return active}
    func restore()async throws {denied=false;_ = try await invoke("restore")}
    func connect()async throws {active=nil;denied=false;revision+=1;changed?();let value=try await invoke("connect");guard value["opened"] as? Bool==true else{throw ShopError.unavailable}}
    func handleReturn(_ url:URL)async throws {guard url.absoluteString.utf8.count<=16384 else{throw ShopError.security};_ = try await invoke("handleReturn",["url":url.absoluteString]);guard current != nil else{throw ShopError.signedOut}}
    func disconnect()throws {active=nil;denied=true;revision+=1;changed?();try runtime.state.requestCurrentRevocation();Task{_ = try? await invoke("disconnect")}}
    func openInvoice(_ url:URL,expected:ShopSession)async throws {guard current==expected,!closed,!denied else{throw ShopError.contextChanged};let context=try runtime.readContext();try runtime.state.permitOpen(context);guard current==expected else{throw ShopError.contextChanged};guard try runtime.openInvoice(url,expected:context) else{throw ShopError.unavailable};guard current==expected else{throw ShopError.contextChanged}}
    func proof(method:String,path:String,body:String,expected:ShopSession)async throws->[String:Any] {guard expected==current else{throw ShopError.contextChanged};let value=try await invoke("business",["method":method,"path":path,"body":body,"requiredScopes":try AppleNativeBusinessPolicy.scopes(method,path)]);guard current==expected,value["body"] as? String==body,let identity=value["identityHeader"] as? String,let action=value["actionHeader"] as? String,NativeWire.matches(identity,"^[A-Za-z0-9_-]{32,32768}$"),NativeWire.matches(action,"^[A-Za-z0-9_-]{32,32768}$") else{throw ShopError.security};return value}
    func close(){closed=true;denied=true;active=nil;revision+=1;for waiter in waits.values{waiter.continuation.resume(throwing:ShopError.contextChanged)};waits.removeAll();engine?.close();http.invalidateAndCancel()}
    private func invoke(_ method:String,_ args:[String:Any]=[:])async throws->[String:Any] {let epoch=revision;let deadline=Date().addingTimeInterval(15);while !ready{guard !closed,bootFailure==nil,Date()<deadline else{throw bootFailure ?? ShopError.unavailable};try await Task.sleep(nanoseconds:10_000_000)};guard !closed,epoch==revision else{throw ShopError.contextChanged};let id=UUID().uuidString;return try await withCheckedThrowingContinuation{continuation in waits[id]=Waiter(revision:epoch,continuation:continuation);do{try engine.dispatch(id,method,args)}catch{waits.removeValue(forKey:id)?.continuation.resume(throwing:error)};Task{[weak self] in try? await Task.sleep(nanoseconds:35_000_000_000);self?.waits.removeValue(forKey:id)?.continuation.resume(throwing:ShopError.unavailable)}}}
    private func complete(_ id:String,_ response:[String:Any]) {if id=="ready"{if response["ok"] as? Bool==true{ready=true}else{bootFailure=ShopError.security};return};guard let waiter=waits.removeValue(forKey:id) else{return};guard waiter.revision==revision,!closed else{waiter.continuation.resume(throwing:ShopError.contextChanged);return};do{guard response["ok"] as? Bool==true else{throw ShopError.security};if let state=response["state"] as? [String:Any]{if !denied,state["status"] as? String=="connected",let session=state["session"] as? [String:Any]{active=try metadata(session)}else{active=nil};changed?()};waiter.continuation.resume(returning:response["value"] as? [String:Any] ?? [:])}catch{active=nil;changed?();waiter.continuation.resume(throwing:error)}}
    private func metadata(_ session:[String:Any])throws->ShopSession {let context=try runtime.readContext();try runtime.state.checkSubject(session,context);guard session["version"] as? String=="2",session["chainId"] as? String=="ynx_6423-1",session["platform"] as? String=="macos",session["deviceAlgorithm"] as? String=="p256-sha256",session["scopes"] as? [String]==AppleNativeProductState.scopes,let account=session["account"] as? String,let binding=session["sessionBinding"] as? String,NativeWire.matches(binding,"^[a-f0-9]{64}$"),let expiry=session["expiresAt"] as? String else{throw ShopError.security};let value=ShopSession(account:account,token:binding,expiresAt:expiry,nativeGeneration:context["generation"] as? Int);guard ShopSession.parse(try JSONEncoder().encode(value)) != nil else{throw ShopError.signedOut};return value}
    private func port(_ method:String,_ args:[String:Any])throws->Any {guard !closed else{throw ShopError.contextChanged};let state=runtime.state
        if method=="config"{return ["gateway":Self.gatewayURL,"registry":registry,"purpose":"Explicit YNX Shop buyer access"]}
        if method=="readContext"{return try runtime.readContext()}
        if method=="randomBytes"{guard let length=args["length"] as? Int else{throw ShopError.security};return NativeWire.base64(try runtime.randomBytes(length))}
        if method=="walletDetected"{
#if canImport(AppKit)
            return NSWorkspace.shared.urlForApplication(toOpen:URL(string:"ynxwallet://authorize")!) != nil
#else
            return false
#endif
        }
        guard let expected=args["expected"] as? [String:Any] else{throw ShopError.security}
        if method=="sign",let input=args["input"] as? [String:Any]{return try runtime.sign(input,expected:expected,revokeOnly:denied)}
        if method=="openWallet",let input=args["input"] as? [String:Any]{guard !denied else{throw ShopError.contextChanged};return try runtime.openWallet(input,expected:expected)}
        guard let namespace=args["namespace"] as? String else{throw ShopError.security}
        if method=="requestRevocation"{denied=true;active=nil;try state.requestRevocation(namespace,expected);changed?();return NSNull()}
        if method=="revocationRequested"{return try state.revocationRequested(namespace,expected)}
        guard let key=args["key"] as? String else{throw ShopError.security}
        switch method {case "get":return try state.get(namespace,key,expected) as Any? ?? NSNull();case "remove":try state.remove(namespace,key,expected);case "set":guard let value=args["value"] as? String else{throw ShopError.security};try state.set(namespace,key,value,expected);case "saveRevocationIntent":guard let raw=args["raw"] as? String else{throw ShopError.security};return try state.saveRevocationIntent(namespace,key,raw,expected);case "finishRevocationIntent":guard let raw=args["raw"] as? String else{throw ShopError.security};try state.finishRevocationIntent(namespace,key,raw,expected);default:throw ShopError.security};return NSNull()
    }
    private func fetch(_ args:[String:Any])async throws->[String:Any] {guard !closed,let raw=args["url"] as? String,let url=URL(string:raw),raw==Self.gatewayURL+url.path,url.query==nil,url.fragment==nil,let method=args["method"] as? String,(method=="GET" && url.path=="/v2/product-sessions/time") || (method=="POST" && ["/v2/product-sessions/challenge","/v2/product-sessions/complete","/v2/product-sessions/introspect","/v2/product-sessions/revoke"].contains(url.path)),let headers=args["headers"] as? [String:String] else{throw ShopError.security};let body=args["body"] as? String ?? "";guard body.utf8.count<=1_048_576,method != "GET" || body.isEmpty else{throw ShopError.security};var request=URLRequest(url:url);request.httpMethod=method;request.timeoutInterval=15;for(key,value) in headers{guard ["accept","content-type","x-request-id","x-ynx-product-session-proof-v2"].contains(key.lowercased()) else{throw ShopError.security};request.setValue(value,forHTTPHeaderField:key)};if method=="POST"{request.httpBody=Data(body.utf8)};let(bytes,response)=try await http.bytes(for:request);guard let response=response as? HTTPURLResponse else{throw ShopError.invalidResponse};var data=Data();for try await byte in bytes{guard data.count<1_048_576 else{throw ShopError.security};data.append(byte)};guard let text=String(data:data,encoding:.utf8) else{throw ShopError.security};var returned:[String:String]=[:];for name in ["content-type","x-request-id","cache-control","content-length"]{if let value=response.value(forHTTPHeaderField:name){returned[name]=value}};return ["status":response.statusCode,"headers":returned,"body":text]}
}

// Fixed owner policy; caller-selected scope lists never enlarge Buyer authority.
@MainActor enum AppleNativeBusinessPolicy {
    static func scopes(_ method:String,_ path:String)throws->[String] {
        guard ["GET","POST","PUT","DELETE"].contains(method),NativeWire.matches(path,"^/api/[A-Za-z0-9._:/-]{1,251}$"),!path.contains("//"),!path.hasSuffix("/"),!path.contains("/../"),!path.contains("/./") else{throw ShopError.security}
        let route=String(path.dropFirst(4)),orders=["account:read","shop:orders:write"]
        if (route=="/profile" && ["GET","PUT"].contains(method)) || (route=="/privacy/export" && method=="GET") || (route=="/privacy/delete" && method=="POST"){return ["account:read","shop:profile:write"]}
        if (route=="/orders" && method=="GET") || (NativeWire.matches(route,"^/orders/[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$") && method=="GET") || (NativeWire.matches(route,"^/orders/[A-Za-z0-9][A-Za-z0-9._:-]{0,127}/(transition|transition-intent-lookup)$") && method=="POST"){return AppleNativeProductState.scopes}
        if (route=="/cart" && ["GET","PUT"].contains(method)) || (route=="/orders" && method=="POST") || (route=="/orders/intent-lookup" && method=="POST") || (NativeWire.matches(route,"^/orders/[A-Za-z0-9][A-Za-z0-9._:-]{0,127}/pay-handoff$") && ["GET","POST"].contains(method)) || (NativeWire.matches(route,"^/orders/[A-Za-z0-9][A-Za-z0-9._:-]{0,127}/confirm-payment$") && method=="POST"){return orders}
        if (route=="/ai/jobs" && ["GET","POST"].contains(method)) || (NativeWire.matches(route,"^/ai/jobs/[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$") && ["GET","DELETE"].contains(method)) || (NativeWire.matches(route,"^/ai/jobs/[A-Za-z0-9][A-Za-z0-9._:-]{0,127}/(run|decision)$") && method=="POST"){return AppleNativeProductState.scopes};throw ShopError.security
    }
}
