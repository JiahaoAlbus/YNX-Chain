package commerce

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"strings"
	"time"
)

const maxBody = 1 << 20

var BuildVersion = "0.3.0-testnet-preview"
var BuildCommit = "development"

type browserIdentityRoutes interface {
	Start(http.ResponseWriter, *http.Request)
	Callback(http.ResponseWriter, *http.Request)
	Account(http.ResponseWriter, *http.Request)
	Logout(http.ResponseWriter, *http.Request)
}

type ServerConfig struct {
	browserSSO                browserIdentityRoutes
	businessV2                businessVerifier
	Auth                      AuthGateway
	Pay                       HTTPPayVerifier
	Trust                     TrustGateway
	AI                        HTTPAIGateway
	ProviderTester            ProviderTester
	BuyerAssets, SellerAssets http.FileSystem
}
type Server struct {
	store   *Store
	cfg     ServerConfig
	mux     *http.ServeMux
	metrics *serverMetrics
}

func NewServer(store *Store, cfg ServerConfig) *Server {
	s := &Server{store: store, cfg: cfg, mux: http.NewServeMux(), metrics: newServerMetrics()}
	s.routes()
	return s
}
func (s *Server) Handler() http.Handler { return s.observe(s.security(s.mux)) }
func (s *Server) routes() {
	if s.cfg.browserSSO != nil {
		s.mux.HandleFunc("GET /sso/start", s.cfg.browserSSO.Start)
		s.mux.HandleFunc("GET /sso/callback", s.cfg.browserSSO.Callback)
		s.mux.HandleFunc("GET /api/sso/account", s.cfg.browserSSO.Account)
		s.mux.HandleFunc("POST /api/sso/logout", s.cfg.browserSSO.Logout)
	}

	s.handleFunc("GET /health", s.health)
	s.handleFunc("GET /version", s.version)
	s.handleFunc("GET /metrics", s.prometheusMetrics)
	s.handleFunc("GET /api/capabilities", s.capabilities)
	s.handleFunc("GET /api/auth/config", s.authConfig)
	s.handleFunc("POST /api/auth/gateway/challenges", s.gatewayChallenge)
	s.handleFunc("POST /api/auth/gateway/sessions", s.gatewaySession)
	s.handleFunc("GET /api/products", s.products)
	s.handleFunc("GET /api/products/{id}", s.product)
	s.handleFunc("GET /api/stores/{id}", s.publicStore)
	s.handleFunc("GET /api/profile", s.profile)
	s.handleFunc("PUT /api/profile", s.saveProfile)
	s.handleFunc("GET /api/cart", s.cart)
	s.handleFunc("PUT /api/cart", s.saveCart)
	s.handleFunc("GET /api/privacy/export", s.exportBuyerData)
	s.handleFunc("POST /api/privacy/delete", s.deleteBuyerData)
	s.handleFunc("GET /api/orders", s.orders)
	s.handleFunc("POST /api/orders", s.createOrder)
	s.handleFunc("POST /api/orders/intent-lookup", s.orderIntentLookup)
	s.handleFunc("GET /api/orders/{id}", s.order)
	s.handleFunc("POST /api/orders/{id}/pay-handoff", s.payHandoff)
	s.handleFunc("GET /api/orders/{id}/pay-handoff", s.invoiceReference)
	s.handleFunc("POST /api/orders/{id}/confirm-payment", s.confirmPayment)
	s.handleFunc("POST /api/orders/{id}/transition", s.orderTransition)
	s.handleFunc("POST /api/seller/stores", s.createStore)
	s.handleFunc("GET /api/seller/stores", s.sellerStores)
	s.handleFunc("PUT /api/seller/stores/{id}", s.updateStore)
	s.handleFunc("POST /api/seller/stores/{id}/activate", s.activateStore)
	s.handleFunc("POST /api/seller/stores/{id}/exports", s.exportSellerData)
	s.handleFunc("GET /api/seller/stores/{id}/providers", s.providerConfigs)
	s.handleFunc("PUT /api/seller/stores/{id}/providers/{kind}", s.configureProvider)
	s.handleFunc("POST /api/seller/stores/{id}/providers/{kind}/test", s.testProvider)
	s.handleFunc("POST /api/seller/stores/{id}/providers/{kind}/disable", s.disableProvider)
	s.handleFunc("POST /api/seller/stores/{id}/providers/{kind}/rotate", s.rotateProviderReference)
	s.handleFunc("GET /api/seller/stores/{id}/roles", s.roles)
	s.handleFunc("PUT /api/seller/stores/{id}/roles", s.setRole)
	s.handleFunc("POST /api/seller/stores/{id}/roles/{account}/revoke", s.revokeRole)
	s.handleFunc("GET /api/seller/invitations", s.mySellerInvitations)
	s.handleFunc("POST /api/seller/invitations/{invitation}/accept", s.acceptSellerInvitation)
	s.handleFunc("POST /api/seller/stores/{id}/invitations", s.createSellerInvitation)
	s.handleFunc("POST /api/seller/stores/{id}/invitations/{invitation}/cancel", s.cancelSellerInvitation)
	s.handleFunc("POST /api/seller/products", s.createProduct)
	s.handleFunc("GET /api/seller/products", s.sellerProducts)
	s.handleFunc("PUT /api/seller/products/{id}", s.updateProduct)
	s.handleFunc("POST /api/seller/products/{id}/publish", s.publishProduct)
	s.handleFunc("POST /api/seller/products/{id}/unpublish", s.unpublishProduct)
	s.handleFunc("POST /api/seller/inventory", s.inventory)
	s.handleFunc("GET /api/seller/audit", s.audit)
	s.handleFunc("GET /api/seller/settlements", s.settlements)
	s.handleFunc("POST /api/ai/jobs", s.createAI)
	s.handleFunc("POST /api/ai/jobs/{id}/run", s.runAI)
	s.handleFunc("POST /api/ai/jobs/{id}/decision", s.decideAI)
	s.handleFunc("POST /api/ai/jobs/{id}/cancel", s.cancelAI)
	s.handleFunc("GET /api/ai/jobs/{id}/stream", s.streamAI)
	s.handleFunc("DELETE /api/ai/jobs/{id}", s.deleteAI)
	if s.cfg.BuyerAssets != nil {
		s.mux.Handle("/shop/", http.StripPrefix("/shop/", http.FileServer(s.cfg.BuyerAssets)))
	}
	if s.cfg.SellerAssets != nil {
		s.mux.Handle("/seller/", http.StripPrefix("/seller/", http.FileServer(s.cfg.SellerAssets)))
	}
}
func (s *Server) security(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'; img-src 'self' data: https:")
		w.Header().Set("Cache-Control", "no-store")
		if r.Method != http.MethodGet && !s.store.Allow(clientSubject(r), "http.mutation", 240, time.Minute) {
			fail(w, http.StatusTooManyRequests, errors.New("mutation rate limit exceeded"))
			return
		}
		next.ServeHTTP(w, r)
	})
}
func (s *Server) health(w http.ResponseWriter, r *http.Request) {
	startedAt := s.metrics.snapshot().StartedAt
	dependencies := map[string]string{
		"walletGateway": availability(s.cfg.businessV2 != nil || (s.cfg.Auth != nil && s.cfg.Auth.Available())),
		"pay":           availability(s.cfg.Pay.BaseURL != "" && s.cfg.Pay.APIKey != "" && s.cfg.Pay.MerchantID != "" && s.cfg.Pay.PayoutAddress != ""),
		"trust":         availability(s.cfg.Trust != nil && s.cfg.Trust.Available()),
		"ai":            availability(s.cfg.AI.BaseURL != "" && s.cfg.AI.APIKey != ""),
	}
	write(w, 200, map[string]any{"ok": true, "status": "healthy", "service": "ynx-shopd", "version": BuildVersion, "commit": BuildCommit, "startedAt": startedAt, "chainId": ChainID, "chain": ChainName, "nativeSymbol": NativeSymbol, "persistence": s.store.path != "", "integrityProtected": len(s.store.integrityKey) > 0, "dependencies": dependencies})
}
func (s *Server) version(w http.ResponseWriter, r *http.Request) {
	write(w, 200, map[string]any{"service": "ynx-shopd", "version": BuildVersion, "commit": BuildCommit, "chain": ChainName, "nativeSymbol": NativeSymbol})
}
func (s *Server) capabilities(w http.ResponseWriter, r *http.Request) {
	wallet := "unavailable"
	protocol := "wallet-auth-v1+p256-sha256"
	if s.cfg.Auth != nil && s.cfg.Auth.Available() {
		wallet = "central_gateway"
	}
	if s.cfg.businessV2 != nil {
		wallet = "canonical_v2"
		protocol = "wallet-product-session-v2+p256-sha256"
	}
	authorizationRevocation := "unavailable"
	_, v2TrustAvailable := businessTrustGateway(s.cfg.Trust)
	if _, ok := s.cfg.Auth.(ProductAuthorizationRevoker); ok && s.cfg.businessV2 == nil && s.cfg.Auth != nil && s.cfg.Auth.Available() {
		authorizationRevocation = "candidate_configured"
	}
	write(w, 200, map[string]any{
		"walletAuth": wallet, "walletProtocol": protocol,
		"sellerStoreAuthorizationRevocation": authorizationRevocation,
		"paySettlement":                      availability(s.cfg.Pay.BaseURL != "" && s.cfg.Pay.APIKey != "" && s.cfg.Pay.MerchantID != "" && s.cfg.Pay.PayoutAddress != ""),
		"payInvoiceHandoff":                  availability(s.cfg.Pay.BaseURL != "" && s.cfg.Pay.APIKey != "" && s.cfg.Pay.MerchantID != "" && s.cfg.Pay.PayoutAddress != ""),
		"logistics":                          "unavailable",
		"tax":                                "unavailable",
		"aiProvider":                         availability(s.cfg.AI.BaseURL != "" && s.cfg.AI.APIKey != ""),
		"trustEvidence":                      availability((s.cfg.businessV2 == nil && s.cfg.Trust != nil && s.cfg.Trust.Available()) || (s.cfg.businessV2 != nil && v2TrustAvailable)),
		"privacyData":                        "export_and_delete",
		"providerRegistry":                   "available_local_authority",
		"providerKinds":                      ProviderKinds(),
		"providerHealthIsStoreScoped":        true,
		"protectedAIActions":                 []string{"publish_product", "change_price", "purchase", "refund", "change_seller_policy"},
	})
}
func availability(ok bool) string {
	if ok {
		return "available"
	}
	return "unavailable"
}
func decode(w http.ResponseWriter, r *http.Request, out any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maxBody)
	d := json.NewDecoder(r.Body)
	d.DisallowUnknownFields()
	if err := d.Decode(out); err != nil {
		fail(w, 400, err)
		return false
	}
	if err := d.Decode(&struct{}{}); err != io.EOF {
		fail(w, 400, errors.New("single JSON object required"))
		return false
	}
	return true
}
func write(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func fail(w http.ResponseWriter, status int, err error) {
	payload := map[string]string{"error": err.Error()}
	if errors.Is(err, ErrCartRevisionConflict) {
		payload["code"] = "CART_REVISION_CONFLICT"
	}
	write(w, status, payload)
}
func status(err error) int {
	switch {
	case errors.Is(err, ErrNotFound):
		return 404
	case errors.Is(err, ErrUnauthorized):
		return 403
	case errors.Is(err, ErrConflict), errors.Is(err, ErrInvalidState), errors.Is(err, ErrInventory):
		return 409
	case errors.Is(err, ErrUnavailable):
		return 503
	case errors.Is(err, ErrRateLimited):
		return http.StatusTooManyRequests
	default:
		return 400
	}
}
func (s *Server) auth(w http.ResponseWriter, r *http.Request, roles ...string) (Principal, bool) {
	if verified, ok := r.Context().Value(businessRequestContextKey{}).(*verifiedBusinessRequest); ok {
		if err := verified.current(r.Context()); err != nil {
			failBusiness(w, err)
			return Principal{}, false
		}
		for _, role := range roles {
			if verified.principal.Role == role {
				return verified.principal, true
			}
		}
		fail(w, http.StatusForbidden, ErrUnauthorized)
		return Principal{}, false
	}

	token := strings.TrimSpace(strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer "))
	if s.cfg.Auth == nil {
		fail(w, http.StatusServiceUnavailable, fmt.Errorf("%w: central Wallet Gateway is not configured", ErrUnavailable))
		return Principal{}, false
	}
	sess, err := s.cfg.Auth.Verify(r.Context(), token)
	if err != nil {
		code := status(err)
		if errors.Is(err, ErrUnauthorized) {
			code = http.StatusUnauthorized
		}
		fail(w, code, err)
		return Principal{}, false
	}
	expected, bindingOK := bindingFor(sess.ProductClientID)
	if !bindingOK || sess.Role != expected.Role || sess.BundleID != expected.BundleID || !exactScopes(sess.Scopes, expected.Scopes) {
		fail(w, http.StatusForbidden, fmt.Errorf("%w: product session scope or binding mismatch", ErrUnauthorized))
		return Principal{}, false
	}
	for _, role := range roles {
		if sess.Role == role {
			return sess, true
		}
	}
	fail(w, 403, ErrUnauthorized)
	return Principal{}, false
}
func (s *Server) rate(w http.ResponseWriter, r *http.Request, actor, action string) bool {
	subject := actor
	if subject == "" {
		subject = clientSubject(r)
	}
	if !s.store.Allow(subject, action, 60, time.Minute) {
		fail(w, 429, errors.New("rate limit exceeded"))
		return false
	}
	return true
}

// clientSubject keeps public clients in separate rate-limit buckets when the
// service is behind the local Caddy reverse proxy. Forwarded headers are never
// trusted from a non-loopback peer, preventing a public caller from choosing a
// different bucket by spoofing X-Forwarded-For.
func clientSubject(r *http.Request) string {
	host, _, err := net.SplitHostPort(strings.TrimSpace(r.RemoteAddr))
	if err != nil {
		host = strings.TrimSpace(r.RemoteAddr)
	}
	peer := net.ParseIP(host)
	if peer != nil && peer.IsLoopback() {
		for _, part := range strings.Split(r.Header.Get("X-Forwarded-For"), ",") {
			candidate := net.ParseIP(strings.TrimSpace(part))
			if candidate != nil && !candidate.IsUnspecified() {
				return candidate.String()
			}
		}
	}
	if peer != nil {
		return peer.String()
	}
	return host
}

func (s *Server) authConfig(w http.ResponseWriter, r *http.Request) {
	binding := ShopBinding()
	if r.URL.Query().Get("surface") == "seller" {
		binding = SellerBinding()
	}
	write(w, 200, map[string]any{"version": "1", "chainId": GatewayChainID, "requestingProduct": binding.RequestingProduct, "productClientId": binding.ProductClientID, "bundleId": binding.BundleID, "productDeviceAlgorithm": DeviceAlgorithm, "callback": binding.Callback, "scopes": binding.Scopes, "gateway": availability(s.cfg.Auth != nil && s.cfg.Auth.Available()), "sessionStorage": "platform_secure_storage_only"})
}
func (s *Server) gatewayChallenge(w http.ResponseWriter, r *http.Request) {
	if !s.rate(w, r, "", "auth.challenge") {
		return
	}
	if s.cfg.Auth == nil {
		fail(w, http.StatusServiceUnavailable, fmt.Errorf("%w: central Wallet Gateway is not configured", ErrUnavailable))
		return
	}
	body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, maxBody))
	if err != nil {
		fail(w, http.StatusBadRequest, err)
		return
	}
	v, err := s.cfg.Auth.Begin(r.Context(), json.RawMessage(body))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	_, _ = w.Write(v)
}
func (s *Server) gatewaySession(w http.ResponseWriter, r *http.Request) {
	if !s.rate(w, r, "", "auth.session") {
		return
	}
	if s.cfg.Auth == nil {
		fail(w, http.StatusServiceUnavailable, fmt.Errorf("%w: central Wallet Gateway is not configured", ErrUnavailable))
		return
	}
	body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, maxBody))
	if err != nil {
		fail(w, http.StatusBadRequest, err)
		return
	}
	v, err := s.cfg.Auth.Complete(r.Context(), json.RawMessage(body))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	_, _ = w.Write(v)
}
func (s *Server) products(w http.ResponseWriter, r *http.Request) {
	write(w, 200, map[string]any{"products": s.store.Products(r.URL.Query().Get("q"), r.URL.Query().Get("category"))})
}
func (s *Server) product(w http.ResponseWriter, r *http.Request) {
	v, err := s.store.Product(r.PathValue("id"))
	if err != nil || !v.Published {
		fail(w, 404, ErrNotFound)
		return
	}
	write(w, 200, v)
}
func (s *Server) publicStore(w http.ResponseWriter, r *http.Request) {
	v, err := s.store.PublicStore(r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) profile(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer", "seller")
	if !ok {
		return
	}
	write(w, 200, map[string]any{"account": sess.Account, "role": sess.Role, "sessionExpiresAt": sess.ExpiresAt, "chain": ChainName, "profile": s.store.Profile(sess.Account)})
}
func (s *Server) saveProfile(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer")
	if !ok {
		return
	}
	var in struct {
		DisplayName string
		Addresses   []Address
	}
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.SaveProfile(sess.Account, in.DisplayName, in.Addresses)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) cart(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer")
	if !ok {
		return
	}
	write(w, 200, s.store.Cart(sess.Account))
}
func (s *Server) saveCart(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer")
	if !ok {
		return
	}
	var in CartInput
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.SaveCartIntent(sess.Account, in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) exportBuyerData(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer")
	if !ok || !s.rate(w, r, sess.Account, "privacy.export") {
		return
	}
	write(w, http.StatusOK, s.store.ExportBuyerData(sess.Account))
}
func (s *Server) deleteBuyerData(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer")
	if !ok {
		return
	}
	var in struct {
		Confirmation      string          `json:"confirmation"`
		RetiredIntents    []RetiredIntent `json:"retiredIntents"`
		DeletionRequestID string          `json:"deletionRequestId"`
	}
	if !decode(w, r, &in) {
		return
	}
	if in.Confirmation != "DELETE_MY_SHOP_DATA" {
		fail(w, http.StatusBadRequest, errors.New("exact confirmation DELETE_MY_SHOP_DATA required"))
		return
	}
	if err := validateRetiredIntents(in.RetiredIntents); err != nil {
		fail(w, http.StatusBadRequest, err)
		return
	}
	if err := validateDeletionRequestID(in.DeletionRequestID); err != nil {
		fail(w, http.StatusBadRequest, err)
		return
	}
	if !s.rate(w, r, sess.Account, "privacy.delete") {
		return
	}
	receipt, err := s.store.DeleteBuyerDataRequest(sess.Account, in.DeletionRequestID, in.RetiredIntents)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, http.StatusOK, receipt)
}
func (s *Server) orders(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer", "seller")
	if !ok {
		return
	}
	write(w, 200, map[string]any{"orders": s.store.Orders(sess.Account, sess.Role)})
}
func (s *Server) order(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer", "seller")
	if !ok {
		return
	}
	v, err := s.store.Order(sess.Account, sess.Role, r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) orderIntentLookup(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer")
	if !ok {
		return
	}
	var in struct{ IdempotencyKey string }
	if !decode(w, r, &in) {
		return
	}
	order, err := s.store.OrderIntent(sess.Account, in.IdempotencyKey)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, order)
}
func (s *Server) createOrder(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer")
	if !ok || !s.rate(w, r, sess.Account, "order.create") {
		return
	}
	var in OrderInput
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.CreateOrder(sess.Account, in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 201, v)
}
func (s *Server) payHandoff(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer")
	if !ok {
		return
	}
	var in struct{ IdempotencyKey string }
	if !decode(w, r, &in) {
		return
	}
	o, err := s.store.Order(sess.Account, "buyer", r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	if original, recoveryErr := boundInvoiceHandoff(o); recoveryErr == nil {
		write(w, 201, invoiceEffectResponse(o, original))
		return
	} else if !errors.Is(recoveryErr, errInvoiceNotBound) {
		fail(w, status(recoveryErr), recoveryErr)
		return
	}
	handoff, err := s.cfg.Pay.CreateInvoice(r.Context(), o, in.IdempotencyKey)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	o, err = s.store.BindInvoice(sess.Account, o.ID, handoff)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 201, map[string]any{"order": o, "invoiceId": handoff.InvoiceID, "intentId": handoff.IntentID, "deepLink": handoff.DeepLink, "merchant": handoff.Merchant, "payoutAddress": handoff.PayoutAddress, "status": "payment_pending"})
}
func (s *Server) confirmPayment(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer")
	if !ok {
		return
	}
	o, err := s.store.Order(sess.Account, "buyer", r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	if o.InvoiceID == "" {
		fail(w, 409, ErrInvalidState)
		return
	}
	e, err := s.cfg.Pay.Settlement(r.Context(), o.InvoiceID)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	v, err := s.store.ConfirmSettlement(o.ID, e)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) orderTransition(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer", "seller")
	if !ok {
		return
	}
	var in orderTransitionInput
	if !decode(w, r, &in) {
		return
	}
	ship, res, review := in.parts()
	v, err := s.store.transition(sess.Account, sess.Role, r.PathValue("id"), in.Action, ship, res, review, in.IdempotencyKey)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	if in.Action == "disputed" && sess.Role == "buyer" {
		if s.cfg.Trust == nil || !s.cfg.Trust.Available() {
			v, err = s.store.BindTrustCase(sess.Account, v.ID, nil, true)
		} else if evidence, trustErr := s.cfg.Trust.SubmitDispute(r.Context(), v, in.IdempotencyKey); trustErr != nil {
			v, err = s.store.BindTrustCase(sess.Account, v.ID, nil, true)
		} else {
			v, err = s.store.BindTrustCase(sess.Account, v.ID, &evidence, false)
		}
		if err != nil {
			fail(w, status(err), err)
			return
		}
	}
	if in.Action == "refund_approved" && sess.Role == "seller" {
		evidence, refundErr := s.cfg.Pay.CreateRefund(r.Context(), v, in.IdempotencyKey)
		if refundErr != nil {
			fail(w, status(refundErr), refundErr)
			return
		}
		v, err = s.store.BindRefundEvidence(sess.Account, v.ID, evidence)
		if err != nil {
			fail(w, status(err), err)
			return
		}
	}
	write(w, 200, v)
}

func (s *Server) createStore(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in CreateStoreInput
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.CreateStore(sess.Account, in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 201, v)
}
func (s *Server) sellerStores(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	write(w, 200, map[string]any{"stores": s.store.SellerStores(sess.Account), "access": s.store.SellerAccess(sess.Account)})
}
func (s *Server) updateStore(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in StoreUpdate
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.UpdateStore(sess.Account, r.PathValue("id"), in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) exportSellerData(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in struct{ Purpose string }
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.ExportSellerData(sess.Account, r.PathValue("id"), in.Purpose)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, http.StatusCreated, map[string]any{"export": v})
}
func (s *Server) providerConfigs(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	providers, err := s.store.ProviderConfigs(sess.Account, r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, http.StatusOK, map[string]any{"providers": providers})
}
func (s *Server) configureProvider(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in ProviderConfigInput
	if !decode(w, r, &in) {
		return
	}
	provider, err := s.store.ConfigureProvider(sess.Account, r.PathValue("id"), r.PathValue("kind"), in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, http.StatusOK, map[string]any{"provider": provider})
}
func (s *Server) disableProvider(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in ProviderDisableInput
	if !decode(w, r, &in) {
		return
	}
	provider, err := s.store.DisableProvider(sess.Account, r.PathValue("id"), r.PathValue("kind"), in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, http.StatusOK, map[string]any{"provider": provider})
}
func (s *Server) rotateProviderReference(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in ProviderRotationInput
	if !decode(w, r, &in) {
		return
	}
	provider, err := s.store.RotateProviderReference(sess.Account, r.PathValue("id"), r.PathValue("kind"), in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, http.StatusOK, map[string]any{"provider": provider})
}
func (s *Server) testProvider(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in struct{}
	if !decode(w, r, &in) {
		return
	}
	request, err := s.store.BeginProviderTest(sess.Account, r.PathValue("id"), r.PathValue("kind"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	result := ProviderTestResult{Status: providerHealthUnavailable, Detail: "provider tester is not configured"}
	var testErr error
	if s.cfg.ProviderTester != nil {
		ctx, cancel := context.WithTimeout(r.Context(), 5*time.Second)
		result, testErr = s.cfg.ProviderTester.TestProvider(ctx, request)
		cancel()
	}
	provider, err := s.store.CompleteProviderTest(request, result, testErr)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, http.StatusOK, map[string]any{"provider": provider})
}
func (s *Server) roles(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	v, err := s.store.SellerRoles(sess.Account, r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	revocations, err := s.store.SellerRoleRevocations(sess.Account, r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	events, err := s.store.SellerIntegrationEvents(sess.Account, r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	invitations, err := s.store.SellerInvitations(sess.Account, r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, map[string]any{"roles": v, "revocations": revocations, "invitations": invitations, "events": events, "actorRole": v[sess.Account]})
}
func (s *Server) setRole(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in struct{ Account, Role string }
	if !decode(w, r, &in) {
		return
	}
	if err := s.store.SetSellerRole(sess.Account, r.PathValue("id"), in.Account, in.Role); err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, map[string]string{"status": "updated"})
}

func (s *Server) mySellerInvitations(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	write(w, http.StatusOK, map[string]any{"invitations": s.store.SellerInvitationsForAccount(sess.Account)})
}

func (s *Server) createSellerInvitation(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in struct {
		Account          string
		Role             string
		ExpiresInMinutes int
	}
	if !decode(w, r, &in) {
		return
	}
	if in.ExpiresInMinutes == 0 {
		in.ExpiresInMinutes = 24 * 60
	}
	if in.ExpiresInMinutes < int(minSellerInvitationTTL/time.Minute) || in.ExpiresInMinutes > int(maxSellerInvitationTTL/time.Minute) {
		fail(w, http.StatusBadRequest, errors.New("invitation expiry must be between 15 minutes and 7 days"))
		return
	}
	invitation, err := s.store.CreateSellerInvitation(sess.Account, r.PathValue("id"), in.Account, in.Role, time.Duration(in.ExpiresInMinutes)*time.Minute)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, http.StatusCreated, map[string]any{"status": "pending", "invitation": invitation})
}

func (s *Server) acceptSellerInvitation(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in struct{}
	if !decode(w, r, &in) {
		return
	}
	invitation, err := s.store.AcceptSellerInvitation(sess.Account, r.PathValue("invitation"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, http.StatusOK, map[string]any{"status": "accepted", "storeId": invitation.StoreID, "role": invitation.Role, "invitation": invitation})
}

func (s *Server) cancelSellerInvitation(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in struct{ Reason string }
	if !decode(w, r, &in) {
		return
	}
	invitation, err := s.store.CancelSellerInvitation(sess.Account, r.PathValue("id"), r.PathValue("invitation"), in.Reason)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, http.StatusOK, map[string]any{"status": "cancelled", "invitation": invitation})
}

func validProductAuthorizationRevocationReceipt(receipt ProductAuthorizationRevocationReceipt, revocation SellerRoleRevocation) bool {
	revocationID := strings.TrimSpace(receipt.RevocationID)
	return receipt.Revoked &&
		len(revocationID) >= 8 && len(revocationID) <= 128 &&
		receipt.Account == revocation.Account &&
		receipt.ProductClientID == SellerClientID &&
		receipt.BundleID == SellerBundleID &&
		receipt.ResourceType == "seller_store" &&
		receipt.ResourceID == revocation.StoreID &&
		receipt.SessionCount >= 0 &&
		!receipt.RevokedAt.IsZero() &&
		!receipt.RevokedAt.After(time.Now().UTC().Add(time.Minute))
}

func (s *Server) revokeRole(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in struct{ Reason string }
	if !decode(w, r, &in) {
		return
	}
	revocation, created, err := s.store.RevokeSellerRole(sess.Account, r.PathValue("id"), r.PathValue("account"), in.Reason)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	if revocation.SessionStatus == "confirmed" {
		write(w, http.StatusOK, map[string]any{"roleRevoked": true, "created": created, "sessionInvalidation": "confirmed", "revocation": revocation})
		return
	}
	revoker, supported := s.cfg.Auth.(ProductAuthorizationRevoker)
	if !supported || s.cfg.Auth == nil || !s.cfg.Auth.Available() {
		revocation, err = s.store.UpdateSellerRoleRevocation(sess.Account, revocation.ID, "unavailable", "", 0, "central Wallet store authorization revocation contract is unavailable")
		if err != nil {
			fail(w, http.StatusInternalServerError, err)
			return
		}
		write(w, http.StatusAccepted, map[string]any{"roleRevoked": true, "created": created, "sessionInvalidation": "unavailable", "revocation": revocation})
		return
	}
	receipt, revokeErr := revoker.RevokeProductAuthorization(r.Context(), ProductAuthorizationRevocationRequest{RequestID: revocation.ID, Account: revocation.Account, ProductClientID: SellerClientID, BundleID: SellerBundleID, ResourceType: "seller_store", ResourceID: revocation.StoreID, Reason: revocation.Reason})
	if revokeErr == nil && !validProductAuthorizationRevocationReceipt(receipt, revocation) {
		revokeErr = fmt.Errorf("%w: central Wallet authorization revocation receipt failed binding validation", ErrUnavailable)
	}
	if revokeErr == nil {
		revocation, err = s.store.UpdateSellerRoleRevocation(sess.Account, revocation.ID, "confirmed", receipt.RevocationID, receipt.SessionCount, "central Wallet store-scoped Seller authorization invalidated")
		if err != nil {
			fail(w, http.StatusInternalServerError, err)
			return
		}
		write(w, http.StatusOK, map[string]any{"roleRevoked": true, "created": created, "sessionInvalidation": "confirmed", "revocation": revocation})
		return
	}
	sessionStatus := "unavailable"
	detail := "central Wallet store authorization revocation contract is unavailable"
	if errors.Is(revokeErr, ErrUnauthorized) || errors.Is(revokeErr, ErrConflict) {
		sessionStatus = "rejected"
		detail = "central Wallet rejected the store-scoped Seller authorization revocation request"
	}
	revocation, err = s.store.UpdateSellerRoleRevocation(sess.Account, revocation.ID, sessionStatus, "", 0, detail)
	if err != nil {
		fail(w, http.StatusInternalServerError, err)
		return
	}
	write(w, http.StatusAccepted, map[string]any{"roleRevoked": true, "created": created, "sessionInvalidation": sessionStatus, "revocation": revocation})
}
func (s *Server) activateStore(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	v, err := s.store.ActivateStore(sess.Account, r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) createProduct(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in CreateProductInput
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.CreateProduct(sess.Account, in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 201, v)
}
func (s *Server) sellerProducts(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	v, err := s.store.SellerProducts(sess.Account, r.URL.Query().Get("storeId"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, map[string]any{"products": v})
}
func (s *Server) updateProduct(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in UpdateProductInput
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.UpdateProduct(sess.Account, r.PathValue("id"), in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) publishProduct(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	v, err := s.store.PublishProduct(sess.Account, r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) unpublishProduct(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	v, err := s.store.UnpublishProduct(sess.Account, r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) inventory(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	var in InventoryInput
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.SetInventory(sess.Account, in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) audit(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	events, err := s.store.SellerAudit(sess.Account)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, map[string]any{"events": events})
}
func (s *Server) settlements(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "seller")
	if !ok {
		return
	}
	settlements, err := s.store.Settlements(sess.Account)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, map[string]any{"settlements": settlements})
}
func (s *Server) createAI(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer", "seller")
	if !ok {
		return
	}
	var in AIInput
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.CreateAIJob(sess.Account, in)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 201, v)
}
func (s *Server) runAI(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer", "seller")
	if !ok {
		return
	}
	v, err := s.store.RunAIJob(r.Context(), sess.Account, r.PathValue("id"), s.cfg.AI)
	if err != nil {
		fail(w, status(err), fmt.Errorf("AI generation failed: %w", err))
		return
	}
	write(w, 200, v)
}
func (s *Server) decideAI(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer", "seller")
	if !ok {
		return
	}
	var in struct{ Decision string }
	if !decode(w, r, &in) {
		return
	}
	v, err := s.store.DecideAIJob(sess.Account, r.PathValue("id"), in.Decision)
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) cancelAI(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer", "seller")
	if !ok {
		return
	}
	v, err := s.store.CancelAIJob(sess.Account, r.PathValue("id"))
	if err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, v)
}
func (s *Server) streamAI(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer", "seller")
	if !ok {
		return
	}
	flusher, ok := w.(http.Flusher)
	if !ok {
		fail(w, 500, errors.New("streaming unavailable"))
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-store")
	for i := 0; i < 120; i++ {
		j, err := s.store.AIJob(sess.Account, r.PathValue("id"))
		if err != nil {
			fmt.Fprintf(w, "event: error\ndata: %q\n\n", err.Error())
			flusher.Flush()
			return
		}
		data, _ := json.Marshal(j)
		fmt.Fprintf(w, "event: status\ndata: %s\n\n", data)
		flusher.Flush()
		if j.Status != "permission_granted" && j.Status != "running" {
			return
		}
		select {
		case <-r.Context().Done():
			return
		case <-time.After(500 * time.Millisecond):
		}
	}
}
func (s *Server) deleteAI(w http.ResponseWriter, r *http.Request) {
	sess, ok := s.auth(w, r, "buyer", "seller")
	if !ok {
		return
	}
	if err := s.store.DeleteAIJob(sess.Account, r.PathValue("id")); err != nil {
		fail(w, status(err), err)
		return
	}
	write(w, 200, map[string]string{"status": "deleted"})
}
