export type ProductBinding = Readonly<{requestingProduct:string;bundleId:string;origins:readonly string[];callbacks:readonly string[];scopes:readonly string[];maxScopes?:number}>;
export type ProductDeviceAlgorithm = "p256-sha256";
export type AuthorizationRequest = Readonly<{version:"2";nonce:string;chainId:"ynx_6423-1";requestingProduct:string;productClientId:string;bundleId:string;productDeviceAlgorithm:ProductDeviceAlgorithm;productDeviceKey:string;origin:string;callback:string;scopes:readonly string[];purpose:string;issuedAt:string;expiresAt:string}>;
export type AuthorizationResponse = Readonly<{version:"2";requestDigest:string;nonce:string;chainId:"ynx_6423-1";requestingProduct:string;productClientId:string;bundleId:string;productDeviceAlgorithm:ProductDeviceAlgorithm;productDeviceKey:string;origin:string;callback:string;account:string;accountPublicKey:string;grantedScopes:readonly string[];purpose:string;issuedAt:string;expiresAt:string;walletSignature:string}>;
export type GatewayChallenge = Readonly<{version:"2";challenge:string;requestDigest:string;productClientId:string;bundleId:string;productDeviceAlgorithm:ProductDeviceAlgorithm;productDeviceKey:string;origin:string;account:string;scopes:readonly string[];issuedAt:string;expiresAt:string}>;
export type GatewayCompletion = Readonly<{challenge:GatewayChallenge;deviceSignature:string}>;
export type CentralRegistryEntryV1 = Readonly<{schemaVersion:1;productClientId:string;requestingProduct:string;bundleId:string;callback:string;scopes:readonly string[];maxScopes:number}>;
export type CentralRegistryEntry = Readonly<{schemaVersion:3;productClientId:string;requestingProduct:string;bundleId:string;callbacks:readonly string[];origins:readonly string[];scopes:readonly string[];maxScopes:number;productDeviceAlgorithms:readonly ProductDeviceAlgorithm[]}>;
export type CentralReviewState = "approved"|"pending-review"|"disabled"|"retired";
export type ClientLifecycleActive=Readonly<{status:"active"}>;
export type ClientLifecycleRetired=Readonly<{status:"retired";clientId:string;replacementURL:string;minimumClientVersion:string;lastSupportedVersion:string;retiredAt:string;disabledCallbacks:readonly string[];disabledAppLinks:readonly string[]}>;
export type ClientRetirementRecord=Readonly<Omit<ClientLifecycleRetired,"status">&{productId:string;requestingProduct:string;productClientId:string;bundleId:string}>;
export type CentralProductRegistration = Readonly<Omit<CentralRegistryEntry,"schemaVersion"|"origins"> & {schemaVersion:5;productId:string;displayName:string;reviewState:CentralReviewState;enabled:boolean;webOrigins:readonly string[];clientLifecycle:ClientLifecycleActive|ClientLifecycleRetired;sessionDurationSeconds:number;revocationPolicy:Readonly<{session:true;approval:true;device:true;accountAllDevices:true}>}>;
export type CentralRegistryDocument = Readonly<{registryVersion:2|3;chainId:"ynx_6423-1";products:readonly CentralProductRegistration[];retiredClients:readonly ClientRetirementRecord[]}>;
export type CentralWalletSession = Readonly<{verifierVersion:"wallet-auth-v2";sessionBinding:string;chainId:"ynx_6423-1";requestingProduct:string;productClientId:string;bundleId:string;origin:string;callback:string;productDeviceAlgorithm:ProductDeviceAlgorithm;productDeviceKey:string;deviceBinding:string;account:string;scopes:readonly string[];nonce:string;purpose:string;requestDigest:string;approvalDigest:string;issuedAt:string;expiresAt:string}>;
export type LegacyCentralWalletSession = Readonly<{verifierVersion:"wallet-auth-v1";sessionBinding:string;chainId:"ynx_6423-1";requestingProduct:string;productClientId:string;bundleId:string;callback:string;productDeviceAlgorithm:ProductDeviceAlgorithm;productDeviceKey:string;deviceBinding:string;account:string;scopes:readonly string[];nonce:string;purpose:string;requestDigest:string;approvalDigest:string;issuedAt:string;expiresAt:string}>;
export type CentralRevocationState = Readonly<{revokedSessionBindings:readonly string[];revokedApprovalDigests:readonly string[];revokedDeviceBindings:readonly string[];accountLogoutRecords:readonly Readonly<{account:string;before:string}>[]}>;
export type CentralWalletStoreSnapshot = Readonly<{schemaVersion:2;consumedNonces:readonly string[];consumedRequestDigests:readonly string[];consumedChallenges:readonly string[];sessions:readonly (CentralWalletSession|LegacyCentralWalletSession)[];revokedSessionBindings:readonly string[];revokedApprovalDigests:readonly string[];revokedDeviceBindings:readonly string[];accountLogoutRecords:readonly Readonly<{account:string;before:string}>[];retiredClients:readonly ClientRetirementRecord[];audit:readonly Readonly<{sequence:number;type:string;subject:string;at:string;previousHash:string|null;hash:string}>[]}>;
export type CentralWalletSessionInactiveReason="issued-in-future"|"expired"|"session-revoked"|"approval-revoked"|"device-revoked"|"account-logout"|"origin-binding-retired"|"client-retired";
export type CentralWalletSessionInventoryItem=Readonly<Pick<CentralWalletSession,"sessionBinding"|"requestingProduct"|"productClientId"|"bundleId"|"origin"|"callback"|"productDeviceAlgorithm"|"productDeviceKey"|"deviceBinding"|"approvalDigest"|"scopes"|"purpose"|"issuedAt"|"expiresAt">&{active:boolean;inactiveReasons:readonly CentralWalletSessionInactiveReason[]}>;
export type CentralWalletConnectedApp=Readonly<{requestingProduct:string;productClientId:string;bundleId:string;sessionBindings:readonly string[];activeSessionBindings:readonly string[];approvalDigests:readonly string[];deviceBindings:readonly string[];active:boolean}>;
export type CentralWalletApprovalInventoryItem=Readonly<{approvalDigest:string;requestingProduct:string;productClientId:string;bundleId:string;sessionBindings:readonly string[];activeSessionBindings:readonly string[];revoked:boolean}>;
export type CentralWalletDeviceInventoryItem=Readonly<{deviceBinding:string;requestingProduct:string;productClientId:string;bundleId:string;productDeviceAlgorithm:ProductDeviceAlgorithm;productDeviceKey:string;sessionBindings:readonly string[];activeSessionBindings:readonly string[];revoked:boolean}>;
export type CentralWalletSessionInventory=Readonly<{schemaVersion:1;account:string;asOf:string;connectedApps:readonly CentralWalletConnectedApp[];approvals:readonly CentralWalletApprovalInventoryItem[];devices:readonly CentralWalletDeviceInventoryItem[];sessions:readonly CentralWalletSessionInventoryItem[]}>;
export type SignedNativeTransfer=Readonly<{version:1;chainId:6423;type:"transfer";from:string;to:string;amount:number;fee:1;nonce:number;publicKey:string;signature:string}>;
export declare const WALLET_AUTH_VERSION:"2";
export declare const YNX_NATIVE_CHAIN_ID:"ynx_6423-1";
export declare const YNX_EVM_CHAIN_ID:6423;
export declare const PRODUCT_DEVICE_ALGORITHM:"p256-sha256";
export declare const CENTRAL_REGISTRY_SCHEMA_VERSION:3;
export declare const CENTRAL_VERIFIER_VERSION:"wallet-auth-v2";
export declare const CENTRAL_REGISTRY_DOCUMENT_VERSION:3;
export declare const CENTRAL_REGISTRY_PRODUCT_COUNT:26;
export declare const CENTRAL_PRODUCT_SCHEMA_VERSION:5;
export declare const CENTRAL_WALLET_SESSION_INVENTORY_SCHEMA_VERSION:1;
export declare const CENTRAL_WALLET_SESSION_STORE_SCHEMA_VERSION:2;
export declare const NATIVE_TRANSACTION_DOMAIN:"YNX_NATIVE_TX_V1";
export declare const NATIVE_TRANSACTION_CHAIN_ID:6423;
export declare const NATIVE_TRANSACTION_FEE_YNXT:1;
export declare class WalletAuthError extends Error {readonly code:string;readonly details?:unknown}
export declare class ClientRetiredError extends WalletAuthError {readonly details:Readonly<{clientId:string;replacementURL:string;minimumClientVersion:string}>}
export declare function canonicalJSON(value:unknown):string;
export declare function digestHex(domain:string,value:unknown):string;
export declare function parseAuthorizationRequest(input:string|unknown,options:{now?:Date;registry:Record<string,ProductBinding>}):AuthorizationRequest;
export declare function requestDigest(request:AuthorizationRequest):string;
export declare function walletIdentity(secretHex:string):Readonly<{account:string;accountPublicKey:string}>;
export declare function walletIdentityFromPublicKey(publicKeyHex:string):string;
export declare function evmAddressFromYNX(account:string):string;
export declare function ynxAddressFromEVM(address:string):string;
export declare function signAuthorization(request:AuthorizationRequest,input:{accountSecret:string;account?:string;issuedAt:string}):AuthorizationResponse;
export declare function verifyAuthorization(response:unknown,expected:AuthorizationRequest&{requestDigest:string;now:Date}):AuthorizationResponse;
export declare function encodeRequestDeepLink(request:AuthorizationRequest):string;
export declare function parseWalletDeepLink(url:string,platform:"android"|"ios",options:{now?:Date;registry:Record<string,ProductBinding>}):Readonly<{platform:string;request:AuthorizationRequest}>;
export declare function createCallbackURL(response:Record<string,unknown>&{callback:string}):string;
export declare function parseCallbackURL(url:string,expectedCallback:string):unknown;
export declare class OneTimeNonceStore {constructor(records?:readonly [string,string][]);consume(request:AuthorizationRequest,at?:Date):void;snapshot():readonly [string,string][]}
export declare function createGatewayChallenge(approval:AuthorizationResponse,input:{challenge:string;expiresAt:string},at?:Date):GatewayChallenge;
export declare function parseGatewayChallenge(input:unknown):GatewayChallenge;
export declare function gatewayChallengeSignBytes(challenge:GatewayChallenge):string;
export declare function signGatewayChallenge(challenge:GatewayChallenge,productDeviceSecret:string):GatewayCompletion;
export declare function verifyGatewayCompletion(completion:GatewayCompletion,expected:AuthorizationResponse,at?:Date):Readonly<{sessionBinding:string;productClientId:string;bundleId:string;productDeviceAlgorithm:ProductDeviceAlgorithm;origin:string;account:string;scopes:readonly string[];expiresAt:string}>;
export declare function migrateCentralRegistryEntry(input:CentralRegistryEntryV1|CentralRegistryEntry):CentralRegistryEntry;
export declare function parseCentralRegistryEntry(input:unknown):CentralRegistryEntry;
export declare function registryParserBinding(input:CentralRegistryEntry):Readonly<Record<string,ProductBinding>>;
export declare function verifyCentralWalletSession(input:Readonly<{registryEntry:CentralRegistryEntry;authorizationRequest:AuthorizationRequest;walletApproval:AuthorizationResponse;gatewayCompletion:GatewayCompletion}>,at?:Date):CentralWalletSession;
export declare function parseCentralWalletSession(input:unknown):CentralWalletSession|LegacyCentralWalletSession;
export declare function centralApprovalDigest(approval:AuthorizationResponse):string;
export declare function centralDeviceBinding(requestOrSession:Readonly<Record<string,unknown>>,account:string):string;
export declare function assertCentralWalletSessionActive(session:CentralWalletSession,input:CentralRevocationState,at?:Date):CentralWalletSession;
export declare function parseCentralRegistryDocument(input:unknown):CentralRegistryDocument;
export declare function migrateCentralRegistryDocumentV1(input:unknown):CentralRegistryDocument;
export declare function parseCentralProductRegistration(input:unknown):CentralProductRegistration;
export declare function centralProtocolEntry(registration:CentralProductRegistration,options?:{requireEnabled?:boolean;allowRetired?:boolean}):CentralRegistryEntry;
export declare function centralRegistrationByProduct(document:CentralRegistryDocument,productId:string,options?:{requireEnabled?:boolean}):CentralProductRegistration;
export declare function centralRegisteredWebOrigins(document:CentralRegistryDocument):readonly string[];
export declare class CentralWalletSessionStore {
  constructor(snapshot?:CentralWalletStoreSnapshot);
  complete(input:Readonly<{registryEntry:CentralRegistryEntry;authorizationRequest:AuthorizationRequest;walletApproval:AuthorizationResponse;gatewayCompletion:GatewayCompletion}>,at?:Date):CentralWalletSession;
  introspect(sessionBinding:string,context:Readonly<{productClientId:string;bundleId:string;origin:string;productDeviceKey:string;requiredScopes:readonly string[]}>,at?:Date):Readonly<{active:true;session:CentralWalletSession}>;
  inventory(account:string,at?:Date):CentralWalletSessionInventory;
  revokeSession(sessionBinding:string,at?:Date):string;
  revokeApproval(approvalDigest:string,at?:Date):string;
  revokeDevice(deviceBinding:string,at?:Date):string;
  retireClient(registration:CentralProductRegistration,at?:Date):Readonly<{clientId:string;changed:boolean;revokedSessionBindings:readonly string[];revokedApprovalDigests:readonly string[];revokedDeviceBindings:readonly string[]}>;
  logoutAllDevices(account:string,at?:Date):Readonly<{account:string;before:string}>;
  revocationState():CentralRevocationState;
  snapshot():CentralWalletStoreSnapshot;
}
export declare function parseCentralWalletStoreSnapshot(input:unknown):CentralWalletStoreSnapshot;
export declare const CLIENT_LIFECYCLE_ACTIVE:ClientLifecycleActive;
export declare function parseClientLifecycle(input:unknown,identity:{callbacks:readonly string[]}):ClientLifecycleActive|ClientLifecycleRetired;
export declare function clientRetirementRecord(registration:CentralProductRegistration):ClientRetirementRecord;
export declare function parseClientRetirementRecord(input:unknown):ClientRetirementRecord;
export declare function assertClientLifecycleActive<T extends CentralProductRegistration>(registration:T):T;
export declare function assertSessionClientActive<T extends CentralWalletSession|LegacyCentralWalletSession>(session:T,retiredClients:readonly ClientRetirementRecord[]):T;
export declare function assertClientReturnTargetActive(target:string,retiredClients:readonly ClientRetirementRecord[]):string;
export declare function retirementMatchesSession(record:ClientRetirementRecord,session:CentralWalletSession|LegacyCentralWalletSession):boolean;
export declare function retirementMatchesAuthorization(record:ClientRetirementRecord,request:AuthorizationRequest):boolean;
export declare function retirementRecord(input:CentralProductRegistration|ClientRetirementRecord):ClientRetirementRecord;
export declare function createSignedNativeTransfer(input:Readonly<{accountSecret:string;to:string;amount:number;nonce:number}>):Readonly<{transaction:SignedNativeTransfer;payload:string;hash:string}>;
export declare function parseSignedNativeTransfer(input:string|unknown):SignedNativeTransfer;
export declare function nativeTransferSignJSON(transaction:Omit<SignedNativeTransfer,"signature">|SignedNativeTransfer):string;
export declare function nativeTransferHash(payload:string):string;
export type SmartAccountCall=Readonly<{target:string;selector:string;value:number;dataDigest:string}>;
export type UserOperationEnvelope=Readonly<{schemaVersion:1;chainId:6423;entryPoint:string;sender:string;nonceKey:string;nonceSequence:number;calls:readonly SmartAccountCall[];callGasLimit:number;verificationGasLimit:number;preVerificationGas:number;maxFeePerGas:number;maxPriorityFeePerGas:number;validAfter:string;validUntil:string}>;
export type SponsorshipPolicy=Readonly<{schemaVersion:1;policyId:string;enabled:boolean;sponsorType:"first-action"|"product"|"merchant"|"developer-testnet";productClientId:string;paymaster:string;entryPoint:string;allowedTargets:readonly string[];allowedSelectors:readonly string[];maxCalls:number;maxCostPerOperation:number;maxCostPerSubjectDay:number;maxCostPerSponsorDay:number;requiresFirstAction:boolean;validAfter:string;validUntil:string;provider:string;fees:string;risk:string;revocation:string;source:string;asOf:string;version:string}>;
export type SponsorshipRequest=Readonly<{schemaVersion:1;policyId:string;sponsorType:SponsorshipPolicy["sponsorType"];productClientId:string;sessionBinding:string;account:string;userOperationDigest:string;antiSybilBinding:string;requestedCost:number;subjectDailyUsed:number;sponsorDailyUsed:number;firstAction:boolean;source:string;asOf:string;version:string}>;
export declare const SMART_ACCOUNT_SCHEMA_VERSION:1;
export declare const SMART_ACCOUNT_CHAIN_ID:6423;
export declare function parseUserOperationEnvelope(input:unknown):UserOperationEnvelope;
export declare function userOperationDigest(input:unknown):string;
export declare function parseSponsorshipPolicy(input:unknown):SponsorshipPolicy;
export declare function parseSponsorshipRequest(input:unknown):SponsorshipRequest;
export declare function evaluateSponsorship(operation:unknown,request:unknown,policy:unknown,at?:Date):Readonly<{eligible:boolean;reasons:readonly string[];policyId:string;userOperationDigest:string;paymaster:string;approvedCost:number;remainingSubjectBudget:number;remainingSponsorBudget:number}>;
export type PackedUserOperation=Readonly<{sender:string;nonce:string;initCode:string;callData:string;accountGasLimits:string;preVerificationGas:string;gasFees:string;paymasterAndData:string;signature:string}>;
export declare const ERC_7769_VERSION:"ERC-7769";
export declare const YNX_TESTNET_CHAIN_QUANTITY:"0x1917";
export declare function parsePackedUserOperation(input:unknown):PackedUserOperation;
export declare class ERC7769BundlerClient{constructor(config:{endpoint:string;entryPoint:string;timeoutMs?:number;maxRequestsPerSecond?:number;authentication?:{header:"authorization"|"x-api-key";value:string}});health():Promise<Readonly<Record<string,unknown>>>;estimateUserOperationGas(operation:unknown):Promise<Readonly<Record<string,unknown>>>;sendUserOperation(operation:unknown):Promise<Readonly<Record<string,unknown>>>;getUserOperationByHash(hash:string):Promise<Readonly<Record<string,unknown>>>;getUserOperationReceipt(hash:string):Promise<Readonly<Record<string,unknown>>>;}
export declare const STRATEGY_MANDATE_SCHEMA_VERSION:2;
export declare const STRATEGY_ACTION_SCHEMA_VERSION:1;
export declare const STRATEGY_MANDATE_STORE_SCHEMA_VERSION:1;
export declare function parseStrategyMandate(input:unknown):Readonly<Record<string,unknown>>;
export declare function strategyMandateDigest(input:unknown):string;
export declare function parseStrategyAction(input:unknown):Readonly<Record<string,unknown>>;
export declare function authorizeStrategyAction(mandate:unknown,action:unknown,at?:Date):Readonly<{authorized:true;mandateId:string;mandateDigest:string;actionDigest:string;nonceDomain:string;nonce:string;at:string}>;
export declare function strategyActionNonceKey(nonceDomain:string,nonce:string):string;
export declare function parseStrategyMandateStoreSnapshot(input:unknown):Readonly<Record<string,unknown>>;
export declare class StrategyMandateStore{constructor(snapshot?:unknown);activate(mandate:unknown,at?:Date):Readonly<Record<string,unknown>>;authorize(mandateId:string,action:unknown,at?:Date):Readonly<{authorized:true;mandateId:string;mandateDigest:string;actionDigest:string;nonceDomain:string;nonce:string;at:string}>;revoke(mandateId:string,at?:Date):string;kill(mandateId:string,at?:Date):string;emergencyExit(mandateId:string,reason:string,at?:Date):Readonly<{mandateDigest:string;at:string;reason:string}>;inventory(account:string,at?:Date):readonly Readonly<{mandate:Readonly<Record<string,unknown>>;mandateDigest:string;status:"active"|"expired"|"revoked"|"killed"|"emergency-exit"}>[];snapshot():Readonly<Record<string,unknown>>;}
export declare function parseCapitalProductReview(input:unknown):Readonly<Record<string,unknown>>;
export declare function parseCredentialCandidate(input:unknown,at?:Date):Readonly<Record<string,unknown>>;
export declare function credentialCandidateDigest(input:unknown,at?:Date):string;

export declare const EIP1193_PROVIDER_CODE:Readonly<{USER_REJECTED:4001;UNAUTHORIZED:4100;UNSUPPORTED_METHOD:4200;PROVIDER_DISCONNECTED:4900;CHAIN_DISCONNECTED:4901;UNKNOWN_CHAIN:4902}>;
export declare const STANDARD_WALLET_METHODS:readonly ["wallet_addEthereumChain","wallet_switchEthereumChain","wallet_requestPermissions","wallet_getPermissions","wallet_watchAsset","eth_requestAccounts","eth_accounts","eth_chainId","personal_sign","eth_signTypedData_v4","eth_sendTransaction"];
export declare class Eip1193ProviderError extends Error { readonly code:4001|4100|4200|4900|4901|4902; }
export declare class StandardWalletConnection { constructor(config:Readonly<{provider:unknown;origin:string;metadata:Readonly<{name:string;url:string}>}>); readonly current:Readonly<Record<string,unknown>>|null; connect():Promise<Readonly<Record<string,unknown>>>; request(input:Readonly<{method:string;params?:unknown}>):Promise<unknown>; disconnect():void; subscribe(listener:(event:Readonly<{event:string;value:unknown}>)=>void):()=>boolean; }
export declare function decodeProductSessionGatewayProofHeaderV2(value:unknown):Readonly<Record<string,unknown>>;
export declare function encodeProductSessionGatewayProofHeaderV2(value:unknown):string;
export declare const PRODUCT_SESSION_GATEWAY_HTTP_MAX_BODY_BYTES:1048576;
export type ProductSessionPlatform="android"|"ios"|"linux"|"macos"|"web"|"windows";
export type ProductSessionV2=Readonly<{version:"2";sessionBinding:string;chainId:"ynx_6423-1";productId:string;clientId:string;platform:ProductSessionPlatform;applicationId:string;bundleId:string|null;packageId:string|null;origin:string;callback:string;account:string;deviceId:string;deviceAlgorithm:"p256-sha256";deviceKey:string;deviceBinding:string;nonce:string;state:string;scopes:readonly string[];requestDigest:string;approvalDigest:string;issuedAt:string;expiresAt:string}>;
export declare const PRODUCT_SESSION_REGISTRY_VERSION:2;
export declare const PRODUCT_SESSION_PROTOCOL_VERSION:"2";
export declare const PRODUCT_SESSION_AUTHORITY_SCHEMA_VERSION:2;
export declare const PRODUCT_SESSION_PLATFORMS:readonly ProductSessionPlatform[];
export declare const WALLET_ROUTE_STATUS:Readonly<Record<string,string>>;
export declare const PRODUCT_SESSION_CLIENT_STATE:Readonly<Record<string,string>>;
export declare function parseProductSessionRegistry(input:unknown):Readonly<Record<string,unknown>>;
export declare function migrateProductSessionRegistryV1(input:unknown):Readonly<Record<string,unknown>>;
export declare function productPlatformBinding(registry:unknown,productId:string,platform:ProductSessionPlatform):Readonly<Record<string,unknown>>;
export declare function migrateLegacyCallback(registry:unknown,legacyValue:string,context:{productId:string;platform:ProductSessionPlatform}):Readonly<Record<string,unknown>>;
export declare function migrateLegacyProductSessionRequest(registry:unknown,legacy:unknown,context:{productId:string;platform:ProductSessionPlatform;deviceId:string;state:string},at?:Date):Readonly<Record<string,unknown>>;
export declare function createProductSessionRequest(registry:unknown,input:Readonly<{productId:string;platform:ProductSessionPlatform;deviceId:string;deviceKey:string;scopes:readonly string[];purpose:string;nonce:string;state:string}>,at?:Date):Readonly<Record<string,unknown>>;
export declare function parseProductSessionRequest(registry:unknown,input:unknown,at?:Date):Readonly<Record<string,unknown>>;
export declare function productSessionRequestDigest(registry:unknown,request:unknown,at?:Date):string;
export declare function signProductSessionApproval(registry:unknown,request:unknown,input:{accountSecret:string;scopes:readonly string[];expiresAt:string},at?:Date):Readonly<Record<string,unknown>>;
export declare function parseProductSessionApproval(registry:unknown,request:unknown,input:unknown,at?:Date):Readonly<Record<string,unknown>>;
export declare function createProductSessionChallenge(registry:unknown,request:unknown,approval:unknown,input:{challenge:string},at?:Date):Readonly<Record<string,unknown>>;
export declare function parseProductSessionChallenge(input:unknown):Readonly<Record<string,unknown>>;
export declare function signProductSessionChallenge(challenge:unknown,deviceSecret:string):Readonly<Record<string,unknown>>;
export type ProductSessionPlatformSigner=(input:Readonly<{purpose:"challenge"|"http-proof";algorithm:"p256-sha256";deviceKey:string;payload:string}>)=>string|Promise<string>;
export declare function signProductSessionChallengeWith(challenge:unknown,signer:ProductSessionPlatformSigner):Promise<Readonly<Record<string,unknown>>>;
export declare function parseProductSession(input:unknown):ProductSessionV2;
export declare class ProductSessionAuthority{constructor(registry:unknown,snapshot?:unknown);issueChallenge(input:{request:unknown;approval:unknown;challenge:string},at?:Date):Readonly<Record<string,unknown>>;complete(input:{request:unknown;approval:unknown;completion:unknown},at?:Date):ProductSessionV2;introspect(sessionBinding:string,context:Readonly<Record<string,unknown>>,at?:Date):Readonly<{active:true;session:ProductSessionV2}>;revokeSession(sessionBinding:string):string;revokeDevice(deviceBinding:string):string;revokeAccount(account:string,at?:Date):Readonly<{account:string;before:string}>;snapshot():Readonly<Record<string,unknown>>;}
export declare function walletConnectionChoices(registry:unknown,productId:string,availability:{ynxWalletInstalled:boolean;metaMaskAvailable:boolean}):readonly Readonly<Record<string,unknown>>[];
export declare const METAMASK_EVM_CONNECTION_STATUS:Readonly<{CONNECTED:"connected-evm"}>;
export declare const METAMASK_EVM_CHAIN_ID:6423;
export declare const METAMASK_EVM_CHAIN_QUANTITY:"0x1917";
export declare const METAMASK_EVM_CHAIN:Readonly<{chainId:"0x1917";chainName:"YNX Testnet";nativeCurrency:Readonly<{name:"YNX Testnet";symbol:"YNXT";decimals:18}>;rpcUrls:readonly ["https://evm.ynxweb4.com"];blockExplorerUrls:readonly ["https://explorer.ynxweb4.com"]}>;
export type MetaMaskEvmConnection=Readonly<{status:"connected-evm";wallet:"metamask";connectionMode:"evm-only";authority:"eip-1193-provider-only";productId:string;chainId:6423;chainQuantity:"0x1917";address:string;ynxProductSession:false;productSession:null;limitations:readonly string[]}>;
export declare class MetaMaskEvmConnectionAdapter{constructor(config:Readonly<{registry:unknown;productId:string;provider:unknown}>);connect():Promise<MetaMaskEvmConnection>}
export declare const WALLET_PROVIDER_DISCOVERY_AUTHORITY:"unverified-injected-candidate";
export declare const WALLET_PROVIDER_KIND:Readonly<{YNX:"ynx-wallet";METAMASK:"metamask"}>;
export type WalletProviderCandidate=Readonly<{kind:"ynx-wallet"|"metamask";provider:Readonly<{request:(input:Readonly<Record<string,unknown>>)=>Promise<unknown>}>;source:"eip6963"|"legacy-injected";uuid:string|null;rdns:string|null;name:string|null;authority:"unverified-injected-candidate"}>;
export type WalletProviderDiscovery=Readonly<{ynx:WalletProviderCandidate|null;metamask:WalletProviderCandidate|null;candidates:readonly WalletProviderCandidate[];ambiguities:readonly ("ynx-wallet"|"metamask")[];conflictedAnnouncements:number;authority:"unverified-injected-candidate"}>;
export declare function discoverInjectedWalletProviders(scope?:unknown):WalletProviderDiscovery;
export declare function discoverEip6963WalletProviders(scope?:unknown,waitMs?:number):Promise<WalletProviderDiscovery>;
export declare function discoverWalletProviders(scope?:unknown,waitMs?:number):Promise<WalletProviderDiscovery>;
export declare function selectWalletProviderCandidates(input:unknown[],conflictedAnnouncements?:number):WalletProviderDiscovery;
export declare function walletAvailabilityFromDiscovery(discovery:WalletProviderDiscovery):Readonly<{ynxWalletInstalled:boolean;metaMaskAvailable:boolean}>;
export declare function encodeProductSessionWalletURL(registry:unknown,request:unknown,at?:Date):string;
export declare function parseProductSessionWalletURL(registry:unknown,url:string,at?:Date):Readonly<Record<string,unknown>>;
export declare function prepareWalletOpen(registry:unknown,request:unknown,environment:{networkAvailable:boolean;walletInstalled:boolean;schemeRegistered:boolean},at?:Date):Readonly<Record<string,unknown>>;
export declare function createProductSessionReturnURL(registry:unknown,request:unknown,result:Readonly<Record<string,unknown>>,at?:Date):string;
export declare function parseProductSessionReturnURL(registry:unknown,request:unknown,url:string,at?:Date):Readonly<Record<string,unknown>>;
export declare function canonicalReturnTarget(registry:unknown,productId:string,platform:ProductSessionPlatform):Readonly<Record<string,unknown>>;
export declare class RecoverableProductSessionClient{constructor(config:Readonly<Record<string,unknown>>);readonly current:Readonly<Record<string,unknown>>;readonly storageKey:string;readonly connectionBinding:Readonly<{productId:string;platform:ProductSessionPlatform;applicationId:string}>;detectWalletEnvironment():Promise<Readonly<{walletInstalled:boolean;schemeRegistered:boolean}>>;beginDetected(automatic?:boolean):Promise<Readonly<Record<string,unknown>>>;retryDetected():Promise<Readonly<Record<string,unknown>>>;restore(networkAvailable?:boolean):Promise<Readonly<Record<string,unknown>>>;begin(environment:{walletInstalled:boolean;schemeRegistered:boolean},automatic?:boolean):Promise<Readonly<Record<string,unknown>>>;handleReturn(url:string):Promise<Readonly<Record<string,unknown>>>;retry(environment:{walletInstalled:boolean;schemeRegistered:boolean}):Promise<Readonly<Record<string,unknown>>>;connectionChoices(availability:{ynxWalletInstalled:boolean;metaMaskAvailable:boolean}):readonly Readonly<Record<string,unknown>>[];setNetworkAvailable(available:boolean):Readonly<Record<string,unknown>>;enterGuest():Readonly<Record<string,unknown>>;disconnect():Promise<Readonly<Record<string,unknown>>>;}
export declare const WALLET_CONNECTION_COORDINATOR_STATUS:Readonly<{OPTIONS_READY:"options-ready";SESSION_STATE:"session-state";WALLET_OPENED:"wallet-opened";WALLET_OPEN_FAILED:"wallet-open-failed";YNX_WALLET_PREFERRED:"ynx-wallet-preferred";EVM_CONNECTED:"evm-connected";EVM_UNAVAILABLE:"evm-unavailable"}>;
export declare class WalletConnectionCoordinator{constructor(config:Readonly<{registry:unknown;productId:string;sessionClient:RecoverableProductSessionClient;scope:unknown;discoveryWaitMs:number;openWallet:(input:Readonly<{url:string;request:Readonly<Record<string,unknown>>;requestId:string;automatic:boolean;productId:string;platform:ProductSessionPlatform}>)=>Readonly<{opened:true}|{opened:false;code:string}>|Promise<Readonly<{opened:true}|{opened:false;code:string}>>;openTimeoutMs:number}>);readonly current:Readonly<Record<string,unknown>>;readonly storageKey:string;readonly connectionBinding:Readonly<{productId:string;platform:ProductSessionPlatform;applicationId:string}>;options():Promise<Readonly<Record<string,unknown>>>;restore(networkAvailable?:boolean):Promise<Readonly<Record<string,unknown>>>;beginYNX():Promise<Readonly<Record<string,unknown>>>;retryYNX():Promise<Readonly<Record<string,unknown>>>;handleReturn(url:string):Promise<Readonly<Record<string,unknown>>>;connectMetaMask():Promise<Readonly<Record<string,unknown>>>;setNetworkAvailable(available:boolean):Readonly<Record<string,unknown>>;enterGuest():Readonly<Record<string,unknown>>;disconnect():Promise<Readonly<Record<string,unknown>>>;}
export declare function createProductSessionProofV2(session:ProductSessionV2,input:Readonly<{method:string;path:string;bodyDigest:string;nonce:string;issuedAt:string;expiresAt:string}>,deviceSecret:string):Readonly<Record<string,unknown>>;
export declare function createProductSessionProofV2With(session:ProductSessionV2,input:Readonly<{method:string;path:string;bodyDigest:string;nonce:string;issuedAt:string;expiresAt:string}>,signer:ProductSessionPlatformSigner):Promise<Readonly<Record<string,unknown>>>;
export declare function parseProductSessionProofV2(input:unknown):Readonly<Record<string,unknown>>;
export declare function verifyProductSessionProofV2(proof:unknown,session:ProductSessionV2,request:Readonly<{method:string;path:string;bodyDigest:string}>,at?:Date):Readonly<Record<string,unknown>>;
export declare function productSessionProofV2SignBytes(input:unknown):string;
export declare function productSessionProofV2Digest(input:unknown):string;
export declare const PRODUCT_SESSION_GATEWAY_SCHEMA_VERSION:2;
export declare class ProductSessionGatewayKernel{constructor(registry:unknown,tokenFactory:()=>string,snapshot?:unknown);dispatch(input:Readonly<{requestId:string;method:string;path:string;body:Readonly<Record<string,unknown>>;proof:Readonly<Record<string,unknown>>|null;walletControlProof?:WalletSessionControlProof|null;networkAvailable:boolean}>,at?:Date):Readonly<{status:number;headers:Readonly<Record<string,string>>;body:string}>;snapshot():Readonly<Record<string,unknown>>;}
export declare function parseProductSessionGatewaySnapshot(input:unknown):Readonly<Record<string,unknown>>;
export declare function migrateProductSessionGatewaySnapshotV1(input:unknown):Readonly<Record<string,unknown>>;
export declare const PRODUCT_SESSION_GATEWAY_PROOF_HEADER_V2:"x-ynx-product-session-proof-v2";
export declare class ProductSessionGatewayFetchAdapter{constructor(config:Readonly<{endpoint:string;fetch:(url:string,init:Readonly<Record<string,unknown>>)=>Promise<unknown>;walletInstalled:()=>boolean|Promise<boolean>;schemeRegistered:()=>boolean|Promise<boolean>;timeoutMs:number}>);currentTime(input:Readonly<{requestId:string}>):Promise<Date>;walletInstalled():Promise<boolean>;schemeRegistered():Promise<boolean>;challenge(input:Readonly<Record<string,unknown>>):Promise<Readonly<Record<string,unknown>>>;complete(input:Readonly<Record<string,unknown>>):Promise<Readonly<Record<string,unknown>>>;introspect(input:Readonly<Record<string,unknown>>):Promise<Readonly<Record<string,unknown>>>;revoke(input:Readonly<Record<string,unknown>>):Promise<Readonly<Record<string,unknown>>>;}
export declare function decodeProductSessionGatewayProofHeaderV2(value:unknown):Readonly<Record<string,unknown>>;
export declare function encodeProductSessionGatewayProofHeaderV2(value:unknown):string;
export declare class ProductSessionGatewayHttpHandler{constructor(registry:unknown,tokenFactory:()=>string,snapshot?:unknown);handle(input:Readonly<{requestId:string;method:string;path:string;contentType:string;body:string;proofHeader:string|null;walletControlProofHeader?:string|null;networkAvailable:boolean}>,at?:Date):Readonly<{status:number;headers:Readonly<Record<string,string>>;body:string}>;snapshot():Readonly<Record<string,unknown>>;}
export declare function createSignedIntent(input:Readonly<Record<string,unknown>&{accountSecret:string}>):Readonly<Record<string,unknown>>;
export declare function parseSignedIntent(input:unknown):Readonly<Record<string,unknown>>;
export declare function signedIntentDigest(input:unknown):string;
export declare function exportSignedIntent(input:unknown):string;
export declare function assertSignedIntentActive(input:unknown,context:Readonly<Record<string,unknown>>,at?:Date):Readonly<Record<string,unknown>>;
export declare function createProductSessionProof(session:CentralWalletSession,input:Readonly<{method:string;path:string;bodyDigest:string;nonce:string;issuedAt:string;expiresAt:string}>,productDeviceSecret:string):Readonly<Record<string,unknown>>;
export declare function parseProductSessionProof(input:unknown):Readonly<Record<string,unknown>>;
export declare function productSessionProofSignBytes(input:unknown):string;
export declare function productSessionProofDigest(input:unknown):string;
export declare function httpBodyDigest(body:string|Uint8Array):string;
export declare function verifyProductSessionProof(proof:unknown,session:CentralWalletSession,expected:Readonly<{method:string;path:string;bodyDigest:string;origin:string}>,at?:Date):Readonly<Record<string,unknown>>;
export declare const CANONICAL_GATEWAY_ADAPTER_SCHEMA_VERSION:2;
export declare class CanonicalWalletGatewayAdapter{constructor(registry:unknown,snapshot?:unknown);complete(input:Readonly<Record<string,unknown>>,at?:Date):CentralWalletSession;introspect(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):Readonly<{active:true;session:CentralWalletSession}>;sessionInventory(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):CentralWalletSessionInventory;revokeSession(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):string;revokeApproval(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):string;revokeDevice(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):string;logoutAllDevices(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):Readonly<{account:string;before:string}>;activateMandate(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):Readonly<Record<string,unknown>>;authorizeMandateAction(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):Readonly<Record<string,unknown>>;mandateInventory(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):readonly Readonly<Record<string,unknown>>[];revokeMandate(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):string;killMandate(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):string;emergencyExitMandate(input:Readonly<Record<string,unknown>>,request:Readonly<Record<string,unknown>>,at?:Date):Readonly<Record<string,unknown>>;snapshot():Readonly<Record<string,unknown>>}
export declare function parseGatewayAdapterSnapshot(input:unknown,registryVersion:number):Readonly<Record<string,unknown>>;
export declare function applyClientRetirementToGatewaySnapshot(registry:unknown,snapshot:unknown,productId:string,clientId:string,at?:Date):Readonly<{result:Readonly<{clientId:string;changed:boolean;revokedSessionBindings:readonly string[];revokedApprovalDigests:readonly string[];revokedDeviceBindings:readonly string[]}>;snapshot:Readonly<Record<string,unknown>>}>;
export type WalletProductMigrationStatus="NO_EVIDENCE"|"PROTOCOL_ONLY"|"IN_PROGRESS"|"MIGRATED";
export type WalletProductMigrationPlatform="android"|"ios"|"macos"|"web"|"windows";
export type WalletProductMigrationScenario="wallet-not-installed"|"wallet-installed"|"approved"|"rejected"|"timeout"|"revoked"|"second-open"|"chain-temporary-disconnect-retry";
export type WalletProductMigrationEvidence=Readonly<{platform:WalletProductMigrationPlatform;scenario:WalletProductMigrationScenario;status:"PASSED"|"FAILED";evidencePath:string;evidenceSha256:string;requestIds:readonly string[];screenshots:readonly string[];testedAt:string}>;
export type WalletProductMigrationRecord=Readonly<{product:string;status:WalletProductMigrationStatus;sourceCommit:string|null;sdkSourceCommit:string|null;supportedPlatforms:readonly WalletProductMigrationPlatform[];evidence:readonly WalletProductMigrationEvidence[];unverifiedScenarios:readonly WalletProductMigrationScenario[]}>;
export type WalletProductMigrationMatrix=Readonly<{schemaVersion:1;protocol:"wallet-auth-v2";products:readonly WalletProductMigrationRecord[]}>;
export declare const WALLET_PRODUCT_MIGRATION_SCHEMA_VERSION:1;
export declare const WALLET_PRODUCT_MIGRATION_PRODUCTS:readonly ["Social","Pay","Shop","Exchange","Quant","Developer","Video","Creator Studio","Calendar","Finance","DEX","Card"];
export declare const WALLET_PRODUCT_MIGRATION_SCENARIOS:readonly ["wallet-not-installed","wallet-installed","approved","rejected","timeout","revoked","second-open","chain-temporary-disconnect-retry"];
export declare const WALLET_PRODUCT_MIGRATION_PLATFORMS:readonly ["android","ios","macos","web","windows"];
export declare function parseWalletProductMigrationMatrix(input:string|unknown):WalletProductMigrationMatrix;
export declare function walletProductMigrationSummary(input:string|unknown):Readonly<{complete:boolean;counts:Readonly<Record<WalletProductMigrationStatus,number>>;migratedProducts:readonly string[];totalProducts:number}>;
export declare const CANONICAL_GATEWAY_HTTP_SCHEMA_VERSION:1;
export declare const CANONICAL_GATEWAY_HTTP_MAX_BODY_BYTES:1048576;
export type CanonicalGatewayHttpInput=Readonly<{method:string;path:string;contentType:string;body:string;proof:Readonly<Record<string,unknown>>|null;origin:string}>;
export type CanonicalGatewayHttpResponse=Readonly<{status:number;headers:Readonly<Record<string,string>>;body:string;mutated:boolean}>;
export declare class CanonicalWalletGatewayHttpKernel{constructor(registry:unknown,snapshot?:unknown);dispatch(input:CanonicalGatewayHttpInput,at?:Date):CanonicalGatewayHttpResponse;snapshot():Readonly<Record<string,unknown>>;}
export declare function gatewayStateDigest(snapshot:unknown):string;
export declare const BROWSER_PRODUCT_SESSION_SECURITY_LEVEL:"webcrypto-nonextractable";
export type BrowserProductSessionStorage=Readonly<{securityLevel:"webcrypto-nonextractable";get(key:string):Promise<string|null>;set(key:string,value:string):Promise<void>;remove(key:string):Promise<void>}>;
export type BrowserProductSessionDevice=Readonly<{id:string;key:string;scopes:readonly string[];purpose:string;sign:ProductSessionPlatformSigner}>;
export type BrowserProductSessionCapabilities=Readonly<{securityLevel:"webcrypto-nonextractable";privateKeyExtractable:false;persistedCryptoKey:true;osProtected:false;hardwareBacked:false;origin:string;productId:string;scopes:readonly string[]}>;
export type BrowserProductSessionAdapter=Readonly<{client:RecoverableProductSessionClient;device:BrowserProductSessionDevice;storage:BrowserProductSessionStorage;capabilities:BrowserProductSessionCapabilities;createIntrospectionProof(requiredScopes:readonly string[]):Promise<Readonly<{proof:Readonly<Record<string,unknown>>;proofHeader:string;requestId:string;body:string}>>;close():void}>;
export declare function createBrowserProductSessionClient(config:Readonly<{registry:unknown;productId:string;scopes:readonly string[];purpose:string;gateway:Pick<ProductSessionGatewayFetchAdapter,"walletInstalled"|"schemeRegistered"|"challenge"|"complete"|"introspect"|"revoke"> & Partial<Pick<ProductSessionGatewayFetchAdapter,"currentTime">>;environment?:Readonly<{isSecureContext:boolean;location:Readonly<{origin:string}>;crypto:unknown;indexedDB:unknown}>;clock?:()=>Date}>):Promise<BrowserProductSessionAdapter>;

export type WalletSessionControlIntentPath="/v2/product-sessions/wallet/sessions/revoke-all"|"/v2/product-sessions/wallet/devices/revoke";
export type WalletSessionControlPath="/v2/product-sessions/wallet/sessions"|"/v2/product-sessions/wallet/sessions/revoke"|WalletSessionControlIntentPath;
export type WalletSessionControlProof=Readonly<{version:"2";chainId:"ynx_6423-1";audience:"https://wallet-auth.ynxweb4.com";account:string;accountPublicKey:string;method:"POST";path:WalletSessionControlPath;bodyDigest:string;nonce:string;issuedAt:string;expiresAt:string;signature:string}>;
export type WalletControlledSession=Readonly<{sessionBinding:string;productId:string;clientId:string;displayName:string;platform:string;applicationId:string;origin:string;callback:string;deviceId:string;deviceBinding:string;scopes:readonly string[];issuedAt:string;expiresAt:string;active:boolean;inactiveReasons:readonly string[]}>;
export type WalletSessionControlInventory=Readonly<{account:string;asOf:string;sessions:readonly WalletControlledSession[]}>;
export type WalletSessionControlRevocation=Readonly<{account:string;sessionBinding:string;revoked:true;alreadyRevoked:boolean;asOf:string}>;
export declare const WALLET_SESSION_CONTROL_PROOF_HEADER:"x-ynx-wallet-control-proof-v2";
export declare const WALLET_SESSION_CONTROL_AUDIENCE:"https://wallet-auth.ynxweb4.com";
export declare const WALLET_SESSION_CONTROL_PATHS:readonly WalletSessionControlPath[];
export declare const WALLET_SESSION_CONTROL_INTENT_PATHS:readonly WalletSessionControlIntentPath[];
export declare function createWalletSessionControlProof(input:Readonly<{accountSecret:string;method:"POST";path:WalletSessionControlPath;bodyDigest:string;nonce:string;issuedAt:string;expiresAt:string}>):WalletSessionControlProof;
export declare function parseWalletSessionControlProof(input:unknown):WalletSessionControlProof;
export declare function verifyWalletSessionControlProof(proof:unknown,expected:Readonly<{method:"POST";path:WalletSessionControlPath;bodyDigest:string}>,at?:Date):WalletSessionControlProof;
export declare function walletSessionControlReplayKey(proof:unknown):string;
export declare function encodeWalletSessionControlProofHeader(proof:unknown):string;
export declare function decodeWalletSessionControlProofHeader(value:unknown):WalletSessionControlProof;
export declare const WALLET_SESSION_CONTROL_REPLAY_PREFIX:"f9c24e16a803b572";
export declare function walletSessionControlReplayExpiry(value:unknown):number|null;

export type WalletDownloadPlatform = "android" | "ios" | "linux" | "macos" | "web-extension" | "windows";
/** universal asserts both arm64 and x64 are included (Android/macOS); any is for extensions. */
export type WalletDownloadArchitecture = "any" | "arm64" | "universal" | "x64";
export type WalletDownloadBrowser = "chromium" | "firefox";
export type WalletDownloadInstallation = "apk" | "ios-ad-hoc" | "dmg" | "exe" | "deb" | "rpm" | "appimage" | "extension-unpacked" | "extension-temporary";
export type WalletDownloadArtifact = Readonly<{
  id:string; sourceCommit:string; sha256:string; bytes:number; filename:string; mimeType:string;
  platform:WalletDownloadPlatform; architecture:WalletDownloadArchitecture;
  browser:WalletDownloadBrowser|null; installation:WalletDownloadInstallation;
  storeStatus:"not-a-store-release";
}> & (Readonly<{status:"published";url:string}> | Readonly<{status:"local-only"|"local-failed";url:null}>);
export type WalletDownloadManifest = Readonly<{schemaVersion:1;product:"ynx-wallet";artifacts:readonly WalletDownloadArtifact[]}>;
/** Explicit selector. Unknown supported-looking targets return unavailable; no UA/network guessing. */
export type WalletDownloadSelector = Readonly<{platform?:WalletDownloadPlatform|string|null;architecture?:WalletDownloadArchitecture|string|null;browser?:WalletDownloadBrowser|"safari"|string|null;installation?:WalletDownloadInstallation|string|null}>;
export type WalletDownloadSelection =
  | Readonly<{status:"download";url:string;artifact:WalletDownloadArtifact & Readonly<{status:"published";url:string}>}>
  | Readonly<{status:"selection-required";field:"platform"|"architecture"|"browser"|"installation";choices:readonly string[];target:WalletDownloadSelector}>
  | Readonly<{status:"unavailable";reason:"unsupported-target"|"incompatible-target"|"not-published"|"no-artifact";target:WalletDownloadSelector;candidateStates:readonly ("local-only"|"local-failed")[]}>;
export declare const WALLET_DOWNLOAD_MANIFEST_SCHEMA_VERSION:1;
/** Structural validation of a trusted publisher manifest; not network/installation attestation. */
export declare function parseWalletDownloadManifest(input:unknown):WalletDownloadManifest;
export declare function selectWalletDownload(manifest:unknown,selector?:WalletDownloadSelector):WalletDownloadSelection;
