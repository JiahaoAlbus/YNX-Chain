# Video controlled-takeover bootstrap handoff

The first absent/free bootstrap request was correctly rejected because `ynx-video-viewer.service` is active and owns port 6494. This successor is source/evidence only and performs no production action.

The new executor freezes the exact legacy unit, PID, executable, cwd, command line, start token, unit bytes, shared-current link, Caddy, Viewer response, three API responses and three Creator responses before it writes a rollback receipt. It then stops only the legacy Viewer, proves 6494 free, invokes the already-reviewed dedicated predecessor bootstrap, and requires exact old Viewer bytes on the new dedicated service.

The Creator manifest probe is the exact production path `http://127.0.0.1:6495/creator-studio.manifest.json`. Production and fixtures share one explicit URL map; the actual-shell test records every URL and rejects the obsolete `/release-manifest.json` alias.

Every failure after the legacy stop removes only the exact dedicated bootstrap and starts the unchanged legacy unit. Recovery accepts only a new PID whose stable executable/cwd/cmdline/unit/shared-current identity matches the frozen predecessor and whose 6494 response is byte exact. API 6493, Creator 6495 and Caddy must remain unchanged.

Actual-shell coverage passes normal takeover/restore, stop failure, port-still-bound, bootstrap failure, post-response failure, and concurrent-executor rejection. Production remains untouched.

The successor no longer depends on the absent, unauthorized `/var/lib/ynx-release-evidence`. It creates exactly one dedicated `/var/lib/ynx-video-viewer-wallet-evidence` directory only after matching the frozen `/var/lib` tuple. Device/inode/uid/gid/mode/nlink are recorded before the legacy stop. Success rollback and every failure remove the directory only after exact identity, allowed-file and empty-state checks. An unrelated container sibling is preserved; parent or identity substitution fails closed without deletion.

The corrected successor also crosses the production authorization boundary explicitly. The outer controlled takeover retains `P0_VIDEO_CONTROLLED_TAKEOVER_SINGLE_USE`, while each nested bootstrap and rollback-bootstrap invocation receives exactly `P0_VIDEO_BOOTSTRAP_SINGLE_USE`. The actual-shell fixture starts with the outer token, makes its bootstrap stub reject every other token with exit 77, and proves the exact bootstrap token on both the forward and rollback paths.

Central must independently verify the exact request, stage the frozen carrier/scripts/unit/baseline, wait for Heavy availability, and issue a wholly new Video-only single-use controlled-takeover bootstrap lease. It must not infer candidate deployment or Wallet completion.
