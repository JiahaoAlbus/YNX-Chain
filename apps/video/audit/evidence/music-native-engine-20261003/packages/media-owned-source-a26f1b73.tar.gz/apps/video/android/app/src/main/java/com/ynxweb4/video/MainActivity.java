package com.ynxweb4.video;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.util.UUID;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

public final class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(0, 47, 167);
    private static final String[] LOCALES = {"en","zh-CN","zh-TW","ja","ko","es","fr","de","pt","ru","ar","id"};
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private JSONObject catalog, words;
    private SharedPreferences prefs;
    private LinearLayout content;
    private TextView status;
    private ProgressBar progress;
    private final VideoRequestBoundary boundary = new VideoRequestBoundary();
    private VideoView activePlayer;
    private android.app.AlertDialog activeDialog;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("ynx_video_settings_v1", MODE_PRIVATE);
        loadCatalog();
        selectLanguage(prefs.getString("locale", systemLocale()));
        render();
        if (!handleIntent(getIntent())) loadVideos("");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void loadCatalog() {
        try (InputStream in = getAssets().open("catalog.json")) {
            byte[] bytes = new byte[in.available()];
            int read = in.read(bytes);
            if (read != bytes.length) throw new IllegalStateException("catalog truncated");
            catalog = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
        } catch (Exception error) { throw new IllegalStateException("i18n catalog unavailable", error); }
    }

    private String systemLocale() {
        String tag = Locale.getDefault().toLanguageTag();
        for (String value : LOCALES) if (tag.equalsIgnoreCase(value) || tag.startsWith(value + "-")) return value;
        return "en";
    }

    private void selectLanguage(String locale) {
        if (!Arrays.asList(LOCALES).contains(locale)) locale = "en";
        words = catalog.optJSONObject(locale);
        if (words == null) words = catalog.optJSONObject("en");
        prefs.edit().putString("locale", locale).apply();
        getWindow().getDecorView().setLayoutDirection("ar".equals(locale) ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
    }

    private String t(String key) {
        String value = words.optString(key, "");
        if (value.isEmpty()) value = catalog.optJSONObject("en").optString(key, "[" + key + "]");
        return value;
    }

    private void render() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        LinearLayout top = row(); top.setPadding(dp(18), dp(12), dp(18), dp(12)); top.setBackgroundColor(BLUE);
        top.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.ynx_brand_original); logo.setScaleType(ImageView.ScaleType.FIT_CENTER); logo.setContentDescription("YNX"); logo.setBackgroundColor(Color.WHITE); logo.setPadding(0,0,0,0);
        LinearLayout.LayoutParams logoLayout = new LinearLayout.LayoutParams(dp(46),dp(24)); logoLayout.setMarginEnd(dp(10)); top.addView(logo,logoLayout);
        TextView brand = label("YNX Video", 16, Color.WHITE); brand.setTypeface(Typeface.DEFAULT_BOLD); brand.setMinHeight(dp(48)); top.addView(brand, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        Button signIn = button(t("signIn")); signIn.setTextColor(BLUE); signIn.setContentDescription(t("signIn")); signIn.setOnClickListener(v -> startWallet()); top.addView(signIn);
        root.addView(top);

        LinearLayout controls = row(); controls.setPadding(dp(16), dp(10), dp(16), dp(4));
        EditText search = new EditText(this); search.setHint(t("search")); search.setSingleLine(true); search.setMinHeight(dp(48)); search.setTextSize(16*DisplayPreferences.factor(this)); search.setContentDescription(t("search")); controls.addView(search, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        Button go = button(t("search")); go.setOnClickListener(v -> loadVideos(search.getText().toString())); controls.addView(go);
        root.addView(controls);

        LinearLayout nav = row(); nav.setPadding(dp(16), 0, dp(16), dp(8));
        for (String key : new String[]{"discover","subscriptions","playlists","history"}) {
            Button b = button(t(key)); b.setContentDescription(t(key));
            b.setOnClickListener(v -> { if("discover".equals(key))loadVideos("");else loadCollection("/v1/"+key,key); });
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(46), 1));
        }
        root.addView(nav);

        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(18), dp(8), dp(18), dp(36)); scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        LinearLayout state = row(); state.setPadding(dp(18), dp(8), dp(18), dp(12)); progress = new ProgressBar(this); state.addView(progress, new LinearLayout.LayoutParams(dp(32), dp(32))); status = label(t("loading"), 14, Color.DKGRAY); status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE); state.addView(status, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        Spinner locale = new Spinner(this); locale.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, LOCALES)); locale.setSelection(Arrays.asList(LOCALES).indexOf(prefs.getString("locale", "en")), false); locale.setContentDescription(t("language")); locale.setOnItemSelectedListener(new SimpleSelection(position -> { String chosen = LOCALES[position]; if (!chosen.equals(prefs.getString("locale", "en"))) { selectLanguage(chosen); recreate(); } })); state.addView(locale, new LinearLayout.LayoutParams(dp(92), dp(48)));
        Spinner aiLocale = new Spinner(this); aiLocale.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, LOCALES)); String selectedAI=prefs.getString("ai_locale",prefs.getString("locale","en")); aiLocale.setSelection(Math.max(0,Arrays.asList(LOCALES).indexOf(selectedAI)),false); aiLocale.setContentDescription(t("aiLanguage")); aiLocale.setOnItemSelectedListener(new SimpleSelection(position -> prefs.edit().putString("ai_locale",LOCALES[position]).apply())); state.addView(aiLocale,new LinearLayout.LayoutParams(dp(92),dp(48))); root.addView(state);
        Button display=button(DisplayPreferences.labels(activeLocale())[0]); display.setOnClickListener(v->DisplayPreferences.show(this,activeLocale(),this::recreate)); root.addView(display);
        setContentView(root);
    }

    private void loadVideos(String query) {
        final long generation = beginNavigation();
        if (!online()) { showState(t("offline"), true); return; }
        showState(t("loading"), false);
        worker.execute(() -> {
            try {
                String path = "/v1/videos?q=" + Uri.encode(query);
                JSONObject response = request(path, "GET", null, generation);
                JSONArray videos = response.optJSONArray("items");
                if (videos == null) videos = response.optJSONArray("data");
                if (videos == null && response.has("array")) videos = response.optJSONArray("array");
                final JSONArray result = videos == null ? new JSONArray() : videos;
                currentUI(generation, () -> renderVideos(result));
            } catch (Exception error) { currentUI(generation, () -> showFailure(error.getMessage())); }
        });
    }

    private JSONObject request(String path,String method,JSONObject payload,long generation) throws Exception {
        boundary.require(generation);
        // Native SDK completion and business proof remain an explicit dependency.
        // A callback string alone never grants authority to private operations.
        if (!VideoRequestBoundary.publicRead(path, method)) throw new IllegalStateException(t("signIn") + " · " + t("unavailable"));
        HttpURLConnection connection = (HttpURLConnection) VideoRequestBoundary.url(path).openConnection();
        VideoRequestBoundary.configure(connection);
        connection.setRequestMethod(method); connection.setRequestProperty("Accept", "application/json");
        try {
        if (!"GET".equals(method) && !"HEAD".equals(method)) connection.setRequestProperty("Idempotency-Key", UUID.randomUUID().toString());
        if(payload!=null){byte[] body=payload.toString().getBytes(StandardCharsets.UTF_8);connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json");connection.setFixedLengthStreamingMode(body.length);try(OutputStream output=connection.getOutputStream()){output.write(body);}}
        boundary.require(generation);
        int code = connection.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
        StringBuilder body = new StringBuilder();
        if (stream != null) try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) { for (String line; (line = reader.readLine()) != null;) body.append(line); }
        boundary.require(generation);
        if (code < 200 || code >= 300) throw new IllegalStateException(code == 401 ? t("signIn") : t("unavailable") + " (HTTP " + code + ")");
        String raw = body.toString().trim();
        if (raw.startsWith("[")) return new JSONObject().put("array", new JSONArray(raw));
        return new JSONObject(raw);
        } finally { connection.disconnect(); }
    }

    private void loadCollection(String path,String labelKey) {
        final long generation = beginNavigation();
        if(!online()) { showState(t("offline"),true); return; }
        showState(t("loading"),false);
        worker.execute(() -> {
            try {
                JSONObject response=request(path,"GET",null,generation);
                JSONArray items=response.optJSONArray("array");
                final JSONArray result=items==null ? new JSONArray() : items;
                currentUI(generation, () -> {
                    content.removeAllViews(); progress.setVisibility(View.GONE);
                    if(result.length()==0) { content.addView(label(t(labelKey)+" · "+t("empty"),20,Color.DKGRAY)); return; }
                    for(int i=0;i<result.length();i++) {
                        JSONObject item=result.optJSONObject(i);
                        String text=item==null ? String.valueOf(result.opt(i)) : item.optString("Name",item.optString("name",item.optString("VideoID",item.optString("video_id","record"))));
                        content.addView(label(text,18,Color.DKGRAY));
                    }
                    status.setText(NumberFormat.getIntegerInstance(activeLocale()).format(result.length())+" · "+t(labelKey));
                });
            } catch(Exception error) { currentUI(generation, () -> showFailure(error.getMessage())); }
        });
    }

    private void renderVideos(JSONArray videos) {
        content.removeAllViews(); progress.setVisibility(View.GONE);
        if (videos.length() == 0) { content.addView(label(t("empty"), 20, Color.DKGRAY)); content.addView(label(t("noMetrics"), 14, Color.GRAY)); status.setText(t("empty")); return; }
        for (int i = 0; i < videos.length(); i++) {
            JSONObject video = videos.optJSONObject(i); if (video == null) continue;
            String title = video.optString("title", "Untitled"), id = video.optString("id", ""), description = video.optString("description", "");
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(16), dp(16), dp(16), dp(16)); card.setBackgroundColor(Color.rgb(245,247,252));
            TextView heading = label(title, 20, Color.BLACK); heading.setTypeface(Typeface.DEFAULT_BOLD); card.addView(heading); card.addView(label(description, 14, Color.DKGRAY));
            Button play = button(t("play")); play.setContentDescription(t("play") + ": " + title); play.setOnClickListener(v -> playVideo(video)); card.addView(play); content.addView(card, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            Space(card);
        }
        status.setText(NumberFormat.getIntegerInstance(activeLocale()).format(videos.length()) + " · " + t("noMetrics"));
    }

    private void playVideo(JSONObject video) {
        final long generation = beginNavigation();
        String key = ""; JSONArray variants = video.optJSONArray("variants");
        if (variants != null) for (int i=0;i<variants.length();i++) { JSONObject item=variants.optJSONObject(i); if (item != null && ("adaptive-hls".equals(item.optString("name")) || key.isEmpty())) key=item.optString("object_key"); }
        if (key.isEmpty()) { showState(t("unavailable"), true); return; }
        VideoView player = new VideoView(this); activePlayer = player;
        player.setContentDescription(t("play") + ": " + video.optString("title")); player.setMediaController(new android.widget.MediaController(this));
        try { player.setVideoURI(Uri.parse(VideoRequestBoundary.url("/media/" + key).toString())); }
        catch(Exception error) { showState(t("unavailable"),true); return; }
        player.setOnPreparedListener(media -> { if(boundary.matches(generation)) player.start(); else player.stopPlayback(); });
        content.removeAllViews(); content.addView(player, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260)));
        JSONArray captions=video.optJSONArray("captions"); content.addView(label(t("captions") + ": " + (captions == null ? 0 : captions.length()), 14, Color.DKGRAY));
        LinearLayout actions=row();
        Button subscribe=button(t("subscriptions"));subscribe.setOnClickListener(v->postAction("/v1/channels/"+video.optString("channel_id")+"/subscription",new JSONObject(),t("subscriptions"),generation));actions.addView(subscribe,new LinearLayout.LayoutParams(0,dp(52),1));
        Button comments=button(t("comments"));comments.setOnClickListener(v->comment(video));actions.addView(comments,new LinearLayout.LayoutParams(0,dp(52),1));
        Button report=button(t("report"));report.setOnClickListener(v->report(video));actions.addView(report,new LinearLayout.LayoutParams(0,dp(52),1));content.addView(actions);
        if(captions!=null&&captions.length()>0){Button transcript=button(t("captions"));transcript.setOnClickListener(v->loadTranscript(captions.optJSONObject(0)));content.addView(transcript);}
    }

    private void postAction(String path,JSONObject body,String success,long generation){
        if(!boundary.matches(generation))return;
        worker.execute(()->{try{request(path,"POST",body,generation);currentUI(generation,()->{showState(success,false);progress.setVisibility(View.GONE);});}catch(Exception error){currentUI(generation,()->showState(error.getMessage(),true));}});
    }
    private void comment(JSONObject video){
        final long generation=boundary.current();EditText input=new EditText(this);input.setHint(t("comments"));
        activeDialog=new android.app.AlertDialog.Builder(this).setTitle(t("comments")).setView(input).setNegativeButton(android.R.string.cancel,null).setPositiveButton(android.R.string.ok,(dialog,which)->{if(!boundary.matches(generation))return;try{postAction("/v1/videos/"+video.optString("id")+"/comments",new JSONObject().put("body",input.getText().toString()),t("comments"),generation);}catch(Exception error){showState(error.getMessage(),true);}}).show();
    }
    private void report(JSONObject video){
        final long generation=boundary.current();EditText input=new EditText(this);input.setHint(t("report"));
        activeDialog=new android.app.AlertDialog.Builder(this).setTitle(t("report")).setMessage(t("noMetrics")).setView(input).setNegativeButton(android.R.string.cancel,null).setPositiveButton(android.R.string.ok,(dialog,which)->{if(!boundary.matches(generation))return;try{postAction("/v1/videos/"+video.optString("id")+"/reports",new JSONObject().put("reason","viewer_report").put("details",input.getText().toString()),t("report"),generation);}catch(Exception error){showState(error.getMessage(),true);}}).show();
    }
    private void loadTranscript(JSONObject track){
        if(track==null||!track.optBoolean("human_approved")){showState(t("unavailable"),true);return;}
        final long generation=boundary.current();worker.execute(()->{
            try{boundary.require(generation);HttpURLConnection connection=(HttpURLConnection)VideoRequestBoundary.url("/media/"+track.optString("object_key")).openConnection();VideoRequestBoundary.configure(connection);
                StringBuilder body=new StringBuilder();try{if(connection.getResponseCode()!=200)throw new IllegalStateException(t("unavailable"));try(BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream(),StandardCharsets.UTF_8))){for(String line;(line=reader.readLine())!=null;){if(body.length()>1024*1024)throw new IllegalStateException(t("unavailable"));if(!line.startsWith("WEBVTT")&&!line.contains("-->"))body.append(line).append('\n');}}}finally{connection.disconnect();}
                currentUI(generation,()->{TextView transcript=label(body.toString().trim(),16,Color.DKGRAY);transcript.setContentDescription(t("captions"));content.addView(transcript);});
            }catch(Exception error){currentUI(generation,()->showState(error.getMessage(),true));}
        });
    }

    private long beginNavigation(){
        long generation=boundary.advance();
        if(activePlayer!=null){activePlayer.stopPlayback();activePlayer=null;}
        if(activeDialog!=null){activeDialog.dismiss();activeDialog=null;}
        if(content!=null)content.removeAllViews();
        return generation;
    }
    private void currentUI(long generation,Runnable action){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed()&&boundary.matches(generation))action.run();});}
    @Override protected void onStop(){if(activePlayer!=null)activePlayer.pause();super.onStop();}
    @Override protected void onDestroy(){beginNavigation();worker.shutdownNow();super.onDestroy();}

    private void showFailure(String detail) { content.removeAllViews(); content.addView(label(t("unavailable"), 20, Color.DKGRAY)); TextView reason=label(detail,14,Color.GRAY); content.addView(reason); Button retry=button(t("retry")); retry.setOnClickListener(v -> loadVideos("")); content.addView(retry); showState(t("unavailable"), true); }
    private void showState(String message, boolean failed) { status.setText(message); status.setTextColor(failed ? Color.rgb(155,35,53) : Color.DKGRAY); progress.setVisibility(failed ? View.GONE : View.VISIBLE); }

    private void startWallet() {
        beginNavigation();
        try {
            Instant issued = Instant.now().truncatedTo(ChronoUnit.MILLIS), expires = issued.plus(5, ChronoUnit.MINUTES);
            String nonce = randomBase64(24), deviceKey = productDeviceKey();
            String[] scopes = {"video.comment","video.history","video.read","video.report","video.subscribe"};
            String json = "{" +
                "\"bundleId\":\"com.ynxweb4.video\"," +
                "\"callback\":\"ynxvideo://wallet-auth/callback\"," +
                "\"chainId\":\"ynx_6423-1\"," +
                "\"expiresAt\":" + JSONObject.quote(expires.toString()) + "," +
                "\"issuedAt\":" + JSONObject.quote(issued.toString()) + "," +
                "\"nonce\":" + JSONObject.quote(nonce) + "," +
                "\"productClientId\":\"ynx-video-mobile-v1\"," +
                "\"productDeviceAlgorithm\":\"p256-sha256\"," +
                "\"productDeviceKey\":" + JSONObject.quote(deviceKey) + "," +
                "\"purpose\":" + JSONObject.quote(t("privacy")) + "," +
                "\"requestingProduct\":\"ynx-video\"," +
                "\"scopes\":[\"video.comment\",\"video.history\",\"video.read\",\"video.report\",\"video.subscribe\"]," +
                "\"version\":\"1\"}";
            String request = Base64.encodeToString(json.getBytes(StandardCharsets.UTF_8), Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("ynxwallet://authorize?request=" + Uri.encode(request))));
        } catch (Exception error) { showState(t("unavailable") + ": " + error.getMessage(), true); }
    }

    private boolean handleIntent(Intent intent) {
        Uri data = intent == null ? null : intent.getData(); if (data == null) return false;
        if (!"ynxvideo".equals(data.getScheme()) || data.getUserInfo()!=null || data.getPort()!=-1 || data.getFragment()!=null) return false;
        if ("wallet-auth".equals(data.getHost()) && "/callback".equals(data.getPath())) {
            beginNavigation();
            // A URI (including gateway_session) is not a verified session.
            // The shared native SDK must complete and confirm the exact approval.
            showState(t("signIn") + " · " + t("unavailable"),true);
            return true;
        }
        if ("watch".equals(data.getHost())) { loadVideos(data.getQueryParameter("video")); return true; }
        return false;
    }

    private String productDeviceKey() throws Exception {
        final String alias = "ynx.video.wallet.product-device.v1";
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (!store.containsAlias(alias)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN).setAlgorithmParameterSpec(new ECGenParameterSpec("secp256r1")).setDigests(KeyProperties.DIGEST_SHA256).setUserAuthenticationRequired(false).build()); generator.generateKeyPair();
        }
        ECPublicKey publicKey = (ECPublicKey) store.getCertificate(alias).getPublicKey();
        byte[] x = unsigned32(publicKey.getW().getAffineX()), compressed = new byte[33]; compressed[0] = publicKey.getW().getAffineY().testBit(0) ? (byte)3 : (byte)2; System.arraycopy(x,0,compressed,1,32);
        return Base64.encodeToString(compressed, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }

    private static byte[] unsigned32(BigInteger value) { byte[] raw=value.toByteArray(), out=new byte[32]; int start=Math.max(0,raw.length-32), count=Math.min(32,raw.length); System.arraycopy(raw,start,out,32-count,count); return out; }
    private static String randomBase64(int count) { byte[] bytes=new byte[count]; new SecureRandom().nextBytes(bytes); return Base64.encodeToString(bytes,Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING); }
    private boolean online() { ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE); Network network=cm.getActiveNetwork(); NetworkCapabilities caps=network==null?null:cm.getNetworkCapabilities(network); return caps!=null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET); }
    private Locale activeLocale() { return Locale.forLanguageTag(prefs.getString("locale","en")); }
    String formatDate(java.util.Date value) { return DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT,activeLocale()).format(value); }
    String formatCurrency(long value) { NumberFormat f=NumberFormat.getCurrencyInstance(activeLocale()); f.setCurrency(java.util.Currency.getInstance("CNY")); return f.format(value); }
    String pluralRecords(int count) { return NumberFormat.getIntegerInstance(activeLocale()).format(count)+(count==1?" record":" records"); }
    private LinearLayout row() { LinearLayout x=new LinearLayout(this); x.setOrientation(LinearLayout.HORIZONTAL); x.setGravity(Gravity.CENTER_VERTICAL); return x; }
    private TextView label(String text,int sp,int color) { TextView x=new TextView(this); x.setText(text); x.setTextSize(sp*DisplayPreferences.factor(this)); x.setTextColor(color); x.setPadding(dp(6),dp(6),dp(6),dp(6)); return x; }
    private Button button(String text) { Button x=new Button(this); x.setText(text); x.setAllCaps(false); x.setTextSize(14*DisplayPreferences.factor(this)); x.setMinHeight(dp(48)); return x; }
    private int dp(int value) { return Math.round(value*getResources().getDisplayMetrics().density); }
    private void Space(LinearLayout parent) { View space=new View(this); parent.addView(space,new LinearLayout.LayoutParams(1,dp(8))); }

    private static final class SimpleSelection implements android.widget.AdapterView.OnItemSelectedListener {
        interface Choice { void selected(int position); } private final Choice choice; SimpleSelection(Choice value){choice=value;}
        public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id){choice.selected(position);} public void onNothingSelected(android.widget.AdapterView<?> parent){}
    }
}
