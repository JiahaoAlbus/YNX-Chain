import {createMediaBrowserIdentity} from './browser-identity.js';
import {connectMediaWallet} from './session-events.js';
import {createHostedWalletAdapter, WalletConnectDAppConnection, QRCode} from './ynx-wallet-transports-2ece0cb329.mjs';
import {connectVideoWallet, restoreVideoWallet, WALLET_INSTALLATION_OPTIONS, discoverWalletCandidates, walletChoiceNeedsResolution, walletCandidatesFromError} from "./wallet-connection.js";
import {ready as i18nReady, t} from "./i18n.js";
import {YNX_TESTNET} from "./ynx-dapp-connect-sdk/constants.js";
import {videoProductSession, dispatchPreparedProductRequest} from "./product-session.js";
import {createVideoAPI} from "./video-api.js";
import {createWatchProgress} from "./watch-progress.js";
import {createVideoBusinessIdentity} from "./business-identity.js";
import {createPlaylistJournal,createPlaylistOperationJournal} from "./playlist-journal.js";
import {createRecoveredPlaylist,recoverPlaylistOperation} from "./playlist-recovery.js";

const API = `${location.origin}/video/api`;
const $ = selector => document.querySelector(selector);
const savedWalletStateKey = "ynx.video.walletState";

let currentWallet = null;
let currentVideo = null;
let currentChannelId = null, returnPlayerVideo = null;
let watchProgress = null;
let subscriptionRevision = 0;
let productState = {status: "guest"};
let productExpiryTimer;
let productRevision = 0;
let productRequestAbort = new AbortController();
function invalidateProductRequests() {
  productRevision++;
  productRequestAbort.abort(new DOMException("Video account changed.", "AbortError"));
  productRequestAbort = new AbortController();
}
let productSignOutPending = false;
let currentView = "discover";
let currentPlaylist = null;
let playlistTarget = null;
let libraryEpoch = 0;
let unsubscribeEvents = [];

const storageState = {
  read() {
    try { return JSON.parse(sessionStorage.getItem(savedWalletStateKey) || "null"); } catch { return null; }
  },
  write(state) {
    try {
      if (!state) return sessionStorage.removeItem(savedWalletStateKey);
      sessionStorage.setItem(savedWalletStateKey, JSON.stringify(state));
    } catch { /* An unavailable optional EVM cache cannot block playback. */ }
  },
  clear() {
    try {sessionStorage.removeItem(savedWalletStateKey);} catch {}
  },
};

function maskAccount(account) {
  return `${account?.slice(0, 6)}…${account?.slice(-4)}`;
}

function clearLegacySession() {
  try {sessionStorage.removeItem("ynx.video.session");} catch {}
  if (new URLSearchParams(location.hash.slice(1)).has("gateway_session")) history.replaceState(null, "", location.pathname + location.search);
}

function showInstallOptions(show) {
  const box = $("#wallet-install");
  const ynx = `<a href="${WALLET_INSTALLATION_OPTIONS.ynxWallet}">Download YNX Wallet</a>`;
  const meta = `<a href="${WALLET_INSTALLATION_OPTIONS.metaMask}">Download MetaMask</a>`;
  box.hidden = !show;
  box.innerHTML = show ? `<span>No compatible Wallet detected.</span><br/>${ynx} · ${meta}` : "";
}

function getWalletName(state) {
  return state?.walletLabel || state?.walletName || state?.walletBrand || "Standard Wallet";
}

function setConnectionMessage(message) {
  $("#session").textContent = message;
}

function resetWallet(message = "Wallet disconnected. Guest playback remains available.") {
  currentWallet = null;
  setConnectionMessage(message + " Your Video sign-in is separate.");
  $("#signin").textContent = "Connect EVM wallet";
  $("#revoke").hidden = true;
  $("#wallet-status").classList.remove("wallet-connected");
  for (const unsub of unsubscribeEvents) {
    try { unsub?.(); } catch {}
  }
  unsubscribeEvents = [];
  storageState.clear();
}

function renderWalletState(state) {
  $("#signin").textContent = `${getWalletName(state)} · ${maskAccount(state.account)}`;
  $("#wallet-status").classList.add("wallet-connected");
  $("#revoke").hidden = false;
  setConnectionMessage(`Connected to ${getWalletName(state)} on YNX Testnet (${state.chainId}). ` +
    "This EVM connection does not sign in to your Video account.");
  $("#wallet-install").hidden = true;
  storageState.write({
    walletId: state.walletId,
    account: state.account,
    chainId: state.chainId,
    walletName: getWalletName(state),
    walletKind: state.walletKind,
    providerKey: state.providerKey,
  });
}

function bindWalletEvents(walletState) {
  const provider = walletState.connection?.provider || walletState.provider;
  if (!provider || typeof provider.on !== "function") return;

  const onAccountsChanged = (accounts) => {
    const account = Array.isArray(accounts) ? accounts[0] || null : null;
    if (!account) {
      setConnectionMessage("Wallet account was revoked. Reconnect to continue.");
      revokeWallet("accountsChanged-empty");
      return;
    }
    currentWallet = {...currentWallet, account};
    renderWalletState(currentWallet);
    setConnectionMessage(`Account changed. Reconnected as ${maskAccount(account)}.`);
  };

  const onChainChanged = (chainId) => {
    if (String(chainId).toLowerCase() !== YNX_TESTNET.evmChainHex) {
      setConnectionMessage(`Wallet chain changed away from ${YNX_TESTNET.evmChainHex}; reconnect or switch back in your Wallet to continue.`);
      return;
    }
    currentWallet = {...currentWallet, chainId: String(chainId).toLowerCase()};
    renderWalletState(currentWallet);
    setConnectionMessage(`Wallet switched back to ${currentWallet.chainId}.`);
  };

  const onDisconnect = () => {
    setConnectionMessage("Provider disconnected. Reconnect to continue.");
    revokeWallet("provider-disconnect");
  };

  unsubscribeEvents.push(() => provider.removeListener?.("accountsChanged", onAccountsChanged));
  unsubscribeEvents.push(() => provider.removeListener?.("chainChanged", onChainChanged));
  unsubscribeEvents.push(() => provider.removeListener?.("disconnect", onDisconnect));
  provider.on("accountsChanged", onAccountsChanged);
  provider.on("chainChanged", onChainChanged);
  provider.on("disconnect", onDisconnect);
}

let siteAccountBusy=false;
const browserIdentity=createMediaBrowserIdentity({productId:"video",onExpiry:()=>renderProductState({status:"retry-required",message:"Your YNX account sign-in expired. Sign in and retry your saved product approval."})});
// Product Session v2 and the EVM provider are independent authorities.
export const api = createVideoAPI({baseURL: API,
  authorize: (path, method, body) => {const state=productState,revision=productRevision;return browserIdentity.authorization(state.session,()=>videoProductSession.authorization(path,method,body),()=>{if(state!==productState||revision!==productRevision||productSignOutPending)throw new DOMException("Video account changed.","AbortError");});},
  onUnauthorized: () => renderProductState({status: "retry-required", message: "Your sign-in needs to be checked. Retry or sign in again."}),
});
const businessIdentity = createVideoBusinessIdentity({read: (path, options) => api(path, {...options, private: true})});
const privateAPI = async (path, options = {}) => {
  const revision = productRevision;
  if (!productConnected() || productSignOutPending) throw new Error("Sign in to use your Video library.");
  const assertCurrent = () => {if (revision !== productRevision || !productConnected() || productSignOutPending) throw new Error("Video account changed. This operation was discarded.");};
  const signal = options.signal ? AbortSignal.any([productRequestAbort.signal, options.signal]) : productRequestAbort.signal;
  const result = await api(path, {...options, signal, private: true, assertCurrent});
  if (revision !== productRevision || !productConnected() || productSignOutPending) throw new Error("Video account changed. This response was discarded.");
  return result;
};

const playlistJournal=createPlaylistJournal(),playlistOperations=createPlaylistOperationJournal();
function playlistScope(extra=()=>{}) {
  const account=productState.session?.account,revision=productRevision;
  const current=()=>{if(revision!==productRevision||!productConnected()||productSignOutPending||productState.session?.account!==account)throw new DOMException("Video account changed.","AbortError");extra();};
  current();const matches=()=>{try{current();return true;}catch{return false;}};return {account,current,matches};
}
async function createOriginalPlaylist(name,scope=playlistScope()) {
  return createRecoveredPlaylist({journal:playlistJournal,...scope,api:privateAPI,name});
}
async function changeOriginalPlaylist(action,playlistID,videoID=null,scope=playlistScope()) {
  return recoverPlaylistOperation({journal:playlistOperations,...scope,api:privateAPI,action,playlistID,videoID});
}
async function renderPlaylistOperations(box,scope) {
  const saved=await playlistOperations.read(scope.account,scope.current);scope.current();box.replaceChildren();
  if(!saved.pending)return;
  const original=saved.pending,label=document.createElement("p");label.textContent=t({add:"addToPlaylist",remove:"removeFromPlaylist",delete:"deletePlaylist"}[original.body.action])+": "+original.body.name;
  const retry=document.createElement("button");retry.type="button";retry.dataset.retryPlaylistChange="";retry.textContent=t("retry");retry.onclick=async()=>{retry.disabled=true;try{scope.current();await changeOriginalPlaylist(original.body.action,original.body.playlistID,original.body.videoID,scope);scope.current();await showPlaylists(document.querySelector('[data-view="playlists"]'));}catch(error){if(scope.matches())notice(error.message,true);}finally{if(scope.matches())retry.disabled=false;}};box.append(label,retry);
}
async function renderPlaylistRecovery(form,box,scope) {
  const saved=await playlistJournal.read(scope.account,scope.current);scope.current();const input=form.elements.name,submit=form.querySelector('button[type="submit"]');
  input.value=saved.pending?.body.Name??"";input.disabled=!!saved.pending;submit.textContent=t(saved.pending?"retry":"createPlaylist");
  form.querySelector('[data-pause-playlist]')?.remove();box.replaceChildren();
  if(saved.pending){const original=saved.pending,pause=document.createElement("button");pause.type="button";pause.className="outline";pause.dataset.pausePlaylist="";pause.textContent=t("pauseDraft");pause.onclick=async()=>{try{scope.current();if(!confirm(t("pauseDraftNotice")))return;scope.current();await playlistJournal.pause(scope.account,original,scope.current);await renderPlaylistRecovery(form,box,scope);}catch(error){if(error.name!=="AbortError")notice(error.message,true);}};form.append(pause);}
  if(saved.history.length){const title=document.createElement("h3");title.textContent=t("savedDrafts");box.append(title);for(const original of saved.history){const row=document.createElement("div");row.className="library-row";const label=document.createElement("span");label.textContent=original.body.Name;const restore=document.createElement("button");restore.type="button";restore.textContent=t("restoreDraft");restore.disabled=!!saved.pending;restore.onclick=async()=>{try{scope.current();await playlistJournal.restore(scope.account,original,scope.current);await renderPlaylistRecovery(form,box,scope);}catch(error){if(error.name!=="AbortError")notice(error.message,true);}};row.append(label,restore);box.append(row);}}
}

const json = body => ({method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});

function notice(message, bad = false) {
  const node = $("#notice");
  node.textContent = message;
  node.style.color = bad ? "#8b1e2d" : "#344054";
}

function productConnected() {
  return productState.status === "connected" && businessIdentity.matches(productState.session);
}

function renderProductState(state, {identityConfirmed = false} = {}) {
  const wasConnected = productConnected();
  const previousAccount = productState.session?.account;
  if (!identityConfirmed) {businessIdentity.invalidate();browserIdentity.invalidate();}
  if (state.revocationPending) productSignOutPending = true;
  if (["disconnected", "expired"].includes(state.status)) productSignOutPending = false;
  productState = state;
  clearTimeout(productExpiryTimer);
  const connected = productConnected();
  const checking = state.status === "connected" && !connected && Date.parse(state.session?.expiresAt || "") > Date.now();
  // Browser capability callbacks intentionally return false: they cannot tell
  // whether the separate native Wallet is installed. This SDK launch route is
  // an unsigned request, not a failed sign-in or an account needing sign-out.
  const walletLaunchRequired = !productSignOutPending && state.status === "retry-required" && state.request &&
    ["wallet-not-installed", "scheme-not-registered"].includes(state.route?.status);
  const retryRequired = !walletLaunchRequired && ["network-unavailable", "retry-required"].includes(state.status);
  $("#product-status").textContent = connected
    ? `Signed in as ${maskAccount(state.session.account)}. Your playlists, subscriptions and history are available.`
    : checking ? "Checking your Video account and saved library…"
    : walletLaunchRequired ? "Watch as a guest, or select Sign in with YNX Wallet to open an approval request."
    : state.message || "Sign in with YNX Wallet to save playlists, subscriptions and watch history.";
  $("#product-signin").textContent = connected ? "Video account" : "Sign in";
  $("#product-connect").textContent = connected ? "Switch Video account" : "Sign in with YNX Wallet";
  $("#product-connect").disabled = siteAccountBusy || productSignOutPending || checking;
  $("#product-disconnect").textContent = productSignOutPending ? "Retry sign out" : "Sign out";
  $("#product-disconnect").hidden = !connected && !checking && !productSignOutPending && !retryRequired;
  $("#product-retry").hidden = productSignOutPending || !retryRequired;
  $("#product-launch").hidden = true;
  $("#comment button").disabled = !connected;
  $("#comment textarea").disabled = !connected;
  $("#comment-account-hint").hidden = connected;
  if (!connected || previousAccount && previousAccount !== state.session?.account) {
    invalidateProductRequests();
    if (!checking || previousAccount && previousAccount !== state.session?.account) currentPlaylist = null;
    playlistTarget = null;
    $("#playlist-choice").replaceChildren();
    $("#playlist-name").value = "";
    $("#comment textarea").value = "";
    $("#product-launch").removeAttribute("href");
    watchProgress?.discard();
    if (["subscriptions", "playlists", "history", "settings"].includes(currentView)) {
      libraryEpoch++;
      renderAccountRequired();
    }
    if ($("#playlist-picker").open) $("#playlist-picker").close();
  }
  if (connected) productExpiryTimer = setTimeout(() => renderProductState({status: "retry-required", message: "Your sign-in expired. Sign in again to use your library."}), Math.max(0, Date.parse(state.session.expiresAt) - Date.now()));
  if (connected && currentVideo && (!wasConnected || previousAccount !== state.session.account)) startWatchProgress(currentVideo);
  void refreshSubscriptionButton();
  if (checking && !productSignOutPending) {
    const revision = productRevision;
    const assertCurrent = () => {if (revision !== productRevision || productState !== state || productSignOutPending) throw new DOMException("Video account changed.", "AbortError");};
    void businessIdentity.verify(state.session, {signal: productRequestAbort.signal, assertCurrent}).then(() => {
      assertCurrent();renderProductState(state, {identityConfirmed: true});void refreshLibraryView().catch(error => {if (revision === productRevision) notice(error.message, true);});
    }).catch(error => {
      if (revision === productRevision && productState === state && error.name !== "AbortError") renderProductState({status: "retry-required", message: error.message || "Video account could not be confirmed. Retry sign in."});
    });
  }
}

function focusSignIn() {
  if ($("#player").open) {returnPlayerVideo=currentVideo?.id; $("#video").pause(); $("#player").close();}
  if ($("#playlist-picker").open) $("#playlist-picker").close();
  $("#video-account").scrollIntoView({behavior: "smooth", block: "center"});
  $("#product-connect").focus();
  if (!productConnected() && productState.status !== "connected") return prepareVideoSignIn();
}

function requireAccount() {
  if (productConnected()) return true;
  notice("Sign in with YNX Wallet to use this action. You can keep watching as a guest.");
  focusSignIn();
  return false;
}

function renderAccountRequired() {
  $("#content").setAttribute("aria-busy", "false");
  $("#content").innerHTML = '<section class="empty"><h2>Your Video library</h2><p>Sign in with YNX Wallet to see your saved videos and history.</p><button id="library-signin">Go to sign in</button></section>';
  $("#library-signin").onclick = focusSignIn;
}

async function restoreVideoAccount() {
  if (productSignOutPending) return;
  const revision = productRevision;
  if (!videoProductSession.atRegisteredOrigin()) {
    renderProductState({status: "guest", message: "Guest playback is available here. Open video.ynxweb4.com to sign in."});
    $("#canonical-signin").hidden = false;
    return;
  }
  $("#product-status").textContent = "Checking your saved sign-in. Guest playback is available.";
  try {
    const state = await videoProductSession.restore();
    if (revision !== productRevision || productSignOutPending) return;
    renderProductState(state);
    if (productConnected()) void refreshLibraryView();
  } catch {
    if (revision !== productRevision || productSignOutPending) return;
    renderProductState({status: "retry-required", message: "Video sign-in is unavailable. Retry when your connection is restored; guest playback remains available."});
  }
}

async function signOutVideoAccount() {
  cancelVideoSignIn();
  if ($("#product-disconnect").disabled) return;
  productSignOutPending = true;
  renderProductState({status: "retry-required", revocationPending: true, message: "Signing out…"});
  videoProductSession.announce?.();
  const revision = productRevision;
  $("#product-disconnect").disabled = true;
  try {
    const state = await videoProductSession.disconnect();
    if (revision !== productRevision) return;
    renderProductState(state);
    videoProductSession.announce?.();
    if (!productSignOutPending) notice("Your Video account is signed out.");
    return state;
  } catch {
    if (revision === productRevision) renderProductState({status: "retry-required", revocationPending: true, message: "Sign-out could not be confirmed. Select Retry sign out when connected."});
  } finally {$("#product-disconnect").disabled = false;}
}

let videoSignInIntent = 0;
let videoSignInAbort, videoTransportCancel, videoPairConnection;
let nativePreparation = false, nativeExpiryTimer, nativeReturn, nativeRestoreFlight;
const productChooser = $("#product-wallet-chooser");
function clearProductPair() {
 $("#product-pair-panel").hidden = true;
 $("#product-pair-open").hidden = true;
 $("#product-pair-open").removeAttribute("href");
}
function clearNativeStep() {
 nativeReturn = null;
 clearTimeout(nativeExpiryTimer);
 $("#product-native-open").hidden = true;
 $("#product-native-open").removeAttribute('href');
 $("#product-native-open").onclick = null;
}
function cancelVideoSignIn() {
 clearNativeStep();
 videoSignInIntent++;
 videoSignInAbort?.abort();
 const release = videoTransportCancel; videoTransportCancel = null;
 if (release) void Promise.resolve().then(release).catch(() => {});
 clearProductPair(); productChooser.close();
 $("#product-connect").disabled = productSignOutPending;
}
$("#product-wallet-cancel").onclick = cancelVideoSignIn;
productChooser.addEventListener("cancel", cancelVideoSignIn);
$("#product-wallet-back").onclick = () => {cancelVideoSignIn(); return prepareVideoSignIn();};
function productWalletFailure(error) {
 const code = String(error?.code ?? '');
 if (code === '4001' || code === 'USER_REJECTED') return 'You rejected the request. Choose another wallet or retry.';
 if (code.includes('RELAY') || code.includes('INITIALIZATION')) return 'The Wallet connection network is unavailable. Choose another wallet or try again later.';
 if (code.includes('DRAINING')) return 'The previous connection is still closing. Choose another wallet or try again shortly.';
 if (code.includes('TIMEOUT') || code.includes('EXPIRED')) return 'This request expired. Choose another wallet to start a fresh request.';
 if (code === 'HOSTED_POPUP_BLOCKED') return 'Allow the Wallet popup for this site, then choose Web Wallet again.';
 if (code === 'HOSTED_POPUP_CLOSED') return 'The Wallet window was closed. Choose Web Wallet again to continue.';
 return 'Sign-in could not complete. Choose another wallet or try again. No new account access has been confirmed.';
}
async function prepareVideoSignIn() {
 if (siteAccountBusy) return;
 if (productChooser.open) {$("#product-wallet-status").focus(); return;}
 videoSignInAbort?.abort();
 if (productSignOutPending) return;
 if (productConnected()) {await signOutVideoAccount(); if (productSignOutPending) return;}
 invalidateProductRequests();
 const intent = ++videoSignInIntent, choices = $("#product-wallet-choices");
 choices.replaceChildren(); choices.hidden = false; clearProductPair(); clearNativeStep();
 $("#product-wallet-back").hidden = true;
 $("#product-wallet-status").textContent = 'Finding YNX Wallet…';
 if (!productChooser.open) productChooser.showModal();
 const current = () => intent === videoSignInIntent && !productSignOutPending;
 const choose = (label, action) => {
  const button = document.createElement('button'); button.type = 'button'; button.textContent = label;
  button.onclick = action; choices.append(button); return button;
 };
 const select = async (label, connect, release) => {
  if (!current()) return;
  if (nativePreparation) {$("#product-wallet-status").textContent = 'The previous request is still closing. Please wait, then choose your Wallet again.'; return;}
  choices.hidden = true; $("#product-wallet-back").hidden = false; clearProductPair();
  $("#product-wallet-status").textContent = label + ': connect your Wallet, then review the Video request.';
  const abort = new AbortController(); videoSignInAbort = abort; videoTransportCancel = release;
  let provider, invalidate;
  try {
   // Called synchronously by the actual click: Hosted opens before any fetch.
   provider = await connectMediaWallet({connect, release, signal: abort.signal, isCurrent: current});
   if (!current()) {release?.(); return;}
   clearProductPair();
   $("#product-wallet-status").textContent = 'Review the Video request in ' + label + '. You may approve or reject it.';
   invalidate = () => {if (intent === videoSignInIntent) cancelVideoSignIn();};
   for (const event of ['accountsChanged', 'chainChanged', 'disconnect']) provider.on?.(event, invalidate);
   const state = await dispatchPreparedProductRequest(provider, async () => {const request = await videoProductSession.prepare(); videoProductSession.rememberReturn?.(request, currentView, {video:returnPlayerVideo,mediaChannel:currentView==="channel"?currentChannelId:null,mediaPlaylist:currentPlaylist}); return request;}, url => videoProductSession.finishReturn(url), current,
    {signal: abort.signal, revoke: () => videoProductSession.disconnect(), onRevocation: renderProductState});
   if (intent !== videoSignInIntent) return;
   renderProductState(state);
   videoProductSession.announce?.();
   if (state.status === 'connected') {productChooser.close(); await refreshLibraryView();}
   else $("#product-wallet-status").textContent = state.message || 'Approval was not completed. Choose another wallet or retry.';
  } catch (error) {
   if (intent === videoSignInIntent && error.productSessionState?.revocationPending) {cancelVideoSignIn(); renderProductState(error.productSessionState);}
   else if (intent === videoSignInIntent) {clearProductPair(); $("#product-wallet-status").textContent = productWalletFailure(error);}
  } finally {
   if (videoSignInAbort === abort) videoSignInAbort = null;
   if (provider && invalidate) for (const event of ['accountsChanged', 'chainChanged', 'disconnect']) provider.removeListener?.(event, invalidate);
  }
 };
 try {
  const candidates = (await discoverWalletCandidates(window).catch(error => {if (error.code === 'WALLET_NOT_INSTALLED') return []; throw error;})).filter(item => item.isYNXWallet);
  if (!current()) return;
  $("#product-wallet-status").textContent = 'Choose how to open YNX Wallet. Each sign-in still requires your approval.';
  for (const candidate of candidates) choose(candidate.label || candidate.info?.name || candidate.name || 'YNX Wallet extension',
   () => select('YNX Wallet extension', () => candidate.provider));
  if (!candidates.length) {const missing = choose('YNX Wallet extension — not detected', () => {}); missing.disabled = true;}
  choose('YNX Web Wallet', () => {
   if (!current()) return;
   let adapter;
   return select('YNX Web Wallet', () => {adapter = createHostedWalletAdapter({window}); return adapter.connect().then(() => adapter);}, () => adapter?.suspend());
  });
  choose('YNX Wallet on my phone', () => {
   if (!current()) return;
   let pair;
   return select('YNX mobile Wallet', () => {
    videoPairConnection ??= new WalletConnectDAppConnection({origin: location.origin, methods: ['ynx_requestProductSessionV2']});
    pair = videoPairConnection;
    return pair.connect({restore: true, onURI: uri => {
    if (!current()) return;
    $("#product-pair-panel").hidden = false;
    $("#product-pair-open").href = 'ynxwallet://wc?uri=' + encodeURIComponent(uri);
    $("#product-pair-open").hidden = false;
    $("#product-wallet-status").textContent = 'Scan this code in YNX Wallet, or open the app on this phone. Review the connection there; the Video sign-in approval follows.';
    void QRCode.toCanvas($("#product-pair-qr"), uri, {width: 240, margin: 2, errorCorrectionLevel: 'M'}).catch(() => {
     if (current()) $("#product-wallet-status").textContent = 'The code could not be displayed. Use Open YNX Wallet or choose another wallet.';
    });
   }});}, () => pair?.cancel());
  });
  choose('YNX Wallet installed app', () => {if (!current()) return; return prepareNativeVideoSignIn(intent);});
 } catch (error) {if (intent === videoSignInIntent) $("#product-wallet-status").textContent = productWalletFailure(error);}
}

async function prepareNativeVideoSignIn(intent) {
 if (productSignOutPending || intent !== videoSignInIntent) return;
 if (nativePreparation) {$("#product-wallet-status").textContent = 'The previous request is still closing. Please wait and try again.'; return;}
 nativePreparation = true;
 $("#product-wallet-choices").hidden = true; $("#product-wallet-back").hidden = false;
 clearNativeStep();
 $("#product-wallet-status").textContent = 'Preparing a secure Video request. Next, select Open YNX Wallet to open the installed app.';
 const current = () => intent === videoSignInIntent && !productSignOutPending;
 const revokeNative = async () => {
  renderProductState({status:'retry-required',revocationPending:true,message:'Cancelling sign-in securely. Confirmation is pending.'});
  try {const state = await videoProductSession.disconnect();renderProductState({...state,revocationPending:!['disconnected','expired'].includes(state.status)});}
  catch {renderProductState({status:'retry-required',revocationPending:true,message:'Sign-out could not be confirmed. Retry sign out when connected.'});}
 };
 try {
  const request = await videoProductSession.prepare();
  videoProductSession.rememberReturn?.(request, currentView); videoProductSession.announce?.();
  if (!current()) {await revokeNative(); return;}
  videoTransportCancel = revokeNative;
  if (!Number.isFinite(Date.parse(request.expiresAt)) || Date.parse(request.expiresAt) <= Date.now() || !request.url.startsWith('ynxwallet://')) throw Object.assign(new Error('Native request unavailable'),{code:'PRODUCT_REQUEST_EXPIRED'});
  const launch = $("#product-native-open"); let launched = false;
  const returning = {intent, state: request.state, expiresAt: request.expiresAt, launched:false, revision:productRevision};
  nativeReturn = returning;
  launch.href = request.url; launch.hidden = false; launch.removeAttribute('aria-disabled');
  $("#product-wallet-status").textContent = 'Your request is ready. Select Open YNX Wallet below, approve Video in the app, and return here. If it does not open, install YNX Wallet or choose another way.';
  launch.onclick = event => {
   if (launched) {event.preventDefault(); return;}
   if (!current() || launch.hidden || launch.href !== request.url || Date.parse(request.expiresAt) <= Date.now()) {
    event.preventDefault(); clearNativeStep();
    if (current()) $("#product-wallet-status").textContent = 'This open attempt is no longer available. Choose another wallet to start a fresh request.';
    return;
   }
   // The actual anchor click owns browser activation; preparation never navigates.
   launched = true; returning.launched = true; launch.setAttribute('aria-disabled','true');
   $("#product-wallet-status").textContent = 'Opening YNX Wallet was requested. Approve the request in the app and return here. If the browser blocked it or Wallet is not installed, choose another wallet or use the download link.';
  };
  launch.focus();
  nativeExpiryTimer = setTimeout(() => {if (current()) {clearNativeStep();$("#product-wallet-status").textContent = 'This sign-in request expired. Choose another wallet to start again.';}},Math.max(0,Date.parse(request.expiresAt)-Date.now()));
 } catch(error) {
  if (current() && error.productSessionState?.revocationPending) renderProductState(error.productSessionState);
  else if (current()) $("#product-wallet-status").textContent = productWalletFailure(error);
 } finally {nativePreparation = false;}
}

async function resumeNativeSignIn() {
 const returning = nativeReturn;
 const current = () => returning && nativeReturn === returning && returning.launched && returning.intent === videoSignInIntent && returning.revision === productRevision && !productSignOutPending && Date.parse(returning.expiresAt) > Date.now();
 if (!current()) return;
 if (nativeRestoreFlight) return nativeRestoreFlight;
 const operation = (async () => {
  try {
   const state = await videoProductSession.restoreNativeReturn(returning.state);
   if (!current()) return;
   if (state?.status === 'connected') {
    if (!returning.state || state.session?.state !== returning.state) {$("#product-wallet-status").textContent = 'This return belongs to a different sign-in. Choose another wallet to start again.'; return;}
    clearNativeStep(); videoTransportCancel = null;
    productChooser.close(); renderProductState(state);
    videoProductSession.announce?.();
    await refreshLibraryView();
   } else if (state?.revocationPending) {clearNativeStep(); renderProductState(state);}
   else $("#product-wallet-status").textContent = 'Approval has not been confirmed yet. Finish in YNX Wallet and return here, or choose another wallet.';
  } catch {if (current()) $("#product-wallet-status").textContent = 'Your sign-in could not be checked. Return here when connected, or choose another wallet.';}
 })();
 nativeRestoreFlight = operation;
 try {return await operation;} finally {if (nativeRestoreFlight === operation) nativeRestoreFlight = null;}
}
window.addEventListener?.('focus', () => void resumeNativeSignIn());
document.addEventListener?.('visibilitychange', () => {if (document.visibilityState === 'visible') void resumeNativeSignIn();});

async function refreshLibraryView() {
  if (returnPlayerVideo && currentVideo?.id===returnPlayerVideo && !$("#player").open) {$("#player").showModal();returnPlayerVideo=null;}
  const button = document.querySelector(`nav button[data-view="${currentView}"]`);
  if (currentView === "subscriptions") return showSubscriptions(button);
  if (currentView === "playlists") return currentPlaylist ? showPlaylist(currentPlaylist) : showPlaylists(button);
  if (currentView === "history") return showHistory(button);
  if (currentView === "channel" && currentChannelId) return showChannel(currentChannelId);
  if (currentView === "settings") return showSettings();
}

function beginLibrary(view, button) {
  currentView = view;
  activate(button);
  $("#page-title").removeAttribute("data-i18n");
  $("#page-title").textContent = ({subscriptions: "Subscriptions", playlists: "Playlists", history: "Watch history", settings: "Settings"})[view];
  const epoch = ++libraryEpoch;
  $("#content").setAttribute("aria-busy", "false");
  if (!productConnected()) {renderAccountRequired(); return null;}
  $("#content").innerHTML = '<p class="meta">Loading your library…</p>';
  notice("");
  return epoch;
}

function libraryFailure(error, epoch, retry) {
  if (epoch !== libraryEpoch) return;
  if (!productConnected()) return renderAccountRequired();
  empty("Your library could not load", "Your saved items remain on the service. Retry when the connection is available.");
  const button = document.createElement("button");
  button.textContent = "Retry";
  button.onclick = retry;
  $("#content .empty").append(button);
  notice(error.message, true);
}

function field(value, lower, upper) {return value?.[lower] ?? value?.[upper];}

async function openSavedVideo(videoId) {
  try {await openVideo(await api(`/v1/videos/${encodeURIComponent(videoId)}`));}
  catch {notice("This saved video is private, unavailable or no longer published.", true);}
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
}

function empty(title, detail = "Published videos will appear here.", retry = false) {
  $("#content").innerHTML = `<div class="empty"><h2>${esc(title)}</h2><p>${esc(detail)}</p>${retry ? `<button id="retry-load">${esc(t("retry"))}</button>` : ""}</div>`;
  $("#retry-load")?.addEventListener("click", () => loadVideos($("#query").value));
}

function activate(button) {
  document.querySelectorAll("nav button").forEach(x => x.classList.toggle("active", x === button));
}

function videoCard(video) {
  const article = document.createElement("article");
  article.className = "card";
  const thumb = video.thumbnail_key ? `<img class="thumb image" src="${API}/media/${encodeURI(video.thumbnail_key)}" alt="">` : '<span class="thumb thumb-fallback">Play video</span>';
  const state = video.takedown?.state ? `Takedown: ${video.takedown.state}` : `${video.status} · ${video.visibility}`;
  article.innerHTML = `<button class="card-open" aria-label="Play ${esc(video.title)}">${thumb}</button><h2>${esc(video.title)}</h2><p class="meta">${esc(state)}</p><p>${esc(video.description || "No description")}</p>`;
  article.querySelector("button").onclick = () => openVideo(video);
  return article;
}

function renderVideos(videos, title) {
  const box = $("#content");
  box.replaceChildren();
  if (!videos.length) {
    empty(title);
    return;
  }
  box.append(...videos.map(videoCard));
}

async function loadVideos(query = "") {
  const epoch = ++libraryEpoch;
  currentView = "discover";
  currentPlaylist = null;
  $("#page-title").setAttribute("data-i18n", "discover");
  $("#page-title").textContent = t("discover");
  $("#content").setAttribute("aria-busy", "true");
  try {
    const videos = await api(`/v1/videos?q=${encodeURIComponent(query)}`);
    if (epoch !== libraryEpoch) return;
    renderVideos(videos, query ? "No matching published videos" : t("empty"));
    notice("");
  } catch (error) {
    if (epoch !== libraryEpoch) return;
    empty(t("unavailable"), navigator.onLine ? t("unavailable") : t("offline"), true);
    notice(error.message, true);
  } finally {
    if (epoch === libraryEpoch) $("#content").setAttribute("aria-busy", "false");
  }
}

function renderWalletChoices(candidates) {
  const chooser = $("#wallet-chooser");
  $("#wallet-choices").replaceChildren();

  for (const candidate of candidates) {
    const walletId = candidate.info?.uuid || candidate.uuid || candidate.providerId || "";
    if (!walletId) continue;
    const item = document.createElement("button");
    item.className = "wallet-choice";
    item.type = "button";
    item.dataset.walletId = walletId;
    item.dataset.walletBrand = candidate.isYNXWallet ? "YNX Wallet" : candidate.isMetaMask ? "MetaMask" : "EIP-1193";
    item.dataset.walletRdns = candidate.info?.rdns || "";
    const icon = candidate.providerInfo?.icon || candidate.icon || candidate.info?.icon || "";
    const iconMarkup = icon ? `<img src="${icon}" alt="${esc(candidate.label)}" />` : "";
    const label = candidate.label || candidate.name || "Wallet";
    const role = candidate.isYNXWallet ? "ynx" : candidate.isMetaMask ? "metamask" : "eip1193";
    const extra = candidate.isYNXWallet ? " · YNX Wallet" : candidate.isMetaMask ? " · MetaMask" : "";
    item.setAttribute("title", `${esc(candidate.label || label)} · ${item.dataset.walletBrand}`);
    item.innerHTML = `<span class="wallet-choice-logo ${role}" aria-hidden="true">${iconMarkup}</span><span>${esc(label + extra)}</span>`;
    item.onclick = async () => {
      chooser.close();
      await connectVideoWalletInteractive(walletId);
    };
    $("#wallet-choices").append(item);
  }
  $("#wallet-chooser-close").onclick = () => chooser.close();
  chooser.showModal();
}

function walletChoiceOptions(error, autoCandidates = []) {
  const candidates = autoCandidates.length ? autoCandidates : walletCandidatesFromError(error);
  const sorted = [...candidates].sort((a,b)=>{
    const aName = String(a.label || a.name || a.walletName || a.info?.name || "");
    const bName = String(b.label || b.name || b.walletName || b.info?.name || "");
    return aName.localeCompare(bName);
  });
  renderWalletChoices(sorted);
}

async function connectVideoWalletInteractive(walletId = null) {
  try {
    $("#signin").disabled = true;
    showInstallOptions(false);
    const result = await connectVideoWallet(window, {timeoutMs: 1500, walletId});
    currentWallet = {...result, walletKind: result.walletBrand, providerKey: result.providerInfo?.uuid};
    renderWalletState(currentWallet);
    bindWalletEvents(currentWallet);
    notice("EVM wallet connected. Video sign-in is managed separately.");
  } catch (error) {
    if (walletChoiceNeedsResolution(error)) {
      walletChoiceOptions(error);
      setConnectionMessage("Select YNX Wallet or MetaMask before continuing.");
      return;
    }
    if (error?.code === "WALLET_NOT_INSTALLED") {
      showInstallOptions(true);
    }
    resetWallet(error?.code === "WALLET_USER_REJECTED" ? "Wallet approval was rejected." : error.message || "Wallet connection failed.");
    notice(error.message || "Wallet connection failed", true);
  } finally {
    $("#signin").disabled = false;
  }
}

async function restoreWalletFromSession() {
  const state = storageState.read();
  const restored = await restoreVideoWallet(state, window);
  if (!restored) return;
  currentWallet = restored;
  renderWalletState(currentWallet);
  bindWalletEvents(currentWallet);
  notice("Wallet connection restored from last session.");
}

async function revokeWallet(reason = "user") {
  resetWallet(reason === "user-requested" ? "EVM wallet disconnected from this page." : "EVM wallet connection ended.");
}

function startWatchProgress(video) {
  const previousProgress = watchProgress;
  void previousProgress?.flush(false).catch(() => {});
  const account = productState.session?.account, revision = productRevision;
  watchProgress = createWatchProgress({signedIn: () => revision === productRevision && productConnected() && productState.session?.account === account,
    onError: () => {if (revision === productRevision && currentVideo === video) notice("Watch history could not be saved. Playback remains available.", true);},
    send: (body, {idempotencyKey}) => privateAPI(`/v1/videos/${video.id}/watch`, {...json(body),
      headers: {"Content-Type": "application/json", "Idempotency-Key": idempotencyKey}})});
}

async function openVideo(video) {
  currentVideo = video;
  startWatchProgress(video);
  $("#player-title").textContent = video.title;
  $("#player-state").textContent = video.takedown ? `Unavailable: ${video.takedown.reason}` : `${video.captions?.length || 0} caption track(s) · ${video.status}`;

  const media = $("#video");
  media.replaceChildren();
  const hls = video.variants?.find(v => v.mime === "application/vnd.apple.mpegurl");
  const fallback = video.variants?.find(v => v.name === "original-fallback");
  const chosen = hls && media.canPlayType(hls.mime) ? hls : fallback || hls;
  if (chosen) media.src = `${API}/media/${chosen.object_key}`;
  else media.removeAttribute("src");

  for (const caption of video.captions || []) {
    if (!caption.human_approved) continue;
    const track = document.createElement("track");
    track.kind = "captions";
    track.label = caption.label;
    track.srclang = caption.language;
    track.src = `${API}/media/${caption.object_key}`;
    media.append(track);
  }
  $("#player").showModal();
  void loadComments();
  void refreshSubscriptionButton();
}

async function loadComments() {
  if (!currentVideo) return;
  const target = currentVideo;
  try {
    const comments = await api(`/v1/videos/${target.id}/comments`);
    if (target !== currentVideo) return;
    $("#comments").innerHTML = comments.length ? comments.map(c => `<article><b>${esc(c.Author || c.author)}</b><p>${esc(c.Body || c.body)}</p></article>`).join("") : '<p class="meta">No comments yet.</p>';
  } catch (error) {
    if (target === currentVideo) $("#comments").textContent = error.message;
  }
}

async function flushWatch(completed = false) {
  try {await watchProgress?.flush(completed);}
  catch {notice("Watch history could not be saved. Playback remains available.", true);}
}

async function showSubscriptions(button) {
  const epoch = beginLibrary("subscriptions", button);
  if (epoch === null) return;
  try {
    const channels = await privateAPI("/v1/subscriptions");
    if (epoch !== libraryEpoch) return;
    const box = $("#content"); box.replaceChildren();
    if (!channels.length) {empty("No subscriptions yet", "Subscribe from a video to keep the channel in your library."); return;}
    for (const channel of channels) {
      const id = field(channel, "id", "ID");
      const article = document.createElement("article"); article.className = "library-row";
      article.innerHTML = '<div><h2>'+esc(field(channel,"name","Name"))+'</h2><p class="meta">@'+esc(field(channel,"handle","Handle"))+'</p></div><div class="row-actions"><button class="open-channel">Open channel</button><button class="outline unsubscribe">Unsubscribe</button></div>';
      article.querySelector(".open-channel").onclick = () => showChannel(id);
      article.querySelector(".unsubscribe").onclick = async event => {
        const action = event.currentTarget;
        action.disabled = true;
        try {await privateAPI('/v1/channels/'+encodeURIComponent(id)+'/subscription', {method:"DELETE"}); await showSubscriptions(button);}
        catch (error) {action.disabled = false; notice(error.message, true);}
      };
      box.append(article);
    }
  } catch (error) {libraryFailure(error, epoch, () => showSubscriptions(button));}
}

async function refreshSubscriptionButton() {
  const target = currentVideo;
  const operation = ++subscriptionRevision;
  const button = $("#subscribe");
  button.disabled = false;
  button.textContent = "Subscribe";
  button.dataset.subscribed = "false";
  if (!target || !productConnected()) return;
  const account = productState.session.account;
  try {
    const channels = await privateAPI("/v1/subscriptions");
    if (operation !== subscriptionRevision || target !== currentVideo || productState.session?.account !== account || !productConnected()) return;
    const subscribed = channels.some(channel => field(channel,"id","ID") === target.channel_id);
    button.textContent = subscribed ? "Unsubscribe" : "Subscribe";
    button.dataset.subscribed = String(subscribed);
  } catch { /* A failed private read never blocks playback. */ }
}

async function showChannel(channelID) {
  currentChannelId=channelID;
  const epoch = ++libraryEpoch;
  currentView = "channel";
  activate(null);
  $("#content").setAttribute("aria-busy", "true");
  try {
    const view = await api(`/v1/channels/${channelID}`);
    if (epoch !== libraryEpoch) return;
    const channel = view.channel;
    $("#page-title").removeAttribute("data-i18n");
    $("#page-title").textContent = channel.Name || channel.name;
    renderVideos(view.videos || [], `@${channel.Handle || channel.handle} has no published videos`);
    notice(`${channel.Name || channel.name} · ${view.subscribers} persisted subscriber(s)`);
    if ($("#player").open) {$("#video").pause(); $("#player").close();}
  } catch (error) {
    if (epoch === libraryEpoch) notice(error.message, true);
  } finally {
    if (epoch === libraryEpoch) $("#content").setAttribute("aria-busy", "false");
  }
}

async function showPlaylists(button) {
  currentPlaylist = null;
  const epoch = beginLibrary("playlists", button);
  if (epoch === null) return;
  try {
    const lists = await privateAPI("/v1/playlists");
    if (epoch !== libraryEpoch) return;
    const box = $("#content"); box.replaceChildren();
    const scope=playlistScope(()=>{if(epoch!==libraryEpoch)throw new DOMException("Video view changed.","AbortError");});
    const form = document.createElement("form"); form.className = "library-create";
    form.innerHTML = '<label for="new-playlist-name">Create a playlist</label><div><input id="new-playlist-name" name="name" maxlength="80" required placeholder="Playlist name"><button type="submit">Create</button></div>';
    const recovery=document.createElement("section");recovery.className="playlist-recovery";
    form.onsubmit = async event => {
      event.preventDefault(); const button=form.querySelector('button[type="submit"]');button.disabled=true;
      try {scope.current();await createOriginalPlaylist(form.elements.name.value,scope);scope.current();await showPlaylists(document.querySelector('[data-view="playlists"]'));}
      catch(error){if(error.name!=="AbortError"){try{await renderPlaylistRecovery(form,recovery,scope);}catch{}notice(error.message,true);}}
      finally{if(epoch===libraryEpoch)button.disabled=false;}
    };
    const changes=document.createElement("section");changes.className="playlist-recovery playlist-operation-recovery";
    box.append(form,recovery,changes);await renderPlaylistRecovery(form,recovery,scope);await renderPlaylistOperations(changes,scope);scope.current();
    if (!lists.length) {const p = document.createElement("p"); p.className="meta"; p.textContent="No playlists yet. Create one here or save a video while watching."; box.append(p);}
    for (const list of lists) {
      const id = field(list,"id","ID"), ids = field(list,"video_ids","VideoIDs") || [];
      const article = document.createElement("article"); article.className = "library-row";
      article.innerHTML = '<div><h2>'+esc(field(list,"name","Name"))+'</h2><p class="meta">'+ids.length+' saved videos</p></div><div class="row-actions"><button class="open-list">Open playlist</button><button class="outline delete-list">Delete playlist</button></div>';
      article.querySelector(".open-list").onclick = () => showPlaylist(id);
      article.querySelector(".delete-list").onclick = async event => {
        if (!confirm('Delete this playlist? The original videos will remain available.')) return;
        const button = event.currentTarget; button.disabled = true;
        try {scope.current();await changeOriginalPlaylist("delete",id,null,scope);scope.current();await showPlaylists(document.querySelector('[data-view="playlists"]'));}
        catch(error) {if(scope.matches()){button.disabled=false;await renderPlaylistOperations(changes,scope).catch(()=>{});notice(error.message,true);}}
      };
      box.append(article);
    }
  } catch (error) {libraryFailure(error, epoch, () => showPlaylists(button));}
}

async function showPlaylist(playlistId) {
  currentPlaylist = playlistId;
  const epoch = beginLibrary("playlists", document.querySelector('[data-view="playlists"]'));
  if (epoch === null) return;
  try {
    const lists = await privateAPI("/v1/playlists");
    if (epoch !== libraryEpoch) return;
    const scope=playlistScope(()=>{if(epoch!==libraryEpoch)throw new DOMException("Video view changed.","AbortError");});
    const list = lists.find(item => field(item,"id","ID") === playlistId);
    if (!list) {currentPlaylist=null; await showPlaylists(document.querySelector('[data-view="playlists"]')); notice("This playlist was removed."); return;}
    const box = $("#content"); box.replaceChildren();
    const heading = document.createElement("div"); heading.className="library-heading";
    heading.innerHTML = '<button class="outline">All playlists</button><h2>'+esc(field(list,"name","Name"))+'</h2>';
    heading.querySelector("button").onclick=()=>showPlaylists(document.querySelector('[data-view="playlists"]'));
    box.append(heading);
    const changes=document.createElement("section");changes.className="playlist-recovery playlist-operation-recovery";box.append(changes);await renderPlaylistOperations(changes,scope);scope.current();
    const ids = field(list,"video_ids","VideoIDs") || [];
    if (!ids.length) {const p=document.createElement("p");p.className="meta";p.textContent="No videos saved here yet. Use Save to playlist while watching.";box.append(p);}
    const labelJobs = [];
    for (const id of ids) {
      const row = document.createElement("article"); row.className="library-row";
      row.innerHTML='<div><h3>Saved video</h3><p class="meta">'+esc(id)+'</p></div><div class="row-actions"><button class="play-saved">Play</button><button class="outline remove-saved">Remove from playlist</button></div>';
      row.querySelector(".play-saved").onclick=()=>openSavedVideo(id);
      row.querySelector(".remove-saved").onclick=async event=>{
        if(!confirm("Remove this item from the playlist? The original video will remain available."))return;
        const button=event.currentTarget;button.disabled=true;
        try{scope.current();await changeOriginalPlaylist("remove",playlistId,id,scope);scope.current();await showPlaylist(playlistId);}
        catch(error){if(scope.matches()){button.disabled=false;await renderPlaylistOperations(changes,scope).catch(()=>{});notice(error.message,true);}}
      };
      box.append(row);
      labelJobs.push(async()=>{
        try{const video=await api('/v1/videos/'+encodeURIComponent(id));if(epoch===libraryEpoch){row.querySelector("h3").textContent=video.title;row.querySelector(".meta").textContent="Ready to watch";}}
        catch{if(epoch===libraryEpoch){row.querySelector("h3").textContent="Video unavailable";row.querySelector(".play-saved").disabled=true;row.querySelector(".meta").textContent="The video may be private or no longer published.";}}
      });
    }
    // A large saved list must not open hundreds of requests at once.
    void Promise.all(Array.from({length:Math.min(4,labelJobs.length)},async()=>{
      while(epoch===libraryEpoch&&labelJobs.length)await labelJobs.shift()();
    }));
  } catch(error){libraryFailure(error,epoch,()=>showPlaylist(playlistId));}
}

async function showHistory(button) {
  const epoch=beginLibrary("history",button);
  if(epoch===null)return;
  try {
    const events=await privateAPI("/v1/history");
    if(epoch!==libraryEpoch)return;
    const box=$("#content");box.replaceChildren();
    if(!events.length){empty("No watch history yet","Videos you watch while signed in will appear here.");return;}
    for(const item of events){
      const id=field(item,"video_id","VideoID");
      const row=document.createElement("article");row.className="library-row";
      const date=new Date(field(item,"created_at","CreatedAt"));
      row.innerHTML='<div><h2>Watched video</h2><p>'+esc(field(item,"seconds","Seconds"))+' seconds watched</p><p class="meta">'+esc(Number.isNaN(date.getTime())?"":date.toLocaleString())+'</p></div><button>Play video</button>';
      row.querySelector("button").onclick=()=>openSavedVideo(id);
      box.append(row);
    }
  }catch(error){libraryFailure(error,epoch,()=>showHistory(button));}
}

function showSettings() {
  const epoch=beginLibrary("settings",$("#privacy"));
  if(epoch===null)return;
  $("#content").innerHTML='<section class="settings-panel"><h2>Your Video data</h2><p>Delete your watch history, subscriptions, playlists and comment text. Original videos remain available, and the service retains a minimal deletion audit record.</p><button id="delete-viewer-data" class="danger">Delete my Video data</button></section>';
  $("#delete-viewer-data").onclick=async event=>{
    if(!confirm("Delete your Video history, subscriptions, playlists and comment text? This cannot be undone. Original videos are not deleted."))return;
    const button=event.currentTarget;button.disabled=true;
    try{
      const scope=playlistScope();
      $("#video").pause();
      await flushWatch(false);scope.current();
      watchProgress?.discard();
      await privateAPI("/v1/privacy/account-data",{method:"DELETE"});scope.current();
      await playlistJournal.clear(scope.account,scope.current);await playlistOperations.clear(scope.account,scope.current);scope.current();
      if(currentVideo)startWatchProgress(currentVideo);
      currentPlaylist=null;notice("Your saved Video data was deleted.");await refreshSubscriptionButton();
    }
    catch(error){notice(error.message,true);}
    finally{button.disabled=false;}
  };
}

$("#signin").onclick = async () => {
  try {
    const candidates = await discoverWalletCandidates(window, {timeoutMs: 250});
    const ynxCount = candidates.filter(c => c.isYNXWallet).length;
    const mmCount = candidates.filter(c => c.isMetaMask).length;
    if ((ynxCount >= 1 && mmCount >= 1) || candidates.length > 1) {
      const choices = candidates.map(entry => ({
        info: entry.info,
        label: entry.label,
        isYNXWallet: entry.isYNXWallet,
        isMetaMask: entry.isMetaMask,
        icon: entry.icon,
      }));
      walletChoiceOptions(null, choices);
      return;
    }
    await connectVideoWalletInteractive();
  } catch (error) {
    if (error?.code === "WALLET_NOT_INSTALLED") showInstallOptions(true);
    resetWallet(error.message || "No provider discovered.");
  }
};

$("#revoke").onclick = () => revokeWallet("user-requested");
async function changeSiteAccount(signIn){
 if(siteAccountBusy)return;siteAccountBusy=true;
 $("#browser-signin").disabled=true;$("#browser-disconnect").disabled=true;$("#product-connect").disabled=true;
 try{const retired=await signOutVideoAccount();if(!retired||!["disconnected","expired"].includes(retired.status)||retired.revocationPending||productSignOutPending)throw Error("Confirm Video sign out before changing your YNX account.");
  browserIdentity.invalidate();if(signIn)browserIdentity.signIn("settings");else{await browserIdentity.logout();notice("Your YNX account is signed out on this site.");}
 }catch(error){notice(error.message,true);}finally{siteAccountBusy=false;$("#browser-signin").disabled=false;$("#browser-disconnect").disabled=false;$("#product-connect").disabled=productSignOutPending;}
}
$("#browser-disconnect").onclick=()=>changeSiteAccount(false);
$("#browser-signin").onclick=()=>changeSiteAccount(true);
$("#product-signin").onclick = focusSignIn;
$("#product-connect").onclick = prepareVideoSignIn;
$("#product-retry").onclick = restoreVideoAccount;
$("#product-disconnect").onclick = signOutVideoAccount;
$("#search").onsubmit = event => {event.preventDefault();currentView="discover";currentPlaylist=null;activate(document.querySelector('[data-view="discover"]'));loadVideos($("#query").value);};
$("#close").onclick = () => {$("#video").pause();$("#player").close();void flushWatch(false);};
$("#player").addEventListener("cancel",()=>{$("#video").pause();void flushWatch(false);});
$("#video").addEventListener("timeupdate",()=>{const video=$("#video");watchProgress?.sample({position:video.currentTime,paused:video.paused,seeking:video.seeking,rate:video.playbackRate});});
$("#video").addEventListener("seeking",()=>watchProgress?.resetSample());
$("#video").addEventListener("pause",()=>{watchProgress?.resetSample();void flushWatch(false);});
$("#video").addEventListener("ended",()=>void flushWatch(true));
$("#channel").onclick = () => currentVideo && showChannel(currentVideo.channel_id);
$("#subscribe").onclick = async event => {
  if(!currentVideo||!requireAccount())return;
  const button=event.currentTarget, target=currentVideo, revision=productRevision, operation=++subscriptionRevision;
  const subscribed=button.dataset.subscribed === "true";
  const current=()=>operation===subscriptionRevision && revision===productRevision && target===currentVideo && productConnected();
  button.disabled=true;
  try {
    await privateAPI('/v1/channels/'+encodeURIComponent(target.channel_id)+'/subscription',{method:subscribed?"DELETE":"PUT"});
    if (!current()) return;
    button.dataset.subscribed=String(!subscribed);
    button.textContent=subscribed?"Subscribe":"Unsubscribe";
    notice(subscribed?"Subscription removed.":"Channel added to your subscriptions.");
  }catch(error){if(current())notice(error.message,true);}
  finally{if(current())button.disabled=false;}
};
$("#playlist").onclick = async()=>{
  if(!currentVideo||!requireAccount())return;
  playlistTarget=currentVideo;const target=playlistTarget;
  const scope=playlistScope(()=>{if(playlistTarget!==target)throw new DOMException("Video playlist choice changed.","AbortError");});
  try{
    const lists=await privateAPI("/v1/playlists");scope.current();const select=$("#playlist-choice");select.replaceChildren();
    select.append(new Option("Create a new playlist", ""));
    for(const list of lists)select.append(new Option(field(list,"name","Name"),field(list,"id","ID")));
    if(lists.length)select.value=field(lists[0],"id","ID");
    const saved=await playlistJournal.read(scope.account,scope.current),changes=await playlistOperations.read(scope.account,scope.current);scope.current();
    const pending=changes.pending;if(pending){if(pending.body.action!=="add"||pending.body.videoID!==target.id)throw Error("Retry the saved playlist change in your playlists first.");select.value=pending.body.playlistID;if(select.value!==pending.body.playlistID)throw Error("Original saved playlist unavailable. Retry in your playlists.");}
    select.disabled=!!pending;
    $("#playlist-name").value=saved.pending?.body.Name??"";$("#playlist-name").disabled=!!saved.pending||!!pending;
    $("#playlist-picker-status").textContent="";$("#playlist-save").disabled=false;
    $("#playlist-picker").showModal();
  }catch(error){if(error.name!=="AbortError")notice(error.message,true);}
};
$("#playlist-picker-close").onclick=()=>{$("#playlist-picker").close();playlistTarget=null;};
$("#playlist-picker").addEventListener("cancel",()=>{playlistTarget=null;});
$("#playlist-save-form").onsubmit=async event=>{
  event.preventDefault();if(!playlistTarget||!requireAccount())return;
  const button=$("#playlist-save"),target=playlistTarget;button.disabled=true;
  const scope=playlistScope(()=>{if(playlistTarget!==target)throw new DOMException("Video playlist choice changed.","AbortError");});
  try{
    const changes=await playlistOperations.read(scope.account,scope.current);scope.current();
    if(changes.pending){if(changes.pending.body.action!=="add"||changes.pending.body.videoID!==target.id)throw Error("Retry the saved playlist change in your playlists first.");await changeOriginalPlaylist(changes.pending.body.action,changes.pending.body.playlistID,changes.pending.body.videoID,scope);scope.current();$("#playlist-picker").close();playlistTarget=null;notice("Video saved to your playlist.");return;}
    const name=$("#playlist-name").value.trim();let id=$("#playlist-choice").value;
    if(name){const created=await createOriginalPlaylist(name,scope);scope.current();id=created.ID;$("#playlist-choice").append(new Option(created.Name,id));$("#playlist-choice").value=id;$("#playlist-name").value="";$("#playlist-name").disabled=false;}
    if(!id)throw new Error("Choose a playlist or enter a new playlist name.");
    scope.current();await changeOriginalPlaylist("add",id,target.id,scope);scope.current();
    $("#playlist-picker").close();playlistTarget=null;notice("Video saved to your playlist.");
  }catch(error){if(error.name!=="AbortError"&&scope.matches()){try{const saved=await playlistJournal.read(scope.account,scope.current);scope.current();$("#playlist-name").value=saved.pending?.body.Name??$("#playlist-name").value;$("#playlist-name").disabled=!!saved.pending;}catch{}if(scope.matches())$("#playlist-picker-status").textContent=error.message;}}
  finally{if(scope.matches())button.disabled=false;}
};

$("#report").onclick = async () => {
  if (!currentVideo || !requireAccount()) return;
  const reason = prompt("Reason for human review");
  if (!reason) return;
  try {
    await privateAPI(`/v1/videos/${currentVideo.id}/reports`, json({reason, details: "Submitted from YNX Video viewer"}));
    notice("Report submitted for human review. No automatic takedown occurred.");
  } catch (error) {
    notice(error.message, true);
  }
};

$("#comment").onsubmit = async event => {
  event.preventDefault();
  if (!currentVideo || !requireAccount()) return;
  try {
    await privateAPI(`/v1/videos/${currentVideo.id}/comments`, json({body: event.target.elements[0].value}));
    event.target.reset();
    await loadComments();
    notice("Comment persisted.");
  } catch (error) {
    notice(error.message, true);
  }
};

const nav = [...document.querySelectorAll("nav button")];
nav.find(b => b.dataset.view === "discover").onclick = event => { currentView="discover";currentPlaylist=null;activate(event.currentTarget);loadVideos(); };
nav.find(b => b.dataset.view === "subscriptions").onclick = event => showSubscriptions(event.currentTarget);
nav.find(b => b.dataset.view === "playlists").onclick = event => showPlaylists(event.currentTarget);
nav.find(b => b.dataset.view === "history").onclick = event => showHistory(event.currentTarget);

$("#privacy").onclick = showSettings;

clearLegacySession();
renderProductState({status:"guest"});
resetWallet("EVM wallet not connected.");
// Guest catalog and playback start independently of translation, Auth, or provider recovery.
void i18nReady.catch(() => null);
const catalogReady = loadVideos();
const linkedVideo = new URLSearchParams(location.search).get("video");
if (linkedVideo) {
  api('/v1/videos/'+encodeURIComponent(linkedVideo)).then(openVideo).catch(async error=>{await catalogReady;notice(error.message,true);});
}
const returnedView = new URLSearchParams(location.search).get('mediaView') || location.hash.slice(1);
if (['subscriptions','playlists','history','settings','channel'].includes(returnedView)) {currentView=returnedView;activate(returnedView==='settings'?$("#privacy"):document.querySelector('nav button[data-view="'+returnedView+'"]'));}
const returnedParams=new URLSearchParams(location.search);
if (/^[A-Za-z0-9_-]{1,128}$/.test(returnedParams.get('mediaPlaylist')||''))currentPlaylist=returnedParams.get('mediaPlaylist');
if (/^[A-Za-z0-9_-]{1,128}$/.test(returnedParams.get('mediaChannel')||''))currentChannelId=returnedParams.get('mediaChannel');
void restoreVideoAccount();
videoProductSession.subscribe?.(() => {
  if (nativeReturn?.launched) {void resumeNativeSignIn(); return;}
  cancelVideoSignIn();
  renderProductState({status: "retry-required", message: "Your Video account changed in another tab. Checking your sign-in…"});
  void restoreVideoAccount();
});
window.addEventListener?.("focus", () => {if (!nativeReturn && !productChooser.open) void restoreVideoAccount();});
void restoreWalletFromSession().catch(()=>resetWallet("EVM wallet not connected."));
window.addEventListener("online",()=>{if(nativeReturn?.launched)void resumeNativeSignIn();else void restoreVideoAccount();});
window.addEventListener("offline",()=>{
  if(productState.status==="connected")renderProductState({status:"network-unavailable",message:"You are offline. Reconnect and retry sign-in to use your library."});
});
