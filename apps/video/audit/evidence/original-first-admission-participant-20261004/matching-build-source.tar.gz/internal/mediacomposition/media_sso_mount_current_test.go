//go:build ynx_canonical_media && ynx_media_combined_authority

package mediacomposition

import (
	"bytes"
	"encoding/json"
	"errors"
	"github.com/JiahaoAlbus/YNX-Chain/internal/productsessionv2"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"strings"
	"testing"
	"time"
)

type originalMediaResponseTransport func(*http.Request) (*http.Response, error)

func (f originalMediaResponseTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	return f(r)
}
func TestMediaMountedOriginalCallbackPostAwaitSourceRetirement(t *testing.T) {
	var fixture struct{ Session productsessionv2.Session }
	raw, err := os.ReadFile("../productsessionv2/testdata/finance-v2.json")
	if err != nil {
		t.Fatal(err)
	}
	if err = json.Unmarshal(raw, &fixture); err != nil {
		t.Fatal(err)
	}
	for _, retire := range []bool{false, true} {
		t.Run(map[bool]string{false: "unchanged", true: "retired"}[retire], func(t *testing.T) {
			live := true
			calls := 0
			current := func() error {
				if !live {
					return errors.New("original source retired")
				}
				return nil
			}
			response := productsessionv2.BrowserGrant{GrantToken: strings.Repeat("g", 43), Identity: productsessionv2.BrowserIdentity{Account: fixture.Session.Account, Subject: fixture.Session.Account, Generation: 2, ExpiresAt: time.Now().Add(time.Hour)}, Audience: "ynx:video:identity", Scopes: []string{"identity:read"}, ExpiresAt: time.Now().Add(time.Minute)}
			transport := originalMediaResponseTransport(func(*http.Request) (*http.Response, error) {
				calls++
				if retire {
					live = false
				}
				b, _ := json.Marshal(response)
				return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"application/json"}}, Body: io.NopCloser(bytes.NewReader(b))}, nil
			})
			// Even original unbound browser instances must gain the captured mount
			// source guard; identity fixture is not actual account/issuer approval.
			vb, err := productsessionv2.NewBrowserSSO("video", "https://wallet-auth.ynxweb4.com", make([]byte, 32), []string{"discover"}, transport)
			if err != nil {
				t.Fatal(err)
			}
			cb, err := productsessionv2.NewBrowserSSO("creator-studio", "https://wallet-auth.ynxweb4.com", make([]byte, 32), []string{"overview"}, transport)
			if err != nil {
				t.Fatal(err)
			}
			p := &PreparedVideo{browserVideo: vb, browserCreator: cb, current: current}
			h := p.WrapOriginalVideoHandler(nil)
			start := httptest.NewRecorder()
			h.ServeHTTP(start, httptest.NewRequest("GET", "https://video.ynxweb4.com/sso/start?target=discover", nil))
			loc, err := url.Parse(start.Header().Get("Location"))
			if err != nil {
				t.Fatal(err)
			}
			r := httptest.NewRequest("GET", "https://video.ynxweb4.com/sso/callback?state="+url.QueryEscape(loc.Query().Get("state"))+"&code="+strings.Repeat("c", 43), nil)
			for _, c := range start.Result().Cookies() {
				r.AddCookie(c)
			}
			out := httptest.NewRecorder()
			h.ServeHTTP(out, r)
			if calls != 1 {
				t.Fatal(calls)
			}
			if retire {
				if out.Code != 503 || out.Header().Get("Location") != "" || len(out.Result().Cookies()) != 0 {
					t.Fatal("stale mounted callback published", out.Code, out.Header())
				}
			} else {
				if out.Code != 303 || out.Header().Get("Location") != "/#discover" {
					t.Fatal("original callback semantics changed", out.Code, out.Header())
				}
			}
		})
	}
}
