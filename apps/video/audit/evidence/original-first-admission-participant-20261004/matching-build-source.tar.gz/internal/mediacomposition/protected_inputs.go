//go:build ynx_canonical_media && ynx_media_combined_authority

package mediacomposition

import (
	"context"
	"encoding/json"
	"github.com/JiahaoAlbus/YNX-Chain/internal/productsessionv2"
	"net/http"
	"reflect"
	"time"
)

// This is a readonly observation of the ORIGINAL protected account/device,
// family and membership source. It never enrolls an account or creates a grant.
// GenerationAvailable distinguishes an enrolled generation zero from missing.
type OriginalMediaActor struct {
	Account, DeviceID, DeviceBinding, DeviceKey, DeviceAlgorithm, SessionBinding, FamilyID, Product, Platform string
	BrowserGeneration                                                                                         int64
	PrivateGeneration                                                                                         uint64
	GenerationAvailable, Enrolled, Revoked                                                                    bool
	MembershipRevision                                                                                        uint64
}

// Capture reads the existing protected runtime, NOT a request/header account.
// The returned local function must synchronously read the SAME original source
// at each effect boundary, without network or reentering a product Store lock.
// No production implementation is supplied by this adapter itself.
type OriginalMediaActorObserver interface {
	CaptureOriginalMediaActor(context.Context, productsessionv2.Session, *productsessionv2.BrowserGrant) (OriginalMediaActor, func() (OriginalMediaActor, error), error)
}

func originalActorGuard(observer OriginalMediaActorObserver, current productsessionv2.OriginalSourceCurrent, ctx context.Context, session productsessionv2.Session, browser *productsessionv2.BrowserGrant) (func(context.Context) error, error) {
	if observer == nil || current == nil || ctx == nil || ctx.Err() != nil {
		return nil, ErrOriginalMediaRuntimeUnavailable
	}
	if err := current(); err != nil {
		return nil, err
	}
	// Freeze all pointer/slice aliases before any provider await. Caller mutation
	// cannot change the authoritative captured session used by the local guard.
	raw, err := json.Marshal(session)
	if err != nil {
		return nil, err
	}
	var frozen productsessionv2.Session
	if err = json.Unmarshal(raw, &frozen); err != nil {
		return nil, err
	}
	var savedBrowser *productsessionv2.BrowserGrant
	if browser != nil {
		b := *browser
		b.Scopes = append([]string(nil), browser.Scopes...)
		savedBrowser = &b
	}
	var providerSession productsessionv2.Session
	if err = json.Unmarshal(raw, &providerSession); err != nil {
		return nil, err
	}
	var providerBrowser *productsessionv2.BrowserGrant
	if savedBrowser != nil {
		b := *savedBrowser
		b.Scopes = append([]string(nil), savedBrowser.Scopes...)
		providerBrowser = &b
	}
	observed, read, err := observer.CaptureOriginalMediaActor(ctx, providerSession, providerBrowser)
	if err != nil {
		return nil, err
	}
	if err = current(); err != nil {
		return nil, err
	}
	expires, err := time.Parse(time.RFC3339Nano, frozen.ExpiresAt)
	if err != nil || read == nil || observed.Revoked || !observed.Enrolled || !observed.GenerationAvailable || observed.FamilyID == "" || observed.Account != frozen.Account || observed.DeviceID != frozen.DeviceID || observed.DeviceBinding != frozen.DeviceBinding || observed.DeviceKey != frozen.DeviceKey || observed.DeviceAlgorithm != frozen.DeviceAlgorithm || observed.SessionBinding != frozen.SessionBinding || observed.Product != frozen.ProductID || observed.Platform != frozen.Platform {
		return nil, ErrOriginalMediaRuntimeUnavailable
	}
	if savedBrowser != nil && (savedBrowser.Identity.Account != frozen.Account || savedBrowser.Identity.Generation <= 0 || observed.BrowserGeneration != savedBrowser.Identity.Generation) {
		return nil, ErrOriginalMediaRuntimeUnavailable
	}
	guard := func(c context.Context) error {
		if c == nil {
			return ErrOriginalMediaRuntimeUnavailable
		}
		if err := c.Err(); err != nil {
			return err
		}
		if err := current(); err != nil {
			return err
		}
		actual, err := read()
		if err != nil {
			return err
		}
		if !reflect.DeepEqual(actual, observed) || actual.Revoked || !expires.After(time.Now()) {
			return ErrOriginalMediaRuntimeUnavailable
		}
		if savedBrowser != nil && (!savedBrowser.ExpiresAt.After(time.Now()) || !savedBrowser.Identity.ExpiresAt.After(time.Now())) {
			return ErrOriginalMediaRuntimeUnavailable
		}
		if err := current(); err != nil {
			return err
		}
		return c.Err()
	}
	if err = guard(ctx); err != nil {
		return nil, err
	}
	return guard, nil
}

// LoadOriginalProtectedMediaInputs returns exactly the input objects consumed
// by the product-owned unexported slots. The owned main assigns them BEFORE
// prepare/NewService/New/any state read. Nil observer is refused before key I/O.
func LoadOriginalProtectedMediaInputs(ctx context.Context, config productsessionv2.MediaProtectedConfiguration, transport http.RoundTripper, registration productsessionv2.OriginalMediaRegistration, current productsessionv2.OriginalSourceCurrent, observer OriginalMediaActorObserver) (*VideoInputs, *MusicInputs, error) {
	if ctx == nil || observer == nil {
		return nil, nil, ErrOriginalMediaRuntimeUnavailable
	}
	if err := ctx.Err(); err != nil {
		return nil, nil, err
	}
	profiles, err := productsessionv2.LoadOriginalMediaProfiles(config, transport, registration, current)
	if err != nil {
		return nil, nil, err
	}
	published := false
	defer func() {
		if !published {
			profiles.DiscardUnpublished()
		}
	}()
	if err = ctx.Err(); err != nil {
		return nil, nil, err
	}
	web := func(c context.Context, r *http.Request, s productsessionv2.Session, b productsessionv2.BrowserGrant) (func(context.Context) error, error) {
		return originalActorGuard(observer, current, c, s, &b)
	}
	native := func(c context.Context, r *http.Request, s productsessionv2.Session) (func(context.Context) error, error) {
		return originalActorGuard(observer, current, c, s, nil)
	}
	videoInputs := &VideoInputs{VideoWeb: profiles.VideoWeb, CreatorWeb: profiles.CreatorWeb, VideoNative: profiles.VideoNative, CreatorNative: profiles.CreatorNative, VideoBrowser: profiles.VideoBrowser, CreatorBrowser: profiles.CreatorBrowser, BindWeb: web, BindNative: native}
	musicInputs := &MusicInputs{Registered: profiles.Music, Bind: native}
	if _, err = PrepareOriginalVideo(ctx, videoInputs); err != nil {
		return nil, nil, err
	}
	if _, err = PrepareOriginalMusic(ctx, musicInputs); err != nil {
		return nil, nil, err
	}
	published = true
	return videoInputs, musicInputs, nil
}
