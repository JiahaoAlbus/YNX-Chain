//go:build ynx_canonical_media && ynx_media_combined_authority

package mediacomposition

import (
	"context"
	"errors"
	"github.com/JiahaoAlbus/YNX-Chain/internal/productsessionv2"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

type controlledActorObservation struct {
	value   OriginalMediaActor
	read    func() (OriginalMediaActor, error)
	capture func(productsessionv2.Session, *productsessionv2.BrowserGrant)
}

func (o *controlledActorObservation) CaptureOriginalMediaActor(_ context.Context, s productsessionv2.Session, b *productsessionv2.BrowserGrant) (OriginalMediaActor, func() (OriginalMediaActor, error), error) {
	if o.capture != nil {
		o.capture(s, b)
	}
	return o.value, o.read, nil
}
func TestMediaOriginalObserverExactCapturedGenerationAndAliasBoundaries(t *testing.T) {
	s := productsessionv2.Session{Account: "verified-account", DeviceID: "verified-device", DeviceBinding: "device-binding", DeviceKey: "original-public-key", DeviceAlgorithm: "p256-sha256", SessionBinding: "original-session", ProductID: "video", Platform: "web", ExpiresAt: time.Now().Add(time.Minute).Format(time.RFC3339Nano), Scopes: []string{"video:account"}}
	b := &productsessionv2.BrowserGrant{Identity: productsessionv2.BrowserIdentity{Account: s.Account, Generation: 4, ExpiresAt: time.Now().Add(time.Minute)}, ExpiresAt: time.Now().Add(time.Minute), Scopes: []string{"identity:read"}}
	original := OriginalMediaActor{Account: s.Account, DeviceID: s.DeviceID, DeviceBinding: s.DeviceBinding, DeviceKey: s.DeviceKey, DeviceAlgorithm: s.DeviceAlgorithm, SessionBinding: s.SessionBinding, FamilyID: "original-family", Product: s.ProductID, Platform: s.Platform, BrowserGeneration: 4, GenerationAvailable: true, PrivateGeneration: 0, Enrolled: true, MembershipRevision: 1}
	// A controlled local source models observer mechanics ONLY, not enrollment.
	actual := original
	sourceLive := true
	o := &controlledActorObservation{value: original, read: func() (OriginalMediaActor, error) { return actual, nil }, capture: func(copy productsessionv2.Session, copyBrowser *productsessionv2.BrowserGrant) {
		copy.Scopes[0] = "not-original"
		copyBrowser.Scopes[0] = "not-identity"
		copyBrowser.Identity.Account = "foreign"
	}}
	current := func() error {
		if !sourceLive {
			return errors.New("source revoked")
		}
		return nil
	}
	guard, err := originalActorGuard(o, current, context.Background(), s, b)
	if err != nil {
		t.Fatal(err)
	}
	s.Scopes[0] = "caller-mutated"
	b.Identity.Account = "caller-mutated"
	b.ExpiresAt = time.Time{}
	if err = guard(context.Background()); err != nil {
		t.Fatal("provider/caller alias changed immutable authority", err)
	}
	for _, modify := range []func(*OriginalMediaActor){func(x *OriginalMediaActor) { x.PrivateGeneration++ }, func(x *OriginalMediaActor) { x.FamilyID = "other" }, func(x *OriginalMediaActor) { x.DeviceKey = "other" }, func(x *OriginalMediaActor) { x.MembershipRevision++ }, func(x *OriginalMediaActor) { x.Revoked = true }, func(x *OriginalMediaActor) { x.GenerationAvailable = false }} {
		actual = original
		modify(&actual)
		if guard(context.Background()) == nil {
			t.Fatal("changed source passed")
		}
	}
	actual = original
	sourceLive = false
	if guard(context.Background()) == nil {
		t.Fatal("revoked source passed")
	}
}
func TestMediaOriginalMissingObserverRefusesBeforeProtectedIO(t *testing.T) {
	if _, _, err := LoadOriginalProtectedMediaInputs(context.Background(), productsessionv2.MediaProtectedConfiguration{}, nil, nil, nil, nil); err == nil {
		t.Fatal("nil original observer accepted")
	}
	if _, err := originalActorGuard(nil, nil, context.Background(), productsessionv2.Session{}, nil); err == nil {
		t.Fatal("nil guard accepted")
	}
}
func TestMediaOriginalSSORoutesAndExactHostNoNativeFallback(t *testing.T) {
	vb, err := productsessionv2.NewBrowserSSO("video", "https://wallet-auth.ynxweb4.com", make([]byte, 32), []string{"discover"}, http.DefaultTransport)
	if err != nil {
		t.Fatal(err)
	}
	cb, err := productsessionv2.NewBrowserSSO("creator-studio", "https://wallet-auth.ynxweb4.com", make([]byte, 32), []string{"overview"}, http.DefaultTransport)
	if err != nil {
		t.Fatal(err)
	}
	sourceLive := true
	p := &PreparedVideo{browserVideo: vb, browserCreator: cb, current: func() error {
		if !sourceLive {
			return errors.New("source unavailable")
		}
		return nil
	}}
	fallbacks := 0
	h := p.WrapOriginalVideoHandler(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { fallbacks++; w.WriteHeader(204) }))
	cases := []struct {
		method, path, host string
		want               int
	}{{"GET", "/api/sso/account", "video.ynxweb4.com", 401}, {"POST", "/api/sso/logout", "video.ynxweb4.com", 403}, {"GET", "/sso/callback?state=x&code=y", "creator.ynxweb4.com", 400}, {"GET", "/sso/start?target=discover", "video.ynxweb4.com", 303}, {"GET", "/api/sso/account?x=1", "video.ynxweb4.com", 400}, {"POST", "/api/sso/account", "video.ynxweb4.com", 405}, {"GET", "/api/sso/account", "attacker.invalid", 403}, {"GET", "/api/sso/foreign", "video.ynxweb4.com", 404}}
	for _, c := range cases {
		r := httptest.NewRequest(c.method, "https://"+c.host+c.path, nil)
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		if w.Code != c.want {
			t.Errorf("%s %s: %d want %d", c.method, c.path, w.Code, c.want)
		}
	}
	if fallbacks != 0 {
		t.Fatal("SSO rejected request reached native/public fallback")
	}
	sourceLive = false
	r := httptest.NewRequest("GET", "https://video.ynxweb4.com/api/sso/account", nil)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	if w.Code != 503 {
		t.Fatal(w.Code)
	}
}
