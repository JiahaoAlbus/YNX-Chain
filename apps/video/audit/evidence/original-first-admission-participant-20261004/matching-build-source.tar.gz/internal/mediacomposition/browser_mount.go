//go:build ynx_canonical_media && ynx_media_combined_authority

package mediacomposition

import (
	"github.com/JiahaoAlbus/YNX-Chain/internal/productsessionv2"
	"net/http"
	"strings"
)

// WrapOriginalVideoHandler mounts the original identity-only BrowserSSO API
// before the owned video Handler. Private routes still use their original dual
// proof + current actor authority. No native fallback follows browser rejection.
func (p *PreparedVideo) WrapOriginalVideoHandler(next http.Handler) http.Handler {
	var videoBrowser, creatorBrowser *productsessionv2.BrowserSSO
	if p != nil && p.current != nil {
		videoBrowser, _ = productsessionv2.BindOriginalMediaBrowserCurrent(p.browserVideo, p.current)
		creatorBrowser, _ = productsessionv2.BindOriginalMediaBrowserCurrent(p.browserCreator, p.current)
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		path := r.URL.Path
		candidate := strings.HasPrefix(path, "/sso/") || strings.HasPrefix(path, "/api/sso/")
		if !candidate {
			if next == nil {
				http.Error(w, "Media unavailable", 503)
				return
			}
			next.ServeHTTP(w, r)
			return
		}
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("Referrer-Policy", "no-referrer")
		if p == nil || videoBrowser == nil || creatorBrowser == nil || p.AssertCurrent() != nil {
			http.Error(w, "Original Media identity unavailable", 503)
			return
		}
		if r.URL.RawPath != "" || r.URL.Fragment != "" || r.URL.ForceQuery {
			http.Error(w, "SSO route rejected", 400)
			return
		}
		var browser *productsessionv2.BrowserSSO
		switch r.Host {
		case "video.ynxweb4.com":
			browser = videoBrowser
		case "creator.ynxweb4.com":
			browser = creatorBrowser
		default:
			http.Error(w, "SSO host rejected", 403)
			return
		}
		method := http.MethodGet
		if path == "/api/sso/logout" {
			method = http.MethodPost
		}
		if r.Method != method {
			w.Header().Set("Allow", method)
			http.Error(w, "SSO method rejected", 405)
			return
		}
		if (path == "/api/sso/account" || path == "/api/sso/logout") && r.URL.RawQuery != "" {
			http.Error(w, "SSO route rejected", 400)
			return
		}
		if len(r.Header.Values("Origin")) > 1 || len(r.Header.Values("X-YNX-SSO-CSRF")) > 1 {
			http.Error(w, "SSO fields rejected", 400)
			return
		}
		switch path {
		case "/sso/start":
			browser.Start(w, r)
		case "/sso/callback":
			browser.Callback(w, r)
		case "/api/sso/account":
			browser.Account(w, r)
		case "/api/sso/logout":
			browser.Logout(w, r)
		default:
			http.NotFound(w, r)
		}
	})
}
