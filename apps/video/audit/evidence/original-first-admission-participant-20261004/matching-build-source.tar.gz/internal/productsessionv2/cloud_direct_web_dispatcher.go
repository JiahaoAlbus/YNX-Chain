package productsessionv2

import (
	"encoding/json"
	"errors"
	"net/http"
	"time"
)

// The original Cloud owner implements this on its existing Server/Service.
// It must commit the original nonce with its original durable intent/effect,
// revalidate after provider await outside the Store lock, and check the local
// original actor/member/upload/revision before persistence. An old legacy
// handler is intentionally not a consumer of this capability interface.
type CloudDirectOriginalConsumer interface {
	ServeCloudDirectOriginal(http.ResponseWriter, *http.Request, *CloudDirectWebCommand)
}

func cloudDirectHTTPFailure(w http.ResponseWriter, err error) {
	status, code := 503, "CLOUD_DIRECT_AUTHORITY_UNAVAILABLE"
	var failure *Error
	if errors.As(err, &failure) {
		status, code = failure.Status, failure.Code
	}
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(map[string]string{"error": code, "code": code})
}

// Explicit protected composition only. The completely absent pair/consumer
// remains closed; partial input is rejected before mounting anything. This
// function neither loads credentials nor starts a daemon/registers a role.
func NewCloudDirectWebDispatcher(set *RegisteredClientSet, browser *BrowserSSO, original CloudDirectOriginalConsumer) (http.Handler, error) {
	if set == nil && browser == nil && original == nil {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			cloudDirectHTTPFailure(w, fail("CLOUD_DIRECT_PRODUCER_UNAVAILABLE", 503))
		}), nil
	}
	if set == nil || browser == nil || original == nil {
		return nil, fail("CLOUD_DIRECT_COMPOSITION_PARTIAL", 503)
	}
	if err := ValidateCloudWebAuthority(set, browser); err != nil {
		return nil, err
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if _, err := ClassifyCloudDirectWebRoute(r); err != nil {
			cloudDirectHTTPFailure(w, err)
			return
		}
		command, err := PrepareCloudDirectWebCommand(set, browser, r, time.Now)
		if err != nil {
			cloudDirectHTTPFailure(w, err)
			return
		}
		if err := command.AssertLocalCurrent(); err != nil {
			cloudDirectHTTPFailure(w, err)
			return
		}
		original.ServeCloudDirectOriginal(w, r, command)
	}), nil
}
