package productsessionv2

import (
	"crypto/ed25519"
	"net/http"
	"slices"
)

// NewMailWebAuthority composes only the existing Mail Web registration.
// Operator-owned credentials are supplied in memory; this function loads no
// keys/configuration, enrolls nobody and makes no network request. The original
// gateway remains responsible for explicit consent and the 240-second ceiling.
func NewMailWebAuthority(backendKeyID string, backendKey ed25519.PrivateKey, browserSealKey []byte, transport http.RoundTripper) (*RegisteredClientSet, *BrowserSSO, error) {
	policy := Policy{ProductID: "mail", ClientID: "ynx-mail-v1", ApplicationID: "com.ynxweb4.mail.web", Platform: "web", Origin: "https://mail.ynxweb4.com", Callback: "https://mail.ynxweb4.com/wallet-auth/callback", AllowedScopes: []string{"mail:account", "mail:recover"}}
	client, err := NewClient(browserIssuer, policy, transport)
	if err != nil {
		return nil, nil, err
	}
	reader, err := NewPrivateBusinessRevalidator(client, "ynx-mail-v1-business-web-v1", backendKeyID, backendKey)
	if err != nil {
		return nil, nil, err
	}
	set, err := NewRegisteredClientSet("mail", []*Client{client}, []*Revalidator{reader})
	if err != nil {
		return nil, nil, err
	}
	browser, err := NewBrowserSSO("mail", browserIssuer, browserSealKey, []string{"overview"}, transport)
	if err != nil {
		return nil, nil, err
	}
	if err = ValidateMailWebAuthority(set, browser); err != nil {
		return nil, nil, err
	}
	return set, browser, nil
}

// ValidateMailWebAuthority prevents zero-value or cross-product pointers
// from enabling the concrete Mail dispatcher. It checks source policy,
// not live operator registration or user authority; every request still uses
// original proof verification and one combined Central decision.
func ValidateMailWebAuthority(set *RegisteredClientSet, browser *BrowserSSO) error {
	reject := func() error { return fail("MAIL_WEB_PROFILE_UNAVAILABLE", 503) }
	if set == nil || browser == nil || set.product != "mail" || len(set.clients) != 1 || len(set.readers) != 1 {
		return reject()
	}
	c, r := set.clients["web"], set.readers["web"]
	if c == nil || r == nil || r.client != c || !r.business || r.backendClientID != "ynx-mail-v1-business-web-v1" || r.keyID == "" || len(r.key) != ed25519.PrivateKeySize || c.endpoint != browserIssuer {
		return reject()
	}
	p := c.policy
	if p.ProductID != "mail" || p.ClientID != "ynx-mail-v1" || p.ApplicationID != "com.ynxweb4.mail.web" || p.Platform != "web" || p.Origin != "https://mail.ynxweb4.com" || p.Callback != p.Origin+"/wallet-auth/callback" || p.BundleID != nil || p.PackageID != nil || !slices.Equal(p.AllowedScopes, []string{"mail:account", "mail:recover"}) {
		return reject()
	}
	if browser.product != "mail" || browser.origin != p.Origin || browser.clientID != "ynx-mail-v1-sso-v1" || browser.audience != "ynx:mail:identity" || browser.authority != browserIssuer || browser.aead == nil || browser.client == nil {
		return reject()
	}
	return nil
}
