package productsessionv2

import (
	"bytes"
	"crypto/ed25519"
	"net/http"
	"testing"
)

func TestMailWebProfileExactAndNoAuthorityRequest(t *testing.T) {
	calls := 0
	transport := roundTrip(func(*http.Request) (*http.Response, error) {
		calls++
		t.Fatal("factory contacted authority")
		return nil, nil
	})
	key := ed25519.NewKeyFromSeed(bytes.Repeat([]byte{7}, 32))
	set, browser, err := NewMailWebAuthority("source-fixture", key, bytes.Repeat([]byte{8}, 32), transport)
	if err != nil {
		t.Fatal(err)
	}
	if err = ValidateMailWebAuthority(set, browser); err != nil {
		t.Fatal(err)
	}
	if calls != 0 {
		t.Fatal(calls)
	}
	for _, mutate := range []func(){func() {
		set.clients["web"].policy.AllowedScopes = append(set.clients["web"].policy.AllowedScopes, "mail:send")
	}, func() {
		set.clients["web"].policy.AllowedScopes = []string{"mail:account", "mail:recover"}
		set.readers["web"].backendClientID = "ynx-ai-v1-business-web-v1"
	}} {
		mutate()
		if ValidateMailWebAuthority(set, browser) == nil {
			t.Fatal("borrowed/widened profile")
		}
	}
}
func TestMailWebProfilePartialAndBorrowedReject(t *testing.T) {
	key := ed25519.NewKeyFromSeed(bytes.Repeat([]byte{7}, 32))
	for _, tc := range []struct {
		id   string
		key  ed25519.PrivateKey
		seal []byte
	}{{"", key, bytes.Repeat([]byte{8}, 32)}, {"source", nil, bytes.Repeat([]byte{8}, 32)}, {"source", key, nil}} {
		set, browser, err := NewMailWebAuthority(tc.id, tc.key, tc.seal, nil)
		if err == nil || set != nil || browser != nil {
			t.Fatal("partial")
		}
	}
	set, browser, err := NewCalendarWebAuthority("source", key, bytes.Repeat([]byte{8}, 32), nil)
	if err != nil {
		t.Fatal(err)
	}
	if ValidateMailWebAuthority(set, browser) == nil {
		t.Fatal("borrowed Calendar")
	}
}
func TestMailWebStartupEmptyAndPartial(t *testing.T) {
	set, browser, err := LoadMailWebAuthorityConfig(MailWebAuthorityConfig{}, nil)
	if err != nil || set != nil || browser != nil {
		t.Fatal("empty changed")
	}
	for _, c := range []MailWebAuthorityConfig{{BackendKeyID: "only"}, {BackendKeyFile: "/foreign"}, {BrowserSealFile: "/foreign"}, {BackendKeyID: " role ", BackendKeyFile: "/foreign", BrowserSealFile: "/foreign"}} {
		set, browser, err = LoadMailWebAuthorityConfig(c, nil)
		if err == nil || set != nil || browser != nil {
			t.Fatal("partial accepted")
		}
	}
}
