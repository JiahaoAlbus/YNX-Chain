package productsessionv2

import (
	"bytes"
	"context"
	"crypto/subtle"
	"encoding/json"
	"io"
	"net/http"
	"reflect"
	"regexp"
	"strings"
	"time"
)

type CloudDirectRoute struct {
	Operation, UploadID, Method, Path string
	MaxBodyBytes                      int64
}

var cloudDirectID = regexp.MustCompile(`^[A-Za-z0-9_-]{1,128}$`)

// Classify only the four original Cloud routes. A syntactically retained ID is
// not authority: the original Store must verify owner/product/state under lock.
func ClassifyCloudDirectWebRoute(r *http.Request) (CloudDirectRoute, error) {
	reject := func() (CloudDirectRoute, error) {
		return CloudDirectRoute{}, fail("CLOUD_DIRECT_ROUTE_NOT_ENABLED", 403)
	}
	if r == nil || r.URL == nil || r.URL.RawPath != "" || r.URL.RawQuery != "" || r.URL.ForceQuery {
		return reject()
	}
	const base = "/api/v1/direct-uploads"
	route := CloudDirectRoute{Method: r.Method, Path: r.URL.Path}
	if r.Method == http.MethodPost && route.Path == base {
		route.Operation = "initiate"
		route.MaxBodyBytes = 32 << 10
		return route, nil
	}
	if !strings.HasPrefix(route.Path, base+"/") {
		return reject()
	}
	parts := strings.Split(strings.TrimPrefix(route.Path, base+"/"), "/")
	if len(parts) < 1 || !cloudDirectID.MatchString(parts[0]) {
		return reject()
	}
	route.UploadID = parts[0]
	if len(parts) == 1 {
		switch r.Method {
		case http.MethodGet:
			route.Operation = "read"
			return route, nil
		case http.MethodDelete:
			route.Operation = "cancel"
			return route, nil
		}
	}
	if len(parts) == 2 && parts[1] == "complete" && r.Method == http.MethodPost {
		route.Operation = "complete"
		return route, nil
	}
	return reject()
}

// Backend-only request capability. No Session/CSRF/cookie/proof is serialized
// into client storage. Each getter detaches mutable fields from this snapshot.
type CloudDirectWebCommand struct {
	ctx       context.Context
	authority *RegisteredClientSet
	browser   *BrowserSSO
	sealed    string
	original  Session
	grant     BrowserGrant
	action    ActionAuthorization
	route     CloudDirectRoute
	wireBody  []byte
	now       func() time.Time
}

func cloneCloudDirectSession(s Session) (Session, error) {
	raw, e := json.Marshal(s)
	if e != nil {
		return Session{}, e
	}
	var out Session
	e = json.Unmarshal(raw, &out)
	return out, e
}
func checkCloudDirectContext(ctx context.Context) error {
	if ctx == nil {
		return fail("CLOUD_DIRECT_CONTEXT_REQUIRED", 503)
	}
	if e := ctx.Err(); e != nil {
		return e
	}
	if d, ok := ctx.Deadline(); ok && !time.Now().Before(d) {
		return context.DeadlineExceeded
	}
	return nil
}

// Admission retains both exact raw proofs and the existing confidential joint
// reader. This is NOT a mount or effect commit. The original engine must call
// RevalidateOriginal after await, then atomically nonce+effect with its own
// current owner/member/upload/revision guard. Missing inputs remain closed.
func PrepareCloudDirectWebCommand(set *RegisteredClientSet, browser *BrowserSSO, r *http.Request, now func() time.Time) (*CloudDirectWebCommand, error) {
	if err := ValidateCloudWebAuthority(set, browser); err != nil {
		return nil, err
	}
	if r == nil || now == nil {
		return nil, fail("CLOUD_DIRECT_INPUT_REQUIRED", 503)
	}
	route, err := ClassifyCloudDirectWebRoute(r)
	if err != nil {
		return nil, err
	}
	ctx := r.Context()
	if err = checkCloudDirectContext(ctx); err != nil {
		return nil, err
	}
	scopes := []string{"files.write"}
	original, err := set.Authorize(ctx, r, scopes)
	if err != nil {
		return nil, err
	}
	origins := r.Header.Values("Origin")
	if len(origins) == 0 && r.Method == http.MethodGet {
		sites := r.Header.Values("Sec-Fetch-Site")
		if "https://"+r.Host != original.Origin || len(sites) != 1 || sites[0] != "same-origin" {
			return nil, fail("ORIGIN_MISMATCH", 403)
		}
	} else if len(origins) != 1 || origins[0] != original.Origin {
		return nil, fail("ORIGIN_MISMATCH", 403)
	}
	headers := r.Header.Values(ActionProofHeader)
	if len(headers) != 1 {
		return nil, fail("ACTION_PROOF_REQUIRED", 401)
	}
	if r.Body == nil {
		r.Body = http.NoBody
	}
	body := r.Body
	var raw bytes.Buffer
	action, err := set.VerifyHTTPActionStream(ctx, headers[0], original, route.Method, route.Path, io.TeeReader(body, &raw), route.MaxBodyBytes, scopes, now())
	_ = body.Close()
	if err != nil {
		return nil, err
	}
	if err = checkCloudDirectContext(ctx); err != nil {
		return nil, err
	}
	r.Body = io.NopCloser(bytes.NewReader(raw.Bytes()))
	sealed, grant, err := browser.Binding(r)
	if err != nil {
		return nil, err
	}
	csrf := r.Header.Values("X-YNX-SSO-CSRF")
	if len(csrf) != 1 || grant.CSRF == "" || subtle.ConstantTimeCompare([]byte(csrf[0]), []byte(grant.CSRF)) != 1 {
		return nil, fail("CSRF_REQUIRED", 403)
	}
	retained, err := cloneCloudDirectSession(original)
	if err != nil {
		return nil, err
	}
	grantRaw, err := json.Marshal(grant)
	if err != nil {
		return nil, err
	}
	var retainedGrant BrowserGrant
	if err = json.Unmarshal(grantRaw, &retainedGrant); err != nil {
		return nil, err
	}
	currentRoute, err := ClassifyCloudDirectWebRoute(r)
	if err != nil || currentRoute != route {
		return nil, fail("CLOUD_DIRECT_REQUEST_CHANGED", 403)
	}
	command := &CloudDirectWebCommand{ctx: ctx, authority: set, browser: browser, sealed: sealed, original: retained, grant: retainedGrant, action: action, route: route, wireBody: append([]byte(nil), raw.Bytes()...), now: now}
	if _, err = command.RevalidateOriginal(); err != nil {
		return nil, err
	}
	return command, nil
}
func (c *CloudDirectWebCommand) Route() CloudDirectRoute {
	if c == nil {
		return CloudDirectRoute{}
	}
	return c.route
}

// OriginalWireBody returns only the exact bytes admitted by the action proof.
// Consumers must not re-marshal JSON or read a replaced request body.
func (c *CloudDirectWebCommand) OriginalWireBody() ([]byte, error) {
	if c == nil {
		return nil, fail("CLOUD_DIRECT_COMMAND_REQUIRED", 503)
	}
	return append([]byte(nil), c.wireBody...), nil
}
func (c *CloudDirectWebCommand) OriginalContext() context.Context {
	if c == nil {
		return nil
	}
	return c.ctx
}
func (c *CloudDirectWebCommand) OriginalSession() (Session, error) {
	if c == nil {
		return Session{}, fail("CLOUD_DIRECT_COMMAND_REQUIRED", 503)
	}
	return cloneCloudDirectSession(c.original)
}
func (c *CloudDirectWebCommand) OriginalAction() (ActionAuthorization, error) {
	if c == nil {
		return ActionAuthorization{}, fail("CLOUD_DIRECT_COMMAND_REQUIRED", 503)
	}
	raw, err := json.Marshal(c.action)
	if err != nil {
		return ActionAuthorization{}, err
	}
	var out ActionAuthorization
	err = json.Unmarshal(raw, &out)
	return out, err
}

// AssertLocalCurrent is a pure final context/finite snapshot fence. It makes no
// authority request and can run under the original Store lock. It does not
// replace RevalidateOriginal or the engine's actual actor/member/revision guard.
func (c *CloudDirectWebCommand) AssertLocalCurrent() error {
	if c == nil || c.now == nil {
		return fail("CLOUD_DIRECT_COMMAND_REQUIRED", 503)
	}
	if err := checkCloudDirectContext(c.ctx); err != nil {
		return err
	}
	now := c.now()
	end, err := time.Parse(time.RFC3339Nano, c.original.ExpiresAt)
	if err != nil || !end.After(now) || !c.action.ExpiresAt.After(now) || !c.grant.ExpiresAt.After(now) || !c.grant.Identity.ExpiresAt.After(now) {
		return fail("SESSION_EXPIRED", 401)
	}
	if c.original.Account == "" || c.grant.Identity.Account != c.original.Account || c.grant.Identity.Subject == "" || c.grant.Audience != "ynx:cloud:identity" || c.action.SessionBinding != c.original.SessionBinding || c.action.Nonce == "" {
		return fail("CLOUD_DIRECT_BINDING_CHANGED", 403)
	}
	return nil
}
func (c *CloudDirectWebCommand) RevalidateOriginal() (Session, error) {
	if c == nil || c.authority == nil || c.browser == nil || c.sealed == "" || c.now == nil {
		return Session{}, fail("CLOUD_DIRECT_COMMAND_REQUIRED", 503)
	}
	if err := c.AssertLocalCurrent(); err != nil {
		return Session{}, err
	}
	end, err := time.Parse(time.RFC3339Nano, c.original.ExpiresAt)
	if err != nil || !end.After(c.now()) || !c.action.ExpiresAt.After(c.now()) {
		return Session{}, fail("SESSION_EXPIRED", 401)
	}
	fresh, grant, err := c.authority.RevalidateBrowser(c.ctx, c.original, c.browser, c.sealed, []string{"files.write"})
	if err != nil {
		return Session{}, err
	}
	if !reflect.DeepEqual(fresh, c.original) || !reflect.DeepEqual(grant, c.grant) {
		return Session{}, fail("CLOUD_DIRECT_BINDING_CHANGED", 403)
	}
	if err := checkCloudDirectContext(c.ctx); err != nil {
		return Session{}, err
	}
	if !end.After(c.now()) || !c.action.ExpiresAt.After(c.now()) {
		return Session{}, fail("SESSION_EXPIRED", 401)
	}
	if err := c.AssertLocalCurrent(); err != nil {
		return Session{}, err
	}
	return cloneCloudDirectSession(c.original)
}
