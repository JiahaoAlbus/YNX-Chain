package productsessionv2

import "net/http"

// LoadMailWebAuthorityConfigWithCurrent captures a source fence before any
// protected carrier read, then binds the exact original registered reader set.
func LoadMailWebAuthorityConfigWithCurrent(config MailWebAuthorityConfig, transport http.RoundTripper, current OriginalSourceCurrent) (*RegisteredClientSet, *BrowserSSO, error) {
	if config.BackendKeyID == "" && config.BackendKeyFile == "" && config.BrowserSealFile == "" {
		return LoadMailWebAuthorityConfig(config, transport)
	}
	if current == nil {
		return nil, nil, fail("ORIGINAL_SOURCE_CURRENT_UNAVAILABLE", 503)
	}
	if err := current(); err != nil {
		return nil, nil, err
	}
	original, browser, err := LoadMailWebAuthorityConfig(config, transport)
	if err != nil {
		return nil, nil, err
	}
	bound, err := BindOriginalSourceCurrent(original, current)
	if err != nil {
		return nil, nil, err
	}
	return bound, browser, nil
}

// LoadCalendarWebAuthorityConfigWithCurrent captures a source fence before any
// protected carrier read, then binds the exact original registered reader set.
func LoadCalendarWebAuthorityConfigWithCurrent(config CalendarWebAuthorityConfig, transport http.RoundTripper, current OriginalSourceCurrent) (*RegisteredClientSet, *BrowserSSO, error) {
	if config.BackendKeyID == "" && config.BackendKeyFile == "" && config.BrowserSealFile == "" {
		return LoadCalendarWebAuthorityConfig(config, transport)
	}
	if current == nil {
		return nil, nil, fail("ORIGINAL_SOURCE_CURRENT_UNAVAILABLE", 503)
	}
	if err := current(); err != nil {
		return nil, nil, err
	}
	original, browser, err := LoadCalendarWebAuthorityConfig(config, transport)
	if err != nil {
		return nil, nil, err
	}
	bound, err := BindOriginalSourceCurrent(original, current)
	if err != nil {
		return nil, nil, err
	}
	return bound, browser, nil
}

// LoadExchangeWebAuthorityConfigWithCurrent captures a source fence before any
// protected carrier read, then binds the exact original registered reader set.
func LoadExchangeWebAuthorityConfigWithCurrent(config ExchangeWebAuthorityConfig, transport http.RoundTripper, current OriginalSourceCurrent) (*RegisteredClientSet, *BrowserSSO, error) {
	if config.BackendKeyID == "" && config.BackendKeyFile == "" && config.BrowserSealFile == "" {
		return LoadExchangeWebAuthorityConfig(config, transport)
	}
	if current == nil {
		return nil, nil, fail("ORIGINAL_SOURCE_CURRENT_UNAVAILABLE", 503)
	}
	if err := current(); err != nil {
		return nil, nil, err
	}
	original, browser, err := LoadExchangeWebAuthorityConfig(config, transport)
	if err != nil {
		return nil, nil, err
	}
	bound, err := BindOriginalSourceCurrent(original, current)
	if err != nil {
		return nil, nil, err
	}
	return bound, browser, nil
}

// LoadWorkspaceWebAuthorityConfigWithCurrent captures a source fence before any
// protected carrier read, then binds the exact original registered reader set.
func LoadWorkspaceWebAuthorityConfigWithCurrent(product string, config WorkspaceWebAuthorityConfig, transport http.RoundTripper, current OriginalSourceCurrent) (*RegisteredClientSet, *BrowserSSO, error) {
	if config.BackendKeyID == "" && config.BackendKeyFile == "" && config.BrowserSealFile == "" {
		return LoadWorkspaceWebAuthorityConfig(product, config, transport)
	}
	if current == nil {
		return nil, nil, fail("ORIGINAL_SOURCE_CURRENT_UNAVAILABLE", 503)
	}
	if err := current(); err != nil {
		return nil, nil, err
	}
	original, browser, err := LoadWorkspaceWebAuthorityConfig(product, config, transport)
	if err != nil {
		return nil, nil, err
	}
	bound, err := BindOriginalSourceCurrent(original, current)
	if err != nil {
		return nil, nil, err
	}
	return bound, browser, nil
}
