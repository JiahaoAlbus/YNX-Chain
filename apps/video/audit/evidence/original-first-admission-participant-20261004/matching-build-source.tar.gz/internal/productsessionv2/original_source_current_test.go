package productsessionv2

import (
	"context"
	"errors"
	"io"
	"strings"
	"testing"
)

type originalRevokingBody struct {
	reader io.Reader
	revoke func()
}

func (b *originalRevokingBody) Read(p []byte) (int, error) {
	n, err := b.reader.Read(p)
	b.revoke()
	return n, err
}

func TestOriginalSourceCurrentExactReaderSnapshotAndLateWireRead(t *testing.T) {
	c, r, session, header, body, path := registeredFixture(t, "mail-business-js-proof.json")
	original, err := NewRegisteredClientSet("mail", []*Client{c}, []*Revalidator{r})
	if err != nil {
		t.Fatal(err)
	}
	live := true
	lost := errors.New("original source revoked")
	current := func() error {
		if !live {
			return lost
		}
		return nil
	}
	bound, err := BindOriginalSourceCurrent(original, current)
	if err != nil {
		t.Fatal(err)
	}
	if bound.clients["web"] != c || bound.readers["web"] != r {
		t.Fatal("replaced original reader")
	}
	// Only the clone's immutable routing map is bound; no mutation of original.
	delete(original.clients, "web")
	if _, err = bound.VerifyHTTPAction(header, session, "POST", path, []byte(body), []string{"mail:account"}, c.clock()); err != nil {
		t.Fatal(err)
	}
	b := &originalRevokingBody{strings.NewReader(body), func() { live = false }}
	if _, err = bound.VerifyHTTPActionStream(context.Background(), header, session, "POST", path, b, int64(len(body)), []string{"mail:account"}, c.clock()); !errors.Is(err, lost) {
		t.Fatalf("late source not rejected: %v", err)
	}
	if err = bound.AssertOriginalSourceCurrent(); !errors.Is(err, lost) {
		t.Fatal(err)
	}
	if original.originalSourceCurrent != nil {
		t.Fatal("changed original set")
	}
}
func TestOriginalSourceCurrentNilAndCancelledBeforeBody(t *testing.T) {
	c, r, session, header, body, path := registeredFixture(t, "mail-business-js-proof.json")
	original, err := NewRegisteredClientSet("mail", []*Client{c}, []*Revalidator{r})
	if err != nil {
		t.Fatal(err)
	}
	if _, err = BindOriginalSourceCurrent(original, nil); err == nil {
		t.Fatal("nil producer accepted")
	}
	bound, err := BindOriginalSourceCurrent(original, func() error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	reads := 0
	b := &originalRevokingBody{strings.NewReader(body), func() { reads++ }}
	if _, err = bound.VerifyHTTPActionStream(ctx, header, session, "POST", path, b, int64(len(body)), []string{"mail:account"}, c.clock()); !errors.Is(err, context.Canceled) || reads != 0 {
		t.Fatalf("cancel ignored: %v reads=%d", err, reads)
	}
	if _, err = BindOriginalSourceCurrent(bound, func() error { return nil }); err == nil {
		t.Fatal("rebound captured source")
	}
}
func TestOriginalSourceCurrentProtectedLoadersRefuseBeforeCarrier(t *testing.T) {
	// Deliberately nonexistent paths are SOURCE inputs only: none are opened when
	// provenance is missing. No protected key/seal is created or read by this test.
	for _, product := range []string{"cloud", "docs", "calendar", "mail", "exchange"} {
		var set *RegisteredClientSet
		var browser *BrowserSSO
		var err error
		switch product {
		case "cloud", "docs":
			set, browser, err = LoadWorkspaceWebAuthorityConfigWithCurrent(product, WorkspaceWebAuthorityConfig{"registered-key", "/nonexistent/key", "/nonexistent/seal"}, nil, nil)
		case "calendar":
			set, browser, err = LoadCalendarWebAuthorityConfigWithCurrent(CalendarWebAuthorityConfig{"registered-key", "/nonexistent/key", "/nonexistent/seal"}, nil, nil)
		case "mail":
			set, browser, err = LoadMailWebAuthorityConfigWithCurrent(MailWebAuthorityConfig{"registered-key", "/nonexistent/key", "/nonexistent/seal"}, nil, nil)
		case "exchange":
			set, browser, err = LoadExchangeWebAuthorityConfigWithCurrent(ExchangeWebAuthorityConfig{"registered-key", "/nonexistent/key", "/nonexistent/seal"}, nil, nil)
		}
		if err == nil || !strings.Contains(err.Error(), "ORIGINAL_SOURCE_CURRENT_UNAVAILABLE") || set != nil || browser != nil {
			t.Fatalf("%s: %v", product, err)
		}
	}
	set, browser, err := LoadCalendarWebAuthorityConfigWithCurrent(CalendarWebAuthorityConfig{}, nil, nil)
	if err != nil || set != nil || browser != nil {
		t.Fatalf("empty public changed: %v", err)
	}
}
