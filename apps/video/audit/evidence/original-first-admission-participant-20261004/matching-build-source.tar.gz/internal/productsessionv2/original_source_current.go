package productsessionv2

import "context"

// OriginalSourceCurrent is a synchronous local custody fence supplied only by
// the original protected composition. It is not an issuer, grant, role registry,
// browser identity, or remote family revalidator. A public marker or ENV flag
// cannot implement it. Products still require their original actor/object/nonce
// checks in the same effect transaction. No production provenance producer is
// supplied by this source adapter.
type OriginalSourceCurrent func() error

// BindOriginalSourceCurrent preserves the exact original immutable clients and
// confidential readers. It snapshots their routing maps without modifying the
// original set or minting/replacing a session. Nil provenance is unavailable.
func BindOriginalSourceCurrent(original *RegisteredClientSet, current OriginalSourceCurrent) (*RegisteredClientSet, error) {
	if original == nil || current == nil || original.originalSourceCurrent != nil {
		return nil, fail("ORIGINAL_SOURCE_CURRENT_UNAVAILABLE", 503)
	}
	if err := current(); err != nil {
		return nil, err
	}
	bound := &RegisteredClientSet{product: original.product, clients: make(map[string]*Client, len(original.clients)), readers: make(map[string]*Revalidator, len(original.readers)), originalSourceCurrent: current}
	for platform, client := range original.clients {
		bound.clients[platform] = client
	}
	for platform, reader := range original.readers {
		bound.readers[platform] = reader
	}
	if err := bound.assertOriginalSourceCurrent(nil); err != nil {
		return nil, err
	}
	return bound, nil
}
func (s *RegisteredClientSet) assertOriginalSourceCurrent(ctx context.Context) error {
	if ctx != nil {
		if err := ctx.Err(); err != nil {
			return err
		}
	}
	if s == nil {
		return fail("AUTHORITY_UNAVAILABLE", 503)
	}
	if s.originalSourceCurrent != nil {
		if err := s.originalSourceCurrent(); err != nil {
			return err
		}
	}
	if ctx != nil {
		return ctx.Err()
	}
	return nil
}

// AssertOriginalSourceCurrent exposes the SAME captured fence to the original
// consumer's locked pre-effect boundary; calling it does not consume a nonce or
// authorize any action. Unbound sets cannot represent protected source custody.
func (s *RegisteredClientSet) AssertOriginalSourceCurrent() error {
	if s == nil || s.originalSourceCurrent == nil {
		return fail("ORIGINAL_SOURCE_CURRENT_UNAVAILABLE", 503)
	}
	return s.assertOriginalSourceCurrent(nil)
}

// OriginalSourceCurrentFence returns the same immutable captured local guard for
// the ORIGINAL product transaction. Unbound historical software configurations
// return nil; protected WithCurrent mains always bind before state construction.
// No caller-set field, role/authorization decision or alternate nonce store.
func (s *RegisteredClientSet) OriginalSourceCurrentFence() OriginalSourceCurrent {
	if s == nil {
		return nil
	}
	return s.originalSourceCurrent
}
