package productsessionv2

import (
	"golang.org/x/sys/unix"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

type WorkspaceWebAuthorityConfig struct{ BackendKeyID, BackendKeyFile, BrowserSealFile string }

func LoadWorkspaceWebAuthorityConfig(product string, config WorkspaceWebAuthorityConfig, transport http.RoundTripper) (*RegisteredClientSet, *BrowserSSO, error) {
	if product != "cloud" && product != "docs" {
		return nil, nil, fail("WORKSPACE_WEB_PROFILE_UNAVAILABLE", 503)
	}
	if config.BackendKeyID == "" && config.BackendKeyFile == "" && config.BrowserSealFile == "" {
		return nil, nil, nil
	}
	if config.BackendKeyID == "" || config.BackendKeyFile == "" || config.BrowserSealFile == "" || strings.TrimSpace(config.BackendKeyID) != config.BackendKeyID {
		return nil, nil, fail("WORKSPACE_PROTECTED_PROFILE_INCOMPLETE", 503)
	}
	key, err := LoadBackendEd25519PrivateKey(config.BackendKeyFile)
	if err != nil {
		return nil, nil, err
	}
	defer clear(key)
	seal, err := loadWorkspaceProtectedSeal(config.BrowserSealFile)
	if err != nil {
		return nil, nil, err
	}
	defer clear(seal)
	switch product {
	case "cloud":
		return NewCloudWebAuthority(config.BackendKeyID, key, seal, transport)
	case "docs":
		return NewDocsWebAuthority(config.BackendKeyID, key, seal, transport)
	default:
		return nil, nil, fail("WORKSPACE_WEB_PROFILE_UNAVAILABLE", 503)
	}
}
func loadWorkspaceProtectedSeal(path string) ([]byte, error) {
	reject := func() ([]byte, error) { return nil, fail("WORKSPACE_BROWSER_SEAL_UNAVAILABLE", 503) }
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return reject()
	}
	parts := strings.Split(strings.TrimPrefix(path, "/"), "/")
	if len(parts) == 0 || parts[len(parts)-1] == "" {
		return reject()
	}
	dir, e := unix.Open("/", unix.O_RDONLY|unix.O_DIRECTORY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
	if e != nil {
		return reject()
	}
	defer func() { unix.Close(dir) }()
	for _, component := range parts[:len(parts)-1] {
		if !protectedBackendDirectory(dir) {
			return reject()
		}
		next, err := unix.Openat(dir, component, unix.O_RDONLY|unix.O_DIRECTORY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
		if err != nil {
			return reject()
		}
		unix.Close(dir)
		dir = next
	}
	if !protectedBackendDirectory(dir) {
		return reject()
	}
	leaf := parts[len(parts)-1]
	fd, e := unix.Openat(dir, leaf, unix.O_RDONLY|unix.O_NOFOLLOW|unix.O_CLOEXEC|unix.O_NONBLOCK, 0)
	if e != nil {
		return reject()
	}
	file := os.NewFile(uintptr(fd), "workspace-protected-browser-seal")
	defer file.Close()
	var before, after, named unix.Stat_t
	if unix.Fstat(fd, &before) != nil || !protectedBackendKeyStat(&before) || before.Size != 32 {
		return reject()
	}
	raw, e := io.ReadAll(io.LimitReader(file, 33))
	if e != nil || len(raw) != 32 || unix.Fstat(fd, &after) != nil || unix.Fstatat(dir, leaf, &named, unix.AT_SYMLINK_NOFOLLOW) != nil || !protectedBackendKeyStat(&after) || !protectedBackendKeyStat(&named) || before.Dev != after.Dev || before.Ino != after.Ino || before.Size != after.Size || before.Dev != named.Dev || before.Ino != named.Ino || before.Size != named.Size {
		clear(raw)
		return reject()
	}
	return raw, nil
}
