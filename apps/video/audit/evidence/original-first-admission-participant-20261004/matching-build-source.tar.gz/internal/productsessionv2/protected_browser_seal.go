package productsessionv2

// LoadProtectedBrowserSeal consumes the existing exact protected binary 32-byte
// carrier contract. It does not construct a BrowserGrant or select a product.
// Protected ancestry/UID/nlink/NOFOLLOW/bounds/name-FD checks are the original
// loader implementation, shared without weakening its filesystem conditions.
func LoadProtectedBrowserSeal(path string) ([]byte, error) {
	return loadMailProtectedSeal(path)
}
