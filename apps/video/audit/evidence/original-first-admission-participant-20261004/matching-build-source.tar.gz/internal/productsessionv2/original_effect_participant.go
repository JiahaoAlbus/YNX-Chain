package productsessionv2

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"reflect"
)

// OriginalEffectOperation is a LOCAL consumer binding, not a new wire schema.
// ID comes from the original owned operation; no ID, nonce or grant is issued.
// Method/Path and Action must have been verified against the actual raw request
// by the mature original HTTP action verifier and fixed route policy.
type OriginalEffectOperation struct {
	ID, Method, Path                   string
	ActionBodyDigest, WireDigest       string
	NodeOperationID, NodeRequestDigest string
	Session                            Session
	Action                             ActionAuthorization
}
type OriginalOperationState string

const (
	OriginalOperationUnknown  OriginalOperationState = "UNKNOWN"
	OriginalOperationTerminal OriginalOperationState = "TERMINAL"
)

// Terminal is accepted only from authenticated original provider readback.
// Result is the original opaque outcome; this package invents no result schema.
type OriginalOperationRecord struct {
	Operation OriginalEffectOperation
	State     OriginalOperationState
	Result    []byte
}
type OriginalAdmission struct {
	Record        OriginalOperationRecord
	NewlyAdmitted bool
}

// OriginalNodeReservationPort is a protected ORIGINAL producer port. Admission
// MUST synchronously durably commit UNKNOWN before returning NewlyAdmitted,
// atomically deduplicate ID and reject every binding mismatch. Existing UNKNOWN
// or TERMINAL MUST return NewlyAdmitted=false; there is no redispatch/renew API.
// Same coordinator gate -> original writer/product lock is mandatory. No HTTP,
// network await, asynchronous write or recursive gate acquisition is permitted.
// No actual original Node transport/provenance implementation is supplied here.
type OriginalNodeReservationPort interface {
	AssertOriginalReservationCurrent(context.Context) error
	AdmitOriginalUnknown(context.Context, OriginalEffectOperation) (OriginalAdmission, error)
}

// The original backend must authenticate readback of EXACT persisted operation,
// not trust a caller ID/hash, session refresh, ACK or cached/unverified terminal.
// Current here is source custody, not a requirement that the old Session still
// be active. Revoked/expired old operations are read-only; never dispatched.
type AuthenticatedOriginalReadbackPort interface {
	AssertAuthenticatedOriginalReadbackCurrent(context.Context) error
	ReadAuthenticatedOriginal(context.Context, OriginalEffectOperation) (OriginalOperationRecord, error)
}

// OriginalNodeOperationMappingPort is the fixed protected original durable
// product mapper. It must READ the real original ID/session/nonce/route/body
// association, authenticate its custody, and return the original Node ID/full
// effect commitment. No algorithm or equivalence to WireDigest is implied.
// Input has no Node fields; output must retain EVERY input field exactly.
// This is not an HTTP caller-provided digest, new ID or enrollment capability.
type OriginalNodeOperationMappingPort interface {
	AssertOriginalNodeMappingCurrent(context.Context) error
	MapOriginalNodeOperation(context.Context, OriginalEffectOperation) (OriginalEffectOperation, error)
}
type OriginalNodeReservation struct {
	port   OriginalNodeReservationPort
	mapper OriginalNodeOperationMappingPort
}
type AuthenticatedOriginalReadback struct {
	port AuthenticatedOriginalReadbackPort
}
type OriginalEffectError struct {
	Code                            string
	AdmissionUnknown, EffectStarted bool
}

func (e *OriginalEffectError) Error() string { return "original effect: " + e.Code }
func originalEffectError(code string, unknown, started bool) error {
	return &OriginalEffectError{code, unknown, started}
}
func originalPortMissing(port any) bool {
	if port == nil {
		return true
	}
	v := reflect.ValueOf(port)
	switch v.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice:
		return v.IsNil()
	}
	return false
}

// Constructors are fixed protected composition seams, NOT registration or
// authenticated enrollment. Their actual ports must already be installed.
func NewOriginalNodeReservation(port OriginalNodeReservationPort, mapper OriginalNodeOperationMappingPort) (*OriginalNodeReservation, error) {
	if originalPortMissing(port) {
		return nil, originalEffectError("RESERVATION_UNAVAILABLE", false, false)
	}
	if originalPortMissing(mapper) {
		return nil, originalEffectError("NODE_MAPPING_UNAVAILABLE", false, false)
	}
	return &OriginalNodeReservation{port: port, mapper: mapper}, nil
}
func NewAuthenticatedOriginalReadback(port AuthenticatedOriginalReadbackPort) (*AuthenticatedOriginalReadback, error) {
	if originalPortMissing(port) {
		return nil, originalEffectError("READBACK_UNAVAILABLE", false, false)
	}
	return &AuthenticatedOriginalReadback{port}, nil
}
func cloneOriginalOperation(op OriginalEffectOperation) (OriginalEffectOperation, error) {
	snapshot, err := cloneMediaSnapshot(MediaAuthoritySnapshot{Session: op.Session})
	if err != nil {
		return OriginalEffectOperation{}, originalEffectError("INVALID_ORIGINAL_BINDING", false, false)
	}
	op.Session = snapshot.Session
	return op, nil
}
func cloneOriginalRecord(record OriginalOperationRecord) (OriginalOperationRecord, error) {
	op, err := cloneOriginalOperation(record.Operation)
	if err != nil {
		return OriginalOperationRecord{}, err
	}
	record.Operation = op
	record.Result = append([]byte(nil), record.Result...)
	return record, nil
}
func validOriginalWireBinding(op OriginalEffectOperation) bool {
	digest, err := hex.DecodeString(op.WireDigest)
	end, expiryErr := protocolTime(op.Session.ExpiresAt)
	return expiryErr == nil && !op.Action.ExpiresAt.After(end) && op.ID != "" && op.Method != "" && op.Path != "" && len(digest) == sha256.Size && err == nil && hex.EncodeToString(digest) == op.WireDigest && op.WireDigest == op.ActionBodyDigest && op.ActionBodyDigest == op.Action.BodyDigest && op.Action.Nonce != "" && op.Action.SessionBinding == op.Session.SessionBinding && op.Session.SessionBinding != "" && op.Session.Account != "" && !op.Action.ExpiresAt.IsZero()
}
func validOriginalNodeHash(value string) bool {
	bytes, err := hex.DecodeString(value)
	return err == nil && len(bytes) == sha256.Size && hex.EncodeToString(bytes) == value
}
func validOriginalOperation(op OriginalEffectOperation) bool {
	return validOriginalWireBinding(op) && validOriginalNodeHash(op.NodeOperationID) && validOriginalNodeHash(op.NodeRequestDigest)
}

// Resolve only through the fixed actual original mapper, under the SAME gate.
// A matching echo plus an arbitrary hash is not provenance: genuine installed
// mapper custody/durable association is an unimplemented producer obligation.
func resolveOriginalNodeOperation(ctx context.Context, coordinator *MediaAuthorityCoordinator, effect *MediaAuthorityEffect, original OriginalEffectOperation, mapper OriginalNodeOperationMappingPort) (OriginalEffectOperation, error) {
	if originalPortMissing(mapper) {
		return OriginalEffectOperation{}, originalEffectError("NODE_MAPPING_UNAVAILABLE", false, false)
	}
	local, release, err := coordinator.enter(ctx)
	if err != nil {
		return OriginalEffectOperation{}, err
	}
	defer release()
	if effect.epoch != coordinator.epoch {
		return OriginalEffectOperation{}, originalEffectError("ORIGINAL_AUTHORITY_CHANGED", false, false)
	}
	current, err := coordinator.read(local, effect.captured)
	if err != nil || !reflect.DeepEqual(current, effect.captured) {
		return OriginalEffectOperation{}, originalEffectError("ORIGINAL_AUTHORITY_CHANGED", false, false)
	}
	if mapper.AssertOriginalNodeMappingCurrent(local) != nil {
		return OriginalEffectOperation{}, originalEffectError("NODE_MAPPING_UNAVAILABLE", false, false)
	}
	if err = mediaContextCurrent(local); err != nil {
		return OriginalEffectOperation{}, err
	}
	detached, err := cloneOriginalOperation(original)
	if err != nil {
		return OriginalEffectOperation{}, err
	}
	mapped, err := mapper.MapOriginalNodeOperation(local, detached)
	if err != nil {
		return OriginalEffectOperation{}, originalEffectError("NODE_MAPPING_UNAVAILABLE", false, false)
	}
	frozen, err := cloneOriginalOperation(mapped)
	if err != nil {
		return OriginalEffectOperation{}, err
	}
	withoutNode := frozen
	withoutNode.NodeOperationID = ""
	withoutNode.NodeRequestDigest = ""
	if !reflect.DeepEqual(withoutNode, original) || !validOriginalOperation(frozen) {
		return OriginalEffectOperation{}, originalEffectError("NODE_MAPPING_MISMATCH", false, false)
	}
	if mapper.AssertOriginalNodeMappingCurrent(local) != nil {
		return OriginalEffectOperation{}, originalEffectError("NODE_MAPPING_UNAVAILABLE", false, false)
	}
	current, err = coordinator.read(local, effect.captured)
	if err != nil || !reflect.DeepEqual(current, effect.captured) {
		return OriginalEffectOperation{}, originalEffectError("ORIGINAL_AUTHORITY_CHANGED", false, false)
	}
	if err = mediaContextCurrent(effect.capturedContext); err != nil {
		return OriginalEffectOperation{}, err
	}
	if err = mediaContextCurrent(local); err != nil {
		return OriginalEffectOperation{}, err
	}
	if !original.Action.ExpiresAt.After(coordinator.now()) {
		return OriginalEffectOperation{}, originalEffectError("ORIGINAL_ACTION_EXPIRED", false, false)
	}
	return frozen, nil
}
func exactOriginalRecord(record OriginalOperationRecord, expected OriginalEffectOperation) (OriginalOperationRecord, error) {
	frozen, err := cloneOriginalRecord(record)
	if err != nil || !reflect.DeepEqual(frozen.Operation, expected) {
		return OriginalOperationRecord{}, originalEffectError("ORIGINAL_BINDING_CHANGED", true, false)
	}
	switch frozen.State {
	case OriginalOperationUnknown:
		if len(frozen.Result) != 0 {
			return OriginalOperationRecord{}, originalEffectError("UNVERIFIED_ORIGINAL_OUTCOME", true, false)
		}
	case OriginalOperationTerminal:
	default:
		return OriginalOperationRecord{}, originalEffectError("UNVERIFIED_ORIGINAL_OUTCOME", true, false)
	}
	return frozen, nil
}

type OriginalEffectParticipant struct {
	coordinator *MediaAuthorityCoordinator
	effect      *MediaAuthorityEffect
	operation   OriginalEffectOperation
	reservation *OriginalNodeReservation
	readback    *AuthenticatedOriginalReadback
}

// A participant consumes already-verified original Session/action/raw bytes.
// It does not verify signatures or introduce permissions/HTTP endpoints. The
// original route validator must bind method/path/schema BEFORE constructing it.
func NewOriginalEffectParticipant(ctx context.Context, coordinator *MediaAuthorityCoordinator, session Session, browser *BrowserGrant, action ActionAuthorization, id, method, path string, wireBody []byte, reservation *OriginalNodeReservation, readback *AuthenticatedOriginalReadback) (*OriginalEffectParticipant, error) {
	if coordinator == nil || reservation == nil || originalPortMissing(reservation.port) || readback == nil || originalPortMissing(readback.port) {
		return nil, originalEffectError("ORIGINAL_PARTICIPANT_UNAVAILABLE", false, false)
	}
	digest := sha256.Sum256(wireBody)
	op, err := cloneOriginalOperation(OriginalEffectOperation{ID: id, Method: method, Path: path, WireDigest: hex.EncodeToString(digest[:]), ActionBodyDigest: action.BodyDigest, Session: session, Action: action})
	if err != nil || !validOriginalWireBinding(op) {
		return nil, originalEffectError("INVALID_ORIGINAL_BINDING", false, false)
	}
	if !action.ExpiresAt.After(coordinator.now()) {
		return nil, originalEffectError("ORIGINAL_ACTION_EXPIRED", false, false)
	}
	effect, err := coordinator.Capture(ctx, op.Session, browser)
	if err != nil {
		return nil, err
	}
	op, err = resolveOriginalNodeOperation(ctx, coordinator, effect, op, reservation.mapper)
	if err != nil {
		return nil, err
	}
	return &OriginalEffectParticipant{coordinator, effect, op, reservation, readback}, nil
}
func (p *OriginalEffectParticipant) OriginalOperation() (OriginalEffectOperation, error) {
	if p == nil {
		return OriginalEffectOperation{}, originalEffectError("ORIGINAL_PARTICIPANT_UNAVAILABLE", false, false)
	}
	return cloneOriginalOperation(p.operation)
}

// Execute enters once, durably admits UNKNOWN, and only then permits the
// original bounded synchronous nonce+effect Store transaction. Every uncertain
// admission/effect remains UNKNOWN; callback success never fabricates TERMINAL.
// Commit MUST recheck local actor/object/member/nonce/cancellation under its own
// Store lock, persist effect/result atomically and publish via original writer.
// No retry is exposed: subsequent resolution uses Recover only.
func (p *OriginalEffectParticipant) Execute(ctx context.Context, commit func(context.Context, OriginalEffectOperation) error) (OriginalOperationRecord, error) {
	if p == nil || p.effect == nil || p.reservation == nil || originalPortMissing(p.reservation.port) || commit == nil {
		return OriginalOperationRecord{}, originalEffectError("ORIGINAL_PARTICIPANT_UNAVAILABLE", false, false)
	}
	var result OriginalOperationRecord
	admitted, started := false, false
	err := p.effect.Execute(ctx, func(local context.Context) error {
		if !p.operation.Action.ExpiresAt.After(p.coordinator.now()) {
			return originalEffectError("ORIGINAL_ACTION_EXPIRED", false, false)
		}
		port := p.reservation.port
		if originalPortMissing(p.reservation.mapper) || p.reservation.mapper.AssertOriginalNodeMappingCurrent(local) != nil {
			return originalEffectError("NODE_MAPPING_UNAVAILABLE", false, false)
		}
		if port.AssertOriginalReservationCurrent(local) != nil {
			return originalEffectError("RESERVATION_UNAVAILABLE", false, false)
		}
		if err := mediaContextCurrent(local); err != nil {
			return err
		}
		if err := mediaContextCurrent(p.effect.capturedContext); err != nil {
			return err
		}
		if !p.operation.Action.ExpiresAt.After(p.coordinator.now()) {
			return originalEffectError("ORIGINAL_ACTION_EXPIRED", false, false)
		}
		detached, err := cloneOriginalOperation(p.operation)
		if err != nil {
			return err
		}
		// Once original admission is attempted, loss of its response is UNKNOWN.
		admitted = true
		admission, err := port.AdmitOriginalUnknown(local, detached)
		if err != nil {
			return originalEffectError("ORIGINAL_ADMISSION_UNKNOWN", true, false)
		}
		result, err = exactOriginalRecord(admission.Record, p.operation)
		if err != nil {
			return err
		}
		if port.AssertOriginalReservationCurrent(local) != nil {
			return originalEffectError("ORIGINAL_ADMISSION_UNKNOWN", true, false)
		}
		if err = mediaContextCurrent(local); err != nil {
			return err
		}
		if p.reservation.mapper.AssertOriginalNodeMappingCurrent(local) != nil {
			return originalEffectError("NODE_MAPPING_UNAVAILABLE", true, false)
		}
		if !admission.NewlyAdmitted {
			// Reservation can prove existence/binding, but only the separate original
			// authenticated readback capability may return a verified terminal result.
			result.State = OriginalOperationUnknown
			result.Result = nil
			return nil
		}
		if result.State != OriginalOperationUnknown {
			return originalEffectError("INVALID_ORIGINAL_ADMISSION", true, false)
		}
		if !p.operation.Action.ExpiresAt.After(p.coordinator.now()) {
			return originalEffectError("ORIGINAL_ACTION_EXPIRED", true, false)
		}
		// Recheck actual source under SAME gate after admission and before commit.
		current, err := p.coordinator.read(local, p.effect.captured)
		if err != nil || !reflect.DeepEqual(current, p.effect.captured) {
			return originalEffectError("ORIGINAL_AUTHORITY_CHANGED", true, false)
		}
		if err = mediaContextCurrent(p.effect.capturedContext); err != nil {
			return err
		}
		if err = mediaContextCurrent(local); err != nil {
			return err
		}
		detached, err = cloneOriginalOperation(p.operation)
		if err != nil {
			return err
		}
		// Final Current and detached cloning can cross the original finite
		// boundary. Check one original clock observation again immediately
		// before commit entry; neither Node commitment nor fresh proof renews it.
		now := p.coordinator.now()
		end, expiryErr := protocolTime(p.operation.Session.ExpiresAt)
		if expiryErr != nil || !end.After(now) || !p.operation.Action.ExpiresAt.After(now) {
			return originalEffectError("ORIGINAL_ACTION_OR_SESSION_EXPIRED", true, false)
		}
		if err = mediaContextCurrent(p.effect.capturedContext); err != nil {
			return err
		}
		if err = mediaContextCurrent(local); err != nil {
			return err
		}
		started = true
		if err = commit(local, detached); err != nil {
			return originalEffectError("ORIGINAL_EFFECT_UNKNOWN", true, true)
		}
		result.State = OriginalOperationUnknown
		result.Result = nil
		return nil
	})
	if err != nil {
		// Never publish a terminal result from admission/commit alone. Conservatively
		// preserve exact original identity for read-only resolution, not redispatch.
		unknown, _ := cloneOriginalOperation(p.operation)
		result = OriginalOperationRecord{Operation: unknown, State: OriginalOperationUnknown}
		return result, originalEffectError("ORIGINAL_OPERATION_UNCONFIRMED", admitted, started)
	}
	return cloneOriginalRecord(result)
}

// Recovery is a separate immutable original-operation read-only capability.
// It can be constructed from a persisted already-admitted original binding
// without Capture/revalidating a now-expired or revoked Session. The producer
// MUST authenticate exact stored ownership/binding; this is not a new grant.
type OriginalEffectRecovery struct {
	coordinator *MediaAuthorityCoordinator
	operation   OriginalEffectOperation
	readback    *AuthenticatedOriginalReadback
}

func NewOriginalEffectRecovery(coordinator *MediaAuthorityCoordinator, original OriginalEffectOperation, readback *AuthenticatedOriginalReadback) (*OriginalEffectRecovery, error) {
	if coordinator == nil || readback == nil || originalPortMissing(readback.port) {
		return nil, originalEffectError("READBACK_UNAVAILABLE", false, false)
	}
	frozen, err := cloneOriginalOperation(original)
	if err != nil || !validOriginalOperation(frozen) {
		return nil, originalEffectError("INVALID_ORIGINAL_BINDING", false, false)
	}
	return &OriginalEffectRecovery{coordinator, frozen, readback}, nil
}
func (p *OriginalEffectParticipant) Recover(ctx context.Context) (OriginalOperationRecord, error) {
	if p == nil {
		return OriginalOperationRecord{}, originalEffectError("READBACK_UNAVAILABLE", false, false)
	}
	recovery, err := NewOriginalEffectRecovery(p.coordinator, p.operation, p.readback)
	if err != nil {
		return OriginalOperationRecord{}, err
	}
	return recovery.Read(ctx)
}
func (r *OriginalEffectRecovery) Read(ctx context.Context) (OriginalOperationRecord, error) {
	if r == nil || r.coordinator == nil || r.readback == nil || originalPortMissing(r.readback.port) {
		return OriginalOperationRecord{}, originalEffectError("READBACK_UNAVAILABLE", false, false)
	}
	local, release, err := r.coordinator.enter(ctx)
	if err != nil {
		return OriginalOperationRecord{}, err
	}
	defer release()
	port := r.readback.port
	if port.AssertAuthenticatedOriginalReadbackCurrent(local) != nil {
		return OriginalOperationRecord{}, originalEffectError("READBACK_UNAVAILABLE", false, false)
	}
	if err = mediaContextCurrent(local); err != nil {
		return OriginalOperationRecord{}, err
	}
	detached, err := cloneOriginalOperation(r.operation)
	if err != nil {
		return OriginalOperationRecord{}, err
	}
	record, err := port.ReadAuthenticatedOriginal(local, detached)
	if err != nil {
		return OriginalOperationRecord{}, originalEffectError("ORIGINAL_READBACK_UNKNOWN", true, false)
	}
	frozen, err := exactOriginalRecord(record, r.operation)
	if err != nil {
		return OriginalOperationRecord{}, err
	}
	if port.AssertAuthenticatedOriginalReadbackCurrent(local) != nil {
		return OriginalOperationRecord{}, originalEffectError("READBACK_UNAVAILABLE", true, false)
	}
	if err = mediaContextCurrent(local); err != nil {
		return OriginalOperationRecord{}, err
	}
	return frozen, nil
}
