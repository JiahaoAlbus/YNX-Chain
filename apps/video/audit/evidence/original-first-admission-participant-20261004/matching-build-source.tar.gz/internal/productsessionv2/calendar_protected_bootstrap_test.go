package productsessionv2

import (
	"bytes"
	"net/http"
	"os"
	"path/filepath"
	"testing"
)

func TestCalendarProtectedBootstrapClosedAndPartial(t *testing.T) {
	set, browser, err := LoadCalendarWebAuthorityConfig(CalendarWebAuthorityConfig{}, nil)
	if err != nil || set != nil || browser != nil {
		t.Fatal("empty startup must remain public-only")
	}
	for _, config := range []CalendarWebAuthorityConfig{{BackendKeyID: "qa"}, {BackendKeyFile: "/not-read"}, {BrowserSealFile: "/not-read"}, {BackendKeyID: " qa", BackendKeyFile: "/not-read", BrowserSealFile: "/not-read"}} {
		set, browser, err = LoadCalendarWebAuthorityConfig(config, nil)
		if err == nil || set != nil || browser != nil {
			t.Fatal("partial operator config admitted")
		}
	}
}
func TestCalendarProtectedBootstrapExactProfileNoNetwork(t *testing.T) {
	dir, key, _ := backendKeyFixture(t)
	keyPath, sealPath := filepath.Join(dir, "key.pem"), filepath.Join(dir, "seal.bin")
	if err := os.WriteFile(keyPath, key, 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(sealPath, bytes.Repeat([]byte{8}, 32), 0600); err != nil {
		t.Fatal(err)
	}
	calls := 0
	transport := roundTrip(func(*http.Request) (*http.Response, error) {
		calls++
		t.Fatal("bootstrap made network request")
		return nil, nil
	})
	set, browser, err := LoadCalendarWebAuthorityConfig(CalendarWebAuthorityConfig{"isolated-key", keyPath, sealPath}, transport)
	if err != nil {
		t.Fatal(err)
	}
	if err := ValidateCalendarWebAuthority(set, browser); err != nil {
		t.Fatal(err)
	}
	if calls != 0 {
		t.Fatal("network called")
	}
	if set.clients["web"].policy.ProductID != "calendar" {
		t.Fatal("original product changed")
	}
}
func TestCalendarProtectedSealRejectsUnsafeInput(t *testing.T) {
	for _, name := range []string{"relative", "missing", "symlink", "hardlink", "mode", "zero", "oversize", "ancestor-writable"} {
		t.Run(name, func(t *testing.T) {
			dir, _, _ := backendKeyFixture(t)
			path := filepath.Join(dir, "seal.bin")
			if err := os.WriteFile(path, bytes.Repeat([]byte{9}, 32), 0600); err != nil {
				t.Fatal(err)
			}
			switch name {
			case "relative":
				path = "seal.bin"
			case "missing":
				path = filepath.Join(dir, "absent")
			case "symlink":
				alias := filepath.Join(dir, "alias")
				if err := os.Symlink(path, alias); err != nil {
					t.Fatal(err)
				}
				path = alias
			case "hardlink":
				if err := os.Link(path, filepath.Join(dir, "alias")); err != nil {
					t.Fatal(err)
				}
			case "mode":
				if err := os.Chmod(path, 0644); err != nil {
					t.Fatal(err)
				}
			case "zero":
				if err := os.WriteFile(path, nil, 0600); err != nil {
					t.Fatal(err)
				}
			case "oversize":
				if err := os.WriteFile(path, bytes.Repeat([]byte{9}, 33), 0600); err != nil {
					t.Fatal(err)
				}
			case "ancestor-writable":
				if err := os.Chmod(dir, 0777); err != nil {
					t.Fatal(err)
				}
			}
			raw, err := loadCalendarProtectedSeal(path)
			if err == nil || raw != nil {
				t.Fatal("unsafe seal accepted")
			}
		})
	}
}
