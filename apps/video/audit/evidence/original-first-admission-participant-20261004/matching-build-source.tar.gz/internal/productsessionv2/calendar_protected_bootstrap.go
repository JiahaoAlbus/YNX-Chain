package productsessionv2

import (
	"golang.org/x/sys/unix"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

// Configuration is operator-owned startup input, never HTTP JSON or proof.
// Files refer only to already-existing protected credentials. This function
// generates/registers/enrolls nothing and has no default guessed filesystem path.
type CalendarWebAuthorityConfig struct{ BackendKeyID, BackendKeyFile, BrowserSealFile string }

func LoadCalendarWebAuthorityConfig(config CalendarWebAuthorityConfig, transport http.RoundTripper) (*RegisteredClientSet, *BrowserSSO, error) {
	if config.BackendKeyID == "" && config.BackendKeyFile == "" && config.BrowserSealFile == "" {
		return nil, nil, nil
	}
	if config.BackendKeyID == "" || config.BackendKeyFile == "" || config.BrowserSealFile == "" || strings.TrimSpace(config.BackendKeyID) != config.BackendKeyID {
		return nil, nil, fail("CALENDAR_PROTECTED_PROFILE_INCOMPLETE", 503)
	}
	key, e := LoadBackendEd25519PrivateKey(config.BackendKeyFile)
	if e != nil {
		return nil, nil, e
	}
	defer clear(key)
	seal, e := loadCalendarProtectedSeal(config.BrowserSealFile)
	if e != nil {
		return nil, nil, e
	}
	defer clear(seal)
	// Fixed mature Calendar factory preserves existing issuer, both tuples,
	// backend role,240s boundary and scopes. No caller policy/authority override.
	return NewCalendarWebAuthority(config.BackendKeyID, key, seal, transport)
}
func loadCalendarProtectedSeal(path string) ([]byte, error) {
	reject := func() ([]byte, error) { return nil, fail("CALENDAR_BROWSER_SEAL_UNAVAILABLE", 503) }
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return reject()
	}
	parts := strings.Split(strings.TrimPrefix(path, "/"), "/")
	if len(parts) == 0 || parts[len(parts)-1] == "" {
		return reject()
	}
	dir, e := unix.Open("/", unix.O_RDONLY|unix.O_DIRECTORY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
	if e != nil {
		return reject()
	}
	defer func() { unix.Close(dir) }()
	for _, component := range parts[:len(parts)-1] {
		if !protectedBackendDirectory(dir) {
			return reject()
		}
		next, err := unix.Openat(dir, component, unix.O_RDONLY|unix.O_DIRECTORY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
		if err != nil {
			return reject()
		}
		unix.Close(dir)
		dir = next
	}
	if !protectedBackendDirectory(dir) {
		return reject()
	}
	leaf := parts[len(parts)-1]
	fd, e := unix.Openat(dir, leaf, unix.O_RDONLY|unix.O_NOFOLLOW|unix.O_CLOEXEC|unix.O_NONBLOCK, 0)
	if e != nil {
		return reject()
	}
	file := os.NewFile(uintptr(fd), "calendar-protected-browser-seal")
	defer file.Close()
	var before, after, named unix.Stat_t
	if unix.Fstat(fd, &before) != nil || !protectedBackendKeyStat(&before) || before.Size != 32 {
		return reject()
	}
	raw, e := io.ReadAll(io.LimitReader(file, 33))
	if e != nil || len(raw) != 32 || unix.Fstat(fd, &after) != nil || unix.Fstatat(dir, leaf, &named, unix.AT_SYMLINK_NOFOLLOW) != nil || !protectedBackendKeyStat(&after) || !protectedBackendKeyStat(&named) || before.Dev != after.Dev || before.Ino != after.Ino || before.Size != after.Size || before.Dev != named.Dev || before.Ino != named.Ino || before.Size != named.Size {
		clear(raw)
		return reject()
	}
	return raw, nil
}
