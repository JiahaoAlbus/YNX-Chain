package productsessionv2

import (
	"crypto/ed25519"
	"net/http"
	"slices"
)

// NewCloudWebAuthority composes only the existing Cloud Web registration.
// Operator-owned credentials are supplied in memory; this function loads no
// keys/configuration, enrolls nobody and makes no network request. The original
// gateway remains responsible for explicit consent and the 240-second ceiling.
func NewCloudWebAuthority(backendKeyID string, backendKey ed25519.PrivateKey, browserSealKey []byte, transport http.RoundTripper) (*RegisteredClientSet, *BrowserSSO, error) {
	policy := Policy{ProductID: "cloud", ClientID: "ynx-cloud-web-v1", ApplicationID: "com.ynxweb4.cloud.web", Platform: "web", Origin: "https://web4.ynxweb4.com", Callback: "https://web4.ynxweb4.com/wallet-auth/callback", AllowedScopes: []string{"files.read", "files.write"}}
	client, err := NewClient(browserIssuer, policy, transport)
	if err != nil {
		return nil, nil, err
	}
	reader, err := NewPrivateBusinessRevalidator(client, "ynx-cloud-web-v1-business-web-v1", backendKeyID, backendKey)
	if err != nil {
		return nil, nil, err
	}
	set, err := NewRegisteredClientSet("cloud", []*Client{client}, []*Revalidator{reader})
	if err != nil {
		return nil, nil, err
	}
	browser, err := NewBrowserSSO("cloud", browserIssuer, browserSealKey, []string{"overview"}, transport)
	if err != nil {
		return nil, nil, err
	}
	if err = ValidateCloudWebAuthority(set, browser); err != nil {
		return nil, nil, err
	}
	return set, browser, nil
}

// ValidateCloudWebAuthority prevents zero-value or cross-product pointers
// from enabling the concrete Cloud dispatcher. It checks source policy,
// not live operator registration or user authority; every request still uses
// original proof verification and one combined Central decision.
func ValidateCloudWebAuthority(set *RegisteredClientSet, browser *BrowserSSO) error {
	reject := func() error { return fail("CLOUD_WEB_PROFILE_UNAVAILABLE", 503) }
	if set == nil || browser == nil || set.product != "cloud" || len(set.clients) != 1 || len(set.readers) != 1 {
		return reject()
	}
	c, r := set.clients["web"], set.readers["web"]
	if c == nil || r == nil || r.client != c || !r.business || r.backendClientID != "ynx-cloud-web-v1-business-web-v1" || r.keyID == "" || len(r.key) != ed25519.PrivateKeySize || c.endpoint != browserIssuer {
		return reject()
	}
	p := c.policy
	if p.ProductID != "cloud" || p.ClientID != "ynx-cloud-web-v1" || p.ApplicationID != "com.ynxweb4.cloud.web" || p.Platform != "web" || p.Origin != "https://web4.ynxweb4.com" || p.Callback != p.Origin+"/wallet-auth/callback" || p.BundleID != nil || p.PackageID != nil || !slices.Equal(p.AllowedScopes, []string{"files.read", "files.write"}) {
		return reject()
	}
	if browser.product != "cloud" || browser.origin != p.Origin || browser.clientID != "ynx-cloud-web-v1-sso-v1" || browser.audience != "ynx:cloud:identity" || browser.authority != browserIssuer || browser.aead == nil || browser.client == nil {
		return reject()
	}
	return nil
}
