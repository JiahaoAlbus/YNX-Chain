package productsessionv2

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"
)

// Real original handlers + controlled original HTTP response, not real issuer.
func TestMediaSSOOriginalSourceRetiredDuringNetworkRefusesPublication(t *testing.T) {
	for _, operation := range []string{"callback", "account", "logout"} {
		t.Run(operation, func(t *testing.T) {
			live := true
			current := func() error {
				if !live {
					return errors.New("original source retired")
				}
				return nil
			}
			account := fixture(t).Session.Account
			grant := BrowserGrant{GrantToken: strings.Repeat("g", 43), Identity: BrowserIdentity{account, account, 2, time.Now().Add(time.Hour)}, Audience: "ynx:video:identity", Scopes: []string{"identity:read"}, ExpiresAt: time.Now().Add(time.Minute), CSRF: strings.Repeat("c", 43)}
			calls := 0
			transport := roundTrip(func(r *http.Request) (*http.Response, error) {
				calls++
				live = false
				var body any = grant
				if operation == "logout" {
					body = map[string]bool{"revoked": true}
				}
				raw, _ := json.Marshal(body)
				return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"application/json"}}, Body: io.NopCloser(bytes.NewReader(raw))}, nil
			})
			s, err := NewMediaBrowserSSO("video", browserIssuer, make([]byte, 32), []string{"discover"}, transport, current)
			if err != nil {
				t.Fatal(err)
			}
			var r *http.Request
			if operation == "callback" {
				start := httptest.NewRecorder()
				s.Start(start, httptest.NewRequest("GET", s.origin+"/sso/start?target=discover", nil))
				loc, _ := url.Parse(start.Header().Get("Location"))
				r = httptest.NewRequest("GET", s.origin+"/sso/callback?state="+url.QueryEscape(loc.Query().Get("state"))+"&code="+strings.Repeat("x", 43), nil)
				for _, c := range start.Result().Cookies() {
					r.AddCookie(c)
				}
			} else {
				method := "GET"
				path := "/api/sso/account"
				if operation == "logout" {
					method = "POST"
					path = "/api/sso/logout"
				}
				r = httptest.NewRequest(method, s.origin+path, nil)
				encoded, err := s.seal(s.identityCookie, grant)
				if err != nil {
					t.Fatal(err)
				}
				r.AddCookie(&http.Cookie{Name: s.identityCookie, Value: encoded})
				r.Header.Set("Origin", s.origin)
				r.Header.Set("X-YNX-SSO-CSRF", grant.CSRF)
			}
			w := httptest.NewRecorder()
			switch operation {
			case "callback":
				s.Callback(w, r)
			case "account":
				s.Account(w, r)
			case "logout":
				s.Logout(w, r)
			}
			if calls != 1 || w.Code != 503 || w.Header().Get("Location") != "" {
				t.Fatal(calls, w.Code, w.Header())
			}
			for _, c := range w.Result().Cookies() {
				if c.Name == s.identityCookie || c.Name == s.identityCookie+"-signedout" {
					t.Fatal("stale source published identity completion cookie", c.Name)
				}
			}
			if strings.Contains(w.Body.String(), "signedIn") || strings.Contains(w.Body.String(), `"revoked":true`) {
				t.Fatal("stale source released success")
			}
		})
	}
}
func TestMediaSSOMissingCapturedSourceRefusedBeforeProtectedConstruction(t *testing.T) {
	if _, err := NewMediaBrowserSSO("video", browserIssuer, make([]byte, 32), []string{"discover"}, nil, nil); err == nil {
		t.Fatal("missing original source accepted")
	}
}
