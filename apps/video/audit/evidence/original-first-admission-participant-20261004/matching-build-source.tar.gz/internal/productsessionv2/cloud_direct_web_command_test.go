package productsessionv2

import (
	"context"
	"net/http"
	"net/http/httptest"
	"net/url"
	"testing"
	"time"
)

func TestCloudDirectWebRoutesKeepOriginalWritePermissionContract(t *testing.T) {
	cases := []struct {
		method, path, operation, id string
		limit                       int64
	}{
		{"POST", "/api/v1/direct-uploads", "initiate", "", 32 << 10},
		{"GET", "/api/v1/direct-uploads/direct_original", "read", "direct_original", 0},
		{"POST", "/api/v1/direct-uploads/direct_original/complete", "complete", "direct_original", 0},
		{"DELETE", "/api/v1/direct-uploads/retained-original-id", "cancel", "retained-original-id", 0},
	}
	for _, v := range cases {
		r := &http.Request{Method: v.method, URL: &url.URL{Path: v.path}}
		route, err := ClassifyCloudDirectWebRoute(r)
		if err != nil || route.Operation != v.operation || route.UploadID != v.id || route.MaxBodyBytes != v.limit {
			t.Fatalf("original route changed: %+v err=%v", route, err)
		}
	}
	for _, v := range []struct{ method, path string }{
		{"GET", "/api/v1/direct-uploads"}, {"PUT", "/api/v1/direct-uploads/direct_original"}, {"DELETE", "/api/v1/direct-uploads/direct_original/complete"},
		{"POST", "/api/v1/direct-uploads/direct_original/renew"}, {"POST", "/api/v1/direct-uploads/"}, {"GET", "/api/v1/direct-uploads/../x"},
		{"GET", "/api/v1/direct-uploads/direct_original/extra"}, {"GET", "/api/v1/direct-uploads/direct+original"}, {"POST", "/api/direct-uploads"},
	} {
		if _, err := ClassifyCloudDirectWebRoute(&http.Request{Method: v.method, URL: &url.URL{Path: v.path}}); err == nil {
			t.Fatalf("unsupported original route admitted: %v", v)
		}
	}
	for _, u := range []*url.URL{{Path: "/api/v1/direct-uploads/direct_original", RawPath: "/api/v1/direct-uploads/%64irect_original"}, {Path: "/api/v1/direct-uploads/direct_original", RawQuery: "x=1"}, {Path: "/api/v1/direct-uploads/direct_original", ForceQuery: true}} {
		if _, err := ClassifyCloudDirectWebRoute(&http.Request{Method: "GET", URL: u}); err == nil {
			t.Fatal("wire alias/query accepted")
		}
	}
}
func TestCloudDirectWebCommandClosedInputsDoNotDispatch(t *testing.T) {
	r := &http.Request{Method: "POST", URL: &url.URL{Path: "/api/v1/direct-uploads"}}
	if _, err := PrepareCloudDirectWebCommand(nil, nil, r, time.Now); err == nil {
		t.Fatal("absent protected profile admitted")
	}
	if _, err := (*CloudDirectWebCommand)(nil).RevalidateOriginal(); err == nil {
		t.Fatal("absent command admitted")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := checkCloudDirectContext(ctx); err == nil {
		t.Fatal("cancelled original context admitted")
	}
}
func TestCloudDirectOriginalSnapshotIsDetached(t *testing.T) {
	bundle := "original"
	scope := []string{"files.write"}
	command := &CloudDirectWebCommand{original: Session{Account: "original-owner", BundleID: &bundle, Scopes: scope}, action: ActionAuthorization{Nonce: "original-nonce"}, wireBody: []byte(`{"name":"original"}`)}
	body, err := command.OriginalWireBody()
	if err != nil {
		t.Fatal(err)
	}
	body[0] = 'x'
	retainedBody, _ := command.OriginalWireBody()
	if string(retainedBody) != `{"name":"original"}` {
		t.Fatal("caller changed admitted wire body")
	}
	a, err := command.OriginalSession()
	if err != nil {
		t.Fatal(err)
	}
	a.Scopes[0] = "forged"
	*a.BundleID = "forged"
	a.Account = "forged"
	again, err := command.OriginalSession()
	if err != nil || again.Account != "original-owner" || again.Scopes[0] != "files.write" || *again.BundleID != "original" {
		t.Fatal("caller alias changed snapshot")
	}
	action, err := command.OriginalAction()
	if err != nil {
		t.Fatal(err)
	}
	action.Nonce = "forged"
	againAction, _ := command.OriginalAction()
	if againAction.Nonce != "original-nonce" {
		t.Fatal("caller action changed snapshot")
	}
}

func TestCloudDirectFinalLocalFenceKeepsFiniteOriginalBinding(t *testing.T) {
	now := time.Now()
	end := now.Add(time.Minute)
	command := &CloudDirectWebCommand{ctx: context.Background(), now: func() time.Time { return now }, original: Session{Account: "original", SessionBinding: "original-binding", ExpiresAt: end.Format(time.RFC3339Nano)}, action: ActionAuthorization{SessionBinding: "original-binding", Nonce: "original", ExpiresAt: end}, grant: BrowserGrant{Audience: "ynx:cloud:identity", ExpiresAt: end, Identity: BrowserIdentity{Account: "original", Subject: "original", ExpiresAt: end}}}
	if err := command.AssertLocalCurrent(); err != nil {
		t.Fatal(err)
	}
	command.grant.Identity.Account = "foreign"
	if err := command.AssertLocalCurrent(); err == nil {
		t.Fatal("foreign browser/private actor admitted")
	}
	command.grant.Identity.Account = "original"
	now = end
	if err := command.AssertLocalCurrent(); err == nil {
		t.Fatal("expiry during original store boundary admitted")
	}
}

func TestCloudDirectActualDispatcherAbsentAndPartialStayClosed(t *testing.T) {
	h, err := NewCloudDirectWebDispatcher(nil, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest("POST", "https://web4.ynxweb4.com/api/v1/direct-uploads", nil)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, req)
	if w.Code != 503 {
		t.Fatal("default closed dispatcher did not refuse")
	}
	if _, err := NewCloudDirectWebDispatcher(&RegisteredClientSet{}, nil, nil); err == nil {
		t.Fatal("partial protected composition accepted")
	}
	if _, err := NewCloudDirectWebDispatcher(nil, &BrowserSSO{}, nil); err == nil {
		t.Fatal("cookie identity alone accepted")
	}
}
