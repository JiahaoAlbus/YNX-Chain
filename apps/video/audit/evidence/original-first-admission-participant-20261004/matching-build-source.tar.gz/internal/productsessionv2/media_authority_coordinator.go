package productsessionv2

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"reflect"
	"sync/atomic"
	"time"
)

// MediaCoordinationError distinguishes an unavailable source from an effect
// whose callback was entered. EffectStarted never implies rollback or success.
type MediaCoordinationError struct {
	Code          string
	EffectStarted bool
}

func (e *MediaCoordinationError) Error() string { return "media coordination: " + e.Code }
func mediaCoordinationError(code string, started bool) error {
	return &MediaCoordinationError{code, started}
}

// Metadata is read from the original writer, NEVER assigned by this component.
// Zero is a valid observed generation only when GenerationAvailable is true.
type MediaAuthoritySnapshot struct {
	Session                                Session
	Browser                                *BrowserGrant
	FamilyID                               string
	PrivateGeneration                      uint64
	GenerationAvailable, Enrolled, Revoked bool
	MembershipAvailable                    bool
	MembershipRevision                     uint64
}

// MediaOriginalAuthoritySource is a local synchronous original-writer port.
// Implementations must publish actual durable enrollment/membership facts and
// route ALL authority/member mutations through the registered Writer lease.
// Read must not use HTTP, await asynchronous work, or acquire a product lock.
// This interface supplies no production writer/provenance implementation.
type MediaOriginalAuthoritySource interface {
	AssertOriginalMediaSourceCurrent(context.Context) error
	ReadOriginalMediaAuthority(context.Context, Session, *BrowserGrant) (MediaAuthoritySnapshot, error)
}

type mediaCoordinationContext struct{ coordinator *MediaAuthorityCoordinator }
type MediaAuthorityCoordinator struct {
	gate    chan struct{}
	source  MediaOriginalAuthoritySource
	epoch   uint64
	retired bool
	now     func() time.Time
}
type MediaAuthorityWriter struct{ coordinator *MediaAuthorityCoordinator }
type MediaAuthorityEffect struct {
	coordinator     *MediaAuthorityCoordinator
	captured        MediaAuthoritySnapshot
	epoch           uint64
	used            atomic.Bool
	capturedContext context.Context
}

// Construction leaves the mechanism unavailable. RegisterOriginalWriter is a
// protected composition seam, not enrollment, a signature verifier or a grant.
func NewMediaAuthorityCoordinator(now func() time.Time) *MediaAuthorityCoordinator {
	if now == nil {
		now = time.Now
	}
	c := &MediaAuthorityCoordinator{gate: make(chan struct{}, 1), now: now}
	c.gate <- struct{}{}
	return c
}
func (c *MediaAuthorityCoordinator) enter(ctx context.Context) (context.Context, func(), error) {
	if c == nil || ctx == nil {
		return nil, nil, mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	if prior, _ := ctx.Value(mediaCoordinationContext{c}).(bool); prior {
		return nil, nil, mediaCoordinationError("REENTRANT_TRANSACTION", false)
	}
	if err := mediaContextCurrent(ctx); err != nil {
		return nil, nil, err
	}
	select {
	case <-ctx.Done():
		return nil, nil, mediaCoordinationError("CANCELLED", false)
	case <-c.gate:
	}
	release := func() { c.gate <- struct{}{} }
	if err := mediaContextCurrent(ctx); err != nil {
		release()
		return nil, nil, err
	}
	return context.WithValue(ctx, mediaCoordinationContext{c}, true), release, nil
}
func mediaContextCurrent(ctx context.Context) error {
	if ctx == nil || ctx.Err() != nil {
		return mediaCoordinationError("CANCELLED", false)
	}
	if d, ok := ctx.Deadline(); ok && !time.Now().Before(d) {
		return mediaCoordinationError("CANCELLED", false)
	}
	return nil
}
func (c *MediaAuthorityCoordinator) RegisterOriginalWriter(ctx context.Context, source MediaOriginalAuthoritySource) (*MediaAuthorityWriter, error) {
	local, release, err := c.enter(ctx)
	if err != nil {
		return nil, err
	}
	defer release()
	if c.retired {
		return nil, mediaCoordinationError("RETIRED", false)
	}
	missingSource := source == nil
	if !missingSource {
		value := reflect.ValueOf(source)
		switch value.Kind() {
		case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice:
			missingSource = value.IsNil()
		}
	}
	if missingSource {
		return nil, mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	if c.source != nil {
		return nil, mediaCoordinationError("WRITER_ALREADY_REGISTERED", false)
	}
	if err := source.AssertOriginalMediaSourceCurrent(local); err != nil {
		return nil, mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	if err := mediaContextCurrent(local); err != nil {
		return nil, err
	}
	c.source = source
	return &MediaAuthorityWriter{c}, nil
}
func cloneMediaSnapshot(value MediaAuthoritySnapshot) (MediaAuthoritySnapshot, error) {
	raw, err := json.Marshal(value)
	if err != nil {
		return MediaAuthoritySnapshot{}, err
	}
	var copy MediaAuthoritySnapshot
	err = json.Unmarshal(raw, &copy)
	return copy, err
}
func (c *MediaAuthorityCoordinator) read(ctx context.Context, expected MediaAuthoritySnapshot) (MediaAuthoritySnapshot, error) {
	if c.retired {
		return MediaAuthoritySnapshot{}, mediaCoordinationError("RETIRED", false)
	}
	if c.source == nil {
		return MediaAuthoritySnapshot{}, mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	if c.source.AssertOriginalMediaSourceCurrent(ctx) != nil {
		return MediaAuthoritySnapshot{}, mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	provider, err := cloneMediaSnapshot(expected)
	if err != nil {
		return MediaAuthoritySnapshot{}, mediaCoordinationError("INVALID_BINDING", false)
	}
	actual, err := c.source.ReadOriginalMediaAuthority(ctx, provider.Session, provider.Browser)
	if err != nil {
		return MediaAuthoritySnapshot{}, mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	frozen, err := cloneMediaSnapshot(actual)
	if err != nil || !reflect.DeepEqual(frozen.Session, expected.Session) || !reflect.DeepEqual(frozen.Browser, expected.Browser) {
		return MediaAuthoritySnapshot{}, mediaCoordinationError("BINDING_CHANGED", false)
	}
	if !frozen.GenerationAvailable || !frozen.MembershipAvailable || !frozen.Enrolled || frozen.FamilyID == "" {
		return MediaAuthoritySnapshot{}, mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	if frozen.Revoked {
		return MediaAuthoritySnapshot{}, mediaCoordinationError("REVOKED", false)
	}
	if err := validMediaCapturedSession(frozen.Session, c.now()); err != nil {
		return MediaAuthoritySnapshot{}, err
	}
	if frozen.Browser != nil {
		b := frozen.Browser
		if b.Identity.Account != frozen.Session.Account || b.Identity.Subject != frozen.Session.Account || b.Identity.Generation <= 0 || !b.ExpiresAt.After(c.now()) || !b.Identity.ExpiresAt.After(c.now()) {
			return MediaAuthoritySnapshot{}, mediaCoordinationError("INVALID_BROWSER_BINDING", false)
		}
	}
	if c.source.AssertOriginalMediaSourceCurrent(ctx) != nil {
		return MediaAuthoritySnapshot{}, mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	if err := mediaContextCurrent(ctx); err != nil {
		return MediaAuthoritySnapshot{}, err
	}
	return frozen, nil
}
func validMediaCapturedSession(s Session, now time.Time) error {
	issued, e1 := protocolTime(s.IssuedAt)
	expires, e2 := protocolTime(s.ExpiresAt)
	if s.Version != "2" || s.ChainID != "ynx_6423-1" || s.Account == "" || s.SessionBinding == "" || s.DeviceID == "" || s.DeviceAlgorithm != "p256-sha256" || s.DeviceKey == "" || !validScopes(s.Scopes) || !validFiniteConsent(s) || e1 != nil || e2 != nil || issued.After(now) || !expires.After(now) {
		return mediaCoordinationError("INVALID_OR_EXPIRED_SESSION", false)
	}
	body := map[string]any{"chainId": s.ChainID, "productId": s.ProductID, "clientId": s.ClientID, "platform": s.Platform, "applicationId": s.ApplicationID, "bundleId": s.BundleID, "packageId": s.PackageID, "origin": s.Origin, "callback": s.Callback, "account": s.Account, "deviceId": s.DeviceID, "deviceAlgorithm": s.DeviceAlgorithm, "deviceKey": s.DeviceKey}
	raw, err := canonical(body)
	if err != nil {
		return mediaCoordinationError("INVALID_BINDING", false)
	}
	digest := sha256.Sum256(append([]byte("YNX_PRODUCT_SESSION_DEVICE_V2\n"), raw...))
	if hex.EncodeToString(digest[:]) != s.DeviceBinding {
		return mediaCoordinationError("INVALID_DEVICE_BINDING", false)
	}
	return nil
}

// Capture requires an already approved full Session from the mature reader.
// It does not run Authorize/introspection, replay a nonce, or verify issuance.
func (c *MediaAuthorityCoordinator) Capture(ctx context.Context, approved Session, browser *BrowserGrant) (*MediaAuthorityEffect, error) {
	original, err := cloneMediaSnapshot(MediaAuthoritySnapshot{Session: approved, Browser: browser})
	if err != nil {
		return nil, mediaCoordinationError("INVALID_BINDING", false)
	}
	local, release, err := c.enter(ctx)
	if err != nil {
		return nil, err
	}
	defer release()
	snapshot, err := c.read(local, original)
	if err != nil {
		return nil, err
	}
	return &MediaAuthorityEffect{coordinator: c, captured: snapshot, epoch: c.epoch, capturedContext: ctx}, nil
}

// Mutate is held by the ORIGINAL writer only. It must synchronously commit and
// read back original durable state, including revoke/generation/member changes.
// The epoch invalidates captures before entering the writer; failure/uncertainty
// retires this mechanism. No memory mutation is promoted to durable enrollment.
func (w *MediaAuthorityWriter) Mutate(ctx context.Context, commit func(context.Context) error) (err error) {
	if w == nil || w.coordinator == nil {
		return mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	c := w.coordinator
	local, release, err := c.enter(ctx)
	if err != nil {
		return err
	}
	defer release()
	if c.retired {
		return mediaCoordinationError("RETIRED", false)
	}
	if commit == nil {
		return mediaCoordinationError("INVALID_MUTATION", false)
	}
	if c.source.AssertOriginalMediaSourceCurrent(local) != nil {
		return mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	// Current is a synchronous source callback: it can observe cancellation or
	// consume the remaining deadline. Do not invalidate captures or enter the
	// original writer commit when that transaction is already cancelled.
	if err := mediaContextCurrent(local); err != nil {
		return err
	}
	if c.epoch == ^uint64(0) {
		c.retired = true
		return mediaCoordinationError("RETIRED", false)
	}
	c.epoch++
	completed := false
	defer func() {
		if !completed {
			c.retired = true
		}
	}()
	if err = commit(local); err != nil {
		return mediaCoordinationError("WRITER_COMMIT_UNCERTAIN", false)
	}
	if c.source.AssertOriginalMediaSourceCurrent(local) != nil || mediaContextCurrent(local) != nil {
		return mediaCoordinationError("WRITER_COMMIT_UNCERTAIN", false)
	}
	completed = true
	return nil
}
func (w *MediaAuthorityWriter) Retire(ctx context.Context) error {
	if w == nil || w.coordinator == nil {
		return mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	local, release, err := w.coordinator.enter(ctx)
	if err != nil {
		return err
	}
	defer release()
	_ = local
	w.coordinator.retired = true
	return nil
}

// Execute linearizes the local effect with registered Mutate/Retire. Authority
// gate -> product transaction lock is the sole order. Callback must be bounded,
// synchronous and make no network calls or coordinator reentry. A callback
// error/cancellation after entry may follow a committed effect: never retry it
// automatically. Actual durable effect/nonce atomicity belongs to the product.
func (e *MediaAuthorityEffect) Execute(ctx context.Context, effect func(context.Context) error) (err error) {
	if e == nil || e.coordinator == nil {
		return mediaCoordinationError("SOURCE_UNAVAILABLE", false)
	}
	c := e.coordinator
	if err := mediaContextCurrent(e.capturedContext); err != nil {
		return err
	}
	local, release, err := c.enter(ctx)
	if err != nil {
		return err
	}
	defer release()
	if c.retired {
		return mediaCoordinationError("RETIRED", false)
	}
	if e.epoch != c.epoch {
		return mediaCoordinationError("AUTHORITY_CHANGED", false)
	}
	if effect == nil {
		return mediaCoordinationError("INVALID_EFFECT", false)
	}
	if e.used.Load() {
		return mediaCoordinationError("EFFECT_ALREADY_USED", false)
	}
	current, err := c.read(local, e.captured)
	if err != nil {
		return err
	}
	if !reflect.DeepEqual(current, e.captured) {
		return mediaCoordinationError("AUTHORITY_CHANGED", false)
	}
	if err := mediaContextCurrent(local); err != nil {
		return err
	}
	if err := mediaContextCurrent(e.capturedContext); err != nil {
		return err
	}
	e.used.Store(true)
	complete := false
	defer func() {
		if !complete {
			c.retired = true
		}
	}()
	callbackErr := effect(local)
	after, afterErr := c.read(local, e.captured)
	if afterErr != nil || mediaContextCurrent(e.capturedContext) != nil || !reflect.DeepEqual(after, e.captured) {
		return mediaCoordinationError("EFFECT_OUTCOME_UNCONFIRMED", true)
	}
	complete = true
	if callbackErr != nil {
		return mediaCoordinationError("EFFECT_OUTCOME_UNCONFIRMED", true)
	}
	return nil
}
