package productsessionv2

import (
	"crypto/ed25519"
	"net/http"
	"slices"
	"strings"
)

// These tuples come from the original Wallet registry. This constructor does
// not install any backend public key or admit additional scopes/platforms.
type MediaCredentialReference struct{ Product, Platform, KeyID, KeyFile string }
type MediaBrowserSealReference struct{ Product, SealFile string }
type MediaProtectedConfiguration struct {
	Readers  []MediaCredentialReference
	Browsers []MediaBrowserSealReference
}
type MediaRegisteredProfiles struct {
	VideoWeb, CreatorWeb, VideoNative, CreatorNative, Music *RegisteredClientSet
	VideoBrowser, CreatorBrowser                            *BrowserSSO
}

// Registration must be checked by the protected original runtime, against the
// actual installed same-role public key. A software registry ceiling is not it.
type OriginalMediaRegistration interface {
	AssertCurrent() error
	AssertRegisteredMediaReader(product, platform, role, keyID string, publicKey ed25519.PublicKey) error
}

func mediaPolicy(product, platform string) (Policy, error) {
	var p Policy
	var app, callback string
	switch product {
	case "video":
		p = Policy{ProductID: product, ClientID: "ynx-video-mobile-v1", AllowedScopes: []string{"video:account", "video:library", "video:playback"}}
		app = "com.ynxweb4.video"
		callback = "ynxvideo://wallet-auth/callback"
	case "creator-studio":
		p = Policy{ProductID: product, ClientID: "ynx-creator-studio-web-v1", AllowedScopes: []string{"creator:account", "creator:publish", "creator:revenue"}}
		app = "com.ynxweb4.creator-studio"
		callback = "ynxcreator://wallet-auth/callback"
	case "music":
		p = Policy{ProductID: product, ClientID: "ynx-music-v1", AllowedScopes: []string{"music.creator", "music.library", "music.playback", "music.profile"}}
		app = "com.ynxweb4.music"
		callback = "ynxmusic://auth/callback"
	default:
		return p, fail("MEDIA_ORIGINAL_PROFILE_UNAVAILABLE", 503)
	}
	if !slices.Contains([]string{"web", "android", "ios", "macos", "linux", "windows"}, platform) || product == "music" && !slices.Contains([]string{"android", "ios", "macos"}, platform) {
		return Policy{}, fail("MEDIA_ORIGINAL_PLATFORM_UNAVAILABLE", 503)
	}
	p.Platform = platform
	p.ApplicationID = app
	p.Callback = callback
	p.Origin = "app://" + platform + "/" + app
	if platform == "web" {
		p.ApplicationID += ".web"
		host := product
		if product == "creator-studio" {
			host = "creator"
		}
		p.Origin = "https://" + host + ".ynxweb4.com"
		p.Callback = p.Origin + "/wallet-auth/callback"
	} else if slices.Contains([]string{"ios", "macos"}, platform) {
		p.BundleID = &app
	} else {
		p.PackageID = &app
	}
	return p, nil
}

// LoadOriginalMediaProfiles uses only already-existing protected references.
// Empty/partial configurations are unavailable, not enabled public defaults.
// No secret body is returned or logged. Registration/source checks precede I/O
// and surround each acquisition; startup happens before product state opens.
func LoadOriginalMediaProfiles(config MediaProtectedConfiguration, transport http.RoundTripper, registration OriginalMediaRegistration, current OriginalSourceCurrent) (*MediaRegisteredProfiles, error) {
	reject := func() (*MediaRegisteredProfiles, error) { return nil, fail("MEDIA_PROTECTED_INPUTS_UNAVAILABLE", 503) }
	if registration == nil || current == nil || (len(config.Readers) < 5 || len(config.Readers) > 15) || len(config.Browsers) != 2 {
		return reject()
	}
	check := func() error {
		if err := current(); err != nil {
			return err
		}
		if err := registration.AssertCurrent(); err != nil {
			return err
		}
		return current()
	}
	if err := check(); err != nil {
		return nil, err
	}
	// Original registry platform ceiling; actual configured native subsets require
	// matching live registration and at least one reader in each original set.
	expected := map[string]bool{}
	for _, prod := range []string{"video", "creator-studio"} {
		for _, platform := range []string{"web", "android", "ios", "macos", "linux", "windows"} {
			expected[prod+"/"+platform] = true
		}
	}
	for _, platform := range []string{"android", "ios", "macos"} {
		expected["music/"+platform] = true
	}
	seen := map[string]bool{}
	groups := map[string][]*Client{}
	readers := map[string][]*Revalidator{}
	// Prevalidate ALL references before opening a credential. Unknown/duplicate
	// tuples cannot leave a partially acquired private reader in a returned graph.
	for _, ref := range config.Readers {
		slot := ref.Product + "/" + ref.Platform
		if !expected[slot] || seen[slot] || ref.KeyID == "" || strings.TrimSpace(ref.KeyID) != ref.KeyID || ref.KeyFile == "" {
			return reject()
		}
		seen[slot] = true
	}
	for _, product := range []string{"video", "creator-studio"} {
		if !seen[product+"/web"] {
			return reject()
		}
		nativeFound := false
		for _, platform := range []string{"android", "ios", "macos", "linux", "windows"} {
			nativeFound = nativeFound || seen[product+"/"+platform]
		}
		if !nativeFound {
			return reject()
		}
	}
	if !seen["music/android"] && !seen["music/ios"] && !seen["music/macos"] {
		return reject()
	}
	browserSeen := map[string]bool{}
	for _, ref := range config.Browsers {
		if (ref.Product != "video" && ref.Product != "creator-studio") || ref.SealFile == "" || browserSeen[ref.Product] {
			return reject()
		}
		browserSeen[ref.Product] = true
	}
	// Roll back only newly allocated in-memory reader copies on construction error;
	// never remove or rewrite original key files or caller credentials.
	complete := false
	var acquired []*Revalidator
	defer func() {
		if !complete {
			for _, reader := range acquired {
				clear(reader.key)
			}
		}
	}()
	for _, ref := range config.Readers {
		if err := check(); err != nil {
			return nil, err
		}
		p, err := mediaPolicy(ref.Product, ref.Platform)
		if err != nil {
			return nil, err
		}
		key, err := LoadBackendEd25519PrivateKey(ref.KeyFile)
		if err != nil {
			return nil, err
		}
		role := p.ClientID + "-business-" + p.Platform + "-v1"
		if p.Platform == "web" {
			role = p.ClientID + "-sso-v1"
		}
		public := append(ed25519.PublicKey(nil), key.Public().(ed25519.PublicKey)...)
		err = registration.AssertRegisteredMediaReader(ref.Product, ref.Platform, role, ref.KeyID, public)
		clear(public)
		if err == nil {
			err = check()
		}
		if err != nil {
			clear(key)
			return nil, err
		}
		c, err := NewClient(browserIssuer, p, transport)
		if err != nil {
			clear(key)
			return nil, err
		}
		var reader *Revalidator
		if p.Platform == "web" {
			reader, err = NewBusinessRevalidator(c, role, ref.KeyID, key)
		} else {
			reader, err = NewPrivateBusinessRevalidator(c, role, ref.KeyID, key)
		}
		clear(key)
		if err != nil {
			return nil, err
		}
		acquired = append(acquired, reader)
		group := ref.Product + "/native"
		if ref.Platform == "web" {
			group = ref.Product + "/web"
		}
		groups[group] = append(groups[group], c)
		readers[group] = append(readers[group], reader)
	}
	build := func(product, group string) (*RegisteredClientSet, error) {
		set, err := NewRegisteredClientSet(product, groups[group], readers[group])
		if err != nil {
			return nil, err
		}
		return BindOriginalSourceCurrent(set, check)
	}
	var result MediaRegisteredProfiles
	var err error
	if result.VideoWeb, err = build("video", "video/web"); err != nil {
		return nil, err
	}
	if result.CreatorWeb, err = build("creator-studio", "creator-studio/web"); err != nil {
		return nil, err
	}
	if result.VideoNative, err = build("video", "video/native"); err != nil {
		return nil, err
	}
	if result.CreatorNative, err = build("creator-studio", "creator-studio/native"); err != nil {
		return nil, err
	}
	if result.Music, err = build("music", "music/native"); err != nil {
		return nil, err
	}
	for _, ref := range config.Browsers {
		if err = check(); err != nil {
			return nil, err
		}
		seal, e := loadCalendarProtectedSeal(ref.SealFile)
		if e != nil {
			return nil, e
		}
		targets := []string{"discover", "subscriptions", "playlists", "history", "settings", "channel"}
		if ref.Product == "creator-studio" {
			targets = []string{"overview", "channel", "team", "rights", "content", "upload", "assets", "earn", "moderation", "disputes", "ai"}
		}
		browser, e := NewMediaBrowserSSO(ref.Product, browserIssuer, seal, targets, transport, check)
		clear(seal)
		if e != nil {
			return nil, e
		}
		if ref.Product == "video" {
			result.VideoBrowser = browser
		} else {
			result.CreatorBrowser = browser
		}
	}
	if err = check(); err != nil {
		return nil, err
	}
	complete = true
	return &result, nil
}

// DiscardUnpublished clears only this freshly constructed graph's confidential
// reader copies after failed composition. Never call on an adopted live graph.
func (p *MediaRegisteredProfiles) DiscardUnpublished() {
	if p == nil {
		return
	}
	for _, set := range []*RegisteredClientSet{p.VideoWeb, p.CreatorWeb, p.VideoNative, p.CreatorNative, p.Music} {
		if set != nil {
			for _, r := range set.readers {
				clear(r.key)
			}
		}
	}
}
