package productsessionv2

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"reflect"
	"strings"
	"testing"
	"time"
)

// COORDINATION MODEL ONLY: no durable Node reservation, proof authentication,
// actual enrollment, OS key, HTTP transport or production actor is supplied.
type originalParticipantModel struct {
	stored                        *OriginalOperationRecord
	admissionCalls, readCalls     int
	admissionCurrent, readCurrent func(context.Context) error
	admitHook                     func(context.Context)
	readHook                      func(context.Context)
	corrupt                       func(*OriginalOperationRecord)
	unavailable                   bool
	admissionFailure              bool
	mappingCorrupt                func(*OriginalEffectOperation)
	mappingUnavailable            bool
	mappingHook                   func(context.Context)
}

func (m *originalParticipantModel) AssertOriginalReservationCurrent(ctx context.Context) error {
	if m.unavailable {
		return errors.New("model unavailable")
	}
	if m.admissionCurrent != nil {
		return m.admissionCurrent(ctx)
	}
	return nil
}
func (m *originalParticipantModel) AssertAuthenticatedOriginalReadbackCurrent(ctx context.Context) error {
	if m.unavailable {
		return errors.New("model unavailable")
	}
	if m.readCurrent != nil {
		return m.readCurrent(ctx)
	}
	return nil
}
func (m *originalParticipantModel) AdmitOriginalUnknown(ctx context.Context, op OriginalEffectOperation) (OriginalAdmission, error) {
	m.admissionCalls++
	if m.admitHook != nil {
		m.admitHook(ctx)
	}
	if m.stored != nil {
		if !reflect.DeepEqual(m.stored.Operation, op) {
			return OriginalAdmission{}, errors.New("model collision")
		}
		record, _ := cloneOriginalRecord(*m.stored)
		return OriginalAdmission{Record: record}, nil
	}
	record, _ := cloneOriginalRecord(OriginalOperationRecord{Operation: op, State: OriginalOperationUnknown})
	m.stored = &record // Model ordering only, NOT a durable admission claim.
	if m.admissionFailure {
		return OriginalAdmission{}, errors.New("model admission response lost")
	}
	out, _ := cloneOriginalRecord(record)
	if m.corrupt != nil {
		m.corrupt(&out)
	}
	return OriginalAdmission{Record: out, NewlyAdmitted: true}, nil
}
func (m *originalParticipantModel) ReadAuthenticatedOriginal(ctx context.Context, op OriginalEffectOperation) (OriginalOperationRecord, error) {
	m.readCalls++
	if m.readHook != nil {
		m.readHook(ctx)
	}
	if m.stored == nil || !reflect.DeepEqual(m.stored.Operation, op) {
		return OriginalOperationRecord{}, errors.New("model missing or foreign original")
	}
	record, _ := cloneOriginalRecord(*m.stored)
	if m.corrupt != nil {
		m.corrupt(&record)
	}
	return record, nil
}
func originalParticipant(t *testing.T) (*OriginalEffectParticipant, *originalParticipantModel, *mediaCoordinatorModel, *MediaAuthorityWriter) {
	t.Helper()
	c, writer, authority, s := mediaModel(t)
	m := &originalParticipantModel{}
	reservation, err := NewOriginalNodeReservation(m, m)
	if err != nil {
		t.Fatal(err)
	}
	readback, err := NewAuthenticatedOriginalReadback(m)
	if err != nil {
		t.Fatal(err)
	}
	raw := []byte("{ \"original\": true }\n")
	digest := sha256.Sum256(raw)
	action := ActionAuthorization{Nonce: "model-original-nonce", BodyDigest: hex.EncodeToString(digest[:]), SessionBinding: s.SessionBinding, ExpiresAt: c.now().Add(time.Minute)}
	p, err := NewOriginalEffectParticipant(context.Background(), c, s, nil, action, "model-original-id", "POST", "/model-original-route", raw, reservation, readback)
	if err != nil {
		t.Fatal(err)
	}
	return p, m, authority, writer
}
func originalFailure(t *testing.T, err error, code string, admitted, started bool) {
	t.Helper()
	var e *OriginalEffectError
	if !errors.As(err, &e) || e.Code != code || e.AdmissionUnknown != admitted || e.EffectStarted != started {
		t.Fatalf("got %v expected %s admission=%v effect=%v", err, code, admitted, started)
	}
}
func TestOriginalEffectParticipantMissingPortsClosed(t *testing.T) {
	var absent *originalParticipantModel
	if _, err := NewOriginalNodeReservation(absent, absent); err == nil {
		t.Fatal("nil reservation accepted")
	}
	if _, err := NewAuthenticatedOriginalReadback(absent); err == nil {
		t.Fatal("nil readback accepted")
	}
	p, _, _, _ := originalParticipant(t)
	if _, err := NewOriginalEffectParticipant(context.Background(), p.coordinator, p.operation.Session, nil, p.operation.Action, p.operation.ID, p.operation.Method, p.operation.Path, nil, nil, p.readback); err == nil {
		t.Fatal("missing source accepted")
	}
}
func TestOriginalEffectParticipantExactRawBindingAndAliases(t *testing.T) {
	p, _, _, _ := originalParticipant(t)
	op, _ := p.OriginalOperation()
	op.Session.Scopes[0] = "alias"
	again, _ := p.OriginalOperation()
	if again.Session.Scopes[0] == "alias" {
		t.Fatal("getter leaked alias")
	}
	_, err := NewOriginalEffectParticipant(context.Background(), p.coordinator, p.operation.Session, nil, p.operation.Action, p.operation.ID, p.operation.Method, p.operation.Path, []byte("different wire"), p.reservation, p.readback)
	originalFailure(t, err, "INVALID_ORIGINAL_BINDING", false, false)
}
func TestOriginalEffectParticipantAdmissionBeforeEffectNoReplay(t *testing.T) {
	p, m, _, _ := originalParticipant(t)
	calls := 0
	record, err := p.Execute(context.Background(), func(ctx context.Context, op OriginalEffectOperation) error {
		calls++
		if m.stored == nil || m.stored.State != OriginalOperationUnknown || !reflect.DeepEqual(m.stored.Operation, op) {
			t.Fatal("effect before exact UNKNOWN admission")
		}
		op.Session.Scopes[0] = "commit alias"
		return nil
	})
	if err != nil || record.State != OriginalOperationUnknown || calls != 1 {
		t.Fatalf("%+v %v calls%d", record, err, calls)
	}
	_, err = p.Execute(context.Background(), func(context.Context, OriginalEffectOperation) error { calls++; return nil })
	if err == nil || calls != 1 || m.admissionCalls != 1 {
		t.Fatal("redispatch")
	}
	m.stored.State = OriginalOperationTerminal
	m.stored.Result = []byte("original outcome")
	terminal, err := p.Recover(context.Background())
	if err != nil || terminal.State != OriginalOperationTerminal {
		t.Fatalf("%+v %v", terminal, err)
	}
	terminal.Result[0] = 'X'
	if m.stored.Result[0] == 'X' {
		t.Fatal("terminal result alias")
	}
}
func TestOriginalEffectParticipantExistingUnknownNeverDispatches(t *testing.T) {
	p, m, _, _ := originalParticipant(t)
	original, _ := p.OriginalOperation()
	m.stored = &OriginalOperationRecord{Operation: original, State: OriginalOperationUnknown}
	record, err := p.Execute(context.Background(), func(context.Context, OriginalEffectOperation) error {
		t.Fatal("existing unknown redispatched")
		return nil
	})
	if err != nil || record.State != OriginalOperationUnknown {
		t.Fatalf("%+v %v", record, err)
	}
	m.stored.State = OriginalOperationTerminal
	m.stored.Result = []byte("terminal")
	recovered, err := p.Recover(context.Background())
	if err != nil || recovered.State != OriginalOperationTerminal {
		t.Fatal(err)
	}
}
func TestOriginalEffectParticipantAdmissionCancelAndCurrentFences(t *testing.T) {
	for _, kind := range []string{"cancel-current", "expired-current", "cancel-admission", "authority-changed", "source-lost"} {
		t.Run(kind, func(t *testing.T) {
			p, m, source, _ := originalParticipant(t)
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			if kind == "cancel-current" {
				m.admissionCurrent = func(context.Context) error { cancel(); return nil }
			}
			if kind == "expired-current" {
				now := p.coordinator.now()
				m.admissionCurrent = func(context.Context) error {
					p.coordinator.now = func() time.Time { return now.Add(2 * time.Minute) }
					return nil
				}
			}
			m.admitHook = func(context.Context) {
				switch kind {
				case "cancel-admission":
					cancel()
				case "authority-changed":
					source.snapshot.PrivateGeneration++
				case "source-lost":
					source.unavailable = true
				}
			}
			calls := 0
			_, err := p.Execute(ctx, func(context.Context, OriginalEffectOperation) error { calls++; return nil })
			if err == nil || calls != 0 {
				t.Fatalf("%s entered effect %d err%v", kind, calls, err)
			}
			if (kind == "cancel-current" || kind == "expired-current") && m.admissionCalls != 0 {
				t.Fatal("known cancellation entered admission")
			}
		})
	}
}
func TestOriginalEffectParticipantBindingMismatchAdmissionClosed(t *testing.T) {
	for _, kind := range []string{"id", "digest", "session", "action", "terminal", "unknown-result"} {
		t.Run(kind, func(t *testing.T) {
			p, m, _, _ := originalParticipant(t)
			m.corrupt = func(record *OriginalOperationRecord) {
				switch kind {
				case "id":
					record.Operation.ID = "foreign"
				case "digest":
					record.Operation.WireDigest = "foreign"
				case "session":
					record.Operation.Session.Account = "foreign"
				case "action":
					record.Operation.Action.Nonce = "foreign"
				case "terminal":
					record.State = OriginalOperationTerminal
				case "unknown-result":
					record.Result = []byte("ACK")
				}
			}
			calls := 0
			_, err := p.Execute(context.Background(), func(context.Context, OriginalEffectOperation) error { calls++; return nil })
			if err == nil || calls != 0 {
				t.Fatalf("unverified %s dispatched", kind)
			}
		})
	}
}
func TestOriginalEffectParticipantUncertainCommitReadOnlyRecovery(t *testing.T) {
	p, m, _, _ := originalParticipant(t)
	record, err := p.Execute(context.Background(), func(context.Context, OriginalEffectOperation) error { return errors.New("model commit uncertainty") })
	originalFailure(t, err, "ORIGINAL_OPERATION_UNCONFIRMED", true, true)
	if record.State != OriginalOperationUnknown {
		t.Fatal("invented terminal")
	}
	read, err := p.Recover(context.Background())
	if err != nil || read.State != OriginalOperationUnknown {
		t.Fatal(err)
	}
	m.stored.State = OriginalOperationTerminal
	if _, err = p.Recover(context.Background()); err != nil {
		t.Fatal(err)
	}
}
func TestOriginalEffectParticipantExpiredRevokedRecoveryOnly(t *testing.T) {
	p, m, source, writer := originalParticipant(t)
	op, _ := p.OriginalOperation()
	m.stored = &OriginalOperationRecord{Operation: op, State: OriginalOperationTerminal, Result: []byte("actual original model outcome")}
	if err := writer.Mutate(context.Background(), func(context.Context) error { source.snapshot.Revoked = true; return nil }); err != nil {
		t.Fatal(err)
	}
	p.coordinator.now = func() time.Time { end, _ := protocolTime(op.Session.ExpiresAt); return end.Add(time.Hour) }
	if err := writer.Retire(context.Background()); err != nil {
		t.Fatal(err)
	}
	recovery, err := NewOriginalEffectRecovery(p.coordinator, op, p.readback)
	if err != nil {
		t.Fatal(err)
	}
	record, err := recovery.Read(context.Background())
	if err != nil || record.State != OriginalOperationTerminal {
		t.Fatalf("%+v %v", record, err)
	}
	if _, err = p.Execute(context.Background(), func(context.Context, OriginalEffectOperation) error { t.Fatal("revoked redispatch"); return nil }); err == nil {
		t.Fatal("revoked effect accepted")
	}
}
func TestOriginalEffectParticipantReadbackRejectsForeignAndCancellation(t *testing.T) {
	for _, kind := range []string{"foreign-id", "foreign-session", "bad-state", "ACK", "cancel-after-read", "source-lost"} {
		t.Run(kind, func(t *testing.T) {
			p, m, _, _ := originalParticipant(t)
			op, _ := p.OriginalOperation()
			m.stored = &OriginalOperationRecord{Operation: op, State: OriginalOperationUnknown}
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			m.corrupt = func(record *OriginalOperationRecord) {
				switch kind {
				case "foreign-id":
					record.Operation.ID = "other"
				case "foreign-session":
					record.Operation.Session.DeviceID = "other"
				case "bad-state":
					record.State = "ACK"
				case "ACK":
					record.Result = []byte("id")
				}
			}
			m.readHook = func(context.Context) {
				if kind == "cancel-after-read" {
					cancel()
				}
				if kind == "source-lost" {
					m.unavailable = true
				}
			}
			if _, err := p.Recover(ctx); err == nil {
				t.Fatalf("unverified %s readback", kind)
			}
		})
	}
}
func TestOriginalEffectParticipantGateAndNoReentry(t *testing.T) {
	p, _, _, writer := originalParticipant(t)
	entered, release, revoked := make(chan struct{}), make(chan struct{}), make(chan struct{})
	done := make(chan error, 1)
	go func() {
		_, err := p.Execute(context.Background(), func(ctx context.Context, _ OriginalEffectOperation) error {
			_, err := p.Recover(ctx)
			mediaCode(t, err, "REENTRANT_TRANSACTION", false)
			close(entered)
			<-release
			return nil
		})
		done <- err
	}()
	<-entered
	go func() {
		if err := writer.Mutate(context.Background(), func(context.Context) error { close(revoked); return nil }); err != nil {
			t.Error(err)
		}
	}()
	select {
	case <-revoked:
		t.Fatal("writer crossed active effect gate")
	default:
	}
	close(release)
	if err := <-done; err != nil {
		t.Fatal(err)
	}
	<-revoked
}

func TestOriginalEffectParticipantCannotExtendOldSessionForRecovery(t *testing.T) {
	p, _, _, _ := originalParticipant(t)
	op, _ := p.OriginalOperation()
	end, _ := protocolTime(op.Session.ExpiresAt)
	op.Action.ExpiresAt = end.Add(time.Nanosecond)
	if _, err := NewOriginalEffectRecovery(p.coordinator, op, p.readback); err == nil {
		t.Fatal("fresh action extended old session recovery")
	}
}

func TestOriginalEffectParticipantUncertainAdmissionAndCollisionClosed(t *testing.T) {
	for _, kind := range []string{"lost-admission-response", "id-collision", "existing-terminal"} {
		t.Run(kind, func(t *testing.T) {
			p, m, _, _ := originalParticipant(t)
			op, _ := p.OriginalOperation()
			switch kind {
			case "lost-admission-response":
				m.admissionFailure = true
			case "id-collision":
				foreign, _ := cloneOriginalOperation(op)
				foreign.NodeRequestDigest = strings.Repeat("c", 64)
				m.stored = &OriginalOperationRecord{Operation: foreign, State: OriginalOperationUnknown}
			case "existing-terminal":
				m.stored = &OriginalOperationRecord{Operation: op, State: OriginalOperationTerminal, Result: []byte("provider-only-ref")}
			}
			calls := 0
			record, err := p.Execute(context.Background(), func(context.Context, OriginalEffectOperation) error { calls++; return nil })
			if calls != 0 || record.State != OriginalOperationUnknown {
				t.Fatalf("uncertain/existing operation dispatched or terminal invented %v %+v", err, record)
			}
			if kind != "existing-terminal" {
				originalFailure(t, err, "ORIGINAL_OPERATION_UNCONFIRMED", true, false)
			} else if err != nil {
				t.Fatal(err)
			}
			m.admissionFailure = false
			recovered, readErr := p.Recover(context.Background())
			if kind == "id-collision" {
				if readErr == nil {
					t.Fatal("foreign original read")
				}
			} else if readErr != nil || recovered.State != m.stored.State {
				t.Fatalf("%+v %v", recovered, readErr)
			}
		})
	}
}
func TestOriginalEffectParticipantCancelAfterCommitKeepsOriginalReadOnly(t *testing.T) {
	p, m, _, _ := originalParticipant(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	_, err := p.Execute(ctx, func(context.Context, OriginalEffectOperation) error {
		m.stored.State = OriginalOperationTerminal
		m.stored.Result = []byte("original model committed outcome")
		cancel()
		return nil
	})
	originalFailure(t, err, "ORIGINAL_OPERATION_UNCONFIRMED", true, true)
	if !p.coordinator.retired {
		t.Fatal("post-entry cancellation did not retire")
	}
	// A fresh context is allowed only for authenticated original readback. It
	// cannot restore a dispatch lease, renew the original session or move state.
	record, err := p.Recover(context.Background())
	if err != nil || record.State != OriginalOperationTerminal {
		t.Fatalf("%+v %v", record, err)
	}
	if _, err = p.Execute(context.Background(), func(context.Context, OriginalEffectOperation) error { t.Fatal("late redispatch"); return nil }); err == nil {
		t.Fatal("retired dispatch restored")
	}
}

func (m *originalParticipantModel) AssertOriginalNodeMappingCurrent(context.Context) error {
	if m.mappingUnavailable {
		return errors.New("model mapper unavailable")
	}
	return nil
}
func (m *originalParticipantModel) MapOriginalNodeOperation(ctx context.Context, op OriginalEffectOperation) (OriginalEffectOperation, error) {
	if m.mappingHook != nil {
		m.mappingHook(ctx)
	}
	if m.mappingUnavailable {
		return OriginalEffectOperation{}, errors.New("model mapper unavailable")
	}
	// Separate MODEL full-commit values, deliberately NOT SHA256(body) or a
	// proposed production algorithm. This model cannot authenticate provenance.
	out, _ := cloneOriginalOperation(op)
	out.NodeOperationID = strings.Repeat("a", 64)
	out.NodeRequestDigest = strings.Repeat("b", 64)
	if m.mappingCorrupt != nil {
		m.mappingCorrupt(&out)
	}
	return out, nil
}

func TestOriginalNodeCommitmentSeparateNamespacesPositive(t *testing.T) {
	p, m, _, _ := originalParticipant(t)
	op, _ := p.OriginalOperation()
	if op.NodeRequestDigest == op.WireDigest || op.ActionBodyDigest != op.WireDigest || op.ActionBodyDigest != op.Action.BodyDigest {
		t.Fatal("body/full-effect namespace collapsed")
	}
	calls := 0
	record, err := p.Execute(context.Background(), func(_ context.Context, original OriginalEffectOperation) error {
		calls++
		if !reflect.DeepEqual(original, op) || m.stored == nil || !reflect.DeepEqual(m.stored.Operation, op) {
			t.Fatal("complete mapping omitted from admission/effect")
		}
		return nil
	})
	if err != nil || calls != 1 || record.Operation.NodeRequestDigest != op.NodeRequestDigest {
		t.Fatal(err)
	}
	m.stored.State = OriginalOperationTerminal
	m.stored.Result = []byte("original-model-full-commit-outcome")
	terminal, err := p.Recover(context.Background())
	if err != nil || terminal.State != OriginalOperationTerminal || !reflect.DeepEqual(terminal.Operation, op) {
		t.Fatalf("%+v %v", terminal, err)
	}
}
func TestOriginalNodeCommitmentMapperUnavailableAndExactBindings(t *testing.T) {
	for _, kind := range []string{"absent", "typed-nil", "unavailable", "id", "session", "nonce", "method", "path", "wire", "action-body", "empty-node-commit", "node-id-format"} {
		t.Run(kind, func(t *testing.T) {
			p, _, _, _ := originalParticipant(t)
			m := &originalParticipantModel{}
			var mapper OriginalNodeOperationMappingPort = m
			if kind == "absent" {
				mapper = nil
			}
			if kind == "typed-nil" {
				var absent *originalParticipantModel
				mapper = absent
			}
			m.mappingUnavailable = kind == "unavailable"
			m.mappingCorrupt = func(op *OriginalEffectOperation) {
				switch kind {
				case "id":
					op.ID = "wrong"
				case "session":
					op.Session.DeviceID = "wrong"
				case "nonce":
					op.Action.Nonce = "wrong"
				case "method":
					op.Method = "DELETE"
				case "path":
					op.Path = "/wrong"
				case "wire":
					op.WireDigest = strings.Repeat("c", 64)
				case "action-body":
					op.ActionBodyDigest = strings.Repeat("c", 64)
				case "empty-node-commit":
					op.NodeRequestDigest = ""
				case "node-id-format":
					op.NodeOperationID = "original-upload-id"
				}
			}
			reservation, err := NewOriginalNodeReservation(m, mapper)
			if kind == "absent" || kind == "typed-nil" {
				originalFailure(t, err, "NODE_MAPPING_UNAVAILABLE", false, false)
				return
			}
			if err != nil {
				t.Fatal(err)
			}
			raw := []byte("{ \"original\": true }\n")
			_, err = NewOriginalEffectParticipant(context.Background(), p.coordinator, p.operation.Session, nil, p.operation.Action, p.operation.ID, p.operation.Method, p.operation.Path, raw, reservation, p.readback)
			if err == nil || m.admissionCalls != 0 {
				t.Fatalf("wrong %s mapping admitted", kind)
			}
		})
	}
}
func TestOriginalNodeCommitmentWrongAdmissionAndTerminalClosed(t *testing.T) {
	for _, phase := range []string{"admission", "terminal"} {
		for _, field := range []string{"node-id", "node-full-commit", "wire", "body", "original-id", "nonce"} {
			t.Run(phase+"/"+field, func(t *testing.T) {
				p, m, _, _ := originalParticipant(t)
				op, _ := p.OriginalOperation()
				m.corrupt = func(record *OriginalOperationRecord) {
					switch field {
					case "node-id":
						record.Operation.NodeOperationID = strings.Repeat("c", 64)
					case "node-full-commit":
						record.Operation.NodeRequestDigest = op.WireDigest // body-only ACK cannot stand for the captured full commitment
					case "wire":
						record.Operation.WireDigest = strings.Repeat("c", 64)
					case "body":
						record.Operation.ActionBodyDigest = strings.Repeat("c", 64)
					case "original-id":
						record.Operation.ID = "wrong"
					case "nonce":
						record.Operation.Action.Nonce = "wrong"
					}
				}
				if phase == "admission" {
					_, err := p.Execute(context.Background(), func(context.Context, OriginalEffectOperation) error {
						t.Fatal("mismatched admission dispatched")
						return nil
					})
					if err == nil {
						t.Fatal("mismatched admission")
					}
				} else {
					m.stored = &OriginalOperationRecord{Operation: op, State: OriginalOperationTerminal, Result: []byte("terminal")}
					if _, err := p.Recover(context.Background()); err == nil {
						t.Fatal("mismatched terminal accepted")
					}
				}
			})
		}
	}
}
func TestOriginalNodeCommitmentMappingCancellationAndCustodyClosed(t *testing.T) {
	for _, kind := range []string{"cancel", "custody-lost", "authority-changed"} {
		t.Run(kind, func(t *testing.T) {
			p, _, source, _ := originalParticipant(t)
			m := &originalParticipantModel{}
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			m.mappingHook = func(context.Context) {
				switch kind {
				case "cancel":
					cancel()
				case "custody-lost":
					m.mappingUnavailable = true
				case "authority-changed":
					source.snapshot.PrivateGeneration++
				}
			}
			reservation, err := NewOriginalNodeReservation(m, m)
			if err != nil {
				t.Fatal(err)
			}
			raw := []byte("{ \"original\": true }\n")
			_, err = NewOriginalEffectParticipant(ctx, p.coordinator, p.operation.Session, nil, p.operation.Action, p.operation.ID, p.operation.Method, p.operation.Path, raw, reservation, p.readback)
			if err == nil || m.admissionCalls != 0 {
				t.Fatal("mapping loss/cancellation admitted operation")
			}
		})
	}
}

// Advances time only AFTER final read validated Session, in its post-Current.
// These are clock-boundary coordination models, not source authority facts.
type originalFinalCurrentModel struct {
	original    *mediaCoordinatorModel
	coordinator *MediaAuthorityCoordinator
	armed, read bool
	late        time.Time
}

func (s *originalFinalCurrentModel) AssertOriginalMediaSourceCurrent(ctx context.Context) error {
	if s.armed && s.read {
		s.coordinator.now = func() time.Time { return s.late }
	}
	return s.original.AssertOriginalMediaSourceCurrent(ctx)
}
func (s *originalFinalCurrentModel) ReadOriginalMediaAuthority(ctx context.Context, session Session, browser *BrowserGrant) (MediaAuthoritySnapshot, error) {
	if s.armed {
		s.read = true
	}
	return s.original.ReadOriginalMediaAuthority(ctx, session, browser)
}
func TestOriginalNodeCommitmentFinalCurrentFiniteBoundary(t *testing.T) {
	for _, kind := range []string{"action", "session"} {
		t.Run(kind, func(t *testing.T) {
			p, m, authority, _ := originalParticipant(t)
			late := p.operation.Action.ExpiresAt
			if kind == "session" {
				late, _ = protocolTime(p.operation.Session.ExpiresAt)
			}
			source := &originalFinalCurrentModel{original: authority, coordinator: p.coordinator, late: late}
			p.coordinator.source = source
			m.admitHook = func(context.Context) { source.armed = true }
			calls := 0
			record, err := p.Execute(context.Background(), func(context.Context, OriginalEffectOperation) error { calls++; return nil })
			originalFailure(t, err, "ORIGINAL_OPERATION_UNCONFIRMED", true, false)
			if calls != 0 || record.State != OriginalOperationUnknown {
				t.Fatal("final Current expiry entered effect")
			}
		})
	}
}
