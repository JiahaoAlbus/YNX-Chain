package productsessionv2

import (
	"crypto/ed25519"
	"net/http"
	"slices"
)

// This is only the existing accepted Web read tuple. Registry ceilings and the
// legacy action signer do not register a write grant or authorize execution.
func NewExchangeWebReadAuthority(keyID string, key ed25519.PrivateKey, seal []byte, transport http.RoundTripper) (*RegisteredClientSet, *BrowserSSO, error) {
	c, err := NewClient(browserIssuer, Policy{ProductID: "exchange", ClientID: "ynx-exchange-v1", ApplicationID: "com.ynxweb4.exchange.web", Platform: "web", Origin: "https://exchange.ynxweb4.com", Callback: "https://exchange.ynxweb4.com/wallet-auth/callback", AllowedScopes: []string{"exchange:read"}}, transport)
	if err != nil {
		return nil, nil, err
	}
	reader, err := NewPrivateBusinessRevalidator(c, "ynx-exchange-v1-business-web-v1", keyID, key)
	if err != nil {
		return nil, nil, err
	}
	set, err := NewRegisteredClientSet("exchange", []*Client{c}, []*Revalidator{reader})
	if err != nil {
		return nil, nil, err
	}
	browser, err := NewBrowserSSO("exchange", browserIssuer, seal, []string{"assets", "market", "activity", "controls"}, transport)
	if err != nil {
		return nil, nil, err
	}
	if err = ValidateExchangeWebReadAuthority(set, browser); err != nil {
		return nil, nil, err
	}
	return set, browser, nil
}

func ValidateExchangeWebReadAuthority(set *RegisteredClientSet, browser *BrowserSSO) error {
	reject := func() error { return fail("EXCHANGE_WEB_READ_PROFILE_UNAVAILABLE", 503) }
	if set == nil || browser == nil || set.product != "exchange" || len(set.clients) != 1 || len(set.readers) != 1 {
		return reject()
	}
	c, r := set.clients["web"], set.readers["web"]
	if c == nil || r == nil || r.client != c || !r.business || r.backendClientID != "ynx-exchange-v1-business-web-v1" || r.keyID == "" || len(r.key) != ed25519.PrivateKeySize {
		return reject()
	}
	p := c.policy
	if c.endpoint != browserIssuer || p.ProductID != "exchange" || p.ClientID != "ynx-exchange-v1" || p.ApplicationID != "com.ynxweb4.exchange.web" || p.Platform != "web" || p.Origin != "https://exchange.ynxweb4.com" || p.Callback != p.Origin+"/wallet-auth/callback" || !slices.Equal(p.AllowedScopes, []string{"exchange:read"}) {
		return reject()
	}
	if browser.product != "exchange" || browser.origin != p.Origin || browser.authority != browserIssuer || browser.clientID != "ynx-exchange-v1-sso-v1" || browser.audience != "ynx:exchange:identity" {
		return reject()
	}
	return nil
}
