package productsessionv2

import (
	"net/http"
	"net/http/httptest"
	"net/url"
	"slices"
	"testing"
)

func TestOriginalMediaFixedRegistryProfiles(t *testing.T) {
	for _, product := range []string{"video", "creator-studio", "music"} {
		for _, platform := range []string{"web", "android", "ios", "macos", "linux", "windows"} {
			p, err := mediaPolicy(product, platform)
			if product == "music" && (platform == "web" || platform == "linux" || platform == "windows") {
				if err == nil {
					t.Fatal("unimplemented Music platform enabled")
				}
				continue
			}
			if err != nil {
				t.Fatal(err)
			}
			if p.ProductID != product || p.Platform != platform || !slices.IsSorted(p.AllowedScopes) {
				t.Fatal("policy mismatch")
			}
			if platform == "web" && (p.BundleID != nil || p.PackageID != nil) {
				t.Fatal("native identity borrowed")
			}
		}
	}
	if _, err := mediaPolicy("pay-merchant", "web"); err == nil {
		t.Fatal("foreign product accepted")
	}
	if _, err := LoadOriginalMediaProfiles(MediaProtectedConfiguration{}, nil, nil, nil); err == nil {
		t.Fatal("absent registration accepted")
	}
}

func TestMediaMicrositeIdentityReturnPreservesOriginalCallback(t *testing.T) {
	for _, product := range []string{"video", "creator-studio"} {
		s, err := NewMediaBrowserSSO(product, browserIssuer, make([]byte, 32), []string{"original-view"}, nil, func() error { return nil })
		if err != nil {
			t.Fatal(err)
		}
		w := httptest.NewRecorder()
		silent := httptest.NewRequest("GET", s.origin+"/sso/start?prompt=none&target=original-view", nil)
		silent.AddCookie(&http.Cookie{Name: s.identityCookie + "-signedout", Value: "1"})
		s.Start(w, silent)
		if w.Code != 303 || w.Header().Get("Location") != "/app.html#original-view" {
			t.Fatal(w.Code, w.Header().Get("Location"))
		}
		w = httptest.NewRecorder()
		s.Start(w, httptest.NewRequest("GET", s.origin+"/sso/start?target=original-view", nil))
		location, err := url.Parse(w.Header().Get("Location"))
		if err != nil {
			t.Fatal(err)
		}
		if location.Query().Get("redirectUri") != s.origin+"/sso/callback" {
			t.Fatal("registered callback changed")
		}
		r := httptest.NewRequest("GET", s.origin+"/sso/callback?state="+url.QueryEscape(location.Query().Get("state"))+"&error=access_denied", nil)
		for _, c := range w.Result().Cookies() {
			r.AddCookie(c)
		}
		out := httptest.NewRecorder()
		s.Callback(out, r)
		if out.Code != 303 || out.Header().Get("Location") != "/app.html#original-view" {
			t.Fatal(out.Code, out.Header().Get("Location"))
		}
	}
	if _, err := NewMediaBrowserSSO("music", browserIssuer, make([]byte, 32), []string{"x"}, nil, func() error { return nil }); err == nil {
		t.Fatal("foreign browser product accepted")
	}
}
