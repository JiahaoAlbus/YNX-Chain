package productsessionv2

import (
	"crypto/ed25519"
	"crypto/rand"
	"net/http"
	"testing"
)

type workspaceNoTransport struct{ t *testing.T }

func (n workspaceNoTransport) RoundTrip(*http.Request) (*http.Response, error) {
	n.t.Fatal("constructor requested authority")
	return nil, nil
}
func TestWorkspaceExactProfilesAndCrossProductReject(t *testing.T) {
	_, key, _ := ed25519.GenerateKey(rand.Reader)
	seal := make([]byte, 32)
	cloud, cb, e := NewCloudWebAuthority("source-test", key, seal, workspaceNoTransport{t})
	if e != nil {
		t.Fatal(e)
	}
	docs, db, e := NewDocsWebAuthority("source-test", key, seal, workspaceNoTransport{t})
	if e != nil {
		t.Fatal(e)
	}
	if ValidateCloudWebAuthority(cloud, cb) != nil || ValidateDocsWebAuthority(docs, db) != nil {
		t.Fatal("exact source tuple rejected")
	}
	if ValidateCloudWebAuthority(docs, db) == nil || ValidateDocsWebAuthority(cloud, cb) == nil || ValidateCloudWebAuthority(cloud, db) == nil {
		t.Fatal("borrowed identity accepted")
	}
	cloud.clients["web"].policy.AllowedScopes = append(cloud.clients["web"].policy.AllowedScopes, "permissions.manage")
	if ValidateCloudWebAuthority(cloud, cb) == nil {
		t.Fatal("scope widening accepted")
	}
	docs.clients["web"].policy.AllowedScopes = append(docs.clients["web"].policy.AllowedScopes, "comments.write")
	if ValidateDocsWebAuthority(docs, db) == nil {
		t.Fatal("unaccepted comments scope")
	}
}
func TestWorkspaceProtectedConfigurationEmptyPartialUnknown(t *testing.T) {
	for _, p := range []string{"cloud", "docs"} {
		a, b, e := LoadWorkspaceWebAuthorityConfig(p, WorkspaceWebAuthorityConfig{}, workspaceNoTransport{t})
		if a != nil || b != nil || e != nil {
			t.Fatal("empty not closed")
		}
		a, b, e = LoadWorkspaceWebAuthorityConfig(p, WorkspaceWebAuthorityConfig{BackendKeyID: "partial"}, workspaceNoTransport{t})
		if a != nil || b != nil || e == nil {
			t.Fatal("partial accepted")
		}
	}
	if _, _, e := LoadWorkspaceWebAuthorityConfig("mail", WorkspaceWebAuthorityConfig{}, nil); e == nil {
		t.Fatal("unknown accepted")
	}
}
