package productsessionv2

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"sync/atomic"
	"testing"
	"time"
)

// This source is a coordination MODEL ONLY, never a production enrollment feed.
// Original fixed Session fixture is reused; generation/family below are model
// labels testing exclusion, not facts asserted about any account or device.
type mediaCoordinatorModel struct {
	snapshot            MediaAuthoritySnapshot
	unavailable         bool
	mutateProviderAlias bool
}

func (m *mediaCoordinatorModel) AssertOriginalMediaSourceCurrent(context.Context) error {
	if m.unavailable {
		return errors.New("model source unavailable")
	}
	return nil
}
func (m *mediaCoordinatorModel) ReadOriginalMediaAuthority(_ context.Context, s Session, b *BrowserGrant) (MediaAuthoritySnapshot, error) {
	if m.mutateProviderAlias {
		s.Scopes[0] = "untrusted-provider-mutation"
		if b != nil {
			b.Scopes[0] = "untrusted"
		}
	}
	return m.snapshot, nil
}
func mediaModel(t *testing.T) (*MediaAuthorityCoordinator, *MediaAuthorityWriter, *mediaCoordinatorModel, Session) {
	t.Helper()
	b, err := os.ReadFile("testdata/finance-v2.json")
	if err != nil {
		t.Fatal(err)
	}
	var fixture struct{ Session Session }
	if json.Unmarshal(b, &fixture) != nil {
		t.Fatal("fixture decode")
	}
	session := fixture.Session
	issued, _ := protocolTime(session.IssuedAt)
	now := issued.Add(time.Second)
	snapshot, _ := cloneMediaSnapshot(MediaAuthoritySnapshot{Session: session, FamilyID: "model-family-not-enrollment", PrivateGeneration: 0, GenerationAvailable: true, Enrolled: true, MembershipRevision: 9, MembershipAvailable: true})
	model := &mediaCoordinatorModel{snapshot: snapshot}
	c := NewMediaAuthorityCoordinator(func() time.Time { return now })
	writer, err := c.RegisterOriginalWriter(context.Background(), model)
	if err != nil {
		t.Fatal(err)
	}
	return c, writer, model, session
}
func mediaCode(t *testing.T, err error, code string, started bool) {
	t.Helper()
	var failure *MediaCoordinationError
	if !errors.As(err, &failure) || failure.Code != code || failure.EffectStarted != started {
		t.Fatalf("got %v want %s started=%v", err, code, started)
	}
}
func TestMediaCoordinatorMissingProducerClosed(t *testing.T) {
	c := NewMediaAuthorityCoordinator(nil)
	_, err := c.Capture(context.Background(), Session{}, nil)
	mediaCode(t, err, "SOURCE_UNAVAILABLE", false)
	_, err = c.RegisterOriginalWriter(context.Background(), nil)
	mediaCode(t, err, "SOURCE_UNAVAILABLE", false)
	var typedNil *mediaCoordinatorModel
	_, err = c.RegisterOriginalWriter(context.Background(), typedNil)
	mediaCode(t, err, "SOURCE_UNAVAILABLE", false)
	for _, kind := range []string{"missing-generation", "missing-membership", "unenrolled", "missing-family", "source-unavailable"} {
		t.Run(kind, func(t *testing.T) {
			c, _, m, s := mediaModel(t)
			switch kind {
			case "missing-generation":
				m.snapshot.GenerationAvailable = false
			case "missing-membership":
				m.snapshot.MembershipAvailable = false
			case "unenrolled":
				m.snapshot.Enrolled = false
			case "missing-family":
				m.snapshot.FamilyID = ""
			case "source-unavailable":
				m.unavailable = true
			}
			_, err := c.Capture(context.Background(), s, nil)
			mediaCode(t, err, "SOURCE_UNAVAILABLE", false)
		})
	}
}
func TestMediaCoordinatorExactSnapshotsAndOneShot(t *testing.T) {
	c, _, m, s := mediaModel(t)
	m.mutateProviderAlias = true
	effect, err := c.Capture(context.Background(), s, nil)
	if err != nil {
		t.Fatal(err)
	}
	// Caller alias mutation after capture cannot change its immutable approved input.
	s.Scopes[0] = "caller-mutation"
	if err = effect.Execute(context.Background(), func(context.Context) error { return nil }); err != nil {
		t.Fatal(err)
	}
	mediaCode(t, effect.Execute(context.Background(), func(context.Context) error { return nil }), "EFFECT_ALREADY_USED", false)
	_, err = c.RegisterOriginalWriter(context.Background(), m)
	mediaCode(t, err, "WRITER_ALREADY_REGISTERED", false)
}
func TestMediaCoordinatorLiveChangeRejectsBeforeEffect(t *testing.T) {
	for _, kind := range []string{"private-generation", "member", "family", "device", "account", "revoked", "source", "browser"} {
		t.Run(kind, func(t *testing.T) {
			c, _, m, s := mediaModel(t)
			var b *BrowserGrant
			if kind == "browser" {
				issued, _ := protocolTime(s.IssuedAt)
				b = &BrowserGrant{Identity: BrowserIdentity{Subject: s.Account, Account: s.Account, Generation: 3, ExpiresAt: issued.Add(time.Hour)}, ExpiresAt: issued.Add(time.Hour), Scopes: []string{"identity:read"}}
				m.snapshot.Browser = b
			}
			e, err := c.Capture(context.Background(), s, b)
			if err != nil {
				t.Fatal(err)
			}
			switch kind {
			case "private-generation":
				m.snapshot.PrivateGeneration++
			case "member":
				m.snapshot.MembershipRevision++
			case "family":
				m.snapshot.FamilyID = "changed"
			case "device":
				m.snapshot.Session.DeviceID = "changed"
			case "account":
				m.snapshot.Session.Account = "changed"
			case "revoked":
				m.snapshot.Revoked = true
			case "source":
				m.unavailable = true
			case "browser":
				b.Identity.Generation++
			}
			calls := 0
			err = e.Execute(context.Background(), func(context.Context) error { calls++; return nil })
			if err == nil || calls != 0 {
				t.Fatalf("change allowed effect %s %v", kind, err)
			}
		})
	}
}
func TestMediaCoordinatorDeviceBindingAndExpiry(t *testing.T) {
	c, _, m, s := mediaModel(t)
	s.DeviceBinding = "invalid"
	m.snapshot.Session = s
	_, err := c.Capture(context.Background(), s, nil)
	mediaCode(t, err, "INVALID_DEVICE_BINDING", false)
	c, _, _, s = mediaModel(t)
	c.now = func() time.Time { expires, _ := protocolTime(s.ExpiresAt); return expires }
	_, err = c.Capture(context.Background(), s, nil)
	mediaCode(t, err, "INVALID_OR_EXPIRED_SESSION", false)
}
func TestMediaCoordinatorWriterInvalidationAndRetirement(t *testing.T) {
	c, w, m, s := mediaModel(t)
	e, err := c.Capture(context.Background(), s, nil)
	if err != nil {
		t.Fatal(err)
	}
	if err = w.Mutate(context.Background(), func(context.Context) error { m.snapshot.PrivateGeneration++; return nil }); err != nil {
		t.Fatal(err)
	}
	mediaCode(t, e.Execute(context.Background(), func(context.Context) error { t.Fatal("late effect"); return nil }), "AUTHORITY_CHANGED", false)
	if err = w.Mutate(context.Background(), func(context.Context) error { return errors.New("unknown original writer commit") }); err == nil {
		t.Fatal("accepted uncertain commit")
	} else {
		mediaCode(t, err, "WRITER_COMMIT_UNCERTAIN", false)
	}
	_, err = c.Capture(context.Background(), s, nil)
	mediaCode(t, err, "RETIRED", false)
	c, w, _, s = mediaModel(t)
	e, _ = c.Capture(context.Background(), s, nil)
	if err = w.Retire(context.Background()); err != nil {
		t.Fatal(err)
	}
	mediaCode(t, e.Execute(context.Background(), func(context.Context) error { return nil }), "RETIRED", false)
}
func TestMediaCoordinatorLinearizesEffectAndOriginalWriter(t *testing.T) {
	c, w, m, s := mediaModel(t)
	e, _ := c.Capture(context.Background(), s, nil)
	started, release := make(chan struct{}), make(chan struct{})
	effects := make(chan error, 1)
	writes := make(chan error, 1)
	var committed atomic.Bool
	go func() {
		effects <- e.Execute(context.Background(), func(context.Context) error { close(started); <-release; return nil })
	}()
	<-started
	// Test-only barrier holds a synchronous callback; no production network/await.
	go func() {
		writes <- w.Mutate(context.Background(), func(context.Context) error { m.snapshot.Revoked = true; committed.Store(true); return nil })
	}()
	if committed.Load() {
		t.Fatal("writer crossed held effect")
	}
	close(release)
	if err := <-effects; err != nil {
		t.Fatal(err)
	}
	if err := <-writes; err != nil {
		t.Fatal(err)
	}
	if !committed.Load() {
		t.Fatal("writer missing")
	}
	_, err := c.Capture(context.Background(), s, nil)
	mediaCode(t, err, "REVOKED", false)
}
func TestMediaCoordinatorCancellationAndReentry(t *testing.T) {
	c, _, _, s := mediaModel(t)
	e, _ := c.Capture(context.Background(), s, nil)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	mediaCode(t, e.Execute(ctx, func(context.Context) error { t.Fatal("cancelled effect"); return nil }), "CANCELLED", false)
	c, _, _, s = mediaModel(t)
	e, _ = c.Capture(context.Background(), s, nil)
	err := e.Execute(context.Background(), func(local context.Context) error {
		_, err := c.Capture(local, s, nil)
		mediaCode(t, err, "REENTRANT_TRANSACTION", false)
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	c, _, _, s = mediaModel(t)
	e, _ = c.Capture(context.Background(), s, nil)
	ctx, cancel = context.WithCancel(context.Background())
	mediaCode(t, e.Execute(ctx, func(context.Context) error { cancel(); return nil }), "EFFECT_OUTCOME_UNCONFIRMED", true)
}
func TestMediaCoordinatorWaitingCancellationAndLateAlias(t *testing.T) {
	c, w, m, s := mediaModel(t)
	e, _ := c.Capture(context.Background(), s, nil)
	started, release := make(chan struct{}), make(chan struct{})
	done := make(chan error, 1)
	go func() {
		done <- w.Mutate(context.Background(), func(context.Context) error { close(started); <-release; return nil })
	}()
	<-started
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	mediaCode(t, e.Execute(ctx, func(context.Context) error { t.Fatal("waiting cancel effect"); return nil }), "CANCELLED", false)
	close(release)
	if err := <-done; err != nil {
		t.Fatal(err)
	}
	c, _, m, s = mediaModel(t)
	e, _ = c.Capture(context.Background(), s, nil)
	mediaCode(t, e.Execute(context.Background(), func(context.Context) error { m.snapshot.MembershipRevision++; return nil }), "EFFECT_OUTCOME_UNCONFIRMED", true)
	_, err := c.Capture(context.Background(), s, nil)
	mediaCode(t, err, "RETIRED", false)
}

func TestMediaCoordinatorMutationPanicRetiresAndReleasesGate(t *testing.T) {
	c, w, _, s := mediaModel(t)
	func() {
		defer func() {
			if recover() == nil {
				t.Fatal("missing model panic")
			}
		}()
		_ = w.Mutate(context.Background(), func(context.Context) error { panic("model original writer interrupted") })
	}()
	_, err := c.Capture(context.Background(), s, nil)
	mediaCode(t, err, "RETIRED", false)
}
func TestMediaCoordinatorEffectPanicNeverPermitsReplay(t *testing.T) {
	c, _, _, s := mediaModel(t)
	e, _ := c.Capture(context.Background(), s, nil)
	func() {
		defer func() {
			if recover() == nil {
				t.Fatal("missing model panic")
			}
		}()
		_ = e.Execute(context.Background(), func(context.Context) error { panic("model effect interrupted") })
	}()
	mediaCode(t, e.Execute(context.Background(), func(context.Context) error { return nil }), "RETIRED", false)
}

func TestMediaCoordinatorCapturedCancellationCannotRebindContext(t *testing.T) {
	c, _, _, s := mediaModel(t)
	captured, cancel := context.WithCancel(context.Background())
	e, err := c.Capture(captured, s, nil)
	if err != nil {
		t.Fatal(err)
	}
	cancel()
	mediaCode(t, e.Execute(context.Background(), func(context.Context) error { t.Fatal("cancelled capture rebound"); return nil }), "CANCELLED", false)
	c, _, _, s = mediaModel(t)
	captured, cancel = context.WithCancel(context.Background())
	e, _ = c.Capture(captured, s, nil)
	mediaCode(t, e.Execute(context.Background(), func(context.Context) error { cancel(); return nil }), "EFFECT_OUTCOME_UNCONFIRMED", true)
}

// Nil-able producer model tests registration only; no enrolled actor is supplied.
type mediaNilFuncSource func()

func (mediaNilFuncSource) AssertOriginalMediaSourceCurrent(context.Context) error { return nil }
func (mediaNilFuncSource) ReadOriginalMediaAuthority(context.Context, Session, *BrowserGrant) (MediaAuthoritySnapshot, error) {
	return MediaAuthoritySnapshot{}, nil
}

// Nil-able producer model tests registration only; no enrolled actor is supplied.
type mediaNilMapSource map[string]string

func (mediaNilMapSource) AssertOriginalMediaSourceCurrent(context.Context) error { return nil }
func (mediaNilMapSource) ReadOriginalMediaAuthority(context.Context, Session, *BrowserGrant) (MediaAuthoritySnapshot, error) {
	return MediaAuthoritySnapshot{}, nil
}

// Nil-able producer model tests registration only; no enrolled actor is supplied.
type mediaNilSliceSource []string

func (mediaNilSliceSource) AssertOriginalMediaSourceCurrent(context.Context) error { return nil }
func (mediaNilSliceSource) ReadOriginalMediaAuthority(context.Context, Session, *BrowserGrant) (MediaAuthoritySnapshot, error) {
	return MediaAuthoritySnapshot{}, nil
}

// Nil-able producer model tests registration only; no enrolled actor is supplied.
type mediaNilChanSource chan struct{}

func (mediaNilChanSource) AssertOriginalMediaSourceCurrent(context.Context) error { return nil }
func (mediaNilChanSource) ReadOriginalMediaAuthority(context.Context, Session, *BrowserGrant) (MediaAuthoritySnapshot, error) {
	return MediaAuthoritySnapshot{}, nil
}

func TestMediaCoordinatorAllNilableSourcesClosed(t *testing.T) {
	var function mediaNilFuncSource
	var mapping mediaNilMapSource
	var slice mediaNilSliceSource
	var channel mediaNilChanSource
	var pointer *mediaCoordinatorModel
	var absent MediaOriginalAuthoritySource
	for _, item := range []struct {
		name   string
		source MediaOriginalAuthoritySource
	}{
		{"func", function}, {"map", mapping}, {"slice", slice}, {"chan", channel}, {"pointer", pointer}, {"nil-interface", absent},
	} {
		t.Run(item.name, func(t *testing.T) {
			c := NewMediaAuthorityCoordinator(nil)
			writer, err := c.RegisterOriginalWriter(context.Background(), item.source)
			mediaCode(t, err, "SOURCE_UNAVAILABLE", false)
			if writer != nil || c.source != nil {
				t.Fatal("missing source acquired writer")
			}
		})
	}
	// Genuine non-nil implementations of each dynamic kind remain admissible at
	// the composition seam. This does not assert enrollment or Capture success.
	for _, source := range []MediaOriginalAuthoritySource{
		mediaNilFuncSource(func() {}), mediaNilMapSource{}, mediaNilSliceSource{}, make(mediaNilChanSource), &mediaCoordinatorModel{},
	} {
		c := NewMediaAuthorityCoordinator(nil)
		if writer, err := c.RegisterOriginalWriter(context.Background(), source); err != nil || writer == nil {
			t.Fatalf("non-nil source refused: %T %v", source, err)
		}
	}
}

type mediaBoundarySource struct {
	*mediaCoordinatorModel
	current func()
}

func (s *mediaBoundarySource) AssertOriginalMediaSourceCurrent(context.Context) error {
	if s.current != nil {
		s.current()
	}
	return nil
}

// Deterministic deadline boundary; Deadline advances during Current even before
// an asynchronous timer can publish Err. Production must check both boundaries.
type mediaBoundaryDeadlineContext struct {
	context.Context
	expired bool
}

func (c *mediaBoundaryDeadlineContext) Deadline() (time.Time, bool) {
	if c.expired {
		return time.Now().Add(-time.Second), true
	}
	return time.Now().Add(time.Hour), true
}
func TestMediaCoordinatorWriterCurrentCancellationBeforeCommit(t *testing.T) {
	for _, kind := range []string{"cancel", "deadline"} {
		t.Run(kind, func(t *testing.T) {
			_, _, model, _ := mediaModel(t)
			c := NewMediaAuthorityCoordinator(nil)
			source := &mediaBoundarySource{mediaCoordinatorModel: model}
			writer, err := c.RegisterOriginalWriter(context.Background(), source)
			if err != nil {
				t.Fatal(err)
			}
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			var transaction context.Context = ctx
			source.current = cancel
			if kind == "deadline" {
				boundary := &mediaBoundaryDeadlineContext{Context: ctx}
				transaction = boundary
				source.current = func() { boundary.expired = true }
			}
			calls := 0
			err = writer.Mutate(transaction, func(context.Context) error { calls++; return nil })
			mediaCode(t, err, "CANCELLED", false)
			if calls != 0 || c.epoch != 0 || c.retired {
				t.Fatalf("pre-entry cancellation changed authority: calls=%d epoch=%d retired=%v", calls, c.epoch, c.retired)
			}
			source.current = nil
			if err = writer.Mutate(context.Background(), func(context.Context) error { calls++; return nil }); err != nil || calls != 1 {
				t.Fatalf("unentered cancellation incorrectly retired writer: %v calls=%d", err, calls)
			}
		})
	}
}
