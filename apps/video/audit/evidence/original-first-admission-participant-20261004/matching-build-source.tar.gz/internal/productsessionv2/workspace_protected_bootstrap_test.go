package productsessionv2

import (
	"bytes"
	"crypto/ed25519"
	"crypto/x509"
	"encoding/pem"
	"os"
	"path/filepath"
	"testing"
)

func TestWorkspaceProtectedStartupRealFDContract(t *testing.T) {
	home, err := os.UserHomeDir()
	if err != nil {
		t.Fatal(err)
	}
	dir, err := os.MkdirTemp(home, ".ynx-workspace-source-loader-")
	if err != nil {
		t.Fatal(err)
	}
	defer os.RemoveAll(dir)
	key := ed25519.NewKeyFromSeed(bytes.Repeat([]byte{3}, 32))
	raw, err := x509.MarshalPKCS8PrivateKey(key)
	if err != nil {
		t.Fatal(err)
	}
	keyPath := filepath.Join(dir, "reader.pem")
	sealPath := filepath.Join(dir, "browser-seal.bin")
	if err = os.WriteFile(keyPath, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: raw}), 0600); err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(sealPath, bytes.Repeat([]byte{4}, 32), 0600); err != nil {
		t.Fatal(err)
	}
	c := WorkspaceWebAuthorityConfig{"source-fixture", keyPath, sealPath}
	set, browser, err := LoadWorkspaceWebAuthorityConfig("cloud", c, nil)
	if err != nil {
		t.Fatal(err)
	}
	if ValidateCloudWebAuthority(set, browser) != nil {
		t.Fatal("loaded invalid")
	}
	docs, db, e := LoadWorkspaceWebAuthorityConfig("docs", c, nil)
	if e != nil || ValidateDocsWebAuthority(docs, db) != nil {
		t.Fatal("Docs protected source loader", e)
	}
	alias := filepath.Join(dir, "alias")
	if err = os.Symlink(dir, alias); err != nil {
		t.Fatal(err)
	}
	c.BrowserSealFile = filepath.Join(alias, "browser-seal.bin")
	if _, _, err = LoadWorkspaceWebAuthorityConfig("cloud", c, nil); err == nil {
		t.Fatal("symlink ancestor")
	}
	c.BrowserSealFile = sealPath
	link := filepath.Join(dir, "seal-hardlink")
	if err = os.Link(sealPath, link); err != nil {
		t.Fatal(err)
	}
	if _, _, err = LoadWorkspaceWebAuthorityConfig("cloud", c, nil); err == nil {
		t.Fatal("hardlinked seal")
	}
	if err = os.Remove(link); err != nil {
		t.Fatal(err)
	}
	if err = os.Chmod(dir, 0777); err != nil {
		t.Fatal(err)
	}
	if _, _, err = LoadWorkspaceWebAuthorityConfig("cloud", c, nil); err == nil {
		t.Fatal("unprotected parent")
	}
	if err = os.Chmod(dir, 0700); err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(sealPath, bytes.Repeat([]byte{4}, 33), 0600); err != nil {
		t.Fatal(err)
	}
	if _, _, err = LoadWorkspaceWebAuthorityConfig("cloud", c, nil); err == nil {
		t.Fatal("oversized seal")
	}
}
