package productsessionv2

import (
	"bytes"
	"crypto/ed25519"
	"net/http"
	"testing"
)

func TestExchangeReadProfileFixedAndNoRegistration(t *testing.T) {
	calls := 0
	transport := roundTrip(func(*http.Request) (*http.Response, error) {
		calls++
		t.Fatal("constructor contacted authority")
		return nil, nil
	})
	key := ed25519.NewKeyFromSeed(bytes.Repeat([]byte{7}, 32))
	set, browser, err := NewExchangeWebReadAuthority("source-only", key, bytes.Repeat([]byte{8}, 32), transport)
	if err != nil {
		t.Fatal(err)
	}
	if err = ValidateExchangeWebReadAuthority(set, browser); err != nil {
		t.Fatal(err)
	}
	set.clients["web"].policy.AllowedScopes = append(set.clients["web"].policy.AllowedScopes, "exchange:trade")
	if err = ValidateExchangeWebReadAuthority(set, browser); err == nil {
		t.Fatal("ceiling expanded read tuple")
	}
	set.clients["web"].policy.AllowedScopes = []string{"exchange:read"}
	set.readers["web"].backendClientID = "ynx-pay-v1-business-web-v1"
	if err = ValidateExchangeWebReadAuthority(set, browser); err == nil {
		t.Fatal("borrowed role")
	}
	if calls != 0 {
		t.Fatal(calls)
	}
}
func TestExchangeReadProfileRejectsIncompleteAndCrossProduct(t *testing.T) {
	key := ed25519.NewKeyFromSeed(bytes.Repeat([]byte{7}, 32))
	for _, tc := range []struct {
		id   string
		key  ed25519.PrivateKey
		seal []byte
	}{{"", key, bytes.Repeat([]byte{8}, 32)}, {"source", nil, bytes.Repeat([]byte{8}, 32)}, {"source", key, nil}} {
		set, browser, err := NewExchangeWebReadAuthority(tc.id, tc.key, tc.seal, nil)
		if err == nil || set != nil || browser != nil {
			t.Fatal("partial accepted")
		}
	}
	set, browser, err := NewCalendarWebAuthority("source", key, bytes.Repeat([]byte{8}, 32), nil)
	if err != nil {
		t.Fatal(err)
	}
	if err = ValidateExchangeWebReadAuthority(set, browser); err == nil {
		t.Fatal("borrowed Calendar identity")
	}
}
