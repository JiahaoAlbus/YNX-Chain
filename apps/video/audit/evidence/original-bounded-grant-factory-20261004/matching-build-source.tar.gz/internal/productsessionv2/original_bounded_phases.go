package productsessionv2

import (
	"context"
	"reflect"
	"sync"
	"sync/atomic"
)

// A trusted original-reader value, never caller phase state. Grant and operation
// retain the FULL original immutable backend-only material. WorkID is original
// owned preparation identity; State is read from its original persisted intent.
type OriginalPreparedEffectPublication struct {
	WorkID, State string
	Operation     OriginalEffectOperation
	Browser       *BrowserGrant
}

// Read runs OUTSIDE authority gate and owned Store lock. Current is pure local
// protected custody/immutable association validation, NOT a Store getter, phase
// state echo, network, cached authorization or a new production enrollment.
// Actual original writer publication/source implementation is not supplied.
type OriginalPreparedPublicationPort interface {
	ReadOriginalPreparedPublication(context.Context, string) (OriginalPreparedEffectPublication, error)
	AssertOriginalPreparedPublicationCurrent(context.Context, OriginalEffectOperation) error
}

// Actual registered transport authenticates exact durable Node UNKNOWN reserve.
// Its network/provider operation runs OUTSIDE the Go authority gate. Current is
// a pure sync protected source-lifetime check; no network inside that method.
// This protocol bridge DOES NOT serialize remote Node revoke with Go commit.
type OriginalPreparedNodeTransport interface {
	AssertOriginalPreparedNodeTransportCurrent(context.Context) error
	ReserveOriginalPreparedNode(context.Context, OriginalEffectOperation) (OriginalAdmission, error)
}

// A process-local holder of a genuine fixed transport reply, not a durable
// account/operation store, independent authority or proof verifier. Losing this
// holder never permits a resend; original Node obligation remains decisive.
type OriginalBoundedPhaseReservation struct {
	transport                 OriginalPreparedNodeTransport
	mu                        sync.Mutex
	bound                     *OriginalEffectOperation
	attempted, ready, claimed bool
	admission                 OriginalAdmission
}

func NewOriginalBoundedPhaseReservation(transport OriginalPreparedNodeTransport) (*OriginalBoundedPhaseReservation, error) {
	if originalPortMissing(transport) {
		return nil, originalEffectError("PREPARED_NODE_TRANSPORT_UNAVAILABLE", false, false)
	}
	return &OriginalBoundedPhaseReservation{transport: transport}, nil
}
func (r *OriginalBoundedPhaseReservation) Reservation(mapper OriginalNodeOperationMappingPort) (*OriginalNodeReservation, error) {
	if r == nil || originalPortMissing(r.transport) {
		return nil, originalEffectError("PREPARED_NODE_TRANSPORT_UNAVAILABLE", false, false)
	}
	return NewOriginalNodeReservation(r, mapper)
}
func (r *OriginalBoundedPhaseReservation) AssertOriginalReservationCurrent(ctx context.Context) error {
	if r == nil || originalPortMissing(r.transport) {
		return originalEffectError("PREPARED_NODE_TRANSPORT_UNAVAILABLE", false, false)
	}
	r.mu.Lock()
	ready := r.ready
	r.mu.Unlock()
	if !ready {
		return originalEffectError("PREPARED_NODE_ACK_UNAVAILABLE", false, false)
	}
	if r.transport.AssertOriginalPreparedNodeTransportCurrent(ctx) != nil {
		return originalEffectError("PREPARED_NODE_TRANSPORT_UNAVAILABLE", true, false)
	}
	return mediaContextCurrent(ctx)
}

// This original port method never calls transport, publication reader or Store.
// It releases only the actual previously obtained FULL acknowledged binding.
func (r *OriginalBoundedPhaseReservation) AdmitOriginalUnknown(ctx context.Context, op OriginalEffectOperation) (OriginalAdmission, error) {
	if r == nil {
		return OriginalAdmission{}, originalEffectError("PREPARED_NODE_ACK_UNAVAILABLE", false, false)
	}
	if err := mediaContextCurrent(ctx); err != nil {
		return OriginalAdmission{}, err
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if !r.ready || r.bound == nil || !reflect.DeepEqual(op, *r.bound) {
		return OriginalAdmission{}, originalEffectError("PREPARED_NODE_ACK_UNAVAILABLE", true, false)
	}
	record, err := exactOriginalRecord(r.admission.Record, op)
	if err != nil {
		return OriginalAdmission{}, err
	}
	newly := r.admission.NewlyAdmitted && !r.claimed
	r.claimed = true
	return OriginalAdmission{Record: record, NewlyAdmitted: newly}, nil
}
func (r *OriginalBoundedPhaseReservation) prepareOutsideGate(ctx context.Context, op OriginalEffectOperation) error {
	r.mu.Lock()
	if r.bound == nil || !reflect.DeepEqual(op, *r.bound) || r.attempted {
		r.mu.Unlock()
		return originalEffectError("PREPARED_NODE_READBACK_ONLY", true, false)
	}
	r.attempted = true
	r.mu.Unlock()
	if r.transport.AssertOriginalPreparedNodeTransportCurrent(ctx) != nil {
		return originalEffectError("PREPARED_NODE_TRANSPORT_UNAVAILABLE", false, false)
	}
	if err := mediaContextCurrent(ctx); err != nil {
		return err
	}
	detached, err := cloneOriginalOperation(op)
	if err != nil {
		return err
	}
	// Attempt is irreversible locally. Lost response never permits redispatch.
	admission, err := r.transport.ReserveOriginalPreparedNode(ctx, detached)
	if err != nil {
		return originalEffectError("PREPARED_NODE_RESERVATION_UNKNOWN", true, false)
	}
	record, err := exactOriginalRecord(admission.Record, op)
	if err != nil {
		return err
	}
	if admission.NewlyAdmitted && record.State != OriginalOperationUnknown {
		return originalEffectError("INVALID_ORIGINAL_ADMISSION", true, false)
	}
	if r.transport.AssertOriginalPreparedNodeTransportCurrent(ctx) != nil {
		return originalEffectError("PREPARED_NODE_RESERVATION_UNKNOWN", true, false)
	}
	if err = mediaContextCurrent(ctx); err != nil {
		return originalEffectError("PREPARED_NODE_RESERVATION_UNKNOWN", true, false)
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	r.admission = OriginalAdmission{Record: record, NewlyAdmitted: admission.NewlyAdmitted}
	r.ready = true
	return nil
}

type OriginalBoundedPhases struct {
	participant                                     *OriginalEffectParticipant
	reservation                                     *OriginalBoundedPhaseReservation
	publication                                     OriginalPreparedPublicationPort
	busy                                            atomic.Bool
	firstAttempted, firstCommitted, followUncertain atomic.Bool
	invalid                                         atomic.Bool
}

// Composition binds one existing participant to the SAME prepared reservation
// instance and fixed publication source. No per-call phase/proof producer swap.
func NewOriginalBoundedPhases(participant *OriginalEffectParticipant, reservation *OriginalBoundedPhaseReservation, publication OriginalPreparedPublicationPort) (*OriginalBoundedPhases, error) {
	if participant == nil || participant.effect == nil || participant.coordinator == nil || participant.reservation == nil || originalPortMissing(participant.reservation.mapper) || participant.readback == nil || originalPortMissing(participant.readback.port) || reservation == nil || originalPortMissing(reservation.transport) || originalPortMissing(publication) {
		return nil, originalEffectError("PREPARED_PHASE_SOURCE_UNAVAILABLE", false, false)
	}
	actual, ok := participant.reservation.port.(*OriginalBoundedPhaseReservation)
	if !ok || actual != reservation {
		return nil, originalEffectError("PREPARED_RESERVATION_MISMATCH", false, false)
	}
	op, err := cloneOriginalOperation(participant.operation)
	if err != nil {
		return nil, err
	}
	reservation.mu.Lock()
	defer reservation.mu.Unlock()
	if reservation.bound != nil {
		return nil, originalEffectError("PREPARED_RESERVATION_ALREADY_BOUND", false, false)
	}
	reservation.bound = &op
	return &OriginalBoundedPhases{participant: participant, reservation: reservation, publication: publication}, nil
}
func (p *OriginalBoundedPhases) enter(ctx context.Context) (func(), error) {
	if p == nil || p.participant == nil || originalPortMissing(p.publication) {
		return nil, originalEffectError("PREPARED_PHASE_SOURCE_UNAVAILABLE", false, false)
	}
	if ctx == nil {
		return nil, originalEffectError("PREPARED_PHASE_CONTEXT_UNAVAILABLE", false, false)
	}
	if marked, _ := ctx.Value(mediaCoordinationContext{p.participant.coordinator}).(bool); marked {
		p.invalid.Store(true)
		return nil, mediaCoordinationError("REENTRANT_TRANSACTION", false)
	}
	if err := mediaContextCurrent(ctx); err != nil {
		return nil, err
	}
	if err := mediaContextCurrent(p.participant.effect.capturedContext); err != nil {
		return nil, err
	}
	if p.invalid.Load() {
		return nil, originalEffectError("PREPARED_BOUNDARY_INVALID", true, false)
	}
	if !p.busy.CompareAndSwap(false, true) {
		p.invalid.Store(true)
		return nil, originalEffectError("PREPARED_PHASE_BUSY", false, false)
	}
	return func() { p.busy.Store(false) }, nil
}
func clonePreparedPublication(value OriginalPreparedEffectPublication) (OriginalPreparedEffectPublication, error) {
	op, err := cloneOriginalOperation(value.Operation)
	if err != nil {
		return OriginalPreparedEffectPublication{}, err
	}
	snapshot, err := cloneMediaSnapshot(MediaAuthoritySnapshot{Browser: value.Browser})
	if err != nil {
		return OriginalPreparedEffectPublication{}, err
	}
	value.Operation = op
	value.Browser = snapshot.Browser
	return value, nil
}
func (p *OriginalBoundedPhases) localCurrent(ctx context.Context) error {
	if p.invalid.Load() {
		return originalEffectError("PREPARED_BOUNDARY_INVALID", true, false)
	}
	if err := mediaContextCurrent(ctx); err != nil {
		return err
	}
	if err := mediaContextCurrent(p.participant.effect.capturedContext); err != nil {
		return err
	}
	original, err := cloneOriginalOperation(p.participant.operation)
	if err != nil {
		return err
	}
	if p.publication.AssertOriginalPreparedPublicationCurrent(ctx, original) != nil {
		return originalEffectError("PREPARED_PUBLICATION_UNAVAILABLE", true, false)
	}
	if p.participant.reservation.mapper.AssertOriginalNodeMappingCurrent(ctx) != nil {
		return originalEffectError("NODE_MAPPING_UNAVAILABLE", true, false)
	}
	if p.reservation.transport.AssertOriginalPreparedNodeTransportCurrent(ctx) != nil {
		return originalEffectError("PREPARED_NODE_TRANSPORT_UNAVAILABLE", true, false)
	}
	// Current may cross time/cancellation. No expiry or context is renewed.
	now := p.participant.coordinator.now()
	end, err := protocolTime(original.Session.ExpiresAt)
	if err != nil || !end.After(now) || !original.Action.ExpiresAt.After(now) {
		return originalEffectError("PREPARED_ORIGINAL_EXPIRED", true, false)
	}
	if err = mediaContextCurrent(p.participant.effect.capturedContext); err != nil {
		return err
	}
	return mediaContextCurrent(ctx)
}

// All publication acquisition, actual getter and network happen BEFORE gate.
// State is accepted only from fixed reader; actual product Store must still
// recheck its own mapped/intent-admitted phase under its final owned lock.
func (p *OriginalBoundedPhases) readPublicationOutsideGate(ctx context.Context, state string) error {
	if err := p.localCurrent(ctx); err != nil {
		return err
	}
	publication, err := p.publication.ReadOriginalPreparedPublication(ctx, p.participant.operation.ID)
	if err != nil {
		return originalEffectError("PREPARED_PUBLICATION_UNAVAILABLE", false, false)
	}
	frozen, err := clonePreparedPublication(publication)
	if err != nil || frozen.WorkID != p.participant.operation.ID || frozen.State != state || !reflect.DeepEqual(frozen.Operation, p.participant.operation) || !reflect.DeepEqual(frozen.Browser, p.participant.effect.captured.Browser) {
		return originalEffectError("PREPARED_PUBLICATION_MISMATCH", false, false)
	}
	return p.localCurrent(ctx)
}

// First durably reserves through actual Node transport OUTSIDE gate, then calls
// existing participant.Execute exactly once. Inside that gate its original
// reservation consumes only the prepared full ACK before bounded Store commit.
func (p *OriginalBoundedPhases) First(ctx context.Context, commit func(context.Context) error) error {
	release, err := p.enter(ctx)
	if err != nil {
		return err
	}
	defer release()
	if commit == nil {
		return originalEffectError("PREPARED_COMMIT_UNAVAILABLE", false, false)
	}
	if !p.firstAttempted.CompareAndSwap(false, true) {
		p.invalid.Store(true)
		return originalEffectError("PREPARED_FIRST_READBACK_ONLY", true, false)
	}
	if err = p.readPublicationOutsideGate(ctx, "mapped"); err != nil {
		return err
	}
	if err = p.reservation.prepareOutsideGate(ctx, p.participant.operation); err != nil {
		return err
	}
	// Node ACK is not a Go commit/revoke atomic fence. Final current stays closed.
	calls := 0
	_, err = p.participant.Execute(ctx, func(local context.Context, op OriginalEffectOperation) error {
		if !reflect.DeepEqual(op, p.participant.operation) {
			return originalEffectError("PREPARED_PUBLICATION_MISMATCH", true, false)
		}
		if err := p.localCurrent(local); err != nil {
			return err
		}
		return p.runCallbackBoundary(local, directOriginalBoundedInvoker, func(scoped context.Context) error {
			if err := p.localCurrent(scoped); err != nil {
				return err
			}
			calls++
			return commit(scoped)
		})
	})
	if err != nil {
		return originalEffectError("PREPARED_FIRST_UNCONFIRMED", true, calls > 0)
	}
	if calls != 1 {
		return originalEffectError("PREPARED_FIRST_READBACK_ONLY", true, false)
	}
	p.firstCommitted.Store(true)
	return nil
}

// Follow is a fresh LOCAL bounded current capture of the SAME original lease,
// epoch/full authority metadata, Session/grant/action/Node mapping. No Node
// transport/reservation/nonce replay/renew/rebind/provider/getter occurs in gate.
func (p *OriginalBoundedPhases) Follow(ctx context.Context, commit func(context.Context) error) error {
	release, err := p.enter(ctx)
	if err != nil {
		return err
	}
	defer release()
	if commit == nil {
		return originalEffectError("PREPARED_COMMIT_UNAVAILABLE", false, false)
	}
	if !p.firstCommitted.Load() {
		return originalEffectError("PREPARED_FIRST_NOT_COMMITTED", true, false)
	}
	if p.followUncertain.Load() {
		return originalEffectError("PREPARED_FOLLOW_READBACK_ONLY", true, false)
	}
	if err = p.readPublicationOutsideGate(ctx, "intent-admitted"); err != nil {
		return err
	}
	original := p.participant
	effect, err := original.coordinator.Capture(ctx, original.operation.Session, original.effect.captured.Browser)
	if err != nil {
		return err
	}
	if effect.epoch != original.effect.epoch || !reflect.DeepEqual(effect.captured, original.effect.captured) {
		return originalEffectError("PREPARED_ORIGINAL_LEASE_CHANGED", true, false)
	}
	effect.capturedContext = original.effect.capturedContext
	entered := false
	err = effect.Execute(ctx, func(local context.Context) error {
		if err := p.localCurrent(local); err != nil {
			return err
		}
		return p.runCallbackBoundary(local, directOriginalBoundedInvoker, func(scoped context.Context) error {
			if err := p.localCurrent(scoped); err != nil {
				return err
			}
			entered = true
			return commit(scoped)
		})
	})
	if err != nil {
		if entered {
			p.followUncertain.Store(true)
		}
		return originalEffectError("PREPARED_FOLLOW_UNCONFIRMED", true, entered)
	}
	return nil
}

// Exact Cloud protected source phase names, without importing owned Cloud types.
func (p *OriginalBoundedPhases) ExecuteOriginalPreparedPhase(ctx context.Context, phase string, commit func(context.Context) error) error {
	switch phase {
	case "intent":
		return p.First(ctx, commit)
	case "follow":
		return p.Follow(ctx, commit)
	}
	return originalEffectError("PREPARED_PHASE_NOT_ENABLED", false, false)
}

// AssertLocalCurrent is a pure captured-association/custody/finite/context guard
// for the original owned Store's final save boundary. It does not acquire gate,
// read publication/Store, reserve, contact Node or attest a remote current root.
// Atomic local effect still requires ExecuteOriginalPreparedPhase holding the
// actual SAME original writer gate before the product lock, plus owned guards.
func (p *OriginalBoundedPhases) AssertLocalCurrent(ctx context.Context) error {
	if p == nil || p.participant == nil || originalPortMissing(p.publication) {
		return originalEffectError("PREPARED_PHASE_SOURCE_UNAVAILABLE", false, false)
	}
	return p.localCurrent(ctx)
}

// OriginalBoundedPhaseInvoker is a bounded ORIGINAL executor, not a verifier or
// source capability. It MUST invoke exactly once synchronously using exact ctx.
// This adapter cannot preempt an arbitrary never-returning Go function. Sources
// violating that bounded contract must not be installed as production ports.
type OriginalBoundedPhaseInvoker func(context.Context, func(context.Context) error) error

func directOriginalBoundedInvoker(ctx context.Context, callback func(context.Context) error) error {
	return callback(ctx)
}

// Exposes the strict callback window for an actual owned fixed executor wrapper.
// No permission/current/registration is supplied by this invocation function.
func (p *OriginalBoundedPhases) ExecuteOriginalPreparedPhaseVia(ctx context.Context, phase string, invoke OriginalBoundedPhaseInvoker, commit func(context.Context) error) error {
	if p == nil || invoke == nil || commit == nil {
		return originalEffectError("PREPARED_COMMIT_UNAVAILABLE", false, false)
	}
	return p.ExecuteOriginalPreparedPhase(ctx, phase, func(gated context.Context) error {
		return p.runCallbackBoundary(gated, invoke, commit)
	})
}
func (p *OriginalBoundedPhases) runCallbackBoundary(parent context.Context, invoke OriginalBoundedPhaseInvoker, commit func(context.Context) error) (err error) {
	scoped, cancel := context.WithCancel(parent)
	defer cancel()
	var mu sync.Mutex
	closed, invalid, active, called, settled := false, false, false, false, false
	var result error
	done := make(chan struct{})
	invalidate := func() { p.invalid.Store(true) }
	callback := func(actual context.Context) (callbackErr error) {
		mu.Lock()
		if closed || called || actual != scoped || p.invalid.Load() {
			invalid = true
			mu.Unlock()
			invalidate()
			return originalEffectError("PREPARED_CALLBACK_INVALID", true, false)
		}
		called = true
		active = true
		mu.Unlock()
		defer func() {
			if recovered := recover(); recovered != nil {
				callbackErr = originalEffectError("PREPARED_CALLBACK_PANIC", true, true)
				invalidate()
			}
			mu.Lock()
			result = callbackErr
			active = false
			settled = true
			close(done)
			mu.Unlock()
		}()
		if callbackErr = p.localCurrent(actual); callbackErr != nil {
			return callbackErr
		}
		return commit(actual)
	}
	completed := false
	defer func() {
		if !completed {
			mu.Lock()
			closed = true
			invalid = true
			running := active
			mu.Unlock()
			invalidate()
			cancel()
			// Never release authority gate over an already-running Store callback.
			// A callback ignoring cancellation cannot be safely forcibly preempted.
			if running {
				<-done
			}
		}
	}()
	invokeErr := invoke(scoped, callback)
	mu.Lock()
	closed = true
	running := active
	if !called || !settled || running {
		invalid = true
	}
	bad := invalid || p.invalid.Load()
	mu.Unlock()
	cancel()
	if bad {
		invalidate()
	}
	// Async return before its callback settled is invalid, but wait for a started
	// callback to settle before releasing the real original authority gate.
	if running {
		<-done
	}
	mu.Lock()
	callbackResult := result
	bad = bad || invalid || p.invalid.Load() || !called || !settled
	mu.Unlock()
	completed = true
	if bad {
		return originalEffectError("PREPARED_CALLBACK_INVALID", true, called)
	}
	if callbackResult != nil {
		invalidate()
		return callbackResult
	}
	return invokeErr
}
