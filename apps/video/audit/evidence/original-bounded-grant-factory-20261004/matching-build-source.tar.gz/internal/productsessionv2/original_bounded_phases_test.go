package productsessionv2

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"reflect"
	"testing"
	"time"
)

// COORDINATION MODELS ONLY: snapshots/ACKs are not registered production source,
// durable Node proof, enrollment, transport or original Cloud Store evidence.
type boundedPublicationModel struct {
	coordinator *MediaAuthorityCoordinator
	value       OriginalPreparedEffectPublication
	reads       int
	unavailable bool
	currentHook func(context.Context)
	readHook    func(context.Context)
}

func (m *boundedPublicationModel) ReadOriginalPreparedPublication(ctx context.Context, work string) (OriginalPreparedEffectPublication, error) {
	m.reads++
	if marked, _ := ctx.Value(mediaCoordinationContext{m.coordinator}).(bool); marked {
		return OriginalPreparedEffectPublication{}, errors.New("getter inside authority gate")
	}
	if m.readHook != nil {
		m.readHook(ctx)
	}
	if m.unavailable || work != m.value.WorkID {
		return OriginalPreparedEffectPublication{}, errors.New("model missing published preparation")
	}
	return m.value, nil
}
func (m *boundedPublicationModel) AssertOriginalPreparedPublicationCurrent(ctx context.Context, _ OriginalEffectOperation) error {
	if m.currentHook != nil {
		m.currentHook(ctx)
	}
	if m.unavailable {
		return errors.New("model unavailable")
	}
	return nil
}

type boundedTransportModel struct {
	coordinator       *MediaAuthorityCoordinator
	journal           *originalParticipantModel
	calls             int
	unavailable, lost bool
	afterReserve      func(context.Context)
}

func (m *boundedTransportModel) AssertOriginalPreparedNodeTransportCurrent(context.Context) error {
	if m.unavailable {
		return errors.New("model transport source unavailable")
	}
	return nil
}
func (m *boundedTransportModel) ReserveOriginalPreparedNode(ctx context.Context, op OriginalEffectOperation) (OriginalAdmission, error) {
	m.calls++
	if marked, _ := ctx.Value(mediaCoordinationContext{m.coordinator}).(bool); marked {
		return OriginalAdmission{}, errors.New("Node transport inside authority gate")
	}
	result, err := m.journal.AdmitOriginalUnknown(ctx, op)
	if m.afterReserve != nil {
		m.afterReserve(ctx)
	}
	if m.lost {
		return OriginalAdmission{}, errors.New("model response lost")
	}
	return result, err
}
func boundedModel(t *testing.T) (*OriginalBoundedPhases, *boundedPublicationModel, *boundedTransportModel, *mediaCoordinatorModel, *MediaAuthorityWriter) {
	t.Helper()
	c, writer, authority, session := mediaModel(t)
	now := c.now()
	browser := &BrowserGrant{Identity: BrowserIdentity{Account: session.Account, Subject: session.Account, Generation: 3, ExpiresAt: now.Add(time.Hour)}, ExpiresAt: now.Add(time.Hour), Audience: "ynx:finance:identity", Scopes: []string{"identity:read"}, GrantToken: "MODEL-NOT-GRANT", CSRF: "MODEL-NOT-CSRF"}
	authority.snapshot.Browser = browser
	journal := &originalParticipantModel{}
	transport := &boundedTransportModel{coordinator: c, journal: journal}
	prepared, err := NewOriginalBoundedPhaseReservation(transport)
	if err != nil {
		t.Fatal(err)
	}
	reservation, err := prepared.Reservation(journal)
	if err != nil {
		t.Fatal(err)
	}
	readback, err := NewAuthenticatedOriginalReadback(journal)
	if err != nil {
		t.Fatal(err)
	}
	wire := []byte("original model wire")
	digest := sha256.Sum256(wire)
	action := ActionAuthorization{Nonce: "model-original-nonce", BodyDigest: hex.EncodeToString(digest[:]), SessionBinding: session.SessionBinding, ExpiresAt: now.Add(time.Minute)}
	participant, err := NewOriginalEffectParticipant(context.Background(), c, session, browser, action, "original-model-work", "POST", "/model-original-route", wire, reservation, readback)
	if err != nil {
		t.Fatal(err)
	}
	operation, _ := participant.OriginalOperation()
	snapshot, _ := clonePreparedPublication(OriginalPreparedEffectPublication{WorkID: operation.ID, State: "mapped", Operation: operation, Browser: browser})
	publication := &boundedPublicationModel{coordinator: c, value: snapshot}
	phases, err := NewOriginalBoundedPhases(participant, prepared, publication)
	if err != nil {
		t.Fatal(err)
	}
	return phases, publication, transport, authority, writer
}
func TestOriginalBoundedPhasesMissingFixedSourceClosed(t *testing.T) {
	var transport *boundedTransportModel
	if _, err := NewOriginalBoundedPhaseReservation(transport); err == nil {
		t.Fatal("missing transport")
	}
	p, _, _, _, _ := boundedModel(t)
	incomplete := &OriginalEffectParticipant{effect: p.participant.effect, coordinator: p.participant.coordinator}
	if _, err := NewOriginalBoundedPhases(incomplete, p.reservation, p.publication); err == nil {
		t.Fatal("incomplete participant accepted")
	}
	var publication *boundedPublicationModel
	if _, err := NewOriginalBoundedPhases(p.participant, p.reservation, publication); err == nil {
		t.Fatal("missing publication")
	}
	other, _ := NewOriginalBoundedPhaseReservation(&boundedTransportModel{})
	if _, err := NewOriginalBoundedPhases(p.participant, other, p.publication); err == nil {
		t.Fatal("foreign reservation")
	}
	if _, err := NewOriginalBoundedPhases(p.participant, p.reservation, p.publication); err == nil {
		t.Fatal("reservation reused by a new participant")
	}
}
func TestOriginalBoundedPhasesFirstFollowOutsideGetterTransport(t *testing.T) {
	p, publication, transport, _, _ := boundedModel(t)
	calls := 0
	commit := func(ctx context.Context) error {
		calls++
		reads := publication.reads
		if err := p.AssertLocalCurrent(ctx); err != nil {
			t.Fatal(err)
		}
		if publication.reads != reads {
			t.Fatal("local Store guard invoked getter")
		}
		if marked, _ := ctx.Value(mediaCoordinationContext{p.participant.coordinator}).(bool); !marked {
			t.Fatal("bounded commit outside authority gate")
		}
		if transport.journal.stored == nil || transport.journal.stored.State != OriginalOperationUnknown {
			t.Fatal("commit before original Node UNKNOWN")
		}
		publication.value.State = "intent-admitted"
		return nil
	}
	if err := p.ExecuteOriginalPreparedPhase(context.Background(), "intent", commit); err != nil {
		t.Fatal(err)
	}
	if err := p.ExecuteOriginalPreparedPhase(context.Background(), "follow", commit); err != nil {
		t.Fatal(err)
	}
	if err := p.Follow(context.Background(), commit); err != nil {
		t.Fatal(err)
	}
	if calls != 3 || transport.calls != 1 || transport.journal.admissionCalls != 1 || publication.reads != 3 {
		t.Fatalf("calls=%d reserves=%d admission=%d getters=%d", calls, transport.calls, transport.journal.admissionCalls, publication.reads)
	}
	if err := p.First(context.Background(), commit); err == nil || calls != 3 {
		t.Fatal("first re-dispatch")
	}
	if err := p.ExecuteOriginalPreparedPhase(context.Background(), "provider", commit); err == nil {
		t.Fatal("unknown phase enabled")
	}
}
func TestOriginalBoundedPhasesPublishedBindingAndStateClosed(t *testing.T) {
	for _, kind := range []string{"not-mapped", "work", "node", "wire", "session", "action", "browser", "source"} {
		t.Run(kind, func(t *testing.T) {
			p, publication, transport, _, _ := boundedModel(t)
			switch kind {
			case "not-mapped":
				publication.value.State = "caller-mapped"
			case "work":
				publication.value.WorkID = "foreign"
			case "node":
				publication.value.Operation.NodeRequestDigest = publication.value.Operation.WireDigest
			case "wire":
				publication.value.Operation.WireDigest = "foreign"
			case "session":
				publication.value.Operation.Session.DeviceID = "foreign"
			case "action":
				publication.value.Operation.Action.Nonce = "foreign"
			case "browser":
				publication.value.Browser.GrantToken = "foreign"
			case "source":
				publication.unavailable = true
			}
			calls := 0
			err := p.First(context.Background(), func(context.Context) error { calls++; return nil })
			if err == nil || calls != 0 || transport.calls != 0 {
				t.Fatalf("%s first admitted", kind)
			}
		})
	}
}
func TestOriginalBoundedPhasesLostOrExistingNodeReplyReadOnly(t *testing.T) {
	for _, kind := range []string{"lost", "existing", "cancel-after-reserve", "revoke-after-reserve"} {
		t.Run(kind, func(t *testing.T) {
			p, _, transport, source, writer := boundedModel(t)
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			if kind == "lost" {
				transport.lost = true
			}
			if kind == "existing" {
				operation, _ := p.participant.OriginalOperation()
				transport.journal.stored = &OriginalOperationRecord{Operation: operation, State: OriginalOperationUnknown}
			}
			transport.afterReserve = func(context.Context) {
				switch kind {
				case "cancel-after-reserve":
					cancel()
				case "revoke-after-reserve":
					if err := writer.Mutate(context.Background(), func(context.Context) error { source.snapshot.Revoked = true; return nil }); err != nil {
						t.Fatal(err)
					}
				}
			}
			calls := 0
			commit := func(context.Context) error { calls++; return nil }
			if err := p.First(ctx, commit); err == nil || calls != 0 {
				t.Fatal("lost/existing/cancelled/revoked operation dispatched")
			}
			if err := p.First(context.Background(), commit); err == nil || calls != 0 || transport.calls != 1 {
				t.Fatal("UNKNOWN reserve resent")
			}
			if err := p.Follow(context.Background(), commit); err == nil || calls != 0 {
				t.Fatal("follow without bounded first")
			}
			if transport.journal.stored == nil || transport.journal.stored.State != OriginalOperationUnknown {
				t.Fatal("pending original Node obligation lost")
			}
		})
	}
}
func TestOriginalBoundedPhasesFollowSameOriginalLease(t *testing.T) {
	for _, kind := range []string{"epoch", "metadata", "state", "full-op", "source", "expired"} {
		t.Run(kind, func(t *testing.T) {
			p, publication, transport, source, writer := boundedModel(t)
			if err := p.First(context.Background(), func(context.Context) error { publication.value.State = "intent-admitted"; return nil }); err != nil {
				t.Fatal(err)
			}
			switch kind {
			case "epoch":
				if err := writer.Mutate(context.Background(), func(context.Context) error { return nil }); err != nil {
					t.Fatal(err)
				}
			case "metadata":
				source.snapshot.MembershipRevision++
			case "state":
				publication.value.State = "mapped"
			case "full-op":
				publication.value.Operation.NodeOperationID = "foreign"
			case "source":
				transport.unavailable = true
			case "expired":
				p.participant.coordinator.now = func() time.Time { return p.participant.operation.Action.ExpiresAt }
			}
			calls := 0
			if err := p.Follow(context.Background(), func(context.Context) error { calls++; return nil }); err == nil || calls != 0 || transport.calls != 1 {
				t.Fatalf("changed %s follow/new reservation", kind)
			}
		})
	}
}
func TestOriginalBoundedPhasesFinalPureCurrentExpiryAndCancel(t *testing.T) {
	for _, phase := range []string{"intent", "follow"} {
		for _, kind := range []string{"action", "session", "cancel"} {
			t.Run(phase+"/"+kind, func(t *testing.T) {
				p, publication, _, _, _ := boundedModel(t)
				if phase == "follow" {
					if err := p.First(context.Background(), func(context.Context) error { publication.value.State = "intent-admitted"; return nil }); err != nil {
						t.Fatal(err)
					}
				}
				ctx, cancel := context.WithCancel(context.Background())
				defer cancel()
				publication.currentHook = func(current context.Context) {
					if marked, _ := current.Value(mediaCoordinationContext{p.participant.coordinator}).(bool); marked {
						switch kind {
						case "cancel":
							cancel()
						case "action":
							p.participant.coordinator.now = func() time.Time { return p.participant.operation.Action.ExpiresAt }
						case "session":
							end, _ := protocolTime(p.participant.operation.Session.ExpiresAt)
							p.participant.coordinator.now = func() time.Time { return end }
						}
					}
				}
				calls := 0
				if err := p.ExecuteOriginalPreparedPhase(ctx, phase, func(context.Context) error { calls++; return nil }); err == nil || calls != 0 {
					t.Fatal("final Current crossed finite/context boundary")
				}
			})
		}
	}
}
func TestOriginalBoundedPhasesFollowUncertainNeverRetries(t *testing.T) {
	p, publication, transport, _, _ := boundedModel(t)
	if err := p.First(context.Background(), func(context.Context) error { publication.value.State = "intent-admitted"; return nil }); err != nil {
		t.Fatal(err)
	}
	calls := 0
	if err := p.Follow(context.Background(), func(context.Context) error { calls++; return errors.New("original product outcome uncertain") }); err == nil {
		t.Fatal("uncertainty hidden")
	}
	if err := p.Follow(context.Background(), func(context.Context) error { calls++; return nil }); err == nil || calls != 1 || transport.calls != 1 {
		t.Fatal("uncertain follow replayed")
	}
}
func TestOriginalBoundedPhasesContextReentryAndAliases(t *testing.T) {
	p, publication, _, _, _ := boundedModel(t)
	if err := p.First(context.Background(), func(ctx context.Context) error {
		if err := p.Follow(ctx, func(context.Context) error { t.Fatal("recursive callback"); return nil }); err == nil {
			t.Fatal("reentry")
		}
		return nil
	}); err == nil {
		t.Fatal("swallowed reentry left phase successful")
	}
	if err := p.AssertLocalCurrent(context.Background()); err == nil {
		t.Fatal("reentry was not sticky")
	}
	copied, err := clonePreparedPublication(publication.value)
	if err != nil {
		t.Fatal(err)
	}
	copied.Operation.Session.Scopes[0] = "alias"
	copied.Browser.Scopes[0] = "alias"
	if reflect.DeepEqual(copied, publication.value) {
		t.Fatal("publication alias not detached")
	}
}

func TestOriginalBoundedPhasesACKMismatchAndFirstCommitUncertainty(t *testing.T) {
	for _, kind := range []string{"node", "body", "session", "commit-error"} {
		t.Run(kind, func(t *testing.T) {
			p, publication, transport, _, _ := boundedModel(t)
			if kind != "commit-error" {
				transport.journal.corrupt = func(record *OriginalOperationRecord) {
					switch kind {
					case "node":
						record.Operation.NodeRequestDigest = record.Operation.WireDigest
					case "body":
						record.Operation.ActionBodyDigest = "foreign"
					case "session":
						record.Operation.Session.DeviceID = "foreign"
					}
				}
			}
			calls := 0
			err := p.First(context.Background(), func(context.Context) error {
				calls++
				publication.value.State = "intent-admitted"
				return errors.New("original commit uncertain")
			})
			if err == nil {
				t.Fatal("ACK/commit uncertainty hidden")
			}
			if kind == "commit-error" {
				originalFailure(t, err, "PREPARED_FIRST_UNCONFIRMED", true, true)
				if calls != 1 {
					t.Fatal("first callback not entered")
				}
			} else if calls != 0 {
				t.Fatal("wrong full ACK entered commit")
			}
			if err = p.Follow(context.Background(), func(context.Context) error { calls++; return nil }); err == nil {
				t.Fatal("follow after uncertain first")
			}
			if transport.calls != 1 {
				t.Fatal("uncertain first reserve repeated")
			}
		})
	}
}

func TestOriginalBoundedPhasesStickyCallbackExecutor(t *testing.T) {
	for _, kind := range []string{"swallowed-double", "none", "changed-context", "late", "async-unsettled", "swallowed-commit-error"} {
		t.Run(kind, func(t *testing.T) {
			p, publication, transport, _, _ := boundedModel(t)
			calls := 0
			entered := make(chan struct{})
			var late func(context.Context) error
			var lateCtx context.Context
			invoke := func(ctx context.Context, callback func(context.Context) error) error {
				switch kind {
				case "swallowed-double":
					first := callback(ctx)
					_ = callback(ctx)
					return first
				case "none":
					return nil
				case "changed-context":
					_ = callback(context.Background())
					return nil
				case "late":
					late = callback
					lateCtx = ctx
					return nil
				case "async-unsettled":
					go func() { _ = callback(ctx) }()
					<-entered
					return nil
				case "swallowed-commit-error":
					_ = callback(ctx)
					return nil
				}
				return nil
			}
			commit := func(ctx context.Context) error {
				calls++
				publication.value.State = "intent-admitted"
				if kind == "async-unsettled" {
					close(entered)
					<-ctx.Done()
					return ctx.Err()
				}
				if kind == "swallowed-commit-error" {
					return errors.New("actual original commit failed")
				}
				return nil
			}
			err := p.ExecuteOriginalPreparedPhaseVia(context.Background(), "intent", invoke, commit)
			if err == nil {
				t.Fatal("invalid/swallowed callback released successful phase")
			}
			expected := 0
			if kind == "swallowed-double" || kind == "async-unsettled" || kind == "swallowed-commit-error" {
				expected = 1
			}
			if calls != expected {
				t.Fatalf("calls%d expected%d", calls, expected)
			}
			if kind == "late" {
				if err = late(lateCtx); err == nil || calls != 0 {
					t.Fatal("late callback entered commit")
				}
			}
			if err = p.Follow(context.Background(), func(context.Context) error { calls++; return nil }); err == nil || calls != expected {
				t.Fatal("invalid phase allowed follow")
			}
			if transport.calls != 1 {
				t.Fatal("invalid phase re-reserved")
			}
		})
	}
}
func TestOriginalBoundedPhasesNeverSettledPortCancellation(t *testing.T) {
	p, _, transport, _, _ := boundedModel(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	entered := make(chan struct{})
	finished := make(chan error, 1)
	calls := 0
	go func() {
		finished <- p.ExecuteOriginalPreparedPhaseVia(ctx, "intent", func(bound context.Context, _ func(context.Context) error) error {
			close(entered)
			<-bound.Done()
			return nil
		}, func(context.Context) error { calls++; return nil })
	}()
	<-entered
	cancel()
	if err := <-finished; err == nil || calls != 0 || transport.calls != 1 {
		t.Fatal("unsettled/cancelled port allowed commit")
	}
	if err := p.AssertLocalCurrent(context.Background()); err == nil {
		t.Fatal("unsettled port not sticky closed")
	}
}
func TestOriginalBoundedPhasesScopedContextClosedAfterReturn(t *testing.T) {
	p, publication, _, _, _ := boundedModel(t)
	var captured context.Context
	if err := p.First(context.Background(), func(ctx context.Context) error {
		captured = ctx
		publication.value.State = "intent-admitted"
		return nil
	}); err != nil {
		t.Fatal(err)
	}
	if captured == nil || captured.Err() == nil {
		t.Fatal("bounded callback context remained live")
	}
	if err := p.First(context.Background(), func(context.Context) error { t.Fatal("double first commit"); return nil }); err == nil {
		t.Fatal("repeat first")
	}
	if err := p.AssertLocalCurrent(context.Background()); err == nil {
		t.Fatal("repeat first error was not sticky")
	}
	if err := p.Follow(context.Background(), func(context.Context) error { t.Fatal("follow after repeat first"); return nil }); err == nil {
		t.Fatal("sticky repeat first allowed follow")
	}
}

func TestOriginalBoundedPhasesSwallowedCommitErrorStickyCurrent(t *testing.T) {
	for _, phase := range []string{"intent", "follow"} {
		t.Run(phase, func(t *testing.T) {
			p, publication, transport, _, _ := boundedModel(t)
			calls := 0
			if phase == "follow" {
				if err := p.First(context.Background(), func(context.Context) error {
					calls++
					publication.value.State = "intent-admitted"
					return nil
				}); err != nil {
					t.Fatal(err)
				}
			}
			commitError := errors.New("original Store commit uncertain")
			err := p.ExecuteOriginalPreparedPhaseVia(context.Background(), phase,
				func(ctx context.Context, callback func(context.Context) error) error {
					if actual := callback(ctx); actual != commitError {
						t.Fatalf("original error changed: %v", actual)
					}
					return nil // The original executor incorrectly swallows the actual commit error.
				}, func(context.Context) error {
					calls++
					publication.value.State = "intent-admitted"
					return commitError
				})
			if err == nil {
				t.Fatal("swallowed commit error accepted")
			}
			expected := 1
			if phase == "follow" {
				expected = 2
			}
			if calls != expected {
				t.Fatal("original callback count changed")
			}
			if err := p.AssertLocalCurrent(context.Background()); err == nil {
				t.Fatal("commit error did not latch Current closed")
			}
			if err := p.Follow(context.Background(), func(context.Context) error { calls++; return nil }); err == nil {
				t.Fatal("follow after commit uncertainty accepted")
			}
			if err := p.First(context.Background(), func(context.Context) error { calls++; return nil }); err == nil {
				t.Fatal("first after commit uncertainty accepted")
			}
			if calls != expected || transport.calls != 1 || transport.journal.admissionCalls != 1 {
				t.Fatal("uncertain operation re-dispatched or re-admitted")
			}
			if transport.journal.stored == nil || transport.journal.stored.State != OriginalOperationUnknown {
				t.Fatal("original UNKNOWN obligation rolled back or promoted")
			}
		})
	}
}
