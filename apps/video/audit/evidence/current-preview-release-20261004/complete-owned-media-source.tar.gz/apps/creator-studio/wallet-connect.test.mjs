import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { attachWalletLifecycle, discoverWalletProviders } from "./wallet-auth.js";
import {
  createStandardWalletConnectState,
  reduceStandardWalletConnectState,
  STANDARD_WALLET_CONNECT_STATE_AUTHORITY,
} from "./standard-wallet-connect-state.js";

const load = name => readFile(new URL(name, import.meta.url), "utf8");
const accountA = "0x1111111111111111111111111111111111111111";

test("Creator consumes the exact shared Standard Wallet reducer boundary", () => {
  assert.equal(STANDARD_WALLET_CONNECT_STATE_AUTHORITY.sourceCommit, "98c6d5d784d212df8981a53b17118a511e246ad2");
  let state = createStandardWalletConnectState();
  state = reduceStandardWalletConnectState(state, { type: "BEGIN", pendingIntent: "creatorwalletintent1" });
  state = reduceStandardWalletConnectState(state, { type: "PROVIDER_SELECTED", provider: { request() {} }, providerKind: "ynx-wallet" });
  state = reduceStandardWalletConnectState(state, { type: "ACCOUNT_APPROVED", account: accountA });
  state = reduceStandardWalletConnectState(state, { type: "CHAIN_CONFIRMED", chainId: "0x1917" });
  assert.equal(state.status, "connected");

  state = reduceStandardWalletConnectState(state, { type: "PRIVATE_SESSION_DEGRADED" });
  assert.equal(state.status, "connected");
  assert.equal(state.privateService, "degraded");
  state = reduceStandardWalletConnectState(state, { type: "OPEN_CHOOSER" });
  assert.equal(state.chooserMode, "connection-details");
  assert.deepEqual(state.chooserActions, ["disconnect", "switch-account", "close"]);
  state = reduceStandardWalletConnectState(state, { type: "DISCONNECT" });
  assert.equal(state.status, "idle");
  assert.equal(state.account, null);
});

test("late legacy injection is re-read after ethereum#initialized", async () => {
  const events = new EventTarget();
  const documentEvents = new EventTarget();
  const scope = {
    document: Object.assign(documentEvents, { readyState: "complete" }),
    addEventListener: events.addEventListener.bind(events),
    removeEventListener: events.removeEventListener.bind(events),
    dispatchEvent: events.dispatchEvent.bind(events),
    setTimeout,
  };
  setTimeout(() => {
    scope.ethereum = { isMetaMask: true, request() {} };
    events.dispatchEvent(new Event("ethereum#initialized"));
  }, 25);
  const found = await discoverWalletProviders(scope, 250);
  assert.equal(found.metamask?.kind, "metamask");
  assert.equal(found.metamask?.name, "MetaMask");
  assert.ok(found.diagnostics.eip6963RequestDispatches >= 2);
});

test("empty accountsChanged disconnects instead of becoming an invalid-account error", () => {
  const listeners = new Map();
  const provider = {
    on(type, listener) { listeners.set(type, listener); },
    removeListener(type) { listeners.delete(type); },
  };
  let observed = null;
  const lifecycle = attachWalletLifecycle(provider, { onAccountsChanged(accounts) { observed = accounts; } });
  listeners.get("accountsChanged")([]);
  assert.deepEqual(observed, []);
  lifecycle.detach();
});

test("wallet UI uses distinct image assets and same-tab provider flow", async () => {
  const [html, app, auth, callback, release, ynxLogo, metamaskLogo] = await Promise.all([
    load("app.html"), load("app.js"), load("wallet-auth.js"), load("wallet-callback.html"), load("product-release.json"), load("assets/ynx-wallet.svg"), load("assets/metamask.svg"),
  ]);
  assert.match(html, /id="wallet-details"/);
  assert.match(html, /id="wallet-switch-account"/);
  assert.match(html, /id="wallet-detail-disconnect"/);
  assert.match(app, /assets\/ynx-wallet\.svg/);
  assert.match(app, /assets\/metamask\.svg/);
  assert.match(ynxLogo, /YNX Wallet/);
  assert.match(metamaskLogo, /MetaMask/);
  assert.match(auth, /ethereum#initialized/);
  assert.match(auth, /DISCOVERY_PHASES_MS[^\n]*250[^\n]*750[^\n]*1500/);
  assert.doesNotMatch(`${app.split('const productStatus=')[0]}\n${auth}`, /window\.open|ynxwallet:|target=["']_blank/i);
  assert.doesNotMatch(app, /location\.(assign|replace)\(/);
  assert.match(callback, /src="..\/wallet-callback\.js"/);
  assert.doesNotMatch(callback, /gateway_session|redirect_to|<script>/);
  const releaseState = JSON.parse(release);
  if (releaseState.currentSourceBoundPublic) {
    assert.match(releaseState.sourceCommit, /^[0-9a-f]{40}$/);
    assert.equal(releaseState.publicRuntime.sourceCommit, releaseState.sourceCommit);
    assert.equal(releaseState.deployedPublic, true);
  }
  if (releaseState.publicRuntime?.installedWalletApprovalVerified && releaseState.publicRuntime.currentForRuntime !== false) {
    assert.equal(releaseState.publicRuntime.verificationScope.creatorSource, releaseState.publicRuntime.sourceCommit);
    assert.match(releaseState.publicRuntime.verificationScope.source, /Wallet owner/);
  }
  assert.equal(releaseState.candidate?.installedWalletApprovalVerified ?? false, false);
});
