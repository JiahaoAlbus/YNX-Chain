# YNX Wallet reviewer sources

Exact source commit: c5df9a9a1cc2a22ba7623ba2b85da138b66c3b5f. No Git repository or developer dependencies are needed. The reference archive was generated with Node 26.7.0 and npm 11.19.0; record the actual versions used for review. From this extracted directory:

```sh
npm ci --prefix packages/wallet-auth --no-audit --no-fund
npm ci --prefix apps/wallet-web --no-audit --no-fund
node apps/wallet-web/store/rebuild-reviewer-source.mjs
```

The rebuild checks every submitted source file, both fixed authority hashes and every generated output byte against the normal Git build. Outputs are in reviewer-output; the result is rebuild-result.json. Dependencies are installed from the included integrity-locked npm manifests, not symlinked to a developer checkout. See apps/wallet-web/store/submission-build.md for disclosure and review boundaries. No store submission or signing is performed.
