(() => {
  "use strict";
  if(globalThis.__YNX_CONTENT_BRIDGE_V1__===true)return;
  Object.defineProperty(globalThis,"__YNX_CONTENT_BRIDGE_V1__",{value:true});
  const PAGE_REQUEST="YNX_PAGE_REQUEST_V1",PAGE_RESPONSE="YNX_PAGE_RESPONSE_V1",PAGE_EVENT="YNX_PAGE_EVENT_V1",RUNTIME_REQUEST="YNX_DAPP_REQUEST_V1",RUNTIME_EVENT="YNX_DAPP_EVENT_V1",DOCUMENT_PROBE="YNX_DAPP_DOCUMENT_PROBE_V1",VERSION=1,TIMEOUT_MS=120000;
  const METHODS=new Set(["eth_chainId","eth_accounts","eth_requestAccounts","wallet_getPermissions","wallet_requestPermissions","wallet_addEthereumChain","wallet_switchEthereumChain","wallet_revokePermissions","personal_sign","eth_signTypedData_v4","eth_sendTransaction","ynx_disconnect","ynx_getDurabilityModel","ynx_getTransactionDurability","ynx_getFeeModel","ynx_getBalanceDetails","eth_blockNumber","eth_call","eth_estimateGas","eth_gasPrice","eth_getBalance","eth_getBlockByHash","eth_getBlockByNumber","eth_getCode","eth_getLogs","eth_getStorageAt","eth_getTransactionByHash","eth_getTransactionCount","eth_getTransactionReceipt","eth_maxPriorityFeePerGas","net_version","web3_clientVersion","ynx_requestProductSessionV2"]);
  const EVENTS=new Set(["connect","accountsChanged","chainChanged","disconnect"]),pending=new Set(),timers=new Map(),requestIdPattern=/^ynx-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u,noncePattern=/^[0-9a-f]{64}$/u,targetOrigin=location.origin;
  const freshNonce=()=>Array.from(crypto.getRandomValues(new Uint8Array(32)),value=>value.toString(16).padStart(2,"0")).join("");
  let active=true,documentNonce=freshNonce();
  const current=()=>active&&window.top===window&&location.origin===targetOrigin&&document.prerendering!==true;
  const clearPending=()=>{for(const timer of timers.values())clearTimeout(timer);timers.clear();pending.clear()};
  window.addEventListener("pagehide",()=>{active=false;documentNonce=null;clearPending()});
  window.addEventListener("pageshow",event=>{if(active&&event?.persisted!==true)return;clearPending();documentNonce=freshNonce();active=true});
  const reply=(requestId,response)=>window.postMessage({type:PAGE_RESPONSE,version:VERSION,requestId,origin:targetOrigin,...response},targetOrigin);
  window.addEventListener("message",(event)=>{
    const data=event.data;
    if(!current()||event.source!==window||event.origin!==targetOrigin||data?.type!==PAGE_REQUEST||data?.version!==VERSION)return;
    if(!Object.keys(data).every(key=>["type","version","requestId","origin","method","params"].includes(key)))return;
    if(data.origin!==targetOrigin||!requestIdPattern.test(data.requestId||"")||!METHODS.has(data.method)||(data.params!==undefined&&!Array.isArray(data.params))||(data.method==="ynx_requestProductSessionV2"&&(!Array.isArray(data.params)||data.params.length!==1||typeof data.params[0]!=="string"||data.params[0].length>16384))||pending.has(data.requestId))return;
    pending.add(data.requestId);
    const activation=documentNonce,timer=setTimeout(()=>{timers.delete(data.requestId);if(current()&&documentNonce===activation&&pending.delete(data.requestId))reply(data.requestId,{ok:false,error:{code:"BRIDGE_TIMEOUT",message:"Wallet extension request timed out."}})},TIMEOUT_MS);timers.set(data.requestId,timer);
    chrome.runtime.sendMessage({type:RUNTIME_REQUEST,version:VERSION,requestId:data.requestId,origin:targetOrigin,method:data.method,params:data.params,deadlineAt:Date.now()+TIMEOUT_MS,documentNonce:activation})
      .then((response)=>{if(!current()||documentNonce!==activation||!pending.delete(data.requestId))return;clearTimeout(timer);timers.delete(data.requestId);reply(data.requestId,response?.ok===true?{ok:true,result:response.result}:{ok:false,error:response?.error||{code:"PROVIDER_REQUEST_FAILED",message:"Wallet request failed closed."}})})
      .catch(()=>{if(!current()||documentNonce!==activation||!pending.delete(data.requestId))return;clearTimeout(timer);timers.delete(data.requestId);reply(data.requestId,{ok:false,error:{code:"RUNTIME_UNAVAILABLE",message:"Wallet extension runtime is unavailable."}})});
  });
  chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
    if(sender?.id!==chrome.runtime.id||!current())return;
    if(message?.type===DOCUMENT_PROBE){if(Object.keys(message).sort().join(",")!=="challenge,origin,type,version"||message.version!==VERSION||message.origin!==targetOrigin||typeof message.challenge!=="string"||!noncePattern.test(message.challenge))return;sendResponse({version:VERSION,origin:targetOrigin,challenge:message.challenge,documentNonce});return false}
    if(message?.type!==RUNTIME_EVENT||message.version!==VERSION||message.origin!==targetOrigin||message.documentNonce!==documentNonce||!EVENTS.has(message.event))return;
    window.postMessage({type:PAGE_EVENT,version:VERSION,origin:targetOrigin,event:message.event,payload:message.payload},targetOrigin);
  });
})();
