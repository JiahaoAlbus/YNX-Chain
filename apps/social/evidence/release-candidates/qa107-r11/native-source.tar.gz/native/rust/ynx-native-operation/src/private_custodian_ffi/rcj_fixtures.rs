//! cfg(test) only: PUBLIC ciphertext-shaped C store, never keys or authority.
use super::*;
#[derive(Debug,PartialEq,Eq)]pub(crate)struct Snapshot{pub store:usize,pub ticket:usize,pub receipt:usize,pub first:Option<i32>,pub unknown:bool,pub discharged:bool,pub closed:bool,pub cleanup_required:bool,pub counts:[u32;6]}
pub(crate)fn original(command:jni::refs::Global<jni::objects::JObject<'static>>,input_java:jni::refs::Global<jni::objects::JObject<'static>>,path:&std::ffi::CStr)->LocalGenesisReservation{
 let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("PUBLIC metadata"));
 let mut owner=LocalGenesisReservation::retain_with_java_command(input,command,input_java);
 let mut ids=[1;32];ids[16..].fill(2);owner.local_ids=Some(ids);owner.id_binding=OriginalIdBinding::Acknowledged;
 owner.reserve_original_context_path(path).unwrap();
 let pq=PqRecord{version:1,aad_size:1,aad:[7;7168],nonce:[0;12],cipher:[0;4912]};
 let classic=ClassicRecord{version:1,aad_size:1,cipher_size:17,aad:[8;7168],nonce:[0;12],cipher:[0;272]};
 let wire=encode_pair(&pq,&classic).unwrap();let pn=u32::from_be_bytes(wire[12..16].try_into().unwrap())as usize;
 let pair=predevice_port::PairBorrow::from_slices(&wire[20+pn..],&wire[20..20+pn],&wire,&[8],&[7]);
 let store=owner.predevice.as_mut().unwrap();store.claim_generation().unwrap();store.commit(&pair).unwrap();owner
}
impl RecoveryLoan<'_>{
 pub(crate)fn rcj_snapshot(&self)->Snapshot{self.0.predevice.as_ref().unwrap().rcj_state()}
 pub(crate)fn rcj_arm_cleanup_failure(&mut self){self.0.predevice.as_mut().unwrap().rcj_arm_cleanup_failure();}
 pub(crate)fn rcj_arm_close_child(&mut self){self.0.predevice.as_mut().unwrap().rcj_arm_close_child();}
 pub(crate)fn rcj_drop_close_child(&mut self){self.0.predevice.as_mut().unwrap().rcj_drop_close_child();}
}
