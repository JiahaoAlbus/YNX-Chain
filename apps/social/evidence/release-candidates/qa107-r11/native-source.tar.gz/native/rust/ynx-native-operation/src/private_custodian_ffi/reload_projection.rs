//! Typed UNVERIFIED protected-record metadata. No source/device capability.
//! Parse selected frozen C AAD, then compare its exact C canonical encodings.
use super::*;
const PQ_DOMAIN:&[u8]=b"YNX/SOCIAL/OWN-PQ-STORAGE/V1";
pub(super)struct UnverifiedProjection{pub(super)binding:StorageBinding,pub(super)pq_public:[u8;2592]}
impl UnverifiedProjection{
 pub(super)fn decode(wire:&[u8],input:&LocalGenesisInput)->Result<Self,CustodyError>{
  let(pq,classic)=decode_pair(wire)?;
  let aad=&pq.aad[..pq.aad_size as usize];let mut c=Cursor{bytes:aad,at:0};
  if c.take(PQ_DOMAIN.len())?!=PQ_DOMAIN||c.n()?!=1||c.n()?!=87{return Err(CustodyError::Pair)}
  let generation=u64::from_be_bytes(c.take(8)?.try_into().map_err(|_|CustodyError::Bounds)?);
  let alias_n=c.n()?;if alias_n>256{return Err(CustodyError::Bounds)}let alias=c.take(alias_n)?;
  let classic_public:[u8;33]=c.take(33)?.try_into().map_err(|_|CustodyError::Bounds)?;
  let pq_public:[u8;2592]=c.take(2592)?.try_into().map_err(|_|CustodyError::Bounds)?;
  let association_n=c.n()?;if !(1..=4096).contains(&association_n){return Err(CustodyError::Bounds)}let association=c.take(association_n)?;
  if c.at!=aad.len()||generation!=input.generation||alias!=input.alias.as_bytes()||association!=input.association{return Err(CustodyError::Pair)}
  libsignal_protocol::IdentityKey::decode(&classic_public).map_err(|_|CustodyError::Pair)?;
  let mut owned=Vec::new();owned.try_reserve_exact(association.len()).map_err(|_|CustodyError::Memory)?;owned.extend_from_slice(association);
  let binding=StorageBinding::new(&input.alias,generation,classic_public,owned)?;
  let mut canonical=[0;7168];let mut written=0;let b=binding.ffi();
  let result=unsafe{veil_own_aad(&b,pq_public.as_ptr(),canonical.as_mut_ptr(),&mut written)};
  if result!=0||written>canonical.len()||written!=aad.len()||canonical[..written]!=*aad{return Err(CustodyError::Pair)}
  written=0;let length=(classic.cipher_size as usize).checked_sub(16).ok_or(CustodyError::Bounds)?;
  let result=unsafe{veil_classic_aad(&b,pq_public.as_ptr(),length,canonical.as_mut_ptr(),&mut written)};
  if result!=0||written>canonical.len()||written!=classic.aad_size as usize||canonical[..written]!=classic.aad[..written]{return Err(CustodyError::Pair)}
  Ok(Self{binding,pq_public}) // Valid structural bytes, still NOT authenticated.
 }
}
#[cfg(test)]mod tests{
 use super::*;
 fn input()->LocalGenesisInput{LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7,8],30).unwrap_or_else(|_|panic!("public input"))}
 fn records()->(PqRecord,ClassicRecord){
  let input=input();let mut public=[0;33];public[0]=5;public[1]=9;
  let binding=StorageBinding::new(&input.alias,1,public,input.association).unwrap();let b=binding.ffi();let pk=[7;2592];
  let mut pq=PqRecord{version:1,aad_size:0,aad:[0;7168],nonce:[0;12],cipher:[0;4912]};let mut n=0;
  assert_eq!(unsafe{veil_own_aad(&b,pk.as_ptr(),pq.aad.as_mut_ptr(),&mut n)},0);pq.aad_size=n as u32;
  let mut classic=ClassicRecord{version:1,aad_size:0,cipher_size:86,aad:[0;7168],nonce:[0;12],cipher:[0;272]};
  assert_eq!(unsafe{veil_classic_aad(&b,pk.as_ptr(),70,classic.aad.as_mut_ptr(),&mut n)},0);classic.aad_size=n as u32;(pq,classic)
 }
 #[test]fn r57_selected_c_aad_projects_unverified_owner_without_keys(){let(pq,classic)=records();let wire=encode_pair(&pq,&classic).unwrap();let p=UnverifiedProjection::decode(&wire,&input()).unwrap_or_else(|_|panic!("canonical C bytes"));assert_eq!(p.pq_public,[7;2592]);let mut owner=NativeOwnKeyCustody::reserve_existing_reload(p.binding);owner.load_unverified_pair(&wire,p.pq_public).unwrap();assert!(owner.platform.is_null()&&owner.pq.is_null()&&owner.classic.is_none()&&!owner.crypto_attempted);assert_eq!(owner.journal.as_deref(),Some(wire.as_slice()));assert!(matches!(owner.reload_both(),Err(CustodyError::Phase)));}
 #[test]fn r57_wrong_profile_generation_and_association_refuse(){let(mut pq,classic)=records();pq.aad[PQ_DOMAIN.len()+7]=86;assert!(UnverifiedProjection::decode(&encode_pair(&pq,&classic).unwrap(),&input()).is_err());let(pq,classic)=records();let wire=encode_pair(&pq,&classic).unwrap();let mut other=input();other.generation=2;assert!(UnverifiedProjection::decode(&wire,&other).is_err());other=input();other.association.push(9);assert!(UnverifiedProjection::decode(&wire,&other).is_err());}
 #[test]fn r57_classic_aad_and_trailing_bytes_not_canonical(){let(pq,mut classic)=records();classic.aad[0]^=1;assert!(UnverifiedProjection::decode(&encode_pair(&pq,&classic).unwrap(),&input()).is_err());let(pq,classic)=records();let mut wire=encode_pair(&pq,&classic).unwrap();wire.push(0);assert!(UnverifiedProjection::decode(&wire,&input()).is_err());}
 #[test]fn r57_missing_capture_retains_attempt_and_typed_cause(){let mut owner=LocalGenesisReservation::retain(input());assert!(matches!(owner.stage_original_captured_reload(),Err(CustodyError::Unknown)));let first=owner.reload_failure.as_ref().unwrap();assert_eq!(first.stage,ReloadStage::Capture);assert!(matches!(first.cause,CustodyError::Phase));assert!(owner.reload_attempted&&owner.custody.is_none());assert!(matches!(owner.stage_original_captured_reload(),Err(CustodyError::Unknown)));assert!(matches!(owner.generate_after_durable_reserve(),Err(CustodyError::Unknown)));}
}
