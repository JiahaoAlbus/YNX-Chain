//! Distinct same-controller cold custody; no resurrection of old command/ack.
#![allow(unsafe_code)]
use super::*;
use jni::objects::{JObject,JValue,JString,JByteArray};
thread_local!{static OPEN_WINDOW:std::cell::Cell<bool>=const{std::cell::Cell::new(false)};static PATH_BUSY:std::cell::Cell<bool>=const{std::cell::Cell::new(false)};}
struct Flags{open:bool,executing:bool}
impl Drop for Flags{fn drop(&mut self){OPEN_WINDOW.with(|v|v.set(self.open));LOCAL_EXECUTING.with(|v|v.set(self.executing));}}
fn callback<T>(open:bool,f:impl FnOnce()->jni::errors::Result<T>)->jni::errors::Result<T>{
 let old=LOCAL_EXECUTING.with(|v|v.replace(true));assert!(!old,"cold callback reentry");
 let _flags=Flags{open:OPEN_WINDOW.with(|v|v.replace(open)),executing:old};f()
}
fn with_cold<T>(f:impl FnOnce(&mut crate::private_custodian_ffi::ColdRecovery)->T)->Result<T,i32>{
 LOCAL.with(|v|{let mut l=v.try_borrow_mut().map_err(|_|BUSY)?;let o=l.as_mut().ok_or(NOT_OPEN)?;
  let cold=o.controller.cold_mut().map_err(controller_error)?;Ok(f(cold))})
}
// Modes3/4 are restricted disposal of retained custody, never new business.
fn actor_gate(o:&LocalOwner,mode:u8)->Result<(),i32>{
 if mode<=2{if o.status==PANIC_RETAINED{return Err(PANIC_RETAINED)}if o.closed{return Err(34)}}
 Ok(())
}
fn with_mode<T>(mode:u8,f:impl FnOnce(&mut crate::private_custodian_ffi::ColdRecovery)->T)->Result<T,i32>{
 LOCAL.with(|v|{let mut l=v.try_borrow_mut().map_err(|_|BUSY)?;let o=l.as_mut().ok_or(NOT_OPEN)?;
  actor_gate(o,mode)?;let cold=o.controller.cold_mut().map_err(controller_error)?;Ok(f(cold))})
}
fn fail(code:i32)->i32{
 LOCAL.with(|v|{if let Ok(mut l)=v.try_borrow_mut(){if let Some(o)=l.as_mut(){if let Ok(c)=o.controller.cold_mut(){c.fail(code);}if o.status!=25{o.status=16}o.exit=ExitEligibility::Missing;if o.status==25{return 25}}}code})
}
fn same(env:&mut jni::Env<'_>,lease:&JObject<'_>,context:Option<&JObject<'_>>)->jni::errors::Result<bool>{
 match with_cold(|c|->jni::errors::Result<bool>{Ok(env.is_same_object(lease,c.lease.as_obj())?&&match context{Some(x)=>env.is_same_object(x,c.context.as_obj())?,None=>true})}){Ok(v)=>v,Err(_)=>Ok(false)}
}
fn check(env:&mut jni::Env<'_>,lease:&JObject<'_>,context:&JObject<'_>)->jni::errors::Result<bool>{
 if !same(env,lease,Some(context))?{return Ok(false)}
 callback(false,||env.call_method(lease,jni::jni_str!("checkForNative"),jni::jni_sig!("()V"),&[]))?;
 Ok(!env.exception_check()&&same(env,lease,Some(context))?)
}
unsafe fn begin(raw:*mut jni::sys::JNIEnv,ctx:jni::sys::jobject,obj:jni::sys::jobject)->i32{
 if let Err(e)=thread_check(false){return e}
 let ready=LOCAL.with(|v|{let l=v.try_borrow().map_err(|_|BUSY)?;let o=l.as_ref().ok_or(NOT_OPEN)?;if o.closed||o.status==16||o.status==25{return Err(o.status)}o.controller.cold_install_ready().map_err(controller_error)});
 if let Err(e)=ready{return e}if raw.is_null()||ctx.is_null()||obj.is_null(){return 43}
 let mut u=unsafe{jni::EnvUnowned::from_raw(raw)};
 let out=u.with_env_no_catch(|env|->jni::errors::Result<i32>{
  if env.exception_check(){return Ok(16)}
  let lease=unsafe{JObject::from_raw(env,obj)};let context=unsafe{JObject::from_raw(env,ctx)};
  if !env.is_instance_of(&lease,jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyColdRecoveryLease"))?{return Ok(43)}
  callback(false,||env.call_method(&lease,jni::jni_str!("checkForNative"),jni::jni_sig!("()V"),&[]))?;
  let retained=callback(false,||env.call_method(&lease,jni::jni_str!("contextForNative"),jni::jni_sig!("()Landroid/content/Context;"),&[]))?.l()?;
  if !env.is_same_object(&retained,&context)?{return Ok(43)}
  let alias=callback(false,||env.call_method(&lease,jni::jni_str!("aliasForNative"),jni::jni_sig!("()Ljava/lang/String;"),&[]))?.l()?;
  let length=callback(false,||env.call_method(&alias,jni::jni_str!("length"),jni::jni_sig!("()I"),&[]))?.i()?;
  if length!=53{return Ok(43)}let alias=JString::cast_local(env,alias)?;let alias:String=env.get_string(&alias)?.into();
  let generation=callback(false,||env.call_method(&lease,jni::jni_str!("generationForNative"),jni::jni_sig!("()J"),&[]))?.j()?;
  let a=callback(false,||env.call_method(&lease,jni::jni_str!("associationForNative"),jni::jni_sig!("()[B"),&[]))?.l()?;
  let a=JByteArray::cast_local(env,a)?;if !(1..=4096).contains(&env.get_array_length(&a)?){return Ok(43)}let association=env.convert_byte_array(&a)?;
  let ids=callback(false,||env.call_method(&lease,jni::jni_str!("originalIdsForNative"),jni::jni_sig!("()[B"),&[]))?.l()?;
  let ids=JByteArray::cast_local(env,ids)?;if env.get_array_length(&ids)?!=32{return Ok(43)}let ids=env.convert_byte_array(&ids)?;let ids:[u8;32]=match ids.try_into(){Ok(v)=>v,Err(_)=>return Ok(43)};
  callback(false,||env.call_method(&lease,jni::jni_str!("checkForNative"),jni::jni_sig!("()V"),&[]))?;
  let original=match crate::private_custodian_ffi::ColdRecovery::retain(alias,generation,association,ids,env.new_global_ref(&lease)?,env.new_global_ref(&context)?){Ok(v)=>v,Err(_)=>return Ok(43)};
  let installed=LOCAL.with(|v|{let mut l=v.try_borrow_mut().map_err(|_|BUSY)?;let o=l.as_mut().ok_or(NOT_OPEN)?;
   if o.closed{return Err(34)}match o.controller.install_cold(original){Ok(())=>{o.exit=ExitEligibility::Missing;Ok(())},Err((e,_unopened))=>Err(controller_error(e))}});
  if let Err(e)=installed{return Ok(e)}
  let code=callback(true,||env.call_method(&lease,jni::jni_str!("openExistingForNative"),jni::jni_sig!("()I"),&[]))?.i()?;
  if code!=180{return Ok(fail(16))}
  if !check(env,&lease,&context)?{return Ok(fail(16))}
  Ok(match with_mode(0,|c|if c.opened(){c.status()}else{c.fail(16)}){Ok(v)=>v,Err(e)=>e})
 }).into_outcome();
 finish(out)
}
fn finish(out:jni::Outcome<i32,jni::errors::Error>)->i32{match out{jni::Outcome::Ok(v)=>v,jni::Outcome::Err(_)=>fail(16),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}}
unsafe fn open_path(raw:*mut jni::sys::JNIEnv,obj:jni::sys::jobject,path:jni::sys::jstring)->i32{
 // Sole exception to callback reentry fence: exact synchronous owned path port.
 if !OPEN_WINDOW.with(|v|v.get())||!LOCAL_EXECUTING.with(|v|v.get()){return 43}
 if OWNER_THREAD.lock().ok().and_then(|v|*v)!=Some(std::thread::current().id()){return WRONG_THREAD}
 if PATH_BUSY.with(|v|v.replace(true)){return BUSY}
 struct Reset;impl Drop for Reset{fn drop(&mut self){PATH_BUSY.with(|v|v.set(false));}}let _reset=Reset;
 if raw.is_null()||obj.is_null()||path.is_null(){return fail(16)}
 let mut u=unsafe{jni::EnvUnowned::from_raw(raw)};
 let out=u.with_env_no_catch(|env|->jni::errors::Result<i32>{
  if env.exception_check(){return Ok(fail(16))}
  let lease=unsafe{JObject::from_raw(env,obj)};let path=unsafe{JString::from_raw(env,path)};
  if !same(env,&lease,None)?{return Ok(43)}
  env.call_method(&lease,jni::jni_str!("checkForNative"),jni::jni_sig!("()V"),&[])?;
  let n=env.call_method(&path,jni::jni_str!("length"),jni::jni_sig!("()I"),&[])?.i()?;if !(1..=4096).contains(&n){return Ok(fail(16))}
  let value:String=env.get_string(&path)?.into();let value=match std::ffi::CString::new(value){Ok(v)=>v,Err(_)=>return Ok(fail(16))};
  if !same(env,&lease,None)?{return Ok(fail(16))}
  let code=with_mode(1,|c|c.open(&value)).unwrap_or_else(|e|e);
  env.call_method(&lease,jni::jni_str!("checkForNative"),jni::jni_sig!("()V"),&[])?;
  if !same(env,&lease,None)?{return Ok(fail(16))}Ok(with_mode(0,|_|code).unwrap_or_else(|e|e))
 }).into_outcome();finish(out)
}
unsafe fn action(raw:*mut jni::sys::JNIEnv,ctx:jni::sys::jobject,obj:jni::sys::jobject,mode:u8)->i32{
 if let Err(e)=thread_check(false){return e}
 let admitted=LOCAL.with(|v|{let l=v.try_borrow().map_err(|_|BUSY)?;actor_gate(l.as_ref().ok_or(NOT_OPEN)?,mode)});
 if let Err(e)=admitted{return e}if raw.is_null()||ctx.is_null()||obj.is_null(){return 43}
 let mut u=unsafe{jni::EnvUnowned::from_raw(raw)};
 let out=u.with_env_no_catch(|env|->jni::errors::Result<i32>{
  if env.exception_check(){return Ok(fail(16))}
  let lease=unsafe{JObject::from_raw(env,obj)};let context=unsafe{JObject::from_raw(env,ctx)};
  if !check(env,&lease,&context)?{return Ok(43)}
  if mode==4{
   if !with_cold(|c|c.releasable()).unwrap_or(false){return Ok(16)}
   callback(false,||env.call_method(&lease,jni::jni_str!("releaseForNative"),jni::jni_sig!("()V"),&[]))?;
   if env.exception_check()||!same(env,&lease,Some(&context))?{return Ok(fail(16))}
   return Ok(LOCAL.with(|v|{let Ok(mut l)=v.try_borrow_mut()else{return BUSY};let Some(o)=l.as_mut()else{return NOT_OPEN};match o.controller.retire_cold(){Ok(())=>184,Err(e)=>controller_error(e)}}))
  }
  let code=with_mode(mode,|c|match mode{0=>c.status(),1=>c.advance(false),2=>c.advance(true),3=>c.cleanup(),_=>43}).unwrap_or_else(|e|e);
  if !check(env,&lease,&context)?{return Ok(fail(16))}Ok(with_mode(mode,|_|code).unwrap_or_else(|e|e))
 }).into_outcome();finish(out)
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeColdRecoveryAbiVersion(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i32{1}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeBeginColdRecovery(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,x:jni::sys::jobject,l:jni::sys::jobject)->i32{boundary(||unsafe{begin(e,x,l)})}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeOpenColdDatabase(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,l:jni::sys::jobject,p:jni::sys::jstring)->i32{boundary(||unsafe{open_path(e,l,p)})}
macro_rules! entry{($name:ident,$mode:expr)=>{#[unsafe(no_mangle)]pub extern "system" fn $name(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,x:jni::sys::jobject,l:jni::sys::jobject)->i32{boundary(||unsafe{action(e,x,l,$mode)})}};}
entry!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeObserveColdRecovery,0);
entry!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeReconcileColdRecovery,1);
entry!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeDischargeColdRecovery,2);
entry!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeCleanupColdRecovery,3);
entry!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeReleaseColdRecovery,4);
#[cfg(test)]mod cold_install_controls{
 use super::*;
 #[test]fn cold_install_controls_path_outside_window_no_actor(){assert_eq!(unsafe{open_path(std::ptr::null_mut(),std::ptr::null_mut(),std::ptr::null_mut())},43);}
}
#[cfg(test)]mod cold_panic_controls{
 use super::*;use std::ffi::{CString,c_void};
 #[link(name="jvm")]unsafe extern "C"{fn JNI_CreateJavaVM(vm:*mut *mut jni::sys::JavaVM,env:*mut *mut c_void,args:*mut c_void)->jni::sys::jint;}
 #[test]fn cold_panic_controls_actual_jvm_actor_boundary_and_cleanup(){
  let cp=CString::new(format!("-Djava.class.path={}",std::env::var("VEIL_COLD_PANIC_CLASSES").expect("PUBLIC classpath"))).unwrap();
  let mut opt=jni::sys::JavaVMOption{optionString:cp.as_ptr()as *mut _,extraInfo:std::ptr::null_mut()};
  let mut args=jni::sys::JavaVMInitArgs{version:jni::sys::JNI_VERSION_1_8,nOptions:1,options:&mut opt,ignoreUnrecognized:jni::sys::JNI_FALSE};
  let mut vm=std::ptr::null_mut();let mut raw=std::ptr::null_mut();
  assert_eq!(unsafe{JNI_CreateJavaVM(&mut vm,&mut raw,&mut args as *mut _ as *mut c_void)},0);
  let raw=raw as *mut jni::sys::JNIEnv;let mut u=unsafe{jni::EnvUnowned::from_raw(raw)};
  let out=u.with_env_no_catch(|env|->jni::errors::Result<()>{
   unsafe{env.register_native_methods(jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyPrivateCommand"),&[
    jni::NativeMethod::from_raw_parts(jni::jni_str!("nativeOpenColdDatabase"),jni::jni_str!("(Lcom/ynx/social/matrix/VeilOwnKeyColdRecoveryLease;Ljava/lang/String;)I"),Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeOpenColdDatabase as *mut c_void),
    jni::NativeMethod::from_raw_parts(jni::jni_str!("nativeReconcileColdRecovery"),jni::jni_str!("(Landroid/content/Context;Lcom/ynx/social/matrix/VeilOwnKeyColdRecoveryLease;)I"),Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeReconcileColdRecovery as *mut c_void)
   ])?;}
   assert_eq!(open(),1);
   let context=env.new_object(jni::jni_str!("android/content/Context"),jni::jni_sig!("()V"),&[])?;
   let path=crate::private_custodian_ffi::ColdRecovery::fixture_reserved();let path=env.new_string(path.to_str().unwrap())?;
   let lease=env.new_object(jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyColdRecoveryLease"),jni::jni_sig!("(Landroid/content/Context;Ljava/lang/String;)V"),&[JValue::Object(&context),JValue::Object(&path)])?;
   assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeBeginColdRecovery(raw,std::ptr::null_mut(),context.as_raw(),lease.as_raw()),180);
   let retained=with_cold(|c|c as *mut _ as usize).unwrap();assert_eq!(with_cold(|c|c.fixture_first()).unwrap(),None);
   env.set_field(&lease,jni::jni_str!("reenter"),jni::jni_sig!("Z"),JValue::Bool(true))?;
   assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeObserveColdRecovery(raw,std::ptr::null_mut(),context.as_raw(),lease.as_raw()),180);
   assert_eq!(boundary(||panic!("PUBLIC contained actor panic after installation")),25);
   for _ in 0..2{
    assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeObserveColdRecovery(raw,std::ptr::null_mut(),context.as_raw(),lease.as_raw()),25);
    assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeReconcileColdRecovery(raw,std::ptr::null_mut(),context.as_raw(),lease.as_raw()),25);
    assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeDischargeColdRecovery(raw,std::ptr::null_mut(),context.as_raw(),lease.as_raw()),25);
   }
   assert_eq!(crate::private_custodian_ffi::ColdRecovery::fixture_effect_count(),0);
   assert_eq!(with_cold(|c|c as *mut _ as usize).unwrap(),retained);assert_eq!(with_cold(|c|c.fixture_first()).unwrap(),Some(25));
   env.set_field(&lease,jni::jni_str!("throwCheck"),jni::jni_sig!("Z"),JValue::Bool(true))?;
   assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeCleanupColdRecovery(raw,std::ptr::null_mut(),context.as_raw(),lease.as_raw()),25);
   assert!(env.exception_check());env.exception_clear();
   assert!(!with_cold(|c|c.releasable()).unwrap());assert_eq!(with_cold(|c|c as *mut _ as usize).unwrap(),retained);
   env.set_field(&lease,jni::jni_str!("throwCheck"),jni::jni_sig!("Z"),JValue::Bool(false))?;
   assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeCleanupColdRecovery(raw,std::ptr::null_mut(),context.as_raw(),lease.as_raw()),183);
   assert_eq!(status(),25);assert_eq!(with_cold(|c|c.fixture_first()).unwrap(),Some(25));
   assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeReleaseColdRecovery(raw,std::ptr::null_mut(),context.as_raw(),lease.as_raw()),184);
   assert_eq!(status(),25);assert_eq!(close(),25);
   assert_eq!(crate::private_custodian_ffi::ColdRecovery::fixture_effect_count(),0);
   assert!(env.get_field(&lease,jni::jni_str!("reentryCount"),jni::jni_sig!("I"))?.i()?>0);
   assert_eq!(env.get_field(&lease,jni::jni_str!("closes"),jni::jni_sig!("I"))?.i()?,1);
   assert!(with_cold(|_|()).is_err());Ok(())
  }).into_outcome();
  match out{jni::Outcome::Ok(())=>{},jni::Outcome::Err(e)=>panic!("PUBLIC JVM error {e:?}"),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
  assert_eq!(unsafe{((**vm).v1_4.DestroyJavaVM)(vm)},0);
 }
}
