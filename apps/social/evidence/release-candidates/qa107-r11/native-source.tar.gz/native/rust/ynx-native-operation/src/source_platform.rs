//! Private statically linked platform owning bridge, NOT a grant factory.
//! The normal physical provider is unbound; no fake accepted inputs are made.
#![allow(unsafe_code)]
use crate::staging::platform::{SourcePreparedOwner,SourceOwnerError};
use std::{ffi::c_void,marker::PhantomData,ptr::{self,NonNull},rc::Rc,thread::{self,ThreadId}};
unsafe extern "C"{
 fn ynx_source_client_current(p:*mut c_void,cleanup:i32)->i32;
 fn ynx_source_client_enter(p:*mut c_void)->i32;
 fn ynx_source_client_type4(p:*mut c_void,b:*const u8,n:usize)->i32;
 fn ynx_source_client_close(p:*mut *mut c_void)->i32;
}
#[derive(Debug)]pub(crate)enum Error{Original(SourceOwnerError),Thread,Required,Unknown,Abi,Foreign(i32)}
#[derive(Clone,Copy,PartialEq,Eq)]enum Phase{Acquired,Entered,Unknown,Closed}
pub(crate)struct Borrow<'prepared,'op>{
 handle:Option<NonNull<c_void>>,thread:ThreadId,phase:Phase,
 prepared:PhantomData<&'prepared mut SourcePreparedOwner<'op>>,local:PhantomData<Rc<()>>,
}
pub(crate)struct AcquireFailure<'prepared,'op>{pub(crate)error:Error,pub(crate)retained:Option<Borrow<'prepared,'op>>}
fn status(s:i32)->Result<(),Error>{match s{0=>Ok(()),1=>Err(Error::Required),8=>Err(Error::Unknown),s=>Err(Error::Foreign(s))}}
impl<'prepared,'op>Borrow<'prepared,'op>{
 // The sole constructor takes a genuine retained PreparedOwner. No raw pointer,
 // profile, public DTO or boolean can construct the Rust owner. C statically
 // verifies the actual private Prepared and independent platform enrollment.
 pub(crate)fn acquire(prepared:&'prepared mut SourcePreparedOwner<'op>)->Result<Self,AcquireFailure<'prepared,'op>>{
  let mut out=ptr::null_mut();
  let s=prepared.platform_acquire_private(&mut out).map_err(|e|AcquireFailure{error:Error::Original(e),retained:None})?;
  let handle=NonNull::new(out);
  let phase=if s==0{Phase::Acquired}else{Phase::Unknown};
  let retained=handle.map(|h|Self{handle:Some(h),thread:thread::current().id(),phase,prepared:PhantomData,local:PhantomData});
  match(status(s),retained){
   (Ok(()),Some(owner))=>Ok(owner),
   (Ok(()),None)=>Err(AcquireFailure{error:Error::Abi,retained:None}),
   (Err(error),retained)=>Err(AcquireFailure{error,retained}),
  }
 }
 fn raw(&self)->Result<*mut c_void,Error>{if self.thread!=thread::current().id(){return Err(Error::Thread)}self.handle.map(|p|p.as_ptr()).ok_or(Error::Required)}
 pub(crate)fn current(&mut self)->Result<(),Error>{
  let p=self.raw()?;if self.phase==Phase::Unknown{return Err(Error::Unknown)}
  let result=status(unsafe{ynx_source_client_current(p,0)});
  if result.is_err()&&self.phase==Phase::Entered{self.phase=Phase::Unknown;return Err(Error::Unknown)}result
 }
 pub(crate)fn enter(&mut self)->Result<(),Error>{
  self.current()?;if self.phase!=Phase::Acquired{return Err(Error::Unknown)}
  let p=self.raw()?;self.phase=Phase::Unknown;
  status(unsafe{ynx_source_client_enter(p)})?;self.phase=Phase::Entered;Ok(())
 }
 pub(crate)fn check_type4(&mut self,wire:&[u8])->Result<(),Error>{
  self.current()?;if self.phase!=Phase::Entered||wire.is_empty()||wire.len()>65536{return Err(Error::Required)}
  let p=self.raw()?;let result=status(unsafe{ynx_source_client_type4(p,wire.as_ptr(),wire.len())});
  if result.is_err(){self.phase=Phase::Unknown;return Err(Error::Unknown)}Ok(())
 }
 // Explicit cleanup remains possible after failure/expiry. Closing RAM custody
 // never settles UNKNOWN, deletes original history or permits a second effect.
 pub(crate)fn close(&mut self)->Result<(),Error>{
  if self.handle.is_none(){return Ok(())}let original=self.raw()?;let mut p=original;
  let s=unsafe{ynx_source_client_close(&mut p)};
  if s==0&&p.is_null(){self.handle=None;self.phase=Phase::Closed;return Ok(())}
  self.phase=Phase::Unknown;if p!=original{return Err(Error::Abi)}status(s)?;Err(Error::Abi)
 }
}
impl Drop for Borrow<'_,'_>{fn drop(&mut self){if self.handle.is_some(){std::process::abort();}}}

#[repr(C)]#[derive(Clone,Copy)]struct OriginalBytes{data:*const u8,size:usize}
impl OriginalBytes{fn of(b:&[u8])->Self{Self{data:b.as_ptr(),size:b.len()}}}
#[repr(C)]struct OriginalInput{root:OriginalBytes,registration:OriginalBytes,status:OriginalBytes,source:OriginalBytes,namespace_prefix:OriginalBytes,request:OriginalBytes,nonce:*const u8,nonce_size:usize,status_history:*const OriginalBytes,status_history_count:usize,native_classic:[u8;33],native_pq:[u8;2592],source_nonce:[u8;32],monotonic_deadline_ns:u64}
unsafe extern "C"{fn ynx_source_monotonic_now_v1(out:*mut u64)->i32;fn ynx_source_client_original_acquire(input:*const OriginalInput,out:*mut *mut c_void)->i32;}
#[repr(C)]struct CoreBorrowRequestV2{version:u32,size:u32,purpose:u32,operation:u32,key_uses:u32,required_operations:u32,context_id:u64,context_generation:u64,deadline:u64,intent_digest:[u8;32]}
#[repr(C)]struct OriginalInputV2{rights:CoreBorrowRequestV2,original:OriginalInput}
impl OriginalInputV2{
 fn original_read(original:OriginalInput)->Self{
  use sha2::{Digest,Sha256};
  // This normal entry acquires/reads an EXISTING core. It cannot silently
  // initialize or authorize later mutations. Those need a genuine native plan.
  let intent=unsafe{std::slice::from_raw_parts(original.request.data,original.request.size)};
  Self{rights:CoreBorrowRequestV2{version:2,size:80,purpose:1,operation:3,key_uses:1,required_operations:4,context_id:0,context_generation:0,deadline:original.monotonic_deadline_ns,intent_digest:Sha256::digest(intent).into()},original}
 }
}
unsafe extern "C"{fn ynx_source_client_original_acquire_v2(input:*const OriginalInputV2,out:*mut *mut c_void)->i32;}
fn original_deadline(input:&crate::private_custodian_ffi::OriginalProviderInput<'_>)->Result<u64,Error>{
 // Sample C's monotonic clock BEFORE checking the original remaining window;
 // any intervening delay shortens, rather than renews, the effective budget.
 let mut sampled=0u64;status(unsafe{ynx_source_monotonic_now_v1(&mut sampled)})?;
 let window=input.operation_window().map_err(|_|Error::Required)?;
 let remaining=u64::try_from(window.remaining().map_err(|_|Error::Required)?.as_nanos()).map_err(|_|Error::Abi)?;
 let deadline=sampled.checked_add(remaining).ok_or(Error::Abi)?;input.recheck().map_err(|_|Error::Required)?;Ok(deadline)
}
// This owns only the qualified STATIC provider's returned root. The borrowed
// loan is the original immutable operation, not a reconstructed lifetime.
pub(crate)struct OriginalAdmission<'loan,'op>{handle:Option<NonNull<c_void>>,loan:&'loan crate::private_custodian_ffi::RecoveryLoan<'op>,native_classic:[u8;33],native_pq:[u8;2592],source_nonce:[u8;32],thread:ThreadId,unknown:bool,local:PhantomData<Rc<()>>}
pub(crate)struct OriginalAcquireFailure<'loan,'op>{pub(crate)error:Error,pub(crate)retained:Option<OriginalAdmission<'loan,'op>>}
impl<'loan,'op>OriginalAdmission<'loan,'op>{
 pub(crate)fn acquire(loan:&'loan crate::private_custodian_ffi::RecoveryLoan<'op>)->Result<Self,OriginalAcquireFailure<'loan,'op>>{
  let refused=||OriginalAcquireFailure{error:Error::Required,retained:None};
  let original=loan.original_provider_input().map_err(|_|refused())?;
  // DEVICE keys are read from the live authenticated local custody, never the
  // Source credential or caller frame. This immutable borrow does not grant.
  let pair=loan.public_pair().map_err(|_|refused())?;
  let native_classic=pair.classic;let native_pq=pair.pq;
  let source_nonce=loan.original_source_nonce().map_err(|_|refused())?;
  let bootstrap=original.bootstrap_raw().map_err(|_|refused())?;
  let source=original.source_raw().map_err(|_|refused())?;
  let prefix=original.namespace_prefix().map_err(|_|refused())?;
  let history:Vec<_>=bootstrap.status_history.iter().map(|raw|OriginalBytes::of(raw)).collect();
  let input=OriginalInput{root:OriginalBytes::of(bootstrap.root),registration:OriginalBytes::of(bootstrap.registration),status:OriginalBytes::of(bootstrap.status),source:OriginalBytes::of(source),namespace_prefix:OriginalBytes::of(prefix),request:OriginalBytes::of(bootstrap.request),nonce:bootstrap.nonce.as_ptr(),nonce_size:32,status_history:history.as_ptr(),status_history_count:history.len(),native_classic,native_pq,source_nonce,monotonic_deadline_ns:original_deadline(&original).map_err(|_|refused())?};
  original.recheck().map_err(|_|refused())?;let mut out=ptr::null_mut();
  let s=unsafe{ynx_source_client_original_acquire_v2(&OriginalInputV2::original_read(input),&mut out)};
  let retained=NonNull::new(out).map(|handle|Self{handle:Some(handle),loan,native_classic,native_pq,source_nonce,thread:thread::current().id(),unknown:s!=0,local:PhantomData});
  match(status(s),retained){
   (Ok(()),Some(mut owner))=>match owner.current(){Ok(())=>Ok(owner),Err(error)=>Err(OriginalAcquireFailure{error,retained:Some(owner)})},
   (Ok(()),None)=>Err(OriginalAcquireFailure{error:Error::Unknown,retained:None}),
   (Err(error),retained)=>Err(OriginalAcquireFailure{error,retained}),
  }
 }
 fn native_origin_current(&self)->Result<(),Error>{
  let pair=self.loan.public_pair().map_err(|_|Error::Unknown)?;
  let nonce=self.loan.original_source_nonce().map_err(|_|Error::Unknown)?;
  if pair.classic!=self.native_classic||pair.pq!=self.native_pq||nonce!=self.source_nonce{return Err(Error::Unknown)}
  Ok(())
 }
 pub(crate)fn current(&mut self)->Result<(),Error>{
  if self.thread!=thread::current().id(){return Err(Error::Thread)}if self.unknown{return Err(Error::Unknown)}
  let result=(||{
   self.native_origin_current()?;
   let original=self.loan.original_provider_input().map_err(|_|Error::Unknown)?;
   original.recheck().map_err(|_|Error::Unknown)?;let p=self.handle.ok_or(Error::Required)?;
   status(unsafe{ynx_source_client_current(p.as_ptr(),0)})?;
   original.recheck().map_err(|_|Error::Unknown)?;self.native_origin_current()
  })();
  if result.is_err(){self.unknown=true;}result
 }
 pub(crate)fn close(&mut self)->Result<(),Error>{
  if self.thread!=thread::current().id(){return Err(Error::Thread)}let Some(original)=self.handle else{return Ok(())};let mut p=original.as_ptr();
  let s=unsafe{ynx_source_client_close(&mut p)};if s==0&&p.is_null(){self.handle=None;return Ok(())}self.unknown=true;if p!=original.as_ptr(){return Err(Error::Abi)}status(s)?;Err(Error::Abi)
 }
}
impl Drop for OriginalAdmission<'_,'_>{fn drop(&mut self){if self.handle.is_some(){std::process::abort();}}}

unsafe extern "C"{fn ynx_source_client_original_projection(h:*mut c_void,a:*mut *const c_void,d:*mut *const c_void,history:*mut *const c_void,r:*mut *const c_void)->i32;}
// Sole constructor is a restricted borrow of a genuinely acquired root. Field
// privacy prevents any pointer/profile/status projection from constructing it.
pub(crate)struct AcceptedOriginalBorrow<'owner>{original:crate::private_custodian_ffi::OriginalProviderInput<'owner>,handle:NonNull<c_void>,thread:ThreadId,unknown:std::cell::Cell<bool>,exclusive:PhantomData<&'owner mut c_void>}
impl OriginalAdmission<'_,'_>{
 pub(crate)fn accepted_borrow(&mut self)->Result<AcceptedOriginalBorrow<'_>,Error>{self.current()?;let original=self.loan.original_provider_input().map_err(|_|Error::Unknown)?;Ok(AcceptedOriginalBorrow{original,handle:self.handle.ok_or(Error::Required)?,thread:self.thread,unknown:std::cell::Cell::new(false),exclusive:PhantomData})}
}
impl AcceptedOriginalBorrow<'_>{
 pub(crate)fn current(&self)->Result<(),Error>{if self.thread!=thread::current().id(){return Err(Error::Thread)}if self.unknown.get(){return Err(Error::Unknown)}let result=self.original.recheck().map_err(|_|Error::Unknown).and_then(|_|status(unsafe{ynx_source_client_current(self.handle.as_ptr(),0)})).and_then(|_|self.original.recheck().map_err(|_|Error::Unknown));if result.is_err(){self.unknown.set(true);}result}
 pub(crate)fn projection(&self)->Result<[*const c_void;4],Error>{
  self.current()?;let(mut a,mut d,mut h,mut r)=(ptr::null(),ptr::null(),ptr::null(),ptr::null());
  let result=status(unsafe{ynx_source_client_original_projection(self.handle.as_ptr(),&mut a,&mut d,&mut h,&mut r)}).and_then(|_|self.current());
  if result.is_err(){self.unknown.set(true);}result?;if [a,d,h,r].iter().any(|p|p.is_null()){self.unknown.set(true);return Err(Error::Unknown)}Ok([a,d,h,r])
 }
}

#[repr(C)]struct NativePlanRaw{intent:*const c_void,journal:[*const c_void;32],journal_count:usize,inbox:*const c_void,outbox:*const c_void}
unsafe extern "C"{fn ynx_source_client_original_native_plan(h:*mut c_void,p:*mut NativePlanRaw)->i32;}
// A read-only private projection. It is meaningful ONLY with the retained
// qualified owning root and prepared proof; this value cannot issue a proof.
pub(crate)struct NativePlan{pub(crate)intent:*const c_void,pub(crate)journal:Vec<*const c_void>,pub(crate)inbox:*const c_void,pub(crate)outbox:*const c_void}
impl AcceptedOriginalBorrow<'_>{
 pub(crate)fn native_plan(&self)->Result<NativePlan,Error>{
  self.current()?;let mut raw=NativePlanRaw{intent:ptr::null(),journal:[ptr::null();32],journal_count:0,inbox:ptr::null(),outbox:ptr::null()};
  let result=status(unsafe{ynx_source_client_original_native_plan(self.handle.as_ptr(),&mut raw)}).and_then(|_|self.current());
  if result.is_err(){self.unknown.set(true);}result?;
  if raw.intent.is_null()||raw.journal_count>32||raw.inbox.is_null()==raw.outbox.is_null()||raw.journal[..raw.journal_count].iter().any(|s|s.is_null()){self.unknown.set(true);return Err(Error::Unknown)}
  Ok(NativePlan{intent:raw.intent,journal:raw.journal[..raw.journal_count].to_vec(),inbox:raw.inbox,outbox:raw.outbox})
 }
}

impl AcceptedOriginalBorrow<'_>{pub(crate)fn enter(&self)->Result<(),Error>{self.current()?;let result=status(unsafe{ynx_source_client_enter(self.handle.as_ptr())}).and_then(|_|self.current());if result.is_err(){self.unknown.set(true);}result}}

unsafe extern "C"{fn ynx_source_client_snapshot_acquire(root:*mut c_void,prepared:*const c_void,out:*mut *mut c_void)->i32;}
impl AcceptedOriginalBorrow<'_>{
 // Controlled acquiring operation, not a handle getter. Original Request,
 // Account and Source are rechecked before and after the same-root C call.
 pub(crate)fn acquire_snapshot_for_prepared(&self,prepared:*const c_void,out:&mut *mut c_void)->Result<i32,Error>{
  if !out.is_null(){return Err(Error::Abi)}self.current()?;
  let s=unsafe{ynx_source_client_snapshot_acquire(self.handle.as_ptr(),prepared,out)};
  if self.current().is_err(){self.unknown.set(true);return Ok(8)}Ok(s)
 }
}

// Qualified foreign root is an OWNING object retained inside the same immutable
// PendingSourceRequest. It is not a borrowed pointer, flag or proof projection.
// The static provider must retain its actual independent owners at acquisition;
// input byte slices are used only for that synchronous borrowing call.
pub(crate)struct OriginalSigningGuard{handle:Option<NonNull<c_void>>,thread:ThreadId,phase:std::cell::Cell<Phase>,nonce:[u8;32],source_digest:[u8;32],local:PhantomData<Rc<()>>}
pub(crate)struct OriginalSigningAcquireFailure{pub(crate)error:Error,pub(crate)retained:Option<OriginalSigningGuard>}
impl OriginalSigningGuard{
 pub(crate)fn acquire(input:&crate::private_custodian_ffi::OriginalProviderInput<'_>,native_classic:&[u8;33],native_pq:&[u8;2592],source_nonce:&[u8;32])->Result<Self,OriginalSigningAcquireFailure>{
  use sha2::Digest;
  let refused=||OriginalSigningAcquireFailure{error:Error::Required,retained:None};input.recheck().map_err(|_|refused())?;
  let b=input.bootstrap_raw().map_err(|_|refused())?;let source=input.source_raw().map_err(|_|refused())?;let prefix=input.namespace_prefix().map_err(|_|refused())?;
  let history:Vec<_>=b.status_history.iter().map(|r|OriginalBytes::of(r)).collect();
  let raw=OriginalInput{root:OriginalBytes::of(b.root),registration:OriginalBytes::of(b.registration),status:OriginalBytes::of(b.status),source:OriginalBytes::of(source),namespace_prefix:OriginalBytes::of(prefix),request:OriginalBytes::of(b.request),nonce:b.nonce.as_ptr(),nonce_size:32,status_history:history.as_ptr(),status_history_count:history.len(),native_classic:*native_classic,native_pq:*native_pq,source_nonce:*source_nonce,monotonic_deadline_ns:original_deadline(input).map_err(|_|refused())?};
  let nonce=*b.nonce;let source_digest=sha2::Sha256::digest(source).into();input.recheck().map_err(|_|refused())?;let mut out=ptr::null_mut();
  let code=unsafe{ynx_source_client_original_acquire_v2(&OriginalInputV2::original_read(raw),&mut out)};
  let retained=NonNull::new(out).map(|h|Self{handle:Some(h),thread:thread::current().id(),phase:std::cell::Cell::new(if code==0{Phase::Acquired}else{Phase::Unknown}),nonce,source_digest,local:PhantomData});
  match(status(code),retained){(Ok(()),Some(owner))=>match owner.current(input){Ok(())=>Ok(owner),Err(error)=>Err(OriginalSigningAcquireFailure{error,retained:Some(owner)})},(Ok(()),None)=>Err(OriginalSigningAcquireFailure{error:Error::Abi,retained:None}),(Err(error),retained)=>Err(OriginalSigningAcquireFailure{error,retained})}
 }
 fn raw(&self)->Result<*mut c_void,Error>{if self.thread!=thread::current().id(){return Err(Error::Thread)}self.handle.map(|p|p.as_ptr()).ok_or(Error::Required)}
 pub(crate)fn invalidate(&self){self.phase.set(Phase::Unknown)}
 pub(crate)fn current(&self,input:&crate::private_custodian_ffi::OriginalProviderInput<'_>)->Result<(),Error>{
  use sha2::Digest;let p=self.raw()?;if matches!(self.phase.get(),Phase::Unknown|Phase::Closed){return Err(Error::Unknown)}
  let result=(||{input.recheck().map_err(|_|Error::Unknown)?;let b=input.bootstrap_raw().map_err(|_|Error::Unknown)?;
   let source=input.source_raw().map_err(|_|Error::Unknown)?;let digest:[u8;32]=sha2::Sha256::digest(source).into();
   // Associations are checked in addition to real qualified platform current;
   // matching bytes alone never qualify a guard.
   if b.nonce!=&self.nonce||digest!=self.source_digest{return Err(Error::Unknown)}
   status(unsafe{ynx_source_client_current(p,0)})?;input.recheck().map_err(|_|Error::Unknown)})();if result.is_err(){self.invalidate()}result
 }
 pub(crate)fn enter(&mut self,input:&crate::private_custodian_ffi::OriginalProviderInput<'_>)->Result<(),Error>{
  self.current(input)?;if self.phase.get()==Phase::Entered{return Ok(())}if self.phase.get()!=Phase::Acquired{return Err(Error::Unknown)}
  let p=self.raw()?;self.invalidate();status(unsafe{ynx_source_client_enter(p)})?;self.phase.set(Phase::Entered);self.current(input)
 }
 pub(crate)fn check_type4(&self,input:&crate::private_custodian_ffi::OriginalProviderInput<'_>,wire:&[u8])->Result<(),Error>{
  self.current(input)?;if self.phase.get()!=Phase::Entered||wire.is_empty()||wire.len()>65536{return Err(Error::Required)}
  let result=status(unsafe{ynx_source_client_type4(self.raw()?,wire.as_ptr(),wire.len())}).and_then(|_|self.current(input));if result.is_err(){self.invalidate()}result
 }
 pub(crate)fn close(&mut self)->Result<(),Error>{
  if self.handle.is_none(){return Ok(())}let original=self.raw()?;let mut p=original;
  let code=unsafe{ynx_source_client_close(&mut p)};if code==0&&p.is_null(){self.handle=None;self.phase.set(Phase::Closed);return Ok(())}
  self.invalidate();if p!=original{return Err(Error::Abi)}status(code)?;Err(Error::Abi)
 }
}
impl Drop for OriginalSigningGuard{fn drop(&mut self){if self.handle.is_some(){std::process::abort();}}}

// Exact private C layout. All fields are UNADMITTED bytes: no flags/current
// callbacks/Android pointers. Qualified static platform retains real owners.
#[repr(C)]#[derive(Clone,Copy)]pub(crate)struct ServerBytes{pub(crate)data:*const u8,pub(crate)size:usize}
impl ServerBytes{fn of(b:&[u8])->Self{Self{data:b.as_ptr(),size:b.len()}}}
#[repr(C)]pub(crate)struct ServerOriginalRaw{pub(crate)root:ServerBytes,pub(crate)registration:ServerBytes,pub(crate)status:ServerBytes,pub(crate)source:ServerBytes,pub(crate)namespace_prefix:ServerBytes,pub(crate)request:ServerBytes,pub(crate)nonce:*const u8,pub(crate)nonce_size:usize,pub(crate)status_history:*const ServerBytes,pub(crate)status_history_count:usize}
#[repr(C)]pub(crate)struct ServerInputRaw{pub(crate)original:ServerOriginalRaw,pub(crate)account_original:ServerBytes,pub(crate)prepared_original:ServerBytes}
#[repr(C)]pub(crate)struct ServerTerminalRaw{pub(crate)checkpoint:ServerBytes,pub(crate)namespace_prefix:ServerBytes,pub(crate)account_result:ServerBytes}
pub(crate)struct ServerInputBytes{fields:[zeroize::Zeroizing<Vec<u8>>;8],nonce:[u8;32],history:Vec<zeroize::Zeroizing<Vec<u8>>>,verified:crate::account_instance::ServerVerifiedOriginal,source_verified:crate::source_evidence::UnadmittedSourceEvidence}
unsafe fn server_copy(b:ServerBytes,total:&mut usize)->Result<zeroize::Zeroizing<Vec<u8>>,Error>{if b.data.is_null()||b.size==0||b.size>393216usize.saturating_sub(*total){return Err(Error::Required)}*total+=b.size;Ok(zeroize::Zeroizing::new(unsafe{std::slice::from_raw_parts(b.data,b.size)}.to_vec()))}
impl ServerInputBytes{
 pub(crate)unsafe fn copy(raw:&ServerInputRaw)->Result<Self,Error>{let r=&raw.original;if r.nonce.is_null()||r.nonce_size!=32||r.status_history_count>255||(r.status_history_count!=0&&r.status_history.is_null()){return Err(Error::Required)}let mut total=32;let mut fields=std::array::from_fn(|_|zeroize::Zeroizing::new(Vec::new()));for(n,b)in [r.root,r.registration,r.status,r.source,r.namespace_prefix,r.request,raw.account_original,raw.prepared_original].into_iter().enumerate(){fields[n]=unsafe{server_copy(b,&mut total)}?;}let mut nonce=[0;32];nonce.copy_from_slice(unsafe{std::slice::from_raw_parts(r.nonce,32)});let mut history=Vec::new();if r.status_history_count!=0{for b in unsafe{std::slice::from_raw_parts(r.status_history,r.status_history_count)}{history.push(unsafe{server_copy(*b,&mut total)}?);}}let verified=crate::account_instance::ServerVerifiedOriginal::receive(&fields[0],&fields[1],&fields[2],&history,&fields[5],&fields[6],&fields[7]).map_err(|_|Error::Required)?;let source_verified=crate::source_evidence::verify_server_original(&fields[3],&fields[4],&nonce,&verified).map_err(|_|Error::Required)?;Ok(Self{fields,nonce,history,verified,source_verified})}
 fn current(&self)->Result<(),Error>{self.verified.current().map_err(|_|Error::Required)?;self.source_verified.recheck(self.verified.operation().map_err(|_|Error::Required)?).map_err(|_|Error::Required)?;self.verified.current().map_err(|_|Error::Required)}
 fn with_raw<R>(&self,f:impl FnOnce(&ServerInputRaw)->R)->R{let a=&self.fields;let history:Vec<_>=self.history.iter().map(|b|ServerBytes::of(b)).collect();let original=ServerOriginalRaw{root:ServerBytes::of(&a[0]),registration:ServerBytes::of(&a[1]),status:ServerBytes::of(&a[2]),source:ServerBytes::of(&a[3]),namespace_prefix:ServerBytes::of(&a[4]),request:ServerBytes::of(&a[5]),nonce:self.nonce.as_ptr(),nonce_size:32,status_history:history.as_ptr(),status_history_count:history.len()};f(&ServerInputRaw{original,account_original:ServerBytes::of(&a[6]),prepared_original:ServerBytes::of(&a[7])})}
}
unsafe extern "C"{fn ynx_source_client_server_acquire(i:*const ServerInputRaw,out:*mut *mut c_void)->i32;fn ynx_source_client_server_current(h:*mut c_void)->i32;fn ynx_source_client_server_enter(h:*mut c_void)->i32;fn ynx_source_client_server_retire(h:*mut c_void,i:*const ServerTerminalRaw)->i32;fn ynx_source_client_server_close(h:*mut *mut c_void)->i32;fn ynx_source_client_server_unknown(h:*mut c_void)->i32;}
pub(crate)struct ServerParticipant{handle:Option<NonNull<c_void>>,thread:ThreadId,phase:Phase,input:ServerInputBytes,enter_attempted:bool,retire_attempted:bool,local:PhantomData<Rc<()>>}
pub(crate)struct ServerAcquireFailure{pub(crate)error:Error,pub(crate)retained:Option<ServerParticipant>}
impl ServerParticipant{
 pub(crate)fn acquire(input:ServerInputBytes)->Result<Self,ServerAcquireFailure>{input.current().map_err(|_|ServerAcquireFailure{error:Error::Required,retained:None})?;let mut out=ptr::null_mut();let s=input.with_raw(|raw|unsafe{ynx_source_client_server_acquire(raw,&mut out)});let retained=NonNull::new(out).map(|h|Self{handle:Some(h),thread:thread::current().id(),phase:if s==0{Phase::Acquired}else{Phase::Unknown},input,enter_attempted:false,retire_attempted:false,local:PhantomData});match(status(s),retained){(Ok(()),Some(mut owner))=>match owner.current(){Ok(())=>Ok(owner),Err(error)=>Err(ServerAcquireFailure{error,retained:Some(owner)})},(Ok(()),None)=>Err(ServerAcquireFailure{error:Error::Abi,retained:None}),(Err(error),retained)=>Err(ServerAcquireFailure{error,retained})}}
 fn raw(&self)->Result<*mut c_void,Error>{if self.thread!=thread::current().id(){return Err(Error::Thread)}self.handle.map(|h|h.as_ptr()).ok_or(Error::Required)}
 pub(crate)fn current(&mut self)->Result<(),Error>{let p=self.raw()?;if self.phase==Phase::Unknown{return Err(Error::Unknown)}if self.phase!=Phase::Acquired&&self.phase!=Phase::Entered{return Err(Error::Required)}let r=self.input.current().and_then(|_|status(unsafe{ynx_source_client_server_current(p)})).and_then(|_|self.input.verified.current().map_err(|_|Error::Required));if r.is_err()&&self.phase==Phase::Entered{self.phase=Phase::Unknown;return Err(Error::Unknown)}r}
 pub(crate)fn enter(&mut self)->Result<(),Error>{self.current()?;if self.phase!=Phase::Acquired||self.enter_attempted{return Err(Error::Unknown)}let p=self.raw()?;self.enter_attempted=true;self.phase=Phase::Unknown;status(unsafe{ynx_source_client_server_enter(p)})?;self.phase=Phase::Entered;self.current()}
 pub(crate)unsafe fn retire(&mut self,raw:&ServerTerminalRaw)->Result<(),Error>{self.current()?;if self.phase!=Phase::Entered||self.retire_attempted{return Err(Error::Unknown)}let mut total=0;let copied=(||{let a=unsafe{server_copy(raw.checkpoint,&mut total)}?;let b=unsafe{server_copy(raw.namespace_prefix,&mut total)}?;let c=unsafe{server_copy(raw.account_result,&mut total)}?;Ok::<_,Error>((a,b,c))})();let (a,b,c)=match copied{Ok(v)=>v,Err(_)=>{self.phase=Phase::Unknown;return Err(Error::Unknown)}};self.input.current().map_err(|_|{self.phase=Phase::Unknown;Error::Unknown})?;let input=ServerTerminalRaw{checkpoint:ServerBytes::of(&a),namespace_prefix:ServerBytes::of(&b),account_result:ServerBytes::of(&c)};let p=self.raw()?;self.retire_attempted=true;self.phase=Phase::Unknown;status(unsafe{ynx_source_client_server_retire(p,&input)})?;self.input.current().map_err(|_|Error::Unknown)?;self.phase=Phase::Closed;/* actual platform retirement checked atomically, handle retained for explicit RAM close */Ok(())}
 pub(crate)fn mark_unknown(&mut self)->Result<(),Error>{let p=self.raw()?;self.phase=Phase::Unknown;let _=unsafe{ynx_source_client_server_unknown(p)};Err(Error::Unknown)}
 pub(crate)fn close(&mut self)->Result<(),Error>{if self.handle.is_none(){return Ok(())}let original=self.raw()?;let mut p=original;let s=unsafe{ynx_source_client_server_close(&mut p)};if s==0&&p.is_null(){self.handle=None;self.phase=Phase::Closed;return Ok(())}self.phase=Phase::Unknown;if p!=original{return Err(Error::Abi)}status(s)?;Err(Error::Abi)}
}
impl Drop for ServerParticipant{fn drop(&mut self){if self.handle.is_some(){std::process::abort();}}}

// Pre-source private input. These borrowed carriers are UNADMITTED facts; only
// the separately enrolled static role platform can create the owning output.
#[repr(C)]pub(crate)struct RoleInputRaw{
 root:OriginalBytes,registration:OriginalBytes,status:OriginalBytes,credential:OriginalBytes,account_original:OriginalBytes,request:OriginalBytes,prepared_original:OriginalBytes,directory_checkpoint:OriginalBytes,namespace_prefix:OriginalBytes,
 status_history:*const OriginalBytes,status_history_count:usize,nonce:*const u8,nonce_size:usize,purpose:u32,role:u32,
}
#[repr(C)]struct RoleBindingRaw{operation:OriginalBytes,custodian:OriginalBytes,frame:OriginalBytes,nonce:[u8;32],head:[u8;32],classic_public:[u8;33],pq_public:[u8;2592],sequence:u64,purpose:u32,role:u32}
unsafe extern "C"{
 fn ynx_source_client_role_acquire(i:*const RoleInputRaw,o:*mut *mut c_void)->i32;
 fn ynx_source_client_role_current(h:*mut c_void)->i32;
 fn ynx_source_client_role_projection(h:*mut c_void,o:*mut RoleBindingRaw)->i32;
 fn ynx_source_client_role_enter(h:*mut c_void)->i32;
 fn ynx_source_client_role_close(h:*mut *mut c_void)->i32;
}
pub(crate)struct ProtectedRole{handle:Option<NonNull<c_void>>,thread:ThreadId,unknown:bool,entered:bool,nonce:[u8;32],role:u32,purpose:u32,local:PhantomData<Rc<()>>}
pub(crate)struct RoleFailure{pub(crate)error:Error,pub(crate)retained:Option<ProtectedRole>}
impl ProtectedRole{
 // Caller must hold actual original carriers alive for this bounded synchronous
 // copy. Platform retains its own authenticated original lifetime before return.
 pub(crate)unsafe fn acquire(input:&RoleInputRaw,credential:&[u8])->Result<Self,RoleFailure>{
  use zeroize::Zeroizing;
  let refused=||RoleFailure{error:Error::Required,retained:None};
  if !(1..=2).contains(&input.role)||!(1..=2).contains(&input.purpose)||input.nonce.is_null()||input.nonce_size!=32||input.status_history_count>255||(input.status_history_count!=0&&input.status_history.is_null()){return Err(refused())}
  let mut total=32usize;
  let copy=|r:&OriginalBytes,total:&mut usize|->Result<Zeroizing<Vec<u8>>,RoleFailure>{if r.data.is_null()||r.size==0||r.size>393216{return Err(refused())}*total=total.checked_add(r.size).filter(|n|*n<=393216).ok_or_else(refused)?;Ok(Zeroizing::new(unsafe{std::slice::from_raw_parts(r.data,r.size)}.to_vec()))};
  let roots=[&input.root,&input.registration,&input.status,&input.credential,&input.account_original,&input.request,&input.prepared_original,&input.directory_checkpoint,&input.namespace_prefix];
  let mut values=Vec::new();for (index,r) in roots.into_iter().enumerate(){if index==6&&input.purpose==1{if r.size!=0{return Err(refused())}values.push(Zeroizing::new(Vec::new()));}else{values.push(copy(r,&mut total)?)}}
  if values[3].as_slice()!=credential{return Err(refused())}
  let histories=if input.status_history_count==0{&[]}else{unsafe{std::slice::from_raw_parts(input.status_history,input.status_history_count)}};
  let mut retained_history=Vec::new();for r in histories{retained_history.push(copy(r,&mut total)?)}
  let history:Vec<_>=retained_history.iter().map(|r|OriginalBytes::of(r)).collect();
  let nonce=unsafe{std::slice::from_raw_parts(input.nonce,32)}.to_vec();
  let raw=RoleInputRaw{root:OriginalBytes::of(&values[0]),registration:OriginalBytes::of(&values[1]),status:OriginalBytes::of(&values[2]),credential:OriginalBytes::of(&values[3]),account_original:OriginalBytes::of(&values[4]),request:OriginalBytes::of(&values[5]),prepared_original:OriginalBytes::of(&values[6]),directory_checkpoint:OriginalBytes::of(&values[7]),namespace_prefix:OriginalBytes::of(&values[8]),status_history:history.as_ptr(),status_history_count:history.len(),nonce:nonce.as_ptr(),nonce_size:32,purpose:input.purpose,role:input.role};
  let mut out=ptr::null_mut();let s=unsafe{ynx_source_client_role_acquire(&raw,&mut out)};
  let retained=NonNull::new(out).map(|h|Self{handle:Some(h),thread:thread::current().id(),unknown:s!=0,entered:false,nonce:nonce.as_slice().try_into().unwrap(),role:input.role,purpose:input.purpose,local:PhantomData});
  match(status(s),retained){(Ok(()),Some(mut owner))=>match owner.current(){Ok(())=>Ok(owner),Err(error)=>Err(RoleFailure{error,retained:Some(owner)})},(Ok(()),None)=>Err(RoleFailure{error:Error::Abi,retained:None}),(Err(error),retained)=>Err(RoleFailure{error,retained})}
 }
 fn raw(&self)->Result<*mut c_void,Error>{if self.thread!=thread::current().id(){return Err(Error::Thread)}self.handle.map(|h|h.as_ptr()).ok_or(Error::Required)}
 pub(crate)fn current(&mut self)->Result<(),Error>{let p=self.raw()?;if self.unknown{return Err(Error::Unknown)}let r=status(unsafe{ynx_source_client_role_current(p)});if r.is_err(){self.unknown=true}r}
 pub(crate)fn enter(&mut self)->Result<(),Error>{self.current()?;if self.entered{return Err(Error::Unknown)}let p=self.raw()?;self.entered=true;self.unknown=true;status(unsafe{ynx_source_client_role_enter(p)})?;self.unknown=false;self.current()}
 pub(crate)fn invalidate(&mut self){self.unknown=true;}
 pub(crate)fn binding(&mut self)->Result<super::SourceAttemptBinding,Error>{
  self.current()?;let mut out:RoleBindingRaw=unsafe{std::mem::zeroed()};let s=unsafe{ynx_source_client_role_projection(self.raw()?,&mut out)};
  if let Err(e)=status(s).and_then(|_|self.current()){self.unknown=true;return Err(e)}
  let copy=|r:&OriginalBytes,max|->Result<Vec<u8>,Error>{if r.data.is_null()||r.size==0||r.size>max{return Err(Error::Abi)}Ok(unsafe{std::slice::from_raw_parts(r.data,r.size)}.to_vec())};
  if out.nonce!=self.nonce||out.role!=self.role||out.purpose!=self.purpose{self.unknown=true;return Err(Error::Abi)}
  let result=(||{
   let op=copy(&out.operation,128)?;let custodian=copy(&out.custodian,512)?;let frame=copy(&out.frame,49152)?;
   let role=match out.role{1=>super::SourceRole::Issuer,2=>super::SourceRole::Anchor,_=>return Err(Error::Abi)};
   match out.purpose{1=>super::SourceAttemptBinding::bounded(&op,out.nonce,out.sequence,out.head,role,&custodian,out.classic_public,&out.pq_public,&frame),2=>super::SourceAttemptBinding::bounded_first_prepared(&op,out.nonce,out.sequence,out.head,role,&custodian,out.classic_public,&out.pq_public,&frame),_=>return Err(Error::Abi)}.map_err(|_|Error::Abi)
  })();
  if result.is_err(){self.unknown=true}self.current()?;result
 }
 pub(crate)fn close(&mut self)->Result<(),Error>{let Some(old)=self.handle else{return Ok(())};let mut out=self.raw()?;let s=unsafe{ynx_source_client_role_close(&mut out)};if s==0&&out.is_null(){self.handle=None;return Ok(())}self.unknown=true;if out!=old.as_ptr(){return Err(Error::Abi)}status(s)?;Err(Error::Abi)}
}
impl Drop for ProtectedRole{fn drop(&mut self){if self.handle.is_some(){std::process::abort()}}}

impl RoleInputRaw{pub(super)fn purpose_value(&self)->u32{self.purpose}}

#[cfg(test)]mod role_abi_delta_controls{
 use super::*;
 #[test]fn exact_private_role_c_layout(){assert_eq!(std::mem::size_of::<RoleInputRaw>(),184);assert_eq!(std::mem::size_of::<RoleBindingRaw>(),2760);assert_eq!(std::mem::size_of::<crate::source_infrastructure::source_collector::ClaimedIntentRaw>(),104);}
 #[test]fn missing_original_input_never_calls_qualified_acquisition(){let r:RoleInputRaw=unsafe{std::mem::zeroed()};let e=match unsafe{ProtectedRole::acquire(&r,b"PUBLIC")}{Err(e)=>e,Ok(_)=>panic!("missing input acquired")};assert!(matches!(e.error,Error::Required));assert!(e.retained.is_none());}
}

#[repr(C)]struct ServerDeviceOriginalRaw{version:u32,final_raw:ServerBytes,current:ServerBytes,terminal:ServerBytes,checkpoint:ServerBytes,predecessors:*const ServerBytes,predecessor_count:usize}
unsafe extern "C"{fn ynx_source_client_server_device_originals(h:*mut c_void,out:*mut ServerDeviceOriginalRaw)->i32;}
impl ServerParticipant{
 pub(crate)fn device_records_transport(&mut self)->Result<Vec<u8>,Error>{
  let p=self.raw()?;if self.phase==Phase::Unknown{return Err(Error::Unknown)}if self.phase!=Phase::Closed||!self.retire_attempted{return Err(Error::Required)}
  let mut raw=ServerDeviceOriginalRaw{version:0,final_raw:ServerBytes{data:ptr::null(),size:0},current:ServerBytes{data:ptr::null(),size:0},terminal:ServerBytes{data:ptr::null(),size:0},checkpoint:ServerBytes{data:ptr::null(),size:0},predecessors:ptr::null(),predecessor_count:0};
  let s=unsafe{ynx_source_client_server_device_originals(p,&mut raw)};if s!=0{if !matches!(status(s),Err(Error::Required)){self.phase=Phase::Unknown;}return status(s).and(Err(Error::Required));}
  let result=(||{if raw.version!=1||raw.predecessor_count>255||(raw.predecessor_count>0&&raw.predecessors.is_null()){return Err(Error::Abi)}let mut total=0;let a=unsafe{server_copy(raw.final_raw,&mut total)}?;let b=unsafe{server_copy(raw.current,&mut total)}?;let c=unsafe{server_copy(raw.terminal,&mut total)}?;let d=unsafe{server_copy(raw.checkpoint,&mut total)}?;let mut history=Vec::new();if raw.predecessor_count>0{for part in unsafe{std::slice::from_raw_parts(raw.predecessors,raw.predecessor_count)}{history.push(unsafe{server_copy(*part,&mut total)}?);}}let parts:Vec<_>=history.iter().map(|x|x.as_slice()).collect();let transport=crate::message_evidence::OriginalDeviceRecords::canonical_transport(&a,&b,&parts,&c,&d).map_err(|_|Error::Abi)?;let mut late=ServerDeviceOriginalRaw{version:0,..raw};status(unsafe{ynx_source_client_server_device_originals(p,&mut late)})?;if late.version!=1||late.predecessor_count!=history.len(){return Err(Error::Unknown)}let mut late_total=0;if unsafe{server_copy(late.final_raw,&mut late_total)}?!=a||unsafe{server_copy(late.current,&mut late_total)}?!=b||unsafe{server_copy(late.terminal,&mut late_total)}?!=c||unsafe{server_copy(late.checkpoint,&mut late_total)}?!=d{return Err(Error::Unknown)}if !history.is_empty(){if late.predecessors.is_null(){return Err(Error::Unknown)}for (original,same) in history.iter().zip(unsafe{std::slice::from_raw_parts(late.predecessors,late.predecessor_count)}){if unsafe{server_copy(*same,&mut late_total)}?.as_slice()!=original.as_slice(){return Err(Error::Unknown)}}}Ok(transport)})();if result.is_err(){self.phase=Phase::Unknown;}result
 }
}
