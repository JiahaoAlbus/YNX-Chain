//! Actual selected preparation; private SQL/waker fixture, not issuer proof.
//! No fixture_unknown is used: only original callback terminal transitions.
use super::*;
use std::{io::Write,process::Command,sync::Arc,task::{Wake,Waker}};
thread_local!{static CALLBACK:RefCell<Option<(Gate,Vec<u8>)>>=const{RefCell::new(None)};}
struct TerminalWake;
impl Wake for TerminalWake{
 fn wake(self:Arc<Self>){self.wake_by_ref();}
 fn wake_by_ref(self:&Arc<Self>){
  let call=CALLBACK.with(|c|c.borrow().as_ref().map(|(g,s)|(g.clone(),s.clone())));
  if let Some((g,steps))=call{for step in steps{match step{0=>g.1.cancel(),1=>g.1.fixture_revoke(),2=>g.1.fixture_rebind(4),_=>panic!("unselected transition")}}}
 }
}
fn prepared()->(NativeStoreBridge,NativePendingHandle){let(mut b,mut s,a,l,w)=tests::setup();tests::prepare(&mut s,&a,&l,&w);let h=b.retain_prepared(s).unwrap_or_else(|_|panic!());(b,h)}
fn sql(b:&mut NativeStoreBridge)->&mut FixtureSql{match &mut b.backend{NativeBackend::Fixture(f)=>f,_=>panic!("private fixture")}}
fn poll(b:&mut NativeStoreBridge,h:&mut NativePendingHandle)->Poll<Result<FinalStatus,PortError>>{b.poll_final(h,&mut Context::from_waker(Waker::noop()))}
fn close(b:&NativeStoreBridge){let q=b.owned_supervisor().unwrap_or_else(|_|panic!());drop(match q.shutdown(){Err(q)=>q,Ok(())=>panic!("held ledger")});}
fn same(b:&NativeStoreBridge,h:&NativePendingHandle)->(*const u8,*const Mutation,usize,usize){let r=&b.pending[&h.slot];let p=r.snapshot.stage.gate.0.borrow();(p.original_ciphertext.as_ref().unwrap().as_ptr(),p.journal.as_ptr(),p.journal.len(),r.reserved_bytes)}
#[test]fn r24_unchanged_waker_pending_with_closing_keeps_same_recovery(){
 let(mut b,mut h)=prepared();let original=same(&b,&h);sql(&mut b).unknown_after_apply=true;assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));close(&b);
 sql(&mut b).lookup_pending=true;let gate=b.pending[&h.slot].snapshot.stage.gate.clone();CALLBACK.with(|c|*c.borrow_mut()=Some((gate.clone(),vec![])));let w=Waker::from(Arc::new(TerminalWake));
 assert!(b.poll_final(&mut h,&mut Context::from_waker(&w)).is_pending());CALLBACK.with(|c|*c.borrow_mut()=None);assert!(!gate.1.has_uncertain_outcome());assert!(validate_computation(&b.pending[&h.slot].snapshot).is_ok());assert_eq!(same(&b,&h),original);
 assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::FixtureApplied))));let f=sql(&mut b);assert_eq!((f.submissions,f.receipts,f.lookups,f.queues.len()),(1,1,2,1));b.consume_once(&mut h).unwrap_or_else(|_|panic!());b.retire(&mut h,RetireAcknowledgement::ConsumedOutput).unwrap_or_else(|_|panic!());
}
#[test]fn r24_child_only_transitions(){
 let Ok(mode)=std::env::var("VEIL_R24_CHILD_MODE")else{return};
 let steps:Vec<u8>=mode.split('-').map(|v|match v{"cancel"=>0,"revoke"=>1,"rebind"=>2,_=>panic!("unselected mode")}).collect();
 let(mut b,mut h)=prepared();let original=same(&b,&h);let bytes=b.retained_bytes;let gate=b.pending[&h.slot].snapshot.stage.gate.clone();sql(&mut b).unknown_after_apply=true;
 assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));assert!(!gate.1.has_uncertain_outcome());close(&b);sql(&mut b).lookup_pending=true;
 CALLBACK.with(|c|*c.borrow_mut()=Some((gate.clone(),steps)));let w=Waker::from(Arc::new(TerminalWake));
 assert!(matches!(b.poll_final(&mut h,&mut Context::from_waker(&w)),Poll::Ready(Ok(FinalStatus::Unknown))));CALLBACK.with(|c|*c.borrow_mut()=None);
 assert!(!gate.1.has_uncertain_outcome(),"control must not mint scope UNKNOWN");assert!(validate_computation(&b.pending[&h.slot].snapshot).is_err());assert!(matches!(b.pending[&h.slot].completion,Completion::Unknown));assert!(gate.0.borrow().phase==Phase::Unknown);assert!(!b.pending[&h.slot].definitely_not_applied);assert!(b.pending[&h.slot].submitted);
 for _ in 0..2{assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));}
 assert!(matches!(b.cancel(&mut h),Err(PortError::Unknown)));assert!(matches!(b.consume_once(&mut h),Err(PortError::Unknown)));for ack in [RetireAcknowledgement::DefiniteRejection,RetireAcknowledgement::ConsumedOutput]{assert!(matches!(b.retire(&mut h,ack),Err(PortError::Unknown)));}
 assert_eq!(same(&b,&h),original);assert_eq!(b.retained_bytes,bytes);assert_eq!(b.custody.borrow().count(),1);assert_eq!(b.custody.borrow().ledger_bytes,bytes);let f=sql(&mut b);assert_eq!((f.submissions,f.receipts,f.lookups,f.queues.len()),(1,1,1,1));
 println!("R24-CHECKED-{mode}");std::io::stdout().flush().unwrap();drop(b);panic!("unresolved original must not be dropped");
}
#[test]fn r24_actual_only_transition_and_order_child_controls(){
 use std::os::unix::process::ExitStatusExt;
 let output=std::path::PathBuf::from(std::env::var_os("VEIL_R24_CHILD_OUTPUT").expect("fresh output required"));std::fs::create_dir(&output).unwrap();let exact=format!("{}::r24_child_only_transitions",module_path!().split_once("::").unwrap().1);
 for mode in ["cancel","revoke","rebind","cancel-revoke","revoke-cancel","cancel-rebind","rebind-cancel","revoke-rebind","rebind-revoke"]{
  let r=Command::new(std::env::current_exe().unwrap()).args(["--exact",&exact,"--nocapture"]).env("VEIL_R24_CHILD_MODE",mode).output().unwrap();std::fs::write(output.join(format!("{mode}.stdout")),&r.stdout).unwrap();std::fs::write(output.join(format!("{mode}.stderr")),&r.stderr).unwrap();std::fs::write(output.join(format!("{mode}.status")),format!("code={:?} signal={:?}\n",r.status.code(),r.status.signal())).unwrap();assert!(String::from_utf8_lossy(&r.stdout).contains(&format!("R24-CHECKED-{mode}")));assert_eq!(r.status.signal(),Some(6));
 }
}
