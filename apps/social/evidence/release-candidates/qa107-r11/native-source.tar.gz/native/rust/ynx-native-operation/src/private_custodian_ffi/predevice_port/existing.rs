//! PRIVATE whole-component v2 reader. No recovery/admission factory or JNI API.
//! Construct in original actor custody BEFORE open_once; never return an owner
//! through Result's error channel or infer permission from diagnostic success.
use super::*;
#[cfg(feature="predevice-cold-v1")]pub(super)mod cold;
#[repr(C)]#[derive(Default,Debug,PartialEq,Eq)]
pub(in crate::private_custodian_ffi)struct Report{pub version:u32,pub stage:u32,pub primary:u32,pub os_error:i32,pub sqlite_error:i32,pub cleanup_uncertain:i32}
const _:()={assert!(std::mem::size_of::<Report>()==24);assert!(std::mem::align_of::<Report>()==4);assert!(std::mem::offset_of!(Report,primary)==8);assert!(std::mem::offset_of!(Report,cleanup_uncertain)==20);};
unsafe extern "C"{
 fn veil_pd_open_existing(path:*const c_char,out:*mut *mut Store)->i32;
 fn veil_pd_existing_diagnostic(store:*const Store,out:*mut Report)->i32;
}
#[derive(Debug,PartialEq,Eq)]pub(in crate::private_custodian_ffi)enum ReaderError{Thread,AlreadyAttempted,Unavailable,Foreign(i32),Quarantined,Abi}
#[derive(Debug,PartialEq,Eq)]pub(in crate::private_custodian_ffi)enum Cleanup{Released,NoHandle,Retained(i32),Quarantined}
/// !Send/!Sync, not Clone. Original receipt/authorization are not represented.
/// Parent reservation has one optional slot, not an independent owner registry.
pub(in crate::private_custodian_ffi)struct ExistingReader{
 #[cfg(feature="predevice-cold-v1")]cold:cold::State,
 store:*mut Store,result:*mut ResultOwner,captured:Option<super::capture::StoredCiphertext>,capture_failure:Option<super::capture::CaptureFailure>,read_binding:Option<([u8;16],[u8;16])>,thread:ThreadId,local:PhantomData<Rc<()>>,
 attempted:bool,open_status:Option<i32>,first:Option<i32>,
 cleanup_status:Option<i32>,ambiguous_close:bool,
}
impl ExistingReader{
 pub(in crate::private_custodian_ffi)fn unopened()->Self{Self{#[cfg(feature="predevice-cold-v1")]cold:cold::State::new(),store:std::ptr::null_mut(),result:std::ptr::null_mut(),captured:None,capture_failure:None,read_binding:None,thread:std::thread::current().id(),local:PhantomData,attempted:false,open_status:None,first:None,cleanup_status:None,ambiguous_close:false}}
 fn on_thread(&self)->Result<(),ReaderError>{if self.thread==std::thread::current().id(){Ok(())}else{Err(ReaderError::Thread)}}
 fn record(&mut self,status:i32){if self.first.is_none(){self.first=Some(status)}}
 pub(in crate::private_custodian_ffi)fn open_once(&mut self,path:&CStr)->Result<(),ReaderError>{
  self.on_thread()?;if self.attempted{return Err(ReaderError::AlreadyAttempted)}
  self.attempted=true;
  // C writes DIRECTLY into the retained original slot even on failure.
  let status=unsafe{veil_pd_open_existing(path.as_ptr(),&mut self.store)};
  self.open_status=Some(status);
  if status!=11{self.record(status);return Err(ReaderError::Foreign(status))}
  if self.store.is_null(){self.record(9);return Err(ReaderError::Abi)}
  Ok(()) // Existing UNVERIFIED reader only; never a generation ticket.
 }
 pub(in crate::private_custodian_ffi)fn diagnostic(&mut self)->Result<Report,ReaderError>{
  self.on_thread()?;if self.store.is_null(){return Err(ReaderError::Unavailable)}
  let mut report=Report::default();let status=unsafe{veil_pd_existing_diagnostic(self.store,&mut report)};
  if status!=1{self.record(status);return Err(ReaderError::Foreign(status))}
  // primary=0 is legitimate. Keep numeric codes; no enum transmute.
  if report.version!=1||!(1..=9).contains(&report.stage)||report.primary>16||!(0..=1).contains(&report.cleanup_uncertain){return Err(ReaderError::Abi)}
  if report.cleanup_uncertain==1{self.ambiguous_close=true}
  Ok(report)
 }
 pub(in crate::private_custodian_ffi)fn cleanup(&mut self)->Result<Cleanup,ReaderError>{
  self.on_thread()?;
  #[cfg(feature="predevice-cold-v1")]if self.cold.started(){return self.cleanup_cold()}
  if self.ambiguous_close{return Ok(Cleanup::Quarantined)}
  if !self.result.is_null(){
   let prior=self.result;let status=unsafe{veil_pd_result_drop(&mut self.result)};self.cleanup_status=Some(status);
   if(status==1&&!self.result.is_null())||(status!=1&&self.result!=prior){std::process::abort()}
   if status!=1{self.record(status);if status==15{self.ambiguous_close=true;return Ok(Cleanup::Quarantined)}return Ok(Cleanup::Retained(status))}
  }
  if self.store.is_null(){return Ok(Cleanup::NoHandle)}
  let prior=self.store;let status=unsafe{veil_pd_close(&mut self.store)};
  self.cleanup_status=Some(status);
  // A changed pointer on error or nonnull success violates frozen ownership.
  // Failstop avoids a second FFI on a possibly stale owner; not durable recovery.
  if (status==1&&!self.store.is_null())||(status!=1&&self.store!=prior){std::process::abort()}
  if status==1{return Ok(Cleanup::Released)}
  self.record(status);
  if status==15{self.ambiguous_close=true;return Ok(Cleanup::Quarantined)}
  Ok(Cleanup::Retained(status)) // caller must retain; no automatic retry.
 }
}
impl Drop for ExistingReader{fn drop(&mut self){#[cfg(feature="predevice-cold-v1")]if self.cold.held(){std::process::abort()}if !self.store.is_null()||!self.result.is_null(){std::process::abort()}/* containment, NOT persistence/recovery */}}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn r58_actual_relative_refusal_no_owner(){let mut owner=ExistingReader::unopened();assert_eq!(owner.open_once(&std::ffi::CString::new("relative").unwrap()),Err(ReaderError::Foreign(6)));assert!(owner.store.is_null());assert_eq!(owner.first,Some(6));assert_eq!(owner.cleanup(),Ok(Cleanup::NoHandle));assert_eq!(owner.open_once(&std::ffi::CString::new("relative").unwrap()),Err(ReaderError::AlreadyAttempted));}
 #[test]fn r58_actual_partial_owner_diagnostic_cleanup(){
  // Actual C publishes an owner before rejecting a dotdot component; no FDs.
  let mut owner=ExistingReader::unopened();assert_eq!(owner.open_once(&std::ffi::CString::new("/../r58-public-missing").unwrap()),Err(ReaderError::Foreign(6)));assert!(!owner.store.is_null());let original=owner.store;
  let report=owner.diagnostic().unwrap();assert_eq!(report.stage,1);assert_eq!(report.primary,6);assert_eq!(report.os_error,0);assert_eq!(report.cleanup_uncertain,0);assert_eq!(owner.store,original);
  assert_eq!(owner.open_once(&std::ffi::CString::new("/different").unwrap()),Err(ReaderError::AlreadyAttempted));assert_eq!(owner.store,original);assert_eq!(owner.cleanup(),Ok(Cleanup::Released));assert_eq!(owner.first,Some(6));assert_eq!(owner.cleanup_status,Some(1));assert_eq!(owner.cleanup(),Ok(Cleanup::NoHandle));
 }
 #[test]fn r58_layout_primary_zero_and_quarantine_no_foreign_call(){
  assert_eq!(Report::default().primary,0);let mut owner=ExistingReader::unopened();owner.first=Some(13);owner.cleanup_status=Some(15);owner.ambiguous_close=true;
  assert_eq!(owner.cleanup(),Ok(Cleanup::Quarantined));assert_eq!(owner.cleanup_status,Some(15));assert_eq!(owner.first,Some(13));assert!(!owner.attempted); // scalar control, not a real OS-close fault.
 }
}

impl ExistingReader{
 pub(in crate::private_custodian_ffi)fn capture_original(&mut self,input:&LocalGenesisInput,operation:[u8;16],incarnation:[u8;16])->Result<&[u8],ReaderError>{
  #[cfg(feature="predevice-cold-v1")] {return self.capture_cold(input,operation,incarnation)}
  #[cfg(not(feature="predevice-cold-v1"))] {
  self.on_thread()?;
  if self.ambiguous_close{return Err(ReaderError::Quarantined)}
  if let Some(first)=self.first{return Err(ReaderError::Foreign(first))}
  if self.open_status!=Some(11)||self.store.is_null(){return Err(ReaderError::Unavailable)}
  if let Some(binding)=self.read_binding{
   if binding!=(operation,incarnation)||self.captured.as_ref().is_some_and(|c|!c.matches(input)){self.record(5);return Err(ReaderError::Foreign(5))}
   return self.captured.as_ref().map(|c|c.journal()).ok_or(ReaderError::Unavailable)
  }
  // Capture association before foreign effect. Any failure leaves it consumed.
  self.read_binding=Some((operation,incarnation));
  let status=unsafe{veil_pd_lookup(self.store,operation.as_ptr(),&mut self.result)};
  if status!=3{self.record(status);return Err(ReaderError::Foreign(status))}
  if self.result.is_null(){self.record(9);return Err(ReaderError::Abi)}
  let capture=super::capture::capture_existing_result(self.result,input,&operation,&incarnation);
  self.captured=capture.out;self.capture_failure=capture.error;
  // Preserve copied ciphertext and original result even on post-callback failure.
  if self.capture_failure.is_some(){self.record(5)}
  if capture.status!=3{self.record(capture.status)}
  if let Some(first)=self.first{return Err(ReaderError::Foreign(first))}
  self.captured.as_ref().map(|c|c.journal()).ok_or(ReaderError::Unavailable)
  }
 }
}
#[cfg(test)]mod r59_tests{
 use super::*;use std::os::unix::fs::DirBuilderExt;
 fn input()->LocalGenesisInput{LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public metadata"))}
 fn fixture()->(std::ffi::CString,Vec<u8>){
  let root=std::path::PathBuf::from(std::env::var_os("TMPDIR").unwrap());let dir=root.join(format!("r59-public-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));std::fs::DirBuilder::new().mode(0o700).create(&dir).unwrap();let path=std::ffi::CString::new(dir.join("pair.sqlite3").as_os_str().as_encoded_bytes()).unwrap();
  let mut pq=super::super::super::PqRecord{version:1,aad_size:1,aad:[0;7168],nonce:[0;12],cipher:[0;4912]};pq.aad[0]=7;
  let mut classic=super::super::super::ClassicRecord{version:1,aad_size:1,cipher_size:17,aad:[0;7168],nonce:[0;12],cipher:[0;272]};classic.aad[0]=8;
  let wire=super::super::super::encode_pair(&pq,&classic).unwrap();let pn=u32::from_be_bytes(wire[12..16].try_into().unwrap())as usize;let cn=u32::from_be_bytes(wire[16..20].try_into().unwrap())as usize;
  let pair=PairBorrow::from_slices(&wire[20+pn..20+pn+cn],&wire[20..20+pn],&wire,&classic.aad[..1],&pq.aad[..1]);let mut fresh=PreDeviceOwner::unopened([1;16],[2;16]);fresh.reserve(&path,&input()).unwrap();fresh.claim_generation().unwrap();fresh.commit(&pair).unwrap();fresh.close_known().unwrap();(path,wire)
 }
 #[test]fn r59_actual_existing_lookup_same_result_and_wire(){let(path,wire)=fixture();let mut reader=ExistingReader::unopened();reader.open_once(&path).unwrap();assert_eq!(reader.diagnostic().unwrap().primary,0);assert_eq!(reader.capture_original(&input(),[1;16],[2;16]).unwrap(),wire);let pointer=reader.captured.as_ref().unwrap().journal().as_ptr();let result=reader.result;assert!(!result.is_null());assert_eq!(reader.capture_original(&input(),[1;16],[2;16]).unwrap().as_ptr(),pointer);assert_eq!(reader.result,result);assert_eq!(reader.cleanup(),Ok(Cleanup::Released));assert!(reader.store.is_null()&&reader.result.is_null());}
 #[test]fn r59_changed_binding_keeps_original_result_and_bytes(){let(path,wire)=fixture();let mut reader=ExistingReader::unopened();reader.open_once(&path).unwrap();reader.capture_original(&input(),[1;16],[2;16]).unwrap();let result=reader.result;assert_eq!(reader.capture_original(&input(),[9;16],[2;16]),Err(ReaderError::Foreign(5)));assert_eq!(reader.result,result);assert_eq!(reader.captured.as_ref().unwrap().journal(),wire);assert_eq!(reader.capture_original(&input(),[1;16],[2;16]),Err(ReaderError::Foreign(5)));assert_eq!(reader.cleanup(),Ok(Cleanup::Released));assert_eq!(reader.first,Some(5));}
}
