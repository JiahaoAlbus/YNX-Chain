//! PRIVATE cfg(test) method-level owner controls. No pointer is passed to C,
//! no real lease/authority/CAS/receipt is issued. Typed Boxes are local dummies.
use super::*;
use std::{cell::RefCell,collections::VecDeque};
pub(super)struct Control{
 pub(super) calls:[usize;15],responses:VecDeque<(Action,i32,bool)>,released:usize,pub(super) stash:bool,
 pending:Option<Box<Pending>>,write:Option<Box<Write>>,finish:Option<Box<Finish>>,lookup:Option<Box<Lookup>>,cleanup:Option<Box<Cleanup>>,
 diagnostic:CleanupObservation,diagnostic_reads:usize,
}
impl Control{
 pub(super) fn new()->Self{Self{diagnostic_reads:0,calls:[0;15],responses:VecDeque::new(),released:0,stash:false,pending:None,write:None,finish:None,lookup:None,cleanup:None,diagnostic:CleanupObservation{primary:OK,rollback:OK,unknown_fence:OK,actual_autocommit:1}}}
 pub(super) fn response(&mut self,a:Action,s:i32,release:bool){self.responses.push_back((a,s,release));}
 pub(super) fn count(&self,a:Action)->usize{self.calls[a as usize]}
}
macro_rules! issue{($c:expr,$field:ident,$ty:ident)=>{{let b=$c.$field.get_or_insert_with(||Box::new($ty{_opaque:[],_controlled:1}));&mut **b as *mut $ty}}}
macro_rules! dispose{($c:expr,$owner:expr,$field:ident,$release:expr)=>{{if $release&&!$owner.$field.is_null(){let b=$c.$field.as_mut().expect("controlled owner exists");assert_eq!($owner.$field,&mut **b as *mut _);$owner.$field=ptr::null_mut();$c.$field.take();$c.released+=1;}}}}
impl<'op>ForeignSlots<'op>{
 pub(super)fn controlled_observation(&self)->CleanupObservation{self.controlled.as_ref().expect("controlled dispatch").borrow_mut().diagnostic_reads+=1;self.observation.expect("successful controlled diagnostic")}
 pub(super) fn controlled_call(&mut self,a:Action)->i32{
  let rc=self.controlled.as_ref().expect("explicit private test dispatcher").clone();let mut c=rc.borrow_mut();c.calls[a as usize]+=1;
  let(st,release)=if c.responses.front().is_some_and(|(expected,_,_)|*expected==a){let(_,s,r)=c.responses.pop_front().unwrap();(s,r)}else{(OK,true)};
  match a{
   Action::Prepare=>{assert!(self.pending.is_null());self.pending=issue!(c,pending,Pending);},
   Action::Begin=>{assert!(self.write.is_null());if st==OK{self.write=issue!(c,write,Write);}},
   Action::Finish=>{assert!(self.finish.is_null());self.finish=issue!(c,finish,Finish);dispose!(c,self,write,release);},
   Action::Lookup=>{assert!(self.lookup.is_null());if st==OK{self.lookup=issue!(c,lookup,Lookup);}},
   Action::Take=>{assert!(self.cleanup.is_null());if st==OK&&c.stash{self.cleanup=issue!(c,cleanup,Cleanup);c.stash=false;}},
   Action::Observe=>{if st==OK{self.observation=Some(c.diagnostic);}},
   Action::PendingDrop=>dispose!(c,self,pending,release),Action::WriteDrop=>dispose!(c,self,write,release),Action::FinishDrop=>dispose!(c,self,finish,release),Action::LookupDrop=>dispose!(c,self,lookup,release),Action::CleanupDrop=>dispose!(c,self,cleanup,release),_=>{}
  }
  st
 }
}
fn actual_snapshot()->NativeSnapshotHandle{
 let(_,mut snapshot,remote,local,wire)=super::super::super::tests::setup();
 super::super::super::tests::prepare(&mut snapshot,&remote,&local,&wire);snapshot
}
fn original(s:&NativeSnapshotHandle,length:usize)->IssuedOriginal<'_>{IssuedOriginal{snapshot:SnapshotCustody::Borrowed(s),resources:ResourceCustody::FixtureOwned(NativeIssuedResources{proof:NativeIssuerProof::ControlledOnly,store:ptr::null_mut(),lease:ptr::null(),intent:ptr::null(),journal:vec![ptr::null();length],queue:IssuedQueue::Inbox(ptr::null()),actor:0,issuer:Rc::new(()),bound:PhantomData}),actor:PhantomData}}
fn slots<'a>(o:&'a IssuedOriginal<'a>,c:Rc<RefCell<Control>>)->ForeignSlots<'a>{ForeignSlots{original:OriginalCustody::Borrowed(o),pending:ptr::null_mut(),write:ptr::null_mut(),finish:ptr::null_mut(),lookup:ptr::null_mut(),cleanup:ptr::null_mut(),store_cleanup_pending:false,cleanup_primary:None,unknown:false,local_finished:false,lifecycle:Lifecycle::Fresh,observation:None,controlled:Some(c)}}
fn writing(f:&mut ForeignSlots<'_>){assert!(matches!(f.prepare(),Ok(MechanicalStatus::Prepared)));assert!(matches!(f.begin_original_journal(),Ok(MechanicalStatus::Prepared)));}
fn assert_wire(s:&NativeSnapshotHandle,wire:&[u8],journal:usize){let g=s.stage.gate.0.borrow();assert_eq!(g.original_ciphertext.as_deref(),Some(wire));assert_eq!(g.journal.len(),journal);}
fn reject_effects(f:&mut ForeignSlots<'_>,c:&Rc<RefCell<Control>>){let before=c.borrow().calls;assert!(f.prepare().is_err());assert!(f.begin_original_journal().is_err());assert!(f.finish_original().is_err());assert!(f.lookup_original().is_err());assert!(f.publish_once().is_err());assert_eq!(c.borrow().calls,before);}
#[test]fn r15_l1_double_prepare_and_begin_preserve_unique_output_owner(){
 let s=actual_snapshot();let wire=s.stage.gate.0.borrow().original_ciphertext.clone().unwrap();let journal=s.stage.gate.0.borrow().journal.len();let o=original(&s,2);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());
 assert!(f.prepare().is_ok());let p=f.pending;assert!(!p.is_null());assert!(matches!(f.prepare(),Err(PortError::Rejected)));assert_eq!(f.pending,p);assert_eq!(c.borrow().count(Action::Prepare),1);assert_eq!(c.borrow().released,0);
 assert!(f.begin_original_journal().is_ok());let w=f.write;let before=c.borrow().calls;assert!(matches!(f.begin_original_journal(),Err(PortError::Rejected)));assert_eq!(c.borrow().calls,before);assert_eq!(f.write,w);assert_eq!(c.borrow().released,1);assert_wire(&s,&wire,journal);
}
#[test]fn r15_l1_finished_lookup_and_populated_slots_reject_before_effect(){
 for finished in [false,true]{let s=actual_snapshot();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());
  if finished{writing(&mut f);assert!(matches!(f.finish_original(),Ok(MechanicalStatus::LocalCommittedOnly)));assert!(!f.finish.is_null());}else{assert!(matches!(f.lookup_original(),Ok(MechanicalStatus::LocalCommittedOnly)));assert!(!f.lookup.is_null());}
  reject_effects(&mut f,&c);
 }
 let s=actual_snapshot();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());assert!(f.prepare().is_ok());let p=f.pending;let calls=c.borrow().calls;assert!(f.lookup_original().is_err());assert!(f.finish_original().is_err());assert_eq!(c.borrow().calls,calls);assert_eq!(f.pending,p);
}
#[test]fn r15_l1_overbound_journal_zero_begin_and_zero_pending_release(){
 let s=actual_snapshot();let o=original(&s,33);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());assert!(f.prepare().is_ok());let p=f.pending;let before=c.borrow().calls;
 assert!(matches!(f.begin_original_journal(),Err(PortError::Capacity)));assert_eq!(c.borrow().calls,before);assert_eq!(c.borrow().count(Action::Begin),0);assert_eq!(c.borrow().count(Action::PendingDrop),0);assert_eq!(f.pending,p);
}
#[test]fn r15_l1_pending_cleanup_refusal_forbids_begin_and_retry(){
 let s=actual_snapshot();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());assert!(f.prepare().is_ok());let p=f.pending;c.borrow_mut().response(Action::PendingDrop,3,false);
 assert!(matches!(f.begin_original_journal(),Ok(MechanicalStatus::HeldCleanup(3))));assert_eq!(f.pending,p);assert_eq!(c.borrow().count(Action::Begin),0);reject_effects(&mut f,&c);
}
#[test]fn r15_l2_cancel_unknown_retained_write_sticky_and_cleanup_does_not_reset(){
 let s=actual_snapshot();let wire=s.stage.gate.0.borrow().original_ciphertext.clone().unwrap();let journal=s.stage.gate.0.borrow().journal.len();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());writing(&mut f);let w=f.write;
 c.borrow_mut().response(Action::Cancel,UNKNOWN,false);c.borrow_mut().response(Action::WriteDrop,3,false);
 assert!(matches!(f.cancel_and_release_ram(),MechanicalStatus::HeldCleanup(UNKNOWN)));assert_eq!(f.write,w);assert!(f.unknown);assert!(s.stage.gate.0.borrow().phase==super::super::super::super::Phase::Unknown);reject_effects(&mut f,&c);
 assert!(matches!(f.cancel_and_release_ram(),MechanicalStatus::Unknown));assert!(f.write.is_null());assert!(f.unknown);assert!(matches!(f.cancel_and_release_ram(),MechanicalStatus::Unknown));reject_effects(&mut f,&c);assert_wire(&s,&wire,journal);
}
#[test]fn r15_l2_every_later_drop_unknown_survives_earlier_primary(){
 for late in [Action::FinishDrop,Action::LookupDrop,Action::PendingDrop]{
  let s=actual_snapshot();let wire=s.stage.gate.0.borrow().original_ciphertext.clone().unwrap();let journal=s.stage.gate.0.borrow().journal.len();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());writing(&mut f);
  // Explicit controlled retained error capsule, never passed to native C.
  {let mut cc=c.borrow_mut();match late{Action::FinishDrop=>f.finish=issue!(cc,finish,Finish),Action::LookupDrop=>f.lookup=issue!(cc,lookup,Lookup),Action::PendingDrop=>f.pending=issue!(cc,pending,Pending),_=>unreachable!()}}
  c.borrow_mut().response(Action::Cancel,3,false);c.borrow_mut().response(Action::WriteDrop,3,false);c.borrow_mut().response(late,UNKNOWN,false);
  assert!(matches!(f.cancel_and_release_ram(),MechanicalStatus::HeldCleanup(3)));assert_eq!(f.cleanup_primary,Some(3));assert!(f.unknown);assert!(s.stage.gate.0.borrow().phase==super::super::super::super::Phase::Unknown);assert!(c.borrow().responses.is_empty());reject_effects(&mut f,&c);assert_wire(&s,&wire,journal);
 }
}
#[test]fn r15_l2_pending_release_unknown_is_observed_before_held_return(){
 let s=actual_snapshot();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());assert!(f.prepare().is_ok());let p=f.pending;c.borrow_mut().response(Action::PendingDrop,UNKNOWN,false);
 assert!(matches!(f.begin_original_journal(),Ok(MechanicalStatus::HeldCleanup(UNKNOWN))));assert_eq!(f.pending,p);assert!(f.unknown);assert_eq!(c.borrow().count(Action::Begin),0);reject_effects(&mut f,&c);
}
#[test]fn r15_failed_begin_and_lookup_null_business_keep_cleanup_owner(){
 for lookup in [false,true]{let s=actual_snapshot();let wire=s.stage.gate.0.borrow().original_ciphertext.clone().unwrap();let journal=s.stage.gate.0.borrow().journal.len();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());c.borrow_mut().stash=true;
  if lookup{c.borrow_mut().response(Action::Lookup,3,false);assert!(matches!(f.lookup_original(),Ok(MechanicalStatus::HeldCleanup(3))));assert!(f.lookup.is_null());}else{assert!(f.prepare().is_ok());c.borrow_mut().response(Action::Begin,3,false);assert!(matches!(f.begin_original_journal(),Ok(MechanicalStatus::HeldCleanup(3))));assert!(f.write.is_null());}
  let cleanup=f.cleanup;assert!(!cleanup.is_null());c.borrow_mut().response(Action::CleanupDrop,REQUIRED,false);assert!(matches!(f.retry_cleanup_owner(),MechanicalStatus::HeldCleanup(3)));assert_eq!(f.cleanup,cleanup);assert!(f.unknown);reject_effects(&mut f,&c);assert_wire(&s,&wire,journal);
 }
}
#[test]fn r15_take_refusal_retains_store_borrow_and_observation_uncertainty(){
 let s=actual_snapshot();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());c.borrow_mut().stash=true;c.borrow_mut().response(Action::Lookup,3,false);c.borrow_mut().response(Action::Take,4,false);
 assert!(matches!(f.lookup_original(),Ok(MechanicalStatus::HeldCleanup(3))));assert!(f.store_cleanup_pending);assert!(f.cleanup.is_null());reject_effects(&mut f,&c);
 c.borrow_mut().diagnostic=CleanupObservation{primary:3,rollback:OK,unknown_fence:UNKNOWN,actual_autocommit:1};c.borrow_mut().response(Action::CleanupDrop,REQUIRED,false);
 assert!(matches!(f.retry_cleanup_owner(),MechanicalStatus::HeldCleanup(3)));assert!(!f.store_cleanup_pending);assert!(!f.cleanup.is_null());assert_eq!(f.observation.unwrap().unknown_fence,UNKNOWN);assert!(f.unknown);assert_eq!(f.cleanup_primary,Some(3));reject_effects(&mut f,&c);
}
#[test]fn r15_scope_unknown_rebind_cancel_revoke_cannot_restore_foreign_effects(){
 for terminal in 0..3{let s=actual_snapshot();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());writing(&mut f);s.stage.gate.1.fixture_unknown();match terminal{0=>s.stage.gate.1.fixture_rebind(4),1=>s.stage.gate.1.cancel(),_=>s.stage.gate.1.fixture_revoke()};reject_effects(&mut f,&c);assert!(f.unknown);}
}
#[test]fn r15_p1_first_primary_independent_of_cancel_and_disposal(){
 for prior in [None,Some(3)]{for cancel in [OK,4,UNKNOWN]{for release in [false,true]{
  let s=actual_snapshot();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());writing(&mut f);let w=f.write;f.cleanup_primary=prior;
  c.borrow_mut().response(Action::Cancel,cancel,false);c.borrow_mut().response(Action::WriteDrop,if release{OK}else{5},release);
  let result=f.cancel_and_release_ram();let expected=prior.or(if cancel!=OK{Some(cancel)}else if !release{Some(5)}else{None});
  assert_eq!(f.cleanup_primary,expected);assert_eq!(f.unknown,cancel==UNKNOWN);
  if !release{assert!(matches!(result,MechanicalStatus::HeldCleanup(n) if Some(n)==expected));assert_eq!(f.write,w);}else if cancel==UNKNOWN{assert!(matches!(result,MechanicalStatus::Unknown));}else{assert!(matches!(result,MechanicalStatus::NativeError(n) if n==expected.unwrap_or(OK)));}
  let _=f.cancel_and_release_ram();assert_eq!(f.cleanup_primary,expected);assert_eq!(f.unknown,cancel==UNKNOWN);assert!(f.write.is_null());
 }}}
}
#[test]fn r15_l2_later_unknown_released_slots_and_diagnostic_fields_stay_sticky(){
 for late in [Action::FinishDrop,Action::LookupDrop,Action::PendingDrop]{
  let s=actual_snapshot();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());writing(&mut f);f.cleanup_primary=Some(3);
  {let mut cc=c.borrow_mut();match late{Action::FinishDrop=>f.finish=issue!(cc,finish,Finish),Action::LookupDrop=>f.lookup=issue!(cc,lookup,Lookup),Action::PendingDrop=>f.pending=issue!(cc,pending,Pending),_=>unreachable!()}}
  c.borrow_mut().response(late,UNKNOWN,true);assert!(matches!(f.cancel_and_release_ram(),MechanicalStatus::Unknown));assert!(f.all_empty());assert!(f.unknown);assert_eq!(f.cleanup_primary,Some(3));reject_effects(&mut f,&c);
 }
 for field in 0..3{
  let s=actual_snapshot();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());f.cleanup_primary=Some(3);{let mut cc=c.borrow_mut();f.cleanup=issue!(cc,cleanup,Cleanup);match field{0=>cc.diagnostic.primary=UNKNOWN,1=>cc.diagnostic.rollback=UNKNOWN,_=>cc.diagnostic.unknown_fence=UNKNOWN}}
  assert!(matches!(f.retry_cleanup_owner(),MechanicalStatus::Unknown));assert!(f.cleanup.is_null());assert!(f.unknown);assert_eq!(f.cleanup_primary,Some(3));reject_effects(&mut f,&c);
 }
}
#[test]fn r16_first_observe_failure_without_observation_retains_owner_and_primary(){
 for prior in [None,Some(3)]{for error in [3,4,UNKNOWN]{
  let s=actual_snapshot();let wire=s.stage.gate.0.borrow().original_ciphertext.clone().unwrap();let journal=s.stage.gate.0.borrow().journal.len();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());
  f.cleanup_primary=prior;{let mut cc=c.borrow_mut();f.cleanup=issue!(cc,cleanup,Cleanup);cc.response(Action::Observe,error,false);}
  let owner=f.cleanup;assert!(f.observation.is_none());
  assert!(matches!(f.retry_cleanup_owner(),MechanicalStatus::HeldCleanup(n) if n==prior.unwrap_or(error)));assert_eq!(f.cleanup,owner);assert!(f.observation.is_none());assert_eq!(f.cleanup_primary,Some(prior.unwrap_or(error)));assert_eq!(c.borrow().count(Action::CleanupDrop),0);assert_eq!(c.borrow().released,0);assert_eq!(c.borrow().diagnostic_reads,0);assert!(c.borrow().responses.is_empty());assert!(f.unknown);assert_wire(&s,&wire,journal);reject_effects(&mut f,&c);
 }}
}
#[test]fn r16_observe_error_after_previous_ok_never_reads_stale_diagnostic(){
 for error in [4,UNKNOWN]{
  let s=actual_snapshot();let wire=s.stage.gate.0.borrow().original_ciphertext.clone().unwrap();let journal=s.stage.gate.0.borrow().journal.len();let o=original(&s,1);let c=Rc::new(RefCell::new(Control::new()));let mut f=slots(&o,c.clone());f.cleanup_primary=Some(3);
  {let mut cc=c.borrow_mut();f.cleanup=issue!(cc,cleanup,Cleanup);cc.diagnostic=CleanupObservation{primary:3,rollback:OK,unknown_fence:REQUIRED,actual_autocommit:0};cc.response(Action::CleanupDrop,REQUIRED,false);}
  assert!(matches!(f.retry_cleanup_owner(),MechanicalStatus::HeldCleanup(3)));let owner=f.cleanup;assert!(!owner.is_null());assert_eq!(c.borrow().diagnostic_reads,1);assert!(f.observation.is_some());assert!(c.borrow().responses.is_empty());
  let drops=c.borrow().count(Action::CleanupDrop);c.borrow_mut().response(Action::Observe,error,false);
  assert!(matches!(f.retry_cleanup_owner(),MechanicalStatus::HeldCleanup(3)));assert_eq!(f.cleanup,owner);assert_eq!(c.borrow().diagnostic_reads,1);assert_eq!(c.borrow().count(Action::CleanupDrop),drops);assert_eq!(c.borrow().released,0);assert!(c.borrow().responses.is_empty());assert_eq!(f.cleanup_primary,Some(3));assert!(f.unknown);assert_wire(&s,&wire,journal);reject_effects(&mut f,&c);
 }
}
