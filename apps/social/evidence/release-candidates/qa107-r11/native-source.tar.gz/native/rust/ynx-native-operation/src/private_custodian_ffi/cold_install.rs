//! New local recovery custody. No old genesis, command, acknowledgement or grant.
use super::*;
pub(crate)struct ColdRecovery{
 pub(crate)lease:jni::refs::Global<jni::objects::JObject<'static>>,
 pub(crate)context:jni::refs::Global<jni::objects::JObject<'static>>,
 input:LocalGenesisInput,ids:[u8;32],reader:predevice_port::ExistingReader,
 thread:ThreadId,first:Option<i32>,opened:bool,cleaned:bool,discharged:bool,
}
impl ColdRecovery{
 pub(crate)fn retain(alias:String,generation:i64,association:Vec<u8>,ids:[u8;32],lease:jni::refs::Global<jni::objects::JObject<'static>>,context:jni::refs::Global<jni::objects::JObject<'static>>)->Result<Self,CustodyError>{
  // window=1 satisfies legacy metadata type only; never passed to any protector,
  // generation or authorization method. This owner exposes none of those paths.
  let input=LocalGenesisInput::checked(alias,u64::try_from(generation).map_err(|_|CustodyError::Bounds)?,association,1).map_err(|(e,_)|e)?;
  Ok(Self{lease,context,input,ids,reader:predevice_port::ExistingReader::unopened(),thread:std::thread::current().id(),first:None,opened:false,cleaned:false,discharged:false})
 }
 fn thread(&self)->Result<(),i32>{if self.thread!=std::thread::current().id(){Err(22)}else{Ok(())}}
 pub(crate)fn fail(&mut self,code:i32)->i32{if self.first.is_none(){self.first=Some(code)}self.first.unwrap_or(16)}
 pub(crate)fn status(&self)->i32{self.first.unwrap_or(if self.discharged{182}else if self.cleaned{183}else if self.reader.cold_stage().is_ok(){181}else{180})}
 pub(crate)fn open(&mut self,path:&std::ffi::CStr)->i32{
  if let Err(e)=self.thread(){return e}if self.opened||self.cleaned||self.first.is_some(){return self.fail(16)}
  self.opened=true;if self.reader.open_once(path).is_err(){self.fail(16)}else{180}
 }
 fn ids(&self)->([u8;16],[u8;16]){let mut op=[0;16];let mut inc=[0;16];op.copy_from_slice(&self.ids[..16]);inc.copy_from_slice(&self.ids[16..]);(op,inc)}
 pub(crate)fn opened(&self)->bool{self.opened}
 pub(crate)fn advance(&mut self,discharge:bool)->i32{
  if let Err(e)=self.thread(){return e}
  if self.discharged{return self.status()}
  if !self.opened||self.cleaned||self.first.is_some(){return self.fail(16)}
  let(op,inc)=self.ids();
  #[cfg(test)]COLD_EFFECTS.with(|v|v.set(v.get()+1));
  if self.reader.prepare_cold(&self.input,op,inc).is_err(){return self.fail(16)}
  if discharge{#[cfg(test)]COLD_EFFECTS.with(|v|v.set(v.get()+1));if self.reader.discharge_cold().is_err(){return self.fail(16)}self.discharged=true;}
  self.status()
 }
 pub(crate)fn cleanup(&mut self)->i32{
  if let Err(e)=self.thread(){return e}
  if self.discharged||self.cleaned{return if self.discharged{182}else{183}}
  match self.reader.cleanup(){
   Ok(predevice_port::ExistingCleanup::Released|predevice_port::ExistingCleanup::NoHandle)=>{self.cleaned=true;183},
   _=>self.fail(16)
  }
 }
 pub(crate)fn releasable(&self)->bool{self.cleaned||self.discharged}
}

#[cfg(test)]thread_local!{pub(crate)static COLD_EFFECTS:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}
#[cfg(test)]impl ColdRecovery{
 pub(crate)fn fixture_effect_count()->usize{COLD_EFFECTS.with(|v|v.get())}
 pub(crate)fn fixture_first(&self)->Option<i32>{self.first}
 pub(crate)fn fixture_reserved()->std::ffi::CString{
  use std::os::unix::fs::DirBuilderExt;
  let root=std::path::PathBuf::from(std::env::var_os("TMPDIR").unwrap()).join(format!("panic-public-{}",std::process::id()));
  std::fs::DirBuilder::new().mode(0o700).create(&root).unwrap();
  let path=std::ffi::CString::new(root.join("pair.sqlite3").as_os_str().as_encoded_bytes()).unwrap();
  let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public"));
  let mut owner=predevice_port::PreDeviceOwner::unopened([1;16],[2;16]);owner.reserve(&path,&input).unwrap();owner.close_known().unwrap();path
 }
}
