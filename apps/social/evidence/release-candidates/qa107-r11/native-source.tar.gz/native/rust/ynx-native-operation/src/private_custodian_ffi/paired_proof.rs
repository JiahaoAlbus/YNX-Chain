//! Exact selected YPA1 grant/type4 parsing. Structural validity is NOT consent.
//! No normal authorization constructor exists until independent original
//! proposal/realm/principals/currentness/nonce ownership is actually supplied.
use super::*;
#[path="paired_attempt.rs"]
pub(super) mod paired_attempt;
#[path="first_genesis.rs"]
pub(super) mod first_genesis;
#[path="source_request.rs"]
pub(super) mod source_request;

struct Type4<'a>{issuer:bool,wire:&'a[u8],transcript:&'a[u8],classic:&'a[u8],pq:&'a[u8]}
pub(super)enum NativeSigningAuthorization<'a>{
 #[cfg(feature="abi5-final-native-link")]Original{guard:&'a crate::source_infrastructure::platform::OriginalSigningGuard,input:&'a source_request::OriginalProviderInput<'a>},
 Unavailable(std::convert::Infallible,std::marker::PhantomData<&'a()>),
}
pub(super)struct AuthorizedType4<'a>{parsed:Type4<'a>,authorization:NativeSigningAuthorization<'a>}
pub(super)struct PairProof{pub(super)classic:Box<[u8]>,pub(super)pq:[u8;4627]}

fn frame<const N:usize>(wire:&[u8],kind:u8)->Result<[&[u8];N],CustodyError>{
 if wire.len()>65536||wire.len()<8||&wire[..4]!=b"YPA1"||wire[4]!=kind||wire[5]!=1||u16::from_be_bytes([wire[6],wire[7]])as usize!=N{return Err(CustodyError::Bounds)}
 let mut c=Cursor{bytes:wire,at:8};let mut fields=[&[][..];N];
 for(i,f)in fields.iter_mut().enumerate(){let tag=u16::from_be_bytes(c.take(2)?.try_into().map_err(|_|CustodyError::Bounds)?);if tag as usize!=i+1{return Err(CustodyError::Bounds)}let n=c.n()?;*f=c.take(n)?;}
 if c.at!=wire.len(){return Err(CustodyError::Bounds)}Ok(fields)
}
fn ascii(b:&[u8],max:usize)->Result<(),CustodyError>{if b.is_empty()||b.len()>max||!b.iter().all(|v|(33..=126).contains(v)){Err(CustodyError::Bounds)}else{Ok(())}}
fn number(b:&[u8],min:u64)->Result<u64,CustodyError>{let v=u64::from_be_bytes(b.try_into().map_err(|_|CustodyError::Bounds)?);if v<min||v>9007199254740991{Err(CustodyError::Bounds)}else{Ok(v)}}
fn principal(wire:&[u8])->Result<[&[u8];12],CustodyError>{
 let p=frame::<12>(wire,1)?;ascii(p[0],128)?;ascii(p[1],128)?;ascii(p[11],256)?;
 if p[2]!=b"LIBSIGNAL-0.104.0-XEDDSA-CANDIDATE"||p[4]!=b"ML-DSA-87"||p[3].len()!=33||p[3][0]!=5||p[5].len()!=2592||p[9].len()!=32||p[10].len()!=32{return Err(CustodyError::Pair)}
 for field in &p[6..9]{number(field,1)?;}Ok(p)
}
impl<'a>Type4<'a>{
 fn parse(wire:&'a[u8])->Result<Self,CustodyError>{
  let m=frame::<4>(wire,4)?;
  if m[0]!=b"YNX/SOCIAL/PQ-AUTH/SIGN/V1"||m[3].is_empty()||m[3].len()>49152{return Err(CustodyError::Bounds)}
  let issuer=match(m[1],m[2]){(b"authorization",b"issuer")=>true,(b"possession",b"target")=>false,_=>return Err(CustodyError::Bounds)};
  let a=frame::<16>(m[3],3)?;
  if a[0]!=b"YNX-SOCIAL"||number(a[2],1)?!=1{return Err(CustodyError::Bounds)}ascii(a[1],128)?;
  if ![b"enroll".as_slice(),b"add",b"revoke",b"rotate",b"migrate"].contains(&a[3]){return Err(CustodyError::Bounds)}
  if !issuer&&a[3]==b"revoke"{return Err(CustodyError::Phase)}
  let i=principal(a[4])?;let t=principal(a[5])?;
  if i[0]!=t[0]||a[6].len()!=32||a[7].len()!=32||a[6]==a[7]||a[10].len()!=32||a[13].len()!=32||a[14].is_empty()||a[14].len()>8192||a[15].len()>4096{return Err(CustodyError::Bounds)}
  let prior=number(a[8],1)?;if number(a[9],2)?!=prior+1{return Err(CustodyError::Bounds)}
  let issued=number(a[11],0)?;let expires=number(a[12],0)?;if expires<=issued||expires-issued>120000{return Err(CustodyError::Bounds)}
  if (a[3]==b"migrate")!=(!a[15].is_empty()){return Err(CustodyError::Bounds)}
  if a[3]==b"enroll"&&(i[1]!=t[1]||i[3]!=t[3]||i[5]!=t[5]){return Err(CustodyError::Pair)}
  let p=if issuer{i}else{t};Ok(Self{issuer,wire,transcript:m[3],classic:p[3],pq:p[5]})
 }
}
impl recovery::RecoveryLoan<'_>{
 // No JNI caller can construct AuthorizedType4 from public bytes or flags.
 // Public bytes cannot qualify authorization; only the retained platform guard can.
 pub(super)fn sign_type4(&mut self,request:&AuthorizedType4<'_>)->Result<PairProof,CustodyError>{
  request.current()?;let parsed=Type4::parse(request.parsed.wire)?;
  if self.0.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  let slot=if parsed.issuer{0}else{1};
  let transaction=*self.0.local_ids.as_ref().ok_or(CustodyError::Phase)?;
  self.0.type4_attempts.check(slot,&transaction,parsed.transcript,parsed.wire)?;
  if let Some(a)=self.0.type4_attempts.get(slot){
   if !a.unresolved(){
    self.0.custody.as_ref().ok_or(CustodyError::Phase)?.live()?;
    let public=self.public_pair()?;
    if parsed.classic!=public.classic||parsed.pq!=public.pq{return Err(CustodyError::Pair)}
   }
   let result=a.observe(parsed.wire);if request.current().is_err(){if let Some(c)=self.0.custody.as_mut(){c.unknown=true}return Err(CustodyError::Unknown)}return result
  }
  let public=self.public_pair()?;
  if parsed.classic!=public.classic||parsed.pq!=public.pq||parsed.transcript!=request.parsed.transcript{return Err(CustodyError::Pair)}
  let custody=self.0.custody.as_mut().ok_or(CustodyError::Phase)?;custody.live()?;
  let classic=custody.classic.as_ref().ok_or(CustodyError::Phase)?;
  let attempt=self.0.type4_attempts.install(slot,&transaction,parsed.transcript,parsed.wire)?;
  let pq_owner=custody.pq;
  attempt.run_once(
   ||{request.current()?;let result=classic.sign_pair_transcript(parsed.wire).map_err(|_|CustodyError::Pair)?;request.current()?;Ok(result)},
   ||{request.current()?;let mut pq=[0;4627];let mut written=0;let code=unsafe{veil_own_sign_public_proof(pq_owner,parsed.wire.as_ptr(),parsed.wire.len(),pq.as_mut_ptr(),&mut written)};
      if code==5||code==9{return Err(CustodyError::Unknown)}
      if code!=0{return Err(CustodyError::Foreign(code))}
      if written!=pq.len(){return Err(CustodyError::Abi)}request.current()?;Ok(pq)}
  );
  let result=attempt.observe(parsed.wire);
  if request.current().is_err(){custody.unknown=true;return Err(CustodyError::Unknown)}
  match &result{Err(CustodyError::Unknown|CustodyError::Abi)=>custody.unknown=true,Err(CustodyError::Foreign(n))=>{let _=custody.result(n.to_owned());},_=>{}}
  result
 }
}
#[cfg(test)]mod tests{
 use super::*;
 unsafe extern "C"{fn own_selected_verify(pk:*const u8,pn:usize,m:*const u8,n:usize,sig:*const u8,sn:usize)->i32;}
 // Test-only copy protector. It is NOT AES-GCM/Android authentication and
 // NEVER constructs AuthenticatedPair/AuthorizedType4 or a native grant.
 unsafe extern "C" fn copy_seal(_: *mut c_void,_aad:*const u8,_an:usize,clear:*const u8,n:usize,nonce:*mut u8,cipher:*mut u8,w:*mut usize)->i32{if n!=4896{return 1}unsafe{std::ptr::copy_nonoverlapping(clear,cipher,n);std::ptr::write_bytes(cipher.add(n),0,16);std::ptr::write_bytes(nonce,0,12);*w=4912;}0}
 unsafe extern "C" fn copy_open(_: *mut c_void,_aad:*const u8,_an:usize,_nonce:*const u8,cipher:*const u8,clear:*mut u8,n:usize,w:*mut usize)->i32{if n!=4896{return 1}unsafe{std::ptr::copy_nonoverlapping(cipher,clear,n);*w=n;}0}
 struct FixturePq(*mut PqOpaque);
 impl Drop for FixturePq{fn drop(&mut self){if !self.0.is_null(){assert_eq!(unsafe{veil_own_close(&mut self.0)},0)}}}
 struct FixtureRecord(PqRecord);
 impl Drop for FixtureRecord{fn drop(&mut self){use zeroize::Zeroize;self.0.cipher.zeroize();}}
 #[test]fn r62_selected_both_signatures_after_same_pair_fixture_reload(){
  let private=libsignal_protocol::PrivateKey::deserialize(&[23;32]).unwrap();let original=NativeClassicOwnKey::from_selected(libsignal_protocol::IdentityKeyPair::new(private.public_key().unwrap().into(),private)).unwrap();
  let public=original.public_identity();let classic=original.serialize_for_native_custody().unwrap().reload_for_native_binding(public).unwrap();
  let binding=StorageBinding::new("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef",1,public.serialize().as_ref().try_into().unwrap(),vec![7]).unwrap();let b=binding.ffi();
  let protector=PqProtector{context:std::ptr::null_mut(),seal:Some(copy_seal),unseal:Some(copy_open)};
  let mut record=FixtureRecord(PqRecord{version:0,aad_size:0,aad:[0;7168],nonce:[0;12],cipher:[0;4912]});let mut first=FixturePq(std::ptr::null_mut());
  assert_eq!(unsafe{veil_own_create_sealed(&b,&protector,&mut first.0,&mut record.0)},0,"actual selected PQ create/mandatory residency");
  let mut pq=[0;2592];assert_eq!(unsafe{veil_own_public(first.0,pq.as_mut_ptr())},0);
  let mut restored=FixturePq(std::ptr::null_mut());assert_eq!(unsafe{veil_own_reload(&b,pq.as_ptr(),&record.0,&protector,&mut restored.0)},0);
  let mut restored_public=[0;2592];assert_eq!(unsafe{veil_own_public(restored.0,restored_public.as_mut_ptr())},0);assert_eq!(pq,restored_public);
  let one=1u64.to_be_bytes();let two=2u64.to_be_bytes();let issued=100u64.to_be_bytes();let expires=200u64.to_be_bytes();let p=f(1,&[b"identity",b"device",b"LIBSIGNAL-0.104.0-XEDDSA-CANDIDATE",public.serialize().as_ref(),b"ML-DSA-87",&pq,&one,&one,&one,&[1;32],&[2;32],b"route"]);let a=f(3,&[b"YNX-SOCIAL",b"realm",&one,b"enroll",&p,&p,&[1;32],&[2;32],&one,&two,&[3;32],&issued,&expires,&[4;32],b"set",b""]);let message=f(4,&[b"YNX/SOCIAL/PQ-AUTH/SIGN/V1",b"possession",b"target",&a]);
  let parsed=Type4::parse(&message).unwrap();assert_eq!(parsed.classic,public.serialize().as_ref());assert_eq!(parsed.pq,pq);
  let c=classic.sign_pair_transcript(&message).unwrap();let mut sig=[0;4627];let mut n=0;assert_eq!(unsafe{veil_own_sign_public_proof(restored.0,message.as_ptr(),message.len(),sig.as_mut_ptr(),&mut n)},0);assert_eq!(n,4627);
  assert!(public.public_key().verify_signature(&message,&c));assert_eq!(unsafe{own_selected_verify(pq.as_ptr(),pq.len(),message.as_ptr(),message.len(),sig.as_ptr(),sig.len())},1);
  let mut changed=message.clone();*changed.last_mut().unwrap()^=1;assert!(!public.public_key().verify_signature(&changed,&c));assert_eq!(unsafe{own_selected_verify(pq.as_ptr(),pq.len(),changed.as_ptr(),changed.len(),sig.as_ptr(),sig.len())},0);
  let mut wrong=pq;wrong[0]^=1;let mut refused=FixturePq(std::ptr::null_mut());assert_eq!(unsafe{veil_own_reload(&b,wrong.as_ptr(),&record.0,&protector,&mut refused.0)},1);assert!(refused.0.is_null());
 }
 fn f(kind:u8,fields:&[&[u8]])->Vec<u8>{let mut v=b"YPA1".to_vec();v.extend([kind,1]);v.extend((fields.len()as u16).to_be_bytes());for(i,b)in fields.iter().enumerate(){v.extend(((i+1)as u16).to_be_bytes());v.extend((b.len()as u32).to_be_bytes());v.extend(*b)}v}
 fn fixture()->Vec<u8>{let mut c=[9;33];c[0]=5;let one=1u64.to_be_bytes();let two=2u64.to_be_bytes();let issued=100u64.to_be_bytes();let expires=200u64.to_be_bytes();let p=f(1,&[b"identity",b"device",b"LIBSIGNAL-0.104.0-XEDDSA-CANDIDATE",&c,b"ML-DSA-87",&[7;2592],&one,&one,&one,&[1;32],&[2;32],b"route"]);let a=f(3,&[b"YNX-SOCIAL",b"realm",&one,b"enroll",&p,&p,&[1;32],&[2;32],&one,&two,&[3;32],&issued,&expires,&[4;32],b"set",b""]);f(4,&[b"YNX/SOCIAL/PQ-AUTH/SIGN/V1",b"possession",b"target",&a])}
 #[test]fn r62_type4_full_nested_parse_not_permission(){let m=fixture();let p=Type4::parse(&m).unwrap();assert_eq!(p.pq,[7;2592]);let mut trailing=m.clone();trailing.push(0);assert!(Type4::parse(&trailing).is_err());let mut wrong=m.clone();wrong[9]=2;assert!(Type4::parse(&wrong).is_err());let at=m.windows(6).position(|v|v==b"enroll").unwrap();let mut wrong=m;wrong[at..at+6].copy_from_slice(b"bogus!");assert!(Type4::parse(&wrong).is_err());}
 #[test]fn r62_selected_classic_signature_same_original_message(){let private=libsignal_protocol::PrivateKey::deserialize(&[19;32]).unwrap();let pair=libsignal_protocol::IdentityKeyPair::new(private.public_key().unwrap().into(),private);let owner=NativeClassicOwnKey::from_selected(pair).unwrap();let message=fixture();let sig=owner.sign_pair_transcript(&message).unwrap();assert_eq!(sig.len(),64);assert!(owner.public_identity().public_key().verify_signature(&message,&sig));let mut changed=message;changed.push(0);assert!(!owner.public_identity().public_key().verify_signature(&changed,&sig));}
}

impl AuthorizedType4<'_>{fn current(&self)->Result<(),CustodyError>{match &self.authorization{
 #[cfg(feature="abi5-final-native-link")]NativeSigningAuthorization::Original{guard,input}=>guard.check_type4(input,self.parsed.wire).map_err(|_|CustodyError::Unknown),
 NativeSigningAuthorization::Unavailable(never,_)=>match *never{},
}}}
#[cfg(feature="abi5-final-native-link")]
pub(in crate::private_custodian_ffi)fn sign_original_pairs(parts:&mut source_request::OriginalSigningParts<'_>,custody:&mut NativeOwnKeyCustody,attempts:&mut paired_attempt::Type4Slots,transaction:&[u8;32],classic_public:&[u8],pq_public:&[u8])->Result<(),CustodyError>{
 parts.input.check_signing_pair(classic_public,pq_public,transaction)?;
 let i=Type4::parse(parts.issuer)?;let t=Type4::parse(parts.target)?;
 if !i.issuer||t.issuer||i.transcript!=t.transcript{return Err(CustodyError::Pair)}
 attempts.check(0,transaction,i.transcript,i.wire)?;attempts.check(1,transaction,t.transcript,t.wire)?;
 custody.live()?;parts.guard.enter(&parts.input).map_err(|_|CustodyError::Unknown)?;
 for parsed in [i,t]{
  // Authorization cannot escape this scope. Its fields are private and require
  // the real returned guard, actual original input and exact retained role.
  let request=AuthorizedType4{parsed,authorization:NativeSigningAuthorization::Original{guard:parts.guard,input:&parts.input}};
  let result=sign_admitted_pair(&request,custody,attempts,transaction);
  if result.is_err(){parts.guard.invalidate();custody.unknown=true;return Err(CustodyError::Unknown)}
 }
 if parts.guard.current(&parts.input).is_err(){parts.guard.invalidate();custody.unknown=true;return Err(CustodyError::Unknown)}Ok(())
}
#[cfg(feature="abi5-final-native-link")]
fn sign_admitted_pair(request:&AuthorizedType4<'_>,custody:&mut NativeOwnKeyCustody,attempts:&mut paired_attempt::Type4Slots,transaction:&[u8;32])->Result<(),CustodyError>{
 request.current()?;custody.live()?;let parsed=&request.parsed;let slot=if parsed.issuer{0}else{1};
 attempts.check(slot,transaction,parsed.transcript,parsed.wire)?;
 if let Some(attempt)=attempts.get(slot){let _=attempt.observe(parsed.wire)?;request.current()?;return Ok(())}
 let classic=custody.classic.as_ref().ok_or(CustodyError::Phase)?;
 if classic.public_identity().serialize().as_ref()!=parsed.classic||custody.pq_public!=parsed.pq{return Err(CustodyError::Pair)}
 let pq_owner=custody.pq;let attempt=attempts.install(slot,transaction,parsed.transcript,parsed.wire)?;
 attempt.run_once(
  ||{request.current()?;let sig=classic.sign_pair_transcript(parsed.wire).map_err(|_|CustodyError::Pair)?;request.current()?;Ok(sig)},
  ||{request.current()?;let mut sig=[0;4627];let mut written=0;let code=unsafe{veil_own_sign_public_proof(pq_owner,parsed.wire.as_ptr(),parsed.wire.len(),sig.as_mut_ptr(),&mut written)};
   if code!=0{return Err(CustodyError::Unknown)}if written!=sig.len(){return Err(CustodyError::Abi)}request.current()?;Ok(sig)}
 );
 let _=attempt.observe(parsed.wire)?;request.current()
}


// Public signatures are observations, NOT Native/server/device authorization.
#[cfg(feature="abi5-final-native-link")]
pub(in crate::private_custodian_ffi)struct ObservedOriginalPairs{issuer:PairProof,target:PairProof}
#[cfg(feature="abi5-final-native-link")]
impl ObservedOriginalPairs{
 pub(in crate::private_custodian_ffi)fn signatures(&self)->[&[u8];4]{[&self.issuer.classic,&self.issuer.pq,&self.target.classic,&self.target.pq]}
}
#[cfg(feature="abi5-final-native-link")]
pub(in crate::private_custodian_ffi)fn observe_original_pairs(parts:&source_request::OriginalSigningParts<'_>,custody:&NativeOwnKeyCustody,attempts:&paired_attempt::Type4Slots,transaction:&[u8;32],classic:&[u8],pq:&[u8])->Result<ObservedOriginalPairs,CustodyError>{
 parts.input.check_signing_pair(classic,pq,transaction)?;custody.live()?;
 parts.guard.current(&parts.input).map_err(|_|CustodyError::Unknown)?;
 let i=Type4::parse(parts.issuer)?;let t=Type4::parse(parts.target)?;
 if !i.issuer||t.issuer||i.transcript!=t.transcript{return Err(CustodyError::Pair)}
 attempts.check(0,transaction,i.transcript,i.wire)?;attempts.check(1,transaction,t.transcript,t.wire)?;
 let issuer=attempts.get(0).ok_or(CustodyError::Phase)?.observe(i.wire)?;
 let target=attempts.get(1).ok_or(CustodyError::Phase)?.observe(t.wire)?;
 if issuer.classic.len()!=64||target.classic.len()!=64{return Err(CustodyError::Abi)}
 // Neither observation nor successful copies enter/sign or acquire a guard.
 parts.guard.current(&parts.input).map_err(|_|CustodyError::Unknown)?;
 Ok(ObservedOriginalPairs{issuer,target})
}
// The view cannot outlive its exact original loan/output callback. Its public
// bytes carry no owning capability; Source owner remains in PendingSourceRequest.
#[cfg(feature="abi5-final-native-link")]
pub(crate)struct FirstDeviceSignatureView<'a>{signatures:[&'a[u8];4],operation:&'a[u8;32],nonce:&'a[u8;32],issuer:&'a[u8],target:&'a[u8]}
#[cfg(feature="abi5-final-native-link")]
impl<'a>FirstDeviceSignatureView<'a>{
 pub(crate)fn public_parts(&self)->[&[u8];8]{[self.signatures[0],self.signatures[1],self.signatures[2],self.signatures[3],self.operation,self.nonce,self.issuer,self.target]}
 pub(in crate::private_custodian_ffi)fn borrowed(p:&'a ObservedOriginalPairs,operation:&'a[u8;32],nonce:&'a[u8;32],issuer:&'a[u8],target:&'a[u8])->Self{Self{signatures:p.signatures(),operation,nonce,issuer,target}}
}

