//! Real SessionCipher, synthetic private SQL fixture only. Never native authority.
use super::*;
use futures_util::FutureExt;
use rand::{rngs::OsRng,TryRngCore as _};
use std::{time::SystemTime,task::{Wake,Waker},sync::{Arc,atomic::{AtomicUsize,Ordering}}};
#[path="../../upstream_test_support.rs"] mod upstream;
fn binding()->LeaseBinding{LeaseBinding{store:1,session:2,incarnation:3,generation:0,operation:5,context:6,route:7,device_authorization:8,revocation_checkpoint:9,source_abi:[10;32]}}
pub(super) fn setup()->(NativeStoreBridge,NativeSnapshotHandle,ProtocolAddress,ProtocolAddress,CiphertextMessage){
 let mut a=upstream::test_in_memory_protocol_store().unwrap();let mut b=upstream::test_in_memory_protocol_store().unwrap();let mut rng=OsRng.unwrap_err();let bundle=upstream::create_pre_key_bundle(&mut b,&mut rng).now_or_never().unwrap().unwrap();
 let alice=ProtocolAddress::new("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa".into(),DeviceId::new(1).unwrap());let bob=ProtocolAddress::new("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb".into(),bundle.device_id().unwrap());
 process_prekey_bundle(&bob,&alice,&mut a.session_store,&mut a.identity_store,&bundle,SystemTime::now(),&mut rng).now_or_never().unwrap().unwrap();let wire=upstream::encrypt(&mut a,&bob,&alice,"private SQL candidate").now_or_never().unwrap().unwrap();
 let gate=Gate(Rc::new(RefCell::new(Pending{phase:Phase::Working,binding:[1,2,3,0,5,6,7,8,9,0,2],bytes:0,journal:Vec::new(),original_ciphertext:Some(wire.serialize().to_vec()),generated_wire:false,selected_wire_kind:None,plaintext:None,trigger:None,pending:false})),Rc::new(spqr::ynx_operation::CallScope::fixture([1,2,3,0,5,6,7,8,9,0,2])));
 let stage=StagedOperation{identity:Identity{snapshot:Box::new(b.identity_store.clone()),gate:gate.clone()},ec:EC{snapshot:Box::new(b.pre_key_store.clone()),gate:gate.clone()},kyber:Kyber{snapshot:Box::new(b.kyber_pre_key_store.clone()),gate:gate.clone()},sessions:Sessions{snapshot:Box::new(b.session_store.clone()),gate:gate.clone()},gate};
 let snapshot=NativeSnapshotHandle{stage,signed:Box::new(b.signed_pre_key_store.clone()),lease:NativeLease{binding:binding(),authority:Authority::Fixture},queue:QueueKind::Inbound,computation:None,budget:Some(SnapshotReservation{snapshot_bytes:MAX_SNAPSHOT_BYTES,source:ReservationSource::Fixture})};
 let sql=FixtureSql{binding:binding(),store:b,revoked:false,fail_at:None,unknown_after_apply:false,lookup_pending:false,before_commit_transition:None,receipts:0,submissions:0,lookups:0,queues:Vec::new(),receipt:None};
 (NativeStoreBridge{actor:11,issuer:Rc::new(()),next:0,backend:NativeBackend::Fixture(sql),pending:RetentionLedger::new(),retained_bytes:0,tombstones:VecDeque::new(),custody:Rc::new(RefCell::new(ActorCustody::new()))},snapshot,alice,bob,wire)
}
pub(super) fn prepare(s:&mut NativeSnapshotHandle,a:&ProtocolAddress,b:&ProtocolAddress,wire:&CiphertextMessage){let mut rng=OsRng.unwrap_err();s.execute_receive(a,b,wire,&mut rng).now_or_never().unwrap().unwrap_or_else(|_|panic!("actual native computation"));}
fn sql(bridge:&mut NativeStoreBridge)->&mut FixtureSql{match &mut bridge.backend{NativeBackend::Fixture(f)=>f,_=>panic!("fixture")}}
struct Notify(AtomicUsize);impl Wake for Notify{fn wake(self:Arc<Self>){self.0.fetch_add(1,Ordering::SeqCst);}fn wake_by_ref(self:&Arc<Self>){self.0.fetch_add(1,Ordering::SeqCst);}}
fn poll(b:&mut NativeStoreBridge,h:&mut NativePendingHandle)->Poll<Result<FinalStatus,PortError>>{let w=Waker::noop();b.poll_final(h,&mut Context::from_waker(w))}
#[test]fn actual_initial_receive_single_fixture_transaction_and_once_output(){
 let(mut b,mut s,a,local,wire)=setup();prepare(&mut s,&a,&local,&wire);assert_eq!(s.stage.gate.0.borrow().journal.len(),4);
 assert!(sql(&mut b).store.get_identity(&a).now_or_never().unwrap().unwrap().is_none());let mut h=b.retain_prepared(s).unwrap_or_else(|_|panic!("retain"));
 assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::FixtureApplied))));let f=sql(&mut b);assert_eq!((f.submissions,f.receipts,f.queues.len()),(1,1,1));assert_eq!(f.queues[0],wire.serialize());assert!(f.store.get_identity(&a).now_or_never().unwrap().unwrap().is_some());assert!(f.store.load_session(&a).now_or_never().unwrap().unwrap().is_some());
 let output=b.consume_once(&mut h).unwrap_or_else(|_|panic!("consume"));assert_eq!(output.ciphertext,wire.serialize());assert_eq!(output.plaintext.unwrap(),b"private SQL candidate");assert!(matches!(b.consume_once(&mut h),Err(PortError::Consumed)));
}
#[test]fn each_mutation_and_queue_failure_leave_entire_live_fixture_unchanged(){
 for at in 0..5{let(mut b,mut s,a,local,wire)=setup();let ec=*sql(&mut b).store.all_pre_key_ids().next().unwrap();prepare(&mut s,&a,&local,&wire);sql(&mut b).fail_at=Some(at);let mut h=b.retain_prepared(s).unwrap_or_else(|_|panic!());assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Err(PortError::Rejected))));
 let f=sql(&mut b);assert_eq!(f.binding.generation,0);assert_eq!(f.receipts,0);assert!(f.queues.is_empty());assert!(f.store.get_identity(&a).now_or_never().unwrap().unwrap().is_none());assert!(f.store.get_pre_key(ec).now_or_never().unwrap().is_ok());assert!(f.store.load_session(&a).now_or_never().unwrap().unwrap().is_none());assert!(b.consume_once(&mut h).is_err());
 }
}
#[test]fn unknown_lookup_pending_retains_cipher_never_resubmits_then_consumes_once(){
 let(mut b,mut s,a,local,wire)=setup();prepare(&mut s,&a,&local,&wire);sql(&mut b).unknown_after_apply=true;sql(&mut b).lookup_pending=true;let mut h=b.retain_prepared(s).unwrap_or_else(|_|panic!());assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));assert!(matches!(b.cancel(&mut h),Err(PortError::Unknown)));assert!(matches!(b.consume_once(&mut h),Err(PortError::Unknown)));
 let notify=Arc::new(Notify(AtomicUsize::new(0)));let w=Waker::from(notify.clone());assert!(b.poll_final(&mut h,&mut Context::from_waker(&w)).is_pending());assert_eq!(notify.0.load(Ordering::SeqCst),1);
 assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::FixtureApplied))));let f=sql(&mut b);assert_eq!((f.submissions,f.receipts,f.lookups,f.queues.len()),(1,1,2,1));let output=b.consume_once(&mut h).unwrap_or_else(|_|panic!());assert_eq!(output.ciphertext,wire.serialize());assert!(matches!(b.consume_once(&mut h),Err(PortError::Consumed)));
}
#[test]fn all_native_lease_fields_revoke_and_foreign_handle_deny_output(){
 for field in 0..11{let(mut b,mut s,a,local,wire)=setup();prepare(&mut s,&a,&local,&wire);sql(&mut b).unknown_after_apply=true;let mut h=b.retain_prepared(s).unwrap_or_else(|_|panic!());assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));
 let f=sql(&mut b);match field{0=>f.binding.store+=1,1=>f.binding.session+=1,2=>f.binding.incarnation+=1,3=>f.binding.generation+=1,4=>f.binding.operation+=1,5=>f.binding.context+=1,6=>f.binding.route+=1,7=>f.binding.device_authorization+=1,8=>f.binding.revocation_checkpoint+=1,9=>f.binding.source_abi[0]^=1,_=>f.revoked=true}
 assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));assert!(b.consume_once(&mut h).is_err());assert_eq!(sql(&mut b).submissions,1);
 }
 let(mut b,mut s,a,local,wire)=setup();prepare(&mut s,&a,&local,&wire);let mut h=b.retain_prepared(s).unwrap_or_else(|_|panic!());h.actor+=1;assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Err(PortError::Binding))));assert_eq!(sql(&mut b).submissions,0);
}
#[test]fn ec_save_kyber_save_and_outbox_share_original_ordered_transaction(){
 let(mut b,mut s,a,local,wire)=setup();let ec=*sql(&mut b).store.all_pre_key_ids().next().unwrap();let kyber=*sql(&mut b).store.all_kyber_pre_key_ids().next().unwrap();
 let er=s.stage.ec.get_pre_key(ec).now_or_never().unwrap().unwrap();s.stage.ec.save_pre_key(ec,&er).now_or_never().unwrap().unwrap();let kr=s.stage.kyber.get_kyber_pre_key(kyber).now_or_never().unwrap().unwrap();s.stage.kyber.save_kyber_pre_key(kyber,&kr).now_or_never().unwrap().unwrap();prepare(&mut s,&a,&local,&wire);assert_eq!(s.stage.gate.0.borrow().journal.len(),6);s.queue=QueueKind::Outbound;
 let mut h=b.retain_prepared(s).unwrap_or_else(|_|panic!());assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::FixtureApplied))));assert_eq!(sql(&mut b).submissions,1);assert_eq!(sql(&mut b).queues[0],wire.serialize());
 let mut required=NativeStoreBridge{actor:99,issuer:Rc::new(()),next:0,backend:NativeBackend::Unavailable,pending:RetentionLedger::new(),retained_bytes:0,tombstones:VecDeque::new(),custody:Rc::new(RefCell::new(ActorCustody::new()))};assert!(matches!(required.acquire_snapshot(),Err(PortError::RequiredNativeSnapshotLease)));assert!(NativeStoreBridge::open_platform().is_err());assert!(crate::open_production().is_err());
}
#[test]fn scope_only_unknown_before_submission_and_before_consume_no_output(){
 for after_applied in [false,true]{let(mut b,mut s,a,local,wire)=setup();prepare(&mut s,&a,&local,&wire);let scope=s.stage.gate.1.clone();let mut h=b.retain_prepared(s).unwrap_or_else(|_|panic!());if after_applied{assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::FixtureApplied))));}scope.fixture_unknown();scope.fixture_rebind(4);scope.fixture_revoke();assert!(matches!(b.consume_once(&mut h),Err(PortError::Unknown)|Err(PortError::Rejected)));if !after_applied{assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));assert_eq!(sql(&mut b).submissions,0);assert_eq!(sql(&mut b).receipts,0);assert!(sql(&mut b).queues.is_empty());}assert_eq!(b.pending.get(&h.slot).unwrap().snapshot.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(wire.serialize()));}
}
fn fixture_snapshot(f:&FixtureSql,input:Option<&[u8]>,queue:QueueKind)->NativeSnapshotHandle{
 let b=f.binding;let binding=[b.store as u64,b.session as u64,b.incarnation,b.generation,b.operation,b.context,b.route,b.device_authorization,b.revocation_checkpoint,0,match queue{QueueKind::Inbound=>2,QueueKind::Outbound=>1}];
 let gate=Gate(Rc::new(RefCell::new(Pending{phase:Phase::Working,binding,bytes:0,journal:Vec::new(),original_ciphertext:input.map(|w|w.to_vec()),generated_wire:false,selected_wire_kind:None,plaintext:None,trigger:None,pending:false})),Rc::new(spqr::ynx_operation::CallScope::fixture(binding)));
 NativeSnapshotHandle{stage:StagedOperation{identity:Identity{snapshot:Box::new(f.store.identity_store.clone()),gate:gate.clone()},ec:EC{snapshot:Box::new(f.store.pre_key_store.clone()),gate:gate.clone()},kyber:Kyber{snapshot:Box::new(f.store.kyber_pre_key_store.clone()),gate:gate.clone()},sessions:Sessions{snapshot:Box::new(f.store.session_store.clone()),gate:gate.clone()},gate},signed:Box::new(f.store.signed_pre_key_store.clone()),lease:NativeLease{binding:b,authority:Authority::Fixture},queue,computation:None,budget:Some(SnapshotReservation{snapshot_bytes:MAX_SNAPSHOT_BYTES,source:ReservationSource::Fixture})}
}
fn fill_unknown_registry(b:&mut NativeStoreBridge)->Vec<(NativePendingHandle,Vec<u8>)>{
 let mut retained=Vec::new();for _ in 0..32{let(_other,mut s,a,local,w)=setup();prepare(&mut s,&a,&local,&w);let h=b.retain_prepared(s).unwrap_or_else(|_|panic!("fixture registry reserve"));b.pending.get(&h.slot).unwrap().snapshot.stage.gate.1.fixture_unknown();retained.push((h,w.serialize().to_vec()));}retained
}
#[test]fn sole_owner_transfer_failure_returns_complete_recovery_for_five_paths(){
 for failure in 0..5{let(mut b,mut s,a,local,w)=setup();prepare(&mut s,&a,&local,&w);let journal_len=s.stage.gate.0.borrow().journal.len();
 let filled=match failure{0=>{s.stage.gate.1.fixture_unknown();None},1=>Some(fill_unknown_registry(&mut b)),2=>{b.backend=NativeBackend::Unavailable;None},3=>{sql(&mut b).binding.source_abi[0]^=1;None},_=>{b.next=u64::MAX;None}};
 // No extra Rc or snapshot clone: this by-value transfer has exactly one owner.
 let fail=match b.retain_prepared(s){Err(f)=>f,Ok(_)=>panic!("must return ownership")};
 assert!(matches!((&fail.error,failure),(PortError::Unknown,0)|(PortError::Capacity,1)|(PortError::RequiredNativeSourceAuthentication,2)|(PortError::Binding,3)|(PortError::Capacity,4)));
 let mut recovered=fail.snapshot;assert_eq!(recovered.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert_eq!(recovered.stage.gate.0.borrow().journal.len(),journal_len);assert!(recovered.computation.is_some());
 let mut rng=OsRng.unwrap_err();assert!(recovered.execute_send(&a,&local,b"must not regenerate",SystemTime::now(),&mut rng).now_or_never().unwrap().is_err());assert_eq!(recovered.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert_eq!(recovered.stage.gate.0.borrow().journal.len(),journal_len);
 if let Some(owners)=filled{assert_eq!(b.pending.len(),32);for(h,wire)in owners{assert_eq!(b.pending.get(&h.slot).unwrap().snapshot.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(wire.as_slice()));}}
 }
}
#[test]fn outer_unknown_dominates_cancel_rebind_revoke_and_already_rejected(){
 for rejected_first in [false,true]{let(mut b,mut s,a,local,w)=setup();prepare(&mut s,&a,&local,&w);let mut h=b.retain_prepared(s).unwrap_or_else(|_|panic!());if rejected_first{sql(&mut b).fail_at=Some(0);assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Err(PortError::Rejected))));assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Rejected))));}
 b.pending.get(&h.slot).unwrap().snapshot.stage.gate.1.fixture_unknown();b.pending.get(&h.slot).unwrap().snapshot.stage.gate.1.fixture_rebind(4);b.pending.get(&h.slot).unwrap().snapshot.stage.gate.1.fixture_revoke();assert!(matches!(b.cancel(&mut h),Err(PortError::Unknown)));assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));assert!(matches!(b.consume_once(&mut h),Err(PortError::Unknown)));assert!(matches!(b.retire(&mut h,RetireAcknowledgement::DefiniteRejection),Err(PortError::Unknown)));assert_eq!(b.pending.get(&h.slot).unwrap().snapshot.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert!(sql(&mut b).queues.is_empty());
 }
}
fn transition(s:&NativeSnapshotHandle,kind:usize){match kind{0=>s.stage.gate.1.cancel(),1=>s.stage.gate.1.fixture_revoke(),2=>s.stage.gate.1.fixture_rebind(4),_=>s.stage.gate.1.fixture_unknown()}}
#[test]fn local_completed_identity_control_and_scope_only_final_fences(){
 if let Ok(mode)=std::env::var("YNX_PLATFORM_FINAL_FENCE_CASE"){
 let(schedule,kind)=mode.split_once('-').expect("selected matrix coordinates");let schedule:usize=schedule.parse().unwrap();let kind:usize=kind.parse().unwrap();assert!(schedule<4&&kind<4);
 let(mut b,mut s,a,local,w)=setup();prepare(&mut s,&a,&local,&w);assert!(!s.stage.gate.1.is_live(),"guard legitimately completed");assert!(validate_computation(&s).is_ok());let mut h=b.retain_prepared(s).unwrap_or_else(|_|panic!());
 if schedule==1{sql(&mut b).before_commit_transition=Some(kind as u8);}else if schedule>=2{if schedule==3{sql(&mut b).unknown_after_apply=true;sql(&mut b).lookup_pending=true;}let _=poll(&mut b,&mut h);if schedule==3{assert!(poll(&mut b,&mut h).is_pending());}transition(&b.pending.get(&h.slot).unwrap().snapshot,kind);}else{transition(&b.pending.get(&h.slot).unwrap().snapshot,kind);}
 if schedule<=1{let r=poll(&mut b,&mut h);assert!(match kind{0=>matches!(r,Poll::Ready(Err(PortError::Cancelled))),1=>matches!(r,Poll::Ready(Err(PortError::Revoked))),2=>matches!(r,Poll::Ready(Err(PortError::Binding))),_=>matches!(r,Poll::Ready(Ok(FinalStatus::Unknown)))});assert_eq!(sql(&mut b).submissions,0);assert!(sql(&mut b).queues.is_empty());}else{let _=poll(&mut b,&mut h);}
 assert!(b.consume_once(&mut h).is_err());assert!(b.retire(&mut h,RetireAcknowledgement::ConsumedOutput).is_err());assert_eq!(b.pending.get(&h.slot).unwrap().snapshot.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));
 use std::io::Write;
 println!("FINAL-FENCE-ASSERTIONS-COMPLETE-{mode}");std::io::stdout().flush().unwrap();
 // Keep the original fail-stop destructor. Unresolved custody must abort,
 // but only after every original matrix assertion has actually completed.
 drop(b);return
 }
 use std::{process::Command,os::unix::process::ExitStatusExt};
 let exact=format!("{}::local_completed_identity_control_and_scope_only_final_fences",module_path!().split_once("::").unwrap().1);
 for schedule in 0..4{for kind in 0..4{
  let mode=format!("{schedule}-{kind}");
  let result=Command::new(std::env::current_exe().unwrap()).args(["--exact",&exact,"--nocapture"]).env("YNX_PLATFORM_FINAL_FENCE_CASE",&mode).output().unwrap();
  assert!(String::from_utf8_lossy(&result.stdout).contains(&format!("FINAL-FENCE-ASSERTIONS-COMPLETE-{mode}")),"matrix case {mode} did not finish assertions: {}",String::from_utf8_lossy(&result.stderr));
  if kind==3||schedule>=2{assert_eq!(result.status.signal(),Some(6),"unresolved custody did not fail-stop: {mode}");}
  else{assert!(result.status.success(),"pre-effect rejection failed: {mode}: {}",String::from_utf8_lossy(&result.stderr));}
 }}
}
fn bridge_for(store:InMemSignalProtocolStore,id:u64)->NativeStoreBridge{let mut bind=binding();bind.store=id as u128;bind.session=id as u128;NativeStoreBridge{actor:id,issuer:Rc::new(()),next:0,backend:NativeBackend::Fixture(FixtureSql{binding:bind,store,revoked:false,fail_at:None,unknown_after_apply:false,lookup_pending:false,before_commit_transition:None,receipts:0,submissions:0,lookups:0,queues:Vec::new(),receipt:None}),pending:RetentionLedger::new(),retained_bytes:0,tombstones:VecDeque::new(),custody:Rc::new(RefCell::new(ActorCustody::new()))}}
#[test]fn eighty_actual_sequential_send_receive_retire_releases_slots_and_tombstones(){
 let mut a=upstream::test_in_memory_protocol_store().unwrap();let mut peer=upstream::test_in_memory_protocol_store().unwrap();let mut rng=OsRng.unwrap_err();let bundle=upstream::create_pre_key_bundle(&mut peer,&mut rng).now_or_never().unwrap().unwrap();let alice=ProtocolAddress::new("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa".into(),DeviceId::new(1).unwrap());let bob=ProtocolAddress::new("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb".into(),bundle.device_id().unwrap());process_prekey_bundle(&bob,&alice,&mut a.session_store,&mut a.identity_store,&bundle,SystemTime::now(),&mut rng).now_or_never().unwrap().unwrap();let mut sender=bridge_for(a,101);let mut receiver=bridge_for(peer,102);let mut stale=None;
 for _ in 0..80{let mut outgoing=fixture_snapshot(sql(&mut sender),None,QueueKind::Outbound);outgoing.execute_send(&bob,&alice,b"actual owned sequential",SystemTime::now(),&mut rng).now_or_never().unwrap().unwrap_or_else(|_|panic!("selected retention entry"));assert!(outgoing.stage.gate.0.borrow().generated_wire);let mut sh=sender.retain_prepared(outgoing).unwrap_or_else(|_|panic!());assert!(matches!(poll(&mut sender,&mut sh),Poll::Ready(Ok(FinalStatus::FixtureApplied))));let out=sender.consume_once(&mut sh).unwrap_or_else(|_|panic!());sender.retire(&mut sh,RetireAcknowledgement::ConsumedOutput).unwrap_or_else(|_|panic!());assert!(matches!(poll(&mut sender,&mut sh),Poll::Ready(Err(PortError::Retired))));if stale.is_none(){stale=Some(sh);}sql(&mut sender).binding.operation+=1;
 let wire=CiphertextMessage::PreKeySignalMessage(PreKeySignalMessage::try_from(out.ciphertext.as_slice()).unwrap());let mut incoming=fixture_snapshot(sql(&mut receiver),Some(wire.serialize()),QueueKind::Inbound);prepare(&mut incoming,&alice,&bob,&wire);let mut rh=receiver.retain_prepared(incoming).unwrap_or_else(|_|panic!());assert!(matches!(poll(&mut receiver,&mut rh),Poll::Ready(Ok(FinalStatus::FixtureApplied))));assert_eq!(receiver.consume_once(&mut rh).unwrap_or_else(|_|panic!()).plaintext.unwrap(),b"actual owned sequential");receiver.retire(&mut rh,RetireAcknowledgement::ConsumedOutput).unwrap_or_else(|_|panic!());sql(&mut receiver).binding.operation+=1;assert!(sender.pending.is_empty()&&receiver.pending.is_empty());assert_eq!(sender.retained_bytes+receiver.retained_bytes,0);
 }
 assert_eq!(sender.tombstones.len(),64);assert!(matches!(sender.consume_once(stale.as_mut().unwrap()),Err(PortError::Retired)));assert!(crate::open_production().is_err());
}
#[test]fn thirty_two_unknown_are_not_evicted_and_unconsumed_output_not_retired(){
 let(mut b,_s,_a,_local,_w)=setup();let mut owners=fill_unknown_registry(&mut b);assert_eq!(b.pending.len(),32);assert_eq!(b.retained_bytes,32*(MAX_SNAPSHOT_BYTES+PENDING_RESERVED_BYTES));for(h,wire)in &mut owners{assert!(matches!(poll(&mut b,h),Poll::Ready(Ok(FinalStatus::Unknown))));assert!(matches!(b.retire(h,RetireAcknowledgement::DefiniteRejection),Err(PortError::Unknown)));assert_eq!(b.pending.get(&h.slot).unwrap().snapshot.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(wire.as_slice()));}
 let(mut fresh,mut s,a,local,w)=setup();prepare(&mut s,&a,&local,&w);let mut h=fresh.retain_prepared(s).unwrap_or_else(|_|panic!());let _=poll(&mut fresh,&mut h);assert!(matches!(fresh.retire(&mut h,RetireAcknowledgement::ConsumedOutput),Err(PortError::Rejected)));assert_eq!(fresh.pending.len(),1);let _=fresh.consume_once(&mut h).unwrap_or_else(|_|panic!());fresh.retire(&mut h,RetireAcknowledgement::ConsumedOutput).unwrap_or_else(|_|panic!());assert_eq!(fresh.retained_bytes,0);
}
#[test]fn missing_or_oversize_full_snapshot_reservation_returns_owner(){
 for absent in [false,true]{let(mut b,mut s,a,local,w)=setup();prepare(&mut s,&a,&local,&w);if absent{s.budget=None;}else{s.budget.as_mut().unwrap().snapshot_bytes=MAX_SNAPSHOT_BYTES+1;}let failure=match b.retain_prepared(s){Err(f)=>f,Ok(_)=>panic!()};assert_eq!(failure.snapshot.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert!(b.pending.is_empty());assert_eq!(b.retained_bytes,0);}
}
struct InboundCallbackProbe{inner:Box<dyn IdentityKeyStore>,gate:Gate,expected:Vec<u8>,terminal:usize,seen:Rc<std::cell::Cell<usize>>}
impl InboundCallbackProbe{fn observe(&self){assert_eq!(self.gate.0.borrow().original_ciphertext.as_deref(),Some(self.expected.as_slice()));self.seen.set(self.seen.get()+1);match self.terminal{0=>self.gate.1.cancel(),1=>self.gate.1.fixture_revoke(),2=>self.gate.1.fixture_rebind(4),_=>self.gate.1.fixture_unknown()}}}
#[async_trait(?Send)]impl IdentityKeyStore for InboundCallbackProbe{
 async fn get_identity_key_pair(&self)->R<IdentityKeyPair>{self.observe();self.inner.get_identity_key_pair().await}
 async fn get_local_registration_id(&self)->R<u32>{self.observe();self.inner.get_local_registration_id().await}
 async fn get_identity(&self,a:&ProtocolAddress)->R<Option<IdentityKey>>{self.observe();self.inner.get_identity(a).await}
 async fn is_trusted_identity(&self,a:&ProtocolAddress,k:&IdentityKey,d:Direction)->R<bool>{self.observe();self.inner.is_trusted_identity(a,k,d).await}
 async fn save_identity(&mut self,a:&ProtocolAddress,k:&IdentityKey)->R<IdentityChange>{self.observe();self.inner.save_identity(a,k).await}
}
#[test]fn cohort_actual_inbound_entry_retains_before_terminal_callback(){
 for terminal in 0..4{let(_b,mut s,a,local,w)=setup();s.stage.gate.0.borrow_mut().original_ciphertext=None;let seen=Rc::new(std::cell::Cell::new(0));let inner=std::mem::replace(&mut s.stage.identity.snapshot,Box::new(InMemIdentityKeyStore::new(IdentityKeyPair::generate(&mut OsRng.unwrap_err()),1)));s.stage.identity.snapshot=Box::new(InboundCallbackProbe{inner,gate:s.stage.gate.clone(),expected:w.serialize().to_vec(),terminal,seen:seen.clone()});let mut rng=OsRng.unwrap_err();assert!(s.execute_receive(&a,&local,&w,&mut rng).now_or_never().unwrap().is_err());assert!(seen.get()>0);assert_eq!(s.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert!(s.stage.gate.0.borrow().journal.is_empty());if terminal==3{assert_eq!(s.stage.gate.0.borrow().phase as u8,Phase::Unknown as u8);}}
}

#[test]fn r13_actual_selected_pending_unknown_rebind_both_orders_no_recomputation(){
 use std::future::Future;
 for sending in [false,true]{for unknown_first in [false,true]{for terminal in 0..3{
  let(mut bridge,mut snapshot,alice,bob,wire)=setup();
  if sending{
   let mut a=upstream::test_in_memory_protocol_store().unwrap();let mut peer=upstream::test_in_memory_protocol_store().unwrap();let mut rng=OsRng.unwrap_err();let bundle=upstream::create_pre_key_bundle(&mut peer,&mut rng).now_or_never().unwrap().unwrap();
   process_prekey_bundle(&bob,&alice,&mut a.session_store,&mut a.identity_store,&bundle,SystemTime::now(),&mut rng).now_or_never().unwrap().unwrap();bridge=bridge_for(a,101);snapshot=fixture_snapshot(sql(&mut bridge),None,QueueKind::Outbound);
  }
  let gate=snapshot.stage.gate.clone();gate.0.borrow_mut().pending=true;let mut rng=OsRng.unwrap_err();
  let mut future=Box::pin(async{if sending{snapshot.execute_send(&bob,&alice,b"sticky unknown",SystemTime::now(),&mut rng).await}else{snapshot.execute_receive(&alice,&bob,&wire,&mut rng).await}});
  let mut cx=Context::from_waker(Waker::noop());assert!(future.as_mut().poll(&mut cx).is_pending());
  let original=gate.0.borrow().original_ciphertext.clone().expect("wire retained before mutating await");let count=gate.0.borrow().journal.len();let bytes=gate.0.borrow().bytes;assert!(count>0);
  let mut changed=gate.0.borrow().binding;changed[4]+=1;
  if unknown_first{gate.1.fixture_unknown();gate.1.fixture_rebind(4);}else{gate.1.fixture_rebind(4);gate.1.fixture_unknown();}
  match terminal{1=>gate.1.cancel(),2=>gate.1.fixture_revoke(),_=>{}}
  assert!(matches!(future.as_mut().poll(&mut cx),Poll::Ready(Err(PortError::Unknown))));drop(future);
  assert!(snapshot.computation.is_none());assert!(gate.0.borrow().phase==Phase::Unknown);assert!(gate.0.borrow().plaintext.is_none());
  let retry=if sending{snapshot.execute_send(&bob,&alice,b"sticky unknown",SystemTime::now(),&mut rng).now_or_never()}else{snapshot.execute_receive(&alice,&bob,&wire,&mut rng).now_or_never()};assert!(matches!(retry,Some(Err(PortError::Unknown))));
  assert_eq!(gate.0.borrow().original_ciphertext.as_deref(),Some(original.as_slice()));assert_eq!(gate.0.borrow().journal.len(),count);assert_eq!(gate.0.borrow().bytes,bytes);let f=sql(&mut bridge);assert_eq!((f.submissions,f.receipts,f.queues.len()),(0,0,0));
 }}}
}
#[test]fn r13_actual_pending_binding_only_control_remains_binding(){
 use std::future::Future;
 let(mut bridge,mut snapshot,alice,bob,wire)=setup();let gate=snapshot.stage.gate.clone();gate.0.borrow_mut().pending=true;let mut rng=OsRng.unwrap_err();let mut future=Box::pin(snapshot.execute_receive(&alice,&bob,&wire,&mut rng));let mut cx=Context::from_waker(Waker::noop());assert!(future.as_mut().poll(&mut cx).is_pending());let mut changed=gate.0.borrow().binding;changed[4]+=1;gate.1.fixture_rebind(4);assert!(matches!(future.as_mut().poll(&mut cx),Poll::Ready(Err(PortError::Binding))));drop(future);assert!(gate.0.borrow().phase==Phase::Rejected);assert_eq!(sql(&mut bridge).submissions,0);
}
