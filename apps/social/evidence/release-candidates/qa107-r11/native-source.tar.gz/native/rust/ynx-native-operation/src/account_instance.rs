//! R2 independent service-instance verification. NEVER an effect/signing grant.
//! Bootstrap is a release-owned input, not a response/Java/ENV root factory.
#![allow(unsafe_code)]
use base64::{Engine as _,engine::general_purpose::{URL_SAFE_NO_PAD as B64,STANDARD}};
use serde_json::{Value,Map};
use sha2::{Digest,Sha256};
use zeroize::Zeroizing;
use std::{cell::RefCell,rc::Rc};
use crate::account_https::{self,Action,Window};
const MAX:u64=(1<<53)-1;
const CLIENT:&str="ynx-social-v1-m1qa-sso-v1";
const ORIGIN:&str="https://social.ynxweb4.com";
const RD:&[u8]=b"YNX_SOCIAL_NATIVE_ACCOUNT_INSTANCE_REGISTRATION_V1\n";
const SD:&[u8]=b"YNX_SOCIAL_NATIVE_ACCOUNT_DELEGATION_STATUS_V1\n";
const CD:&[u8]=b"YNX_SOCIAL_NATIVE_ACCOUNT_CURRENT_V1\n";
const RF:&[&str]=&["version","purpose","environment","registrationId","registrationRevision","rootId","rootKeyId","instanceId","instanceKeyId","instancePublicKey","serviceOrigin","apiMount","packageId","certificateDigest","callbackManifestDigest","clientId","profileRegistrationId","profileRevision","profileDigest","centralRegistryDigest","operationRegistrationDigest","serviceBinaryDigest","tlsSpkiDigest","actions","issuedAtMs","expiresAtMs"];
const SF:&[&str]=&["version","purpose","rootId","rootKeyId","instanceId","registrationId","registrationRevision","registrationDigest","statusSequence","status","previousStatusDigest","effectiveAtMs","issuedAtMs","expiresAtMs"];
const CF:&[&str]=&["version","purpose","instanceId","instanceKeyId","registrationDigest","sequence","action","phase","requestId","loginInstanceDigest","nativeRequestDigest","operation","challengeNonce","challengeRequestDigest","preparedRevision","issuerMessageDigest","targetMessageDigest","identity","device","accountIssuer","account","clientId","origin","sessionId","familyId","generation","associationCommitment","reservedAtMs","centralFrameDigest","delegationStatusDigest","historicalCarrierDigest","tlsExporterDigest","state","issuedAtMs","expiresAtMs"];
const FF:&[&str]=&["version","phase","issuer","account","clientId","origin","sessionId","familyId","generation","operation","challenge","preparedPublicCommitment","associationCommitment","reservedAtMs","observedAtMs","expiresAtMs","state","dispatchAllowed"];
#[derive(Clone,Copy,Debug,PartialEq,Eq)]pub(crate)enum Error{Required,Bounds,Canonical,Binding,Signature,Window,Unknown,Transport(account_https::Error)}
fn need(ok:bool)->Result<(),Error>{if ok{Ok(())}else{Err(Error::Binding)}}
pub(crate)fn hash(b:&[u8])->String{Sha256::digest(b).iter().map(|v|format!("{v:02x}")).collect()}
fn canonical(v:&Value)->Result<Vec<u8>,Error>{
 fn ordered(v:&Value)->Result<Value,Error>{Ok(match v{Value::Object(m)=>{let mut keys:Vec<_>=m.keys().collect();keys.sort();let mut out=Map::new();for k in keys{out.insert(k.clone(),ordered(&m[k])?);}Value::Object(out)},Value::Array(a)=>Value::Array(a.iter().map(ordered).collect::<Result<_,_>>()?),Value::Number(n)=>{if n.as_u64().filter(|n|*n<=MAX).is_none(){return Err(Error::Canonical)}v.clone()},_=>v.clone()})}
 serde_json::to_vec(&ordered(v)?).map_err(|_|Error::Canonical)
}
fn fields(v:&Value,keys:&[&str])->Result<(),Error>{let m=v.as_object().ok_or(Error::Canonical)?;need(m.len()==keys.len()&&keys.iter().all(|k|m.contains_key(*k)))}
fn parse(raw:&[u8],cap:usize,keys:&[&str])->Result<Value,Error>{
 if raw.is_empty()||raw.len()>cap{return Err(Error::Bounds)}
 let v:Value=serde_json::from_slice(raw).map_err(|_|Error::Canonical)?;fields(&v,keys)?;if canonical(&v)?!=raw{return Err(Error::Canonical)}Ok(v)
}
fn text<'a>(v:&'a Value,k:&str)->Result<&'a str,Error>{v[k].as_str().filter(|s|!s.is_empty()&&s.len()<=65536).ok_or(Error::Binding)}
fn num(v:&Value,k:&str)->Result<u64,Error>{v[k].as_u64().filter(|n|*n<=MAX).ok_or(Error::Binding)}
fn eq(v:&Value,k:&str,s:&str)->Result<(),Error>{need(text(v,k)?==s)}
fn id(s:&str)->bool{!s.is_empty()&&s.len()<=128&&s.bytes().all(|v|v.is_ascii_alphanumeric()||b"._:-".contains(&v))}
fn ascii(s:&str)->bool{!s.is_empty()&&s.len()<=512&&s.bytes().all(|v|(33..=126).contains(&v))}
fn hex(s:&str)->bool{s.len()==64&&s.bytes().all(|v|v.is_ascii_digit()||(b'a'..=b'f').contains(&v))}
// Exact original delegation-record grammar. This is NOT chain admission,
// currentness, durable history or permission to refresh an original Attempt.
fn delegation_status_shape(v:&Value)->Result<(),Error>{
 fields(v,SF)?;
 need(num(v,"version")?==1)?;
 eq(v,"purpose","social-native-account-delegation-status/v1")?;
 for k in ["rootId","rootKeyId","instanceId","registrationId"]{need(id(text(v,k)?))?;}
 need(num(v,"registrationRevision")?>0&&hex(text(v,"registrationDigest")?))?;
 let sequence=num(v,"statusSequence")?;
 need(sequence>0)?;
 need(matches!(text(v,"status")?,"active"|"withdrawing"|"revoked"))?;
 if sequence==1{need(v["previousStatusDigest"].is_null())?;}
 else{need(hex(text(v,"previousStatusDigest")?))?;}
 let issued=num(v,"issuedAtMs")?;let expires=num(v,"expiresAtMs")?;
 need(expires.checked_sub(issued).is_some_and(|n|n>0&&n<=30000))?;
 let effective=num(v,"effectiveAtMs")?;
 need(effective>=issued&&effective<expires)
}
fn b64(s:&str,n:usize)->Result<Vec<u8>,Error>{let b=B64.decode(s).map_err(|_|Error::Binding)?;need(b.len()==n&&B64.encode(&b)==s)?;Ok(b)}
fn window(v:&Value,cap:u64,now:u64)->Result<(u64,u64),Error>{let lo=num(v,"issuedAtMs")?;let hi=num(v,"expiresAtMs")?;need(hi.checked_sub(lo).is_some_and(|n|n>0&&n<=cap))?;if now<lo||now>=hi{return Err(Error::Window)}Ok((lo,hi))}
fn now()->Result<u64,Error>{u64::try_from(crate::source_evidence::now_ms().map_err(|_|Error::Window)?).map_err(|_|Error::Window)}
unsafe extern "C"{fn crypto_sign_verify_detached(s:*const u8,m:*const u8,n:u64,k:*const u8)->i32;}
fn verify(v:&Value,key:&[u8;32],domain:&[u8])->Result<(),Error>{let sig=b64(text(v,"signature")?,64)?;let mut msg=domain.to_vec();msg.extend(canonical(&v["body"])?);if unsafe{crypto_sign_verify_detached(sig.as_ptr(),msg.as_ptr(),msg.len()as u64,key.as_ptr())}!=0{return Err(Error::Signature)}Ok(())}
fn pem(s:&str)->Result<[u8;32],Error>{
 let s=s.strip_prefix("-----BEGIN PUBLIC KEY-----\n").and_then(|s|s.strip_suffix("-----END PUBLIC KEY-----\n").or_else(||s.strip_suffix("-----END PUBLIC KEY-----"))).ok_or(Error::Binding)?.replace('\n',"");
 let b=STANDARD.decode(&s).map_err(|_|Error::Binding)?;need(STANDARD.encode(&b)==s&&b.len()==44&&b[..12]==[0x30,0x2a,0x30,5,6,3,0x2b,0x65,0x70,3,0x21,0])?;b[12..].try_into().map_err(|_|Error::Binding)
}
// No constructor/export accepts this selection from an HTTP/JNI response.
// Genuine release-owned approved material is NOT provisioned in this candidate.
struct ApprovedBootstrap{root:&'static str,registration:&'static str,status:&'static str,status_history:&'static [&'static str],root_hash:&'static str,registration_hash:&'static str,status_hash:&'static str,pins:[&'static str;7],minimum_revision:u64,minimum_status:u64}
const APPROVED:&[ApprovedBootstrap]=&[];
const PIN_KEYS:[&str;7]=["profileDigest","centralRegistryDigest","operationRegistrationDigest","serviceBinaryDigest","tlsSpkiDigest","certificateDigest","callbackManifestDigest"];
// Receive PUBLIC signed history only through the independently approved source.
// A minimum sequence is not a cold checkpoint. Until the separately approved
// durable checkpoint receiver exists, an incomplete history fails closed.
fn status_successor(previous:&Value,previous_raw:&[u8],next:&Value)->Result<(),Error>{
 for k in ["rootId","rootKeyId","instanceId","registrationId","registrationRevision","registrationDigest"]{need(previous[k]==next[k])?;}
 need(num(previous,"statusSequence")?.checked_add(1)==Some(num(next,"statusSequence")?))?;
 eq(next,"previousStatusDigest",&hash(previous_raw))?;
 let old=text(previous,"status")?;let new=text(next,"status")?;
 need(match old{"active"=>true,"withdrawing"=>new!="active","revoked"=>new=="revoked",_=>false})
}
fn receive_status_history(s:&ApprovedBootstrap,registration:&Value,root_key:&[u8;32])->Result<Value,Error>{
 if s.status_history.len()>255{return Err(Error::Bounds)}
 let mut previous:Option<(Value,&[u8])>=None;
 for raw in s.status_history.iter().copied().chain(std::iter::once(s.status)){
  let record=parse(raw.as_bytes(),16384,&["body","signature"])?;let body=&record["body"];
  delegation_status_shape(body)?;
  for k in ["rootId","rootKeyId","instanceId","registrationId","registrationRevision"]{need(body[k]==registration[k])?;}
  eq(body,"registrationDigest",s.registration_hash)?;
  verify(&record,root_key,SD)?;
  if let Some((prior,prior_raw))=&previous{status_successor(&prior["body"],prior_raw,body)?;}
  else{need(num(body,"statusSequence")?==1)?;eq(body,"status","active")?;}
  previous=Some((record,raw.as_bytes()));
 }
 previous.map(|(record,_)|record).ok_or(Error::Required)
}
pub(crate)struct Bootstrap{registration:Value,status:Value,status_raw:Zeroizing<Vec<u8>>,root_raw:Zeroizing<Vec<u8>>,registration_raw:Zeroizing<Vec<u8>>,status_history_raw:Vec<Zeroizing<Vec<u8>>>,registration_hash:String,key:[u8;32],lower:u64,upper:u64,last:std::cell::Cell<u64>}
// Private synchronous startup borrow only. It has no request, AccountAttempt,
// Source key or signing permission and must not escape its selected Bootstrap.
pub(crate)struct FixedBootstrapRaw<'a>{
 pub(crate)root:&'a[u8],pub(crate)registration:&'a[u8],pub(crate)status:&'a[u8],
 pub(crate)status_history:&'a[Zeroizing<Vec<u8>>],
}
impl Bootstrap{
 pub(crate)fn selected()->Result<Self,Error>{if APPROVED.len()!=1{return Err(Error::Required)}Self::load(&APPROVED[0])}
 pub(crate)fn with_startup_originals<R>(&self,run:impl for<'a>FnOnce(FixedBootstrapRaw<'a>)->R)->Result<R,(Error,Option<R>)>{
  self.current().map_err(|e|(e,None))?;
  let result=run(FixedBootstrapRaw{root:&self.root_raw,registration:&self.registration_raw,status:&self.status_raw,status_history:&self.status_history_raw});
  // A late fence refusal must retain any partial output produced by the
  // caller, rather than silently dropping a sole owning result.
  match self.current(){Ok(())=>Ok(result),Err(e)=>Err((e,Some(result)))}
 }
 pub(crate)fn match_startup_originals(&self,root:&[u8],registration:&[u8],status:&[u8],history:&[Zeroizing<Vec<u8>>])->Result<(),Error>{
  let matched=self.with_startup_originals(|selected|{
   root==selected.root&&registration==selected.registration&&status==selected.status&&
   history.len()==selected.status_history.len()&&history.iter().zip(selected.status_history).all(|(raw,original)|raw.as_slice()==original.as_slice())
  }).map_err(|(e,_)|e)?;
  if !matched{return Err(Error::Binding)}Ok(())
 }
 fn load(s:&ApprovedBootstrap)->Result<Self,Error>{
  need([s.root_hash,s.registration_hash,s.status_hash].iter().all(|v|hex(v))&&s.pins.iter().all(|v|hex(v)))?;
  need(hash(s.root.as_bytes())==s.root_hash&&hash(s.registration.as_bytes())==s.registration_hash&&hash(s.status.as_bytes())==s.status_hash)?;
  let root=parse(s.root.as_bytes(),16384,&["version","rootId","keyId","publicKey","purposes"])?;
  need(num(&root,"version")?==1&&id(text(&root,"rootId")?)&&id(text(&root,"keyId")?))?;
  need(root["purposes"]==serde_json::json!(["social-native-account-instance-registration/v1","social-native-account-delegation-status/v1"]))?;
  let key=pem(text(&root,"publicKey")?)?;
  let r=parse(s.registration.as_bytes(),16384,&["body","signature"])?;fields(&r["body"],RF)?;
  let b=&r["body"];need(num(b,"version")?==1)?;eq(b,"purpose","social-native-account-instance-registration/v1")?;eq(b,"environment","testnet-qa")?;
  for k in ["registrationId","rootId","rootKeyId","instanceId","instanceKeyId","profileRegistrationId"]{need(id(text(b,k)?))?;}
  need(num(b,"registrationRevision")?>=s.minimum_revision&&s.minimum_revision>0&&num(b,"profileRevision")?>0)?;
  for(k,pin)in PIN_KEYS.iter().zip(s.pins){eq(b,k,pin)?;}
  eq(b,"serviceOrigin",ORIGIN)?;eq(b,"apiMount","/m1qa")?;eq(b,"packageId","com.ynx.social.m1qa")?;eq(b,"clientId",CLIENT)?;
  need(b["actions"]==serde_json::json!(["capture","join","observe","retire"]))?;
  eq(b,"rootId",text(&root,"rootId")?)?;eq(b,"rootKeyId",text(&root,"keyId")?)?;
  verify(&r,&key,RD)?;let at=now()?;let(rl,ru)=window(b,86400000,at)?;
  let status=receive_status_history(s,b,&key)?;let st=&status["body"];
  need(num(st,"version")?==1)?;eq(st,"purpose","social-native-account-delegation-status/v1")?;
  for k in ["rootId","rootKeyId","instanceId","registrationId"]{eq(st,k,text(b,k)?)?;}
  need(num(st,"registrationRevision")?==num(b,"registrationRevision")?&&num(st,"statusSequence")?>=s.minimum_status&&s.minimum_status>0)?;
  eq(st,"registrationDigest",s.registration_hash)?;eq(st,"status","active")?;
  verify(&status,&key,SD)?;let(sl,su)=window(st,30000,at)?;let effective=num(st,"effectiveAtMs")?;need(effective>=sl&&effective<su&&at>=effective)?;
  let instancekey=b64(text(b,"instancePublicKey")?,32)?.try_into().map_err(|_|Error::Binding)?;
  let out=Self{registration:r,status,status_raw:Zeroizing::new(s.status.as_bytes().to_vec()),root_raw:Zeroizing::new(s.root.as_bytes().to_vec()),registration_raw:Zeroizing::new(s.registration.as_bytes().to_vec()),status_history_raw:s.status_history.iter().map(|raw|Zeroizing::new(raw.as_bytes().to_vec())).collect(),registration_hash:s.registration_hash.into(),key:instancekey,lower:rl.max(effective),upper:ru.min(su),last:std::cell::Cell::new(at)};out.current()?;Ok(out)
 }
 pub(crate)fn current(&self)->Result<(),Error>{let at=now()?;if at<self.last.get()||at<self.lower||at>=self.upper{return Err(Error::Window)}self.last.set(at);Ok(())}
 pub(crate)fn peer(&self,certificate:&[u8])->Result<(),Error>{self.current()?;eq(&self.registration["body"],"tlsSpkiDigest",&hash(spki(certificate)?))?;self.current()}
}
// Bounded DER navigation only; certificate validation remains selected rustls.
fn tlv<'a>(bytes:&mut &'a[u8],tag:u8)->Result<(&'a[u8],&'a[u8]),Error>{
 let all=*bytes;if all.len()<2||all[0]!=tag{return Err(Error::Binding)}let first=all[1];let(n,h)=if first<128{(first as usize,2)}else{let count=(first&127)as usize;if count==0||count>4||all.len()<2+count||all[2]==0{return Err(Error::Binding)}let mut n=0usize;for v in &all[2..2+count]{n=n.checked_mul(256).and_then(|n|n.checked_add(*v as usize)).ok_or(Error::Bounds)?;}if n<128{return Err(Error::Binding)}(n,2+count)};let end=h.checked_add(n).ok_or(Error::Bounds)?;if end>all.len(){return Err(Error::Bounds)}*bytes=&all[end..];Ok((&all[..end],&all[h..end]))
}
fn spki(der:&[u8])->Result<&[u8],Error>{if der.len()>65536{return Err(Error::Bounds)}let mut input=der;let(_,mut cert)=tlv(&mut input,0x30)?;need(input.is_empty())?;let(_,mut tbs)=tlv(&mut cert,0x30)?;if tbs.first()==Some(&0xa0){tlv(&mut tbs,0xa0)?;}for tag in [2,0x30,0x30,0x30,0x30]{tlv(&mut tbs,tag)?;}Ok(tlv(&mut tbs,0x30)?.0)}
// Expected request is produced only by original RecoveryLoan/Type4/borrow
// matching. It contains no account identity inferred from the remote response.
pub(crate)struct Request{pub(crate) expected:Value,pub(crate) nonce:[u8;32],pub(crate) body:Zeroizing<Vec<u8>>,pub(crate) cookie:Zeroizing<Vec<u8>>,pub(crate) issued:u64,pub(crate) expires:u64}
pub(crate)fn login_digest(cookie:&[u8])->Result<String,Error>{
 let s=std::str::from_utf8(cookie).map_err(|_|Error::Binding)?;let mut pairs=s.split("; ");
 let id=pairs.next().and_then(|v|v.strip_prefix("__Host-ynx-social-m1qa-login-id=")).ok_or(Error::Binding)?;
 let binding=pairs.next().and_then(|v|v.strip_prefix("__Host-ynx-social-m1qa-login-binding=")).ok_or(Error::Binding)?;
 need(pairs.next().is_none())?;for v in [id,binding]{need(v.len()==43)?;b64(v,32)?;}
 let descriptor=serde_json::json!({"version":1,"clientId":CLIENT,"origin":ORIGIN,"apiMount":"/m1qa","intent":"A","transactionId":id,"cookieBinding":binding});
 let mut raw=Zeroizing::new(b"YNX_SOCIAL_NATIVE_LOGIN_INSTANCE_V1\n".to_vec());raw.extend(canonical(&descriptor)?);Ok(hash(&raw))
}
fn current_frame(raw:&[u8],bootstrap:&Bootstrap,request:&Request,exporter:&str,action:Action,prior:Option<&Value>,original:&Window)->Result<VerifiedCurrentFrame,Error>{
 current_frame_origin(raw,bootstrap,request,exporter,FrameOrigin::Exchange(action,prior),original)
}
#[derive(Clone,Copy)]enum FrameOrigin<'a>{Exchange(Action,Option<&'a Value>),ServerJoined}
fn current_frame_origin(raw:&[u8],bootstrap:&Bootstrap,request:&Request,exporter:&str,origin:FrameOrigin<'_>,original:&Window)->Result<VerifiedCurrentFrame,Error>{
 let (action,prior)=match origin{FrameOrigin::Exchange(a,p)=>(a,p),FrameOrigin::ServerJoined=>(Action::Join,None)};
 bootstrap.current()?;let e=parse(raw,65536,&["body","signature","accountFrame","delegationStatus","historicalCarrier"])?;let b=&e["body"];fields(b,CF)?;
 need(num(b,"version")?==1&&num(b,"sequence")?>0)?;eq(b,"purpose","social-native-account-current/v1")?;
 for k in ["instanceId","instanceKeyId"]{eq(b,k,text(&bootstrap.registration["body"],k)?)?;}
 eq(b,"registrationDigest",&bootstrap.registration_hash)?;eq(b,"clientId",CLIENT)?;eq(b,"origin",ORIGIN)?;
 for k in ["requestId","loginInstanceDigest","nativeRequestDigest","operation","challengeNonce","challengeRequestDigest","preparedRevision","issuerMessageDigest","targetMessageDigest","identity","device"]{need(b[k]==request.expected[k])?;}
 eq(b,"tlsExporterDigest",exporter)?;need(hex(exporter))?;
 need(text(&e,"delegationStatus")?.as_bytes()==bootstrap.status_raw.as_slice())?;eq(b,"delegationStatusDigest",&hash(&bootstrap.status_raw))?;
 need(e["historicalCarrier"].is_null()&&b["historicalCarrierDigest"].is_null())?;
 let sampled_elapsed=original.start.elapsed();let sampled_at=now()?;let at=sampled_at;let(lo,hi)=window(b,30000,at)?;need(lo>=bootstrap.lower&&lo>=request.issued&&hi<=bootstrap.upper&&hi<=request.expires)?;
 let fraw=text(&e,"accountFrame")?;let f=parse(fraw.as_bytes(),16384,FF)?;eq(b,"centralFrameDigest",&hash(fraw.as_bytes()))?;
 eq(&f,"version","ynx-social-original-account-acquisition/v1")?;need(f["dispatchAllowed"]==Value::Bool(false))?;
 for (fk,bk) in [("issuer","accountIssuer"),("account","account"),("sessionId","sessionId"),("familyId","familyId")]{need(ascii(text(&f,fk)?))?;eq(b,bk,text(&f,fk)?)?;}
 for k in ["clientId","origin","operation","generation","associationCommitment","reservedAtMs"]{need(f[k]==b[k])?;}
 need(num(&f,"generation")?>0&&num(&f,"observedAtMs")?<=at&&num(&f,"expiresAtMs")?>num(&f,"observedAtMs")?&&hi<=num(&f,"expiresAtMs")?)?;
 let c=&f["challenge"];fields(c,&["operation","nonce","requestDigest","issuedAtMs","expiresAtMs"])?;
 eq(c,"operation",text(b,"operation")?)?;eq(c,"nonce",text(b,"challengeNonce")?)?;eq(c,"requestDigest",text(b,"challengeRequestDigest")?)?;
 need(num(c,"issuedAtMs")?==request.issued&&num(c,"expiresAtMs")?==request.expires)?;
 let p=&f["preparedPublicCommitment"];fields(p,&["version","operation","revision","identity","device","issuerMessage","targetMessage"])?;eq(p,"version","ynx-social-first-enrollment-prepared/v1")?;
 for (pk,bk) in [("operation","operation"),("revision","preparedRevision"),("identity","identity"),("device","device")]{need(p[pk]==b[bk])?;}
 for (pk,bk,role) in [("issuerMessage","issuerMessageDigest","ISSUER"),("targetMessage","targetMessageDigest","TARGET")]{let encoded=text(p,pk)?;let bytes=B64.decode(encoded).map_err(|_|Error::Binding)?;need(!bytes.is_empty()&&bytes.len()<=65536&&B64.encode(&bytes)==encoded)?;let mut v=format!("YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_{role}_V1\n").into_bytes();v.extend(bytes);eq(b,bk,&hash(&v))?;}
 match action{Action::Capture=>{eq(b,"action","capture")?;for v in [b,&f]{eq(v,"phase","captured")?;eq(v,"state","not-reserved")?;need(v["associationCommitment"].is_null()&&v["reservedAtMs"].is_null())?;}need(prior.is_none())?;},Action::Join=>{eq(b,"action","join")?;for v in [b,&f]{eq(v,"phase","joined")?;eq(v,"state","unknown-pending")?;need(hex(text(v,"associationCommitment")?)&&num(v,"reservedAtMs")?<=at)?;}if matches!(origin,FrameOrigin::Exchange(_, _)){let old=prior.ok_or(Error::Binding)?;for k in ["issuer","account","clientId","origin","sessionId","familyId","generation","operation","challenge","preparedPublicCommitment"]{need(f[k]==old[k])?;}}}}
 verify(&e,&bootstrap.key,CD)?;bootstrap.current()?;let at=now()?;if at<lo||at>=hi{return Err(Error::Window)}
 let budget=original.budget.min(sampled_elapsed.checked_add(std::time::Duration::from_millis(hi-sampled_at)).ok_or(Error::Window)?);
 let retained=RetainedCurrentWindow{lower:lo,upper:hi,started:original.start,budget};
 retained.check(at)?;Ok(VerifiedCurrentFrame{frame:f,envelope:Zeroizing::new(raw.to_vec()),window:retained})
}
// Verified signed-envelope lifetime, never reconstructed from inner frame.
struct RetainedCurrentWindow{lower:u64,upper:u64,started:std::time::Instant,budget:std::time::Duration}
impl RetainedCurrentWindow{
 fn check(&self,at:u64)->Result<(),Error>{if at<self.lower||at>=self.upper||self.started.elapsed()>=self.budget{Err(Error::Window)}else{Ok(())}}
}
struct VerifiedCurrentFrame{frame:Value,envelope:Zeroizing<Vec<u8>>,window:RetainedCurrentWindow}
struct NativeOriginal{frame:Value}
struct State{original:Option<NativeOriginal>,started:bool,complete:bool,first:Option<Error>,capture_frame:Option<VerifiedCurrentFrame>,join_frame:Option<VerifiedCurrentFrame>,capture:Option<account_https::UnadmittedResponse>,join:Option<account_https::UnadmittedResponse>}
pub(crate)struct Attempt{bootstrap:Bootstrap,request:Request,window:Window,connect_peer:account_https::ConnectPeer,state:RefCell<State>}
// Restricted exact input projection: no admitted owner, public getter or renewal.
pub(crate)struct OriginalBootstrapRaw<'a>{
 pub(crate)root:&'a[u8],pub(crate)registration:&'a[u8],pub(crate)status:&'a[u8],
 pub(crate)status_history:&'a[Zeroizing<Vec<u8>>],
 pub(crate)request:&'a[u8],pub(crate)nonce:&'a[u8;32],
}
impl Attempt{
 pub(crate)fn original_bootstrap_raw(&self)->Result<OriginalBootstrapRaw<'_>,Error>{
  self.recheck()?;let b=&self.bootstrap;
  let raw=OriginalBootstrapRaw{root:&b.root_raw,registration:&b.registration_raw,status:&b.status_raw,status_history:&b.status_history_raw,request:&self.request.body,nonce:&self.request.nonce};
  self.recheck()?;Ok(raw)
 }
 pub(crate)fn new(bootstrap:Bootstrap,request:Request,window:Window)->Rc<Self>{Rc::new(Self{bootstrap,request,window,connect_peer:account_https::take_prepare_peer(),state:RefCell::new(State{original:None,started:false,complete:false,first:None,capture_frame:None,join_frame:None,capture:None,join:None})})}
 fn fail(&self,e:Error)->Error{let mut s=self.state.borrow_mut();*s.first.get_or_insert(e)}
 pub(crate)fn recheck(&self)->Result<(),Error>{
  if let Some(e)=self.state.borrow().first{return Err(e)}
  let result=(||{self.bootstrap.current()?;self.window.remaining().map_err(|_|Error::Window)?;
   let s=self.state.borrow();if !s.complete||s.original.is_none(){return Err(Error::Unknown)}
   self.check_currents(&s,now()?)
  })();result.map_err(|e|self.fail(e))
 }
 fn check_currents(&self,s:&State,at:u64)->Result<(),Error>{
  s.capture_frame.as_ref().ok_or(Error::Unknown)?.window.check(at)?;
  s.join_frame.as_ref().ok_or(Error::Unknown)?.window.check(at)
 }
 fn before_join(&self,live:&mut dyn FnMut()->Result<(),account_https::Error>)->Result<(),Error>{
  live().map_err(Error::Transport)?;self.bootstrap.current()?;self.window.remaining().map_err(|_|Error::Window)?;
  self.state.borrow().capture_frame.as_ref().ok_or(Error::Unknown)?.window.check(now()?)
 }
 fn before_complete(&self,live:&mut dyn FnMut()->Result<(),account_https::Error>)->Result<(),Error>{
  live().map_err(Error::Transport)?;self.window.remaining().map_err(|_|Error::Window)?;self.bootstrap.current()?;
  self.check_currents(&self.state.borrow(),now()?)
 }
 pub(crate)fn run(&self,mut live:impl FnMut()->Result<(),account_https::Error>)->Result<(),Error>{
  self.run_io(&mut live,|a,c,b,w,boot,n,l|account_https::exchange_bound(a,c,b,w,boot,n,self.connect_peer,l))
 }
 fn run_io(&self,live:&mut dyn FnMut()->Result<(),account_https::Error>,mut exchange:impl FnMut(Action,&[u8],&[u8],&Window,&Bootstrap,&[u8;32],&mut dyn FnMut()->Result<(),account_https::Error>)->Result<account_https::UnadmittedResponse,account_https::Error>)->Result<(),Error>{
  {let mut s=self.state.borrow_mut();if s.started{return Err(s.first.unwrap_or(Error::Unknown))}s.started=true;}
  let result=(||{
   self.bootstrap.current()?;self.window.remaining().map_err(|_|Error::Window)?;
   let capture=exchange(Action::Capture,&self.request.cookie,&self.request.body,&self.window,&self.bootstrap,&self.request.nonce,live).map_err(Error::Transport)?;
   // Retain response BEFORE validation/next phase. Partial same-owner evidence
   // never disappears on signature, publication or second-IO failure.
   self.state.borrow_mut().capture=Some(capture);
   let first={let s=self.state.borrow();let c=s.capture.as_ref().ok_or(Error::Unknown)?;current_frame(&c.body,&self.bootstrap,&self.request,c.exporter.as_deref().ok_or(Error::Binding)?,Action::Capture,None,&self.window)?};
   let first_frame=first.frame.clone();
   self.state.borrow_mut().capture_frame=Some(first);
   self.before_join(live)?;
   let joined=exchange(Action::Join,&self.request.cookie,&self.request.body,&self.window,&self.bootstrap,&self.request.nonce,live).map_err(Error::Transport)?;
   self.state.borrow_mut().join=Some(joined);
   let joined_frame={let s=self.state.borrow();let j=s.join.as_ref().ok_or(Error::Unknown)?;current_frame(&j.body,&self.bootstrap,&self.request,j.exporter.as_deref().ok_or(Error::Binding)?,Action::Join,Some(&first_frame),&self.window)?};
   self.state.borrow_mut().original=Some(NativeOriginal{frame:joined_frame.frame.clone()});
   self.state.borrow_mut().join_frame=Some(joined_frame);
   self.before_complete(live)?;Ok(())
  })();match result{Ok(())=>{self.state.borrow_mut().complete=true;Ok(())},Err(e)=>Err(self.fail(e))}
 }
}
#[cfg(test)]mod delegation_status_record_controls{
 use super::*;
 fn body()->Value{serde_json::json!({
  "version":1,"purpose":"social-native-account-delegation-status/v1",
  "rootId":"PUBLIC-root","rootKeyId":"PUBLIC-root-key","instanceId":"PUBLIC-instance","registrationId":"PUBLIC-registration",
  "registrationRevision":1,"registrationDigest":"a".repeat(64),"statusSequence":1,"status":"active","previousStatusDigest":null,
  "effectiveAtMs":100,"issuedAtMs":100,"expiresAtMs":200
 })}
 #[test]fn initial_sequence_has_no_predecessor(){
  let mut v=body();assert_eq!(delegation_status_shape(&v),Ok(()));
  v["previousStatusDigest"]=Value::String("b".repeat(64));assert_eq!(delegation_status_shape(&v),Err(Error::Binding));
 }
 #[test]fn later_sequence_requires_exact_digest_shape(){
  let mut v=body();v["statusSequence"]=serde_json::json!(2);
  assert_eq!(delegation_status_shape(&v),Err(Error::Binding));
  for bad in ["","B".repeat(64).as_str(),"a".repeat(63).as_str()]{
   v["previousStatusDigest"]=Value::String(bad.into());assert_eq!(delegation_status_shape(&v),Err(Error::Binding));
  }
  v["previousStatusDigest"]=Value::String("b".repeat(64));assert_eq!(delegation_status_shape(&v),Ok(()));
  // Shape does not verify linkage, signature, trusted floor or latest head.
 }
 #[test]fn identifiers_and_safe_positive_sequences(){
  for k in ["rootId","rootKeyId","instanceId","registrationId"]{
   let mut v=body();v[k]=Value::String("not an identifier".into());assert_eq!(delegation_status_shape(&v),Err(Error::Binding));
  }
  for bad in [serde_json::json!(0),serde_json::json!("1"),serde_json::json!(9007199254740992u64)]{
   for k in ["statusSequence","registrationRevision"]{let mut v=body();v[k]=bad.clone();assert_eq!(delegation_status_shape(&v),Err(Error::Binding));}
  }
 }
 #[test]fn denial_states_are_not_active_authority(){
  for state in ["active","withdrawing","revoked"]{let mut v=body();v["status"]=Value::String(state.into());assert_eq!(delegation_status_shape(&v),Ok(()));}
  for state in ["","ACTIVE","unknown-pending"]{let mut v=body();v["status"]=Value::String(state.into());assert_eq!(delegation_status_shape(&v),Err(Error::Binding));}
  assert!(APPROVED.is_empty());
 }
 #[test]fn exact_fields_and_half_open_effective_window(){
  let mut v=body();v["extra"]=Value::Bool(true);assert_eq!(delegation_status_shape(&v),Err(Error::Binding));
  let mut v=body();v.as_object_mut().unwrap().remove("previousStatusDigest");assert_eq!(delegation_status_shape(&v),Err(Error::Binding));
  for (key,value) in [("expiresAtMs",100),("expiresAtMs",30101),("effectiveAtMs",99),("effectiveAtMs",200)]{
   let mut v=body();v[key]=serde_json::json!(value);assert_eq!(delegation_status_shape(&v),Err(Error::Binding));
  }
 }
 #[test]fn successor_links_complete_original_raw_and_exact_registration(){
  // PUBLIC grammar/control values only: never signed evidence or a grant.
  let prior=body();let raw=b"PUBLIC full envelope control";
  let mut next=prior.clone();next["statusSequence"]=serde_json::json!(2);next["previousStatusDigest"]=serde_json::json!(hash(raw));
  assert_eq!(status_successor(&prior,raw,&next),Ok(()));
  assert_eq!(status_successor(&prior,b"different full envelope",&next),Err(Error::Binding));
  for k in ["rootId","rootKeyId","instanceId","registrationId","registrationDigest"]{
   let mut wrong=next.clone();wrong[k]=serde_json::json!("different");assert_eq!(status_successor(&prior,raw,&wrong),Err(Error::Binding));
  }
  next["registrationRevision"]=serde_json::json!(2);assert_eq!(status_successor(&prior,raw,&next),Err(Error::Binding));
 }
 #[test]fn successor_refuses_gap_duplicate_and_denial_revival(){
  let raw=b"PUBLIC full envelope control";
  for (old,new,allowed) in [("active","active",true),("active","withdrawing",true),("withdrawing","withdrawing",true),("withdrawing","revoked",true),("withdrawing","active",false),("revoked","active",false),("revoked","withdrawing",false),("revoked","revoked",true)]{
   let mut prior=body();prior["status"]=serde_json::json!(old);
   let mut next=prior.clone();next["status"]=serde_json::json!(new);next["statusSequence"]=serde_json::json!(2);next["previousStatusDigest"]=serde_json::json!(hash(raw));
   assert_eq!(status_successor(&prior,raw,&next).is_ok(),allowed);
   for sequence in [1,3]{next["statusSequence"]=serde_json::json!(sequence);assert_eq!(status_successor(&prior,raw,&next),Err(Error::Binding));}
  }
 }
}
#[cfg(test)]mod instance_r2_controls{
 use super::*;
 #[test]fn absent_approved_source_never_imports_response_root(){assert!(matches!(Bootstrap::selected(),Err(Error::Required)));assert!(APPROVED.is_empty());}
 #[test]fn canonical_bounds_duplicates_and_safe_numbers(){
  for raw in [br#"{"a":1,"a":1}"#.as_slice(),br#"{"a":9007199254740992}"#,br#"{"a":1,"b":0}"#,br#"{ "a":1}"#]{assert!(parse(raw,128,&["a"]).is_err());}
  assert!(parse(br#"{"a":9007199254740991}"#,128,&["a"]).is_ok());assert!(parse(&vec![b' ';65537],65536,&["a"]).is_err());
 }
 #[test]fn private_cookie_exact_existing_canonical_domain(){
  let id=B64.encode([1;32]);let binding=B64.encode([2;32]);let cookie=format!("__Host-ynx-social-m1qa-login-id={id}; __Host-ynx-social-m1qa-login-binding={binding}");
  let got=login_digest(cookie.as_bytes()).expect("PUBLIC cookie fixture");
  let expected=format!("YNX_SOCIAL_NATIVE_LOGIN_INSTANCE_V1\n{{\"apiMount\":\"/m1qa\",\"clientId\":\"ynx-social-v1-m1qa-sso-v1\",\"cookieBinding\":\"{binding}\",\"intent\":\"A\",\"origin\":\"https://social.ynxweb4.com\",\"transactionId\":\"{id}\",\"version\":1}}");
  assert_eq!(got,hash(expected.as_bytes()));
  for bad in [format!("{cookie}; x=y"),cookie.replace("m1qa-",""),cookie.replace("; ",";"),cookie.replace(&binding,&format!("{binding}="))]{assert!(login_digest(bad.as_bytes()).is_err());}
 }
 #[test]fn exact_der_spki_not_full_certificate_or_trailing(){
  // Synthetic noncertificate PUBLIC DER used only for parser boundaries, never TLS.
  let der=[0x30,16,0x30,14,2,1,1,0x30,0,0x30,0,0x30,0,0x30,0,0x30,1,7];
  assert_eq!(spki(&der).unwrap(),&[0x30,1,7]);let mut trailing=der.to_vec();trailing.push(0);assert!(spki(&trailing).is_err());
  for n in 0..der.len(){assert!(spki(&der[..n]).is_err());}
 }
 #[test]fn signed_envelope_cannot_gain_admission_from_shape(){
  let v=serde_json::json!({"body":{"version":1},"signature":B64.encode([0;64])});
  assert!(matches!(verify(&v,&[0;32],RD),Err(Error::Signature)));
  assert!(fields(&v["body"],RF).is_err());assert_eq!(RF.len(),26);assert_eq!(SF.len(),14);assert_eq!(CF.len(),35);
 }
 #[test]fn selected_sodium_existing_public_vector_only(){
  fn decode(s:&str)->Vec<u8>{(0..s.len()).step_by(2).map(|i|u8::from_str_radix(&s[i..i+2],16).unwrap()).collect()}
  let k=decode("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a");
  let sig=decode("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b");
  assert_eq!(unsafe{crypto_sign_verify_detached(sig.as_ptr(),b"".as_ptr(),0,k.as_ptr())},0);
 }
}
#[cfg(test)]mod instance_r2_controls_custody{
 use super::*;
 fn attempt()->Rc<Attempt>{let at=now().unwrap();let b=Bootstrap{registration:Value::Null,status:Value::Null,status_raw:Zeroizing::new(vec![]),root_raw:Zeroizing::new(vec![]),registration_raw:Zeroizing::new(vec![]),status_history_raw:vec![],registration_hash:String::new(),key:[0;32],lower:at-1,upper:at+10000,last:std::cell::Cell::new(at)};
 Attempt::new(b,Request{expected:Value::Null,nonce:[0;32],body:Zeroizing::new(vec![]),cookie:Zeroizing::new(vec![]),issued:at-1,expires:at+10000},Window{start:std::time::Instant::now(),budget:std::time::Duration::from_secs(10),issued:(at-1)as i64,expires:(at+10000)as i64})}
 #[test]fn malformed_partial_is_retained_and_retry_never_calls_transport(){
  let a=attempt();let mut calls=0;let mut live=||Ok(());
  let result=a.run_io(&mut live,|_,_,_,_,_,_,_|{calls+=1;Ok(account_https::UnadmittedResponse{eligibility:None,body:Zeroizing::new(b"PUBLIC MALFORMED RESPONSE".to_vec()),exporter:Some("0".repeat(64))})});
  assert_eq!(result,Err(Error::Canonical));assert_eq!(calls,1);
  assert_eq!(a.state.borrow().capture.as_ref().unwrap().body.as_slice(),b"PUBLIC MALFORMED RESPONSE");assert!(a.state.borrow().join.is_none());
  assert_eq!(a.run_io(&mut live,|_,_,_,_,_,_,_|{calls+=1;Err(account_https::Error::Io)}),Err(Error::Canonical));assert_eq!(calls,1);assert!(a.recheck().is_err());
 }
 #[test]fn transport_unknown_first_cause_sticky_no_second_exchange(){let a=attempt();let mut calls=0;let mut live=||Ok(());assert_eq!(a.run_io(&mut live,|_,_,_,_,_,_,_|{calls+=1;Err(account_https::Error::Unknown)}),Err(Error::Transport(account_https::Error::Unknown)));assert_eq!(a.run_io(&mut live,|_,_,_,_,_,_,_|{calls+=1;Err(account_https::Error::Cancelled)}),Err(Error::Transport(account_https::Error::Unknown)));assert_eq!(calls,1);assert!(a.state.borrow().started);assert!(!a.state.borrow().complete);}
}
impl Attempt{
 // Only a completed independently verified SAME capture/join chain supplies
 // these expectations. ROLE eligibility never fills NativeOriginal. This method
 // remains private, and returns UNADMITTED evidence, not a Type4 permit.
 pub(crate)fn verify_pending(&self,role:&[u8],raw:&[u8],lifetime:&crate::account_evidence::RequestLifetime,issuer_message:&[u8],target_message:&[u8])->Result<crate::account_evidence::UnadmittedAccountEvidence,Error>{
  self.pending_checks(||{let s=self.state.borrow();let f=&s.original.as_ref().ok_or(Error::Unknown)?.frame;
  let expected=&self.request.expected;
  for(role,wire,k)in[("ISSUER",issuer_message,"issuerMessageDigest"),("TARGET",target_message,"targetMessageDigest")]{let mut v=format!("YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_{role}_V1\n").into_bytes();v.extend(wire);eq(expected,k,&hash(&v))?;}
  eq(f,"issuer","https://wallet-auth.ynxweb4.com")?;
  let original=crate::account_evidence::Original{lifetime,account:text(f,"account")?,operation:text(expected,"operation")?,association:text(f,"associationCommitment")?,challenge_nonce:text(expected,"challengeNonce")?,request_digest:text(expected,"challengeRequestDigest")?,identity:text(expected,"identity")?,device:text(expected,"device")?,session:text(f,"sessionId")?,family:text(f,"familyId")?,revision:text(expected,"preparedRevision")?.parse().map_err(|_|Error::Binding)?,generation:num(f,"generation")?,reserved:num(f,"reservedAtMs")?,challenge_issued:self.request.issued,challenge_expires:self.request.expires,issuer_message,target_message};
  let result=crate::account_evidence::verify_original(role,raw,&original).map_err(|_|Error::Binding)?;
  Ok(result)})
 }
}
impl Attempt{
 // Internal orchestration only, no grant/provider callback. The verification
 // closure ends (including its Ref) before either failure can be latched.
 fn pending_checks<T>(&self,verify:impl FnOnce()->Result<T,Error>)->Result<T,Error>{
  self.recheck()?;let out=verify()?;self.recheck()?;Ok(out)
 }
 fn with_received_pending<T>(&self,consume:impl FnOnce(&[u8])->Result<T,Error>)->Result<T,Error>{
  self.recheck()?;
  let result=(||{
   let raw={let s=self.state.borrow();let raw=s.join.as_ref().and_then(|r|r.eligibility.as_ref()).ok_or(Error::Unknown)?;
    if raw.is_empty()||raw.len()>8192{return Err(Error::Bounds)}
    Zeroizing::new(raw.to_vec())};
   // No state Ref survives into consume/pending_checks/recheck/fail.
   consume(&raw)
  })();result.map_err(|e|self.fail(e))
 }
 pub(crate)fn verify_received_pending(&self,lifetime:&crate::account_evidence::RequestLifetime,issuer:&[u8],target:&[u8])->Result<crate::account_evidence::UnadmittedAccountEvidence,Error>{
  self.with_received_pending(|raw|{
   let role=crate::account_evidence::original_pending_role().map_err(|_|Error::Required)?;
   self.verify_pending(role,raw,lifetime,issuer,target)
  })
 }
}

#[cfg(test)]mod current_window_controls{
 use super::*;use std::time::{Duration,Instant};
 // PUBLIC state/lifetime fixture only; cannot construct an approved bootstrap.
 pub(super) fn attempt()->Rc<Attempt>{let at=now().unwrap();let a=Attempt::new(Bootstrap{registration:Value::Null,status:Value::Null,status_raw:Zeroizing::new(vec![]),root_raw:Zeroizing::new(vec![]),registration_raw:Zeroizing::new(vec![]),status_history_raw:vec![],registration_hash:String::new(),key:[0;32],lower:at-1000,upper:at+60000,last:std::cell::Cell::new(at)},Request{expected:Value::Null,nonce:[0;32],body:Zeroizing::new(vec![]),cookie:Zeroizing::new(vec![]),issued:at-1000,expires:at+60000},Window{start:Instant::now(),budget:Duration::from_secs(60),issued:(at-1000)as i64,expires:(at+60000)as i64});
  {let mut s=a.state.borrow_mut();s.started=true;s.complete=true;s.original=Some(NativeOriginal{frame:Value::Null});
   let f=||VerifiedCurrentFrame{frame:Value::Null,envelope:Zeroizing::new(b"PUBLIC verified-state seam; not a signed fixture".to_vec()),window:RetainedCurrentWindow{lower:at-1000,upper:at+30000,started:Instant::now(),budget:Duration::from_secs(30)}};s.capture_frame=Some(f());s.join_frame=Some(f());}a
 }
 #[test]fn current_window_controls_each_envelope_expires_before_longer_owners(){
  for capture in [true,false]{let a=attempt();assert_eq!(a.recheck(),Ok(()));
   let r=crate::source_evidence::after_callbacks(||{let mut s=a.state.borrow_mut();let f=if capture{s.capture_frame.as_mut()}else{s.join_frame.as_mut()}.unwrap();f.window.upper=now().unwrap();Ok(())},||a.recheck());
   assert_eq!(r,Err(Error::Window));assert!(a.bootstrap.current().is_ok());assert!(a.window.remaining().is_ok());
   let s=a.state.borrow();assert!(s.original.is_some()&&s.capture_frame.is_some()&&s.join_frame.is_some());assert_eq!(s.first,Some(Error::Window));
  }
 }
 #[test]fn current_window_controls_half_open_and_no_reset(){let a=attempt();let at=now().unwrap();{let mut s=a.state.borrow_mut();let w=&mut s.capture_frame.as_mut().unwrap().window;w.lower=at;w.upper=at+10;}
  assert_eq!(a.check_currents(&a.state.borrow(),at-1),Err(Error::Window));assert_eq!(a.check_currents(&a.state.borrow(),at),Ok(()));assert_eq!(a.check_currents(&a.state.borrow(),at+9),Ok(()));assert_eq!(a.check_currents(&a.state.borrow(),at+10),Err(Error::Window));
 }
 #[test]fn current_window_controls_monotonic_and_first_error_retained(){let a=attempt();{let mut s=a.state.borrow_mut();let w=&mut s.join_frame.as_mut().unwrap().window;w.started=Instant::now()-Duration::from_secs(31);}
  assert_eq!(a.recheck(),Err(Error::Window));assert_eq!(a.recheck(),Err(Error::Window));assert!(a.state.borrow().original.is_some());
  let b=attempt();b.fail(Error::Transport(account_https::Error::Cancelled));assert_eq!(b.recheck(),Err(Error::Transport(account_https::Error::Cancelled)));
 }
}

#[cfg(test)]mod current_window_controls_ordering{
 use super::*;
 #[test]fn current_window_controls_completion_and_prejoin_callbacks(){
  for prejoin in [true,false]{let a=super::current_window_controls::attempt();a.state.borrow_mut().complete=false;
   let mut cb=||{let mut s=a.state.borrow_mut();let f=if prejoin{s.capture_frame.as_mut()}else{s.join_frame.as_mut()}.unwrap();f.window.upper=now().unwrap();Ok(())};
   let result=if prejoin{a.before_join(&mut cb)}else{a.before_complete(&mut cb)};
   assert_eq!(result,Err(Error::Window));a.fail(result.unwrap_err());
   let mut exchanges=0;assert_eq!(a.run_io(&mut||Ok(()),|_,_,_,_,_,_,_|{exchanges+=1;Err(account_https::Error::Io)}),Err(Error::Window));assert_eq!(exchanges,0);
   let s=a.state.borrow();assert!(!s.complete);assert!(s.original.is_some());assert_eq!(s.capture_frame.as_ref().unwrap().envelope.as_slice(),b"PUBLIC verified-state seam; not a signed fixture");assert!(s.join_frame.is_some());
  }
 }
}

#[cfg(test)]mod pending_borrow_controls{
 use super::*;
 fn attempt()->Rc<Attempt>{let a=super::current_window_controls::attempt();a.state.borrow_mut().join=Some(account_https::UnadmittedResponse{body:Zeroizing::new(b"PUBLIC original envelope".to_vec()),eligibility:Some(Zeroizing::new(b"PUBLIC original eligibility".to_vec())),exporter:None});a}
 fn expire(a:&Attempt){a.state.borrow_mut().join_frame.as_mut().unwrap().window.upper=now().unwrap();}
 fn retained(a:&Attempt){let s=a.state.borrow();assert!(s.original.is_some()&&s.capture_frame.is_some()&&s.join_frame.is_some());assert_eq!(s.join.as_ref().unwrap().eligibility.as_ref().unwrap().as_slice(),b"PUBLIC original eligibility");assert_eq!(s.join.as_ref().unwrap().body.as_slice(),b"PUBLIC original envelope");}
 #[test]fn pending_borrow_controls_nested_precheck_and_postcheck_expiry(){
  for pre in [true,false]{let a=attempt();let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||a.with_received_pending(|raw|{
   assert_eq!(raw,b"PUBLIC original eligibility");if pre{expire(&a)}
   // Same inner pre/postcheck used by verify_pending; only mathematical
   // verification is replaced with PUBLIC work, never a root/permission.
   a.pending_checks(||{if !pre{expire(&a)}Ok(())})
  })));
  assert!(matches!(result,Ok(Err(Error::Window))));assert_eq!(a.state.borrow().first,Some(Error::Window));retained(&a);
  let mut calls=0;assert_eq!(a.run_io(&mut||Ok(()),|_,_,_,_,_,_,_|{calls+=1;Err(account_https::Error::Io)}),Err(Error::Window));assert_eq!(calls,0);
  }
 }
 #[test]fn pending_borrow_controls_old_firstcause_and_successful_borrow(){let a=attempt();assert_eq!(a.with_received_pending(|raw|a.pending_checks(||{assert_eq!(raw,b"PUBLIC original eligibility");Ok(())})),Ok(()));retained(&a);
  a.fail(Error::Transport(account_https::Error::Cancelled));expire(&a);let mut calls=0;
  assert_eq!(a.with_received_pending(|_|{calls+=1;Ok(())}),Err(Error::Transport(account_https::Error::Cancelled)));assert_eq!(calls,0);retained(&a);
 }
 #[test]fn pending_borrow_controls_bounded_snapshot_retains_oversize(){let a=attempt();a.state.borrow_mut().join.as_mut().unwrap().eligibility=Some(Zeroizing::new(vec![0;8193]));let mut calls=0;
  assert_eq!(a.with_received_pending(|_|{calls+=1;Ok(())}),Err(Error::Bounds));assert_eq!(calls,0);assert_eq!(a.state.borrow().join.as_ref().unwrap().eligibility.as_ref().unwrap().len(),8193);assert_eq!(a.state.borrow().first,Some(Error::Bounds));}
}

// Server byte carrier is checked against the existing signed instance contract.
// This retains UNADMITTED facts only; no AcceptedInputs or issuer proof exists here.
#[derive(serde::Deserialize)]#[serde(deny_unknown_fields)]
struct ServerRequestWire{operation:String,proposal:String,nonce:String,#[serde(rename="requestDigest")]request_digest:String,#[serde(rename="issuedAtMs")]issued:String,#[serde(rename="expiresMs")]expires:String}
fn decimal(s:&str)->Result<u64,Error>{let n=s.parse::<u64>().map_err(|_|Error::Binding)?;need(n<=MAX&&n.to_string()==s)?;Ok(n)}
fn server_parts(request:&[u8],account:&[u8],prepared:&[u8])->Result<(Request,Value,Zeroizing<Vec<u8>>,Zeroizing<Vec<u8>>,Zeroizing<Vec<u8>>),Error>{
 if request.is_empty()||request.len()>8192{return Err(Error::Bounds)}
 let w:ServerRequestWire=serde_json::from_slice(request).map_err(|_|Error::Canonical)?;
 need(id(&w.operation))?;let proposal=Zeroizing::new(b64(&w.proposal,2657)?);let challenge=b64(&w.nonce,32)?;
 need(B64.encode(Sha256::digest(&proposal))==w.request_digest)?;
 let issued=decimal(&w.issued)?;let expires=decimal(&w.expires)?;need(expires>issued)?;
 let p=parse(prepared,16384,&["version","operation","revision","identity","device","issuerMessage","targetMessage"])?;
 eq(&p,"version","ynx-social-first-enrollment-prepared/v1")?;eq(&p,"operation",&w.operation)?;
 need(decimal(text(&p,"revision")?)?>0&&ascii(text(&p,"identity")?)&&ascii(text(&p,"device")?))?;
 let messages=|key:&str|->Result<Zeroizing<Vec<u8>>,Error>{let encoded=text(&p,key)?;let bytes=B64.decode(encoded).map_err(|_|Error::Binding)?;need(!bytes.is_empty()&&bytes.len()<=65536&&B64.encode(&bytes)==encoded)?;Ok(Zeroizing::new(bytes))};
 let issuer=messages("issuerMessage")?;let target=messages("targetMessage")?;
 let e=parse(account,65536,&["body","signature","accountFrame","delegationStatus","historicalCarrier"])?;let b=&e["body"];fields(b,CF)?;
 let f=parse(text(&e,"accountFrame")?.as_bytes(),16384,FF)?;need(canonical(&f["preparedPublicCommitment"])?==prepared)?;
 let commitment=|role:&str,wire:&[u8]|{let mut raw=Zeroizing::new(format!("YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_{role}_V1\n").into_bytes());raw.extend(wire);hash(&raw)};
 let expected=serde_json::json!({"requestId":w.operation,"operation":w.operation,"loginInstanceDigest":text(b,"loginInstanceDigest")?,"nativeRequestDigest":hash(request),"challengeNonce":w.nonce,"challengeRequestDigest":hash(&proposal),"preparedRevision":p["revision"],"identity":p["identity"],"device":p["device"],"issuerMessageDigest":commitment("ISSUER",&issuer),"targetMessageDigest":commitment("TARGET",&target)});
 need(hex(text(&expected,"loginInstanceDigest")?))?;
 let nonce=challenge.try_into().map_err(|_|Error::Binding)?;
 Ok((Request{expected,nonce,body:Zeroizing::new(request.to_vec()),cookie:Zeroizing::new(vec![]),issued,expires},e,proposal,issuer,target))
}
pub(crate)struct ServerVerifiedOriginal{bootstrap:Bootstrap,request:Request,joined:VerifiedCurrentFrame,pub(crate)proposal:Zeroizing<Vec<u8>>,pub(crate)issuer:Zeroizing<Vec<u8>>,pub(crate)target:Zeroizing<Vec<u8>>}
impl ServerVerifiedOriginal{
 pub(crate)fn receive(root:&[u8],registration:&[u8],status:&[u8],history:&[Zeroizing<Vec<u8>>],request:&[u8],account:&[u8],prepared:&[u8])->Result<Self,Error>{
  let (request,e,proposal,issuer,target)=server_parts(request,account,prepared)?;
  let bootstrap=Bootstrap::selected()?;
  need(root==bootstrap.root_raw.as_slice()&&registration==bootstrap.registration_raw.as_slice()&&status==bootstrap.status_raw.as_slice()&&history.len()==bootstrap.status_history_raw.len()&&history.iter().zip(&bootstrap.status_history_raw).all(|(a,b)|a.as_slice()==b.as_slice()))?;
  let at=now()?;need(at>=request.issued&&at<request.expires)?;
  let original=Window{start:std::time::Instant::now(),budget:std::time::Duration::from_millis(request.expires-at),issued:request.issued as i64,expires:request.expires as i64};
  let joined=current_frame_origin(account,&bootstrap,&request,text(&e["body"],"tlsExporterDigest")?,FrameOrigin::ServerJoined,&original)?;
  let out=Self{bootstrap,request,joined,proposal,issuer,target};out.current()?;Ok(out)
 }
 pub(crate)fn current(&self)->Result<(),Error>{self.bootstrap.current()?;self.joined.window.check(now()?)}
 pub(crate)fn frame(&self)->Result<&Value,Error>{self.current()?;Ok(&self.joined.frame)}
 pub(crate)fn operation(&self)->Result<&str,Error>{self.current()?;text(&self.request.expected,"operation")}
}

#[cfg(test)]mod server_original_parser_controls{
 use super::*;
 // PUBLIC grammar-only dummies: no signature, selected bootstrap, or authority.
 fn public()->(Vec<u8>,Vec<u8>,Vec<u8>){
  let proposal=vec![7;2657];let nonce=vec![8;32];
  let request=serde_json::to_vec(&serde_json::json!({"operation":"fd1-public","proposal":B64.encode(&proposal),"nonce":B64.encode(nonce),"requestDigest":B64.encode(Sha256::digest(&proposal)),"issuedAtMs":"100","expiresMs":"200"})).unwrap();
  let p=serde_json::json!({"version":"ynx-social-first-enrollment-prepared/v1","operation":"fd1-public","revision":"1","identity":"PUBLIC-identity","device":"PUBLIC-device","issuerMessage":B64.encode(b"PUBLIC-issuer"),"targetMessage":B64.encode(b"PUBLIC-target")});
  let mut f=serde_json::json!({});for k in FF{f[*k]=Value::Null;}f["preparedPublicCommitment"]=p.clone();
  let mut b=serde_json::json!({});for k in CF{b[*k]=Value::Null;}b["loginInstanceDigest"]=Value::String("a".repeat(64));
  let e=serde_json::json!({"body":b,"signature":"PUBLIC-unverified","accountFrame":String::from_utf8(canonical(&f).unwrap()).unwrap(),"delegationStatus":"PUBLIC-unverified","historicalCarrier":null});
  (request,canonical(&e).unwrap(),canonical(&p).unwrap())
 }
 #[test]fn original_parser_public_exact_recipe_is_unadmitted(){let(r,a,p)=public();let(out,_,proposal,issuer,target)=server_parts(&r,&a,&p).unwrap();assert_eq!(out.issued,100);assert_eq!(out.expires,200);assert_eq!(proposal.len(),2657);assert_eq!(issuer.as_slice(),b"PUBLIC-issuer");assert_eq!(target.as_slice(),b"PUBLIC-target");assert!(matches!(ServerVerifiedOriginal::receive(b"PUBLIC",b"PUBLIC",b"PUBLIC",&[],&r,&a,&p),Err(Error::Required)));}
 #[test]fn original_parser_duplicate_and_unknown_request_rejected(){let(r,a,p)=public();let mut duplicate=r.clone();duplicate.pop();duplicate.extend(b",\"operation\":\"fd1-public\"}");assert!(matches!(server_parts(&duplicate,&a,&p),Err(Error::Canonical)));let mut v:Value=serde_json::from_slice(&r).unwrap();v["extra"]=Value::Bool(true);assert!(server_parts(&canonical(&v).unwrap(),&a,&p).is_err());}
 #[test]fn original_parser_proposal_digest_and_decimal_window_rejected(){let(r,a,p)=public();let v:Value=serde_json::from_slice(&r).unwrap();for(k,value)in [("requestDigest",B64.encode([9;32])),("issuedAtMs","0100".into()),("expiresMs","9007199254740992".into()),("expiresMs","100".into())]{let mut bad=v.clone();bad[k]=Value::String(value);assert!(server_parts(&canonical(&bad).unwrap(),&a,&p).is_err());}}
 #[test]fn original_parser_prepared_exact_authenticated_frame_bytes(){let(r,a,p)=public();let mut v:Value=serde_json::from_slice(&p).unwrap();v["identity"]=Value::String("OTHER".into());assert!(server_parts(&r,&a,&canonical(&v).unwrap()).is_err());let mut spaced=p.clone();spaced.push(b' ');assert!(matches!(server_parts(&r,&a,&spaced),Err(Error::Canonical)));}
 #[test]fn original_parser_retained_window_half_open_without_renewal(){let w=RetainedCurrentWindow{lower:100,upper:200,started:std::time::Instant::now(),budget:std::time::Duration::from_secs(30)};assert!(w.check(100).is_ok());assert_eq!(w.check(99),Err(Error::Window));assert_eq!(w.check(200),Err(Error::Window));let retired=RetainedCurrentWindow{lower:100,upper:200,started:std::time::Instant::now(),budget:std::time::Duration::ZERO};assert_eq!(retired.check(150),Err(Error::Window));}
 #[test]fn original_parser_invalid_revision_and_encoded_message_refused(){let(r,a,p)=public();let v:Value=serde_json::from_slice(&p).unwrap();for(k,value)in[("revision","0"),("revision","01"),("issuerMessage","PUBLIC==")]{let mut bad=v.clone();bad[k]=Value::String(value.into());assert!(server_parts(&r,&a,&canonical(&bad).unwrap()).is_err());}}
}


// Synchronous restricted view of the SAME retained signed joined frame.
// The HRTB callback cannot return a borrow of its RefCell-held current bytes.
pub(crate)struct MessageAccountOriginal<'a>{pub(crate)operation:&'a str,pub(crate)request:&'a[u8],pub(crate)nonce:&'a[u8;32],pub(crate)current:&'a[u8],pub(crate)started:std::time::Instant,pub(crate)budget:std::time::Duration,pub(crate)issued:i64,pub(crate)expires:i64}
impl Attempt{
 pub(crate)fn with_message_original<R>(&self,run:impl for<'a>FnOnce(MessageAccountOriginal<'a>)->Result<R,Error>)->Result<R,Error>{
  self.recheck()?;
  let state=self.state.try_borrow().map_err(|_|Error::Unknown)?;
  let joined=state.join_frame.as_ref().ok_or(Error::Unknown)?;
  let operation=self.request.expected["operation"].as_str().ok_or(Error::Binding)?;
  let issued=i64::try_from(self.request.issued.max(joined.window.lower)).map_err(|_|Error::Window)?;
  let expires=i64::try_from(self.request.expires.min(joined.window.upper)).map_err(|_|Error::Window)?;
  let result=run(MessageAccountOriginal{operation,request:&self.request.body,nonce:&self.request.nonce,current:&joined.envelope,started:self.window.start,budget:self.window.budget.min(joined.window.budget),issued,expires});
  drop(state);self.recheck()?;result
 }
}
