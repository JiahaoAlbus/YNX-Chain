//! Local bounded ownership/routing only; NEVER source authority or receipt.
use super::*;
use std::thread::{self,ThreadId};
#[derive(Clone,Copy)]pub(super)struct Target{pub(super)registry:u64,pub(super)index:usize,pub(super)generation:u64}
pub(super)struct Route{pub(super)slot:u64,pub(super)target:Target,pub(super)gate:Gate,pub(super)bytes:usize,pub(super)started:bool}
pub(super)struct ActorCustody{pub(super)thread:ThreadId,pub(super)active:Option<u64>,pub(super)next:u64,pub(super)closing:bool,pub(super)ledger_count:usize,pub(super)ledger_bytes:usize,pub(super)routed_bytes:usize,pub(super)routes:[Option<Route>;32]}
impl ActorCustody{
 pub(super)fn new()->Self{Self{thread:thread::current().id(),active:None,next:0,closing:false,ledger_count:0,ledger_bytes:0,routed_bytes:0,routes:std::array::from_fn(|_|None)}}
 pub(super)fn check_thread(&self)->Result<(),PortError>{if self.thread==thread::current().id(){Ok(())}else{Err(PortError::Binding)}}
 pub(super)fn route(&self,slot:u64)->Option<&Route>{self.routes.iter().flatten().find(|r|r.slot==slot)}
 pub(super)fn count(&self)->usize{self.ledger_count+self.routes.iter().flatten().count()}
 pub(super)fn total_bytes(&self)->Option<usize>{self.ledger_bytes.checked_add(self.routed_bytes)}
}
// Shares gate ownership, NOT plaintext/wire/journal copies. The operation's
// original gate remains inaccessible to UI, no pointer or proof factory here.
struct View{gate:Gate,started:bool}
impl NativeStoreBridge{
 fn routed_view(&self,h:&NativePendingHandle)->Option<View>{let c=self.custody.borrow();c.route(h.slot).map(|r|View{gate:r.gate.clone(),started:r.started})}
 pub(super)fn routed_poll(&self,h:&NativePendingHandle)->Option<FinalStatus>{self.routed_view(h).map(|v|if uncertain(&v.gate){FinalStatus::Unknown}else{FinalStatus::Held})}
 pub(super)fn routed_read_error(&self,h:&NativePendingHandle)->Option<PortError>{self.routed_view(h).map(|v|if uncertain(&v.gate){PortError::Unknown}else{PortError::RequiredOnceReceipt})}
 pub(super)fn routed_cancel(&self,h:&NativePendingHandle)->Option<Result<(),PortError>>{
  let v=self.routed_view(h)?; // shared custody borrow ends BEFORE scope/waker callbacks
  let prior=uncertain(&v.gate);v.gate.1.cancel();
  if prior||v.started{v.gate.0.borrow_mut().phase=Phase::Unknown;Some(Err(PortError::Unknown))}else{v.gate.failed();Some(Err(PortError::Held))}
 }
}
