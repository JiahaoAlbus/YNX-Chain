// Private same-reservation custody. Never constructs signing authorization.
use super::{CustodyError, PairProof};
use std::panic::{catch_unwind, AssertUnwindSafe};

pub(crate) struct Type4Attempt {
    wire: Box<[u8]>,
    classic: Option<Box<[u8]>>,
    pq: Option<[u8; 4627]>,
    failure: Option<CustodyError>,
    started: bool,
}
fn copy_error(e: &CustodyError) -> CustodyError {
    match e {
        CustodyError::Bounds => CustodyError::Bounds,
        CustodyError::Thread => CustodyError::Thread,
        CustodyError::Phase => CustodyError::Phase,
        CustodyError::Foreign(n) => CustodyError::Foreign(*n),
        CustodyError::Unknown => CustodyError::Unknown,
        CustodyError::Pair => CustodyError::Pair,
        CustodyError::Memory => CustodyError::Memory,
        CustodyError::RequiredAtomicPairJournal => CustodyError::RequiredAtomicPairJournal,
        CustodyError::Abi => CustodyError::Abi,
    }
}
impl Type4Attempt {
    pub(super) fn new(wire: &[u8]) -> Result<Self, CustodyError> {
        if wire.is_empty() || wire.len() > 65536 { return Err(CustodyError::Bounds); }
        Ok(Self { wire: wire.into(), classic: None, pq: None, failure: None, started: false })
    }
    pub(super) fn unresolved(&self) -> bool { self.started && (self.failure.is_some() || self.pq.is_none()) }
    pub(super) fn observe(&self, wire: &[u8]) -> Result<PairProof, CustodyError> {
        if wire != self.wire.as_ref() { return Err(CustodyError::Pair); }
        if let Some(e) = &self.failure { return Err(copy_error(e)); }
        match (&self.classic, &self.pq) {
            (Some(c), Some(q)) => Ok(PairProof { classic: c.clone(), pq: *q }),
            _ => Err(CustodyError::Unknown),
        }
    }
    // Called only from the already-private authorized native method. Closures
    // receive no key material; production closures call existing primitives.
    pub(super) fn run_once(
        &mut self,
        classic: impl FnOnce() -> Result<Box<[u8]>, CustodyError>,
        pq: impl FnOnce() -> Result<[u8; 4627], CustodyError>,
    ) {
        if self.started { return; }
        self.started = true;
        // Install UNKNOWN before either primitive. Panic cannot turn this into
        // an unattempted operation, including after classic success.
        self.failure = Some(CustodyError::Unknown);
        let result = catch_unwind(AssertUnwindSafe(|| -> Result<(), CustodyError> {
            let c = classic()?;
            self.classic = Some(c);
            if self.classic.as_ref().unwrap().len() != 64 { return Err(CustodyError::Abi); }
            self.pq = Some(pq()?);
            Ok(())
        }));
        match result {
            Ok(Ok(())) => self.failure = None,
            Ok(Err(e)) => self.failure = Some(e),
            Err(_) => {} // original UNKNOWN and any classic result remain held
        }
    }
}

#[cfg(test)] mod tests {
    use super::*;
    use std::cell::Cell;
    #[test] fn partial_is_retained_and_not_resigned() {
        let mut a = Type4Attempt::new(b"PUBLIC exact original").unwrap();
        let calls = Cell::new(0);
        a.run_once(|| { calls.set(calls.get()+1); Ok(vec![7;64].into_boxed_slice()) }, || Err(CustodyError::Foreign(17)));
        let address = a.classic.as_ref().unwrap().as_ptr();
        a.run_once(|| panic!("second classic"), || panic!("second PQ"));
        assert_eq!(calls.get(),1); assert_eq!(address,a.classic.as_ref().unwrap().as_ptr());
        assert!(matches!(a.observe(b"PUBLIC exact original"),Err(CustodyError::Foreign(17))));
        assert!(matches!(a.observe(b"changed"),Err(CustodyError::Pair))); assert!(a.unresolved());
    }
    #[test] fn panic_after_classic_retains_partial() {
        let mut a=Type4Attempt::new(b"PUBLIC").unwrap();
        a.run_once(||Ok(vec![8;64].into_boxed_slice()),||panic!("PUBLIC controlled PQ panic"));
        assert_eq!(a.classic.as_ref().unwrap().as_ref(),&[8;64]);
        assert!(matches!(a.observe(b"PUBLIC"),Err(CustodyError::Unknown)));
        a.run_once(||panic!("resign"),||panic!("resign")); assert!(a.unresolved());
    }
    #[test] fn classic_failure_has_no_pq_effect() {
        let mut a=Type4Attempt::new(b"PUBLIC").unwrap();
        a.run_once(||Err(CustodyError::Pair),||panic!("PQ after failed classic"));
        assert!(a.classic.is_none()); assert!(a.unresolved());
        assert!(matches!(a.observe(b"PUBLIC"),Err(CustodyError::Pair)));
    }
    #[test] fn complete_observation_has_no_new_effect() {
        let mut a=Type4Attempt::new(b"PUBLIC").unwrap();
        a.run_once(||Ok(vec![9;64].into_boxed_slice()),||Ok([10;4627]));
        a.run_once(||panic!("resign"),||panic!("resign"));
        let p=a.observe(b"PUBLIC").unwrap();assert_eq!(&*p.classic,&[9;64]);assert_eq!(p.pq,[10;4627]);assert!(!a.unresolved());
    }
    #[test] fn bounded_and_wrong_classic_length() {
        assert!(Type4Attempt::new(&[]).is_err());assert!(Type4Attempt::new(&vec![0;65537]).is_err());
        let mut a=Type4Attempt::new(b"PUBLIC").unwrap();
        a.run_once(||Ok(vec![1;63].into_boxed_slice()),||panic!("PQ after ABI violation"));
        assert_eq!(a.classic.as_ref().unwrap().len(),63);
        assert!(matches!(a.observe(b"PUBLIC"),Err(CustodyError::Abi)));
    }
}

// This is the actual LocalGenesisReservation field, not a parallel QA ledger.
// Common public transcript/local transaction association is NOT authorization.
pub(crate) struct Type4Slots {
    original: Option<([u8;32], Box<[u8]>)>,
    slots: [Option<Type4Attempt>;2],
}
impl Type4Slots {
    pub(crate) fn new() -> Self { Self { original:None, slots:[None,None] } }
    pub(super) fn get(&self,slot:usize) -> Option<&Type4Attempt> { self.slots.get(slot).and_then(Option::as_ref) }
    pub(super) fn check(&self,slot:usize,transaction:&[u8;32],transcript:&[u8],wire:&[u8]) -> Result<(),CustodyError> {
        if slot>1 || transcript.is_empty() || transcript.len()>49152 || wire.is_empty() || wire.len()>65536 { return Err(CustodyError::Bounds) }
        if let Some((original,body))=&self.original {
            if original!=transaction || body.as_ref()!=transcript { return Err(CustodyError::Pair) }
        }
        if let Some(a)=&self.slots[slot] {
            if a.wire.as_ref()!=wire { return Err(CustodyError::Pair) }
        } else if self.slots.iter().flatten().any(Type4Attempt::unresolved) { return Err(CustodyError::Unknown) }
        Ok(())
    }
    pub(super) fn install(&mut self,slot:usize,transaction:&[u8;32],transcript:&[u8],wire:&[u8]) -> Result<&mut Type4Attempt,CustodyError> {
        self.check(slot,transaction,transcript,wire)?;
        if self.slots[slot].is_none() {
            let attempt=Type4Attempt::new(wire)?;
            if self.original.is_none() { self.original=Some((*transaction,transcript.into())); }
            self.slots[slot]=Some(attempt);
        }
        Ok(self.slots[slot].as_mut().unwrap())
    }
}

#[cfg(test)] mod reservation_slot_controls {
    use super::*;
    use std::cell::Cell;
    fn complete(slots:&mut Type4Slots,slot:usize,transaction:&[u8;32],transcript:&[u8],wire:&[u8],effects:&Cell<u32>)->Result<(),CustodyError>{
        let a=slots.install(slot,transaction,transcript,wire)?;
        a.run_once(||{effects.set(effects.get()+1);Ok(vec![3;64].into_boxed_slice())},||{effects.set(effects.get()+1);Ok([4;4627])});
        a.observe(wire).map(|_|())
    }
    #[test] fn dtr_i1_both_orders_mismatch_no_second_effect(){
        for first in [0,1] {
            for mutation in [0,1,2] {
                let mut slots=Type4Slots::new();let effects=Cell::new(0);let transaction=[7;32];
                complete(&mut slots,first,&transaction,b"PUBLIC transcript nonce-A",b"PUBLIC first outer",&effects).unwrap();
                let before=slots.get(first).unwrap().classic.as_ref().unwrap().as_ptr();
                let changed=if mutation==0 {b"PUBLIC transcript nonce-B".as_slice()}else if mutation==1 {b"PUBLIC other transcript".as_slice()}else{b"PUBLIC transcript nonce-A".as_slice()};
                let mut tx=transaction;if mutation==2{tx[0]^=1;}
                assert!(matches!(complete(&mut slots,1-first,&tx,changed,b"PUBLIC second outer",&effects),Err(CustodyError::Pair)));
                assert_eq!(effects.get(),2);assert!(slots.get(1-first).is_none());assert_eq!(slots.get(first).unwrap().classic.as_ref().unwrap().as_ptr(),before);
            }
        }
    }
    #[test] fn dtr_i1_paired_both_orders_replay_no_resign(){
        for first in [0,1] {
            let mut slots=Type4Slots::new();let effects=Cell::new(0);
            complete(&mut slots,first,&[7;32],b"PUBLIC common",b"PUBLIC role-first",&effects).unwrap();
            complete(&mut slots,1-first,&[7;32],b"PUBLIC common",b"PUBLIC role-second",&effects).unwrap();
            complete(&mut slots,first,&[7;32],b"PUBLIC common",b"PUBLIC role-first",&effects).unwrap();
            assert_eq!(effects.get(),4);
        }
    }
    #[test] fn dtr_i1_unresolved_blocks_other_preserves_first(){
        for first in [0,1] {
            let mut slots=Type4Slots::new();let effects=Cell::new(0);
            slots.install(first,&[7;32],b"PUBLIC common",b"PUBLIC first").unwrap().run_once(||Ok(vec![5;64].into_boxed_slice()),||Err(CustodyError::Foreign(17)));
            assert!(matches!(complete(&mut slots,1-first,&[7;32],b"PUBLIC common",b"PUBLIC second",&effects),Err(CustodyError::Unknown)));
            assert_eq!(effects.get(),0);assert!(slots.get(1-first).is_none());
            assert!(matches!(slots.get(first).unwrap().observe(b"PUBLIC first"),Err(CustodyError::Foreign(17))));
        }
    }
}
