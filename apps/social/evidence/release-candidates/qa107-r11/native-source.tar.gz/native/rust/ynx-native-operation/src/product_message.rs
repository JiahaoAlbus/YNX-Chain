//! Private application input framing. These bytes never authorize a native route.
use crate::{NativeProductError,NativeProductOperation};
use libsignal_protocol::{CiphertextMessage,SignalMessage,PreKeySignalMessage};
use std::{cell::RefCell,future::Future,pin::Pin,rc::Rc,sync::{Arc,atomic::{AtomicBool,Ordering}},task::{Context,Poll,Wake,Waker}};
use zeroize::Zeroizing;
pub(crate) const HEADER:usize=28;
pub(crate) const MAX_TEXT:usize=64*1024;
pub(crate) const MAX_CIPHER:usize=1024*1024;
pub(crate) const MAX_INPUT:usize=HEADER+MAX_CIPHER;
#[derive(Clone,Copy,PartialEq,Eq,Debug)]pub(crate) enum Direction{Send,Receive}
#[derive(Clone,Copy,PartialEq,Eq,Debug)]pub(crate) enum InputError{Bounds,Framing,Utf8,Wire,Memory}
pub(crate) struct MessageInput{bytes:Zeroizing<Vec<u8>>,logical:[u8;16],direction:Direction,wire:Option<CiphertextMessage>}
impl MessageInput{
 pub(crate) fn decode(bytes:Zeroizing<Vec<u8>>,expected:Direction)->Result<Self,InputError>{
  if bytes.len()<HEADER||bytes.len()>MAX_INPUT{return Err(InputError::Bounds)}
  if &bytes[..4]!=b"YNXM"||bytes[4]!=1||bytes[7]!=0{return Err(InputError::Framing)}
  let direction=match bytes[5]{1=>Direction::Send,2=>Direction::Receive,_=>return Err(InputError::Framing)};
  if direction!=expected{return Err(InputError::Framing)}
  let n=u32::from_be_bytes(bytes[24..28].try_into().map_err(|_|InputError::Framing)?) as usize;
  if n==0||n!=bytes.len()-HEADER{return Err(InputError::Bounds)}
  let logical:[u8;16]=bytes[8..24].try_into().map_err(|_|InputError::Framing)?;
  if logical==[0;16]{return Err(InputError::Framing)}
  let wire=match direction{
   Direction::Send=>{if n>MAX_TEXT{return Err(InputError::Bounds)}if bytes[6]!=1{return Err(InputError::Framing)}std::str::from_utf8(&bytes[HEADER..]).map_err(|_|InputError::Utf8)?;None},
   Direction::Receive=>{
    if n>MAX_CIPHER{return Err(InputError::Bounds)}
    // New-core product admission only; selected Signal decoding is untouched.
    if bytes[HEADER]>>4!=4{return Err(InputError::Wire)}
    Some(match bytes[6]{2=>CiphertextMessage::SignalMessage(SignalMessage::try_from(&bytes[HEADER..]).map_err(|_|InputError::Wire)?),3=>CiphertextMessage::PreKeySignalMessage(PreKeySignalMessage::try_from(&bytes[HEADER..]).map_err(|_|InputError::Wire)?),_=>return Err(InputError::Framing)})
   }
  };
  Ok(Self{bytes,logical,direction,wire})
 }
 pub(crate) fn original_digest(&self)->[u8;32]{use sha2::Digest;sha2::Sha256::digest(self.bytes.as_slice()).into()}
 pub(crate) fn logical(&self)->&[u8;16]{&self.logical}
 pub(crate) fn direction(&self)->Direction{self.direction}
 pub(crate) fn body(&self)->&[u8]{&self.bytes[HEADER..]}
 pub(crate) fn wire(&self)->Option<&CiphertextMessage>{self.wire.as_ref()}
 pub(crate) fn same_original(&self,other:&Self)->bool{self.bytes.as_slice()==other.bytes.as_slice()}
}
struct ReadyFlag(AtomicBool);
impl Wake for ReadyFlag{fn wake(self:Arc<Self>){self.0.store(true,Ordering::Release)}fn wake_by_ref(self:&Arc<Self>){self.0.store(true,Ordering::Release)}}
#[derive(Clone,Debug,PartialEq,Eq)]pub(crate) enum Progress{Pending,Prepared,Stopped(NativeProductError)}
/// Poll retains the SAME input and operation outside the future. A caught panic
/// never destroys the original operation, permits retry, or publishes a result.
pub(crate) struct MessageJob{
 original:Rc<MessageInput>,
 _operation:Rc<RefCell<NativeProductOperation>>,
 poller:RetainedPoll,
}
struct RetainedPoll{future:Pin<Box<dyn Future<Output=Result<(),NativeProductError>>>>,ready:Arc<ReadyFlag>,state:Progress}
impl MessageJob{
 pub(crate) fn new(operation:Rc<RefCell<NativeProductOperation>>,input:MessageInput)->Result<Self,(NativeProductError,MessageInput)>{
  let route=match operation.try_borrow(){Ok(op)=>match op.message_route(&input){Ok(r)=>r,Err(e)=>return Err((e,input))},Err(_)=>return Err((NativeProductError::Held,input))};
  let original=Rc::new(input);let request=original.clone();let owner=operation.clone();
  let future=Box::pin(async move{
   let mut op=owner.try_borrow_mut().map_err(|_|NativeProductError::Held)?;
   op.prepare_message(&request,route).await
  });
  Ok(Self{original,_operation:operation,poller:RetainedPoll{future,ready:Arc::new(ReadyFlag(AtomicBool::new(true))),state:Progress::Pending}})
 }
 pub(crate) fn same_original(&self,input:&MessageInput)->bool{self.original.same_original(input)}
 pub(crate) fn logical(&self)->&[u8;16]{self.original.logical()}
 pub(crate) fn progress(&self)->Progress{self.poller.state.clone()}
 pub(crate) fn waker(&self)->Waker{Waker::from(self.poller.ready.clone())}
 pub(crate) fn poll(&mut self)->Progress{self.poller.poll()}
}
impl RetainedPoll{
 fn poll(&mut self)->Progress{
  if self.state!=Progress::Pending{return self.state.clone()}
  if !self.ready.0.swap(false,Ordering::AcqRel){return Progress::Pending}
  let waker=Waker::from(self.ready.clone());let mut cx=Context::from_waker(&waker);
  let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||self.future.as_mut().poll(&mut cx)));
  self.state=match result{Ok(Poll::Pending)=>Progress::Pending,Ok(Poll::Ready(Ok(())))=>Progress::Prepared,Ok(Poll::Ready(Err(e)))=>Progress::Stopped(e),Err(payload)=>{if std::panic::catch_unwind(std::panic::AssertUnwindSafe(||drop(payload))).is_err(){std::process::abort()}Progress::Stopped(NativeProductError::PanicRetained)}};
  self.state.clone()
 }
}
#[cfg(test)]mod tests{
 use super::*;
 fn frame(direction:u8,kind:u8,body:&[u8])->Zeroizing<Vec<u8>>{let mut b=Vec::from(&b"YNXM"[..]);b.extend([1,direction,kind,0]);b.extend([7;16]);b.extend((body.len()as u32).to_be_bytes());b.extend(body);Zeroizing::new(b)}
 #[test]fn r52_text_complete_utf8_and_exact_boundary(){for body in ["你好, Social".as_bytes().to_vec(),vec![b'x';MAX_TEXT]]{let input=MessageInput::decode(frame(1,1,&body),Direction::Send).unwrap_or_else(|_|panic!("valid text"));assert_eq!(input.body(),body);assert_eq!(input.logical(),&[7;16]);}assert!(matches!(MessageInput::decode(frame(1,1,&vec![b'x';MAX_TEXT+1]),Direction::Send),Err(InputError::Bounds)));assert!(matches!(MessageInput::decode(frame(1,1,&[0xff]),Direction::Send),Err(InputError::Utf8)));}
 #[test]fn r52_framing_trailing_truncated_and_wrong_direction(){let good=frame(1,1,b"text");for i in 0..good.len(){assert!(MessageInput::decode(Zeroizing::new(good[..i].to_vec()),Direction::Send).is_err());}let mut extra=good.clone();extra.push(0);assert!(MessageInput::decode(extra,Direction::Send).is_err());assert!(MessageInput::decode(good,Direction::Receive).is_err());for position in [0,4,7,24]{let mut b=frame(1,1,b"text");b[position]=255;assert!(MessageInput::decode(b,Direction::Send).is_err());}}
 #[test]fn r52_selected_receive_parser_public_shape_not_auth(){
  // Public curve base point and zero MAC: structural parse ONLY, never auth.
  let mut wire=vec![0x44,0x0a,33,5,9];wire.extend([0;31]);wire.extend([0x10,0,0x22,1,0]);wire.extend([0;8]);
  let parsed=MessageInput::decode(frame(2,2,&wire),Direction::Receive).unwrap_or_else(|_|panic!("selected structural parse"));assert_eq!(parsed.wire().unwrap().serialize(),wire);assert_eq!(parsed.body(),wire);
  assert!(MessageInput::decode(frame(2,7,&wire),Direction::Receive).is_err());wire[0]=0x33;assert!(MessageInput::decode(frame(2,2,&wire),Direction::Receive).is_err());assert!(MessageInput::decode(frame(2,3,&[0x44]),Direction::Receive).is_err());
 }
 #[test]fn r52_same_logical_id_changed_body_is_conflict(){let a=MessageInput::decode(frame(1,1,b"one"),Direction::Send).unwrap_or_else(|_|panic!("input"));let b=MessageInput::decode(frame(1,1,b"two"),Direction::Send).unwrap_or_else(|_|panic!("input"));assert_eq!(a.logical(),b.logical());assert!(!a.same_original(&b));}
}

#[cfg(test)]mod poll_tests{
 use super::*;use std::cell::Cell;
 struct Controlled{polls:Rc<Cell<usize>>,drops:Rc<Cell<usize>>,wake:Rc<RefCell<Option<Waker>>>,ready:Rc<Cell<bool>>,panic:bool}
 impl Future for Controlled{type Output=Result<(),NativeProductError>;fn poll(self:Pin<&mut Self>,cx:&mut Context<'_>)->Poll<Self::Output>{self.polls.set(self.polls.get()+1);if self.panic{panic!("NONSECRET pending state control")}if self.ready.get(){Poll::Ready(Ok(()))}else{*self.wake.borrow_mut()=Some(cx.waker().clone());Poll::Pending}}}
 impl Drop for Controlled{fn drop(&mut self){self.drops.set(self.drops.get()+1)}}
 #[test]fn r52_pending_wake_retains_future_and_does_not_restart(){
  let polls=Rc::new(Cell::new(0));let drops=Rc::new(Cell::new(0));let ready=Rc::new(Cell::new(false));let wake=Rc::new(RefCell::new(None));
  let future=Controlled{polls:polls.clone(),drops:drops.clone(),ready:ready.clone(),wake:wake.clone(),panic:false};
  let mut core=RetainedPoll{future:Box::pin(future),ready:Arc::new(ReadyFlag(AtomicBool::new(true))),state:Progress::Pending};
  assert_eq!(core.poll(),Progress::Pending);assert_eq!(core.poll(),Progress::Pending);assert_eq!(polls.get(),1);assert_eq!(drops.get(),0);
  ready.set(true);wake.borrow().as_ref().unwrap().wake_by_ref();assert_eq!(core.poll(),Progress::Prepared);assert_eq!(core.poll(),Progress::Prepared);assert_eq!(polls.get(),2);assert_eq!(drops.get(),0);drop(core);assert_eq!(drops.get(),1);
 }
 #[test]fn r52_poll_panic_retains_future_and_never_repolls(){
  let polls=Rc::new(Cell::new(0));let drops=Rc::new(Cell::new(0));
  let mut core=RetainedPoll{future:Box::pin(Controlled{polls:polls.clone(),drops:drops.clone(),ready:Rc::new(Cell::new(false)),wake:Rc::new(RefCell::new(None)),panic:true}),ready:Arc::new(ReadyFlag(AtomicBool::new(true))),state:Progress::Pending};
  for _ in 0..2{assert_eq!(core.poll(),Progress::Stopped(NativeProductError::PanicRetained))}assert_eq!(polls.get(),1);assert_eq!(drops.get(),0);drop(core);assert_eq!(drops.get(),1);
 }
}
