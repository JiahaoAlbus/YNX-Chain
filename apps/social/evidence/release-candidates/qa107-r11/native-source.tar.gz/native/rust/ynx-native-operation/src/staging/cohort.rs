//! Private selected-codec cohort candidate. Authenticated source/device cohort REQUIRED.
//! Serialized input is zeroized; upstream decoded objects are lifetime-owned,
//! NOT claimed securely zeroized/locked by ordinary upstream Drop.
use super::*;
use std::collections::{BTreeMap, HashMap};
use zeroize::{Zeroizing,Zeroize};
pub(super) mod persisted;
const MAX_ROWS:usize=64;
const MAX_ROW_BYTES:usize=64*1024;
const MAX_INPUT_BYTES:usize=1024*1024;
const MAX_USES:usize=16;
#[derive(Debug,PartialEq,Eq)]
pub(super) enum DecodeError{RequiredAuthenticatedCohort,Bound,Binding,Duplicate,Encoding,KeyMismatch,Signature,Policy}
enum NativeAuthenticatedView{#[cfg(feature="abi5-final-native-link")]Held(Rc<super::platform::NativeSnapshotOwner>)}
impl CoherentView{fn current(&self)->Result<(),DecodeError>{match &self.authority{ViewAuthority::Native(view)=>match view{#[cfg(feature="abi5-final-native-link")]NativeAuthenticatedView::Held(owner)=>owner.current().map_err(|_|DecodeError::RequiredAuthenticatedCohort)},#[cfg(test)]ViewAuthority::Fixture=>Ok(())}}}
enum ViewAuthority{Native(NativeAuthenticatedView),#[cfg(test)]Fixture}
struct CoherentView{binding:[u64;11],source_abi:[u8;32],authority:ViewAuthority}
struct SecretInput(Zeroizing<Vec<u8>>);
impl SecretInput{fn bytes(&self)->&[u8]{&self.0}}
impl Drop for SecretInput{fn drop(&mut self){self.0.zeroize();#[cfg(test)]INPUT_RELEASES.with(|n|n.set(n.get()+1));}}
// Mechanically controlled lifetime, NOT a lock/wipe/authentication witness.
// Only the private decoder constructs this after its bounded typed preflight.
struct ControlledLifetime{binding:[u64;11],source_abi:[u8;32],serialized_bytes:usize}

#[derive(Clone,Copy,PartialEq,Eq)] enum SignedPolicy{ReceiveAllowed,Revoked}
#[derive(Clone,Copy,PartialEq,Eq)] enum KyberPolicy{OneTimeAvailable,OneTimeConsumed,LastResort}
enum EcPayload{Record(SecretInput),Missing,Tombstone} // NOT a new tombstone wire codec.
enum Payload{
 LocalIdentity{pair:SecretInput,registration:u32},
 PeerIdentity{address:ProtocolAddress,key:SecretInput},
 Ec{id:PreKeyId,body:EcPayload},
 Signed{id:SignedPreKeyId,body:SecretInput,policy:SignedPolicy},
 Kyber{id:KyberPreKeyId,body:Option<SecretInput>,policy:KyberPolicy,used:Vec<(SignedPreKeyId,PublicKey)>},
 Session{address:ProtocolAddress,body:Option<SecretInput>},
}
struct AuthenticatedRow{view:Rc<CoherentView>,version:u64,payload:Payload}
#[derive(PartialEq,Eq,Hash)]enum RecordSlot{LocalIdentity,Peer(ProtocolAddress),Ec(PreKeyId),Signed(SignedPreKeyId),Kyber(KyberPreKeyId),Session(ProtocolAddress)}
fn clone_slot_address(a:&ProtocolAddress)->ProtocolAddress{#[cfg(test)]SLOT_CLONES.with(|n|n.set(n.get()+1));a.clone()}
impl Clone for RecordSlot{fn clone(&self)->Self{match self{Self::LocalIdentity=>Self::LocalIdentity,Self::Peer(a)=>Self::Peer(clone_slot_address(a)),Self::Ec(id)=>Self::Ec(*id),Self::Signed(id)=>Self::Signed(*id),Self::Kyber(id)=>Self::Kyber(*id),Self::Session(a)=>Self::Session(clone_slot_address(a))}}}
fn slot(p:&Payload)->RecordSlot{match p{Payload::LocalIdentity{..}=>RecordSlot::LocalIdentity,Payload::PeerIdentity{address,..}=>RecordSlot::Peer(clone_slot_address(address)),Payload::Ec{id,..}=>RecordSlot::Ec(*id),Payload::Signed{id,..}=>RecordSlot::Signed(*id),Payload::Kyber{id,..}=>RecordSlot::Kyber(*id),Payload::Session{address,..}=>RecordSlot::Session(clone_slot_address(address))}}
pub(super) struct AuthenticatedOwnedCohortInput{view:Rc<CoherentView>,rows:Vec<AuthenticatedRow>}
pub(super) fn acquire_authenticated_input()->Result<AuthenticatedOwnedCohortInput,DecodeError>{Err(DecodeError::RequiredAuthenticatedCohort)}
struct SignedEntry{record:SignedPreKeyRecord,policy:SignedPolicy}
enum EcEntry{Record(PreKeyRecord),Missing,Tombstone}
struct KyberEntry{record:Option<KyberPreKeyRecord>,policy:KyberPolicy,used:Vec<(SignedPreKeyId,PublicKey)>}
struct DecodedCohort{
 view:Rc<CoherentView>,lifetime:ControlledLifetime,identity:IdentityKeyPair,registration:u32,
 peers:HashMap<ProtocolAddress,IdentityKey>,ec:BTreeMap<PreKeyId,EcEntry>,
 signed:BTreeMap<SignedPreKeyId,SignedEntry>,kyber:BTreeMap<KyberPreKeyId,KyberEntry>,
 sessions:HashMap<ProtocolAddress,Option<SessionRecord>>,
 versions:HashMap<RecordSlot,u64>,serialized_lengths:HashMap<RecordSlot,usize>,
 #[cfg(test)] drop_count:Option<Rc<std::cell::Cell<usize>>>,
}
pub(super) struct DecodedCohortOwner(Rc<RefCell<DecodedCohort>>);
fn protocol<T>(v:R<T>)->Result<T,DecodeError>{v.map_err(|_|DecodeError::Encoding)}
fn address_bound(a:&ProtocolAddress)->Result<(),DecodeError>{if a.name().is_empty()||a.name().len()>128{Err(DecodeError::Bound)}else{Ok(())}}
fn input_len(p:&Payload)->usize{match p{Payload::LocalIdentity{pair,..}=>pair.bytes().len(),Payload::PeerIdentity{key,..}=>key.bytes().len(),Payload::Ec{body:EcPayload::Record(b),..}|Payload::Signed{body:b,..}=>b.bytes().len(),Payload::Kyber{body:Some(b),..}|Payload::Session{body:Some(b),..}=>b.bytes().len(),_=>0}}
fn pair_consistent(pair:&KeyPair)->Result<(),DecodeError>{if pair.private_key.public_key().map_err(|_|DecodeError::Encoding)?!=pair.public_key{Err(DecodeError::KeyMismatch)}else{Ok(())}}
pub(super) fn decode(input:AuthenticatedOwnedCohortInput)->Result<DecodedCohortOwner,DecodeError>{
 input.view.current()?;
 // Complete preflight before ANY selected deserializer/decoded record allocation.
 if input.rows.is_empty()||input.rows.len()>MAX_ROWS{return Err(DecodeError::Bound)}
 let mut total=0usize;let mut identities=0;
 for row in &input.rows{
  if !Rc::ptr_eq(&row.view,&input.view)||row.version==0{return Err(DecodeError::Binding)}
  let n=input_len(&row.payload);if n>MAX_ROW_BYTES{return Err(DecodeError::Bound)}
  total=total.checked_add(n).ok_or(DecodeError::Bound)?;if total>MAX_INPUT_BYTES{return Err(DecodeError::Bound)}
  match &row.payload{
   Payload::LocalIdentity{pair,registration}=>{identities+=1;if pair.bytes().is_empty()||pair.bytes().len()>256||*registration==0{return Err(DecodeError::Policy)}},
   Payload::PeerIdentity{address,key}=>{address_bound(address)?;if key.bytes().len()>64{return Err(DecodeError::Bound)}},
   Payload::Session{address,..}=>address_bound(address)?,
   Payload::Kyber{body,policy,used,..}=>{
    if used.len()>MAX_USES{return Err(DecodeError::Bound)}
    if (*policy==KyberPolicy::OneTimeAvailable&&!used.is_empty())||(*policy==KyberPolicy::OneTimeConsumed&&used.len()!=1)||(*policy!=KyberPolicy::OneTimeConsumed&&body.is_none()){return Err(DecodeError::Policy)}
    if used.iter().enumerate().any(|(i,v)|used[..i].contains(v)){return Err(DecodeError::Duplicate)}
   },_=>{},
  }
 }
 if identities!=1{return Err(DecodeError::Duplicate)}
 // Entire borrowing-only preflight precedes owned keys and map reservation.
 #[cfg(test)]MAP_RESERVATIONS.with(|n|n.set(n.get()+2));
 let mut versions=HashMap::with_capacity(input.rows.len());
 let mut serialized_lengths=HashMap::with_capacity(input.rows.len());
 for row in &input.rows{let key=slot(&row.payload);if versions.insert(key.clone(),row.version).is_some(){return Err(DecodeError::Duplicate)}serialized_lengths.insert(key,input_len(&row.payload));}
 let mut local=None;
 for row in &input.rows{if let Payload::LocalIdentity{pair,registration}=&row.payload{
  let identity=protocol(IdentityKeyPair::try_from(pair.bytes()))?;
  if identity.private_key().public_key().map_err(|_|DecodeError::Encoding)?!=*identity.public_key(){return Err(DecodeError::KeyMismatch)}
  local=Some((identity,*registration));
 }}
 let(identity,registration)=local.ok_or(DecodeError::Policy)?;
 let mut cohort=DecodedCohort{view:input.view.clone(),lifetime:ControlledLifetime{binding:input.view.binding,source_abi:input.view.source_abi,serialized_bytes:total},identity,registration,peers:HashMap::new(),ec:BTreeMap::new(),signed:BTreeMap::new(),kyber:BTreeMap::new(),sessions:HashMap::new(),versions,serialized_lengths,#[cfg(test)]drop_count:None};
 // Input owner remains alive through validation; error drops EVERY partial owner.
 for row in &input.rows{match &row.payload{
  Payload::LocalIdentity{..}=>{},
  Payload::PeerIdentity{address,key}=>{let key=protocol(IdentityKey::decode(key.bytes()))?;if cohort.peers.insert(address.clone(),key).is_some(){return Err(DecodeError::Duplicate)}},
  Payload::Ec{id,body}=>{let entry=match body{EcPayload::Record(b)=>{let r=protocol(PreKeyRecord::deserialize(b.bytes()))?;if protocol(r.id())?!=*id{return Err(DecodeError::Binding)}pair_consistent(&protocol(r.key_pair())?)?;EcEntry::Record(r)},EcPayload::Missing=>EcEntry::Missing,EcPayload::Tombstone=>EcEntry::Tombstone};if cohort.ec.insert(*id,entry).is_some(){return Err(DecodeError::Duplicate)}},
  Payload::Signed{id,body,policy}=>{let r=protocol(SignedPreKeyRecord::deserialize(body.bytes()))?;if protocol(r.id())?!=*id{return Err(DecodeError::Binding)}pair_consistent(&protocol(r.key_pair())?)?;if !identity.public_key().verify_signature(&protocol(r.public_key())?.serialize(),&protocol(r.signature())?){return Err(DecodeError::Signature)}if cohort.signed.insert(*id,SignedEntry{record:r,policy:*policy}).is_some(){return Err(DecodeError::Duplicate)}},
  Payload::Kyber{id,body,policy,used}=>{
   if (*policy==KyberPolicy::OneTimeAvailable&&!used.is_empty())||(*policy==KyberPolicy::OneTimeConsumed&&used.len()!=1)||(*policy!=KyberPolicy::OneTimeConsumed&&body.is_none()){return Err(DecodeError::Policy)}
   let record=if let Some(b)=body{let r=protocol(KyberPreKeyRecord::deserialize(b.bytes()))?;if protocol(r.id())?!=*id{return Err(DecodeError::Binding)}let pair=protocol(r.key_pair())?;if pair.public_key.key_type()!=kem::KeyType::Kyber1024||pair.secret_key.key_type()!=kem::KeyType::Kyber1024{return Err(DecodeError::Policy)}if !identity.public_key().verify_signature(&pair.public_key.serialize(),&protocol(r.signature())?){return Err(DecodeError::Signature)}Some(r)}else{None};
   if used.iter().enumerate().any(|(i,v)|used[..i].contains(v)){return Err(DecodeError::Duplicate)}
   if cohort.kyber.insert(*id,KyberEntry{record,policy:*policy,used:used.clone()}).is_some(){return Err(DecodeError::Duplicate)}
  },
  Payload::Session{address,body}=>{let record=if let Some(b)=body{if b.bytes().is_empty(){return Err(DecodeError::Encoding)}Some(protocol(SessionRecord::deserialize(b.bytes()))?)}else{None};if cohort.sessions.insert(address.clone(),record).is_some(){return Err(DecodeError::Duplicate)}},
 }}
 for k in cohort.kyber.values(){for (id,_) in &k.used{if !cohort.signed.contains_key(id){return Err(DecodeError::Policy)}}}
 for (peer,session) in &cohort.sessions{if let Some(s)=session{
  if protocol(s.local_registration_id())?!=registration||protocol(s.local_identity_key_bytes())?.as_slice()!=identity.identity_key().serialize().as_ref(){return Err(DecodeError::Binding)}
  protocol(s.session_version())?;
  // Denial-only format gate, NOT freshness/selected-key/protection authority.
  if !s.current_pq_state().is_some_and(|state|!state.is_empty()){return Err(DecodeError::Policy)}
  if let Some(remote)=protocol(s.remote_identity_key_bytes())?{let expected=cohort.peers.get(peer).ok_or(DecodeError::Policy)?;if protocol(IdentityKey::decode(&remote))?!=*expected{return Err(DecodeError::Binding)}}
 }}
 Ok(DecodedCohortOwner(Rc::new(RefCell::new(cohort))))
}
// Replacements stay inside the originally selected cohort. Encoding is an
// upstream temporary allocated before accounting; Zeroizing cleans this copy,
// not the upstream object. No decoded-heap/allocator peak bound is claimed.
fn replacement_budget(c:&mut DecodedCohort,slot:RecordSlot,encoded:&[u8])->R<()>{c.view.current().map_err(|_|stopped())?;
 if !c.versions.contains_key(&slot)||encoded.len()>MAX_ROW_BYTES{return Err(stopped())}
 let old=*c.serialized_lengths.get(&slot).ok_or_else(stopped)?;
 let next=c.lifetime.serialized_bytes.checked_sub(old).and_then(|n|n.checked_add(encoded.len())).ok_or_else(stopped)?;
 if next>MAX_INPUT_BYTES{return Err(stopped())}
 c.serialized_lengths.insert(slot,encoded.len());c.lifetime.serialized_bytes=next;Ok(())
}
struct IdentityProjection(Rc<RefCell<DecodedCohort>>);
struct EcProjection(Rc<RefCell<DecodedCohort>>);
struct KyberProjection(Rc<RefCell<DecodedCohort>>);
struct SessionProjection(Rc<RefCell<DecodedCohort>>);
struct SignedProjection(Rc<RefCell<DecodedCohort>>);
#[async_trait(?Send)]impl IdentityKeyStore for IdentityProjection{
 async fn get_identity_key_pair(&self)->R<IdentityKeyPair>{self.0.borrow().view.current().map_err(|_|stopped())?;Ok(self.0.borrow().identity)}
 async fn get_local_registration_id(&self)->R<u32>{self.0.borrow().view.current().map_err(|_|stopped())?;Ok(self.0.borrow().registration)}
 async fn get_identity(&self,a:&ProtocolAddress)->R<Option<IdentityKey>>{self.0.borrow().view.current().map_err(|_|stopped())?;Ok(self.0.borrow().peers.get(a).copied())}
 async fn is_trusted_identity(&self,a:&ProtocolAddress,k:&IdentityKey,_:Direction)->R<bool>{self.0.borrow().view.current().map_err(|_|stopped())?;Ok(self.0.borrow().peers.get(a)==Some(k))} // no unconditional TOFU/grant
 async fn save_identity(&mut self,a:&ProtocolAddress,k:&IdentityKey)->R<IdentityChange>{self.0.borrow().view.current().map_err(|_|stopped())?;if self.0.borrow().peers.get(a)!=Some(k){return Err(stopped())}Ok(IdentityChange::NewOrUnchanged)}
}
#[async_trait(?Send)]impl PreKeyStore for EcProjection{
 async fn get_pre_key(&self,id:PreKeyId)->R<PreKeyRecord>{self.0.borrow().view.current().map_err(|_|stopped())?;match self.0.borrow().ec.get(&id){Some(EcEntry::Record(r))=>Ok(r.clone()),_=>Err(SignalProtocolError::InvalidPreKeyId)}}
 async fn save_pre_key(&mut self,id:PreKeyId,r:&PreKeyRecord)->R<()>{self.0.borrow().view.current().map_err(|_|stopped())?;if r.id()?!=id{return Err(stopped())}let encoded=Zeroizing::new(r.serialize()?);let mut c=self.0.borrow_mut();replacement_budget(&mut c,RecordSlot::Ec(id),&encoded)?;c.ec.insert(id,EcEntry::Record(r.clone()));Ok(())}
 async fn remove_pre_key(&mut self,id:PreKeyId)->R<()>{self.0.borrow().view.current().map_err(|_|stopped())?;if !matches!(self.0.borrow().ec.get(&id),Some(EcEntry::Record(_))){return Err(SignalProtocolError::InvalidPreKeyId)}self.0.borrow_mut().ec.insert(id,EcEntry::Tombstone);Ok(())}
}
#[async_trait(?Send)]impl KyberPreKeyStore for KyberProjection{
 async fn get_kyber_pre_key(&self,id:KyberPreKeyId)->R<KyberPreKeyRecord>{self.0.borrow().view.current().map_err(|_|stopped())?;let c=self.0.borrow();let k=c.kyber.get(&id).ok_or(SignalProtocolError::InvalidKyberPreKeyId)?;if k.policy==KyberPolicy::OneTimeConsumed{return Err(SignalProtocolError::InvalidKyberPreKeyId)}k.record.clone().ok_or(SignalProtocolError::InvalidKyberPreKeyId)}
 async fn save_kyber_pre_key(&mut self,_:KyberPreKeyId,_:&KyberPreKeyRecord)->R<()>{self.0.borrow().view.current().map_err(|_|stopped())?;Err(stopped())} // policy/provenance needed for new record
 async fn mark_kyber_pre_key_used(&mut self,id:KyberPreKeyId,signed:SignedPreKeyId,base:&PublicKey)->R<()>{self.0.borrow().view.current().map_err(|_|stopped())?;let mut c=self.0.borrow_mut();if !matches!(c.signed.get(&signed),Some(SignedEntry{policy:SignedPolicy::ReceiveAllowed,..})){return Err(SignalProtocolError::InvalidSignedPreKeyId)}let k=c.kyber.get_mut(&id).ok_or(SignalProtocolError::InvalidKyberPreKeyId)?;if k.policy==KyberPolicy::OneTimeConsumed||k.used.contains(&(signed,*base))||k.used.len()>=MAX_USES{return Err(stopped())}k.used.push((signed,*base));if k.policy==KyberPolicy::OneTimeAvailable{k.policy=KyberPolicy::OneTimeConsumed;k.record=None;}Ok(())}
}
#[async_trait(?Send)]impl SignedPreKeyStore for SignedProjection{
 async fn get_signed_pre_key(&self,id:SignedPreKeyId)->R<SignedPreKeyRecord>{self.0.borrow().view.current().map_err(|_|stopped())?;match self.0.borrow().signed.get(&id){Some(SignedEntry{record,policy:SignedPolicy::ReceiveAllowed})=>Ok(record.clone()),_=>Err(SignalProtocolError::InvalidSignedPreKeyId)}}
 async fn save_signed_pre_key(&mut self,_:SignedPreKeyId,_:&SignedPreKeyRecord)->R<()>{self.0.borrow().view.current().map_err(|_|stopped())?;Err(stopped())}
}
#[async_trait(?Send)]impl SessionStore for SessionProjection{
 async fn load_session(&self,a:&ProtocolAddress)->R<Option<SessionRecord>>{self.0.borrow().view.current().map_err(|_|stopped())?;Ok(self.0.borrow().sessions.get(a).cloned().flatten())}
 async fn store_session(&mut self,a:&ProtocolAddress,r:&SessionRecord)->R<()>{self.0.borrow().view.current().map_err(|_|stopped())?;let encoded=Zeroizing::new(r.serialize()?);let mut c=self.0.borrow_mut();replacement_budget(&mut c,RecordSlot::Session(a.clone()),&encoded)?;c.sessions.insert(a.clone(),Some(r.clone()));Ok(())}
}
impl DecodedCohortOwner{
 pub(super) fn require_source(&self,source:&[u8;32])->Result<(),DecodeError>{self.0.borrow().view.current()?;if &self.0.borrow().view.source_abi!=source{return Err(DecodeError::Binding)}Ok(())}

 // One owner moved to fixed five projections; no native serialized-byte getter.
 pub(super) fn into_staging(self,gate:Gate)->Result<(StagedOperation,Box<dyn SignedPreKeyStore>),DecodeError>{
  {
   let c=self.0.borrow();c.view.current()?;
   if c.view.binding!=gate.0.borrow().binding||c.lifetime.binding!=c.view.binding||c.lifetime.source_abi!=c.view.source_abi{return Err(DecodeError::Binding)}
  }
  let c=self.0;
  Ok((StagedOperation{identity:Identity{snapshot:Box::new(IdentityProjection(c.clone())),gate:gate.clone()},ec:EC{snapshot:Box::new(EcProjection(c.clone())),gate:gate.clone()},kyber:Kyber{snapshot:Box::new(KyberProjection(c.clone())),gate:gate.clone()},sessions:Sessions{snapshot:Box::new(SessionProjection(c.clone())),gate:gate.clone()},gate},Box::new(SignedProjection(c))))
 }
}
impl Drop for DecodedCohort{fn drop(&mut self){#[cfg(test)]{DECODED_RELEASES.with(|n|n.set(n.get()+1));if let Some(n)=&self.drop_count{n.set(n.get()+1);}}}}
#[cfg(test)]thread_local!{static SLOT_CLONES:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};static MAP_RESERVATIONS:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};static INPUT_RELEASES:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};static DECODED_RELEASES:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}
#[cfg(test)]mod tests;

#[cfg(feature="abi5-final-native-link")]
pub(super)fn acquire_from_original(owner:Rc<super::platform::NativeSnapshotOwner>,p:&mut super::platform::NativeSnapshotData)->Result<AuthenticatedOwnedCohortInput,DecodeError>{
 // The private transfer is readable only while its SAME authentic owner is
 // current; no serialized PUBLIC manifest is an authenticated cohort.
 owner.current().map_err(|_|DecodeError::RequiredAuthenticatedCohort)?;
 let view=Rc::new(CoherentView{binding:p.binding,source_abi:p.source_abi,authority:ViewAuthority::Native(NativeAuthenticatedView::Held(owner.clone()))});
 let mut rows=Vec::with_capacity(p.rows.len());let mut total=0usize;
 // Consume exactly the projection that supplied the lease/queue/reservation.
 // Re-querying here could splice a later projection into the earlier binding.
 for r in std::mem::take(&mut p.rows){
  if r.version==0||r.used.len()>MAX_USES{return Err(DecodeError::Bound)}
  let body=r.body;if body.len()>MAX_ROW_BYTES{return Err(DecodeError::Bound)}total=total.checked_add(body.len()).ok_or(DecodeError::Bound)?;if total>MAX_INPUT_BYTES{return Err(DecodeError::Bound)}
  let address=||->Result<ProtocolAddress,DecodeError>{let name=std::str::from_utf8(&r.name).map_err(|_|DecodeError::Encoding)?;if name.is_empty(){return Err(DecodeError::Bound)}let d=u8::try_from(r.device).map_err(|_|DecodeError::Bound)?;let device=DeviceId::new(d).map_err(|_|DecodeError::Bound)?;Ok(ProtocolAddress::new(name.to_owned(),device))};
  let payload=match r.kind{
   1=>{if r.registration==0||body.is_empty(){return Err(DecodeError::Policy)}Payload::LocalIdentity{pair:SecretInput(body),registration:r.registration}},
   2=>Payload::PeerIdentity{address:address()?,key:SecretInput(body)},
   3=>Payload::Ec{id:r.id.into(),body:match r.policy{0=>EcPayload::Record(SecretInput(body)),1 if body.is_empty()=>EcPayload::Missing,2 if body.is_empty()=>EcPayload::Tombstone,_=>return Err(DecodeError::Policy)}},
   4=>Payload::Signed{id:r.id.into(),body:SecretInput(body),policy:match r.policy{0=>SignedPolicy::ReceiveAllowed,1=>SignedPolicy::Revoked,_=>return Err(DecodeError::Policy)}},
   5=>{let mut used=Vec::with_capacity(r.used.len());for (signed_id,b) in r.used{used.push((signed_id.into(),PublicKey::deserialize(&b).map_err(|_|DecodeError::Encoding)?));}Payload::Kyber{id:r.id.into(),body:if body.is_empty(){None}else{Some(SecretInput(body))},policy:match r.policy{0=>KyberPolicy::OneTimeAvailable,1=>KyberPolicy::OneTimeConsumed,2=>KyberPolicy::LastResort,_=>return Err(DecodeError::Policy)},used}},
   6=>Payload::Session{address:address()?,body:if body.is_empty(){None}else{Some(SecretInput(body))}},
   _=>return Err(DecodeError::Policy),
  };rows.push(AuthenticatedRow{view:view.clone(),version:r.version,payload});
 }
 owner.current().map_err(|_|DecodeError::RequiredAuthenticatedCohort)?;Ok(AuthenticatedOwnedCohortInput{view,rows})
}
