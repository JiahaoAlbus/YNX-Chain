//! Exact GztcU7 same-original synchronous JNI read-existing consumer.
#![allow(unsafe_code)]
use super::*;
use crate::private_custodian_ffi::{RecoveryLoan,RecoveryTopology};
use jni::objects::{JObject,JValue,JByteArray,JString};
pub(super)fn loan<T>(f:impl FnOnce(&mut RecoveryLoan<'_>)->T)->Result<T,i32>{
 thread_check(false)?;
 LOCAL.with(|cell|{let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;let owner=local.as_mut().ok_or(25)?;
  if owner.status==25{return Err(25)}if owner.closed{return Err(16)}
  let selector=owner.genesis.as_ref().ok_or(16)?;
  let mut borrow=owner.controller.local_recovery_loan(selector).map_err(|_|16)?;Ok(f(&mut borrow))
 })
}
fn fail()->i32{match loan(|r|r.fail(16)){Err(25)=>25,_=>16}}
// Java callbacks cannot reenter ANY same-worker owner operation. No RefCell
// borrow crosses the callback; the prior execution state is restored on unwind.
fn recovery_callback<T>(call:impl FnOnce()->jni::errors::Result<T>)->jni::errors::Result<T>{
 struct Fence(bool);impl Drop for Fence{fn drop(&mut self){LOCAL_EXECUTING.with(|v|v.set(self.0));}}
 let prior=LOCAL_EXECUTING.with(|v|v.replace(true));let _fence=Fence(prior);
 assert!(!prior,"private recovery callback already active");call()
}
fn guard(env:&mut jni::Env<'_>,input:&JObject<'_>,command:&JObject<'_>,installed:bool)->jni::errors::Result<i32>{
 guard_context(env,input,command,installed,None)
}
fn guard_context(env:&mut jni::Env<'_>,input:&JObject<'_>,command:&JObject<'_>,installed:bool,context:Option<&JObject<'_>>)->jni::errors::Result<i32>{
 recovery_callback(||env.call_method(input,jni::jni_str!("requireSubmitted"),jni::jni_sig!("()V"),&[]))?;
 let original=env.get_field(input,jni::jni_str!("originalCommand"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;"))?.l()?;
 if !env.is_same_object(&original,command)?{return Ok(43)}
 if env.get_field(input,jni::jni_str!("protectorMode"),jni::jni_sig!("I"))?.i()?!=3||env.get_field(input,jni::jni_str!("authWindowSeconds"),jni::jni_sig!("I"))?.i()?!=0{return Ok(43)}
 let Some(alias)=read_original_alias(env,input)?else{return Ok(43)};
 let generation=env.get_field(input,jni::jni_str!("storageGeneration"),jni::jni_sig!("J"))?.j()?;
 let a=env.get_field(input,jni::jni_str!("originalAssociation"),jni::jni_sig!("[B"))?.l()?;let a=JByteArray::cast_local(env,a)?;let n=env.get_array_length(&a)?;if !(1..=4096).contains(&n){return Ok(43)}
 let ids=env.get_field(input,jni::jni_str!("originalOperationAndIncarnation"),jni::jni_sig!("[B"))?.l()?;let ids=JByteArray::cast_local(env,ids)?;if env.get_array_length(&ids)?!=32{return Ok(43)}
 let association=env.convert_byte_array(&a)?;let ids=env.convert_byte_array(&ids)?;
 // Final user callback before taking native RefCell; no Java method under loan.
 recovery_callback(||env.call_method(input,jni::jni_str!("requireSubmitted"),jni::jni_sig!("()V"),&[]))?;
 if let Some(context)=context{
  let retained=env.get_field(command,jni::jni_str!("retainedAppContext"),jni::jni_sig!("Landroid/content/Context;"))?.l()?;
  if !env.is_same_object(context,&retained)?{return Ok(43)}
  recovery_callback(||env.call_static_method(jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyPrivateCommand"),jni::jni_str!("validateActualContext"),jni::jni_sig!("(Landroid/content/Context;)V"),&[JValue::Object(context)]))?;
  if env.exception_check(){return Ok(16)}
 }
 let checked=loan(|r|->jni::errors::Result<bool>{
  let Ok(c)=r.command()else{return Ok(false)};
  if !env.is_same_object(command,c.as_obj())?||!r.matches(&alias,generation,&association,&ids){return Ok(false)}
  if installed{let Ok(i)=r.input()else{return Ok(false)};if !env.is_same_object(input,i.as_obj())?{return Ok(false)}}Ok(true)
 });
 match checked{Ok(v)=>Ok(if v?{44}else{43}),Err(code)=>Ok(code)}
}
unsafe fn read(env:*mut jni::sys::JNIEnv,context:jni::sys::jobject,input:jni::sys::jobject)->i32{
 if let Err(code)=thread_check(false){return code}if env.is_null()||context.is_null()||input.is_null(){return 43}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(env)};
 let outcome=unowned.with_env_no_catch(|env|->jni::errors::Result<i32>{
  let context=unsafe{JObject::from_raw(env,context)};let input=unsafe{JObject::from_raw(env,input)};
  let command=env.get_field(&input,jni::jni_str!("originalCommand"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;"))?.l()?;
  let retained=env.get_field(&command,jni::jni_str!("retainedAppContext"),jni::jni_sig!("Landroid/content/Context;"))?.l()?;
  if !env.is_same_object(&context,&retained)?{return Ok(43)}
  env.call_static_method(jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyPrivateCommand"),jni::jni_str!("validateActualContext"),jni::jni_sig!("(Landroid/content/Context;)V"),&[JValue::Object(&context)])?;
  let code=guard(env,&input,&command,false)?;if code!=44{return Ok(code)}
  let global=env.new_global_ref(&input)?;
  let topology=match loan(|r|r.start(global)){Ok(Ok(t))=>t,Err(25)=>return Ok(25),_=>return Ok(fail())};
  if topology==RecoveryTopology::Existing{
   // Actual matched Java owns Outcomes before throwing; they stay in command.
   env.call_method(&command,jni::jni_str!("prepareExistingLocalStore"),jni::jni_sig!("(Lcom/ynx/social/matrix/VeilLocalRecoveryInput;)Lcom/ynx/social/matrix/VeilOwnKeyLocalStoreContext$Outcome;"),&[JValue::Object(&input)])?;
   if guard(env,&input,&command,true)?!=44{return Ok(fail())}
   env.call_method(&command,jni::jni_str!("useExistingLocalStore"),jni::jni_sig!("(Lcom/ynx/social/matrix/VeilLocalRecoveryInput;)Lcom/ynx/social/matrix/VeilOwnKeyLocalStoreContext$Outcome;"),&[JValue::Object(&input)])?;
  }
  if guard(env,&input,&command,true)?!=44{return Ok(fail())}
  match loan(|r|r.capture()){Ok(Ok(()))=>{},Err(25)=>return Ok(25),_=>return Ok(fail())}
  // No first-cause/UNKNOWN clearing:61 is copied ciphertext only.
  env.call_static_method(jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyPrivateCommand"),jni::jni_str!("validateActualContext"),jni::jni_sig!("(Landroid/content/Context;)V"),&[JValue::Object(&context)])?;
  if guard(env,&input,&command,true)?!=44{return Ok(fail())}Ok(61)
 }).into_outcome();
 match outcome{jni::Outcome::Ok(code)=>code,jni::Outcome::Err(_)=>fail(),jni::Outcome::Panic(payload)=>std::panic::resume_unwind(payload)}
}
unsafe fn path(env:*mut jni::sys::JNIEnv,command:jni::sys::jobject,input:jni::sys::jobject,path:jni::sys::jstring)->i32{
 if let Err(code)=thread_check(false){return code}if env.is_null()||command.is_null()||input.is_null()||path.is_null(){return 43}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(env)};
 let outcome=unowned.with_env_no_catch(|env|->jni::errors::Result<i32>{
  let command=unsafe{JObject::from_raw(env,command)};let input=unsafe{JObject::from_raw(env,input)};let path=unsafe{JString::from_raw(env,path)};
  let code=guard(env,&input,&command,true)?;if code!=44{return Ok(code)}
  if !env.get_field(&command,jni::jni_str!("recoveryPathActive"),jni::jni_sig!("Z"))?.z()?||!env.get_field(&command,jni::jni_str!("recoveryPathAttempted"),jni::jni_sig!("Z"))?.z()?{return Ok(43)}
  let n=env.call_method(&path,jni::jni_str!("length"),jni::jni_sig!("()I"),&[])?.i()?;if !(1..=4096).contains(&n){return Ok(43)}
  let path:String=env.get_string(&path)?.into();let path=match std::ffi::CString::new(path){Ok(v)=>v,Err(_)=>return Ok(43)};
  if guard(env,&input,&command,true)?!=44{return Ok(fail())}
  match loan(|r|r.open_existing(&path)){Ok(Ok(()))=>{},Err(25)=>return Ok(25),_=>return Ok(fail())}
  if guard(env,&input,&command,true)?!=44{return Ok(fail())}Ok(44)
 }).into_outcome();
 match outcome{jni::Outcome::Ok(code)=>code,jni::Outcome::Err(_)=>fail(),jni::Outcome::Panic(payload)=>std::panic::resume_unwind(payload)}
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeExistingRecoveryAbiVersion(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{boundary(||1)}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeReadExistingLocalPair(env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject)->i32{boundary(||unsafe{read(env,context,input)})}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeOpenExistingDatabase(env:*mut jni::sys::JNIEnv,command:jni::sys::jobject,input:jni::sys::jobject,pathvalue:jni::sys::jstring)->i32{boundary(||unsafe{path(env,command,input,pathvalue)})}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn r60_no_actor_refuses_before_env_or_path(){std::thread::spawn(||{let n: *mut jni::sys::JNIEnv=std::ptr::null_mut();let o:jni::sys::jobject=std::ptr::null_mut();assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeExistingRecoveryAbiVersion(n,o),1);assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeReadExistingLocalPair(n,o,o,o),21);assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeOpenExistingDatabase(n,o,o,o),21);assert!(LOCAL.with(|l|l.borrow().is_none()));}).join().unwrap();}
}

const RECOVERY_ALIAS_PREFIX:&str="ynx.social.ownkey.v1.";
// R62 separate ABI: 61 remains ciphertext-held. 62 means only authenticated
// LOCAL reload/public projection; it is NOT a Principal, grant, or commit.
unsafe fn authenticate(env_raw:*mut jni::sys::JNIEnv,context_raw:jni::sys::jobject,input_raw:jni::sys::jobject,output_raw:jni::sys::jbyteArray)->i32{
 if let Err(code)=thread_check(false){return code}
 if env_raw.is_null()||context_raw.is_null()||input_raw.is_null(){return 43}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(env_raw)};
 let outcome=unowned.with_env_no_catch(|env|->jni::errors::Result<i32>{
  let context=unsafe{JObject::from_raw(env,context_raw)};let input=unsafe{JObject::from_raw(env,input_raw)};
  let command=env.get_field(&input,jni::jni_str!("originalCommand"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;"))?.l()?;
  let retained=env.get_field(&command,jni::jni_str!("retainedAppContext"),jni::jni_sig!("Landroid/content/Context;"))?.l()?;
  if !env.is_same_object(&context,&retained)?{return Ok(43)}
  env.call_static_method(jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyPrivateCommand"),jni::jni_str!("validateActualContext"),jni::jni_sig!("(Landroid/content/Context;)V"),&[JValue::Object(&context)])?;
  if guard(env,&input,&command,true)?!=44{return Ok(fail())}
  if output_raw.is_null(){
   let code=with_original_local_execution(|owner|{
    if owner.status==25{return 25}if owner.closed{return 16}
    let Some(selector)=owner.genesis.as_ref()else{return 16};
    let Ok(mut original)=owner.controller.local_recovery_loan(selector)else{return 16};
    if env.exception_check(){original.fail(16);return 16}
    match unsafe{original.authenticate_captured(env_raw,context_raw)}{Ok(())=>62,Err(_)=>{original.fail(16);16}}
   });
   if code!=62{return Ok(code)}
  }
  // Platform callbacks have completed and the original TLS owner is restored.
  // Recheck original submission before exposing ANY public projection.
  if env.exception_check(){return Ok(fail())}
  if guard(env,&input,&command,true)?!=44{return Ok(fail())}
  if !output_raw.is_null(){
   let out=unsafe{JByteArray::from_raw(env,output_raw)};
   if env.get_array_length(&out)?!=2657{return Ok(43)}
   let bytes=match loan(|r|r.public_pair().map(|p|{let mut out=[0i8;2657];for(i,b)in p.classic.iter().chain(p.pq.iter()).chain(p.operation.iter()).enumerate(){out[i]=*b as i8}out})){Ok(Ok(v))=>v,Err(25)=>return Ok(25),_=>return Ok(fail())};
   env.set_byte_array_region(&out,0,&bytes)?;
  }
  Ok(62)
 }).into_outcome();
 match outcome{jni::Outcome::Ok(code)=>code,jni::Outcome::Err(_)=>fail(),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeAuthenticatedPairAbiVersion(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i32{boundary(||1)}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeAuthenticateExistingLocalPair(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject)->i32{boundary(||unsafe{authenticate(e,context,input,std::ptr::null_mut())})}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeCopyAuthenticatedPublicPair(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject,out:jni::sys::jbyteArray)->i32{boundary(||{if out.is_null(){43}else{unsafe{authenticate(e,context,input,out)}}})}
// Shared by actual receiving guard and JVM field-path control; bounded BEFORE
// native String conversion. The retained native alias comparison still follows.
fn read_original_alias(env:&mut jni::Env<'_>,input:&JObject<'_>)->jni::errors::Result<Option<String>>{
 let alias=env.get_field(input,jni::jni_str!("alias"),jni::jni_sig!("Ljava/lang/String;"))?.l()?;
 if env.call_method(&alias,jni::jni_str!("length"),jni::jni_sig!("()I"),&[])?.i()?!=(RECOVERY_ALIAS_PREFIX.len()+32) as i32{return Ok(None)}
 let alias=JString::cast_local(env,alias)?;let alias:String=env.get_string(&alias)?.into();
 let Some(suffix)=alias.strip_prefix(RECOVERY_ALIAS_PREFIX)else{return Ok(None)};
 if suffix.len()!=32||!suffix.bytes().all(|b|b.is_ascii_digit()||matches!(b,b'a'..=b'f')){return Ok(None)}
 Ok(Some(alias))
}
#[cfg(test)]mod r61_jvm{
 use super::*;use std::ffi::{CString,c_void};
 #[link(name="jvm")]unsafe extern "C"{fn JNI_CreateJavaVM(vm:*mut *mut jni::sys::JavaVM,env:*mut *mut c_void,args:*mut c_void)->jni::sys::jint;}
 #[test]fn r61_actual_jvm_receiver_alias_field_and_original_binding(){
  let cp=CString::new(format!("-Djava.class.path={}",std::env::var("VEIL_R61_JVM_CLASSES").expect("frozen public fixture classes"))).unwrap();
  let mut option=jni::sys::JavaVMOption{optionString:cp.as_ptr() as *mut _,extraInfo:std::ptr::null_mut()};
  let mut args=jni::sys::JavaVMInitArgs{version:jni::sys::JNI_VERSION_1_8,nOptions:1,options:&mut option,ignoreUnrecognized:jni::sys::JNI_FALSE};
  let mut vm:*mut jni::sys::JavaVM=std::ptr::null_mut();let mut raw:*mut c_void=std::ptr::null_mut();
  assert_eq!(unsafe{JNI_CreateJavaVM(&mut vm,&mut raw,&mut args as *mut _ as *mut c_void)},jni::sys::JNI_OK);
  assert!(!vm.is_null()&&!raw.is_null());
  let mut env=unsafe{jni::EnvUnowned::from_raw(raw as *mut jni::sys::JNIEnv)};
  let outcome=env.with_env_no_catch(|env|->jni::errors::Result<()>{
   let good=format!("{}0123456789abcdef0123456789abcdef",RECOVERY_ALIAS_PREFIX);assert_eq!(good.len(),53);
   let rows=[(good.clone(),true,true),(good[..52].to_owned(),false,false),(format!("{good}0"),false,false),(format!("x{}",&good[1..]),false,false),(format!("{}g",&good[..52]),false,false),(format!("{}ffffffffffffffffffffffffffffffff",RECOVERY_ALIAS_PREFIX),true,false)];
   for (i,(value,shape,bound)) in rows.into_iter().enumerate(){
    let string=env.new_string(value)?;let receiver=env.new_object(jni::jni_str!("AliasFixture"),jni::jni_sig!("(Ljava/lang/String;)V"),&[JValue::Object(&string)])?;
    let alias=read_original_alias(env,&receiver)?;assert_eq!(alias.is_some(),shape,"fieldcase {i}");
    let matches=alias.as_ref().is_some_and(|a|crate::private_custodian_ffi::r61_fixture_original_matches(a));assert_eq!(matches,bound,"originalbinding {i}");
   }
   assert!(!env.exception_check());Ok(())
  }).into_outcome();
  match outcome{jni::Outcome::Ok(())=>{},jni::Outcome::Err(e)=>panic!("JVM field path: {e:?}"),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
  assert_eq!(unsafe{((**vm).v1_4.DestroyJavaVM)(vm)},jni::sys::JNI_OK);
 }
}

mod source_current;
#[cfg(feature="predevice-reconciliation-v3")]mod reconciliation_v3;

mod account_channel;


// Actual same-worker normal message acquisition seam. The factory executes
// inside the original RecoveryLoan borrow, never a caller-created Expected.
pub(super)fn with_message_open<R>(input:&crate::message_evidence::MessageOpenInput,run:impl for<'a>FnOnce(&crate::message_evidence::MessageEvidence<'a>)->R)->Result<Result<R,(crate::private_custodian_ffi::CustodyError,Option<R>)>,i32>{
 loan(|original|original.with_message_evidence(&input.issuer_credential,&input.anchor_credential,&input.purpose_authorization,&input.association_issuer,&input.association_anchor,run).map_err(|failure|(failure.error,failure.retained)))
}
