//! Actual prekey side effects remain UNFENCED fixtures; not rollback proof.
use super::*;use async_trait::async_trait;use spqr::ynx_operation::CallScope;
use std::{rc::Rc,cell::RefCell,future::{Future,poll_fn},task::Poll};
type R<T>=libsignal_protocol::error::Result<T>;
#[derive(Clone)]struct Control<'a>{scope:&'a CallScope,counts:Rc<RefCell<[usize;4]>>,stage:usize,mutation:usize,pending:bool}
async fn yield_once(){let mut ready=false;poll_fn(|cx|{if ready{Poll::Ready(())}else{ready=true;cx.waker().wake_by_ref();Poll::Pending}}).await}
impl Control<'_>{async fn hit(&self,stage:usize){self.counts.borrow_mut()[stage]+=1;if stage==self.stage{match self.mutation{0=>self.scope.fixture_revoke(),1=>self.scope.cancel(),_=>self.scope.fixture_rebind(4)}if self.pending{yield_once().await;}}}}
struct Id<'a>{inner:&'a mut dyn IdentityKeyStore,c:Control<'a>}
#[async_trait(?Send)]impl IdentityKeyStore for Id<'_>{
 async fn get_identity_key_pair(&self)->R<IdentityKeyPair>{self.inner.get_identity_key_pair().await}
 async fn get_local_registration_id(&self)->R<u32>{self.inner.get_local_registration_id().await}
 async fn save_identity(&mut self,a:&ProtocolAddress,k:&IdentityKey)->R<IdentityChange>{let r=self.inner.save_identity(a,k).await?;self.c.hit(0).await;Ok(r)}
 async fn is_trusted_identity(&self,a:&ProtocolAddress,k:&IdentityKey,d:Direction)->R<bool>{self.inner.is_trusted_identity(a,k,d).await}
 async fn get_identity(&self,a:&ProtocolAddress)->R<Option<IdentityKey>>{self.inner.get_identity(a).await}
}
struct Kyber<'a>{inner:&'a mut dyn KyberPreKeyStore,c:Control<'a>}
#[async_trait(?Send)]impl KyberPreKeyStore for Kyber<'_>{
 async fn get_kyber_pre_key(&self,id:KyberPreKeyId)->R<KyberPreKeyRecord>{self.inner.get_kyber_pre_key(id).await}
 async fn save_kyber_pre_key(&mut self,id:KyberPreKeyId,r:&KyberPreKeyRecord)->R<()>{self.inner.save_kyber_pre_key(id,r).await}
 async fn mark_kyber_pre_key_used(&mut self,k:KyberPreKeyId,s:SignedPreKeyId,b:&PublicKey)->R<()>{self.inner.mark_kyber_pre_key_used(k,s,b).await?;self.c.hit(1).await;Ok(())}
}
struct EC<'a>{inner:&'a mut dyn PreKeyStore,c:Control<'a>}
#[async_trait(?Send)]impl PreKeyStore for EC<'_>{
 async fn get_pre_key(&self,id:PreKeyId)->R<PreKeyRecord>{self.inner.get_pre_key(id).await}
 async fn save_pre_key(&mut self,id:PreKeyId,r:&PreKeyRecord)->R<()>{self.inner.save_pre_key(id,r).await}
 async fn remove_pre_key(&mut self,id:PreKeyId)->R<()>{self.inner.remove_pre_key(id).await?;self.c.hit(2).await;Ok(())}
}
struct Sessions<'a>{inner:&'a mut dyn SessionStore,c:Control<'a>}
#[async_trait(?Send)]impl SessionStore for Sessions<'_>{
 async fn load_session(&self,a:&ProtocolAddress)->R<Option<SessionRecord>>{self.inner.load_session(a).await}
 async fn store_session(&mut self,a:&ProtocolAddress,r:&SessionRecord)->R<()>{self.inner.store_session(a,r).await?;self.c.hit(3).await;Ok(())}
}
fn run<F:Future>(f:F)->F::Output{let mut f=Box::pin(f);let w=std::task::Waker::noop();let mut cx=std::task::Context::from_waker(w);for _ in 0..16{if let Poll::Ready(r)=f.as_mut().poll(&mut cx){return r}}panic!("bounded fixture pending")}
#[test]fn actual_prekey_immediate_and_pending_callback_terminal_boundaries(){
 for stage in 0..4{for mutation in 0..3{for pending in [false,true]{
    let mut a=upstream::test_in_memory_protocol_store().unwrap();let mut b=upstream::test_in_memory_protocol_store().unwrap();let mut rng=OsRng.unwrap_err();let bundle=upstream::create_pre_key_bundle(&mut b,&mut rng).now_or_never().unwrap().unwrap();
    let alice=ProtocolAddress::new("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa".into(),DeviceId::new(1).unwrap());let bob=ProtocolAddress::new("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb".into(),bundle.device_id().unwrap());
    process_prekey_bundle(&bob,&alice,&mut a.session_store,&mut a.identity_store,&bundle,SystemTime::now(),&mut rng).now_or_never().unwrap().unwrap();let initial=upstream::encrypt(&mut a,&bob,&alice,"prekey callback").now_or_never().unwrap().unwrap();
    let base=match &initial{CiphertextMessage::PreKeySignalMessage(p)=>*p.base_key(),_=>panic!("actual prekey wire")};let ec=*b.all_pre_key_ids().next().unwrap();let signed=*b.all_signed_pre_key_ids().next().unwrap();let kyber=*b.all_kyber_pre_key_ids().next().unwrap();
    assert!(b.get_identity(&alice).now_or_never().unwrap().unwrap().is_none());assert!(b.load_session(&alice).now_or_never().unwrap().unwrap().is_none());
    let scope=CallScope::fixture([1,2,3,0,1,6,7,8,9,0,2]);let counts=Rc::new(RefCell::new([0;4]));let control=Control{scope:&scope,counts:counts.clone(),stage:if stage==3{99}else{stage},mutation,pending};
    let mut ids=Id{inner:&mut b.identity_store,c:control.clone()};let mut keys=EC{inner:&mut b.pre_key_store,c:control.clone()};let mut k=Kyber{inner:&mut b.kyber_pre_key_store,c:control.clone()};let mut sessions=Sessions{inner:&mut b.session_store,c:control};
    let result=run(scope.guard(message_decrypt_with_scope(&initial,&alice,&bob,&mut sessions,&mut ids,&mut keys,&b.signed_pre_key_store,&mut k,&mut rng,Some(&scope))));drop(ids);drop(keys);drop(k);drop(sessions);
    let seen=*counts.borrow();let positive=stage==3;
    if positive{assert_eq!(result.unwrap().unwrap(),b"prekey callback");assert_eq!(seen,[1,1,1,1]);}else{assert!(result.is_err()||result.unwrap().is_err());assert_eq!(seen,match stage{0=>[1,0,0,0],1=>[1,1,0,0],_=>[1,1,1,0]});}
    // Earlier mutations DID occur. Later checks don't roll identity/used keys back.
    assert!(b.get_identity(&alice).now_or_never().unwrap().unwrap().is_some());
    assert_eq!(b.get_pre_key(ec).now_or_never().unwrap().is_err(),stage>=2);
    assert_eq!(b.load_session(&alice).now_or_never().unwrap().unwrap().is_some(),positive);
    let reused=b.mark_kyber_pre_key_used(kyber,signed,&base).now_or_never().unwrap();assert_eq!(reused.is_err(),stage!=0);
    assert!(CallScope::open_production().is_err());
 }}}
}
