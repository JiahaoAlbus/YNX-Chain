//! Public/dummy bytes only. No key generation/signature/authority fixture.
use super::*;
fn bytes()->Zeroizing<Vec<u8>>{Zeroizing::new(vec![1])}
fn ec(id:u32,state:UnverifiedEc)->UnverifiedCell{UnverifiedCell::Ec{id,version:1,state}}
fn signed(id:u32)->UnverifiedCell{UnverifiedCell::Signed{id,version:1,record:bytes(),policy:SignedPolicy::ReceiveAllowed}}
fn tuple(signed:u32)->UsedTuple{let mut base=[0;33];base[0]=5;base[1]=9;UsedTuple{signed,base}}
fn roundtrip(cells:Vec<UnverifiedCell>)->(Zeroizing<Vec<u8>>,UnauthenticatedStorage){let input=UnauthenticatedStorage{cells};let encoded=encode(&input).unwrap();let decoded=decode(&encoded).unwrap();assert_eq!(encode(&decoded).unwrap().as_slice(),encoded.as_slice());(encoded,decoded)}
#[test]fn storage_codec_all_policies_roundtrip_no_authority(){
 let(_,d)=roundtrip(vec![ec(1,UnverifiedEc::Record(bytes())),ec(2,UnverifiedEc::Missing),ec(3,UnverifiedEc::Tombstone),signed(9),UnverifiedCell::Signed{id:10,version:2,record:bytes(),policy:SignedPolicy::Revoked},UnverifiedCell::Kyber{id:20,version:1,record:Some(bytes()),policy:KyberPolicy::OneTimeAvailable,used:vec![]},UnverifiedCell::Kyber{id:21,version:2,record:None,policy:KyberPolicy::OneTimeConsumed,used:vec![tuple(9)]},UnverifiedCell::Kyber{id:22,version:3,record:Some(bytes()),policy:KyberPolicy::LastResort,used:vec![tuple(9),tuple(10)]}]);assert_eq!(d.cells.len(),8);assert!(matches!(d.cells[1],UnverifiedCell::Ec{state:UnverifiedEc::Missing,..}));assert!(matches!(d.cells[2],UnverifiedCell::Ec{state:UnverifiedEc::Tombstone,..}));
}
#[test]fn storage_codec_absence_is_not_stored_missing_or_tombstone(){let(_,empty)=roundtrip(vec![]);assert!(empty.cells.is_empty());let(_,rows)=roundtrip(vec![ec(1,UnverifiedEc::Missing),ec(2,UnverifiedEc::Tombstone)]);assert_eq!(rows.cells.len(),2);assert!(!rows.cells.iter().any(|c|c.view().id==3));let selected=rows.decode_selected().unwrap();assert!(matches!(selected.entries[0].record,SelectedUnverified::Missing));assert!(matches!(selected.entries[1].record,SelectedUnverified::Tombstone));}
#[test]fn storage_codec_bounds_before_record_copies(){
 assert!(matches!(decode(&vec![0;MAX_INPUT_BYTES+1]),Err(CodecError::Bound)));
 let n=MAX_ROW_BYTES-ROW_HEADER;roundtrip(vec![ec(1,UnverifiedEc::Record(Zeroizing::new(vec![1;n])))]);
 assert!(matches!(encode(&UnauthenticatedStorage{cells:vec![ec(1,UnverifiedEc::Record(Zeroizing::new(vec![1;n+1])))]}),Err(CodecError::Bound)));
 let cells=(0..65).map(|id|ec(id,UnverifiedEc::Missing)).collect();assert!(matches!(encode(&UnauthenticatedStorage{cells}),Err(CodecError::Bound)));
 let cells=(0..16).map(|id|ec(id,UnverifiedEc::Record(Zeroizing::new(vec![1;n])))).collect();assert!(matches!(encode(&UnauthenticatedStorage{cells}),Err(CodecError::Bound)));
}
#[test]fn storage_codec_wrong_kind_version_reserved_length_trailing_and_ids(){
 let(encoded,_)=roundtrip(vec![ec(1,UnverifiedEc::Missing),ec(2,UnverifiedEc::Tombstone)]);
 for (at,value)in [(8,1),(16,99),(19,1),(37,1),(24,0)]{let mut b=encoded.to_vec();if at==24{b[24..32].fill(0);}else{b[at]=value;}assert!(decode(&b).is_err());}
 let mut b=encoded.to_vec();b.extend_from_slice(&[0]);assert!(matches!(decode(&b),Err(CodecError::Encoding)));
 let mut b=encoded.to_vec();b[44..48].copy_from_slice(&1u32.to_be_bytes());assert!(matches!(decode(&b),Err(CodecError::Duplicate)));
 let mut b=encoded.to_vec();b[32..36].copy_from_slice(&u32::MAX.to_be_bytes());assert!(matches!(decode(&b),Err(CodecError::Bound)));
 assert!(matches!(encode(&UnauthenticatedStorage{cells:vec![ec(2,UnverifiedEc::Missing),ec(1,UnverifiedEc::Missing)]}),Err(CodecError::Order)));
}
#[test]fn storage_codec_kyber_used16_consumed_and_reference_rules(){
 let mut cells:Vec<_>=(0..16).map(signed).collect();cells.push(UnverifiedCell::Kyber{id:1,version:1,record:Some(bytes()),policy:KyberPolicy::LastResort,used:(0..16).map(tuple).collect()});roundtrip(cells);
 for (policy,record,used,error)in [(KyberPolicy::OneTimeAvailable,Some(bytes()),vec![tuple(9)],CodecError::Policy),(KyberPolicy::OneTimeConsumed,Some(bytes()),vec![tuple(9)],CodecError::Policy),(KyberPolicy::OneTimeConsumed,None,vec![],CodecError::Policy),(KyberPolicy::LastResort,Some(bytes()),vec![tuple(9);2],CodecError::Duplicate),(KyberPolicy::LastResort,Some(bytes()),(0..17).map(tuple).collect(),CodecError::Bound)]{
  let cells=vec![signed(9),UnverifiedCell::Kyber{id:1,version:1,record,policy,used}];assert_eq!(encode(&UnauthenticatedStorage{cells}).err(),Some(error));
 }
 // Real existing storage protector binds EACH kind/id independently. A raw
 // consumed-cell reference is representable but confers NO signed grant.
 let(_,sparse)=roundtrip(vec![UnverifiedCell::Kyber{id:1,version:2,record:None,policy:KyberPolicy::OneTimeConsumed,used:vec![tuple(8)]}]);assert_eq!(sparse.cells.len(),1);
 assert!(matches!(acquire_authenticated_input(),Err(DecodeError::RequiredAuthenticatedCohort)));
}
#[test]fn storage_codec_selected_upstream_rejects_dummy_records_no_keygen(){
 for cell in [ec(1,UnverifiedEc::Record(bytes())),signed(1),UnverifiedCell::Kyber{id:1,version:1,record:Some(bytes()),policy:KyberPolicy::OneTimeAvailable,used:vec![]}]{let(_,d)=roundtrip(vec![cell]);assert!(matches!(d.decode_selected(),Err(CodecError::SelectedRecord)));}
 assert!(matches!(acquire_authenticated_input(),Err(DecodeError::RequiredAuthenticatedCohort)));
}
