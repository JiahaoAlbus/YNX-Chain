//! Existing ForeignSlots + real Retained ownership composition in normal code.
//! NOT an issuer, live actor runtime, private resource constructor or receipt.
use super::*;
use std::thread::{self,ThreadId};
use super::super::super::custody::{ActorCustody,Route,Target};
const MAX_OWNERS:usize=32;

#[derive(Clone,Copy)]pub(super)struct Ticket{registry:u64,index:usize,generation:u64}
struct Slot<'op>{generation:u64,owner:Option<ForeignSlots<'op>>,retained_slot:u64,bytes:usize,started:bool,disposed:Option<MechanicalStatus>}
pub(crate)struct NativeActorRegistry<'op>{id:u64,actor:u64,issuer:Rc<()>,thread:ThreadId,slots:Vec<Slot<'op>>,closing:bool,bytes:usize,custody:Rc<std::cell::RefCell<ActorCustody>>,bound:PhantomData<Rc<()>>}
struct Operation<'a,'op>{registry:&'a mut NativeActorRegistry<'op>,ticket:Ticket,retained_after_call:bool,effect_attempted:bool}
// Exact genuine private anchor acknowledgement NOT supplied, no variants or
// fixture factory. Local C disposal is insufficient for unknown retirement.
enum VerifiedRecoveryRetirement{}
impl<'op>NativeActorRegistry<'op>{
 pub(super)fn for_bridge(b:&NativeStoreBridge,capacity:usize)->Result<Self,PortError>{
  if capacity==0||capacity>MAX_OWNERS{return Err(PortError::Capacity)}
  {let c=b.custody.borrow();c.check_thread()?;if c.closing{return Err(PortError::Cancelled)}if c.active.is_some(){return Err(PortError::Held)}}
  let mut slots=Vec::new();slots.try_reserve_exact(capacity).map_err(|_|PortError::Capacity)?;
  for _ in 0..capacity{slots.push(Slot{generation:0,owner:None,retained_slot:0,bytes:0,started:false,disposed:None});}
  let mut c=b.custody.borrow_mut();c.check_thread()?;if c.closing{return Err(PortError::Cancelled)}if c.active.is_some(){return Err(PortError::Held)}let id=c.next.checked_add(1).ok_or(PortError::Capacity)?;c.next=id;c.active=Some(id);drop(c);
  Ok(Self{id,actor:b.actor,issuer:b.issuer.clone(),thread:thread::current().id(),slots,closing:false,bytes:0,custody:b.custody.clone(),bound:PhantomData})
 }
 fn thread(&self)->Result<(),PortError>{if thread::current().id()==self.thread{Ok(())}else{Err(PortError::Binding)}}
 // Private typed issuer resources, not public pointers, flags or a proof trait.
 // EVERY check/reservation precedes pending removal or any foreign effect.
 pub(super)fn bind_original(&mut self,b:&mut NativeStoreBridge,h:&super::super::super::NativePendingHandle,resources:&'op mut NativeIssuedResources)->Result<Ticket,PortError>{
  self.thread()?;if self.closing||self.custody.borrow().closing{return Err(PortError::Cancelled)}
  if !Rc::ptr_eq(&b.custody,&self.custody)||b.actor!=self.actor||!Rc::ptr_eq(&b.issuer,&self.issuer)||resources.actor!=self.actor||!Rc::ptr_eq(&resources.issuer,&self.issuer){return Err(PortError::Binding)}
  b.handle_ok(h)?;if self.custody.borrow().route(h.slot).is_some(){return Err(PortError::Held)}
  let r=b.pending.get(&h.slot).ok_or(PortError::Retired)?;
  if super::super::super::uncertain(&r.snapshot.stage.gate){return Err(PortError::Unknown)}
  validate_computation(&r.snapshot)?;
  if r.submitted||r.consumed||!matches!(r.completion,super::super::super::Completion::Prepared){return Err(PortError::Rejected)}
  let p=r.snapshot.stage.gate.0.borrow();
  if resources.journal.len()>32||resources.journal.len()!=p.journal.len(){return Err(PortError::Capacity)}
  match (&resources.queue,&r.snapshot.queue){(IssuedQueue::Inbox(_),super::super::super::QueueKind::Inbound)|(IssuedQueue::Outbox(_),super::super::super::QueueKind::Outbound)=>{},_=>return Err(PortError::Binding)}
  drop(p);
  let index=self.slots.iter().position(|s|s.owner.is_none()).ok_or(PortError::Capacity)?;
  let generation=self.slots[index].generation.checked_add(1).ok_or(PortError::Capacity)?;
  let bytes=r.reserved_bytes.checked_add(std::mem::size_of::<ForeignSlots<'op>>()).ok_or(PortError::Capacity)?;
  // Route + merged actor budget is reserved BEFORE moving the ledger owner.
  let mut c=self.custody.borrow_mut();c.check_thread()?;
  if c.active!=Some(self.id)||c.ledger_count!=b.pending.len()||c.ledger_bytes!=b.retained_bytes{return Err(PortError::Binding)}
  let route_index=c.routes.iter().position(Option::is_none).ok_or(PortError::Capacity)?;
  let extra=bytes.checked_sub(r.reserved_bytes).ok_or(PortError::Capacity)?;
  if extra>super::super::super::MAX_RETAINED_BYTES.saturating_sub(c.total_bytes().ok_or(PortError::Capacity)?){return Err(PortError::Capacity)}
  let target=Target{registry:self.id,index,generation};
  // Rc gate clone shares SAME native pending allocation; no wire/journal copy.
  let route=Route{slot:h.slot,target,gate:r.snapshot.stage.gate.clone(),bytes,started:false};
  // Infallible moves into PREALLOCATED inventory; no snapshot/key/journal/wire
  // clone, Box allocation, callback, native prepare/CAS/BEGIN or C destructor.
  let retained=b.pending.remove(&h.slot).expect("same actor checked sole retained owner");b.retained_bytes-=retained.reserved_bytes;
  c.ledger_count-=1;c.ledger_bytes-=retained.reserved_bytes;c.routed_bytes+=bytes;c.routes[route_index]=Some(route);drop(c);
  let original=IssuedOriginal{snapshot:SnapshotCustody::Retained(retained,PhantomData),resources:ResourceCustody::Borrowed(resources),actor:PhantomData};
  let owner=ForeignSlots{original:OriginalCustody::Owned(original),pending:ptr::null_mut(),write:ptr::null_mut(),finish:ptr::null_mut(),lookup:ptr::null_mut(),commit:None,unverified_commit:None,cleanup:ptr::null_mut(),store_cleanup_pending:false,cleanup_primary:None,unknown:false,local_finished:false,lifecycle:Lifecycle::Fresh,observation:None,#[cfg(test)]controlled:None};
  self.slots[index]=Slot{generation,owner:Some(owner),retained_slot:h.slot,bytes,started:false,disposed:None};self.bytes+=bytes;
  Ok(Ticket{registry:self.id,index,generation})
 }
 fn slot(&mut self,t:Ticket)->Result<&mut Slot<'op>,PortError>{self.thread()?;if t.registry!=self.id{return Err(PortError::Binding)}let s=self.slots.get_mut(t.index).ok_or(PortError::Retired)?;if s.generation!=t.generation||s.owner.is_none(){return Err(PortError::Retired)}Ok(s)}
 fn operation(&mut self,t:Ticket)->Result<Operation<'_,'op>,PortError>{self.slot(t)?;Ok(Operation{registry:self,ticket:t,retained_after_call:false,effect_attempted:false})}
 pub(in crate::staging::platform) fn shutdown(mut self)->Result<(),Self>{self.closing=true;self.custody.borrow_mut().closing=true;if self.thread().is_err()||self.slots.iter().any(|s|s.owner.is_some())||self.custody.borrow().ledger_count!=0{Err(self)}else{Ok(())}}
 fn ticket_for_handle(&self,b:&NativeStoreBridge,h:&super::super::super::NativePendingHandle)->Result<Ticket,PortError>{
  self.thread()?;if !Rc::ptr_eq(&self.custody,&b.custody){return Err(PortError::Binding)}b.handle_ok(h)?;
  let c=self.custody.borrow();let r=c.route(h.slot).ok_or(PortError::Held)?;if r.target.registry!=self.id||c.active!=Some(self.id){return Err(PortError::Binding)}let t=Ticket{registry:r.target.registry,index:r.target.index,generation:r.target.generation};
  let s=self.slots.get(t.index).ok_or(PortError::Binding)?;if s.generation!=t.generation||s.retained_slot!=h.slot||s.owner.is_none(){return Err(PortError::Binding)}Ok(t)
 }
 pub(super)fn same_original_pending(&self,t:Ticket,b:&NativeStoreBridge,h:&super::super::super::NativePendingHandle)->Result<(),PortError>{let actual=self.ticket_for_handle(b,h)?;if actual.registry!=t.registry||actual.index!=t.index||actual.generation!=t.generation{return Err(PortError::Binding)}Ok(())}
 // Normal caller keeps the inventory after each synchronous dispatch. This
 // disposition suppresses abandonment classification only while SAME slot
 // custody is retained; it grants no effect or terminal authority.
 pub(super)fn dispatch_retained(&mut self,t:Ticket,action:NativeFinalAction)->Result<MechanicalStatus,PortError>{
  self.current_original(t)?;let mut op=self.operation(t)?;
  let result=match action{NativeFinalAction::Prepare=>op.prepare(),NativeFinalAction::Begin=>op.begin(),NativeFinalAction::Finish=>op.finish(),NativeFinalAction::Lookup=>op.lookup(),NativeFinalAction::Publish=>op.publish()};
  if result.is_err()&&op.effect_attempted{let slot=op.registry.slot(t)?;if slot.started{slot.owner.as_mut().expect("retained slot").mark_unknown();}}
  op.retained_after_call=true;result
 }
 pub(super)fn current_original(&mut self,t:Ticket)->Result<(),PortError>{let s=self.slot(t)?;let owner=s.owner.as_mut().expect("same retained slot");owner.fence()?;owner.resource_current()}
 // Borrow the inhabited final proof from the SAME routed inventory. No handle
 // getter, transfer, extra reference, publish/retry or lifetime extension.
 pub(super)fn with_final_owner<R>(&mut self,t:Ticket,run:impl FnOnce(&model_a_owner::FinalOwner)->R)->Result<R,(PortError,Option<R>)>{
  self.current_original(t).map_err(|e|(e,None))?;
  let s=self.slot(t).map_err(|e|(e,None))?;
  let o=s.owner.as_mut().expect("same retained slot");
  if s.disposed.is_some()||o.unknown{return Err((PortError::Unknown,None))}
  let proof=o.commit.as_ref().ok_or((PortError::RequiredOnceReceipt,None))?;
  if proof.current().is_err(){o.mark_unknown();return Err((PortError::Unknown,None))}
  let value=run(&proof.owner);
  if o.commit.as_ref().expect("borrow cannot remove final proof").current().is_err(){o.mark_unknown();return Err((PortError::Unknown,Some(value)))}
  if o.fence().and_then(|_|o.resource_current()).is_err(){o.mark_unknown();return Err((PortError::Unknown,Some(value)))}
  Ok(value)
 }
 pub(super)fn observe_late_failure(&mut self,t:Ticket)->Result<(),PortError>{let s=self.slot(t)?;if s.started{s.owner.as_mut().expect("same retained slot").mark_unknown();}Ok(())}
 pub(super)fn deliver_verified_to_ledger(&mut self,t:Ticket,b:&mut NativeStoreBridge)->Result<(),PortError>{
  self.thread()?;if self.closing||self.custody.borrow().closing{return Err(PortError::Cancelled)}
  if !Rc::ptr_eq(&b.custody,&self.custody)||b.actor!=self.actor||!Rc::ptr_eq(&b.issuer,&self.issuer){return Err(PortError::Binding)}
  let s=self.slot(t)?;let retained_slot=s.retained_slot;let bytes=s.bytes;
  if s.disposed.is_some()||b.pending.contains_key(&retained_slot){return Err(PortError::Binding)}
  match &s.owner.as_ref().expect("same slot").original{
   OriginalCustody::Owned(o)=>match &o.snapshot{SnapshotCustody::Retained(r,_)=>if !matches!(r.completion,super::super::super::Completion::Prepared)||r.consumed{return Err(PortError::Binding)},#[cfg(test)]SnapshotCustody::Borrowed(_)=>return Err(PortError::RequiredOnceReceipt)},
   #[cfg(test)]OriginalCustody::Borrowed(_)=>return Err(PortError::RequiredOnceReceipt),
  }
  let route_index={let c=self.custody.borrow();c.check_thread()?;if c.active!=Some(self.id)||c.ledger_count!=b.pending.len()||c.ledger_bytes!=b.retained_bytes||c.routed_bytes<bytes{return Err(PortError::Binding)}c.routes.iter().position(|r|r.as_ref().is_some_and(|r|r.slot==retained_slot&&r.target.registry==t.registry&&r.target.index==t.index&&r.target.generation==t.generation)).ok_or(PortError::Binding)?};
  // Reserve the original destination cell BEFORE any foreign RAM disposal.
  if b.pending.reserve(retained_slot).is_none(){return Err(PortError::Binding)}
  self.slot(t)?.owner.as_mut().expect("same slot").prepare_verified_delivery()?;
  let mut owner=self.slot(t)?.owner.take().expect("sole completed owner");
  let proof=owner.commit.take().expect("verified proof checked before move");
  let original=match owner.original{OriginalCustody::Owned(o)=>o,#[cfg(test)]OriginalCustody::Borrowed(_)=>unreachable!("refused before native effects")};
  let mut retained=match original.snapshot{SnapshotCustody::Retained(r,_)=>r,#[cfg(test)]SnapshotCustody::Borrowed(_)=>unreachable!("refused before native effects")};
  let restored_bytes=retained.reserved_bytes;
  let binding=retained.snapshot.lease.binding;
  retained.completion=super::super::super::Completion::Applied(super::super::super::PrivateDurableReceipt{proof,binding});retained.submitted=true;
  retained.snapshot.stage.gate.0.borrow_mut().phase=super::super::super::Phase::Applied;
  // Infallible move into the pre-reserved cell; no post-effect allocation.
  let cell=b.pending.entries.get_mut(&retained_slot).expect("destination reserved before effects");if cell.is_some(){std::process::abort()}*cell=Some(retained);
  b.retained_bytes+=restored_bytes;
  let mut c=self.custody.borrow_mut();let removed=c.routes[route_index].take().expect("same reserved route");if removed.slot!=retained_slot||removed.bytes!=bytes{std::process::abort()}c.routed_bytes-=bytes;c.ledger_count+=1;c.ledger_bytes+=restored_bytes;drop(c);
  self.bytes-=bytes;let s=&mut self.slots[t.index];s.bytes=0;s.retained_slot=0;s.disposed=None;Ok(())
 }
 pub(super)fn recover_retained(&mut self,t:Ticket)->Result<MechanicalStatus,PortError>{let mut op=self.operation(t)?;let result=op.recover_same_owner();op.retained_after_call=true;result}
 pub(super)fn close_empty(&mut self)->Result<(),PortError>{self.thread()?;if self.slots.iter().any(|s|s.owner.is_some())||self.custody.borrow().routes.iter().flatten().any(|r|r.target.registry==self.id){return Err(PortError::RequiredOnceReceipt)}Ok(())}
 fn recover_old_handle(&mut self,b:&NativeStoreBridge,h:&super::super::super::NativePendingHandle)->Result<MechanicalStatus,PortError>{let t=self.ticket_for_handle(b,h)?;self.operation(t)?.recover_same_owner()}
 fn acknowledge_recovery(&mut self,_t:Ticket,proof:VerifiedRecoveryRetirement)->Result<(),PortError>{match proof{}}
 #[cfg(test)]fn fixture_teardown(mut self){
  // Explicit controlled-only teardown, NOT production retirement or a receipt.
  // Do not free any populated foreign slot, even in this synthetic fixture.
  for s in &mut self.slots{if let Some(o)=&s.owner{assert!(o.all_empty());match &o.original.proof{NativeIssuerProof::ControlledOnly=>{},NativeIssuerProof::Qualified(_)=>panic!("qualified owner cannot enter fixture teardown")}}let removed={let mut c=self.custody.borrow_mut();let i=c.routes.iter().position(|r|r.as_ref().is_some_and(|r|r.target.registry==self.id&&r.slot==s.retained_slot));i.map(|i|{let r=c.routes[i].take().unwrap();c.routed_bytes-=r.bytes;r})};drop(removed);s.owner.take();}self.bytes=0;
 }
}
impl<'a,'op> Operation<'a,'op>{
 fn live_effect(&mut self)->Result<&mut ForeignSlots<'op>,PortError>{
  if self.registry.closing||self.registry.custody.borrow().closing{return Err(PortError::Cancelled)}
  {let mut c=self.registry.custody.borrow_mut();let r=c.routes.iter_mut().flatten().find(|r|r.target.registry==self.ticket.registry&&r.target.index==self.ticket.index&&r.target.generation==self.ticket.generation).ok_or(PortError::Binding)?;r.started=true;}
  self.effect_attempted=true;let s=self.registry.slot(self.ticket)?;if s.disposed.is_some(){return Err(PortError::Rejected)}s.started=true;Ok(s.owner.as_mut().expect("owned slot"))
 }
 fn live_admitted(&mut self,expected:Lifecycle)->Result<&mut ForeignSlots<'op>,PortError>{self.registry.slot(self.ticket)?.owner.as_mut().expect("same retained slot").admit(expected)?;self.live_effect()}
 fn prepare(&mut self)->Result<MechanicalStatus,PortError>{self.live_admitted(Lifecycle::Fresh)?.prepare()}
 fn begin(&mut self)->Result<MechanicalStatus,PortError>{self.live_admitted(Lifecycle::Prepared)?.begin_original_journal()}
 fn finish(&mut self)->Result<MechanicalStatus,PortError>{self.live_admitted(Lifecycle::Writing)?.finish_original()}
 fn lookup(&mut self)->Result<MechanicalStatus,PortError>{self.live_admitted(Lifecycle::Fresh)?.lookup_original()}
 fn publish(&mut self)->Result<MechanicalStatus,PortError>{self.registry.slot(self.ticket)?.owner.as_mut().expect("same retained slot").publish_once()}
 fn recover_same_owner(&mut self)->Result<MechanicalStatus,PortError>{
  let s=self.registry.slot(self.ticket)?;let o=s.owner.as_mut().expect("same owned slot");
  if let Some(result)=s.disposed{if super::super::super::uncertain(&o.original.snapshot.stage.gate){o.mark_unknown();return Ok(MechanicalStatus::Unknown)}return Ok(result)}
  let result=o.cancel_and_release_ram();if o.all_empty()&&!matches!(result,MechanicalStatus::HeldCleanup(_)){s.disposed=Some(result);}Ok(result)
 }
}
impl Drop for Operation<'_,'_>{fn drop(&mut self){let s=match self.registry.slot(self.ticket){Ok(s)=>s,Err(_)=>std::process::abort()};if !self.retained_after_call&&s.started&&s.disposed.is_none(){let o=s.owner.as_mut().expect("retained original");o.mark_unknown();}/* NO foreign drop, reencrypt or allocation */}}
impl Drop for NativeActorRegistry<'_>{fn drop(&mut self){if self.slots.iter().any(|s|s.owner.is_some()){std::process::abort();}let mut c=self.custody.borrow_mut();if c.routes.iter().flatten().any(|r|r.target.registry==self.id)||c.active!=Some(self.id){std::process::abort();}c.active=None;/* closing remains sticky */}}
#[cfg(test)]#[path="supervisor/tests.rs"]mod tests;

#[cfg(test)]#[path="supervisor/routing_tests.rs"]mod routing_tests;
