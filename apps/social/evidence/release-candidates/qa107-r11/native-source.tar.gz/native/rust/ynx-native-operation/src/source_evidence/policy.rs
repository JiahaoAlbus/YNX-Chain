//! Exact Go signed APPLICATION policies/checkpoint, not Signal wire changes.
use super::*;
const PROFILE:&str="FIRST_ACCOUNT_ORIGINS_DUAL_PROOFS_CHECKPOINT_V1";
#[derive(Serialize,Deserialize,PartialEq,Eq)]#[serde(deny_unknown_fields,rename_all="camelCase")]
pub(super)struct FirstEnrollment{
 #[serde(default,skip_serializing_if="String::is_empty")] replay_admission:String,
 #[serde(default,skip_serializing_if="String::is_empty")] directory_schema:String,
 #[serde(default,skip_serializing_if="String::is_empty")] deployment:String,
 #[serde(default,skip_serializing_if="String::is_empty")] instance:String,
 #[serde(default,skip_serializing_if="String::is_empty",rename="headerSHA256")] header:String,
 #[serde(default,skip_serializing_if="String::is_empty")] route:String,
 #[serde(default,skip_serializing_if="String::is_empty")] finalization:String,
 version:u64,realm:String,account_issuer:String,writer_authority:String,mode:String,
}
impl FirstEnrollment{
 fn core(&self)->bool{self.version==1&&ascii(&self.realm,128)&&self.account_issuer=="https://wallet-auth.ynxweb4.com"&&ascii(&self.writer_authority,512)&&self.mode=="SINGLE_WRITER_FIRST_IDENTITY_SAME_DEVICE_DUAL_V1"}
 fn complete(&self)->bool{self.core()&&self.replay_admission==PROFILE&&self.directory_schema=="YNX-SOCIAL-FIRST-DIRECTORY-V3"&&self.finalization=="SAME_INODE_SINGLE_WRITER_SOURCE_EXPIRY_V1"&&ascii(&self.deployment,128)&&ascii(&self.instance,128)&&digest(&self.header)&&ascii(&self.route,256)}
}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
pub(super)struct Issuance{version:u64,purpose:String,role:String,realm:String,deployment:String,instance:String,#[serde(rename="headerSHA256")]header:String,key_alias:String,storage_generation:u64,#[serde(rename="notBeforeMS")]not_before:i64,#[serde(rename="expiresMS")]expires:i64}
impl Issuance{
 pub(super)fn holder_storage(&self)->(&str,u64,i64,i64){(&self.key_alias,self.storage_generation,self.not_before,self.expires)}
 pub(super)fn holder_matches(&self,e:&FirstEnrollment,role:&str,authority:&str)->bool{
  matches!(role,"issuer"|"anchor")&&self.valid(role)&&e.complete()&&self.realm==e.realm&&self.deployment==e.deployment&&self.instance==e.instance&&self.header==e.header&&(role!="issuer"||e.writer_authority==authority)
 }

 fn valid(&self,role:&str)->bool{self.version==1&&self.purpose=="SOURCE_PROOF_ARTIFACT_V1"&&self.role==if role=="issuer"{"directory-checkpoint"}else{"current-history"}&&ascii(&self.realm,128)&&ascii(&self.deployment,512)&&ascii(&self.instance,512)&&digest(&self.header)&&ascii(&self.key_alias,128)&&self.storage_generation>0&&self.storage_generation<=i64::MAX as u64&&self.not_before>=0&&self.expires>self.not_before}
}
#[derive(Serialize,Deserialize,PartialEq,Eq)]#[serde(deny_unknown_fields,rename_all="camelCase")]
pub(super)struct Checkpoint{version:u64,profile:String,realm:String,deployment:String,instance:String,#[serde(rename="headerSHA256")]header:String,scope:Scope,sequence:u64,bytes:u64,head:String,root:String,directory_epoch:u64,source_history_head:String,source_catalog_digest:String,anchor_custodian:String,#[serde(rename="issuedMs")]issued:i64,#[serde(rename="expiresMs")]expires:i64}
fn endpoint(s:&str)->bool{
 let Some(authority)=s.strip_prefix("https://").and_then(|s|s.strip_suffix("/v4/source-authority/current-history"))else{return false};
 if !ascii(authority,512)||authority.contains(['@','/','?','#','\\','%']){return false}
 let (host,port)=if let Some(rest)=authority.strip_prefix('['){let Some((h,p))=rest.split_once(']')else{return false};if h.parse::<std::net::Ipv6Addr>().is_err(){return false}(h,if p.is_empty(){None}else{let Some(port)=p.strip_prefix(':')else{return false};Some(port)})}else{let(h,p)=authority.rsplit_once(':').map(|(h,p)|(h,Some(p))).unwrap_or((authority,None));if h.is_empty()||!h.split('.').all(|label|!label.is_empty()&&label.len()<=63&&!label.starts_with('-')&&!label.ends_with('-')&&label.bytes().all(|b|b.is_ascii_alphanumeric()||b==b'-')){return false}(h,p)};
 !host.is_empty()&&port.is_none_or(|p|!p.is_empty()&&p.bytes().all(|b|b.is_ascii_digit())&&p.parse::<u16>().is_ok_and(|n|n>0))
}

impl Checkpoint {
 pub(super) fn deployment_coordinates(&self)->(&str,&str,&str){(&self.deployment,&self.instance,&self.header)}
 pub(super) fn storage_coordinates(&self)->(u64,&str,&str){(self.sequence,&self.head,&self.anchor_custodian)}
 pub(super) fn pending_extent(&self,realm:&str,scope:&Scope,root:&str,epoch:u64,sequence:u64,offset:u64,length:u64,issued:i64,expires:i64)->bool {
  self.version==1&&self.profile==PROFILE&&ascii(&self.deployment,256)&&ascii(&self.instance,256)&&ascii(&self.anchor_custodian,512)&&self.sequence>0&&self.sequence<=4096&&self.bytes>0&&self.bytes<=64*1024*1024&&self.directory_epoch>0&&self.directory_epoch<((1u64<<53)-1)&&[&self.header,&self.head,&self.root,&self.source_history_head,&self.source_catalog_digest].iter().all(|s|digest(s)&&s.bytes().any(|b|b!=b'0'))&&self.issued>=0&&self.expires>self.issued&&self.expires-self.issued<=30000&&self.expires<=((1i64<<53)-1)&&self.realm==realm&&self.scope==*scope&&self.root==root&&self.directory_epoch==epoch&&sequence>0&&sequence<=self.sequence&&offset>0&&offset<self.bytes&&length>0&&length<=512*1024&&length<=self.bytes-offset&&issued>=self.issued&&expires<=self.expires
 }
}
pub(super)fn credential_shape(c:&Credential)->Result<(),Error>{
 if !endpoint(&c.history_endpoint)||c.first_enrollment.as_ref().is_some_and(|p|!p.core())||c.issuance.as_ref().is_some_and(|p|!p.valid(&c.role))||c.first_prepared.as_ref().is_some_and(|p|!p.valid(&c.role)){return Err(Error::Binding)}Ok(())
}
/// Retained signed time intersection; not an authority or renewable lease.
pub(super)struct Window{not_before:i64,pub(super)expires:i64}
impl Window{
 pub(super)fn restrict(&mut self,lower:i64,upper:i64)->Result<(),Error>{
  if lower<0||upper<=lower{return Err(Error::Window)}
  self.not_before=self.not_before.max(lower);self.expires=self.expires.min(upper);
  if self.not_before>=self.expires{return Err(Error::Window)}Ok(())
 }
 pub(super)fn intersect(history:(i64,i64),checkpoint:(i64,i64),issuer:Option<(i64,i64)>,anchor:Option<(i64,i64)>)->Result<Self,Error>{
  let mut window=Self{not_before:0,expires:i64::MAX};
  for (lower,upper) in [Some(history),Some(checkpoint),issuer,anchor].into_iter().flatten(){
   if lower<0||upper<=lower{return Err(Error::Window)}
   window.not_before=window.not_before.max(lower);window.expires=window.expires.min(upper);
  }
  if window.not_before>=window.expires{return Err(Error::Window)}Ok(window)
 }
 pub(super)fn current(&self,now:i64)->Result<(),Error>{if now<self.not_before||now>=self.expires{Err(Error::Window)}else{Ok(())}}
}
pub(super)fn verify(reg:&Registration,issuer:&Credential,anchor:&Credential,h:&History,now:i64)->Result<(Window,FirstGenesisBinding),Error>{
 let p=issuer.first_enrollment.as_ref().ok_or(Error::Binding)?;
 if !p.complete()||anchor.first_enrollment.as_ref()!=Some(p)||p.writer_authority!=issuer.authority{return Err(Error::Binding)}
 for c in [issuer,anchor]{if let Some(i)=&c.issuance{if now<i.not_before||now>=i.expires||i.realm!=p.realm||i.deployment!=p.deployment||i.instance!=p.instance||i.header!=p.header{return Err(Error::Window)}}}
 let envelope=reg.directory_checkpoint.as_ref().ok_or(Error::Binding)?;
 let raw=verify_envelope(envelope,"directory-checkpoint",&issuer.public)?;
 let cp:Checkpoint=canonical(&raw,32768)?;
 if h.directory_checkpoint.as_ref()!=Some(&cp)||cp.version!=1||cp.profile!=PROFILE||cp.realm!=p.realm||cp.deployment!=p.deployment||cp.instance!=p.instance||cp.header!=p.header||cp.scope!=issuer.scope||cp.source_history_head!=h.head||cp.source_catalog_digest!=h.catalog_digest||cp.anchor_custodian!=anchor.custodian||cp.sequence>4096||cp.bytes==0||cp.bytes>64*1024*1024||!digest(&cp.head)||!digest(&cp.root)||cp.directory_epoch==0{return Err(Error::Binding)}
 if cp.issued<0||now<cp.issued||now>=cp.expires||cp.expires>h.expires||cp.expires.checked_sub(cp.issued).filter(|v|*v>0&&*v<=30000).is_none(){return Err(Error::Window)}
 let window=Window::intersect((h.issued,h.expires),(cp.issued,cp.expires),issuer.issuance.as_ref().map(|i|(i.not_before,i.expires)),anchor.issuance.as_ref().map(|i|(i.not_before,i.expires)))?;
 window.current(now)?;
 let mut root=[0;32];for(i,b)in root.iter_mut().enumerate(){*b=u8::from_str_radix(&cp.root[2*i..2*i+2],16).map_err(|_|Error::Binding)?;}
 Ok((window,FirstGenesisBinding{realm:p.realm.clone(),route:p.route.clone(),root,epoch:cp.directory_epoch}))
}
#[cfg(test)]mod policy_controls{
 use super::*;
 #[test]fn policy_controls_endpoint_and_no_opaque_policy(){
  assert!(endpoint("https://source.invalid/v4/source-authority/current-history"));
  for p in ["https://u@source.invalid/v4/source-authority/current-history","http://source.invalid/v4/source-authority/current-history","https://source.invalid:0/v4/source-authority/current-history","https://source.invalid/v4/source-authority/current-history?nonce=x"]{assert!(!endpoint(p))}
  assert!(canonical::<FirstEnrollment>(br#"{"version":1,"realm":"r","accountIssuer":"https://wallet-auth.ynxweb4.com","writerAuthority":"w","mode":"SINGLE_WRITER_FIRST_IDENTITY_SAME_DEVICE_DUAL_V1","extra":true}"#,32768).is_err());
  let p:FirstEnrollment=canonical(br#"{"version":1,"realm":"r","accountIssuer":"https://wallet-auth.ynxweb4.com","writerAuthority":"w","mode":"SINGLE_WRITER_FIRST_IDENTITY_SAME_DEVICE_DUAL_V1"}"#,32768).unwrap();assert!(p.core());assert!(!p.complete());
 }
}

// Same verified source policy/checkpoint. This is not proof of account absence
// or a live remote through-effect lease, and cannot construct signing authority.
pub(super)struct FirstGenesisBinding{realm:String,route:String,root:[u8;32],epoch:u64}
impl FirstGenesisBinding{
 pub(super)fn matches(&self,realm:&[u8],route:&[u8],root:&[u8],epoch:u64)->Result<(),Error>{
  if realm!=self.realm.as_bytes()||route!=self.route.as_bytes()||root!=self.root||epoch!=self.epoch{return Err(Error::Binding)}Ok(())
 }
}
#[cfg(test)]mod first_genesis_source_binding_controls{
 use super::*;
 #[test]fn first_genesis_binding_controls_signed_coordinates(){
  let b=FirstGenesisBinding{realm:"r".into(),route:"route".into(),root:[1;32],epoch:7};
  assert_eq!(b.matches(b"r",b"route",&[1;32],7),Ok(()));
  assert_eq!(b.matches(b"other",b"route",&[1;32],7),Err(Error::Binding));
  assert_eq!(b.matches(b"r",b"other",&[1;32],7),Err(Error::Binding));
  assert_eq!(b.matches(b"r",b"route",&[2;32],7),Err(Error::Binding));
  assert_eq!(b.matches(b"r",b"route",&[1;32],8),Err(Error::Binding));
 }
}
#[cfg(test)]mod pending_window_regression{
 use super::*;
 #[test]fn pending_cannot_extend_retained_window(){
  let mut w=Window::intersect((100,1000),(100,900),None,None).unwrap();
  w.restrict(150,200).unwrap();assert_eq!(w.expires,200);
  assert!(w.current(149).is_err());assert!(w.current(199).is_ok());assert!(w.current(200).is_err());
  w.restrict(0,800).unwrap();assert_eq!(w.expires,200);assert!(w.current(149).is_err());
  assert!(w.restrict(200,300).is_err());
 }
}

#[cfg(test)]mod directory_custody_delta_controls{
 use super::*;
 fn enrollment()->FirstEnrollment{serde_json::from_value(serde_json::json!({"version":1,"realm":"PUBLIC-realm","accountIssuer":"https://wallet-auth.ynxweb4.com","writerAuthority":"PUBLIC-writer","mode":"SINGLE_WRITER_FIRST_IDENTITY_SAME_DEVICE_DUAL_V1","replayAdmission":"FIRST_ACCOUNT_ORIGINS_DUAL_PROOFS_CHECKPOINT_V1","directorySchema":"YNX-SOCIAL-FIRST-DIRECTORY-V3","deployment":"PUBLIC-deployment","instance":"PUBLIC-instance","headerSHA256":"a".repeat(64),"route":"PUBLIC-route","finalization":"SAME_INODE_SINGLE_WRITER_SOURCE_EXPIRY_V1"})).unwrap()}
 fn policy(role:&str)->Issuance{serde_json::from_value(serde_json::json!({"version":1,"purpose":"SOURCE_PROOF_ARTIFACT_V1","role":role,"realm":"PUBLIC-realm","deployment":"PUBLIC-deployment","instance":"PUBLIC-instance","headerSHA256":"a".repeat(64),"keyAlias":"PUBLIC-key","storageGeneration":7,"notBeforeMS":10,"expiresMS":30})).unwrap()}
 #[test]fn original_directory_coordinates_match_without_authority_creation(){let e=enrollment();let i=policy("directory-checkpoint");assert!(i.holder_matches(&e,"issuer","PUBLIC-writer"));assert_eq!(i.holder_storage(),("PUBLIC-key",7,10,30));let a=policy("current-history");assert!(a.holder_matches(&e,"anchor","PUBLIC-independent-anchor"));}
 #[test]fn directory_policy_rejects_changed_coordinates_role_and_writer(){let e=enrollment();let i=policy("directory-checkpoint");assert!(!i.holder_matches(&e,"anchor","PUBLIC-writer"));assert!(!i.holder_matches(&e,"issuer","OTHER"));for n in 0..4{let mut changed=enrollment();match n{0=>changed.realm="OTHER".into(),1=>changed.deployment="OTHER".into(),2=>changed.instance="OTHER".into(),_=>changed.header="b".repeat(64)}assert!(!i.holder_matches(&changed,"issuer","PUBLIC-writer"));}}
 #[test]fn incomplete_enrollment_does_not_become_directory_custody(){let i=policy("directory-checkpoint");let mut e=enrollment();e.route.clear();assert!(!i.holder_matches(&e,"issuer","PUBLIC-writer"));assert!(!i.holder_matches(&enrollment(),"caller-choice","PUBLIC-writer"));}
}
