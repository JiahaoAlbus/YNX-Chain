//! Private Model A ownership adapter. Not an issuer or verified receipt factory.
//! No raw-pointer constructor. Missing genuine inputs/held projection stay closed.
use super::{Admission,Lease,Intent,VerifiedCommit,NativeIssuedResources,OK,REQUIRED,UNKNOWN};
use std::{cell::RefCell,convert::Infallible,marker::PhantomData,ptr::{self,NonNull},rc::Rc,thread::{self,ThreadId}};
macro_rules! opaque {($($name:ident),*)=>{$(#[repr(C)]struct $name{_opaque:[u8;0]})*};}
opaque!(Origin,Device,History,Original,Prepared,Guard,Pin,Once,ProtectedOutput,HeldProjection);
unsafe extern "C" {
 fn veil_private_prepare_accepted_inputs(a:*const Origin,d:*const Device,h:*const History,r:*const Original,o:*mut *mut Prepared)->i32;
 fn veil_private_prepared_input_retain(p:*const Prepared,o:*mut *mut Prepared)->i32;
 fn veil_private_prepared_input_borrow(p:*const Prepared,a:*mut *const Admission,l:*mut *const Lease,i:*mut *const Intent)->i32;
 fn veil_private_prepared_input_validate(g:*mut Guard,p:*mut Pin,o:*const Prepared)->i32;
 fn veil_private_prepared_input_drop(p:*mut *mut Prepared)->i32;
 fn ynx_source_client_prepared_acquire(p:*const Prepared,out:*mut *mut std::ffi::c_void)->i32;
 fn veil_private_verified_commit_retain(p:*const VerifiedCommit,o:*mut *mut VerifiedCommit)->i32;
 fn veil_private_verified_commit_borrow(p:*const VerifiedCommit,i:*mut *const Intent,a:*mut *const Once,o:*mut *const ProtectedOutput)->i32;
 fn veil_private_verified_commit_acknowledge(g:*mut Guard,p:*mut Pin,o:*const Prepared,c:*const VerifiedCommit)->i32;
 fn veil_private_verified_commit_recover(g:*mut Guard,p:*mut Pin,o:*const Prepared,c:*mut *mut VerifiedCommit)->i32;
 fn veil_private_verified_commit_drop(c:*mut *mut VerifiedCommit)->i32;
 fn veil_private_verified_commit_originals(c:*const VerifiedCommit,out:*mut FinalOriginalsRaw)->i32;
}
const MAX_REFS:usize=32;
#[derive(Debug,PartialEq,Eq)]pub(crate) enum Error{Required,Unknown,Thread,Association,Capacity,AbiInvariant,Foreign(i32)}
// These fields are NOT exposed. No normal or cfg(test) constructor exists.
// Infallible encodes the missing real accepted-owner projection, not a proof.
struct AcceptedInputs<'op>{
 origin:NonNull<Origin>,device:NonNull<Device>,history:NonNull<History>,selected:NonNull<Original>,
 original:&'op mut NativeIssuedResources,missing_accepted_projection:Infallible,
}
#[derive(Default)]struct Diagnostics{first:Option<i32>,unknown:bool,refs:usize,original_intent:Option<NonNull<Intent>>}
impl Diagnostics{
 fn observe(&mut self,s:i32){if s==UNKNOWN{self.unknown=true;}if s!=OK&&self.first.is_none(){self.first=Some(s);}}
 fn classify(&mut self,s:i32)->Result<(),Error>{self.observe(s);if self.unknown{return Err(Error::Unknown)}match s{OK=>Ok(()),REQUIRED=>Err(Error::Required),other=>Err(Error::Foreign(other))}}
 fn reserve(&mut self)->Result<(),Error>{if self.refs>=MAX_REFS{return Err(Error::Capacity)}self.refs+=1;Ok(())}
}
// Bounded shared diagnostics across retained refs; no permission bit.
#[derive(Clone)]enum PreparedOriginal<'op>{Issued(&'op NativeIssuedResources),QualifiedRoot(Rc<crate::source_infrastructure::platform::AcceptedOriginalBorrow<'op>>),Message(Rc<MessageOperationWindow>)}
impl PreparedOriginal<'_>{fn current(&self)->Result<(),Error>{match self{Self::Issued(_)=>Ok(()),Self::QualifiedRoot(root)=>root.current().map_err(|_|Error::Unknown),Self::Message(window)=>window.current()}}}
pub(crate) struct PreparedOwner<'op>{handle:Option<NonNull<Prepared>>,original:PreparedOriginal<'op>,thread:ThreadId,state:Rc<RefCell<Diagnostics>>}
pub(crate) struct CommitOwner<'prepared,'op>{handle:Option<NonNull<VerifiedCommit>>,prepared:&'prepared PreparedOwner<'op>,thread:ThreadId,state:Rc<RefCell<Diagnostics>>}
// The C producer owns genuine guard/pin internally. No safe projection is in
// the supplied ABI, so this exclusive borrowed form has NO constructor.
// It must eventually be supplied with exact same-held lifetime, not reacquire.
pub(crate) struct HeldOriginal<'held,'op>{prepared:&'held PreparedOwner<'op>,projection:Option<NonNull<HeldProjection>>,exclusive:PhantomData<&'held mut HeldProjection>}
struct HeldAcquireFailure<'held,'op>{error:Error,retained:Option<HeldOriginal<'held,'op>>}
unsafe extern "C" {
 fn veil_private_held_original_acquire(g:*mut Guard,p:*mut Pin,prepared:*const Prepared,out:*mut *mut HeldProjection)->i32;
 fn veil_private_held_original_validate(p:*const HeldProjection)->i32;
 fn veil_private_held_original_recover(p:*const HeldProjection,out:*mut *mut VerifiedCommit)->i32;
 fn veil_private_held_original_acknowledge(p:*const HeldProjection,commit:*const VerifiedCommit)->i32;
 fn veil_private_held_original_drop(p:*mut *mut HeldProjection)->i32;
}
// These private decoders preserve partial custody. They cannot issue accepted
// inputs, and never treat pointer presence as an authorization or terminal.
fn held_output<T>(s:i32,p:*mut T,state:&Rc<RefCell<Diagnostics>>)->(Result<(),Error>,Option<NonNull<T>>){
 let retained=NonNull::new(p);let mut d=state.borrow_mut();
 let mut result=d.classify(s);
 if s==OK&&retained.is_none(){d.observe(UNKNOWN);result=Err(Error::AbiInvariant);}
 (result,retained)
}
fn held_drop_disposition<T>(s:i32,original:*mut T,returned:*mut T,state:&Rc<RefCell<Diagnostics>>)->Result<(),Error>{
 let mut d=state.borrow_mut();d.observe(s);
 // Cleanup success does not clear a previously uncertain permission.
 if s==OK&&returned.is_null(){return Ok(())}
 if returned!=original{d.observe(UNKNOWN);return Err(Error::AbiInvariant)}
 if s==OK{d.observe(UNKNOWN);return Err(Error::Unknown)}
 d.classify(s)
}
struct BorrowedCapabilities<'owner>{admission:NonNull<Admission>,lease:NonNull<Lease>,intent:NonNull<Intent>,owner:PhantomData<&'owner Prepared>}
struct BorrowedResult<'owner>{intent:NonNull<Intent>,once:NonNull<Once>,output:NonNull<ProtectedOutput>,owner:PhantomData<&'owner VerifiedCommit>}
fn owner_thread(t:ThreadId)->Result<(),Error>{if t==thread::current().id(){Ok(())}else{Err(Error::Thread)}}
// Exact contract: errors do not transfer output refs. An unexpected non-null
// error output cannot be disposed by an invented destructor/custody protocol.
// Fail-stop preserves the violation instead of silently losing sole custody.
fn output<T>(s:i32,p:*mut T,state:&Rc<RefCell<Diagnostics>>)->Result<NonNull<T>,Error>{
 if s!=OK&&!p.is_null(){state.borrow_mut().observe(s);std::process::abort();}
 // A successful owning RAM transfer MUST survive existing logical UNKNOWN.
 // Owning a ref never clears uncertainty or grants delivery/authorization.
 state.borrow_mut().observe(s);
 if s!=OK{state.borrow_mut().classify(s)?;}
 match NonNull::new(p){Some(p)=>Ok(p),None=>{state.borrow_mut().unknown=true;Err(Error::AbiInvariant)}}
}
// Exact drop slot contract; no dereference, destructor or ownership guessing.
// The caller changes its stored handle/ref count ONLY after OK/null returns.
fn drop_disposition<T>(s:i32,original:*mut T,returned:*mut T,state:&Rc<RefCell<Diagnostics>>)->Result<(),Error>{
 state.borrow_mut().observe(s);
 if (s==OK&&!returned.is_null())||(s!=OK&&returned!=original){
  state.borrow_mut().unknown=true;
  #[cfg(test)]if std::env::var_os("R29_DROP_CHILD").is_some(){
   assert!(state.borrow().unknown);
   eprintln!("R29_UNKNOWN_LATCHED_BEFORE_ABORT");
  }
  std::process::abort();
 }
 if s!=OK{return state.borrow_mut().classify(s)}
 Ok(())
}

impl<'op> AcceptedInputs<'op>{
 fn prepare(&self)->Result<PreparedOwner<'_>,Error>{
  // Allocated BEFORE native preparation; local reference budget is ownership,
  // not an accepted-origin/device/history authority or whole-actor budget.
  let state=Rc::new(RefCell::new(Diagnostics{refs:1,..Diagnostics::default()}));
  let mut p=ptr::null_mut();
  let s=unsafe{veil_private_prepare_accepted_inputs(self.origin.as_ptr(),self.device.as_ptr(),self.history.as_ptr(),self.selected.as_ptr(),&mut p)};
  let handle=output(s,p,&state)?;
  Ok(PreparedOwner{handle:Some(handle),original:PreparedOriginal::Issued(self.original),thread:thread::current().id(),state})
 }
}
impl<'op> PreparedOwner<'op>{
 pub(crate)fn from_original_root(root:crate::source_infrastructure::platform::AcceptedOriginalBorrow<'op>)->Result<Self,Error>{
  root.current().map_err(|_|Error::Unknown)?;let [a,d,h,r]=root.projection().map_err(|_|Error::Unknown)?;
  let state=Rc::new(RefCell::new(Diagnostics{refs:1,..Diagnostics::default()}));let mut p=ptr::null_mut();
  let s=unsafe{veil_private_prepare_accepted_inputs(a.cast(),d.cast(),h.cast(),r.cast(),&mut p)};
  let handle=output(s,p,&state)?;
  // C preparation independently retained this same qualified root; the Rust
  // exclusive borrowed root also remains alive through every prepared ref.
  let owner=Self{handle:Some(handle),original:PreparedOriginal::QualifiedRoot(Rc::new(root)),thread:thread::current().id(),state};
  if owner.original.current().is_err(){owner.state.borrow_mut().observe(UNKNOWN);}Ok(owner)
 }
 fn associate_intent(&self,i:*const Intent)->Result<(),Error>{
  self.original.current()?;let intent=NonNull::new(i.cast_mut()).ok_or(Error::AbiInvariant)?;
  match &self.original{PreparedOriginal::Issued(original)=>if i!=original.intent{return Err(Error::Association)},PreparedOriginal::QualifiedRoot(_)|PreparedOriginal::Message(_)=>{}}
  let mut d=self.state.borrow_mut();if let Some(previous)=d.original_intent{if previous!=intent{return Err(Error::Association)}}else{d.original_intent=Some(intent);}Ok(())
 }

 // Private FFI projection of THIS actual prepared owner, not an owning raw
 // constructor. Only the typed platform bridge consumes the returned status/
 // partial output; platform producer must authenticate retained private inputs.
 pub(crate)fn platform_acquire_private(&mut self,out:&mut *mut std::ffi::c_void)->Result<i32,Error>{
  if !out.is_null(){return Err(Error::AbiInvariant)}
  let source=self.ptr()?;
  let s=unsafe{ynx_source_client_prepared_acquire(source,out)};
  self.state.borrow_mut().observe(s);Ok(s)
 }
 fn ptr(&self)->Result<*mut Prepared,Error>{owner_thread(self.thread)?;self.handle.map(|p|p.as_ptr()).ok_or(Error::AbiInvariant)}
 fn retain(&self)->Result<Self,Error>{
  let source=self.ptr()?;self.state.borrow_mut().reserve()?;let mut p=ptr::null_mut();
  let s=unsafe{veil_private_prepared_input_retain(source,&mut p)};
  let handle=match output(s,p,&self.state){Ok(p)=>p,Err(e)=>{self.state.borrow_mut().refs-=1;return Err(e)}};
  Ok(Self{handle:Some(handle),original:self.original.clone(),thread:self.thread,state:Rc::clone(&self.state)})
 }
 fn borrow(&mut self)->Result<BorrowedCapabilities<'_>,Error>{
  let source=self.ptr()?;let(mut a,mut l,mut i)=(ptr::null(),ptr::null(),ptr::null());
  let s=unsafe{veil_private_prepared_input_borrow(source,&mut a,&mut l,&mut i)};self.state.borrow_mut().classify(s)?;
  // Identity comparison is ONLY structural association; no pointer mints trust.
  self.associate_intent(i)?;
  Ok(BorrowedCapabilities{admission:NonNull::new(a.cast_mut()).ok_or(Error::AbiInvariant)?,lease:NonNull::new(l.cast_mut()).ok_or(Error::AbiInvariant)?,intent:NonNull::new(i.cast_mut()).ok_or(Error::AbiInvariant)?,owner:PhantomData})
 }
 // Explicit caller-visible disposal of THIS initial Prepared owning ref.
 // Additional native/store borrows must be closed and dropped first. Exact
 // failed custody/UNKNOWN and live-handle Drop fail-stop remain unchanged.
 pub(crate)fn release(&mut self)->Result<(),Error>{self.try_drop()}
 fn try_drop(&mut self)->Result<(),Error>{
  let original=self.ptr()?;let mut p=original;let s=unsafe{veil_private_prepared_input_drop(&mut p)};
  drop_disposition(s,original,p,&self.state)?;
  self.handle=None;self.state.borrow_mut().refs-=1;
  // Successful RAM disposal does not clear sticky UNKNOWN or durable history.
  Ok(())
 }
}
impl<'held,'op> HeldOriginal<'held,'op>{
 // Module-private normal producer seam. Raw guard/pin never come from JNI,
 // public tokens or metadata; C rechecks the actual owners before retaining.
 fn acquire(guard:NonNull<Guard>,pin:NonNull<Pin>,prepared:&'held PreparedOwner<'op>)->Result<Self,HeldAcquireFailure<'held,'op>>{
  let raw=prepared.ptr().map_err(|error|HeldAcquireFailure{error,retained:None})?;
  prepared.state.borrow_mut().reserve().map_err(|error|HeldAcquireFailure{error,retained:None})?;
  let mut out=ptr::null_mut();
  let s=unsafe{veil_private_held_original_acquire(guard.as_ptr(),pin.as_ptr(),raw,&mut out)};
  let (result,projection)=held_output(s,out,&prepared.state);
  let retained=projection.map(|p|Self{prepared,projection:Some(p),exclusive:PhantomData});
  if retained.is_none(){prepared.state.borrow_mut().refs-=1;}
  match (result,retained){
   (Ok(()),Some(owner))=>Ok(owner),
   (Err(error),retained)=>Err(HeldAcquireFailure{error,retained}),
   (Ok(()),None)=>Err(HeldAcquireFailure{error:Error::AbiInvariant,retained:None}),
  }
 }
 fn try_drop(&mut self)->Result<(),Error>{
  owner_thread(self.prepared.thread)?;
  let Some(original)=self.projection else{return Ok(())};
  let mut returned=original.as_ptr();
  let s=unsafe{veil_private_held_original_drop(&mut returned)};
  held_drop_disposition(s,original.as_ptr(),returned,&self.prepared.state)?;
  self.projection=None;self.prepared.state.borrow_mut().refs-=1;Ok(())
 }
 pub(crate) fn validate(&mut self)->Result<(),Error>{
  owner_thread(self.prepared.thread)?;
  let projection=self.projection.ok_or(Error::Required)?;
  let s=unsafe{veil_private_held_original_validate(projection.as_ptr())};
  self.prepared.state.borrow_mut().classify(s)?;
  self.prepared.ptr()?;Ok(())
 }
 pub(crate) fn recover(&mut self)->Result<CommitOwner<'held,'op>,Error>{
  self.validate()?;let projection=self.projection.ok_or(Error::Required)?;
  self.prepared.state.borrow_mut().reserve()?;let mut c=ptr::null_mut();
  let s=unsafe{veil_private_held_original_recover(projection.as_ptr(),&mut c)};
  let handle=match output(s,c,&self.prepared.state){Ok(c)=>c,Err(e)=>{self.prepared.state.borrow_mut().refs-=1;return Err(e)}};
  Ok(CommitOwner{handle:Some(handle),prepared:self.prepared,thread:self.prepared.thread,state:Rc::clone(&self.prepared.state)})
 }
}
// No implicit supplier retry after failed explicit cleanup. Retained custody
// must be explicitly discharged; otherwise fail-stop rather than abandon it.
impl Drop for HeldOriginal<'_,'_>{fn drop(&mut self){if self.projection.is_some(){std::process::abort();}}}

#[cfg(test)]mod held_projection_controls{
 use super::*;
 #[test]fn held_projection_error_retains_nonnull_without_abort(){
  for s in [REQUIRED,UNKNOWN,17]{
   let state=Rc::new(RefCell::new(Diagnostics::default()));
   // A pointer-shape control only, never dereferenced or promoted to an owner.
   let raw=NonNull::<u8>::dangling().as_ptr();
   let (result,retained)=held_output(s,raw,&state);
   assert!(result.is_err());assert_eq!(retained.unwrap().as_ptr(),raw);
   assert_eq!(state.borrow().first,Some(s));
  }
 }
 #[test]fn held_projection_success_without_owner_is_not_admission(){
  let state=Rc::new(RefCell::new(Diagnostics::default()));
  let (result,retained)=held_output(OK,ptr::null_mut::<u8>(),&state);
  assert_eq!(result,Err(Error::AbiInvariant));assert!(retained.is_none());assert!(state.borrow().unknown);
 }
 #[test]fn held_projection_drop_failure_preserves_custody_and_first_cause(){
  let state=Rc::new(RefCell::new(Diagnostics::default()));
  let raw=NonNull::<u8>::dangling().as_ptr();
  assert_eq!(held_drop_disposition(UNKNOWN,raw,raw,&state),Err(Error::Unknown));
  assert_eq!(state.borrow().first,Some(UNKNOWN));
  assert_eq!(held_drop_disposition(OK,raw,ptr::null_mut(),&state),Ok(()));
  assert!(state.borrow().unknown);assert_eq!(state.borrow().first,Some(UNKNOWN));
 }
 #[test]fn held_projection_drop_ok_with_retained_pointer_latches_unknown(){
  let state=Rc::new(RefCell::new(Diagnostics::default()));
  let raw=NonNull::<u8>::dangling().as_ptr();
  assert_eq!(held_drop_disposition(OK,raw,raw,&state),Err(Error::Unknown));assert!(state.borrow().unknown);
 }
}
impl<'prepared,'op> CommitOwner<'prepared,'op>{
 fn ptr(&self)->Result<*mut VerifiedCommit,Error>{owner_thread(self.thread)?;self.handle.map(|c|c.as_ptr()).ok_or(Error::AbiInvariant)}
 fn retain(&self)->Result<Self,Error>{
  let source=self.ptr()?;self.state.borrow_mut().reserve()?;let mut c=ptr::null_mut();let s=unsafe{veil_private_verified_commit_retain(source,&mut c)};
  let handle=match output(s,c,&self.state){Ok(c)=>c,Err(e)=>{self.state.borrow_mut().refs-=1;return Err(e)}};
  Ok(Self{handle:Some(handle),prepared:self.prepared,thread:self.thread,state:Rc::clone(&self.state)})
 }
 fn borrow(&mut self)->Result<BorrowedResult<'_>,Error>{
  let source=self.ptr()?;let(mut i,mut a,mut o)=(ptr::null(),ptr::null(),ptr::null());
  let s=unsafe{veil_private_verified_commit_borrow(source,&mut i,&mut a,&mut o)};self.state.borrow_mut().classify(s)?;
  self.prepared.associate_intent(i)?;
  Ok(BorrowedResult{intent:NonNull::new(i.cast_mut()).ok_or(Error::AbiInvariant)?,once:NonNull::new(a.cast_mut()).ok_or(Error::AbiInvariant)?,output:NonNull::new(o.cast_mut()).ok_or(Error::AbiInvariant)?,owner:PhantomData})
 }
 pub(crate) fn acknowledge(&mut self,held:&mut HeldOriginal<'_,'op>)->Result<(),Error>{
  if !Rc::ptr_eq(&self.state,&held.prepared.state)||self.prepared.handle!=held.prepared.handle{return Err(Error::Association)}
  let commit=self.ptr()?;held.validate()?;
  let projection=held.projection.ok_or(Error::Required)?;
  let s=unsafe{veil_private_held_original_acknowledge(projection.as_ptr(),commit)};
  self.state.borrow_mut().classify(s)
 }
 fn try_drop(&mut self)->Result<(),Error>{
  let original=self.ptr()?;let mut c=original;let s=unsafe{veil_private_verified_commit_drop(&mut c)};
  drop_disposition(s,original,c,&self.state)?;self.handle=None;self.state.borrow_mut().refs-=1;Ok(())
 }
}
// Explicit same-actor disposal only; never silently drop a refused owning ref.
// Fail-stop is RAM containment, NOT durable process recovery or authorization.
impl Drop for PreparedOwner<'_>{fn drop(&mut self){if self.handle.is_some(){std::process::abort();}}}
impl Drop for CommitOwner<'_,'_>{fn drop(&mut self){if self.handle.is_some(){std::process::abort();}}}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn r28_model_a_normal_preparation_retain_borrow_required(){unsafe{
  let mut p=ptr::null_mut();assert_eq!(veil_private_prepare_accepted_inputs(ptr::null(),ptr::null(),ptr::null(),ptr::null(),&mut p),REQUIRED);assert!(p.is_null());
  assert_eq!(veil_private_prepared_input_retain(ptr::null(),&mut p),REQUIRED);assert!(p.is_null());
  let(mut a,mut l,mut i)=(ptr::null(),ptr::null(),ptr::null());assert_eq!(veil_private_prepared_input_borrow(ptr::null(),&mut a,&mut l,&mut i),REQUIRED);assert!(a.is_null()&&l.is_null()&&i.is_null());
 }}
 #[test]fn r28_model_a_normal_same_held_ports_unissued_required(){unsafe{
  assert_eq!(veil_private_prepared_input_validate(ptr::null_mut(),ptr::null_mut(),ptr::null()),REQUIRED);
  let mut c=ptr::null_mut();assert_eq!(veil_private_verified_commit_recover(ptr::null_mut(),ptr::null_mut(),ptr::null(),&mut c),REQUIRED);assert!(c.is_null());
  assert_eq!(veil_private_verified_commit_acknowledge(ptr::null_mut(),ptr::null_mut(),ptr::null(),ptr::null()),REQUIRED);
 }}
 #[test]fn r28_model_a_normal_commit_retain_borrow_required(){unsafe{
  let mut c=ptr::null_mut();assert_eq!(veil_private_verified_commit_retain(ptr::null(),&mut c),REQUIRED);assert!(c.is_null());
  let(mut i,mut a,mut o)=(ptr::null(),ptr::null(),ptr::null());assert_eq!(veil_private_verified_commit_borrow(ptr::null(),&mut i,&mut a,&mut o),REQUIRED);assert!(i.is_null()&&a.is_null()&&o.is_null());
 }}
 #[test]fn r28_model_a_normal_null_disposal_not_once_receipt(){unsafe{
  let mut p=ptr::null_mut();let mut c=ptr::null_mut();assert_eq!(veil_private_prepared_input_drop(&mut p),OK);assert_eq!(veil_private_verified_commit_drop(&mut c),OK);assert!(p.is_null()&&c.is_null());
  assert_eq!(veil_private_prepared_input_drop(ptr::null_mut()),2);assert_eq!(veil_private_verified_commit_drop(ptr::null_mut()),2);
 }}
 #[test]fn r28_model_a_diagnostics_bound_and_uncertainty_not_authority(){
  let mut d=Diagnostics::default();assert_eq!(d.classify(3),Err(Error::Foreign(3)));assert_eq!(d.classify(UNKNOWN),Err(Error::Unknown));assert_eq!(d.classify(OK),Err(Error::Unknown));assert_eq!(d.first,Some(3));
  for _ in 0..MAX_REFS{assert_eq!(d.reserve(),Ok(()));}assert_eq!(d.reserve(),Err(Error::Capacity));assert_eq!(d.refs,MAX_REFS);
 }
 #[test]fn r28_model_a_public_dummy_ownership_survives_unknown(){
  // Generic public byte only: not a C owner, issuer, guard or test grant.
  let state=Rc::new(RefCell::new(Diagnostics{first:Some(3),unknown:true,refs:1,..Diagnostics::default()}));
  let mut byte=7u8;let p=&mut byte as *mut u8;assert_eq!(output(OK,p,&state),Ok(NonNull::new(p).unwrap()));
  assert!(state.borrow().unknown);assert_eq!(state.borrow().first,Some(3));
  assert_eq!(state.borrow_mut().classify(OK),Err(Error::Unknown));
 }
}

#[cfg(test)]#[path="model_a_owner/drop_slot_controls.rs"]mod drop_slot_controls;

// True C-owned retained Prepared root, never a unit provenance marker. The
// constructor below exclusively retains an already actual qualified owner.
pub(super)struct NativeResourceProof{handle:Option<NonNull<Prepared>>,thread:ThreadId,unknown:bool}
impl NativeResourceProof{
 pub(super)fn current(&mut self)->Result<(),Error>{
  owner_thread(self.thread)?;if self.unknown{return Err(Error::Unknown)}let p=self.handle.ok_or(Error::Required)?;
  let(mut a,mut l,mut i)=(ptr::null(),ptr::null(),ptr::null());let s=unsafe{veil_private_prepared_input_borrow(p.as_ptr(),&mut a,&mut l,&mut i)};
  if s!=OK||a.is_null()||l.is_null()||i.is_null(){self.unknown=true;return Err(Error::Unknown)}Ok(())
 }
 pub(in crate::staging::platform)fn close(&mut self)->Result<(),Error>{
  owner_thread(self.thread)?;let Some(original)=self.handle else{return Ok(())};let mut p=original.as_ptr();let s=unsafe{veil_private_prepared_input_drop(&mut p)};
  if s==OK&&p.is_null(){self.handle=None;return Ok(())}if p!=original.as_ptr(){std::process::abort();}self.unknown=true;Err(Error::Unknown)
 }
}
impl Drop for NativeResourceProof{fn drop(&mut self){if self.handle.is_some(){std::process::abort();}}}
pub(super)struct NativeResourceInputs<'prepared,'op>{pub(super)proof:NativeResourceProof,pub(super)prepared:&'prepared PreparedOwner<'op>,pub(super)admission:*const Admission,pub(super)lease:*const Lease,pub(super)intent:*const Intent,pub(super)plan:crate::source_infrastructure::platform::NativePlan}

pub(super)struct NativeResourceInputFailure<'prepared,'op>{pub(super)error:Error,pub(super)retained:Option<NativeResourceInputs<'prepared,'op>>}
impl<'op>PreparedOwner<'op>{
 pub(super)fn native_resource_inputs(&mut self)->Result<NativeResourceInputs<'_,'op>,NativeResourceInputFailure<'_,'op>>{
  fn rejected<'p,'o>(error:Error)->NativeResourceInputFailure<'p,'o>{NativeResourceInputFailure{error,retained:None}}
  self.original.current().map_err(rejected)?;
  let plan=match &self.original{PreparedOriginal::QualifiedRoot(root)=>root.native_plan().map_err(|_|rejected(Error::Unknown))?,PreparedOriginal::Message(_)=>self.message_native_plan().map_err(rejected)?,PreparedOriginal::Issued(_)=>return Err(rejected(Error::Required))};
  let caps=self.borrow().map_err(rejected)?;let (admission,lease,intent)=(caps.admission.as_ptr().cast_const(),caps.lease.as_ptr().cast_const(),caps.intent.as_ptr().cast_const());
  if plan.intent!=intent.cast(){return Err(rejected(Error::Association))}
  self.original.current().map_err(rejected)?;let p=self.ptr().map_err(rejected)?;let mut retained=ptr::null_mut();let s=unsafe{veil_private_prepared_input_retain(p,&mut retained)};
  let retained=output(s,retained,&self.state).map_err(rejected)?;
  let proof=NativeResourceProof{handle:Some(retained),thread:self.thread,unknown:false};
  let mut inputs=NativeResourceInputs{proof,prepared:self,admission,lease,intent,plan};
  if let Err(error)=inputs.current(){return Err(NativeResourceInputFailure{error,retained:Some(inputs)})}Ok(inputs)
 }
 pub(super)fn original_current(&self)->Result<(),Error>{self.original.current()?;if matches!(self.original,PreparedOriginal::Message(_)){let p=self.ptr()?;let s=unsafe{veil_private_message_operation_current(p)};self.state.borrow_mut().classify(s)?;}Ok(())}
 pub(super)fn enter_original(&self)->Result<(),Error>{self.original_current()?;match &self.original{PreparedOriginal::QualifiedRoot(root)=>root.enter().map_err(|_|Error::Unknown),PreparedOriginal::Message(_)=>{let p=self.ptr()?;self.state.borrow_mut().classify(unsafe{veil_private_message_operation_enter(p)})},PreparedOriginal::Issued(_)=>Err(Error::Required)}}
}
impl NativeResourceInputs<'_,'_>{
 pub(super)fn current(&mut self)->Result<(),Error>{self.prepared.original_current()?;self.proof.current()?;self.prepared.original_current()}
 pub(in crate::staging::platform)fn close(&mut self)->Result<(),Error>{self.proof.close()}
}


impl PreparedOwner<'_>{
 // Only THIS retained Prepared may acquire a snapshot from its SAME original.
 // Partial output remains caller-owned on late failure; never erased here.
 pub(super)fn acquire_original_snapshot(&self,out:&mut *mut std::ffi::c_void)->Result<i32,Error>{
  self.original.current()?;let prepared=self.ptr()?;
  match &self.original{PreparedOriginal::QualifiedRoot(root)=>{
   let s=root.acquire_snapshot_for_prepared(prepared.cast(),out).map_err(|_|Error::Unknown)?;
   self.state.borrow_mut().observe(s);Ok(s)
  },PreparedOriginal::Message(_)=>{let p=self.ptr()?;let s=unsafe{veil_private_message_operation_snapshot(p,out)};self.state.borrow_mut().observe(s);Ok(s)},PreparedOriginal::Issued(_)=>Err(Error::Required)}
 }
}

// Owning final RAM root returned only by the actual linked terminal producer.
// It independently retains origin/output; no lifetime extension of Prepared.
// Adoption preserves custody and does NOT produce the verified proof. Every
// proof use first borrows the genuine C final owner/current fence.
pub(crate)struct FinalOwner{handle:Option<NonNull<VerifiedCommit>>,intent:NonNull<Intent>,thread:ThreadId,state:Rc<RefCell<Diagnostics>>}
impl FinalOwner{
 pub(in crate::staging::platform)fn adopt_published(raw:NonNull<VerifiedCommit>,intent:NonNull<Intent>)->Self{Self{handle:Some(raw),intent,thread:thread::current().id(),state:Rc::new(RefCell::new(Diagnostics{refs:1,..Diagnostics::default()}))}}
 pub(in crate::staging::platform)fn current(&self)->Result<(),Error>{
  owner_thread(self.thread)?;if self.state.borrow().unknown{return Err(Error::Unknown)}let h=self.handle.ok_or(Error::AbiInvariant)?;
  let(mut i,mut a,mut o)=(ptr::null(),ptr::null(),ptr::null());let s=unsafe{veil_private_verified_commit_borrow(h.as_ptr(),&mut i,&mut a,&mut o)};
  self.state.borrow_mut().classify(s)?;
  if i!=self.intent.as_ptr()||a.is_null()||o.is_null(){self.state.borrow_mut().observe(UNKNOWN);return Err(Error::Unknown)}Ok(())
 }
 // Explicit native reference transfer, not qualification from Rc identity.
 // Late refusal returns the newly acquired owner for mandatory cleanup.
 pub(crate)fn retain_final_root(&self)->Result<Self,(Error,Option<Self>)>{
  self.current().map_err(|e|(e,None))?;
  let source=self.handle.ok_or((Error::AbiInvariant,None))?;
  self.state.borrow_mut().reserve().map_err(|e|(e,None))?;
  let mut raw=ptr::null_mut();let status=unsafe{veil_private_verified_commit_retain(source.as_ptr(),&mut raw)};
  let handle=match output(status,raw,&self.state){Ok(h)=>h,Err(e)=>{self.state.borrow_mut().refs-=1;return Err((e,None))}};
  let retained=Self{handle:Some(handle),intent:self.intent,thread:self.thread,state:Rc::clone(&self.state)};
  match retained.current().and_then(|_|self.current()){Ok(())=>Ok(retained),Err(e)=>Err((e,Some(retained)))}
 }
 pub(in crate::staging::platform)fn close(&mut self)->Result<(),Error>{
  owner_thread(self.thread)?;let Some(original)=self.handle else{return Ok(())};let mut returned=original.as_ptr();let s=unsafe{veil_private_verified_commit_drop(&mut returned)};
  drop_disposition(s,original.as_ptr(),returned,&self.state)?;self.handle=None;self.state.borrow_mut().refs-=1;Ok(())
 }
}
impl Drop for FinalOwner{fn drop(&mut self){if self.handle.is_some(){std::process::abort();}}}

#[repr(C)]#[derive(Clone,Copy)]struct FinalOriginalBytes{data:*const u8,size:usize}
#[repr(C)]struct FinalOriginalsRaw{
 version:u32,engine_issuer:FinalOriginalBytes,engine_anchor:FinalOriginalBytes,checkpoint_anchor:FinalOriginalBytes,terminal_issuer:FinalOriginalBytes,terminal_anchor:FinalOriginalBytes,
 checkpoint_predecessors:*const FinalOriginalBytes,checkpoint_count:usize,
 terminal_issuer_predecessors:*const FinalOriginalBytes,terminal_issuer_count:usize,
 terminal_anchor_predecessors:*const FinalOriginalBytes,terminal_anchor_count:usize,
}
impl FinalOwner{
 pub(crate)fn with_independent_originals<R>(&self,run:impl for<'a>FnOnce(&crate::message_evidence::IndependentCommitOriginals<'a>)->R)->Result<R,(Error,Option<R>)>{
  self.current().map_err(|e|(e,None))?;let handle=self.handle.ok_or((Error::AbiInvariant,None))?;
  let mut raw:FinalOriginalsRaw=unsafe{std::mem::zeroed()};
  let status=unsafe{veil_private_verified_commit_originals(handle.as_ptr(),&mut raw)};
  self.state.borrow_mut().classify(status).map_err(|e|(e,None))?;
  let material=(||{
   if raw.version!=1||raw.checkpoint_count>255||raw.terminal_issuer_count>255||raw.terminal_anchor_count!=raw.terminal_issuer_count{return Err(Error::Association)}
   let mut total=0usize;
   let mut copy=|b:FinalOriginalBytes|->Result<zeroize::Zeroizing<Vec<u8>>,Error>{
    if b.data.is_null()||b.size==0||b.size>65536{return Err(Error::Capacity)}total=total.checked_add(b.size).ok_or(Error::Capacity)?;if total>393216{return Err(Error::Capacity)}
    let mut v=zeroize::Zeroizing::new(Vec::new());v.try_reserve_exact(b.size).map_err(|_|Error::Capacity)?;v.extend_from_slice(unsafe{std::slice::from_raw_parts(b.data,b.size)});Ok(v)
   };
   let ei=copy(raw.engine_issuer)?;let ea=copy(raw.engine_anchor)?;let cp=copy(raw.checkpoint_anchor)?;let ti=copy(raw.terminal_issuer)?;let ta=copy(raw.terminal_anchor)?;
   let mut history=|p:*const FinalOriginalBytes,n:usize|->Result<Vec<zeroize::Zeroizing<Vec<u8>>>,Error>{
    if n>255{return Err(Error::Capacity)}if n==0{return Ok(Vec::new())}if p.is_null()||(p as usize)%std::mem::align_of::<FinalOriginalBytes>()!=0{return Err(Error::AbiInvariant)}
    let mut out=Vec::new();out.try_reserve_exact(n).map_err(|_|Error::Capacity)?;
    for b in unsafe{std::slice::from_raw_parts(p,n)}{out.push(copy(*b)?)}Ok(out)
   };
   let ch=history(raw.checkpoint_predecessors,raw.checkpoint_count)?;let ih=history(raw.terminal_issuer_predecessors,raw.terminal_issuer_count)?;let ah=history(raw.terminal_anchor_predecessors,raw.terminal_anchor_count)?;
   Ok::<_,Error>((ei,ea,cp,ti,ta,ch,ih,ah))
  })().map_err(|e|{self.state.borrow_mut().observe(UNKNOWN);(e,None)})?;
  self.current().map_err(|e|(e,None))?;
  let(ei,ea,cp,ti,ta,ch,ih,ah)=material;
  let cb:Vec<&[u8]>=ch.iter().map(|b|b.as_slice()).collect();let ib:Vec<&[u8]>=ih.iter().map(|b|b.as_slice()).collect();let ab:Vec<&[u8]>=ah.iter().map(|b|b.as_slice()).collect();
  let originals=crate::message_evidence::IndependentCommitOriginals{engine_issuer:&ei,engine_anchor:&ea,checkpoint_anchor:&cp,terminal_issuer:&ti,terminal_anchor:&ta,checkpoint_predecessors:&cb,terminal_issuer_predecessors:&ib,terminal_anchor_predecessors:&ab};
  let result=run(&originals);match self.current(){Ok(())=>Ok(result),Err(e)=>Err((e,Some(result)))}
 }
}

#[repr(C)]struct DeviceOriginalInputRaw{version:u32,final_original:FinalOriginalBytes,current:FinalOriginalBytes,terminal:FinalOriginalBytes,checkpoint:FinalOriginalBytes,predecessors:*const FinalOriginalBytes,predecessor_count:usize}
unsafe extern "C"{fn veil_private_verified_commit_device_current(c:*const VerifiedCommit,i:*const DeviceOriginalInputRaw)->i32;}
// Persistent device custody derives from an ACTUAL independently retained final
// root and verified originals. Rc/bytes/status never independently inhabit it.

struct RestoredDeviceRoot{handle:Option<NonNull<VerifiedCommit>>,thread:ThreadId,state:Rc<RefCell<Diagnostics>>}
impl RestoredDeviceRoot{
 fn current(&self)->Result<(),Error>{
  owner_thread(self.thread)?;if self.state.borrow().unknown{return Err(Error::Unknown)}
  let h=self.handle.ok_or(Error::AbiInvariant)?;let(mut i,mut a,mut o)=(ptr::null(),ptr::null(),ptr::null());
  let s=unsafe{veil_private_verified_commit_borrow(h.as_ptr(),&mut i,&mut a,&mut o)};
  self.state.borrow_mut().classify(s)?;if i.is_null()||a.is_null()||o.is_null(){self.state.borrow_mut().observe(UNKNOWN);return Err(Error::Unknown)}Ok(())
 }
 fn close(&mut self)->Result<(),Error>{
  owner_thread(self.thread)?;let Some(h)=self.handle else{return Ok(())};let mut returned=h.as_ptr();let s=unsafe{veil_private_verified_commit_drop(&mut returned)};
  drop_disposition(s,h.as_ptr(),returned,&self.state)?;self.handle=None;self.state.borrow_mut().refs-=1;Ok(())
 }
}
impl Drop for RestoredDeviceRoot{fn drop(&mut self){if self.handle.is_some(){std::process::abort()}}}
enum DeviceOwnerRoot{Final(FinalOwner),Restored(RestoredDeviceRoot)}
impl DeviceOwnerRoot{
 fn current(&self)->Result<(),Error>{match self{Self::Final(r)=>r.current(),Self::Restored(r)=>r.current()}}
 fn handle(&self)->Result<NonNull<VerifiedCommit>,Error>{match self{Self::Final(r)=>r.handle,Self::Restored(r)=>r.handle}.ok_or(Error::AbiInvariant)}
 fn classify(&self,s:i32)->Result<(),Error>{match self{Self::Final(r)=>r.state.borrow_mut().classify(s),Self::Restored(r)=>r.state.borrow_mut().classify(s)}}
 fn close(&mut self)->Result<(),Error>{match self{Self::Final(r)=>r.close(),Self::Restored(r)=>r.close()}}
}
unsafe extern "C"{fn veil_private_verified_commit_restore_device(i:*const DeviceOriginalInputRaw,c:*const u8,cn:usize,p:*const u8,pn:usize,out:*mut *mut VerifiedCommit)->i32;}
fn with_device_input<R>(records:&crate::message_evidence::OriginalDeviceRecords,f:impl FnOnce(&DeviceOriginalInputRaw)->R)->Result<R,Error>{
 records.with_original_parts(|a,b,c,d,p|{
  let bytes=|s:&[u8]|FinalOriginalBytes{data:s.as_ptr(),size:s.len()};
  let mut history=Vec::new();history.try_reserve_exact(p.len()).map_err(|_|Error::Capacity)?;
  for raw in p{history.push(bytes(raw));}
  let input=DeviceOriginalInputRaw{version:1,final_original:bytes(a),current:bytes(b),terminal:bytes(c),checkpoint:bytes(d),predecessors:if history.is_empty(){ptr::null()}else{history.as_ptr()},predecessor_count:history.len()};
  Ok(f(&input))
 })
}
pub(crate)struct AcceptedDeviceOwner{root:DeviceOwnerRoot,records:crate::message_evidence::OriginalDeviceRecords}
impl AcceptedDeviceOwner{
 pub(crate)fn acquire(root:&FinalOwner,evidence:&crate::message_evidence::UnadmittedDeviceEvidence<'_>)->Result<Self,(Error,Option<Self>)>{
  let records=evidence.retain_original_records().map_err(|_|(Error::Association,None))?;
  let root=match root.retain_final_root(){Ok(r)=>r,Err((e,None))=>return Err((e,None)),Err((e,Some(root)))=>return Err((e,Some(Self{root:DeviceOwnerRoot::Final(root),records})))};
  let owner=Self{root:DeviceOwnerRoot::Final(root),records};match owner.current(){Ok(())=>Ok(owner),Err(e)=>Err((e,Some(owner)))}
 }
 // Native-authenticated public device keys are lent by actual recovery custody,
 // never JNI arguments. The static protected provider selects/verifies its own
 // admitted Root and independent historical terminal/latest head/floor.
 pub(crate)fn restore(records:crate::message_evidence::OriginalDeviceRecords,classic:&[u8;33],pq:&[u8;2592])->Result<Self,(Error,Option<Self>)>{
  let mut raw=ptr::null_mut();let status=with_device_input(&records,|input|unsafe{veil_private_verified_commit_restore_device(input,classic.as_ptr(),classic.len(),pq.as_ptr(),pq.len(),&mut raw)}).map_err(|e|(e,None))?;
  let state=Rc::new(RefCell::new(Diagnostics{refs:1,..Diagnostics::default()}));
  let handle=output(status,raw,&state).map_err(|e|(e,None))?;
  let owner=Self{root:DeviceOwnerRoot::Restored(RestoredDeviceRoot{handle:Some(handle),thread:thread::current().id(),state}),records};
  match owner.current(){Ok(())=>Ok(owner),Err(e)=>Err((e,Some(owner)))}
 }
 pub(crate)fn current(&self)->Result<(),Error>{
  self.root.current()?;let h=self.root.handle()?;
  let status=with_device_input(&self.records,|raw|unsafe{veil_private_verified_commit_device_current(h.as_ptr(),raw)})?;
  self.root.classify(status)?;self.root.current()
 }
 pub(crate)fn public_projection(&self)->Result<crate::message_evidence::AcceptedDeviceProjection,Error>{
  self.current()?;
  let projection=match self.records.public_projection(){Ok(v)=>v,Err(_)=>{let _=self.root.classify(UNKNOWN);return Err(Error::Unknown)}};
  self.current()?;Ok(projection)
 }
 pub(crate)fn release(&mut self)->Result<(),Error>{self.root.close()}
}

#[repr(C)]struct MessageSessionInputRaw{version:u32,issuer_credential:FinalOriginalBytes,anchor_credential:FinalOriginalBytes,purpose:FinalOriginalBytes,association_issuer:FinalOriginalBytes,association_anchor:FinalOriginalBytes,issuer_enrollment:FinalOriginalBytes,anchor_enrollment:FinalOriginalBytes,issuer_history:*const FinalOriginalBytes,issuer_history_count:usize,anchor_history:*const FinalOriginalBytes,anchor_history_count:usize}
#[repr(C)]struct NativeCoreDeviceBindingV2{root:[u8;32],registration:[u8;32],classic:[u8;33],pq:[u8;2592]}
#[repr(C)]struct MessageSessionProjectionRaw{version:u32,local_name:FinalOriginalBytes,remote_name:FinalOriginalBytes,local_device:u32,remote_device:u32,purpose_digest:[u8;32],selected_session_digest:[u8;32],relation_digest:[u8;32],checkpoint_digest:[u8;32],relation_revision:u64,purpose_expires_ms:i64}
unsafe extern "C"{
 fn veil_private_message_session_acquire_v2(root:*const VerifiedCommit,device:*const DeviceOriginalInputRaw,binding:*const NativeCoreDeviceBindingV2,input:*const MessageSessionInputRaw,out:*mut *mut std::ffi::c_void)->i32;
 fn veil_private_message_session_current(h:*mut std::ffi::c_void)->i32;
 fn veil_private_message_session_projection(h:*mut std::ffi::c_void,out:*mut MessageSessionProjectionRaw)->i32;
 fn veil_private_message_session_close(h:*mut *mut std::ffi::c_void)->i32;
}
#[derive(serde::Serialize)]#[serde(rename_all="camelCase")]pub(crate)struct MessageSessionAddress{name:String,device_id:u32}
#[derive(serde::Serialize)]#[serde(rename_all="camelCase")]pub(crate)struct PersistentMessageProjection{version:u32,kind:&'static str,device:crate::message_evidence::AcceptedDeviceProjection,local:MessageSessionAddress,remote:MessageSessionAddress,purpose_digest:String,selected_session_digest:String,relation_digest:String,checkpoint_digest:String,relation_revision:String,#[serde(rename="purposeExpiresMS")]purpose_expires_ms:i64}
// Owns both ACTUAL device and ACTUAL protected session. Neither a public
// projection nor an Rc identity/Envelope alone inhabits this private type.
pub(crate)struct MessageSessionOwner{handle:Option<NonNull<std::ffi::c_void>>,device:Option<AcceptedDeviceOwner>,thread:ThreadId,unknown:std::cell::Cell<bool>}
pub(crate)struct MessageSessionAcquireFailure{pub(crate)error:Error,pub(crate)device:Option<AcceptedDeviceOwner>,pub(crate)session:Option<MessageSessionOwner>}
impl MessageSessionOwner{
 pub(crate)fn acquire(device:AcceptedDeviceOwner,input:&crate::message_evidence::MessageOpenInput,enrollment:&crate::message_enrollment::OriginalEnrollmentRecords)->Result<Self,MessageSessionAcquireFailure>{
  if let Err(error)=device.current(){return Err(MessageSessionAcquireFailure{error,device:Some(device),session:None})}
  let bytes=|s:&[u8]|FinalOriginalBytes{data:s.as_ptr(),size:s.len()};
  fn history(p:&[zeroize::Zeroizing<Vec<u8>>])->Result<Vec<FinalOriginalBytes>,Error>{let mut out=Vec::new();out.try_reserve_exact(p.len()).map_err(|_|Error::Capacity)?;for b in p{out.push(FinalOriginalBytes{data:b.as_ptr(),size:b.len()});}Ok(out)}
  let histories=history(&enrollment.issuer_predecessors).and_then(|i|history(&enrollment.anchor_predecessors).map(|a|(i,a)));
  let(ih,ah)=match histories{Ok(v)=>v,Err(error)=>return Err(MessageSessionAcquireFailure{error,device:Some(device),session:None})};
  let raw=MessageSessionInputRaw{version:1,issuer_credential:bytes(&input.issuer_credential),anchor_credential:bytes(&input.anchor_credential),purpose:bytes(&input.purpose_authorization),association_issuer:bytes(&input.association_issuer),association_anchor:bytes(&input.association_anchor),issuer_enrollment:bytes(&enrollment.issuer_current),anchor_enrollment:bytes(&enrollment.anchor_current),issuer_history:if ih.is_empty(){ptr::null()}else{ih.as_ptr()},issuer_history_count:ih.len(),anchor_history:if ah.is_empty(){ptr::null()}else{ah.as_ptr()},anchor_history_count:ah.len()};
  let root=match device.root.handle(){Ok(v)=>v,Err(error)=>return Err(MessageSessionAcquireFailure{error,device:Some(device),session:None})};
  let binding=match device.records.with_native_core_binding(|root,registration,classic,pq|NativeCoreDeviceBindingV2{root:*root,registration:*registration,classic:*classic,pq:*pq}){Ok(v)=>v,Err(_)=>return Err(MessageSessionAcquireFailure{error:Error::Association,device:Some(device),session:None})};
  if let Err(error)=device.current(){return Err(MessageSessionAcquireFailure{error,device:Some(device),session:None})}
  let mut out=ptr::null_mut();let s=match with_device_input(&device.records,|original|unsafe{veil_private_message_session_acquire_v2(root.as_ptr(),original,&binding,&raw,&mut out)}){Ok(s)=>s,Err(error)=>return Err(MessageSessionAcquireFailure{error,device:Some(device),session:None})};
  let Some(handle)=NonNull::new(out)else{return Err(MessageSessionAcquireFailure{error:match s{REQUIRED=>Error::Required,OK=>Error::AbiInvariant,2=>Error::Association,3=>Error::Capacity,4=>Error::Thread,_=>Error::Unknown},device:Some(device),session:None})};
  let owner=Self{handle:Some(handle),device:Some(device),thread:thread::current().id(),unknown:std::cell::Cell::new(s!=OK)};
  match owner.current(){Ok(())=>Ok(owner),Err(error)=>Err(MessageSessionAcquireFailure{error,device:None,session:Some(owner)})}
 }
 pub(crate)fn current(&self)->Result<(),Error>{
  owner_thread(self.thread)?;if self.unknown.get(){return Err(Error::Unknown)}
  let result=(||{let device=self.device.as_ref().ok_or(Error::Unknown)?;device.current()?;let h=self.handle.ok_or(Error::Unknown)?;if unsafe{veil_private_message_session_current(h.as_ptr())}!=OK{return Err(Error::Unknown)}device.current()})();
  if result.is_err(){self.unknown.set(true)}result
 }
 pub(crate)fn public_projection(&self)->Result<PersistentMessageProjection,Error>{
  self.current()?;let h=self.handle.ok_or(Error::Unknown)?;let mut p:MessageSessionProjectionRaw=unsafe{std::mem::zeroed()};
  if unsafe{veil_private_message_session_projection(h.as_ptr(),&mut p)}!=OK{self.unknown.set(true);return Err(Error::Unknown)}
  let result=(||{
   if p.version!=1||p.relation_revision==0||p.purpose_expires_ms<=0{return Err(Error::Association)}
   if crate::source_evidence::now_ms().map_err(|_|Error::Unknown)?>=p.purpose_expires_ms{return Err(Error::Unknown)}
   fn address(b:FinalOriginalBytes,id:u32)->Result<MessageSessionAddress,Error>{if b.data.is_null()||b.size==0||b.size>128||id==0||id>127{return Err(Error::Association)}let raw=unsafe{std::slice::from_raw_parts(b.data,b.size)};if raw.contains(&0){return Err(Error::Association)}let name=std::str::from_utf8(raw).map_err(|_|Error::Association)?.to_owned();libsignal_protocol::DeviceId::try_from(id).map_err(|_|Error::Association)?;Ok(MessageSessionAddress{name,device_id:id})}
   let local=address(p.local_name,p.local_device)?;let remote=address(p.remote_name,p.remote_device)?;if local.name==remote.name&&local.device_id==remote.device_id{return Err(Error::Association)}
   let hex=|b:&[u8;32]|->Result<String,Error>{if b.iter().all(|v|*v==0){return Err(Error::Association)}Ok(b.iter().map(|v|format!("{v:02x}")).collect())};
   let device=self.device.as_ref().ok_or(Error::Unknown)?.public_projection()?;
   let out=PersistentMessageProjection{version:1,kind:"protected-message-session-observation",device,local,remote,purpose_digest:hex(&p.purpose_digest)?,selected_session_digest:hex(&p.selected_session_digest)?,relation_digest:hex(&p.relation_digest)?,checkpoint_digest:hex(&p.checkpoint_digest)?,relation_revision:p.relation_revision.to_string(),purpose_expires_ms:p.purpose_expires_ms};self.current()?;Ok(out)
  })();if result.is_err(){self.unknown.set(true)}result
 }
 pub(crate)fn release(&mut self)->Result<(),Error>{
  owner_thread(self.thread)?;
  if let Some(original)=self.handle{let mut out=original.as_ptr();let s=unsafe{veil_private_message_session_close(&mut out)};if s!=OK||!out.is_null(){if out!=original.as_ptr(){std::process::abort()}self.unknown.set(true);return Err(Error::Unknown)}self.handle=None;}
  if let Some(device)=self.device.as_mut(){if let Err(e)=device.release(){self.unknown.set(true);return Err(e)}}self.device.take();Ok(())
 }
}
impl Drop for MessageSessionOwner{fn drop(&mut self){if self.handle.is_some()||self.device.is_some(){std::process::abort()}}}

// Per-operation continuation is Native-generated original facts, not a new
// issuer grant. The C Prepared retains actual session/device custody.
#[repr(C)]struct MessageOperationRaw{version:u32,direction:u32,logical:[u8;16],request_digest:[u8;32],nonce:[u8;32],issued_ms:i64,expires_ms:i64}
#[repr(C)]struct MessagePlanRaw{intent:*const std::ffi::c_void,journal:[*const std::ffi::c_void;32],journal_count:usize,inbox:*const std::ffi::c_void,outbox:*const std::ffi::c_void}
unsafe extern "C"{
 fn veil_private_message_operation_prepare(h:*mut std::ffi::c_void,i:*const MessageOperationRaw,out:*mut *mut Prepared)->i32;
 fn veil_private_message_operation_current(p:*mut Prepared)->i32;
 fn veil_private_message_operation_plan(p:*mut Prepared,out:*mut MessagePlanRaw)->i32;
 fn veil_private_message_operation_enter(p:*mut Prepared)->i32;
 fn veil_private_message_operation_snapshot(p:*mut Prepared,out:*mut *mut std::ffi::c_void)->i32;
}
struct MessageOperationWindow{started:std::time::Instant,budget:std::time::Duration,expires_ms:i64,unknown:std::cell::Cell<bool>}
impl MessageOperationWindow{fn current(&self)->Result<(),Error>{if self.unknown.get(){return Err(Error::Unknown)}let now=match crate::source_evidence::now_ms(){Ok(now)=>now,Err(_)=>{self.unknown.set(true);return Err(Error::Unknown)}};if self.started.elapsed()>=self.budget||now>=self.expires_ms{self.unknown.set(true);return Err(Error::Unknown)}Ok(())}}
impl MessageSessionOwner{
 pub(crate)fn prepare_operation(&self,input:&crate::product_message::MessageInput)->Result<PreparedOwner<'static>,Error>{
  self.current()?;let projection=self.public_projection()?;let now=crate::source_evidence::now_ms().map_err(|_|Error::Unknown)?;let expires=now.checked_add(30000).ok_or(Error::Capacity)?.min(projection.purpose_expires_ms);if expires<=now{return Err(Error::Required)}
  let started=std::time::Instant::now();use rand::TryRngCore;let mut nonce=[0u8;32];rand::rngs::OsRng.try_fill_bytes(&mut nonce).map_err(|_|Error::Unknown)?;
  let raw=MessageOperationRaw{version:1,direction:match input.direction(){crate::product_message::Direction::Send=>1,crate::product_message::Direction::Receive=>2},logical:*input.logical(),request_digest:input.original_digest(),nonce,issued_ms:now,expires_ms:expires};
  let window=Rc::new(MessageOperationWindow{started,budget:std::time::Duration::from_millis((expires-now)as u64),expires_ms:expires,unknown:std::cell::Cell::new(false)});
  let state=Rc::new(RefCell::new(Diagnostics{refs:1,..Diagnostics::default()}));let h=self.handle.ok_or(Error::Unknown)?;let mut p=ptr::null_mut();let s=unsafe{veil_private_message_operation_prepare(h.as_ptr(),&raw,&mut p)};let handle=output(s,p,&state)?;
  let owner=PreparedOwner{handle:Some(handle),original:PreparedOriginal::Message(window),thread:self.thread,state};if self.current().and_then(|_|owner.original_current()).is_err(){owner.state.borrow_mut().observe(UNKNOWN);}Ok(owner)
 }
}
impl PreparedOwner<'_>{
 fn message_native_plan(&self)->Result<crate::source_infrastructure::platform::NativePlan,Error>{
  self.original_current()?;let p=self.ptr()?;let mut out=MessagePlanRaw{intent:ptr::null(),journal:[ptr::null();32],journal_count:0,inbox:ptr::null(),outbox:ptr::null()};let s=unsafe{veil_private_message_operation_plan(p,&mut out)};self.state.borrow_mut().classify(s)?;
  if out.intent.is_null()||out.journal_count>32||out.journal[..out.journal_count].iter().any(|p|p.is_null())||(out.inbox.is_null()==out.outbox.is_null()){self.state.borrow_mut().observe(UNKNOWN);return Err(Error::Unknown)}self.original_current()?;Ok(crate::source_infrastructure::platform::NativePlan{intent:out.intent,journal:out.journal[..out.journal_count].to_vec(),inbox:out.inbox,outbox:out.outbox})
 }
 pub(super)fn detached_message_inputs(&mut self)->Result<DetachedMessageInputs,Error>{
  if !matches!(self.original,PreparedOriginal::Message(_)){return Err(Error::Required)}self.original_current()?;let plan=self.message_native_plan()?;let caps=self.borrow()?;let (admission,lease,intent)=(caps.admission.as_ptr().cast_const(),caps.lease.as_ptr().cast_const(),caps.intent.as_ptr().cast_const());if plan.intent!=intent.cast(){return Err(Error::Association)}
  self.original_current()?;let p=self.ptr()?;let mut retained=ptr::null_mut();let s=unsafe{veil_private_prepared_input_retain(p,&mut retained)};let handle=output(s,retained,&self.state)?;Ok(DetachedMessageInputs{proof:NativeResourceProof{handle:Some(handle),thread:self.thread,unknown:false},admission,lease,intent,plan})
 }
}
pub(super)struct DetachedMessageInputs{pub(super)proof:NativeResourceProof,pub(super)admission:*const Admission,pub(super)lease:*const Lease,pub(super)intent:*const Intent,pub(super)plan:crate::source_infrastructure::platform::NativePlan}

impl FinalOwner{pub(in crate::staging::platform)fn matches_intent(&self,intent:*const Intent)->Result<(),Error>{self.current()?;if self.intent.as_ptr().cast_const()!=intent{return Err(Error::Association)}self.current()}}
