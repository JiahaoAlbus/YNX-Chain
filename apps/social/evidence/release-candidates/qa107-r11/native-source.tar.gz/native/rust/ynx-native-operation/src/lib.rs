//! Native operation candidate ABI 1. No production authority constructor exists.
#![deny(unsafe_code)]
// Unsafe FFI is allowed ONLY in the cfg(test) null-handle ABI3 host probe.
use std::collections::BTreeMap;

pub const CANDIDATE_ABI: u32 = 1;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RequiredProvider {
    NativeDeviceAuthorityV1,
    TrustedRevocationCheckpointV1,
    ProtectedAtomicSessionInboxOutboxCommitV1,
    SourceBoundDurableObserverProvenanceV1,
}
#[derive(Debug, PartialEq, Eq)]
pub enum OperationError {
    Required([RequiredProvider; 4]),
    Authentication, CommitFailed, Unknown, Revoked, Binding, Consumed, Unproven, Crypto,
}
/// Native-only, non-Clone, non-serializable, non-Debug. No JNI/JS representation.
pub struct OpaqueOperationCapability { owner: u64, slot: u64 }
/// No public admission factory, trait fixture, metadata or PB field can open it.
pub struct NativeOperations { core: Core }
pub fn open_production() -> Result<NativeOperations, OperationError> {
    Err(OperationError::Required([
        RequiredProvider::NativeDeviceAuthorityV1,
        RequiredProvider::TrustedRevocationCheckpointV1,
        RequiredProvider::ProtectedAtomicSessionInboxOutboxCommitV1,
        RequiredProvider::SourceBoundDurableObserverProvenanceV1,
    ]))
}
#[derive(Clone, Copy, PartialEq, Eq)]
struct Binding {
    session: u64, state_generation: u64, operation: u64,
    context: u64, route: u64, device_authorization: u64, checkpoint: u64,
}
// These private proof constructors have no production implementation. Only the
// cfg(test) actual cipher/real fsync adapter below creates them in this candidate.
struct VerifiedFresh { binding: Binding }
struct VerifiedCommit { binding: Binding }
struct Core {
    owner: u64, next_slot: u64, published_operation: Option<u64>, current: Binding, revoked: bool, unknown: bool,
    capabilities: BTreeMap<u64, Binding>,
}
impl Core {
    fn finalize(&mut self, fresh: VerifiedFresh, commit: VerifiedCommit)
        -> Result<OpaqueOperationCapability, OperationError> {
        if self.revoked { return Err(OperationError::Revoked); }
        if self.unknown { return Err(OperationError::Unknown); }
        if fresh.binding != self.current || commit.binding != self.current {
            return Err(OperationError::Binding);
        }
        if self.published_operation == Some(self.current.operation) {
            return Err(OperationError::Consumed);
        }
        let slot = self.next_slot.checked_add(1).ok_or(OperationError::Consumed)?;
        self.next_slot = slot;
        self.capabilities.insert(slot, self.current);
        self.published_operation = Some(self.current.operation);
        Ok(OpaqueOperationCapability { owner: self.owner, slot })
    }
    fn consume(&mut self, capability: OpaqueOperationCapability, expected_operation: u64)
        -> Result<(), OperationError> {
        if capability.owner != self.owner { return Err(OperationError::Binding); }
        let binding = self.capabilities.remove(&capability.slot).ok_or(OperationError::Consumed)?;
        if self.revoked { return Err(OperationError::Revoked); }
        if self.unknown { return Err(OperationError::Unknown); }
        if binding != self.current || binding.operation != expected_operation {
            return Err(OperationError::Binding);
        }
        Ok(())
    }
    fn invalidate(&mut self) { self.capabilities.clear(); }
}
// Consumption is exposed only to a future controlled native CryptoEngine, not UI.
impl NativeOperations {
    pub fn consume_native(&mut self, capability: OpaqueOperationCapability, operation: u64)
        -> Result<(), OperationError> { self.core.consume(capability, operation) }
}
#[cfg(test)]
mod tests;

mod staging;

// Native product read-only diagnostics; no source/authority or messaging factory.
pub mod product_entry;

// Native Rust message path only. No JNI/JS pointer or source/key factory.
pub use staging::product_facade::{NativeProductEngine,NativeProductOperation,NativeProductPending,NativeProductRetainFailure,NativeProductDelivery,NativeProductError,NativeProductCommit};

pub mod product_controller;

pub mod product_jni;

mod private_own_key;

mod private_pq_storage;

#[cfg(feature="abi5-final-native-link")] mod private_custodian_ffi;

mod product_message;

mod source_infrastructure;
mod source_evidence;

mod account_evidence;

mod account_https;
mod account_instance;

mod message_evidence;

mod message_enrollment;

// Native-private math bridge; never an authority or public key factory.
#[cfg(feature="abi5-final-native-link")] mod message_custody_ffi;

#[cfg(feature="abi5-final-native-link")] mod message_execution;
