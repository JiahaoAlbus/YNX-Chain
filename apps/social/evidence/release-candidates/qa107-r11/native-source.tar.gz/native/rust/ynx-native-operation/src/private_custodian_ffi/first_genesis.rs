//! Exact existing firstDirectoryMessages/Leaf application mapping. This is NOT
//! an account permission, directory-absence witness or signing authorization.
use super::*;
use sha2::{Digest,Sha256};

pub(super)struct FirstGenesisIntent<'a>{realm:&'a[u8],route:&'a[u8],base:&'a[u8],epoch:u64}
fn next_directory_epoch(epoch:u64)->Result<u64,CustodyError>{epoch.checked_add(1).ok_or(CustodyError::Pair)}
fn app_frame(domain:&[u8],fields:&[&[u8]])->Vec<u8>{
 let mut out=Vec::new();out.extend(domain);out.push(0);
 for field in fields{out.extend((field.len()as u32).to_be_bytes());out.extend(*field)}out
}
pub(super)fn inspect<'a>(issuer:&'a[u8],target:&'a[u8])->Result<FirstGenesisIntent<'a>,CustodyError>{
 let i=Type4::parse(issuer)?;let t=Type4::parse(target)?;
 if !i.issuer||t.issuer||i.transcript!=t.transcript{return Err(CustodyError::Pair)}
 let a=frame::<16>(i.transcript,3)?;let p=principal(a[4])?;
 // First identity self-authorization uses the SAME complete proposed device,
 // not merely two equal keys. Existing/add/revoke/rotate/migrate are different.
 if a[3]!=b"enroll"||a[4]!=a[5]||a[10]!=a[13]||!a[15].is_empty(){return Err(CustodyError::Pair)}
 let one=1u64.to_be_bytes();let epoch=number(a[8],1)?;
 let next_epoch=next_directory_epoch(epoch)?;
 if p[6]!=one||p[7]!=one||number(p[8],1)?!=next_epoch||p[9]!=a[7]{return Err(CustodyError::Pair)}
 let leaf=app_frame(b"YNX/SOCIAL/FIRST-LEAF/V1",&[p[0],p[1],p[3],p[5],&one,&one,p[11]]);
 let grant=Sha256::digest(app_frame(b"YNX/SOCIAL/FIRST-DEVICE-REFERENCE/V1",&[&leaf]));
 if p[10]!=grant.as_slice()||a[14]!=app_frame(b"YNX/SOCIAL/FIRST-ACTIVE-DEVICE/V1",&[&leaf]){return Err(CustodyError::Pair)}
 Ok(FirstGenesisIntent{realm:a[1],route:p[11],base:a[6],epoch})
}
impl FirstGenesisIntent<'_>{
 pub(super)fn check_source(&self,e:&crate::source_evidence::UnadmittedSourceEvidence)->Result<(),crate::source_evidence::Error>{
  e.check_first_genesis(self.realm,self.route,self.base,self.epoch)
 }
}
#[cfg(test)]mod first_genesis_binding_controls{
 use super::*;
 fn f(kind:u8,fields:&[&[u8]])->Vec<u8>{let mut out=b"YPA1".to_vec();out.extend([kind,1]);out.extend((fields.len()as u16).to_be_bytes());for(i,b)in fields.iter().enumerate(){out.extend(((i+1)as u16).to_be_bytes());out.extend((b.len()as u32).to_be_bytes());out.extend(*b)}out}
 fn messages(fault:u8)->(Vec<u8>,Vec<u8>){
  let mut classic=[7;33];classic[0]=5;let pq=[8;2592];let one=1u64.to_be_bytes();let two=2u64.to_be_bytes();let three=3u64.to_be_bytes();
  let leaf=app_frame(b"YNX/SOCIAL/FIRST-LEAF/V1",&[b"identity",b"device",&classic,&pq,&one,&one,b"route"]);
  let grant=Sha256::digest(app_frame(b"YNX/SOCIAL/FIRST-DEVICE-REFERENCE/V1",&[&leaf]));
  let principal=f(1,&[b"identity",b"device",b"LIBSIGNAL-0.104.0-XEDDSA-CANDIDATE",&classic,b"ML-DSA-87",&pq,if fault==1{&two}else{&one},&one,if fault==2{&three}else{&two},if fault==3{&[9;32]}else{&[2;32]},if fault==4{&[9;32]}else{&grant},b"route"]);
  let mut other=principal.clone();if fault==5{let end=other.len()-1;other[end]=b'X'}
  let active=app_frame(b"YNX/SOCIAL/FIRST-ACTIVE-DEVICE/V1",&[&leaf]);
  let epoch=if fault==8{u64::MAX.to_be_bytes()}else{one};
  let a=f(3,&[b"YNX-SOCIAL",b"realm",&one,b"enroll",&principal,&other,&[1;32],&[2;32],&epoch,&two,&[3;32],&100u64.to_be_bytes(),&200u64.to_be_bytes(),if fault==6{&[4;32]}else{&[3;32]},if fault==7{b"wrong"}else{&active},b""]);
  (f(4,&[b"YNX/SOCIAL/PQ-AUTH/SIGN/V1",b"authorization",b"issuer",&a]),f(4,&[b"YNX/SOCIAL/PQ-AUTH/SIGN/V1",b"possession",b"target",&a]))
 }
 #[test]fn first_genesis_binding_controls_exact_application_mapping(){let(i,t)=messages(0);let v=inspect(&i,&t).expect("public structural fixture");assert_eq!(v.realm,b"realm");assert_eq!(v.route,b"route");assert_eq!(v.base,[1;32]);assert_eq!(v.epoch,1);for fault in 1..=7{let(i,t)=messages(fault);assert!(inspect(&i,&t).is_err(),"mapping fault {fault}")}}
 #[test]fn first_genesis_binding_controls_roles_and_original(){let(i,t)=messages(0);assert!(inspect(&t,&i).is_err());let(mut changed,_)=messages(0);changed.push(0);assert!(inspect(&changed,&t).is_err());let(i2,_)=messages(6);assert!(inspect(&i2,&t).is_err())}
 #[test]fn first_genesis_binding_controls_overflow_refuses_without_panicking(){
  assert!(matches!(next_directory_epoch(u64::MAX),Err(CustodyError::Pair)));
  let(i,t)=messages(8);assert!(inspect(&i,&t).is_err());
  // The original valid case remains valid; a refusal never grants trust.
  let(i,t)=messages(0);assert!(inspect(&i,&t).is_ok());
 }
}

#[cfg(test)]mod first_genesis_go_cross {
 use super::*;
 #[test]
 #[ignore="dedicated runner requires actual PUBLIC Go fixture output"]
 fn first_genesis_go_cross_actual_directory_messages(){
  let dir=std::env::var("YNX_FIRST_GENESIS_PUBLIC_DIR").expect("mandatory public Go output");
  let i=std::fs::read(std::path::Path::new(&dir).join("issuer.bin")).expect("Go issuer bytes");
  let t=std::fs::read(std::path::Path::new(&dir).join("target.bin")).expect("Go target bytes");
  let intent=inspect(&i,&t).expect("actual original Go encoding");
  assert_eq!(intent.realm,b"PUBLIC-REALM");assert_eq!(intent.route,b"PUBLIC-ROUTE");assert_eq!(intent.base,[1;32]);assert_eq!(intent.epoch,1);
  assert!(inspect(&t,&i).is_err());
 }
}
