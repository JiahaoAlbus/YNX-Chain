//! Native source evidence verification. No device permit, receipt or Go trust.
//! The normal approved profile table is deliberately empty. Mathematical
//! evidence is NOT NativeSigningAuthorization or a retained revocation lease.
#![allow(unsafe_code)]
use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD as B64};
use serde::{Deserialize, Serialize};
mod policy;
mod catalog;
mod first_prepared;
mod pending;
mod source_holder;
pub(crate) mod native_core_rights_v2;
pub(crate) use source_holder::{VerifiedFirstPreparedHolderCredential,VerifiedDirectoryHolderCredential};
// Storage coordinates only, not verified source provenance or permission.
pub(crate) struct FirstPreparedStorageCoordinates{pub(crate) operation:String,pub(crate) nonce:[u8;32],pub(crate) sequence:u64,pub(crate) head:[u8;32],pub(crate) anchor_custodian:String}
pub(crate) fn first_prepared_storage_coordinates(raw:&[u8])->Result<FirstPreparedStorageCoordinates,Error>{pending::storage_coordinates(raw)}
use std::{marker::PhantomData,rc::Rc,time::{Duration,Instant,SystemTime,UNIX_EPOCH}};

#[derive(Debug,Clone,Copy,PartialEq,Eq)] pub(crate) enum Error { Bounds,Canonical,ProfileRequired,Signature,Binding,Window }
#[derive(Serialize,Deserialize,PartialEq,Eq)] #[serde(deny_unknown_fields)]
struct Pair { classic:String,pq:String }
#[derive(Serialize,Deserialize,PartialEq,Eq)] #[serde(deny_unknown_fields,rename_all="camelCase")]
pub(crate) struct Scope { source:String,store:String,schema:String,inode:String,restore:String,source_generation:u64,native_restore_incarnation:u64 }
#[derive(Serialize,Deserialize)] #[serde(deny_unknown_fields)]
struct Envelope { version:u32,role:String,body:String,signature:Pair }
#[derive(Serialize,Deserialize)] #[serde(deny_unknown_fields,rename_all="camelCase")]
struct Credential {
 #[serde(default,skip_serializing_if="Option::is_none")] issuance:Option<policy::Issuance>,
 version:u32,bootstrap:String,authority:String,role:String,custodian:String,epoch:u64,scope:Scope,public:Pair,history_endpoint:String,
 #[serde(default,skip_serializing_if="Option::is_none")] first_enrollment:Option<policy::FirstEnrollment>,
 #[serde(default,skip_serializing_if="Option::is_none")] first_prepared:Option<first_prepared::Issuance>,
}
#[derive(Serialize,Deserialize)] #[serde(deny_unknown_fields,rename_all="camelCase")]
struct Registration {
 #[serde(default,skip_serializing_if="Option::is_none")] directory_checkpoint:Option<Envelope>,
 version:u32,issuer:Envelope,anchor:Envelope,
}
#[derive(Serialize,Deserialize)] #[serde(deny_unknown_fields,rename_all="camelCase")]
struct History {
 #[serde(default,skip_serializing_if="Option::is_none")] directory_checkpoint:Option<policy::Checkpoint>,
 version:u32,authority:String,epoch:u64,scope:Scope,nonce:String,head:String,catalog_digest:String,records:u64,
 #[serde(rename="issuedMS")] issued:i64,#[serde(rename="expiresMS")] expires:i64,
}
#[derive(Serialize,Deserialize)] #[serde(deny_unknown_fields,rename_all="camelCase")]
struct Carrier { version:u32,operation:String,proposal:String,issuer_transcript:String,target_transcript:String,registration:Registration,history:Envelope, #[serde(default,skip_serializing_if="Option::is_none")] catalog:Option<String>, #[serde(default,skip_serializing_if="Option::is_none")] pending:Option<pending::Carrier> }

// Release-owned trust material ONLY. No environment, JNI, Go DTO or callback
// can add an entry. Root approval and exact pinned material remain missing.
struct ApprovedProfile { bootstrap:&'static str,classic:&'static str,pq:&'static str,issuer_custodian:&'static str,anchor_custodian:&'static str,
 // Exact OriginalSource/Identity Native-purpose approval original. None is
 // deliberately NOT inferred from Source-proof credential authorization.
 native_core_approval_original:Option<&'static [u8]>,
}
fn approved_profiles()-> &'static [ApprovedProfile] { &[] }

// Matching expectations alone are NOT trusted provenance. The caller must
// eventually supply these from its same native request/operation owner, not Go.
pub(crate) struct OriginalExpectation<'a> {
 pub(crate) operation:&'a str,pub(crate) proposal:&'a [u8],
 pub(crate) issuer_transcript:&'a [u8],pub(crate) target_transcript:&'a [u8],
 pub(crate) scope:&'a Scope,pub(crate) nonce:&'a [u8;32],pub(crate) head:&'a str,pub(crate) catalog:&'a str,
}
// Private !Send evidence retains the actual original carrier and parsed signed
// history. Opaque policies/catalog membership/checkpoint admission are NOT
// verified here and cannot be used to sign. No conversion into authorization.
pub(crate) struct UnadmittedSourceEvidence { raw:Box<[u8]>,operation:String,history:History,contract_window:policy::Window,first_genesis:Option<policy::FirstGenesisBinding>,pending:Option<pending::Evidence>,holder_credentials:Option<(Credential,Credential)>,started:Instant,remaining:Duration,local:PhantomData<Rc<()>> }

fn ascii(s:&str,n:usize)->bool{ !s.is_empty()&&s.len()<=n&&s.bytes().all(|b|(33..=126).contains(&b)) }
fn digest(s:&str)->bool{s.len()==64&&s.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b))}
fn scope_valid(s:&Scope)->bool{[&s.source,&s.store,&s.schema,&s.inode,&s.restore].iter().all(|s|ascii(s,512))&&s.source_generation>0&&s.native_restore_incarnation>0}
fn decode(s:&str,min:usize,max:usize)->Result<Vec<u8>,Error>{
 if s.len()>max.div_ceil(3)*4{return Err(Error::Bounds)}
 let b=B64.decode(s).map_err(|_|Error::Bounds)?;
 if b.len()<min||b.len()>max||B64.encode(&b)!=s{return Err(Error::Bounds)}Ok(b)
}
fn canonical<T:Serialize+for<'d>Deserialize<'d>>(raw:&[u8],limit:usize)->Result<T,Error>{
 if raw.is_empty()||raw.len()>limit{return Err(Error::Bounds)}
 let v:T=serde_json::from_slice(raw).map_err(|_|Error::Canonical)?;
 // Match Go encoding/json escaping WITHOUT changing the bytes being verified.
 let s=serde_json::to_string(&v).map_err(|_|Error::Canonical)?;
 let s=s.replace('&',"\\u0026").replace('<',"\\u003c").replace('>',"\\u003e").replace('\u{2028}',"\\u2028").replace('\u{2029}',"\\u2029");
 if s.as_bytes()!=raw{return Err(Error::Canonical)}Ok(v)
}
fn signing_input(role:&str,body:&[u8])->Result<Vec<u8>,Error>{
 if !["credential","record-issuer","record-anchor","current-history","directory-checkpoint"].contains(&role)||body.is_empty()||body.len()>32768{return Err(Error::Bounds)}
 let mut out=b"YNX/SOCIAL/SOURCE-PROOF/V1\0".to_vec();out.push(role.len() as u8);out.extend(role.as_bytes());out.extend((body.len() as u32).to_be_bytes());out.extend(body);Ok(out)
}
unsafe extern "C" { fn own_selected_verify(pk:*const u8,pn:usize,m:*const u8,n:usize,sig:*const u8,sn:usize)->i32; }
fn verify_envelope(e:&Envelope,role:&str,key:&Pair)->Result<Vec<u8>,Error>{
 if e.version!=1||e.role!=role{return Err(Error::Binding)}
 let body=decode(&e.body,1,32768)?;let input=signing_input(role,&body)?;
 let pk=decode(&key.classic,33,33)?;if pk[0]!=5{return Err(Error::Bounds)}
 let pq=decode(&key.pq,2592,2592)?;let cs=decode(&e.signature.classic,64,64)?;let ps=decode(&e.signature.pq,4627,4627)?;
 let classic=libsignal_protocol::PublicKey::deserialize(&pk).map_err(|_|Error::Signature)?;
 if !classic.verify_signature(&input,&cs){return Err(Error::Signature)}
 // Existing selected ML-DSA-87 verifier/context, not a new primitive or mode.
 if unsafe{own_selected_verify(pq.as_ptr(),pq.len(),input.as_ptr(),input.len(),ps.as_ptr(),ps.len())}!=1{return Err(Error::Signature)}
 Ok(body)
}
fn credential(e:&Envelope,role:&str)->Result<Credential,Error>{
 let body=decode(&e.body,1,32768)?;let c:Credential=canonical(&body,32768)?;
 if c.version!=1||c.role!=role||!scope_valid(&c.scope)||!ascii(&c.authority,512)||c.epoch==0{return Err(Error::Binding)}
 let profile=approved_profiles().iter().find(|p|p.bootstrap==c.bootstrap).ok_or(Error::ProfileRequired)?;
 let custodian=if role=="issuer"{profile.issuer_custodian}else{profile.anchor_custodian};
 if custodian.is_empty()||c.custodian!=custodian{return Err(Error::Binding)}
 verify_envelope(e,"credential",&Pair{classic:profile.classic.into(),pq:profile.pq.into()})?;
 let pk=decode(&c.public.classic,33,33)?;if pk[0]!=5{return Err(Error::Bounds)}decode(&c.public.pq,2592,2592)?;
 policy::credential_shape(&c)?;
 Ok(c)
}
pub(crate) fn now_ms()->Result<i64,Error>{i64::try_from(SystemTime::now().duration_since(UNIX_EPOCH).map_err(|_|Error::Window)?.as_millis()).map_err(|_|Error::Window)}
fn current(h:&History,now:i64)->Result<(),Error>{
 if h.issued<0||now<h.issued||now>=h.expires||h.expires.checked_sub(h.issued).filter(|d|*d>0&&*d<=30000).is_none(){return Err(Error::Window)}Ok(())
}

pub(crate) fn verify_original(raw:&[u8],original:&OriginalExpectation<'_>)->Result<UnadmittedSourceEvidence,Error>{
 let started=Instant::now();let at=now_ms()?;
 let c:Carrier=canonical(raw,393216)?;
 if c.version!=1||c.registration.version!=1||!ascii(&c.operation,128)||c.operation!=original.operation{return Err(Error::Binding)}
 let proposal=decode(&c.proposal,2657,2657)?;
 if proposal!=original.proposal||c.operation!=format!("fd1-{}",B64.encode(&proposal[proposal.len()-32..]))||decode(&c.issuer_transcript,1,65536)?!=original.issuer_transcript||decode(&c.target_transcript,1,65536)?!=original.target_transcript{return Err(Error::Binding)}
 let issuer=credential(&c.registration.issuer,"issuer")?;let anchor=credential(&c.registration.anchor,"anchor")?;
 if issuer.scope!=anchor.scope||issuer.scope!=*original.scope||issuer.authority==anchor.authority||issuer.custodian==anchor.custodian||issuer.public.classic==anchor.public.classic||issuer.public.pq==anchor.public.pq{return Err(Error::Binding)}
 let body=verify_envelope(&c.history,"current-history",&anchor.public)?;let h:History=canonical(&body,32768)?;
 if h.version!=1||h.authority!=anchor.authority||h.epoch!=anchor.epoch||h.scope!=anchor.scope||decode(&h.nonce,32,32)?.as_slice()!=original.nonce||!digest(&h.head)||!digest(&h.catalog_digest)||h.head!=original.head||h.catalog_digest!=original.catalog||h.records>4096{return Err(Error::Binding)}
 current(&h,at)?;current(&h,now_ms()?)?;
 let (mut contract_window,first_genesis)=policy::verify(&c.registration,&issuer,&anchor,&h,at)?;
 let catalog_bytes=match c.catalog.as_ref(){Some(s)=>decode(s,0,393216)?,None if h.records==0=>Vec::new(),None=>return Err(Error::Binding)};
 catalog::verify(&catalog_bytes,&issuer,&anchor,&h)?;
 let pending=match c.pending.as_ref(){Some(p)=>Some(pending::verify(p,original,&issuer,&anchor,&h,&c.registration,&c.history)?),None=>None};
 if let Some(p)=pending.as_ref(){p.restrict_window(&mut contract_window)?;}
 contract_window.current(at)?;
 let remaining=Duration::from_millis((contract_window.expires-at) as u64);
 contract_window.current(now_ms()?)?;
 if started.elapsed()>=remaining{return Err(Error::Window)}
 Ok(UnadmittedSourceEvidence{raw:raw.to_vec().into_boxed_slice(),operation:c.operation,history:h,contract_window,first_genesis:Some(first_genesis),pending,holder_credentials:Some((issuer,anchor)),started,remaining,local:PhantomData})
}
impl UnadmittedSourceEvidence {
 // Exact verified source bytes are borrowed for the original operation only.
 // This is UNADMITTED input, never an owner or signing authorization.
 pub(crate)fn original_raw(&self,operation:&str)->Result<&[u8],Error>{
  self.recheck(operation)?;let raw=&self.raw;self.recheck(operation)?;Ok(raw)
 }
 // This is an immutable storage projection of verified input, NEVER admission.
 pub(crate)fn original_storage_frame(&self,operation:&str,credential:&VerifiedFirstPreparedHolderCredential)->Result<Vec<u8>,Error>{
  self.recheck(operation)?;
  let (issuer,anchor)=self.holder_credentials.as_ref().ok_or(Error::Binding)?;
  let (role,_,_,_,_,_)=credential.storage();
  credential.matches_original_credential(match role{crate::source_infrastructure::SourceRole::Issuer=>issuer,crate::source_infrastructure::SourceRole::Anchor=>anchor})?;
  let body=self.pending.as_ref().ok_or(Error::Binding)?.retained_storage_body();
  let name:&[u8]=match role{crate::source_infrastructure::SourceRole::Issuer=>b"first-prepared-issuer",crate::source_infrastructure::SourceRole::Anchor=>b"first-prepared-anchor"};
  let mut frame=b"YNX/SOCIAL/SOURCE-PROOF/V1\0".to_vec();frame.push(name.len() as u8);frame.extend(name);frame.extend((body.len() as u32).to_be_bytes());frame.extend(body);
  self.recheck(operation)?;credential.recheck()?;Ok(frame)
 }

 pub(crate) fn has_pending(&self)->bool{self.pending.is_some()}
 // Retained transport completeness only, never an admission predicate.
 pub(crate) fn has_namespace_prefix(&self)->bool{self.pending.as_ref().is_some_and(|p|p.has_namespace_prefix())}
 pub(crate) fn check_pending_account(&self,account:&crate::account_evidence::UnadmittedAccountEvidence)->Result<(),Error>{
  self.recheck(&self.operation)?;
  if let Some(p)=&self.pending{p.check_account(account)?;}
  self.recheck(&self.operation)
 }
 // Complete historical facts are available only through the SAME original
 // source/account receiving chain. This borrowed raw view grants no effect.
 pub(crate)fn original_namespace_prefix<'a>(&'a self,operation:&str,account:&crate::account_evidence::UnadmittedAccountEvidence)->Result<&'a[u8],Error>{
  self.recheck(operation)?;let prefix=self.pending.as_ref().ok_or(Error::Binding)?.original_namespace_prefix(account)?;self.recheck(operation)?;Ok(prefix)
 }
 pub(crate) fn check_first_genesis(&self,realm:&[u8],route:&[u8],root:&[u8],epoch:u64)->Result<(),Error>{self.first_genesis.as_ref().ok_or(Error::Binding)?.matches(realm,route,root,epoch)}
 pub(crate) fn recheck(&self,operation:&str)->Result<(),Error>{self.recheck_at(operation,now_ms()?)}
 fn recheck_at(&self,operation:&str,now:i64)->Result<(),Error>{
 self.recheck_elapsed(operation,now,self.started.elapsed())
 }
 fn recheck_elapsed(&self,operation:&str,now:i64,elapsed:Duration)->Result<(),Error>{
 if operation!=self.operation||elapsed>=self.remaining{return Err(Error::Window)}
 self.contract_window.current(now)?;
 if let Some(p)=&self.pending{p.current(now)?;}
 current(&self.history,now)
 }
}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn native_source_domain_preserves_original(){let body=b"{\"x\":\"\\u003c\"}";let f=signing_input("current-history",body).unwrap();assert!(f.ends_with(body));assert_eq!(f[b"YNX/SOCIAL/SOURCE-PROOF/V1\0".len()],15);assert!(signing_input("device",body).is_err());}
 #[test]fn native_source_selected_public_invalid_signatures(){
  let mut pk=[0u8;33];pk[0]=5;let pq=[0u8;2592];let cs=[0u8;64];let ps=[0u8;4627];
  let e=Envelope{version:1,role:"current-history".into(),body:B64.encode(b"{}"),signature:Pair{classic:B64.encode(cs),pq:B64.encode(ps)}};
  assert!(matches!(verify_envelope(&e,"current-history",&Pair{classic:B64.encode(pk),pq:B64.encode(pq)}),Err(Error::Signature)));
  let m=signing_input("current-history",b"{}").unwrap();
  assert_eq!(unsafe{own_selected_verify(pq.as_ptr(),pq.len(),m.as_ptr(),m.len(),ps.as_ptr(),ps.len())},0);
 }
 #[test]fn native_source_profile_missing_is_not_go_permission(){
 let scope=Scope{source:"s".into(),store:"s".into(),schema:"s".into(),inode:"s".into(),restore:"s".into(),source_generation:1,native_restore_incarnation:1};
 let c=Credential{issuance:None,version:1,bootstrap:"PUBLIC-UNAPPROVED".into(),authority:"a".into(),role:"issuer".into(),custodian:"c".into(),epoch:1,scope,public:Pair{classic:"x".into(),pq:"x".into()},history_endpoint:"https://invalid/".into(),first_enrollment:None,first_prepared:None};
 let e=Envelope{version:1,role:"credential".into(),body:B64.encode(serde_json::to_vec(&c).unwrap()),signature:Pair{classic:"x".into(),pq:"x".into()}};
 assert!(matches!(credential(&e,"issuer"),Err(Error::ProfileRequired)));assert!(approved_profiles().is_empty());
 }
 #[test]fn native_source_canonical_and_strict_base64(){assert!(canonical::<Pair>(br#"{"classic":"x","classic":"y","pq":"z"}"#,100).is_err());assert!(decode("YQ==",1,32).is_err());assert!(decode("YR",1,32).is_err());assert_eq!(decode("YQ",1,32).unwrap(),b"a");}
 #[test]fn native_source_half_open_window(){let raw=br#"{"version":1,"authority":"a","epoch":1,"scope":{"source":"s","store":"s","schema":"s","inode":"s","restore":"s","sourceGeneration":1,"nativeRestoreIncarnation":1},"nonce":"n","head":"h","catalogDigest":"c","records":0,"issuedMS":100,"expiresMS":200}"#;let h:History=canonical(raw,32768).unwrap();assert_eq!(current(&h,99),Err(Error::Window));assert_eq!(current(&h,100),Ok(()));assert_eq!(current(&h,199),Ok(()));assert_eq!(current(&h,200),Err(Error::Window));}
}

#[cfg(test)]mod cross_language {
 use super::*;
 #[test] #[ignore = "requires the separately generated PUBLIC Go carrier"]
 fn native_source_actual_go_carrier_missing_profile(){
  let path=std::env::var("YNX_SOURCE_CARRIER_PUBLIC_INPUT").expect("mandatory PUBLIC carrier path");
  let raw=std::fs::read(path).expect("actual Go output");let c:Carrier=canonical(&raw,393216).unwrap();
  let body=decode(&c.registration.issuer.body,1,32768).unwrap();let credential:Credential=canonical(&body,32768).unwrap();
  let proposal=decode(&c.proposal,2657,2657).unwrap();let im=decode(&c.issuer_transcript,1,65536).unwrap();let tm=decode(&c.target_transcript,1,65536).unwrap();
  // Matching PUBLIC expectations is fixture-only, not a native request owner.
  let expected=OriginalExpectation{operation:&c.operation,proposal:&proposal,issuer_transcript:&im,target_transcript:&tm,scope:&credential.scope,nonce:&[0;32],head:"unused",catalog:"unused"};
  assert!(matches!(verify_original(&raw,&expected),Err(Error::ProfileRequired)));
 }
}

// Structural selection only, never an approved source or original-operation
// capability. The real local owner supplies its own keys, IDs and nonce.
#[derive(PartialEq,Eq)]
pub(crate) struct SourceSelection { scope:Scope,head:String,catalog:String }
impl SourceSelection {
 pub(crate) fn checked(raw_scope:&[u8],head:&str,catalog:&str)->Result<Self,Error>{
  if !digest(head)||!digest(catalog){return Err(Error::Bounds)}
  let scope:Scope=canonical(raw_scope,4096)?;
  if !scope_valid(&scope){return Err(Error::Bounds)}
  Ok(Self{scope,head:head.into(),catalog:catalog.into()})
 }
 pub(crate) fn verify(&self,raw:&[u8],operation:&str,proposal:&[u8],issuer:&[u8],target:&[u8],nonce:&[u8;32])->Result<UnadmittedSourceEvidence,Error>{
  verify_original(raw,&OriginalExpectation{operation,proposal,issuer_transcript:issuer,target_transcript:target,scope:&self.scope,nonce,head:&self.head,catalog:&self.catalog})
 }
}

// Ordering only: this cannot create an evidence/authority owner. Used after
// application callbacks, before exposing the retained UNADMITTED status.
pub(crate) fn after_callbacks<E>(callback:impl FnOnce()->Result<(),E>,recheck:impl FnOnce()->Result<(),E>)->Result<(),E>{callback()?;recheck()}
#[cfg(test)]mod postcallback_controls{
 use super::*;use std::cell::Cell;
 fn fixture()->UnadmittedSourceEvidence{
  let history=History{directory_checkpoint:None,version:1,authority:"PUBLIC".into(),epoch:1,scope:Scope{source:"s".into(),store:"s".into(),schema:"s".into(),inode:"s".into(),restore:"s".into(),source_generation:1,native_restore_incarnation:1},nonce:"n".into(),head:"h".into(),catalog_digest:"c".into(),records:0,issued:100,expires:200};
  UnadmittedSourceEvidence{raw:Box::new([]),operation:"original".into(),history,contract_window:policy::Window::intersect((100,200),(100,180),None,None).unwrap(),first_genesis:None,pending:None,holder_credentials:None,started:Instant::now(),remaining:Duration::from_secs(30),local:PhantomData}
 }
 #[test]fn postcallback_controls_evidence_expiry_not_just_nonce(){
  for after in [180,200,99]{let e=fixture();let clock=Cell::new(150);assert!(e.recheck_at("original",150).is_ok());
   assert_eq!(after_callbacks(||{clock.set(after);Ok(())},||e.recheck_at("original",clock.get())),Err(Error::Window));assert_eq!(e.operation,"original");}
  let e=fixture();assert_eq!(after_callbacks(||Ok(()),||e.recheck_at("original",179)),Ok(()));assert_eq!(e.recheck_at("other",150),Err(Error::Window));
 }
}

#[cfg(test)]mod sap_window_controls{
 use super::*;use std::cell::Cell;
 // Public time-only controls, no enrolled profile, signature or device grant.
 fn fixture(windows:[(i64,i64);4])->UnadmittedSourceEvidence{
  let history=History{directory_checkpoint:None,version:1,authority:"PUBLIC".into(),epoch:1,scope:Scope{source:"s".into(),store:"s".into(),schema:"s".into(),inode:"s".into(),restore:"s".into(),source_generation:1,native_restore_incarnation:1},nonce:"original-nonce".into(),head:"h".into(),catalog_digest:"c".into(),records:0,issued:windows[0].0,expires:windows[0].1};
  let window=policy::Window::intersect(windows[0],windows[1],Some(windows[2]),Some(windows[3])).unwrap();
  let remaining=Duration::from_millis((window.expires-160)as u64);
  UnadmittedSourceEvidence{raw:Box::new([]),operation:"original".into(),history,contract_window:window,first_genesis:None,pending:None,holder_credentials:None,started:Instant::now(),remaining,local:PhantomData}
 }
 #[test]fn sap_window_controls_each_lower_survives_callback_rollback(){
  for index in 0..4{
   let mut windows=[(100,300);4];windows[index].0=155;
   let evidence=fixture(windows);let clock=Cell::new(160);let elapsed=Duration::from_millis(1);
   assert_eq!(evidence.recheck_elapsed("original",160,elapsed),Ok(()));
   assert_eq!(after_callbacks(||{clock.set(154);Ok(())},||evidence.recheck_elapsed("original",clock.get(),elapsed)),Err(Error::Window));
   assert_eq!(evidence.recheck_elapsed("original",155,elapsed),Ok(()));
   assert_eq!(evidence.operation,"original");assert_eq!(evidence.history.nonce,"original-nonce");
   if index!=0{assert_eq!(current(&evidence.history,154),Ok(()));}
  }
 }
 #[test]fn sap_window_controls_each_upper_is_half_open(){
  for index in 0..4{
   let mut windows=[(100,300);4];windows[index].1=250;
   let evidence=fixture(windows);
   assert_eq!(evidence.recheck_elapsed("original",249,Duration::from_millis(1)),Ok(()));
   assert_eq!(evidence.recheck_elapsed("original",250,Duration::from_millis(1)),Err(Error::Window));
  }
 }
 #[test]fn sap_window_controls_monotonic_never_renews_on_wall_rollback(){
  let evidence=fixture([(100,300),(150,250),(155,290),(152,280)]);
  let started=evidence.started;let budget=evidence.remaining;
  assert_eq!(budget,Duration::from_millis(90));
  assert_eq!(evidence.recheck_elapsed("original",155,Duration::from_millis(89)),Ok(()));
  assert_eq!(evidence.recheck_elapsed("original",155,budget),Err(Error::Window));
  assert_eq!(evidence.recheck_elapsed("original",160,budget+Duration::from_millis(1)),Err(Error::Window));
  assert_eq!(evidence.started,started);assert_eq!(evidence.remaining,budget);
  assert_eq!(evidence.recheck_elapsed("changed",160,Duration::ZERO),Err(Error::Window));
 }
 #[test]fn sap_window_controls_empty_and_optional_intersections(){
  assert!(matches!(policy::Window::intersect((100,200),(150,250),Some((200,300)),None),Err(Error::Window)));
  assert!(matches!(policy::Window::intersect((100,200),(150,250),None,Some((-1,300))),Err(Error::Window)));
  let window=policy::Window::intersect((100,300),(150,250),None,None).unwrap();
  assert_eq!(window.current(149),Err(Error::Window));assert_eq!(window.current(150),Ok(()));assert_eq!(window.current(250),Err(Error::Window));
 }
}

// A server original has no caller-selected Scope. Select the expectation only
// from the existing credential verifier, then run the unchanged full verifier.
// These facts remain UNADMITTED; historical account-role ownership is distinct.
pub(crate)fn verify_server_original(raw:&[u8],prefix:&[u8],nonce:&[u8;32],account:&crate::account_instance::ServerVerifiedOriginal)->Result<UnadmittedSourceEvidence,Error>{
 account.current().map_err(|_|Error::Window)?;
 let c:Carrier=canonical(raw,393216)?;
 let issuer=credential(&c.registration.issuer,"issuer")?;
 let anchor=credential(&c.registration.anchor,"anchor")?;
 if issuer.scope!=anchor.scope{return Err(Error::Binding)}
 let history_body=verify_envelope(&c.history,"current-history",&anchor.public)?;
 let h:History=canonical(&history_body,32768)?;
 let original=OriginalExpectation{operation:account.operation().map_err(|_|Error::Binding)?,proposal:&account.proposal,issuer_transcript:&account.issuer,target_transcript:&account.target,scope:&issuer.scope,nonce,head:&h.head,catalog:&h.catalog_digest};
 let verified=verify_original(raw,&original)?;
 verified.pending.as_ref().ok_or(Error::Binding)?.server_consistency(account,prefix)?;
 verified.recheck(original.operation)?;account.current().map_err(|_|Error::Window)?;Ok(verified)
}


// Restricted mathematical verifier for the newly approved message domains.
// It borrows the SAME retained Source evidence. No owner, resource, enrollment
// or signing permission is created by signature verification.
pub(crate) struct MessageSourceKeys<'a>{source:&'a UnadmittedSourceEvidence,operation:&'a str,root:Pair,issuer_digest:String,anchor_digest:String}
fn message_preimage(domain:&[u8],role:&str,body:&[u8])->Result<Vec<u8>,Error>{
 let allowed=match domain{
  b"YNX/SOCIAL/MESSAGE-PURPOSE/V1\0"=>role=="purpose-authorization",
  b"YNX/SOCIAL/MESSAGE-ASSOCIATION/V1\0"=>matches!(role,"association-issuer"|"association-anchor"),
  b"YNX/SOCIAL/MESSAGE-FINAL/V1\0"=>matches!(role,"final-issuer"|"final-anchor"),
  b"YNX/SOCIAL/MESSAGE-ENROLLMENT/V1\0"=>matches!(role,"message-enrollment-issuer"|"message-enrollment-anchor"),
  b"YNX/SOCIAL/ACCEPTED-DEVICE-FINAL/V1\0"=>matches!(role,"accepted-device-final-issuer"|"accepted-device-final-anchor"),
  b"YNX/SOCIAL/ACCEPTED-DEVICE-CURRENT/V1\0"=>matches!(role,"accepted-device-current-issuer"|"accepted-device-current-anchor"),
  b"YNX/SOCIAL/FIRST-DEVICE-ENGINE-COMMIT/V1\0"=>matches!(role,"first-device-engine-commit-issuer"|"first-device-engine-commit-anchor"),
  b"YNX/SOCIAL/FIRST-DEVICE-INDEPENDENT-CHECKPOINT/V1\0"=>role=="first-device-independent-checkpoint-anchor",
  b"YNX/SOCIAL/FIRST-DEVICE-INDEPENDENT-TERMINAL/V1\0"=>matches!(role,"first-device-independent-terminal-issuer"|"first-device-independent-terminal-anchor"),_=>false};
 if !allowed||body.is_empty()||body.len()>32768{return Err(Error::Bounds)}
 let mut out=domain.to_vec();out.push(role.len()as u8);out.extend(role.as_bytes());out.extend((body.len()as u32).to_be_bytes());out.extend(body);Ok(out)
}
fn verify_message_envelope(raw:&[u8],domain:&[u8],role:&str,key:&Pair)->Result<Vec<u8>,Error>{
 let e:Envelope=canonical(raw,65536)?;
 if e.version!=1||e.role!=role{return Err(Error::Binding)}
 let body=decode(&e.body,1,32768)?;let input=message_preimage(domain,role,&body)?;
 let pk=decode(&key.classic,33,33)?;if pk[0]!=5{return Err(Error::Bounds)}
 let pq=decode(&key.pq,2592,2592)?;let cs=decode(&e.signature.classic,64,64)?;let ps=decode(&e.signature.pq,4627,4627)?;
 let classic=libsignal_protocol::PublicKey::deserialize(&pk).map_err(|_|Error::Signature)?;
 if !classic.verify_signature(&input,&cs){return Err(Error::Signature)}
 if unsafe{own_selected_verify(pq.as_ptr(),pq.len(),input.as_ptr(),input.len(),ps.as_ptr(),ps.len())}!=1{return Err(Error::Signature)}Ok(body)
}
impl UnadmittedSourceEvidence{
 pub(crate)fn message_keys<'a>(&'a self,operation:&'a str,issuer_raw:&[u8],anchor_raw:&[u8])->Result<MessageSourceKeys<'a>,Error>{
  use sha2::{Digest,Sha256};
  self.recheck(operation)?;
  let carrier:Carrier=canonical(&self.raw,393216)?;
  let i:Envelope=canonical(issuer_raw,65536)?;let a:Envelope=canonical(anchor_raw,65536)?;
  let same=|x:&Envelope,y:&Envelope|x.version==y.version&&x.role==y.role&&x.body==y.body&&x.signature==y.signature;
  if !same(&i,&carrier.registration.issuer)||!same(&a,&carrier.registration.anchor){return Err(Error::Binding)}
  let issuer=credential(&i,"issuer")?;let anchor=credential(&a,"anchor")?;
  if issuer.bootstrap!=anchor.bootstrap||issuer.scope!=anchor.scope||issuer.scope!=self.history.scope||issuer.custodian==anchor.custodian||issuer.authority==anchor.authority||issuer.public==anchor.public{return Err(Error::Binding)}
  let profile=approved_profiles().iter().find(|p|p.bootstrap==issuer.bootstrap).ok_or(Error::ProfileRequired)?;
  let key=MessageSourceKeys{source:self,operation,root:Pair{classic:profile.classic.into(),pq:profile.pq.into()},issuer_digest:Sha256::digest(issuer_raw).iter().map(|b|format!("{b:02x}")).collect(),anchor_digest:Sha256::digest(anchor_raw).iter().map(|b|format!("{b:02x}")).collect()};
  key.recheck()?;Ok(key)
 }
}
#[derive(PartialEq,Eq,Debug)]
enum MessageSigner{Root,Issuer,Anchor}
fn message_signer(role:&str)->Result<MessageSigner,Error>{match role{
 "purpose-authorization"|"message-enrollment-issuer"|"message-enrollment-anchor"=>Ok(MessageSigner::Root),
 "association-issuer"|"final-issuer"|"accepted-device-final-issuer"|"accepted-device-current-issuer"|"first-device-engine-commit-issuer"|"first-device-independent-terminal-issuer"=>Ok(MessageSigner::Issuer),
 "association-anchor"|"final-anchor"|"accepted-device-final-anchor"|"accepted-device-current-anchor"|"first-device-engine-commit-anchor"|"first-device-independent-checkpoint-anchor"|"first-device-independent-terminal-anchor"=>Ok(MessageSigner::Anchor),
 _=>Err(Error::Binding)
}}
impl MessageSourceKeys<'_>{
 pub(crate)fn recheck(&self)->Result<(),Error>{self.source.recheck(self.operation)}
 pub(crate)fn scope(&self)->&Scope{&self.source.history.scope}
 pub(crate)fn bootstrap(&self)->Result<&str,Error>{self.recheck()?;Ok(&self.source.holder_credentials.as_ref().ok_or(Error::Binding)?.0.bootstrap)}
 pub(crate)fn credential_digests(&self)->(&str,&str){(&self.issuer_digest,&self.anchor_digest)}
 pub(crate)fn expires(&self)->i64{self.source.contract_window.expires}
 pub(crate)fn verify(&self,raw:&[u8],domain:&[u8],role:&str)->Result<Vec<u8>,Error>{
  self.recheck()?;
  let keys=self.source.holder_credentials.as_ref().ok_or(Error::Binding)?;
  let key=match message_signer(role)?{MessageSigner::Root=>&self.root,MessageSigner::Issuer=>&keys.0.public,MessageSigner::Anchor=>&keys.1.public};
  let body=verify_message_envelope(raw,domain,role,key)?;self.recheck()?;Ok(body)
 }
}


// Extract the exact original top-level value span. Deserialization is used only
// for byte offsets; no reconstructed JSON is hashed or supplied to consumers.
fn original_field<'a>(raw:&'a[u8],field:&str)->Result<&'a[u8],Error>{
 if raw.first()!=Some(&b'{'){return Err(Error::Canonical)}let mut offset=1;
 loop{
  if raw.get(offset)==Some(&b'}'){return Err(Error::Binding)}
  let mut key=serde_json::Deserializer::from_slice(&raw[offset..]).into_iter::<String>();
  let name=key.next().ok_or(Error::Canonical)?.map_err(|_|Error::Canonical)?;offset+=key.byte_offset();
  if raw.get(offset)!=Some(&b':'){return Err(Error::Canonical)}offset+=1;let start=offset;
  let mut value=serde_json::Deserializer::from_slice(&raw[offset..]).into_iter::<serde_json::Value>();
  value.next().ok_or(Error::Canonical)?.map_err(|_|Error::Canonical)?;offset+=value.byte_offset();
  if name==field{return Ok(&raw[start..offset])}
  match raw.get(offset){Some(b',')=>offset+=1,Some(b'}')=>return Err(Error::Binding),_=>return Err(Error::Canonical)}
 }
}
impl MessageSourceKeys<'_>{pub(crate)fn history_original(&self)->Result<&[u8],Error>{self.recheck()?;let raw=original_field(&self.source.raw,"history")?;self.recheck()?;Ok(raw)}}

// Original-body observation is not signature verification or owning admission.
// Actual accepted-device owner performs protected current before and after use.
pub(crate)fn observe_device_original_body(raw:&[u8],role:&str)->Result<Vec<u8>,Error>{
 let e:Envelope=canonical(raw,65536)?;
 if e.version!=1||e.role!=role{return Err(Error::Binding)}
 decode(&e.body,1,32768)
}


// Private fixed-startup custody intake. Public selection bytes are matching
// observations only; trusted Source material still comes from the independently
// release-owned profile table above, never the Account26 Ed25519 Root.
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
struct CustodyIdentity {key_id:String,classic:String,pq:String}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields)]
struct CustodyIdentities {root:CustodyIdentity,issuer:CustodyIdentity,anchor:CustodyIdentity}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
struct CustodySelection {schema:String,suite:String,bootstrap:String,adapter_path:String,adapter_sha256:String,public_identities:CustodyIdentities,approval_input_digest:String}
// This object retains only authenticated public originals. It is deliberately
// not Native custody, an enrolled resource, a signing lease or a floor proof.
pub(crate)struct FixedStartupSourceEvidence {
 manifest:Box<[u8]>,issuer_raw:Box<[u8]>,anchor_raw:Box<[u8]>,selected_bootstrap:String,
 issuer:Credential,anchor:Credential,local:PhantomData<Rc<()>>,
}
fn custody_label(s:&str)->bool{!s.is_empty()&&s.len()<=128&&s.bytes().all(|b|b.is_ascii_alphanumeric()||matches!(b,b'.'|b'_'|b':'|b'-'))}
fn custody_selection(raw:&[u8])->Result<CustodySelection,Error>{
 if raw.is_empty()||raw.len()>1048576{return Err(Error::Bounds)}
 let m:CustodySelection=serde_json::from_slice(raw).map_err(|_|Error::Canonical)?;
 // Auth's existing JSON.stringify transport, distinct from signed Go envelopes.
 if serde_json::to_vec(&m).map_err(|_|Error::Canonical)?.as_slice()!=raw{return Err(Error::Canonical)}
 if m.schema!="ynx-social-message-release-custody-selection/v1"||m.suite!="original-libsignal-05-33-64+selected-ml-dsa-87-2592-4627"||!custody_label(&m.bootstrap)||!digest(&m.adapter_sha256)||!digest(&m.approval_input_digest)||!m.adapter_path.starts_with('/')||!ascii(&m.adapter_path,4096){return Err(Error::Binding)}
 let identities=[&m.public_identities.root,&m.public_identities.issuer,&m.public_identities.anchor];
 for i in identities {if !custody_label(&i.key_id){return Err(Error::Bounds)}let pk=decode(&i.classic,33,33)?;if pk[0]!=5{return Err(Error::Bounds)}decode(&i.pq,2592,2592)?;}
 for i in 0..3{for j in 0..i{if identities[i].key_id==identities[j].key_id||identities[i].classic==identities[j].classic||identities[i].pq==identities[j].pq{return Err(Error::Binding)}}}Ok(m)
}
pub(crate)fn validate_custody_selection(raw:&[u8])->Result<(),Error>{custody_selection(raw).map(|_|())}
pub(crate)fn verify_fixed_startup_source(manifest:&[u8],issuer_raw:&[u8],anchor_raw:&[u8],selected_bootstrap:&str)->Result<FixedStartupSourceEvidence,Error>{
 let m=custody_selection(manifest)?;
 if !custody_label(selected_bootstrap)||m.bootstrap!=selected_bootstrap{return Err(Error::Binding)}
 // The caller supplies credential originals from its private fixed startup
 // selection, not from JS arguments. Selection never adds a trust-table entry.
 let i:Envelope=canonical(issuer_raw,65536)?;let a:Envelope=canonical(anchor_raw,65536)?;
 let issuer=credential(&i,"issuer")?;let anchor=credential(&a,"anchor")?;
 if issuer.bootstrap!=m.bootstrap||anchor.bootstrap!=m.bootstrap||issuer.scope!=anchor.scope||issuer.custodian==anchor.custodian||issuer.authority==anchor.authority||issuer.public==anchor.public{return Err(Error::Binding)}
 let profile=approved_profiles().iter().find(|p|p.bootstrap==m.bootstrap).ok_or(Error::ProfileRequired)?;
 let same=|identity:&CustodyIdentity,pair:&Pair|identity.classic==pair.classic&&identity.pq==pair.pq;
 if !same(&m.public_identities.root,&Pair{classic:profile.classic.into(),pq:profile.pq.into()})||!same(&m.public_identities.issuer,&issuer.public)||!same(&m.public_identities.anchor,&anchor.public){return Err(Error::Binding)}
 Ok(FixedStartupSourceEvidence{manifest:manifest.into(),issuer_raw:issuer_raw.into(),anchor_raw:anchor_raw.into(),selected_bootstrap:selected_bootstrap.into(),issuer,anchor,local:PhantomData})
}
// PRIVATE release selection, separate from signing profiles and wrapping scope.
// No wire/JNI/ENV constructor can install an entry. These exact originals bind
// policy, not live resource possession or a protected registration commit.
#[derive(Clone,Copy,PartialEq,Eq)]
pub(crate) enum AdministrationOperation { Register, Update, Revoke }
struct ApprovedAdministrationPolicy {
 bootstrap:&'static str, authority:&'static str, custodian:&'static str,
 role:u8, credential_epoch:u64, source_generation:u64,
 operation:AdministrationOperation, originals:[[u8;32];15],
 registry_generation:u64, registry_head:[u8;32], not_before_ms:i64, expires_ms:i64,
}
fn approved_administration_policies()->&'static [ApprovedAdministrationPolicy]{&[]}
// This witness is policy evidence ONLY. A live protection owner must separately
// recognize resources and atomically consume the same registry head before a row
// can be admitted. Neither digest nor this witness inhabits that owner.
pub(crate) struct SelectedAdministrationPolicy {
 policy:&'static ApprovedAdministrationPolicy, role:u8,
 originals:[Box<[u8]>;15], local:PhantomData<Rc<()>>,
}
impl SelectedAdministrationPolicy {
 pub(crate) fn recheck(&self,source:&FixedStartupSourceEvidence,role:u8,operation:AdministrationOperation,originals:&[&[u8];15],now_ms:i64)->Result<(),Error>{
  if role!=self.role||operation!=self.policy.operation{return Err(Error::Binding)}
  for (expected,actual) in self.originals.iter().zip(originals){if expected.as_ref()!=*actual{return Err(Error::Binding)}}
  source.check_administration_policy(self.policy,role,operation,originals,now_ms)
 }
 pub(crate) fn protected_head_expectation(&self)->(u64,[u8;32]){(self.policy.registry_generation,self.policy.registry_head)}
}
impl FixedStartupSourceEvidence{
 fn check_administration_policy(&self,policy:&ApprovedAdministrationPolicy,role:u8,operation:AdministrationOperation,originals:&[&[u8];15],now_ms:i64)->Result<(),Error>{
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let subject=match role{1=>&self.issuer,2=>&self.anchor,_=>return Err(Error::Binding)};
  if policy.bootstrap!=self.selected_bootstrap||policy.authority!=subject.authority||policy.custodian!=subject.custodian||policy.role!=role||policy.credential_epoch!=subject.epoch||policy.source_generation!=subject.scope.source_generation||policy.operation!=operation{return Err(Error::Binding)}
  if policy.not_before_ms>=policy.expires_ms||now_ms<policy.not_before_ms||now_ms>=policy.expires_ms{return Err(Error::Window)}
  use sha2::{Digest,Sha256};
  for (raw,expected) in originals.iter().zip(policy.originals){if raw.is_empty()||raw.len()>65536{return Err(Error::Bounds)}let actual:[u8;32]=Sha256::digest(raw).into();if actual!=expected{return Err(Error::Binding)}}
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)
 }
 pub(crate) fn select_administration_policy(&self,role:u8,operation:AdministrationOperation,originals:&[&[u8];15],now_ms:i64)->Result<SelectedAdministrationPolicy,Error>{
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let subject=match role{1=>&self.issuer,2=>&self.anchor,_=>return Err(Error::Binding)};
  let policy=approved_administration_policies().iter().find(|p|p.bootstrap==self.selected_bootstrap&&p.authority==subject.authority&&p.custodian==subject.custodian&&p.role==role&&p.operation==operation).ok_or(Error::ProfileRequired)?;
  self.check_administration_policy(policy,role,operation,originals,now_ms)?;
  Ok(SelectedAdministrationPolicy{policy,role,originals:std::array::from_fn(|i|originals[i].into()),local:PhantomData})
 }

 // Matching a held selected role original is evidence, never registry admission.
 pub(crate)fn match_registered_role_original(&self,role:u8,raw:&[u8])->Result<(),Error>{
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let selected=match role{1=>self.issuer_raw.as_ref(),2=>self.anchor_raw.as_ref(),_=>return Err(Error::Binding)};
  if raw!=selected{return Err(Error::Binding)}
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)
 }
 pub(crate)fn custody_public_binding(&self,role:u8)->Result<(&[u8],[u8;33],Box<[u8;2592]>),Error>{
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let c=match role{1=>&self.issuer,2=>&self.anchor,_=>return Err(Error::Binding)};
  let classic=decode(&c.public.classic,33,33)?;let pq=decode(&c.public.pq,2592,2592)?;
  if classic[0]!=5{return Err(Error::Binding)}
  let mut selected=[0;33];selected.copy_from_slice(&classic);
  let mut selected_pq=Box::new([0;2592]);selected_pq.copy_from_slice(&pq);
  Ok((c.custodian.as_bytes(),selected,selected_pq))
 }
 pub(crate)fn match_selected_manifest(&self,manifest:&[u8])->Result<(),Error>{
  self.recheck_originals(manifest,&self.issuer_raw,&self.anchor_raw)
 }
 pub(crate)fn match_approval_input_digest(&self,expected:&[u8;32])->Result<(),Error>{
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let expected:String=expected.iter().map(|b|format!("{b:02x}")).collect();
  if custody_selection(&self.manifest)?.approval_input_digest!=expected{return Err(Error::Binding)}Ok(())
 }
 // Independent startup verification has no account Attempt or previously
 // produced Source carrier. Original release selection is rechecked here;
 // the returned bytes remain unadmitted and cannot manufacture resource/floor.
 pub(crate)fn verify_enrollment_original(&self,raw:&[u8],role:u8)->Result<Vec<u8>,Error>{
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let role=match role{1=>"message-enrollment-issuer",2=>"message-enrollment-anchor",_=>return Err(Error::Binding)};
  let profile=approved_profiles().iter().find(|p|p.bootstrap==self.selected_bootstrap).ok_or(Error::ProfileRequired)?;
  let body=verify_message_envelope(raw,b"YNX/SOCIAL/MESSAGE-ENROLLMENT/V1\0",role,&Pair{classic:profile.classic.into(),pq:profile.pq.into()})?;
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;Ok(body)
 }
 // This synchronous borrow checks only the five already defined first-device
 // original roles. No live resource/permission follows from returned body bytes.
 pub(crate)fn verify_commit_original(&self,raw:&[u8],domain:&[u8],role:&str)->Result<Vec<u8>,Error>{
  let allowed=match domain{
   b"YNX/SOCIAL/FIRST-DEVICE-ENGINE-COMMIT/V1\0"=>matches!(role,"first-device-engine-commit-issuer"|"first-device-engine-commit-anchor"),
   b"YNX/SOCIAL/FIRST-DEVICE-INDEPENDENT-CHECKPOINT/V1\0"=>role=="first-device-independent-checkpoint-anchor",
   b"YNX/SOCIAL/FIRST-DEVICE-INDEPENDENT-TERMINAL/V1\0"=>matches!(role,"first-device-independent-terminal-issuer"|"first-device-independent-terminal-anchor"),_=>false};
  if !allowed{return Err(Error::Binding)}
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let key=match message_signer(role)?{MessageSigner::Issuer=>&self.issuer.public,MessageSigner::Anchor=>&self.anchor.public,MessageSigner::Root=>return Err(Error::Binding)};
  let body=verify_message_envelope(raw,domain,role,key)?;
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;Ok(body)
 }
 pub(crate)fn enrollment_binding(&self,role:u8)->Result<(&str,String),Error>{
  use sha2::{Digest,Sha256};
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let raw=match role{1=>self.issuer_raw.as_ref(),2=>self.anchor_raw.as_ref(),_=>return Err(Error::Binding)};
  Ok((&self.selected_bootstrap,Sha256::digest(raw).iter().map(|b|format!("{b:02x}")).collect()))
 }
 pub(crate)fn recheck_originals(&self,manifest:&[u8],issuer:&[u8],anchor:&[u8])->Result<(),Error>{
 if manifest!=self.manifest.as_ref()||issuer!=self.issuer_raw.as_ref()||anchor!=self.anchor_raw.as_ref(){return Err(Error::Binding)}
 // Reuse the actual release profile and original suite, not cached success or
 // a manifest boolean. This is public evidence verification, not live current.
 let renewed=verify_fixed_startup_source(manifest,issuer,anchor,&self.selected_bootstrap)?;
 if renewed.issuer.scope!=self.issuer.scope||renewed.anchor.scope!=self.anchor.scope{return Err(Error::Binding)}Ok(())
 }
}

// PRIVATE Social Native-core policy, separate from administration and public
// SourcePurpose 1/2. This witness is NOT resource possession or admission.
#[derive(Clone,Copy,PartialEq,Eq)]
pub(crate) enum NativeCorePurpose { FirstDeviceCore, MessageCore }
struct ApprovedNativeCorePolicy {
 bootstrap:&'static str,purpose:NativeCorePurpose,
 root_digest:[u8;32],registration_digest:[u8;32],source_digest:[u8;32],namespace_digest:[u8;32],native_identity:[u8;32],
 resource_association:[u8;32],not_before_ms:i64,expires_ms:i64,
}
fn approved_native_core_policies()->&'static [ApprovedNativeCorePolicy]{&[]}
pub(crate) struct SelectedNativeCorePolicy {
 policy:&'static ApprovedNativeCorePolicy,purpose:NativeCorePurpose,
 originals:[Box<[u8]>;6],classic:[u8;33],pq:Box<[u8]>,
 source_nonce:[u8;32],account_nonce:[u8;32],local:PhantomData<Rc<()>>,
}
impl FixedStartupSourceEvidence {
 fn check_native_core_policy(&self,p:&ApprovedNativeCorePolicy,purpose:NativeCorePurpose,
  originals:&[&[u8];6],classic:&[u8;33],pq:&[u8],now:i64)->Result<(),Error>{
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  if p.bootstrap!=self.selected_bootstrap||p.purpose!=purpose{return Err(Error::Binding)}
  if now<p.not_before_ms||now>=p.expires_ms||p.not_before_ms>=p.expires_ms{return Err(Error::Window)}
  if classic[0]!=5||pq.len()!=2592{return Err(Error::Bounds)}
  use sha2::{Digest,Sha256};
  // Status/request are authenticated by the same account/operation loan and
  // retained verbatim below. They are not a new release approval per request.
  for raw in originals {if raw.is_empty()||raw.len()>1048576{return Err(Error::Bounds)}}
  for (index,expected) in [(0,p.root_digest),(1,p.registration_digest),(3,p.source_digest),(4,p.namespace_digest)]{
   let raw=originals[index];
   if raw.is_empty()||raw.len()>1048576{return Err(Error::Bounds)}
   let digest:[u8;32]=Sha256::digest(raw).into();if digest!=expected{return Err(Error::Binding)}
  }
  let mut native=Sha256::new();native.update(classic);native.update(pq);
  let native:[u8;32]=native.finalize().into();if native!=p.native_identity{return Err(Error::Binding)}
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)
 }
 pub(crate) fn select_native_core_policy(&self,purpose:NativeCorePurpose,originals:&[&[u8];6],
  classic:&[u8;33],pq:&[u8],source_nonce:[u8;32],account_nonce:[u8;32],now:i64)->Result<SelectedNativeCorePolicy,Error>{
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let p=approved_native_core_policies().iter().find(|p|p.bootstrap==self.selected_bootstrap&&p.purpose==purpose).ok_or(Error::ProfileRequired)?;
  self.check_native_core_policy(p,purpose,originals,classic,pq,now)?;
  Ok(SelectedNativeCorePolicy{policy:p,purpose,originals:std::array::from_fn(|i|originals[i].into()),classic:*classic,pq:pq.into(),source_nonce,account_nonce,local:PhantomData})
 }
}
impl SelectedNativeCorePolicy {
 pub(crate) fn recheck(&self,source:&FixedStartupSourceEvidence,purpose:NativeCorePurpose,
  originals:&[&[u8];6],classic:&[u8;33],pq:&[u8],source_nonce:&[u8;32],account_nonce:&[u8;32],now:i64)->Result<(),Error>{
  if self.purpose!=purpose||&self.classic!=classic||self.pq.as_ref()!=pq||&self.source_nonce!=source_nonce||&self.account_nonce!=account_nonce{return Err(Error::Binding)}
  if self.originals.iter().zip(originals).any(|(a,b)|a.as_ref()!=*b){return Err(Error::Binding)}
  source.check_native_core_policy(self.policy,purpose,originals,classic,pq,now)
 }
 // Exact lookup expectation only. A qualified owning resource constructor
 // independently verifies the complete association and holds its true owners.
 pub(crate) fn resource_association(&self)->[u8;32]{self.policy.resource_association}
}
