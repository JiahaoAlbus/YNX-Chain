//! Source-current ABI1, SAME original Java command / LOCAL / reservation.
//! All bytes are public transport, never an authorization or generic signing API.
use super::*;
use crate::source_evidence::{SourceSelection,Error as EvidenceError};
use crate::private_custodian_ffi::CustodyError;
const REQUEST_READY:i32=71;
const EVIDENCE_UNADMITTED:i32=72;
const PROFILE_REQUIRED:i32=73;
const SOURCE_REJECTED:i32=74;
const REQUEST_CANCELLED:i32=75;
fn custody(e:CustodyError)->i32{match e{CustodyError::Thread=>22,CustodyError::Unknown=>16,CustodyError::Memory=>20,_=>SOURCE_REJECTED}}
fn evidence(e:EvidenceError)->i32{match e{EvidenceError::ProfileRequired=>PROFILE_REQUIRED,_=>SOURCE_REJECTED}}
fn bytes(env:&mut jni::Env<'_>,raw:jni::sys::jbyteArray,min:i32,max:i32)->jni::errors::Result<Option<Vec<u8>>>{
 if raw.is_null(){return Ok(None)}
 let array=unsafe{JByteArray::from_raw(env,raw)};let n=env.get_array_length(&array)?;
 if n<min||n>max{return Ok(None)}
 Ok(Some(env.convert_byte_array(&array)?))
}
// Java callbacks happen without a LOCAL borrow. Existing guard then proves
// identity with retained command/input and original IDs; no new actor/open.
fn checked(env:&mut jni::Env<'_>,context:&JObject<'_>,input:&JObject<'_>)->jni::errors::Result<i32>{
 if env.exception_check(){return Ok(16)}
 let command=env.get_field(input,jni::jni_str!("originalCommand"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;"))?.l()?;
 let retained=env.get_field(&command,jni::jni_str!("retainedAppContext"),jni::jni_sig!("Landroid/content/Context;"))?.l()?;
 if !env.is_same_object(context,&retained)?{return Ok(43)}
 env.call_static_method(jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyPrivateCommand"),jni::jni_str!("validateActualContext"),jni::jni_sig!("(Landroid/content/Context;)V"),&[JValue::Object(context)])?;
 guard(env,input,&command,true)
}
unsafe fn enter(raw:*mut jni::sys::JNIEnv,context:jni::sys::jobject,input:jni::sys::jobject,body:impl FnOnce(&mut jni::Env<'_>,&JObject<'_>,&JObject<'_>)->jni::errors::Result<i32>)->i32{
 if let Err(code)=thread_check(false){return code}
 if LOCAL.with(|c|c.try_borrow().ok().and_then(|v|v.as_ref().map(|o|o.status==25)).unwrap_or(false)){return 25}
 if raw.is_null(){return 43}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(raw)};
 let outcome=unowned.with_env_no_catch(|env|->jni::errors::Result<i32>{
  // Leave the exact Throwable pending; no clear, retry or new owner.
  if env.exception_check(){return Ok(16)}
  if context.is_null()||input.is_null(){return Ok(43)}
  let context=unsafe{JObject::from_raw(env,context)};let input=unsafe{JObject::from_raw(env,input)};
  let code=checked(env,&context,&input)?;if code!=44{return Ok(code)}
  body(env,&context,&input)
 }).into_outcome();
 match outcome{jni::Outcome::Ok(code)=>code,jni::Outcome::Err(_)=>fail(),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
unsafe fn begin(raw:*mut jni::sys::JNIEnv,context:jni::sys::jobject,input:jni::sys::jobject,scope:jni::sys::jbyteArray,head:jni::sys::jbyteArray,catalog:jni::sys::jbyteArray,issuer:jni::sys::jbyteArray,target:jni::sys::jbyteArray,out:jni::sys::jbyteArray)->i32{
 unsafe{enter(raw,context,input,|env,context,input|{
  let Some(scope)=bytes(env,scope,1,4096)?else{return Ok(43)};
  let Some(head)=bytes(env,head,64,64)?else{return Ok(43)};
  let Some(catalog)=bytes(env,catalog,64,64)?else{return Ok(43)};
  let Some(issuer)=bytes(env,issuer,1,65536)?else{return Ok(43)};
  let Some(target)=bytes(env,target,1,65536)?else{return Ok(43)};
  if out.is_null(){return Ok(43)}let out=JByteArray::from_raw(env,out);
  if env.get_array_length(&out)?!=32{return Ok(43)}
  let (Ok(head),Ok(catalog))=(std::str::from_utf8(&head),std::str::from_utf8(&catalog))else{return Ok(43)};
  let selection=match SourceSelection::checked(&scope,head,catalog){Ok(s)=>s,Err(e)=>return Ok(evidence(e))};
  let code=checked(env,context,input)?;if code!=44{return Ok(code)}
  let nonce=match loan(|r|r.begin_source_current_request(selection,&issuer,&target)){Ok(Ok(n))=>n,Ok(Err(e))=>return Ok(custody(e)),Err(code)=>return Ok(code)};
  // If a callback revoked/cancelled input or threw, retain the same request.
  let code=checked(env,context,input)?;if code!=44{let _=loan(|r|r.cancel_source_current_request());return Ok(code)}
  let current=match loan(|r|r.original_source_nonce()){Ok(Ok(n))=>n,Ok(Err(e))=>return Ok(custody(e)),Err(code)=>return Ok(code)};
  if current!=nonce{return Ok(SOURCE_REJECTED)}
  let mut signed=[0i8;32];for(i,b)in nonce.iter().enumerate(){signed[i]=*b as i8}
  env.set_byte_array_region(&out,0,&signed)?;Ok(REQUEST_READY)
 })}
}
unsafe fn accept(raw:*mut jni::sys::JNIEnv,context:jni::sys::jobject,input:jni::sys::jobject,response:jni::sys::jbyteArray)->i32{
 unsafe{enter(raw,context,input,|env,context,input|{
  let Some(response)=bytes(env,response,1,393216)?else{return Ok(43)};
  let code=checked(env,context,input)?;if code!=44{return Ok(code)}
  let result=match loan(|r|r.accept_source_current_response(&response)){Ok(Ok(()))=>EVIDENCE_UNADMITTED,Ok(Err(e))=>evidence(e),Err(code)=>code};
  let checked_result=crate::source_evidence::after_callbacks(
   ||{let code=checked(env,context,input).map_err(|_|fail())?;if code!=44{let _=loan(|r|r.cancel_source_current_request());return Err(code)}Ok(())},
   ||{if result!=EVIDENCE_UNADMITTED{return Ok(())}match loan(|r|r.recheck_source_current_evidence()){Ok(Ok(()))=>Ok(()),Ok(Err(e))=>Err(evidence(e)),Err(code)=>Err(code)}});
  Ok(match checked_result{Ok(())=>result,Err(code)=>code})

 })}
}
unsafe fn cancel(raw:*mut jni::sys::JNIEnv,context:jni::sys::jobject,input:jni::sys::jobject)->i32{
 unsafe{enter(raw,context,input,|_env,_context,_input|Ok(match loan(|r|r.cancel_source_current_request()){Ok(Ok(()))=>REQUEST_CANCELLED,Ok(Err(e))=>custody(e),Err(code)=>code}))}
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeSourceCurrentAbiVersion(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i32{boundary(||1)}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeBeginSourceCurrent(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject,scope:jni::sys::jbyteArray,head:jni::sys::jbyteArray,catalog:jni::sys::jbyteArray,issuer:jni::sys::jbyteArray,target:jni::sys::jbyteArray,out:jni::sys::jbyteArray)->i32{boundary(||unsafe{begin(e,context,input,scope,head,catalog,issuer,target,out)})}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeAcceptSourceCurrent(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject,response:jni::sys::jbyteArray)->i32{boundary(||unsafe{accept(e,context,input,response)})}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeCancelSourceCurrent(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject)->i32{boundary(||unsafe{cancel(e,context,input)})}
#[cfg(test)]mod source_jni_controls{
 use super::*;
 #[test]fn source_jni_controls_no_owner_no_creation(){std::thread::spawn(||{
  let e=std::ptr::null_mut();let o=std::ptr::null_mut();
  assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeSourceCurrentAbiVersion(e,o),1);
  assert_eq!(unsafe{begin(e,o,o,o,o,o,o,o,o)},21);assert_eq!(unsafe{accept(e,o,o,o)},21);assert_eq!(unsafe{cancel(e,o,o)},21);
  assert!(LOCAL.with(|c|c.borrow().is_none()));
 }).join().unwrap()}
 #[test]fn source_jni_controls_status_is_not_permission(){assert_eq!(evidence(EvidenceError::ProfileRequired),73);assert_eq!(custody(CustodyError::Unknown),16);assert_eq!(custody(CustodyError::Thread),22);assert_ne!(EVIDENCE_UNADMITTED,0);assert_ne!(REQUEST_READY,0);assert_ne!(REQUEST_CANCELLED,24);}
}
#[cfg(test)]mod source_current_jvm{
 use super::*;use std::ffi::c_void;
 #[link(name="jvm")]unsafe extern "C"{fn JNI_CreateJavaVM(vm:*mut *mut jni::sys::JavaVM,env:*mut *mut c_void,args:*mut c_void)->i32;}
 #[test]fn source_current_jvm_pending_throwable_and_wrong_thread(){
  let mut args=jni::sys::JavaVMInitArgs{version:jni::sys::JNI_VERSION_1_8,nOptions:0,options:std::ptr::null_mut(),ignoreUnrecognized:jni::sys::JNI_FALSE};
  let mut vm:*mut jni::sys::JavaVM=std::ptr::null_mut();let mut raw:*mut c_void=std::ptr::null_mut();
  assert_eq!(unsafe{JNI_CreateJavaVM(&mut vm,&mut raw,&mut args as *mut _ as *mut c_void)},0);
  let e=raw as *mut jni::sys::JNIEnv;let o=std::ptr::null_mut();
  // Actual normal open refuses roots, not a fixture successful controller.
  assert_eq!(open(),1);
  let mut unowned=unsafe{jni::EnvUnowned::from_raw(e)};
  match unowned.with_env_no_catch(|env|->jni::errors::Result<()>{
   assert!(matches!(env.throw_new(jni::jni_str!("java/lang/IllegalStateException"),jni::jni_str!("PUBLIC pending source request control")),Err(jni::errors::Error::JavaException)));
   assert!(env.exception_check());
   assert_eq!(unsafe{begin(e,o,o,o,o,o,o,o,o)},16);assert!(env.exception_check());
   assert_eq!(unsafe{accept(e,o,o,o)},16);assert!(env.exception_check());
   assert_eq!(unsafe{cancel(e,o,o)},16);assert!(env.exception_check());
   // Test alone clears its own exception; production never does.
   env.exception_clear();Ok(())
  }).into_outcome(){jni::Outcome::Ok(())=>{},jni::Outcome::Err(e)=>panic!("{e:?}"),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
  assert_eq!(status(),1);assert!(LOCAL.with(|c|c.borrow().as_ref().unwrap().genesis.is_none()));
  assert_eq!(std::thread::spawn(||unsafe{cancel(std::ptr::null_mut(),std::ptr::null_mut(),std::ptr::null_mut())}).join().unwrap(),22);
  assert_eq!(close(),24);assert_eq!(release_no_effect_for_exit(),36);
  assert_eq!(unsafe{((**vm).v1_4.DestroyJavaVM)(vm)},0);
 }
}
