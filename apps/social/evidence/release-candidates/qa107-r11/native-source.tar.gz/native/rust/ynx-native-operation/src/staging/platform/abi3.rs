//! Private ABI3 unavailable-provider consumer. NOT an authority implementation.
//! No C handle is issued by this source pin. Host probes use only null inputs;
//! they do not create stores, decoded records, dispositions, or receipts.
use std::{convert::Infallible, marker::PhantomData, rc::Rc};

const ABI: u32 = 3;
const HEADER_SHA256: &str = "0c1ff95153565d99388e1e372fb1e9846542cdd2b1b4dfe88f68ac5d5c6668e8";
const C_SHA256: &str = "675b496797a63921eb02ffdea6b6a20fb0e9fdbb655a2faf206e0e697d000834";
const HOST_ARCHIVE_SHA256: &str = "9c372214a4626d07049c3d4f10adb6f413c56519dddcf396899088cc9b2c6eb0";
// Source identity identifies the linked candidate, NEVER a verified source lease.
#[derive(Debug, PartialEq, Eq)]
pub(super) enum Dependency { CheckedStoreAdmission, CoherentSnapshot, ProtectedRecordDecoder,
    FinalProducer, ExactOperationLookup, ResultInspectionAndConsume, IssuedHandleDestruction }
pub(super) fn require_open() -> Result<Infallible, Dependency> {
    Err(Dependency::CheckedStoreAdmission)
}

// Exact future borrow topology, with NO constructors. A real reviewed provider
// must supply these private proofs, not an unsafe pointer/public metadata cast.
enum IssuedNativeProof {}
enum VerifiedLeaseProof {}
struct StoreOwner { issued: IssuedNativeProof, actor: PhantomData<Rc<()>> }
struct Lease<'store> { proof: VerifiedLeaseProof, owner: &'store StoreOwner }
struct Read<'store, 'lease> { issued: IssuedNativeProof, lease: &'lease Lease<'store> }
struct Record<'store, 'lease, 'read> { issued: IssuedNativeProof, read: &'read Read<'store, 'lease> }
struct Intent<'store, 'lease, 'operation> {
    issued: IssuedNativeProof, lease: &'lease Lease<'store>, operation: PhantomData<&'operation mut ()>,
}
struct Write<'store, 'lease, 'operation, 'intent> {
    issued: IssuedNativeProof, intent: &'intent Intent<'store, 'lease, 'operation>,
}
// No success enum/accessor exists in ABI3: do not invent Applied/NotApplied or
// implement Drop on an issued object. REQUIRED leaves non-null inputs owned.
// These private uninhabited borrow types are NOT claimed admitted handles.

#[cfg(all(test, feature = "abi3-host-required-probe", target_os = "macos"))]
#[allow(unsafe_code)]
mod host {
    use super::*;
    use std::ptr::null_mut;
    // Only this audited test module may cross FFI. No raw handle getter, public
    // authorization trait, fixture constructor, or fabricated non-null pointer.
    macro_rules! opaque { ($($name:ident),*) => { $(#[repr(C)] struct $name { _opaque: [u8; 0] })* }; }
    opaque!(Admission, Store, VerifiedLease, ReadHandle, OwnedSnapshot, RecordKey,
        ReadResult, WriteHandle, IntentHandle, OrderedStep, Inbound, Outbound,
        FinishResult, LookupResult);
    unsafe extern "C" {
        fn veil_store_open_required(a: *const Admission, s: *mut *mut Store) -> i32;
        fn veil_native_acquire_snapshot(s: *mut Store, l: *const VerifiedLease, r: *mut *mut ReadHandle) -> i32;
        fn veil_native_read_identity(r: *mut ReadHandle, k: *const RecordKey, o: *mut *mut ReadResult) -> i32;
        fn veil_native_read_ec(r: *mut ReadHandle, k: *const RecordKey, o: *mut *mut ReadResult) -> i32;
        fn veil_native_read_kyber(r: *mut ReadHandle, k: *const RecordKey, o: *mut *mut ReadResult) -> i32;
        fn veil_native_read_session(r: *mut ReadHandle, k: *const RecordKey, o: *mut *mut ReadResult) -> i32;
        fn veil_native_read_signed(r: *mut ReadHandle, k: *const RecordKey, o: *mut *mut ReadResult) -> i32;
        fn veil_native_finish_snapshot(r: *mut *mut ReadHandle, o: *mut *mut OwnedSnapshot) -> i32;
        fn veil_native_begin_checked_write(s: *mut Store, l: *const VerifiedLease, i: *const IntentHandle, w: *mut *mut WriteHandle) -> i32;
        fn veil_native_apply_ordered_step(w: *mut WriteHandle, s: *const OrderedStep) -> i32;
        fn veil_native_append_inbox(w: *mut WriteHandle, i: *const Inbound) -> i32;
        fn veil_native_append_outbox(w: *mut WriteHandle, o: *const Outbound) -> i32;
        fn veil_native_finish_commit(w: *mut *mut WriteHandle, r: *mut *mut FinishResult) -> i32;
        fn veil_native_lookup_operation(s: *mut Store, l: *const VerifiedLease, i: *const IntentHandle, r: *mut *mut LookupResult) -> i32;
        fn veil_native_cancel_operation(w: *mut WriteHandle, i: *const IntentHandle) -> i32;
        fn veil_native_snapshot_read_drop(r: *mut *mut ReadHandle) -> i32;
        fn veil_native_owned_snapshot_drop(r: *mut *mut OwnedSnapshot) -> i32;
        fn veil_native_read_result_drop(r: *mut *mut ReadResult) -> i32;
        fn veil_native_checked_write_drop(r: *mut *mut WriteHandle) -> i32;
        fn veil_native_finish_result_drop(r: *mut *mut FinishResult) -> i32;
        fn veil_native_lookup_result_drop(r: *mut *mut LookupResult) -> i32;
    }
    const REQUIRED: i32 = 1;
    #[test] fn normal_open_refuses_unissued_admission() {
        let mut store = null_mut();
        // SAFETY: the frozen ABI explicitly accepts null admission and valid
        // writable output storage, issues no object, and returns REQUIRED.
        assert_eq!(unsafe { veil_store_open_required(null_mut(), &mut store) }, REQUIRED);
        assert!(store.is_null());
        assert_eq!(require_open(), Err(Dependency::CheckedStoreAdmission));
    }
    #[test] fn all_eight_groups_are_required_not_dispositions() {
        let mut read = null_mut(); let mut owned = null_mut(); let mut record = null_mut();
        let mut write = null_mut(); let mut finish = null_mut(); let mut lookup = null_mut();
        // SAFETY: all borrowed handles are null/unissued; only correctly typed
        // local output slots are passed, no opaque object is dereferenced here.
        unsafe {
            assert_eq!(veil_native_acquire_snapshot(null_mut(), null_mut(), &mut read), REQUIRED);
            for reader in [veil_native_read_identity, veil_native_read_ec, veil_native_read_kyber,
                veil_native_read_session, veil_native_read_signed] {
                assert_eq!(reader(read, null_mut(), &mut record), REQUIRED); assert!(record.is_null());
            }
            assert_eq!(veil_native_finish_snapshot(&mut read, &mut owned), REQUIRED);
            assert_eq!(veil_native_begin_checked_write(null_mut(), null_mut(), null_mut(), &mut write), REQUIRED);
            assert_eq!(veil_native_apply_ordered_step(write, null_mut()), REQUIRED);
            assert_eq!(veil_native_append_inbox(write, null_mut()), REQUIRED);
            assert_eq!(veil_native_append_outbox(write, null_mut()), REQUIRED);
            assert_eq!(veil_native_finish_commit(&mut write, &mut finish), REQUIRED);
            assert_eq!(veil_native_lookup_operation(null_mut(), null_mut(), null_mut(), &mut lookup), REQUIRED);
        }
        assert!(read.is_null() && owned.is_null() && write.is_null() && finish.is_null() && lookup.is_null());
    }
    #[test] fn cancel_is_required_and_unissued_cleanup_is_only_ok() {
        let mut read = null_mut(); let mut owned = null_mut(); let mut record = null_mut();
        let mut write = null_mut(); let mut finish = null_mut(); let mut lookup = null_mut();
        // SAFETY: null handles only, writable double-pointer slots; this is NOT
        // evidence for a non-null destructor, rollback, or cancellation receipt.
        unsafe {
            assert_eq!(veil_native_cancel_operation(write, null_mut()), REQUIRED);
            assert_eq!(veil_native_snapshot_read_drop(&mut read), 0);
            assert_eq!(veil_native_owned_snapshot_drop(&mut owned), 0);
            assert_eq!(veil_native_read_result_drop(&mut record), 0);
            assert_eq!(veil_native_checked_write_drop(&mut write), 0);
            assert_eq!(veil_native_finish_result_drop(&mut finish), 0);
            assert_eq!(veil_native_lookup_result_drop(&mut lookup), 0);
        }
        assert!(read.is_null() && owned.is_null() && record.is_null() && write.is_null() && finish.is_null() && lookup.is_null());
    }
    #[test] fn frozen_identity_does_not_issue_a_lease() {
        assert_eq!(ABI, 3); assert_eq!(HEADER_SHA256.len(), 64);
        assert_eq!(C_SHA256.len(), 64); assert_eq!(HOST_ARCHIVE_SHA256.len(), 64);
        assert_eq!(require_open(), Err(Dependency::CheckedStoreAdmission));
    }
}
