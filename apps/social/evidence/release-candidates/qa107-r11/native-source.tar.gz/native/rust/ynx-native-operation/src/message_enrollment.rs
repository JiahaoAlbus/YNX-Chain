//! Original Root-signed enrollment facts. Never an enrolled resource owner.
use crate::source_evidence::{Error,MessageSourceKeys,FixedStartupSourceEvidence};
use base64::{Engine as _,engine::general_purpose::URL_SAFE_NO_PAD as B64};
use serde::{Deserialize,Serialize};
use sha2::{Digest,Sha256};
use std::{marker::PhantomData,rc::Rc};
use zeroize::Zeroizing;
const DOMAIN:&[u8]=b"YNX/SOCIAL/MESSAGE-ENROLLMENT/V1\0";
const SAFE:i64=9007199254740991;
fn hash(raw:&[u8])->String{Sha256::digest(raw).iter().map(|b|format!("{b:02x}")).collect()}
fn digest(s:&str)->bool{s.len()==64&&s.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b))}
fn label(s:&str,max:usize)->bool{!s.is_empty()&&s.len()<=max&&s.bytes().all(|b|(33..=126).contains(&b))}
fn number(s:&str)->Result<u64,Error>{let n=s.parse::<u64>().map_err(|_|Error::Bounds)?;if n.to_string()!=s{return Err(Error::Canonical)}Ok(n)}
fn bytes(s:&str,min:usize,max:usize)->Result<Zeroizing<Vec<u8>>,Error>{if s.len()>max.div_ceil(3)*4{return Err(Error::Bounds)}let b=B64.decode(s).map_err(|_|Error::Bounds)?;if b.len()<min||b.len()>max||B64.encode(&b)!=s{return Err(Error::Canonical)}Ok(Zeroizing::new(b))}
fn name(s:&str)->Result<(),Error>{let b=bytes(s,34,34)?;if b[..2]!=[0,11]{return Err(Error::Binding)}Ok(())}
fn endpoint(s:&str)->bool{
 // Exact registered transport location only; this does not authenticate a host.
 if !label(s,2048)||!s.starts_with("https://")||s.contains(['#','@','\\']){return false}
 let authority=s[8..].split('/').next().unwrap_or("");
 !authority.is_empty()&&!authority.contains('?')&&authority.bytes().all(|b|b.is_ascii_alphanumeric()||matches!(b,b'.'|b'-'|b':'|b'['|b']'))
}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
pub(crate)struct Registration{
 version:u32,purpose:String,environment:String,bootstrap:String,
 pub(crate)credential_digest:String,pub(crate)administration_domain:String,
 pub(crate)platform_identity_digest:String,pub(crate)protected_service_binary_digest:String,
 pub(crate)protected_service_endpoint:String,pub(crate)protected_service_spki_digest:String,
 pub(crate)device:String,sealed_object_handle:String,salt_key_handle:String,attestation_key_handle:String,counter_handle:String,
 pub(crate)sealed_object_public:String,pub(crate)salt_key_public:String,pub(crate)attestation_key_public:String,pub(crate)counter_public:String,
 pub(crate)object_name:String,pub(crate)salt_name:String,pub(crate)ak_name:String,pub(crate)ak_qualified_name:String,pub(crate)counter_name:String,
 pub(crate)object_policy:String,pub(crate)counter_policy:String,pub(crate)pcr_selection:String,pub(crate)pcr_digest:String,
 counter_floor:String,previous_enrollment_digest:String,enrollment_sequence:String,
 #[serde(rename="notBeforeMS")]not_before:i64,#[serde(rename="expiresMS")]expires:i64,
}
fn canonical(raw:&[u8])->Result<Registration,Error>{
 if raw.is_empty()||raw.len()>32768{return Err(Error::Bounds)}
 let r:Registration=serde_json::from_slice(raw).map_err(|_|Error::Canonical)?;
 let encoded=serde_json::to_string(&r).map_err(|_|Error::Canonical)?.replace('&',"\\u0026").replace('<',"\\u003c").replace('>',"\\u003e").replace('\u{2028}',"\\u2028").replace('\u{2029}',"\\u2029");
 if encoded.as_bytes()!=raw{return Err(Error::Canonical)}Ok(r)
}
impl Registration{
 pub(crate)fn handles(&self)->Result<[u32;4],Error>{
  let mut out=[0;4];for(i,v)in [&self.sealed_object_handle,&self.salt_key_handle,&self.attestation_key_handle,&self.counter_handle].iter().enumerate(){let n=number(v)?;out[i]=u32::try_from(n).map_err(|_|Error::Bounds)?;}
  if out[..3].iter().any(|n|!(0x81000000..=0x81ffffff).contains(n))||!(0x01000000..=0x01ffffff).contains(&out[3])||out[0]==out[1]||out[0]==out[2]||out[1]==out[2]{return Err(Error::Binding)}Ok(out)
 }
 fn shape(&self,bootstrap:&str,credential:&str)->Result<(),Error>{
  if self.version!=1||self.purpose!="SOCIAL_MESSAGE_RESOURCE_ENROLLMENT_V1"||self.environment!="testnet-qa"||!label(&self.bootstrap,512)||self.bootstrap!=bootstrap||self.credential_digest!=credential||!label(&self.administration_domain,512)||!endpoint(&self.protected_service_endpoint)||![&self.credential_digest,&self.platform_identity_digest,&self.protected_service_binary_digest,&self.protected_service_spki_digest,&self.previous_enrollment_digest].iter().all(|v|digest(v)){return Err(Error::Binding)}
  self.handles()?;number(&self.counter_floor)?;if number(&self.enrollment_sequence)?==0{return Err(Error::Binding)}
  if !matches!(self.device.as_str(),"/dev/tpmrm0"|"/dev/tpm0"){return Err(Error::Binding)}
  for p in [&self.sealed_object_public,&self.salt_key_public,&self.attestation_key_public]{bytes(p,2,4096)?;}
  bytes(&self.counter_public,2,2048)?;bytes(&self.pcr_selection,7,256)?;
  for n in [&self.object_name,&self.salt_name,&self.ak_name,&self.ak_qualified_name,&self.counter_name]{name(n)?;}
  for p in [&self.object_policy,&self.counter_policy,&self.pcr_digest]{let b=bytes(p,34,34)?;if b[..2]!=[0,32]{return Err(Error::Binding)}}
  if self.not_before<0||self.expires>SAFE||self.expires<=self.not_before{return Err(Error::Window)}Ok(())
 }
}
// This lifetime pins the already selected original Root/current keys. MU/name,
// hardware possession, independently protected floors and domains remain UNVERIFIED.
pub(crate)struct UnadmittedEnrollment<'a>{
 keys:&'a MessageSourceKeys<'a>,pub(crate)registration:Registration,
 raw:Zeroizing<Vec<u8>>,history:Vec<Zeroizing<Vec<u8>>>,role:u8,local:PhantomData<Rc<()>>,
}
impl UnadmittedEnrollment<'_>{
 pub(crate)fn recheck(&self)->Result<(),Error>{self.keys.recheck()?;let at=crate::source_evidence::now_ms()?;if at<self.registration.not_before||at>=self.registration.expires||at>=self.keys.expires(){return Err(Error::Window)}Ok(())}
 pub(crate)fn raw_digest(&self)->String{hash(&self.raw)}
 pub(crate)fn role(&self)->u8{self.role}
 pub(crate)fn floor(&self)->Result<u64,Error>{number(&self.registration.counter_floor)}
}
pub(crate)fn verify<'a>(keys:&'a MessageSourceKeys<'a>,current:&[u8],predecessors:&[&[u8]],role:u8,expected_digest:&str)->Result<UnadmittedEnrollment<'a>,Error>{
 keys.recheck()?;let role_name=match role{1=>"message-enrollment-issuer",2=>"message-enrollment-anchor",_=>return Err(Error::Binding)};
 let (issuer,anchor)=keys.credential_digests();let credential=if role==1{issuer}else{anchor};
 let total=predecessors.iter().try_fold(current.len(),|n,p|n.checked_add(p.len()).ok_or(Error::Bounds))?;
 if current.is_empty()||current.len()>65536||total>393216||!digest(expected_digest)||hash(current)!=expected_digest{return Err(Error::Bounds)}
 let original_body=keys.verify(current,DOMAIN,role_name)?;let latest=canonical(&original_body)?;latest.shape(keys.bootstrap()?,credential)?;
 let seq=number(&latest.enrollment_sequence)?;
 if usize::try_from(seq-1).map_err(|_|Error::Bounds)?!=predecessors.len(){return Err(Error::Binding)}
 let mut previous="0".repeat(64);let mut history=Vec::new();let mut floor=0;let mut prior_time=None;
 for(i,raw)in predecessors.iter().chain(std::iter::once(&current)).enumerate(){
  if raw.is_empty()||raw.len()>65536{return Err(Error::Bounds)}
  let body=keys.verify(raw,DOMAIN,role_name)?;let r=canonical(&body)?;r.shape(keys.bootstrap()?,credential)?;
  if number(&r.enrollment_sequence)?!=(i as u64)+1||r.previous_enrollment_digest!=previous||r.administration_domain!=latest.administration_domain||r.platform_identity_digest!=latest.platform_identity_digest{return Err(Error::Binding)}
  let next=number(&r.counter_floor)?;if next<floor||prior_time.is_some_and(|t|r.not_before<t){return Err(Error::Binding)}floor=next;prior_time=Some(r.not_before);previous=hash(raw);
  if i<predecessors.len(){history.push(Zeroizing::new(raw.to_vec()));}
 }
 // Sequence1's Root signature is the original authorized genesis carrier.
 // Historical expiry is not extended and does not renew the live operation.
 let result=UnadmittedEnrollment{keys,registration:latest,raw:Zeroizing::new(current.to_vec()),history,role,local:PhantomData};result.recheck()?;Ok(result)
}

// Startup borrows the independent release-selected Source evidence directly.
// It does not create MessageSourceKeys/AccountAttempt or require an already
// produced Source. Signature mathematics remains unadmitted resource evidence.
pub(crate)struct StartupEnrollment<'a>{
 evidence:&'a FixedStartupSourceEvidence,pub(crate)registration:Registration,
 raw:Zeroizing<Vec<u8>>,history:Vec<Zeroizing<Vec<u8>>>,role:u8,local:PhantomData<Rc<()>>,
}
impl StartupEnrollment<'_>{
 pub(crate)fn match_source_role(&self,source:&FixedStartupSourceEvidence,role:u8)->Result<(),Error>{
  self.recheck()?;if self.role!=role{return Err(Error::Binding)}
  if self.evidence.enrollment_binding(role)?!=source.enrollment_binding(role)?{return Err(Error::Binding)}
  self.recheck()
 }
 pub(crate)fn with_sealed_custody_input<R>(&self,run:impl FnOnce(&crate::source_infrastructure::MessageSealedRawInput)->R)->Result<R,Error>{
  self.recheck()?;
  let r=&self.registration;
  let fields=[&r.sealed_object_public,&r.salt_key_public,&r.attestation_key_public,&r.counter_public,&r.object_policy,&r.counter_policy,&r.pcr_selection,&r.pcr_digest,&r.object_name,&r.salt_name,&r.ak_name,&r.ak_qualified_name,&r.counter_name];
  let mut decoded=Vec::with_capacity(13);
  for(i,raw)in fields.iter().enumerate(){decoded.push(bytes(raw,2,if i<3{4096}else if i==3{2048}else if i==6{256}else{34})?);}
  // Capture the monotonic sample before calculating signed remaining time.
  // No credential renewal and no independent floor is manufactured here.
  let sampled=crate::source_infrastructure::message_monotonic_ns().map_err(|_|Error::Window)?;
  let now=crate::source_evidence::now_ms()?;
  let remaining=r.expires.checked_sub(now).filter(|n|*n>0).ok_or(Error::Window)?;
  let deadline=sampled.checked_add(u64::try_from(remaining).map_err(|_|Error::Window)?.checked_mul(1000000).ok_or(Error::Window)?).ok_or(Error::Window)?;
  let input=crate::source_infrastructure::MessageSealedRawInput{
   device:match r.device.as_str(){"/dev/tpmrm0"=>0,"/dev/tpm0"=>1,_=>return Err(Error::Binding)},handles:r.handles()?,
   fields:std::array::from_fn(|i|crate::source_infrastructure::MessageOriginalSpan{raw:decoded[i].as_ptr(),size:decoded[i].len()}),
   counter_floor:number(&r.counter_floor)?,monotonic_deadline_ns:deadline,not_before_ms:r.not_before,expires_ms:r.expires,
  };
  // Returning a partial resource cannot be lost at a late current fence.
  // The owning constructor rechecks after retaining its returned original.
  Ok(run(&input))
 }
 pub(crate)fn recheck(&self)->Result<(),Error>{
  self.evidence.enrollment_binding(self.role)?;
  let at=crate::source_evidence::now_ms()?;
  if at<self.registration.not_before||at>=self.registration.expires{return Err(Error::Window)}Ok(())
 }
 pub(crate)fn raw_digest(&self)->String{hash(&self.raw)}
 pub(crate)fn floor(&self)->Result<u64,Error>{number(&self.registration.counter_floor)}
}
pub(crate)fn verify_startup<'a>(evidence:&'a FixedStartupSourceEvidence,current:&[u8],predecessors:&[&[u8]],role:u8,expected_digest:&str)->Result<StartupEnrollment<'a>,Error>{
 let (bootstrap,credential)=evidence.enrollment_binding(role)?;
 let total=predecessors.iter().try_fold(current.len(),|n,p|n.checked_add(p.len()).ok_or(Error::Bounds))?;
 if current.is_empty()||current.len()>65536||predecessors.len()>255||total>393216||!digest(expected_digest)||hash(current)!=expected_digest{return Err(Error::Bounds)}
 let latest=canonical(&evidence.verify_enrollment_original(current,role)?)?;latest.shape(bootstrap,&credential)?;
 let seq=number(&latest.enrollment_sequence)?;
 if usize::try_from(seq-1).map_err(|_|Error::Bounds)?!=predecessors.len(){return Err(Error::Binding)}
 let mut previous="0".repeat(64);let mut history=Vec::new();let mut floor=0;let mut prior_time=None;
 for(i,raw)in predecessors.iter().chain(std::iter::once(&current)).enumerate(){
  if raw.is_empty()||raw.len()>65536{return Err(Error::Bounds)}
  let r=canonical(&evidence.verify_enrollment_original(raw,role)?)?;r.shape(bootstrap,&credential)?;
  if number(&r.enrollment_sequence)?!=(i as u64)+1||r.previous_enrollment_digest!=previous||r.administration_domain!=latest.administration_domain||r.platform_identity_digest!=latest.platform_identity_digest{return Err(Error::Binding)}
  let next=number(&r.counter_floor)?;if next<floor||prior_time.is_some_and(|t|r.not_before<t){return Err(Error::Binding)}floor=next;prior_time=Some(r.not_before);previous=hash(raw);
  if i<predecessors.len(){history.push(Zeroizing::new(raw.to_vec()));}
 }
 let result=StartupEnrollment{evidence,registration:latest,raw:Zeroizing::new(current.to_vec()),history,role,local:PhantomData};result.recheck()?;Ok(result)
}

// Original public registration snapshot. Parsing is never admission, current
// head/floor proof or a factory. All five transport fields retain original bytes.
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
struct EnrollmentTransport{version:u32,issuer_current:String,issuer_history:Vec<String>,anchor_current:String,anchor_history:Vec<String>}
pub(crate)struct OriginalEnrollmentRecords{
 pub(crate)issuer_current:Zeroizing<Vec<u8>>,pub(crate)issuer_predecessors:Vec<Zeroizing<Vec<u8>>>,
 pub(crate)anchor_current:Zeroizing<Vec<u8>>,pub(crate)anchor_predecessors:Vec<Zeroizing<Vec<u8>>>,
 local:PhantomData<Rc<()>>,
}
impl OriginalEnrollmentRecords{
 // Fixed Native startup carries the complete original spans directly. No
 // signed envelope/body is reconstructed to manufacture a transport carrier.
 pub(crate)fn copy_originals(issuer:&[u8],issuer_history:&[&[u8]],anchor:&[u8],anchor_history:&[&[u8]])->Result<Self,Error>{
  if issuer_history.len()>255||anchor_history.len()>255{return Err(Error::Bounds)}
  let mut total=0usize;
  let mut copy=|raw:&[u8]|->Result<Zeroizing<Vec<u8>>,Error>{
   if raw.is_empty()||raw.len()>65536{return Err(Error::Bounds)}
   total=total.checked_add(raw.len()).ok_or(Error::Bounds)?;if total>393216{return Err(Error::Bounds)}
   Ok(Zeroizing::new(raw.to_vec()))
  };
  let issuer_current=copy(issuer)?;let mut issuer_predecessors=Vec::new();
  issuer_predecessors.try_reserve_exact(issuer_history.len()).map_err(|_|Error::Bounds)?;
  for raw in issuer_history{issuer_predecessors.push(copy(raw)?);}
  let anchor_current=copy(anchor)?;let mut anchor_predecessors=Vec::new();
  anchor_predecessors.try_reserve_exact(anchor_history.len()).map_err(|_|Error::Bounds)?;
  for raw in anchor_history{anchor_predecessors.push(copy(raw)?);}
  Ok(Self{issuer_current,issuer_predecessors,anchor_current,anchor_predecessors,local:PhantomData})
 }
 pub(crate)fn parse(raw:&[u8])->Result<Self,Error>{
  if raw.is_empty()||raw.len()>393216{return Err(Error::Bounds)}
  let t:EnrollmentTransport=serde_json::from_slice(raw).map_err(|_|Error::Canonical)?;
  let encoded=serde_json::to_vec(&t).map_err(|_|Error::Canonical)?;
  // Values are base64url ASCII; no JSON escape normalization is necessary.
  if encoded.as_slice()!=raw{return Err(Error::Canonical)}
  if t.version!=1{return Err(Error::Binding)}
  if t.issuer_history.len()>255||t.anchor_history.len()>255{return Err(Error::Bounds)}
  let mut total=0usize;
  let mut decode=|v:&str|->Result<Zeroizing<Vec<u8>>,Error>{
   let b=bytes(v,1,65536)?;total=total.checked_add(b.len()).ok_or(Error::Bounds)?;
   if total>393216{return Err(Error::Bounds)}Ok(b)
  };
  let issuer_current=decode(&t.issuer_current)?;
  let mut issuer_predecessors=Vec::new();issuer_predecessors.try_reserve_exact(t.issuer_history.len()).map_err(|_|Error::Bounds)?;
  for v in &t.issuer_history{issuer_predecessors.push(decode(v)?);}
  let anchor_current=decode(&t.anchor_current)?;
  let mut anchor_predecessors=Vec::new();anchor_predecessors.try_reserve_exact(t.anchor_history.len()).map_err(|_|Error::Bounds)?;
  for v in &t.anchor_history{anchor_predecessors.push(decode(v)?);}
  Ok(Self{issuer_current,issuer_predecessors,anchor_current,anchor_predecessors,local:PhantomData})
 }
}
