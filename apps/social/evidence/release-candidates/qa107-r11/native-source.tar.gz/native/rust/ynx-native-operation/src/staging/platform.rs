//! Closed native recovery seam; real authority/SQL/protection remain REQUIRED.
mod abi3;
mod abi5;
// Crate-only borrowed owner seam; no acquisition or pointer constructor.
#[cfg(feature="abi5-final-native-link")]
pub(crate) use abi5::{SourceHeldOriginal,SourcePreparedOwner,SourceCommitOwner,SourceOwnerError};

#[cfg(all(test,feature="abi5-final-native-link"))]
mod source_owner_seam_controls {
 use crate::staging::platform::{SourceHeldOriginal,SourcePreparedOwner,SourceCommitOwner,SourceOwnerError};
 // Compile the exact supplier borrow surface without creating custody or
 // invoking any native validation, recovery, acknowledgement or signature.
 fn recover<'held,'op>(held:&mut SourceHeldOriginal<'held,'op>)->Result<SourceCommitOwner<'held,'op>,SourceOwnerError>{
  held.validate()?;held.recover()
 }
 fn acknowledge<'op>(commit:&mut SourceCommitOwner<'_,'op>,held:&mut SourceHeldOriginal<'_,'op>)->Result<(),SourceOwnerError>{
  commit.acknowledge(held)
 }
 fn prepared<'borrow,'op>(owner:&'borrow SourcePreparedOwner<'op>)->&'borrow SourcePreparedOwner<'op>{owner}
 #[test] fn source_owner_seam_controls_borrowed_types_compile_without_acquisition(){
  let _=recover;let _=acknowledge;let _=prepared;
 }
}
mod custody;
use custody::ActorCustody;
use super::*;
use std::{collections::{BTreeMap,VecDeque},task::{Context,Poll}};
use spqr::ynx_operation::{LocalComputationIdentity,Stopped};
#[derive(Clone,Copy,PartialEq,Eq)]struct LeaseBinding{store:u128,session:u128,incarnation:u64,generation:u64,operation:u64,context:u64,route:u64,device_authorization:u64,revocation_checkpoint:u64,source_abi:[u8;32]}
enum NativeVerifiedAuthority{#[cfg(feature="abi5-final-native-link")]Held(Rc<NativeSnapshotOwner>)}
enum Authority{Required,Verified(NativeVerifiedAuthority),#[cfg(test)]Fixture}
struct NativeLease{binding:LeaseBinding,authority:Authority}
#[cfg(test)]thread_local!{static LEASE_RELEASES:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}
#[cfg(test)]impl Drop for NativeLease{fn drop(&mut self){LEASE_RELEASES.with(|n|n.set(n.get()+1));}}
#[cfg(test)]pub(super)fn fixture_lease_releases()->usize{LEASE_RELEASES.with(std::cell::Cell::get)}
pub(crate) enum PortError{PanicRetained,RequiredNativeSnapshotLease,RequiredNativeSourceAuthentication,RequiredCheckedSqlProducer,RequiredNoetherNativeRecordProtector,RequiredSnapshotBudget,Binding,Capacity,Authentication,Rejected,Unknown,Consumed,Cancelled,Revoked,Retired,Held,RequiredOnceReceipt}
enum QueueKind{Inbound,Outbound}
// No caller metadata can create a production reservation/authority proof.
enum NativeVerifiedReservation{#[cfg(feature="abi5-final-native-link")]Held(Rc<NativeSnapshotOwner>)}
enum ReservationSource{Required,Verified(NativeVerifiedReservation),#[cfg(test)]Fixture}
struct SnapshotReservation{snapshot_bytes:usize,source:ReservationSource}
const MAX_SNAPSHOT_BYTES:usize=8*1024*1024;
const PENDING_RESERVED_BYTES:usize=2*MAX_BYTES+3*MAX_WIRE; // includes private transaction journal/wire copies
const MAX_RETAINED_BYTES:usize=32*(MAX_SNAPSHOT_BYTES+PENDING_RESERVED_BYTES);
struct ComputationAdmission{local:LocalComputationIdentity,binding:LeaseBinding}
pub(crate) struct NativeSnapshotHandle{stage:StagedOperation,signed:Box<dyn SignedPreKeyStore>,lease:NativeLease,queue:QueueKind,computation:Option<ComputationAdmission>,budget:Option<SnapshotReservation>}
pub(crate) struct NativeStagingPorts<'op>{pub(crate) identity:&'op mut dyn IdentityKeyStore,pub(crate) ec:&'op mut dyn PreKeyStore,pub(crate) kyber:&'op mut dyn KyberPreKeyStore,pub(crate) sessions:&'op mut dyn SessionStore,pub(crate) signed:&'op dyn SignedPreKeyStore,pub(crate) scope:&'op spqr::ynx_operation::CallScope}
fn uncertain(g:&Gate)->bool{g.sync_uncertainty();g.1.has_uncertain_outcome()||g.0.borrow().phase==Phase::Unknown}
fn stopped_error(e:Stopped)->PortError{match e{Stopped::Unknown=>PortError::Unknown,Stopped::Revoked=>PortError::Revoked,Stopped::Cancelled=>PortError::Cancelled,Stopped::Binding=>PortError::Binding,_=>PortError::RequiredNativeSourceAuthentication}}
// Failure retains sole complete predecode input/lease/gate owners. A codec
// failure wipes consumed serialized input; original wire remains gate-owned.
struct CohortSnapshotFailure{error:PortError,input:Option<super::cohort::AuthenticatedOwnedCohortInput>,gate:Gate,lease:NativeLease}
impl NativeSnapshotHandle{
 fn from_cohort_input(input:super::cohort::AuthenticatedOwnedCohortInput,gate:Gate,lease:NativeLease,queue:QueueKind,budget:Option<SnapshotReservation>,inbound:Option<&[u8]>)->Result<Self,CohortSnapshotFailure>{
  let mut input=Some(input);
  let admission=(||{
   // No awaited callback may precede original inbound retention, including
   // future native decoding/acquisition adapters at this controlled entry.
   match (&queue,inbound){(QueueKind::Inbound,Some(w))=>gate.retain_inbound(w).map_err(|_|if uncertain(&gate){PortError::Unknown}else{PortError::Rejected})?,(QueueKind::Outbound,None)=>{},_=>return Err(PortError::Binding)}
   if uncertain(&gate){return Err(PortError::Unknown)}
   match &lease.authority{Authority::Required=>return Err(PortError::RequiredNativeSourceAuthentication),Authority::Verified(p)=>match p{#[cfg(feature="abi5-final-native-link")]NativeVerifiedAuthority::Held(owner)=>owner.current().map_err(|_|PortError::Unknown)?},#[cfg(test)]Authority::Fixture=>{}}
   let owner=super::cohort::decode(input.take().expect("sole input owner")).map_err(|_|PortError::Authentication)?;
   owner.require_source(&lease.binding.source_abi).map_err(|_|PortError::Binding)?;
   owner.into_staging(gate.clone()).map_err(|_|PortError::Binding)
  })();
  match admission{Ok((stage,signed))=>Ok(Self{stage,signed,lease,queue,computation:None,budget}),Err(error)=>Err(CohortSnapshotFailure{error,input,gate,lease})}
 }

 pub(crate) fn stores(&mut self)->NativeStagingPorts<'_>{NativeStagingPorts{identity:&mut self.stage.identity,ec:&mut self.stage.ec,kyber:&mut self.stage.kyber,sessions:&mut self.stage.sessions,signed:self.signed.as_ref(),scope:&self.stage.gate.1}}
 // Only these controlled executor entries create the local computation identity.
 // It is not source/device authority; that production constructor is missing.
 pub(crate) async fn execute_receive<R:rand::Rng+rand::CryptoRng>(&mut self,remote:&ProtocolAddress,local:&ProtocolAddress,wire:&CiphertextMessage,rng:&mut R)->Result<(),PortError>{
  // Original inbound wire is held before any awaited store/auth callback.
  self.stage.gate.retain_selected_inbound(wire).map_err(|_|if uncertain(&self.stage.gate){PortError::Unknown}else{PortError::Rejected})?;
  let scope=self.stage.gate.1.clone();
  let result=scope.guard(async{
   let clear=message_decrypt_with_scope(wire,remote,local,&mut self.stage.sessions,&mut self.stage.identity,&mut self.stage.ec,self.signed.as_ref(),&mut self.stage.kyber,rng,Some(&scope)).await?;
   self.stage.prepare(wire.serialize(),Some(clear))
  }).await;
  self.finish_computation(result)
 }
 pub(crate) async fn execute_send<R:rand::Rng+rand::CryptoRng>(&mut self,remote:&ProtocolAddress,local:&ProtocolAddress,clear:&[u8],now:std::time::SystemTime,rng:&mut R)->Result<(),PortError>{
  let scope=self.stage.gate.1.clone();
  let result=scope.guard(async{
   // Explicit selection; default-retainer failure NEVER falls back to old API.
   let wire=message_encrypt_with_native_retention(clear,remote,local,&mut self.stage.sessions,&mut self.stage.identity,now,rng,Some(&scope)).await?;
   if !self.stage.gate.0.borrow().generated_wire{return Err(stopped())}
   self.stage.prepare(wire.serialize(),None)
  }).await;
  self.finish_computation(result)
 }
 fn finish_computation(&mut self,result:Result<R<()>,Stopped>)->Result<(),PortError>{
  match result{Err(e)=>{self.stage.reject();return Err(if uncertain(&self.stage.gate){PortError::Unknown}else{stopped_error(e)})},Ok(Err(_))=>{self.stage.reject();return Err(if uncertain(&self.stage.gate){PortError::Unknown}else{PortError::Authentication})},Ok(Ok(()))=>{}}
  let local=self.stage.gate.1.completed_computation_identity().map_err(|e|if uncertain(&self.stage.gate){PortError::Unknown}else{stopped_error(e)})?;
  match &self.lease.authority{Authority::Required=>return Err(PortError::RequiredNativeSourceAuthentication),Authority::Verified(p)=>match p{#[cfg(feature="abi5-final-native-link")]NativeVerifiedAuthority::Held(owner)=>owner.current().map_err(|_|PortError::Unknown)?},#[cfg(test)]Authority::Fixture=>{}}
  self.computation=Some(ComputationAdmission{local,binding:self.lease.binding});Ok(())
 }
 fn reserved_bytes(&self)->Result<usize,PortError>{
  let b=self.budget.as_ref().ok_or(PortError::RequiredSnapshotBudget)?;
  match &b.source{ReservationSource::Required=>return Err(PortError::RequiredSnapshotBudget),ReservationSource::Verified(p)=>match p{#[cfg(feature="abi5-final-native-link")]NativeVerifiedReservation::Held(owner)=>owner.current().map_err(|_|PortError::Unknown)?},#[cfg(test)]ReservationSource::Fixture=>{}}
  if b.snapshot_bytes>MAX_SNAPSHOT_BYTES{return Err(PortError::Capacity)}
  b.snapshot_bytes.checked_add(PENDING_RESERVED_BYTES).ok_or(PortError::Capacity)
 }
}
// Failure RETURNS the sole complete native owner. No JS/plaintext export.
pub(crate) struct RetainFailure{error:PortError,snapshot:NativeSnapshotHandle}
pub(crate) struct NativePendingHandle{actor:u64,issuer:Rc<()>,slot:u64}
// No public/metadata constructor; the only inhabited branch owns an actual
// C independently verified terminal root, checked before each proof use.
struct NativeVerifiedFinalCommit{#[cfg(feature="abi5-final-native-link")]owner:abi5::NativeFinalCommitOwner,#[cfg(not(feature="abi5-final-native-link"))]missing:std::convert::Infallible}
impl NativeVerifiedFinalCommit{
 fn current(&self)->Result<(),PortError>{
  #[cfg(feature="abi5-final-native-link")]{self.owner.current().map_err(|_|PortError::Unknown)}
  #[cfg(not(feature="abi5-final-native-link"))]{match self.missing{}}
 }
 fn close(&mut self)->Result<(),PortError>{
  #[cfg(feature="abi5-final-native-link")]{self.owner.close().map_err(|_|PortError::Unknown)}
  #[cfg(not(feature="abi5-final-native-link"))]{match self.missing{}}
 }
}
struct PrivateDurableReceipt{proof:NativeVerifiedFinalCommit,binding:LeaseBinding}
enum Completion{Prepared,Unknown,Rejected,Applied(PrivateDurableReceipt),#[cfg(test)]FixtureApplied}
struct Retained{snapshot:NativeSnapshotHandle,completion:Completion,submitted:bool,consumed:bool,reserved_bytes:usize,definitely_not_applied:bool}
pub(crate) enum FinalStatus{Applied,Unknown,Rejected,Required,Held,#[cfg(test)]FixtureApplied}
pub(crate) struct NativeCommittedOutput{ciphertext:Vec<u8>,plaintext:Option<Vec<u8>>,kind:Option<super::output::SelectedWireKind>,outbound:bool}
pub(crate) enum RetireAcknowledgement{ConsumedOutput,DefiniteRejection}
pub(crate) struct NativeStoreBridge{actor:u64,issuer:Rc<()>,next:u64,backend:NativeBackend,pending:RetentionLedger<u64,Retained>,retained_bytes:usize,tombstones:VecDeque<u64>,custody:Rc<RefCell<ActorCustody>>}

struct RetentionLedger<K:Ord,V>{entries:BTreeMap<K,Option<V>>}
impl<K:Ord,V> RetentionLedger<K,V>{
 fn new()->Self{Self{entries:BTreeMap::new()}}
 fn reserve(&mut self,key:K)->Option<&mut Option<V>>{let cell=self.entries.entry(key).or_insert(None);if cell.is_some(){None}else{Some(cell)}}
 fn get(&self,key:&K)->Option<&V>{self.entries.get(key).and_then(Option::as_ref)}
 fn get_mut(&mut self,key:&K)->Option<&mut V>{self.entries.get_mut(key).and_then(Option::as_mut)}
 fn contains_key(&self,key:&K)->bool{self.get(key).is_some()}
 fn remove(&mut self,key:&K)->Option<V>{self.entries.remove(key).flatten()}
 fn values_mut(&mut self)->impl Iterator<Item=&mut V>{self.entries.values_mut().filter_map(Option::as_mut)}
 fn len(&self)->usize{self.entries.values().filter(|x|x.is_some()).count()}
 fn is_empty(&self)->bool{self.len()==0}
 #[cfg(test)]fn insert(&mut self,key:K,value:V)->Option<V>{self.entries.insert(key,Some(value)).flatten()}
}
fn contain_retention<T>(f:impl FnOnce()->Result<T,PortError>)->Result<T,PortError>{
 match std::panic::catch_unwind(std::panic::AssertUnwindSafe(f)){
  Ok(r)=>r,Err(payload)=>{
   // Never unwind a panic-payload destructor across the caller/native boundary.
   // Double-panic payloads require fail-stop containment, not recovery success.
   if let Err(_nested)=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||drop(payload))){std::process::abort()}
   Err(PortError::PanicRetained)
  }
 }
}

enum NativeBackend{Unavailable,#[cfg(feature="abi5-final-native-link")]Qualified(Rc<NativeSnapshotOwner>),#[cfg(test)]Fixture(FixtureSql)}
fn synchronize(r:&mut Retained)->bool{
 r.snapshot.stage.gate.sync_uncertainty();
 if r.snapshot.stage.gate.0.borrow().phase==Phase::Unknown{if !matches!(r.completion,Completion::Applied(_)){r.completion=Completion::Unknown;}r.definitely_not_applied=false;true}else{false}
}
fn validate_computation(s:&NativeSnapshotHandle)->Result<(),PortError>{
 s.stage.gate.sync_uncertainty();
 if s.stage.gate.1.has_uncertain_outcome(){return Err(PortError::Unknown)}
 let c=s.computation.as_ref().ok_or(PortError::RequiredNativeSourceAuthentication)?;
 if c.binding!=s.lease.binding{return Err(PortError::Binding)}
 c.local.check_current(&s.stage.gate.1).map_err(stopped_error)?;
 match &s.lease.authority{Authority::Required=>Err(PortError::RequiredNativeSourceAuthentication),Authority::Verified(p)=>match p{#[cfg(feature="abi5-final-native-link")]NativeVerifiedAuthority::Held(owner)=>owner.current().map_err(|_|PortError::Unknown)},#[cfg(test)]Authority::Fixture=>Ok(())}
}
impl NativeStoreBridge{
 // Normal selected receiving code: inventory allocation alone issues no proof.
 // open_platform/acquire_snapshot/issuer factories remain REQUIRED.
 #[cfg(feature="abi5-final-native-link")]fn owned_supervisor<'op>(&self)->Result<abi5::NativeActorSupervisor<'op>,PortError>{abi5::retain_actual_actor(self)}

 pub(crate) fn open_platform()->Result<Self,PortError>{
  match abi5::require_open(){Ok(never)=>match never{},Err(_)=>Err(PortError::RequiredCheckedSqlProducer)}
 }
 pub(crate) fn acquire_snapshot(&mut self)->Result<NativeSnapshotHandle,PortError>{
  #[cfg(feature="abi5-final-native-link")]if let NativeBackend::Qualified(owner)=&self.backend{
   owner.current().map_err(|_|PortError::Unknown)?;if self.next!=0{return Err(PortError::Consumed)}self.next=1;
   let mut p=owner.projection().map_err(|_|PortError::Unknown)?;
   let input=super::cohort::acquire_from_original(owner.clone(),&mut p).map_err(|_|PortError::Authentication)?;
   let b=p.binding;let binding=LeaseBinding{store:b[0]as u128,session:b[1]as u128,incarnation:b[2],generation:b[3],operation:b[4],context:b[5],route:b[6],device_authorization:b[7],revocation_checkpoint:b[8],source_abi:p.source_abi};
   let scope=Rc::new(spqr::ynx_operation::CallScope::local_computation_only(b));
   let gate=Gate(Rc::new(RefCell::new(Pending{phase:Phase::Working,binding:b,bytes:0,journal:Vec::new(),original_ciphertext:None,generated_wire:false,selected_wire_kind:None,plaintext:None,#[cfg(test)]trigger:None,#[cfg(test)]pending:false})),scope);
   let wire=if p.inbound_wire.is_empty(){None}else{Some(p.inbound_wire.as_slice())};
   let queue=match p.queue{1=>QueueKind::Inbound,2=>QueueKind::Outbound,_=>return Err(PortError::Binding)};
   let snapshot=NativeSnapshotHandle::from_cohort_input(input,gate,NativeLease{binding,authority:Authority::Verified(NativeVerifiedAuthority::Held(owner.clone()))},queue,Some(SnapshotReservation{snapshot_bytes:p.reserved_bytes,source:ReservationSource::Verified(NativeVerifiedReservation::Held(owner.clone()))}),wire).map_err(|e|e.error)?;
   owner.current().map_err(|_|PortError::Unknown)?;return Ok(snapshot)
  }Err(PortError::RequiredNativeSnapshotLease)
 }
 fn handle_ok(&self,h:&NativePendingHandle)->Result<(),PortError>{if h.actor!=self.actor||!Rc::ptr_eq(&h.issuer,&self.issuer){return Err(PortError::Binding)}self.custody.borrow().check_thread()?;if !self.pending.contains_key(&h.slot)&&self.custody.borrow().route(h.slot).is_none(){return Err(if h.slot<=self.next{PortError::Retired}else{PortError::Binding})}Ok(())}

 pub(crate) fn retain_prepared(&mut self,snapshot:NativeSnapshotHandle)->Result<NativePendingHandle,RetainFailure>{
  let mut owner=Some(snapshot);
  match self.retain_in_place(&mut owner){Ok(h)=>Ok(h),Err(error)=>Err(RetainFailure{error,snapshot:owner.take().expect("failed retention keeps same owner")})}
 }
 pub(super) fn retain_in_place(&mut self,owner:&mut Option<NativeSnapshotHandle>)->Result<NativePendingHandle,PortError>{
  contain_retention(||self.retain_in_place_inner(owner))
 }
 fn retain_in_place_inner(&mut self,owner:&mut Option<NativeSnapshotHandle>)->Result<NativePendingHandle,PortError>{
  let snapshot=owner.as_ref().ok_or(PortError::Consumed)?;
  snapshot.stage.gate.sync_uncertainty();
  if snapshot.stage.gate.0.borrow().phase==Phase::Unknown{return Err(PortError::Unknown)}
  if snapshot.stage.gate.0.borrow().phase!=Phase::Prepared{return Err(PortError::Rejected)}
  let mut custody=self.custody.borrow_mut();custody.check_thread()?;
  if custody.closing{return Err(PortError::Cancelled)}
  if custody.count()>=32{return Err(PortError::Capacity)}
  let bytes=snapshot.reserved_bytes()?;
  if bytes>MAX_RETAINED_BYTES.saturating_sub(custody.total_bytes().ok_or(PortError::Capacity)?){return Err(PortError::Capacity)}
  match &self.backend{NativeBackend::Unavailable=>return Err(PortError::RequiredNativeSourceAuthentication),#[cfg(feature="abi5-final-native-link")]NativeBackend::Qualified(owner)=>{owner.current().map_err(|_|PortError::Unknown)?;match &snapshot.lease.authority{Authority::Verified(NativeVerifiedAuthority::Held(lease)) if Rc::ptr_eq(owner,lease)=>{},_=>return Err(PortError::Binding)}},#[cfg(test)]NativeBackend::Fixture(f)=>if snapshot.lease.binding!=f.binding{return Err(PortError::Binding)}}
  validate_computation(snapshot)?;
  let slot=self.next.checked_add(1).ok_or(PortError::Capacity)?;
  let retained_bytes=self.retained_bytes.checked_add(bytes).ok_or(PortError::Capacity)?;
  let ledger_count=custody.ledger_count.checked_add(1).ok_or(PortError::Capacity)?;
  let ledger_bytes=custody.ledger_bytes.checked_add(bytes).ok_or(PortError::Capacity)?;
  let handle=NativePendingHandle{actor:self.actor,issuer:self.issuer.clone(),slot};
  // Reserve BTree allocation and borrow receiver cell BEFORE taking snapshot.
  // All source/gate/custody checks above leave caller's Option intact.
  let receiver=self.pending.reserve(slot).ok_or(PortError::Binding)?;
  let snapshot=owner.take().expect("borrowed owner checked under exclusive borrow");
  // Nonallocating installation into EMPTY receiver; no await, callback,
  // RefCell borrow, fallible arithmetic or destructor in this transfer tail.
  *receiver=Some(Retained{snapshot,completion:Completion::Prepared,submitted:false,consumed:false,reserved_bytes:bytes,definitely_not_applied:false});
  self.next=slot;self.retained_bytes=retained_bytes;custody.ledger_count=ledger_count;custody.ledger_bytes=ledger_bytes;
  Ok(handle)
 }
 pub(crate) fn poll_final(&mut self,h:&mut NativePendingHandle,cx:&mut Context<'_>)->Poll<Result<FinalStatus,PortError>>{
  if let Err(e)=self.handle_ok(h){return Poll::Ready(Err(e))}
  if let Some(status)=self.routed_poll(h){return Poll::Ready(Ok(status))}
  let r=self.pending.get_mut(&h.slot).expect("checked native slot");
  let uncertain=synchronize(r);
  // Same-owner UNKNOWN may observe an independent terminal, never replay or
  // regain permission. C retains exact ciphertext/lease/intent; Rust retains
  // partial finals before every late fence. The status remains UNKNOWN.
  #[cfg(feature="abi5-final-native-link")]
  if r.submitted&&!r.consumed&&uncertain&&matches!(r.completion,Completion::Prepared|Completion::Unknown){
   if let NativeBackend::Qualified(owner)=&self.backend{owner.observe_unknown_lookup();}
  }
  // Scope-origin UNKNOWN cannot be erased by a fixture SQL receipt or rebind.
  if r.snapshot.stage.gate.1.has_uncertain_outcome(){return Poll::Ready(Ok(FinalStatus::Unknown))}
  if let Err(e)=validate_computation(&r.snapshot){
   if uncertain{return Poll::Ready(Ok(FinalStatus::Unknown))}
   // The submission marker precedes the effect. Loss of currentness cannot
   // establish non-application when no authenticated terminal result exists.
   // Keep known final receipts/rejections intact; only unresolved submission
   // becomes UNKNOWN, exactly as at the post-lookup validation fence below.
   if r.submitted&&matches!(r.completion,Completion::Prepared|Completion::Unknown){
    r.completion=Completion::Unknown;
    r.snapshot.stage.gate.0.borrow_mut().phase=Phase::Unknown;
    r.definitely_not_applied=false;
    return Poll::Ready(Ok(FinalStatus::Unknown))
   }
   if !r.submitted{r.completion=Completion::Rejected;r.definitely_not_applied=true;}
   return Poll::Ready(Err(e))
  }
  if r.consumed{return Poll::Ready(Err(PortError::Consumed))}
  match r.completion{Completion::Rejected=>return Poll::Ready(Ok(FinalStatus::Rejected)),Completion::Applied(ref receipt)=>return Poll::Ready(receipt.proof.current().map(|()|FinalStatus::Applied)),#[cfg(test)]Completion::FixtureApplied=>return Poll::Ready(Ok(FinalStatus::FixtureApplied)),_=>{}}
  if r.submitted{
   let result=poll_lookup(&mut self.backend,r,cx);
   // Lookup may invoke an executor waker. Re-read scope after callbacks;
   // neither Pending nor a cached classification can hide new uncertainty.
   synchronize(r);
   if r.snapshot.stage.gate.1.has_uncertain_outcome(){return Poll::Ready(Ok(FinalStatus::Unknown))}
   // All executor callbacks have returned. Revalidate SAME computation and
   // its scope/binding, including terminal transitions without the UNKNOWN bit.
   // Failed validity cannot resolve an already submitted unresolved effect.
   if validate_computation(&r.snapshot).is_err(){
    r.completion=Completion::Unknown;
    r.snapshot.stage.gate.0.borrow_mut().phase=Phase::Unknown;
    r.definitely_not_applied=false;
    return Poll::Ready(Ok(FinalStatus::Unknown))
   }
   if uncertain&&matches!(result,Poll::Ready(Err(_))){return Poll::Ready(Ok(FinalStatus::Unknown))}return result
  }
  if uncertain{return Poll::Ready(Ok(FinalStatus::Unknown))}
  // Closing forbids FRESH effects, not same-owner submitted lookup/recovery.
  // Held does not reject or manufacture a definite non-application outcome.
  if self.custody.borrow().closing{return Poll::Ready(Ok(FinalStatus::Held))}
  r.submitted=true;
  match submit_same_transaction(&mut self.backend,&r.snapshot,&self.custody){
   Err(PortError::Held)=>{r.submitted=false;if synchronize(r){return Poll::Ready(Ok(FinalStatus::Unknown))}Poll::Ready(Ok(FinalStatus::Held))},
   Err(PortError::RequiredCheckedSqlProducer)|Err(PortError::RequiredNoetherNativeRecordProtector)=>{r.submitted=false;Poll::Ready(Ok(FinalStatus::Required))},
   Err(PortError::Unknown)=>{r.completion=Completion::Unknown;r.snapshot.stage.gate.0.borrow_mut().phase=Phase::Unknown;Poll::Ready(Ok(FinalStatus::Unknown))},
   Err(e)=>{if synchronize(r){return Poll::Ready(Ok(FinalStatus::Unknown))}r.completion=Completion::Rejected;r.snapshot.stage.reject();#[cfg(test)]{r.definitely_not_applied=matches!(self.backend,NativeBackend::Fixture(_));}Poll::Ready(Err(e))},
   Ok(c)=>{r.completion=c;r.snapshot.stage.gate.0.borrow_mut().phase=Phase::Applied;Poll::Ready(Ok(status_of(&r.completion)))},
  }
 }
 pub(crate) fn consume_once(&mut self,h:&mut NativePendingHandle)->Result<NativeCommittedOutput,PortError>{
  self.handle_ok(h)?;if let Some(error)=self.routed_read_error(h){return Err(error)}let r=self.pending.get_mut(&h.slot).unwrap();
  if synchronize(r){return Err(PortError::Unknown)}
  validate_computation(&r.snapshot)?;
  if r.consumed{return Err(PortError::Consumed)}
  match r.completion{Completion::Applied(ref receipt)=>receipt.proof.current()?,#[cfg(test)]Completion::FixtureApplied=>{},Completion::Unknown=>return Err(PortError::Unknown),_=>return Err(PortError::Rejected)}
  match &r.completion{Completion::Applied(receipt)=>{#[cfg(feature="abi5-final-native-link")]if let NativeBackend::Qualified(owner)=&self.backend{owner.verify_final_binding(&r.snapshot.lease.binding,&receipt.proof)?;}else{validate_receipt_binding(&self.backend,&r.snapshot.lease.binding)?;}#[cfg(not(feature="abi5-final-native-link"))]validate_receipt_binding(&self.backend,&r.snapshot.lease.binding)?;},#[cfg(test)]Completion::FixtureApplied=>validate_receipt_binding(&self.backend,&r.snapshot.lease.binding)?,_=>return Err(PortError::RequiredOnceReceipt)}
  let mut p=r.snapshot.stage.gate.0.borrow_mut();let ciphertext=p.original_ciphertext.as_ref().ok_or(PortError::Binding)?.clone();
  // Keep canonical ciphertext in recovery until explicit final retirement.
  r.consumed=true;Ok(NativeCommittedOutput{ciphertext,plaintext:p.plaintext.take(),kind:p.selected_wire_kind,outbound:matches!(r.snapshot.queue,QueueKind::Outbound)})
 }
 pub(crate) fn cancel(&mut self,h:&mut NativePendingHandle)->Result<(),PortError>{
  self.handle_ok(h)?;if let Some(result)=self.routed_cancel(h){return result}let r=self.pending.get_mut(&h.slot).unwrap();if synchronize(r){return Err(PortError::Unknown)}
  r.snapshot.stage.gate.1.cancel();r.snapshot.stage.cancel();
  if r.submitted{return Err(PortError::Unknown)}
  r.completion=Completion::Rejected;r.definitely_not_applied=true;Ok(())
 }
 pub(crate) fn retire(&mut self,h:&mut NativePendingHandle,ack:RetireAcknowledgement)->Result<(),PortError>{
  self.handle_ok(h)?;if let Some(error)=self.routed_read_error(h){return Err(error)}let r=self.pending.get_mut(&h.slot).unwrap();if synchronize(r){return Err(PortError::Unknown)}
  let eligible=match ack{RetireAcknowledgement::ConsumedOutput=>r.consumed&&is_applied(&r.completion),RetireAcknowledgement::DefiniteRejection=>r.definitely_not_applied&&matches!(r.completion,Completion::Rejected)};
  if !eligible{return Err(PortError::Rejected)}
  // Keep the ledger and sole proof on cleanup failure; RAM close is not settlement.
  if let Completion::Applied(receipt)=&mut r.completion{
   if receipt.proof.current().and_then(|()|receipt.proof.close()).is_err(){
    r.snapshot.stage.gate.0.borrow_mut().phase=Phase::Unknown;
    return Err(PortError::Unknown)
   }
  }
  let r=self.pending.remove(&h.slot).unwrap();self.retained_bytes-=r.reserved_bytes;{let mut c=self.custody.borrow_mut();c.ledger_count-=1;c.ledger_bytes-=r.reserved_bytes;}
  self.tombstones.push_back(h.slot);if self.tombstones.len()>64{self.tombstones.pop_front();}
  // Slots never reused; next high-water rejects even tombstones beyond the window.
  Ok(())
 }
}
fn status_of(c:&Completion)->FinalStatus{match c{Completion::Applied(_)=>FinalStatus::Applied,Completion::Unknown=>FinalStatus::Unknown,Completion::Rejected=>FinalStatus::Rejected,Completion::Prepared=>FinalStatus::Required,#[cfg(test)]Completion::FixtureApplied=>FinalStatus::FixtureApplied}}

// A single borrowed SQL transaction spans ALL journal entries and queues.
// No await into a live Identity/Kyber/EC/SessionStore is permitted here.
struct CheckedSqlTransaction<'txn,'op> {
 backend:&'txn mut NativeBackend,lease:&'op NativeLease,snapshot:&'op NativeSnapshotHandle,steps:Vec<NativeSqlStep<'op>>,
}
enum NativeSqlStep<'op> {
 Identity(&'op ProtocolAddress,&'op IdentityKey),
 EcSave(PreKeyId,&'op PreKeyRecord),EcRemove(PreKeyId),
 KyberSave(KyberPreKeyId,&'op KyberPreKeyRecord),
 KyberUsed(KyberPreKeyId,SignedPreKeyId,&'op PublicKey),
 Session(&'op ProtocolAddress,&'op SessionRecord),
 Inbox(&'op [u8]),Outbox(&'op [u8]),
}
impl<'txn,'op> CheckedSqlTransaction<'txn,'op> {
 fn begin(backend:&'txn mut NativeBackend,snapshot:&'op NativeSnapshotHandle)->Result<Self,PortError>{
  validate_computation(snapshot)?;let lease=&snapshot.lease;
  match backend{NativeBackend::Unavailable=>return Err(PortError::RequiredCheckedSqlProducer),#[cfg(feature="abi5-final-native-link")]NativeBackend::Qualified(owner)=>{owner.current().map_err(|_|PortError::Unknown)?;},
   #[cfg(test)]NativeBackend::Fixture(f)=>if lease.binding!=f.binding||f.revoked{return Err(PortError::Binding)},}
  Ok(Self{backend,lease,snapshot,steps:Vec::new()})
 }
 fn apply(&mut self,m:&'op Mutation){self.steps.push(match m{
  Mutation::Identity(a,k)=>NativeSqlStep::Identity(a,k),
  Mutation::PreKeySave(id,r)=>NativeSqlStep::EcSave(*id,r),Mutation::PreKeyRemove(id)=>NativeSqlStep::EcRemove(*id),
  Mutation::KyberSave(id,r)=>NativeSqlStep::KyberSave(*id,r),Mutation::KyberUsed(k,e,b)=>NativeSqlStep::KyberUsed(*k,*e,b),
  Mutation::Session(a,r)=>NativeSqlStep::Session(a,r),
 });}
 fn inbox(&mut self,wire:&'op [u8]){self.steps.push(NativeSqlStep::Inbox(wire));}
 fn outbox(&mut self,wire:&'op [u8]){self.steps.push(NativeSqlStep::Outbox(wire));}
 fn commit(self,custody:&RefCell<ActorCustody>)->Result<Completion,PortError>{
  #[cfg(test)]if let NativeBackend::Fixture(f)=&mut *self.backend{if let Some(v)=f.before_commit_transition.take(){match v{0=>self.snapshot.stage.gate.1.cancel(),1=>self.snapshot.stage.gate.1.fixture_revoke(),2=>self.snapshot.stage.gate.1.fixture_rebind(4),_=>self.snapshot.stage.gate.1.fixture_unknown()}}}
  validate_computation(self.snapshot)?;
  if custody.borrow().closing{return Err(PortError::Held)}
  match self.backend {NativeBackend::Unavailable=>Err(PortError::RequiredNoetherNativeRecordProtector),#[cfg(feature="abi5-final-native-link")]NativeBackend::Qualified(owner)=>owner.protected_commit(self.snapshot,&self.steps).map(|proof|Completion::Applied(PrivateDurableReceipt{proof,binding:self.lease.binding})),
   #[cfg(test)]NativeBackend::Fixture(f)=>fixture_transaction(f,self.lease,&self.steps),}
 }
}
fn submit_same_transaction(backend:&mut NativeBackend,s:&NativeSnapshotHandle,custody:&RefCell<ActorCustody>)->Result<Completion,PortError>{
 validate_computation(s)?;
 let (journal,wire)={
  s.stage.gate.sync_uncertainty();let p=s.stage.gate.0.borrow();
  if p.phase==Phase::Unknown{return Err(PortError::Unknown)}
  if p.phase!=Phase::Prepared{return Err(PortError::Rejected)}
  (p.journal.clone(),p.original_ciphertext.as_ref().ok_or(PortError::Binding)?.clone())
 };
 // Native-only bounded input copies; no RefCell loan spans control callbacks.
 // Canonical original remains held by pending for every failure/UNKNOWN path.
 let mut txn=CheckedSqlTransaction::begin(backend,s)?;
 for m in &journal{txn.apply(m);}
 match s.queue{QueueKind::Inbound=>txn.inbox(&wire),QueueKind::Outbound=>txn.outbox(&wire)}
 txn.commit(custody)
}
fn poll_lookup(backend:&mut NativeBackend,r:&mut Retained,cx:&mut Context<'_>)->Poll<Result<FinalStatus,PortError>>{
 if let Err(e)=validate_computation(&r.snapshot){return Poll::Ready(Err(e))}
 match backend{NativeBackend::Unavailable=>Poll::Ready(Err(PortError::RequiredCheckedSqlProducer)),#[cfg(feature="abi5-final-native-link")]NativeBackend::Qualified(owner)=>match owner.protected_lookup(&r.snapshot){
   Ok(proof)=>{r.completion=Completion::Applied(PrivateDurableReceipt{proof,binding:r.snapshot.lease.binding});Poll::Ready(Ok(FinalStatus::Applied))},
   Err(PortError::Unknown)=>Poll::Ready(Ok(FinalStatus::Unknown)),
   Err(e)=>Poll::Ready(Err(e)),
  },
  #[cfg(test)] NativeBackend::Fixture(f)=>{
   let lookup_binding=if f.receipt.is_some(){validate_fixture_receipt_binding(f,&r.snapshot.lease.binding)}else if !f.revoked&&f.binding==r.snapshot.lease.binding{Ok(())}else{Err(PortError::Binding)};
   if lookup_binding.is_err(){return Poll::Ready(Err(PortError::Binding))}
   f.lookups+=1;
   if f.lookup_pending{f.lookup_pending=false;cx.waker().wake_by_ref();return Poll::Pending}
   match &f.receipt{
    Some((b,wire)) if *b==r.snapshot.lease.binding&&r.snapshot.stage.gate.0.borrow().original_ciphertext.as_deref()==Some(wire.as_slice())=>{
     r.completion=Completion::FixtureApplied;r.snapshot.stage.gate.0.borrow_mut().phase=Phase::Applied;Poll::Ready(Ok(FinalStatus::FixtureApplied))
    },
    _=>Poll::Ready(Ok(FinalStatus::Unknown)),
   }
  },
 }
}
#[cfg(test)] struct FixtureSql {
 binding:LeaseBinding,store:InMemSignalProtocolStore,revoked:bool,
 fail_at:Option<usize>,unknown_after_apply:bool,lookup_pending:bool,
 before_commit_transition:Option<u8>,receipts:usize,submissions:usize,lookups:usize,queues:Vec<Vec<u8>>,
 receipt:Option<(LeaseBinding,Vec<u8>)>,
}
#[cfg(test)] fn fixture_clone(s:&InMemSignalProtocolStore)->InMemSignalProtocolStore{
 use futures_util::FutureExt;
 let mut n=InMemSignalProtocolStore::new(s.get_identity_key_pair().now_or_never().unwrap().unwrap(),s.get_local_registration_id().now_or_never().unwrap().unwrap()).unwrap();
 n.identity_store=s.identity_store.clone();n.pre_key_store=s.pre_key_store.clone();n.kyber_pre_key_store=s.kyber_pre_key_store.clone();n.session_store=s.session_store.clone();n.signed_pre_key_store=s.signed_pre_key_store.clone();n
}
#[cfg(test)] fn fixture_transaction(f:&mut FixtureSql,l:&NativeLease,steps:&[NativeSqlStep<'_>])->Result<Completion,PortError>{
 use futures_util::FutureExt;
 f.submissions+=1;
 if l.binding!=f.binding||f.revoked{return Err(PortError::Binding)}
 let mut next=fixture_clone(&f.store);let mut queues=f.queues.clone();let mut wire=None;
 for (i,m) in steps.iter().enumerate(){if f.fail_at==Some(i){return Err(PortError::Rejected)}
 let result=match m{
  NativeSqlStep::Identity(a,k)=>next.save_identity(a,k).now_or_never().unwrap().map(|_|()),
  NativeSqlStep::EcSave(id,r)=>next.save_pre_key(*id,r).now_or_never().unwrap(),
  NativeSqlStep::EcRemove(id)=>next.remove_pre_key(*id).now_or_never().unwrap(),
  NativeSqlStep::KyberSave(id,r)=>next.save_kyber_pre_key(*id,r).now_or_never().unwrap(),
  NativeSqlStep::KyberUsed(k,e,b)=>next.mark_kyber_pre_key_used(*k,*e,b).now_or_never().unwrap(),
  NativeSqlStep::Session(a,r)=>next.store_session(a,r).now_or_never().unwrap(),
  NativeSqlStep::Inbox(w)|NativeSqlStep::Outbox(w)=>{queues.push(w.to_vec());wire=Some(w.to_vec());Ok(())},
 };if result.is_err(){return Err(PortError::Rejected)}}
 // Single cfg(test) aggregate replacement. NOT actual SQL/durability proof.
 f.store=next;f.queues=queues;f.binding.generation+=1;f.receipts+=1;
 f.receipt=Some((l.binding,wire.ok_or(PortError::Binding)?));
 if f.unknown_after_apply{Err(PortError::Unknown)}else{Ok(Completion::FixtureApplied)}
}
#[cfg(test)] mod tests;
#[cfg(test)] mod r23_tests;
#[cfg(test)] mod r24_tests;
#[cfg(test)] mod r56_submitted_precheck;

fn validate_receipt_binding(backend:&NativeBackend,b:&LeaseBinding)->Result<(),PortError>{match backend{NativeBackend::Unavailable=>Err(PortError::RequiredCheckedSqlProducer),#[cfg(feature="abi5-final-native-link")]NativeBackend::Qualified(_)=>Err(PortError::RequiredCheckedSqlProducer),#[cfg(test)]NativeBackend::Fixture(f)=>validate_fixture_receipt_binding(f,b)}}
#[cfg(test)]fn validate_fixture_receipt_binding(f:&FixtureSql,b:&LeaseBinding)->Result<(),PortError>{let expected=LeaseBinding{generation:b.generation.checked_add(1).ok_or(PortError::Binding)?,..*b};if f.revoked||f.binding!=expected{Err(PortError::Binding)}else{Ok(())}}

fn is_applied(c:&Completion)->bool{match c{Completion::Applied(_)=>true,#[cfg(test)]Completion::FixtureApplied=>true,_=>false}}

#[cfg(test)]pub(super) fn fixture_cohort_snapshot(input:super::cohort::AuthenticatedOwnedCohortInput,gate:Gate,wire:&[u8],source:[u8;32],required:bool)->Result<NativeSnapshotHandle,FixtureCohortFailure>{
 let binding=LeaseBinding{store:1,session:2,incarnation:3,generation:0,operation:5,context:6,route:7,device_authorization:8,revocation_checkpoint:9,source_abi:source};
 let lease=NativeLease{binding,authority:if required{Authority::Required}else{Authority::Fixture}};
 NativeSnapshotHandle::from_cohort_input(input,gate,lease,QueueKind::Inbound,Some(SnapshotReservation{snapshot_bytes:MAX_SNAPSHOT_BYTES,source:ReservationSource::Fixture}),Some(wire)).map_err(|actual|FixtureCohortFailure{actual})
}
#[cfg(test)]pub(super) fn fixture_closed_retention(snapshot:NativeSnapshotHandle)->NativeSnapshotHandle{
 let mut bridge=NativeStoreBridge{actor:11,issuer:Rc::new(()),next:0,backend:NativeBackend::Unavailable,pending:RetentionLedger::new(),retained_bytes:0,tombstones:VecDeque::new(),custody:Rc::new(RefCell::new(ActorCustody::new()))};
 match bridge.retain_prepared(snapshot){Err(f)=>{assert!(matches!(f.error,PortError::RequiredNativeSourceAuthentication));assert!(bridge.pending.is_empty());f.snapshot},Ok(_)=>panic!("unissued backend admitted")}
}
#[cfg(test)]pub(super) fn fixture_cohort_gate(snapshot:&NativeSnapshotHandle)->Gate{snapshot.stage.gate.clone()}

#[cfg(all(test,feature="abi5-final-native-link"))]pub(super) fn fixture_actual_final_store_required(s:&NativeSnapshotHandle){assert!(matches!(abi5::require_after_actual_computation(s),Err(PortError::RequiredCheckedSqlProducer)));}

// Test-only ownership observation. Retry moves the SAME unavailable lease; it
// never upgrades fixture/source authorization or clears irreversible uncertainty.
#[cfg(test)]pub(super)struct FixtureCohortFailure{actual:CohortSnapshotFailure}
#[cfg(test)]impl FixtureCohortFailure{
 pub(super)fn error(&self)->&PortError{&self.actual.error}
 pub(super)fn gate(&self)->&Gate{&self.actual.gate}
 pub(super)fn input(&self)->Option<&super::cohort::AuthenticatedOwnedCohortInput>{self.actual.input.as_ref()}
 pub(super)fn retry_same_unavailable(self,wire:&[u8])->Result<NativeSnapshotHandle,Self>{
  let CohortSnapshotFailure{error,input,gate,lease}=self.actual;
  match input{Some(input)=>NativeSnapshotHandle::from_cohort_input(input,gate,lease,QueueKind::Inbound,None,Some(wire)).map_err(|actual|Self{actual}),None=>Err(Self{actual:CohortSnapshotFailure{error,input:None,gate,lease}})}
 }
}

// SAME original ledger is also custody: UNKNOWN is never silently discarded.
// A genuinely pre-effect unsubmitted owner may be released locally. A submitted
// owner needs definite rejection or consumed authenticated final completion.
// This is process-local fail-stop, NOT durable process-death recovery.
impl Drop for NativeStoreBridge{fn drop(&mut self){
 let c=self.custody.borrow();
 if c.active.is_some()||c.routes.iter().any(Option::is_some){std::process::abort();}
 drop(c);
 for r in self.pending.values_mut(){
  if synchronize(r)||matches!(r.completion,Completion::Unknown)
   ||(r.submitted&&!((r.definitely_not_applied&&matches!(r.completion,Completion::Rejected))||(r.consumed&&is_applied(&r.completion)))){std::process::abort();}
 }
}}

// Native-only opaque owner transfer to product facade. No key/state getter.
impl NativeSnapshotHandle{
 pub(super)fn product_outcome_uncertain(&self)->bool{uncertain(&self.stage.gate)}
}
impl RetainFailure{
 pub(super)fn into_product_parts(self)->(PortError,NativeSnapshotHandle){(self.error,self.snapshot)}
}
impl NativeCommittedOutput{
 pub(super)fn into_product_parts(self)->(Vec<u8>,Option<Vec<u8>>,Option<super::output::SelectedWireKind>,bool){(self.ciphertext,self.plaintext,self.kind,self.outbound)}
}

// Product delivery independently requires REAL completion, even without poll.
fn require_product_completion(c:&Completion,b:&LeaseBinding)->Result<(),PortError>{
 match c{Completion::Applied(receipt)=>if receipt.binding==*b{receipt.proof.current()}else{Err(PortError::Binding)},Completion::Unknown=>Err(PortError::Unknown),#[cfg(test)]Completion::FixtureApplied=>Err(PortError::RequiredOnceReceipt),_=>Err(PortError::Rejected)}
}
impl NativeStoreBridge{
 pub(super)fn consume_product_once(&mut self,h:&mut NativePendingHandle)->Result<NativeCommittedOutput,PortError>{
  self.handle_ok(h)?;if let Some(e)=self.routed_read_error(h){return Err(e)}
  let r=self.pending.get_mut(&h.slot).ok_or(PortError::Binding)?;
  if synchronize(r){return Err(PortError::Unknown)}
  require_product_completion(&r.completion,&r.snapshot.lease.binding)?;
  validate_computation(&r.snapshot)?;
  {let p=r.snapshot.stage.gate.0.borrow();product_preconsume_state(&p,&r.snapshot.queue,r.consumed)?;}
  self.consume_once(h)
 }
}
#[cfg(test)]mod product_isolation_r32{
 use super::*;
 #[test]fn r32_controller_product_fixture_completion_not_promoted(){
  let b=LeaseBinding{store:1,session:2,incarnation:3,generation:0,operation:5,context:6,route:7,device_authorization:8,revocation_checkpoint:9,source_abi:[0;32]};
  let fixture=Completion::FixtureApplied;
  assert!(is_applied(&fixture)); // Existing fixture baseline deliberately remains supported.
  assert!(matches!(require_product_completion(&fixture,&b),Err(PortError::RequiredOnceReceipt)));
  assert!(matches!(require_product_completion(&Completion::Unknown,&b),Err(PortError::Unknown)));
  assert!(matches!(require_product_completion(&Completion::Prepared,&b),Err(PortError::Rejected)));
 }
}

#[cfg(test)]mod direct_product_consume_r32{
 use super::*;
 struct NoIdentity;
 #[async_trait(?Send)]impl IdentityKeyStore for NoIdentity{
  async fn get_identity_key_pair(&self)->R<IdentityKeyPair>{panic!("fixture rejection before selected store")}
  async fn get_local_registration_id(&self)->R<u32>{panic!("fixture rejection before selected store")}
  async fn save_identity(&mut self,_:&ProtocolAddress,_:&IdentityKey)->R<IdentityChange>{panic!("fixture rejection before selected store")}
  async fn is_trusted_identity(&self,_:&ProtocolAddress,_:&IdentityKey,_:Direction)->R<bool>{panic!("fixture rejection before selected store")}
  async fn get_identity(&self,_:&ProtocolAddress)->R<Option<IdentityKey>>{panic!("fixture rejection before selected store")}
 }
 #[test]fn r32_controller_direct_product_consume_without_poll_keeps_fixture_owner(){
  let binding=LeaseBinding{store:1,session:2,incarnation:3,generation:0,operation:5,context:6,route:7,device_authorization:8,revocation_checkpoint:9,source_abi:[0;32]};
  let gate=Gate(Rc::new(RefCell::new(Pending{phase:Phase::Applied,binding:[1,2,3,0,5,6,7,8,9,0,2],bytes:0,journal:Vec::new(),original_ciphertext:Some(b"public fixture wire".to_vec()),generated_wire:false,selected_wire_kind:None,plaintext:Some(b"public dummy payload".to_vec()),trigger:None,pending:false})),Rc::new(spqr::ynx_operation::CallScope::fixture([1,2,3,0,5,6,7,8,9,0,2])));
  let stage=StagedOperation{identity:Identity{snapshot:Box::new(NoIdentity),gate:gate.clone()},ec:EC{snapshot:Box::new(InMemPreKeyStore::new()),gate:gate.clone()},kyber:Kyber{snapshot:Box::new(InMemKyberPreKeyStore::new()),gate:gate.clone()},sessions:Sessions{snapshot:Box::new(InMemSessionStore::new()),gate:gate.clone()},gate};
  let snapshot=NativeSnapshotHandle{stage,signed:Box::new(InMemSignedPreKeyStore::new()),lease:NativeLease{binding,authority:Authority::Required},queue:QueueKind::Inbound,computation:None,budget:None};
  let issuer=Rc::new(());let mut handle=NativePendingHandle{actor:11,issuer:issuer.clone(),slot:1};
  let mut bridge=NativeStoreBridge{actor:11,issuer,next:1,backend:NativeBackend::Unavailable,pending:RetentionLedger::new(),retained_bytes:0,tombstones:VecDeque::new(),custody:Rc::new(RefCell::new(ActorCustody::new()))};
  bridge.pending.insert(1,Retained{snapshot,completion:Completion::FixtureApplied,submitted:false,consumed:false,reserved_bytes:0,definitely_not_applied:false});
  for _ in 0..2{assert!(matches!(super::super::product_facade::consume_product_delivery(&mut bridge,&mut handle),Err(crate::NativeProductError::RequiredReceipt)));let retained=bridge.pending.get(&1).expect("same owner");assert!(!retained.consumed);assert!(matches!(retained.completion,Completion::FixtureApplied));assert_eq!(retained.snapshot.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(b"public fixture wire".as_slice()));assert_eq!(retained.snapshot.stage.gate.0.borrow().plaintext.as_deref(),Some(b"public dummy payload".as_slice()));assert_eq!(bridge.pending.len(),1);}
 }
}

#[cfg(test)]mod retention_custody_r33{use super::*; struct NoIdentity;
 #[async_trait(?Send)]impl IdentityKeyStore for NoIdentity{
  async fn get_identity_key_pair(&self)->R<IdentityKeyPair>{panic!("fixture rejection before selected store")}
  async fn get_local_registration_id(&self)->R<u32>{panic!("fixture rejection before selected store")}
  async fn save_identity(&mut self,_:&ProtocolAddress,_:&IdentityKey)->R<IdentityChange>{panic!("fixture rejection before selected store")}
  async fn is_trusted_identity(&self,_:&ProtocolAddress,_:&IdentityKey,_:Direction)->R<bool>{panic!("fixture rejection before selected store")}
  async fn get_identity(&self,_:&ProtocolAddress)->R<Option<IdentityKey>>{panic!("fixture rejection before selected store")}
 }

 fn dummy()->(NativeStoreBridge,NativeSnapshotHandle){  let binding=LeaseBinding{store:1,session:2,incarnation:3,generation:0,operation:5,context:6,route:7,device_authorization:8,revocation_checkpoint:9,source_abi:[0;32]};
  let gate=Gate(Rc::new(RefCell::new(Pending{phase:Phase::Applied,binding:[1,2,3,0,5,6,7,8,9,0,2],bytes:0,journal:Vec::new(),original_ciphertext:Some(b"public fixture wire".to_vec()),generated_wire:false,selected_wire_kind:None,plaintext:Some(b"public dummy payload".to_vec()),trigger:None,pending:false})),Rc::new(spqr::ynx_operation::CallScope::fixture([1,2,3,0,5,6,7,8,9,0,2])));
  let stage=StagedOperation{identity:Identity{snapshot:Box::new(NoIdentity),gate:gate.clone()},ec:EC{snapshot:Box::new(InMemPreKeyStore::new()),gate:gate.clone()},kyber:Kyber{snapshot:Box::new(InMemKyberPreKeyStore::new()),gate:gate.clone()},sessions:Sessions{snapshot:Box::new(InMemSessionStore::new()),gate:gate.clone()},gate};
  let snapshot=NativeSnapshotHandle{stage,signed:Box::new(InMemSignedPreKeyStore::new()),lease:NativeLease{binding,authority:Authority::Required},queue:QueueKind::Inbound,computation:None,budget:None};
  let issuer=Rc::new(());let mut handle=NativePendingHandle{actor:11,issuer:issuer.clone(),slot:1};
  let mut bridge=NativeStoreBridge{actor:11,issuer,next:1,backend:NativeBackend::Unavailable,pending:RetentionLedger::new(),retained_bytes:0,tombstones:VecDeque::new(),custody:Rc::new(RefCell::new(ActorCustody::new()))};
let _=handle; (bridge,snapshot)}
 #[test]fn r33_retention_returned_failure_keeps_actual_snapshot(){let(mut bridge,snapshot)=dummy();let mut owner=Some(snapshot);assert!(matches!(bridge.retain_in_place(&mut owner),Err(PortError::Rejected)));let s=owner.as_ref().unwrap();assert_eq!(s.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(b"public fixture wire".as_slice()));assert!(bridge.pending.is_empty());assert_eq!(bridge.next,1);}
 #[test]fn r33_retention_actual_borrow_panic_keeps_owner(){let(mut bridge,snapshot)=dummy();let gate=snapshot.stage.gate.clone();let mut owner=Some(snapshot);let borrow=gate.0.borrow_mut();assert!(matches!(bridge.retain_in_place(&mut owner),Err(PortError::PanicRetained)));drop(borrow);assert!(owner.is_some());assert!(bridge.pending.is_empty());assert_eq!(owner.as_ref().unwrap().stage.gate.0.borrow().plaintext.as_deref(),Some(b"public dummy payload".as_slice()));}
 #[test]fn r33_retention_byvalue_failure_returns_original(){let(mut bridge,snapshot)=dummy();let gate=snapshot.stage.gate.clone();let borrow=gate.0.borrow_mut();let failure=bridge.retain_prepared(snapshot).err().expect("contained panic");assert!(matches!(failure.error,PortError::PanicRetained));drop(borrow);assert_eq!(failure.snapshot.stage.gate.0.borrow().original_ciphertext.as_deref(),Some(b"public fixture wire".as_slice()));}
 #[test]fn r33_retention_reserved_receiver_unwind_no_owner_move(){let mut ledger=RetentionLedger::<u64,Vec<u8>>::new();let mut owner=Some(b"public dummy wire".to_vec());let result:Result<(),PortError>=contain_retention(||{let _cell=ledger.reserve(1).unwrap();panic!("before transfer")});assert!(matches!(result,Err(PortError::PanicRetained)));assert!(owner.is_some());assert!(ledger.is_empty());let cell=ledger.reserve(1).unwrap();*cell=owner.take();assert_eq!(ledger.get(&1).unwrap(),b"public dummy wire");assert!(owner.is_none());}
}

#[cfg(test)]impl<K:Ord,V> std::ops::Index<&K> for RetentionLedger<K,V>{type Output=V;fn index(&self,key:&K)->&V{self.get(key).expect("occupied fixture ledger index")}}

/// Private route projection must originate in the SAME authenticated snapshot.
/// Structural JNI logical IDs/addresses never construct this type.
pub(crate)struct NativeMessageRoute{local:ProtocolAddress,remote:ProtocolAddress,logical:[u8;16],direction:crate::product_message::Direction,binding:LeaseBinding}
impl NativeMessageRoute{
 pub(crate)fn local(&self)->&ProtocolAddress{&self.local}
 pub(crate)fn remote(&self)->&ProtocolAddress{&self.remote}
 pub(crate)fn matches(&self,id:&[u8;16],direction:crate::product_message::Direction)->bool{&self.logical==id&&self.direction==direction}
}
impl NativeSnapshotHandle{
 pub(crate)fn message_route(&self,logical:&[u8;16],direction:crate::product_message::Direction)->Result<NativeMessageRoute,PortError>{
  if uncertain(&self.stage.gate){return Err(PortError::Unknown)}
  if !matches!((&self.queue,direction),(QueueKind::Inbound,crate::product_message::Direction::Receive)|(QueueKind::Outbound,crate::product_message::Direction::Send)){return Err(PortError::Binding)}
  #[cfg(feature="abi5-final-native-link")]
  if let Authority::Verified(NativeVerifiedAuthority::Held(owner))=&self.lease.authority{
   let b=self.stage.gate.0.borrow().binding;
   let (local,remote)=owner.message_route(logical,direction,&b).map_err(|e|match e{SourceOwnerError::Required=>PortError::RequiredNativeSourceAuthentication,SourceOwnerError::Association=>PortError::Binding,SourceOwnerError::Thread=>PortError::Held,_=>PortError::Unknown})?;
   return Ok(NativeMessageRoute{local,remote,logical:*logical,direction,binding:self.lease.binding})
  }
  Err(PortError::RequiredNativeSourceAuthentication)
 }
 // A late route rejection follows an attempted computation. Retain the same
 // snapshot and permanently quarantine its existing stage; never reprepare.
 pub(crate)fn finish_message_route(&self,route:&NativeMessageRoute)->Result<(),PortError>{
  if self.validate_message_route(route).is_err(){
   self.stage.gate.0.borrow_mut().phase=Phase::Unknown;
   return Err(PortError::Unknown)
  }
  Ok(())
 }
 pub(crate)fn validate_message_route(&self,route:&NativeMessageRoute)->Result<(),PortError>{
  if uncertain(&self.stage.gate){return Err(PortError::Unknown)}
  if route.binding!=self.lease.binding{return Err(PortError::Binding)}
  let current=self.message_route(&route.logical,route.direction)?;
  if current.local!=route.local||current.remote!=route.remote{return Err(PortError::Binding)}
  Ok(())
 }
}

// Synchronous read fence on the SAME consumed pending. No public tuple or
// cached UI status is a receipt. No callback/await between this and native copy.
impl NativeStoreBridge{
 pub(super) fn validate_product_delivery(&mut self,h:&NativePendingHandle)->Result<(),PortError>{
  self.handle_ok(h)?;if let Some(e)=self.routed_read_error(h){return Err(e)}
  let r=self.pending.get_mut(&h.slot).ok_or(PortError::Binding)?;
  if synchronize(r){return Err(PortError::Unknown)}
  require_product_completion(&r.completion,&r.snapshot.lease.binding)?;
  validate_computation(&r.snapshot)?;
  match &r.completion{Completion::Applied(receipt)=>{#[cfg(feature="abi5-final-native-link")]if let NativeBackend::Qualified(owner)=&self.backend{owner.verify_final_binding(&r.snapshot.lease.binding,&receipt.proof)?;}else{validate_receipt_binding(&self.backend,&r.snapshot.lease.binding)?;}#[cfg(not(feature="abi5-final-native-link"))]validate_receipt_binding(&self.backend,&r.snapshot.lease.binding)?;},#[cfg(test)]Completion::FixtureApplied=>validate_receipt_binding(&self.backend,&r.snapshot.lease.binding)?,_=>return Err(PortError::RequiredOnceReceipt)}
  if !r.consumed{return Err(PortError::Rejected)}
  Ok(())
 }
}

// Classification only, never a receipt or output constructor. The caller has
// already synchronized scope UNKNOWN and checked real receipt/currentness.
// Repeat consumption precedes the pre-consumption plaintext shape, because
// the first consume has legitimately taken the inbound plaintext.
fn product_preconsume_state(p:&Pending,queue:&QueueKind,consumed:bool)->Result<(),PortError>{
 if p.phase==Phase::Unknown{return Err(PortError::Unknown)}
 if consumed{return Err(PortError::Consumed)}
 if p.selected_wire_kind.is_none()||matches!(queue,QueueKind::Outbound)==p.plaintext.is_some(){return Err(PortError::Binding)}
 Ok(())
}
#[cfg(test)]mod r55_repeat_classification{
 use super::*;
 fn pending(clear:Option<Vec<u8>>)->Pending{Pending{phase:Phase::Applied,binding:[1,2,3,0,5,6,7,8,9,0,2],bytes:0,journal:Vec::new(),original_ciphertext:Some(b"PUBLIC original wire".to_vec()),generated_wire:false,selected_wire_kind:Some(super::super::output::SelectedWireKind::Signal),plaintext:clear,trigger:None,pending:false}}
 #[test]fn r55_inbound_repeated_classification_consumed_no_payload(){
  let mut p=pending(Some(b"PUBLIC dummy text".to_vec()));let original=p.original_ciphertext.as_ref().unwrap().as_ptr();
  assert!(product_preconsume_state(&p,&QueueKind::Inbound,false).is_ok());
  let first=p.plaintext.take().unwrap(); // Mechanical first-consume shape only, NOT a receipt.
  for _ in 0..2{assert!(matches!(product_preconsume_state(&p,&QueueKind::Inbound,true),Err(PortError::Consumed)));assert!(p.plaintext.is_none());assert_eq!(p.original_ciphertext.as_ref().unwrap().as_ptr(),original);assert_eq!(p.original_ciphertext.as_deref(),Some(b"PUBLIC original wire".as_slice()));}
  assert_eq!(first,b"PUBLIC dummy text");assert!(p.journal.is_empty());
 }
 #[test]fn r55_outbound_repeated_classification_consumed_same_wire(){
  let p=pending(None);let original=p.original_ciphertext.as_ref().unwrap().as_ptr();assert!(product_preconsume_state(&p,&QueueKind::Outbound,false).is_ok());
  for _ in 0..2{assert!(matches!(product_preconsume_state(&p,&QueueKind::Outbound,true),Err(PortError::Consumed)));assert_eq!(p.original_ciphertext.as_ref().unwrap().as_ptr(),original);assert!(p.plaintext.is_none());}
 }
 #[test]fn r55_unknown_dominates_consumed_for_both_directions(){
  let mut p=pending(None);p.phase=Phase::Unknown;
  for queue in [QueueKind::Inbound,QueueKind::Outbound]{for consumed in [false,true]{assert!(matches!(product_preconsume_state(&p,&queue,consumed),Err(PortError::Unknown)))}}
  assert_eq!(p.original_ciphertext.as_deref(),Some(b"PUBLIC original wire".as_slice()));assert!(p.plaintext.is_none());
 }
 #[test]fn r55_first_consume_shape_gate_and_fixture_receipt_unchanged(){
  let mut p=pending(None);assert!(matches!(product_preconsume_state(&p,&QueueKind::Inbound,false),Err(PortError::Binding)));
  p.plaintext=Some(vec![1]);assert!(matches!(product_preconsume_state(&p,&QueueKind::Outbound,false),Err(PortError::Binding)));
  p.selected_wire_kind=None;assert!(matches!(product_preconsume_state(&p,&QueueKind::Inbound,false),Err(PortError::Binding)));
  let b=LeaseBinding{store:1,session:2,incarnation:3,generation:0,operation:5,context:6,route:7,device_authorization:8,revocation_checkpoint:9,source_abi:[0;32]};
  assert!(matches!(require_product_completion(&Completion::FixtureApplied,&b),Err(PortError::RequiredOnceReceipt)));
 }
}

#[cfg(feature="abi5-final-native-link")]pub(super)use abi5::{NativeSnapshotOwner,NativeSnapshotData,SnapshotBytes};

#[cfg(feature="abi5-final-native-link")]
impl NativeStoreBridge{
 pub(super)fn from_qualified_snapshot(owner:Rc<NativeSnapshotOwner>)->Result<Self,PortError>{
  owner.current().map_err(|_|PortError::Unknown)?;let p=owner.projection().map_err(|_|PortError::Unknown)?;
  // This local routing identity is allocated only AFTER true platform actor
  // enrollment. Its Rc identity never supplies qualification by itself.
  Ok(Self{actor:p.actor,issuer:Rc::new(()),next:0,backend:NativeBackend::Qualified(owner),pending:RetentionLedger::new(),retained_bytes:0,tombstones:VecDeque::new(),custody:Rc::new(RefCell::new(ActorCustody::new()))})
 }
}

#[cfg(feature="abi5-final-native-link")]pub(crate)use abi5::{ScopedNativeOriginal,ScopedNativeFailure};

#[cfg(feature="abi5-final-native-link")]pub(crate)use abi5::{ScopedNativeFinalRequest,NativeFinalAction,NativeFinalObservation};

#[cfg(feature="abi5-final-native-link")]pub(crate)use abi5::NativeFinalCommitOwner as QualifiedFinalEvidenceOwner;

#[cfg(feature="abi5-final-native-link")]pub(crate)use abi5::AcceptedDeviceOwner;

#[cfg(feature="abi5-final-native-link")]pub(crate)use abi5::{MessageSessionOwner,PersistentMessageProjection};

#[cfg(feature="abi5-final-native-link")]pub(crate)use abi5::{OwnedMessageOriginal,OwnedMessageOpenFailure};
