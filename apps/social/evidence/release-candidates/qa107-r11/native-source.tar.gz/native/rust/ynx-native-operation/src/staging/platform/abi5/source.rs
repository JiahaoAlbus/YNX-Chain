//! Private R27 joint source SPI borrow closure. No constructor/admission from a view.
use super::*;
use std::ffi::{c_char,c_uchar};
#[repr(C)]struct StoreBinding{_opaque:[u8;0]}
#[repr(C)]struct SourceHold{_opaque:[u8;0]}
#[derive(Clone,Copy)]#[repr(C)]enum SourceMode{Fresh=0,Recovery=1,Transition=2}
#[repr(C)]struct OriginalView{
 op:*const c_char,owner:*const c_char,device:*const c_char,identity_fp:*const c_char,key_alias:*const c_char,
 base_hash:*const c_char,next_hash:*const c_char,cipher_hash:*const c_char,
 base_rev:i64,next_rev:i64,auth_gen:i64,sealed_candidate:*const c_uchar,candidate_size:usize,journal_steps:u32,
}
#[repr(C)]struct SourceView{
 issuer:*const c_char,actor:*const c_char,source_id:*const c_char,store_id:*const c_char,
 restore_incarnation:i64,source_generation:i64,revoked_through:i64,original:OriginalView,
}
unsafe extern "C"{
 fn veil_source_acquire(b:*mut StoreBinding,l:*const Lease,i:*const Intent,m:SourceMode,h:*mut *mut SourceHold,v:*mut SourceView)->i32;
 fn veil_source_validate(h:*mut SourceHold,cleanup_only:i32)->i32;
 fn veil_source_drop(h:*mut *mut SourceHold);
 fn veil_private_initialize_source(s:*mut Store,l:*const Lease,i:*const Intent)->i32;
 fn veil_private_persist_revocation(s:*mut Store,l:*const Lease,i:*const Intent)->i32;
}
// No owned/borrowed-view conversion is admitted. Source/auth generations,
// restore, original intent, and checkpoint/cipher hashes remain distinct types
// of facts. Never read a projected view as an issuer/receipt witness.
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn r17_normal_source_spi_all_modes_required_without_admission(){
  for mode in [SourceMode::Fresh,SourceMode::Recovery,SourceMode::Transition]{
   let mut hold=ptr::null_mut();let mut view=std::mem::MaybeUninit::<SourceView>::uninit();
   // Exact default normal SPI writes only output hold; no metadata grant.
   unsafe{assert_eq!(veil_source_acquire(ptr::null_mut(),ptr::null(),ptr::null(),mode,&mut hold,view.as_mut_ptr()),REQUIRED);assert!(hold.is_null());veil_source_drop(&mut hold);assert!(hold.is_null());}
  }
 }
 #[test]fn r17_normal_source_transitions_and_validation_require_original_owner(){
  unsafe{assert_eq!(veil_source_validate(ptr::null_mut(),0),REQUIRED);assert_eq!(veil_source_validate(ptr::null_mut(),1),REQUIRED);
   assert_eq!(veil_private_initialize_source(ptr::null_mut(),ptr::null(),ptr::null()),REQUIRED);
   assert_eq!(veil_private_persist_revocation(ptr::null_mut(),ptr::null(),ptr::null()),REQUIRED);}
 }
}

// Exact R27 native-source inventory SHA; no issuer projection or adoption.
const SOURCE_HEADER_SHA256:&str="0296ca3b24d9081b3f2b09c2f341baa316386d90cc6762a85911dc192852bc6d";
const SOURCE_GRAPH_SHA256:&str="25e427a0ee11b1a868c64868374b30c4069441b1255e8b0556e1a756fdd81026";
