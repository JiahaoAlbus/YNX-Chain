//! Public custody projection, not authorized conversation/account data.
use super::*;
#[derive(serde::Serialize,PartialEq,Eq)]
pub(crate)struct ProductInventoryView{
 pub(crate)engine_present:bool,pub(crate)open_attempted:bool,
 pub(crate)admission_closed:bool,capacity:usize,entries:Vec<Entry>,
}
#[derive(serde::Serialize,PartialEq,Eq)]
struct Entry{selector:u64,kind:&'static str,phase:&'static str}
impl NativeProductController{
 pub(crate)fn product_inventory_view(&self)->Result<ProductInventoryView,ControllerError>{
  let mut entries=Vec::new();entries.try_reserve_exact(self.inventory.slots.len()).map_err(|_|ControllerError::Capacity)?;
  for slot in self.inventory.slots.iter().flatten(){
   let(kind,phase)=match &slot.value{
    #[cfg(feature="predevice-cold-v1")]Owned::ColdRecovery(_)=>("cold-local-custody","unverified-original-retained"),
    Owned::Operation(_)=>("message-operation","retained"),
    Owned::Pending(_)=>("message-operation","durable-pending"),
    Owned::RetainedDelivery{..}=>("message-operation","unknown-output-retained"),
    Owned::Delivery{..}=>("message-operation","delivery-held-recheck-required"),
    Owned::Message(m)=>{
     let phase=if m.failure.is_some(){"unknown-output-retained"}else if m.delivery.is_some(){"delivery-held-recheck-required"}else if m.pending.is_some(){"durable-pending"}else{match m.job.progress(){crate::product_message::Progress::Pending=>"preparing",crate::product_message::Progress::Prepared=>"prepared",crate::product_message::Progress::Stopped(_)=>"stopped-original-retained"}};
     ("message-operation",phase)
    },
    #[cfg(feature="abi5-final-native-link")]Owned::OwnKey(_)=>("local-key-custody","retained-not-device-trust"),
    #[cfg(feature="abi5-final-native-link")]Owned::LocalGenesis(_)=>("local-genesis","retained-not-enrollment"),
   };entries.push(Entry{selector:slot.id,kind,phase});
  }
  Ok(ProductInventoryView{engine_present:self.engine.is_some(),open_attempted:self.open_attempted,admission_closed:self.admission_closed,capacity:self.inventory.slots.len(),entries})
 }
}
#[cfg(all(test,feature="abi5-final-native-link"))]mod product_ports_inventory_controls{
 use super::*;
 #[test]fn product_ports_inventory_controls_actual_reservation_not_authorized(){
  let mut c=NativeProductController::new(2).unwrap_or_else(|_|panic!("inventory"));
  let before=c.product_inventory_view().unwrap_or_else(|_|panic!("view"));assert!(before.entries.is_empty());
  let input=match crate::private_custodian_ffi::LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30){Ok(v)=>v,Err(_)=>panic!("PUBLIC input")};
  let original=crate::private_custodian_ffi::LocalGenesisReservation::retain(input);
  let selector=c.reserve_local_genesis(original).unwrap_or_else(|_|panic!("normal reserve"));
  let view=c.product_inventory_view().unwrap_or_else(|_|panic!("view"));
  assert_eq!(view.entries.len(),1);assert_eq!(view.entries[0].selector,selector.routing_id());
  assert_eq!(view.entries[0].kind,"local-genesis");assert!(!view.engine_present);
  c.block_new_operations();assert!(c.product_inventory_view().unwrap_or_else(|_|panic!("view")).admission_closed);
 }
}
