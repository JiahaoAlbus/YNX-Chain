//! Exact frozen private PRE_DEVICE C ownership. Local UNVERIFIED, not trust.
#![allow(unsafe_code)]
use super::{LocalGenesisInput,CustodyError};
use std::{ffi::{c_char,c_void,CStr},marker::PhantomData,rc::Rc,thread::ThreadId};
#[repr(C)]struct Store{_private:[u8;0]}
#[repr(C)]struct Ticket{_private:[u8;0]}
#[repr(C)]struct ResultOwner{_private:[u8;0]}
#[repr(C)]#[derive(Clone,Copy)]pub(super)struct Bytes{pub(super)bytes:*const u8,pub(super)size:usize}
impl Bytes{fn none()->Self{Self{bytes:std::ptr::null(),size:0}}pub(super)fn borrow(b:&[u8])->Self{Self{bytes:b.as_ptr(),size:b.len()}}}
#[repr(C)]struct Original{operation:[u8;16],incarnation:[u8;16],storage_generation:i64,protected_record_version:u32,alias:Bytes,original_association:Bytes,classic_aad:Bytes,pq_aad:Bytes}
#[repr(C)]struct Pair{classic_record:Bytes,pq_record:Bytes,original_journal:Bytes,classic_aad:Bytes,pq_aad:Bytes}
/// Lifetime-bearing ciphertext loan; no raw pointer getter/Clone/JNI view.
pub(super)struct PairBorrow<'a>{pair:Pair,lifetime:PhantomData<&'a[u8]>}
impl<'a>PairBorrow<'a>{pub(super)fn from_slices(classic:&'a[u8],pq:&'a[u8],journal:&'a[u8],classic_aad:&'a[u8],pq_aad:&'a[u8])->Self{Self{pair:Pair{classic_record:Bytes::borrow(classic),pq_record:Bytes::borrow(pq),original_journal:Bytes::borrow(journal),classic_aad:Bytes::borrow(classic_aad),pq_aad:Bytes::borrow(pq_aad)},lifetime:PhantomData}}}
#[cfg_attr(not(feature="predevice-reconciliation-v3"),link(name="veil_predevice_pair_existing_v2",kind="static"))]
#[cfg_attr(feature="predevice-reconciliation-v3",link(name="veil_predevice_pair",kind="static"))]
unsafe extern "C"{
 fn veil_pd_open(path:*const c_char,out:*mut *mut Store)->i32;
 fn veil_pd_reserve(store:*mut Store,original:*const Original,expected:u64,out:*mut *mut Ticket)->i32;
 fn veil_pd_commit_pair(ticket:*mut Ticket,pair:*const Pair)->i32;
 fn veil_pd_lookup(store:*mut Store,operation:*const u8,out:*mut *mut ResultOwner)->i32;
 fn veil_pd_result_borrow(result:*mut ResultOwner,callback:extern "C" fn(*const Original,*const Pair,*mut c_void),context:*mut c_void)->i32;
 fn veil_pd_ticket_drop(out:*mut *mut Ticket)->i32;
 fn veil_pd_result_drop(out:*mut *mut ResultOwner)->i32;
 fn veil_pd_close(out:*mut *mut Store)->i32;
}
/// No foreign pointer constructor/getter; actual C outputs stored in same owner.
/// Local operation/incarnation are caller-owned bookkeeping, NOT source proof.
pub(super)struct PreDeviceOwner{
 #[cfg(feature="predevice-reconciliation-v3")] resolution:v3::State,
 store:*mut Store,ticket:*mut Ticket,result:*mut ResultOwner,
 operation:[u8;16],incarnation:[u8;16],thread:ThreadId,
 attempted:bool,generation_claimed:bool,readback_verified:bool,capture_attempted:bool,captured:Option<capture::StoredCiphertext>,capture_error:Option<capture::CaptureFailure>,first:Option<i32>,unknown:bool,commit_invocation:reconciliation::CommitInvocation,local:PhantomData<Rc<()>>,
}
impl PreDeviceOwner{
 pub(super)fn unopened(operation:[u8;16],incarnation:[u8;16])->Self{Self{#[cfg(feature="predevice-reconciliation-v3")]resolution:v3::State::new(),store:std::ptr::null_mut(),ticket:std::ptr::null_mut(),result:std::ptr::null_mut(),operation,incarnation,thread:std::thread::current().id(),attempted:false,generation_claimed:false,readback_verified:false,capture_attempted:false,captured:None,capture_error:None,first:None,unknown:false,commit_invocation:reconciliation::CommitInvocation::NotEntered,local:PhantomData}}
 fn thread(&self)->Result<(),CustodyError>{if self.thread!=std::thread::current().id(){Err(CustodyError::Thread)}else{Ok(())}}
 pub(super)fn live(&self)->Result<(),CustodyError>{self.thread()?;if self.unknown{return Err(CustodyError::Unknown)}#[cfg(feature="predevice-reconciliation-v3")]if self.resolution.started(){return Err(CustodyError::Phase)}if let Some(code)=self.first{return Err(CustodyError::Foreign(code))}Ok(())}
 fn failed(&mut self,code:i32)->CustodyError{if self.first.is_none(){self.first=Some(code)}self.unknown=true;CustodyError::Unknown}
 pub(super)fn reserve(&mut self,path:&CStr,input:&LocalGenesisInput)->Result<(),CustodyError>{
  self.live()?;if self.attempted{return Err(CustodyError::Phase)}
  self.attempted=true;
  let code=unsafe{veil_pd_open(path.as_ptr(),&mut self.store)};
  if code!=1{if !self.store.is_null(){self.unknown=true;std::process::abort()}return Err(self.failed(code))}
  if self.store.is_null(){return Err(self.failed(9))}
  let original=Original{operation:self.operation,incarnation:self.incarnation,storage_generation:input.generation as i64,protected_record_version:1,alias:Bytes::borrow(input.alias.as_bytes()),original_association:Bytes::borrow(&input.association),classic_aad:Bytes::none(),pq_aad:Bytes::none()};
  let code=unsafe{veil_pd_reserve(self.store,&original,0,&mut self.ticket)};
  if code!=2{if !self.ticket.is_null(){self.unknown=true;std::process::abort()}return Err(self.failed(code))}
  if self.ticket.is_null(){return Err(self.failed(9))}
  #[cfg(feature="predevice-reconciliation-v3")]self.resolution.reserved_here();
  Ok(())
 }
 /// Only exact durable C reserve2/nonNULL, current owner/phase permit this
 /// LOCAL one-shot claim. It issues NO device/source/firsttrust capability.
 pub(super)fn readback_complete(&self)->Result<bool,CustodyError>{self.live()?;Ok(self.generation_claimed&&self.readback_verified)}
 pub(super)fn reserved_ready(&self)->Result<(),CustodyError>{self.live()?;if self.ticket.is_null()||self.generation_claimed{Err(CustodyError::Phase)}else{Ok(())}}
 pub(super)fn claim_generation(&mut self)->Result<(),CustodyError>{self.live()?;if self.ticket.is_null()||self.generation_claimed{return Err(CustodyError::Phase)}self.generation_claimed=true;Ok(())}
 pub(super)fn commit(&mut self,borrowed:&PairBorrow<'_>)->Result<(),CustodyError>{self.live()?;if self.ticket.is_null()||!self.generation_claimed{return Err(CustodyError::Phase)}self.commit_invocation.enter();let code=unsafe{veil_pd_commit_pair(self.ticket,&borrowed.pair)};self.commit_invocation.returned(code);if code!=3{return Err(self.failed(code))}Ok(())}
 /// Lookup is allowed for the SAME original op even after uncertain commit.
 /// SEALED readback remains UNVERIFIED; does NOT clear sticky UNKNOWN.
 pub(super)fn verify_readback(&mut self,input:&LocalGenesisInput,borrowed:&PairBorrow<'_>)->Result<(),CustodyError>{
  self.thread()?;if self.store.is_null(){return Err(CustodyError::Phase)}
  if !self.result.is_null(){return Err(CustodyError::Phase)}
  let code=unsafe{veil_pd_lookup(self.store,self.operation.as_ptr(),&mut self.result)};
  if code!=3{if !self.result.is_null(){self.unknown=true;std::process::abort()}return Err(self.failed(code))}
  if self.result.is_null(){return Err(self.failed(9))}
  let mut comparison=Comparison{input,pair:&borrowed.pair,operation:&self.operation,incarnation:&self.incarnation,matched:false,panicked:false};
  let code=unsafe{veil_pd_result_borrow(self.result,compare,&mut comparison as *mut _ as *mut c_void)};
  if code!=3{return Err(self.failed(code))}
  if comparison.panicked||!comparison.matched{return Err(self.failed(5))}
  if self.unknown{Err(CustodyError::Unknown)}else{self.readback_verified=true;Ok(())}
 }
 /// Explicit disposal after caller's local custody decision, never a receipt
 /// or regeneration grant. UNKNOWN must remain in the original actor custody.
 pub(super)fn close_known(&mut self)->Result<(),CustodyError>{
  self.live()?;
  if !self.result.is_null(){let prior=self.result;let code=unsafe{veil_pd_result_drop(&mut self.result)};if(code==1&&!self.result.is_null())||(code!=1&&self.result!=prior){std::process::abort()}if code!=1{return Err(self.failed(code))}}
  if !self.ticket.is_null(){let prior=self.ticket;let code=unsafe{veil_pd_ticket_drop(&mut self.ticket)};if(code==1&&!self.ticket.is_null())||(code!=1&&self.ticket!=prior){std::process::abort()}if code!=1{return Err(self.failed(code))}}
  if !self.store.is_null(){let prior=self.store;let code=unsafe{veil_pd_close(&mut self.store)};if(code==1&&!self.store.is_null())||(code!=1&&self.store!=prior){std::process::abort()}if code!=1{return Err(self.failed(code))}}Ok(())
 }
}
impl Drop for PreDeviceOwner{fn drop(&mut self){if !self.store.is_null()||!self.ticket.is_null()||!self.result.is_null(){std::process::abort()}/* failstop only; NOT durable recovery */}}
struct Comparison<'a>{input:&'a LocalGenesisInput,pair:&'a Pair,operation:&'a[u8;16],incarnation:&'a[u8;16],matched:bool,panicked:bool}
unsafe fn equal(actual:Bytes,expected:Bytes,max:usize)->bool{if actual.size!=expected.size||actual.size==0||actual.size>max||actual.bytes.is_null()||expected.bytes.is_null(){return false}unsafe{std::slice::from_raw_parts(actual.bytes,actual.size)==std::slice::from_raw_parts(expected.bytes,expected.size)}}
extern "C" fn compare(original:*const Original,pair:*const Pair,context:*mut c_void){
 if original.is_null()||pair.is_null()||context.is_null(){return}
 let target=unsafe{&mut*(context as *mut Comparison<'_>)};
 let checked=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||unsafe{
  let original=&*original;let pair=&*pair;
  original.operation==*target.operation&&original.incarnation==*target.incarnation&&original.storage_generation==target.input.generation as i64&&original.protected_record_version==1&&
  equal(original.alias,Bytes::borrow(target.input.alias.as_bytes()),256)&&equal(original.original_association,Bytes::borrow(&target.input.association),4096)&&
  equal(original.classic_aad,target.pair.classic_aad,8192)&&equal(original.pq_aad,target.pair.pq_aad,8192)&&
  equal(pair.classic_record,target.pair.classic_record,19600)&&equal(pair.pq_record,target.pair.pq_record,19600)&&equal(pair.original_journal,target.pair.original_journal,19600)&&
  equal(pair.classic_aad,target.pair.classic_aad,8192)&&equal(pair.pq_aad,target.pair.pq_aad,8192)
 }));
 match checked{Ok(v)=>target.matched=v,Err(payload)=>{target.panicked=true;if std::panic::catch_unwind(std::panic::AssertUnwindSafe(||drop(payload))).is_err(){std::process::abort()}}}
}
#[cfg(test)]mod controls{
 use super::*;use std::ffi::CString;use std::os::unix::fs::DirBuilderExt;
 fn input()->LocalGenesisInput{LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".to_owned(),1,vec![7],30).unwrap_or_else(|_|panic!("public local input"))}
 fn path()->CString{let root=std::env::var_os("TMPDIR").unwrap_or_else(||panic!("owned external TMPDIR"));let name=format!("r43-nonsecret-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos());let dir=std::path::PathBuf::from(root).join(name);std::fs::DirBuilder::new().mode(0o700).create(&dir).unwrap();CString::new(dir.join("pair.sqlite3").as_os_str().as_encoded_bytes()).unwrap()}
 #[test]fn r43_predevice_actual_reserve_before_claim(){let mut owner=PreDeviceOwner::unopened([1;16],[2;16]);assert!(matches!(owner.claim_generation(),Err(CustodyError::Phase)));owner.reserve(&path(),&input()).unwrap();owner.claim_generation().unwrap();assert!(matches!(owner.claim_generation(),Err(CustodyError::Phase)));owner.close_known().unwrap();}
 #[test]fn r43_predevice_bound_input_layout_matches_header(){assert_eq!(std::mem::size_of::<Bytes>(),16);assert_eq!(std::mem::size_of::<Original>(),112);assert_eq!(std::mem::size_of::<Pair>(),80);}
}

mod capture;
#[cfg(feature="predevice-reconciliation-v3")]mod v3;
#[cfg(feature="predevice-reconciliation-v3")]pub(in crate::private_custodian_ffi)use v3::HeldDisposition;
#[cfg(feature="predevice-reconciliation-v3")]pub(crate)use v3::LocalStoreStage;
mod reconciliation;
pub(super)use reconciliation::RetainedReconciliation;
impl PreDeviceOwner{
 pub(super)fn capture_original_journal(&mut self,input:&LocalGenesisInput)->Result<&[u8],CustodyError>{self.capture_original_pair(input).map(|p|p.journal())}
}

mod existing;
pub(super)use existing::ExistingReader;
#[cfg(feature="predevice-cold-v1")]pub(super)use existing::Cleanup as ExistingCleanup;

impl PreDeviceOwner{pub(super)fn recovery_topology(&self)->super::RecoveryTopology{if !self.store.is_null(){super::RecoveryTopology::Held}else if self.attempted&&self.first.is_some()&&self.ticket.is_null()&&self.result.is_null(){super::RecoveryTopology::Existing}else{super::RecoveryTopology::Refused}}}
