//! Actual upstream codecs/SessionCipher; synthetic admission ONLY; owned lifetime is not secure-wipe proof.
use super::*;
use futures_util::FutureExt;
use rand::{rngs::OsRng,TryRngCore as _};
use std::{cell::Cell,time::SystemTime};
#[path="../../upstream_test_support.rs"]mod upstream;
fn secret(b:Vec<u8>)->SecretInput{SecretInput(Zeroizing::new(b))}
fn view()->Rc<CoherentView>{Rc::new(CoherentView{binding:[1,2,3,0,5,6,7,8,9,0,2],source_abi:[10;32],authority:ViewAuthority::Fixture})}
fn gate(v:&Rc<CoherentView>)->Gate{Gate(Rc::new(RefCell::new(Pending{phase:Phase::Working,binding:v.binding,bytes:0,journal:Vec::new(),original_ciphertext:None,generated_wire:false,selected_wire_kind:None,plaintext:None,trigger:None,pending:false})),Rc::new(spqr::ynx_operation::CallScope::fixture(v.binding)))}
fn packet()->(InMemSignalProtocolStore,InMemSignalProtocolStore,ProtocolAddress,ProtocolAddress,CiphertextMessage){
 let mut a=upstream::test_in_memory_protocol_store().unwrap();let mut b=upstream::test_in_memory_protocol_store().unwrap();let mut rng=OsRng.unwrap_err();let bundle=upstream::create_pre_key_bundle(&mut b,&mut rng).now_or_never().unwrap().unwrap();let alice=ProtocolAddress::new("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa".into(),DeviceId::new(1).unwrap());let bob=ProtocolAddress::new("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb".into(),bundle.device_id().unwrap());process_prekey_bundle(&bob,&alice,&mut a.session_store,&mut a.identity_store,&bundle,SystemTime::now(),&mut rng).now_or_never().unwrap().unwrap();let wire=upstream::encrypt(&mut a,&bob,&alice,"decoded actual PQXDH session").now_or_never().unwrap().unwrap();(a,b,alice,bob,wire)
}
fn input(s:&InMemSignalProtocolStore,peer:&ProtocolAddress,key:IdentityKey,policy:KyberPolicy)->AuthenticatedOwnedCohortInput{
 let v=view();let mut payloads=vec![Payload::LocalIdentity{pair:secret(s.get_identity_key_pair().now_or_never().unwrap().unwrap().serialize().into_vec()),registration:s.get_local_registration_id().now_or_never().unwrap().unwrap()},Payload::PeerIdentity{address:peer.clone(),key:secret(key.serialize().into_vec())}];
 for id in s.all_pre_key_ids(){let r=s.get_pre_key(*id).now_or_never().unwrap().unwrap();payloads.push(Payload::Ec{id:*id,body:EcPayload::Record(secret(r.serialize().unwrap()))});}
 for id in s.all_signed_pre_key_ids(){let r=s.get_signed_pre_key(*id).now_or_never().unwrap().unwrap();payloads.push(Payload::Signed{id:*id,body:secret(r.serialize().unwrap()),policy:SignedPolicy::ReceiveAllowed});}
 for id in s.all_kyber_pre_key_ids(){let r=s.get_kyber_pre_key(*id).now_or_never().unwrap().unwrap();payloads.push(Payload::Kyber{id:*id,body:Some(secret(r.serialize().unwrap())),policy,used:Vec::new()});}
 payloads.push(Payload::Session{address:peer.clone(),body:s.load_session(peer).now_or_never().unwrap().unwrap().map(|r|secret(r.serialize().unwrap()))});
 AuthenticatedOwnedCohortInput{rows:payloads.into_iter().map(|payload|AuthenticatedRow{view:v.clone(),version:1,payload}).collect(),view:v}
}
fn receiver_input()->(AuthenticatedOwnedCohortInput,ProtocolAddress,ProtocolAddress,CiphertextMessage){let(a,b,alice,bob,w)=packet();let i=input(&b,&alice,*a.get_identity_key_pair().now_or_never().unwrap().unwrap().identity_key(),KyberPolicy::OneTimeAvailable);(i,alice,bob,w)}
fn next_fixture_view(c:&DecodedCohort)->AuthenticatedOwnedCohortInput{
 let mut binding=c.view.binding;binding[4]+=1;
 let v=Rc::new(CoherentView{binding,source_abi:c.view.source_abi,authority:ViewAuthority::Fixture});
 let mut payloads=vec![Payload::LocalIdentity{pair:secret(c.identity.serialize().into_vec()),registration:c.registration}];
 for(a,k)in &c.peers{payloads.push(Payload::PeerIdentity{address:a.clone(),key:secret(k.serialize().into_vec())});}
 for(id,r)in &c.ec{payloads.push(Payload::Ec{id:*id,body:match r{EcEntry::Record(r)=>EcPayload::Record(secret(r.serialize().unwrap())),EcEntry::Missing=>EcPayload::Missing,EcEntry::Tombstone=>EcPayload::Tombstone}});}
 for(id,r)in &c.signed{payloads.push(Payload::Signed{id:*id,body:secret(r.record.serialize().unwrap()),policy:r.policy});}
 for(id,r)in &c.kyber{payloads.push(Payload::Kyber{id:*id,body:r.record.as_ref().map(|r|secret(r.serialize().unwrap())),policy:r.policy,used:r.used.clone()});}
 for(a,r)in &c.sessions{payloads.push(Payload::Session{address:a.clone(),body:r.as_ref().map(|r|secret(r.serialize().unwrap()))});}
 let rows=payloads.into_iter().map(|payload|{let version=*c.versions.get(&slot(&payload)).unwrap_or(&1);AuthenticatedRow{view:v.clone(),version,payload}}).collect();
 AuthenticatedOwnedCohortInput{view:v,rows}
}
#[test]fn cohort_all_selected_codecs_real_receive_then_real_reply(){
 let(mut a,b,alice,bob,w)=packet();let bi=input(&b,&alice,*a.get_identity_key_pair().now_or_never().unwrap().unwrap().identity_key(),KyberPolicy::OneTimeAvailable);let owner=decode(bi).unwrap_or_else(|e|panic!("{e:?}"));let fixture_owner=owner.0.clone();let v=owner.0.borrow().view.clone();let g=gate(&v);let(mut stage,signed)=owner.into_staging(g.clone()).unwrap_or_else(|_|panic!());let mut rng=OsRng.unwrap_err();g.retain_inbound(w.serialize()).unwrap();let clear=message_decrypt_with_scope(&w,&alice,&bob,&mut stage.sessions,&mut stage.identity,&mut stage.ec,signed.as_ref(),&mut stage.kyber,&mut rng,Some(&g.1)).now_or_never().unwrap().unwrap();assert_eq!(clear,b"decoded actual PQXDH session");assert_eq!(g.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert_eq!(g.0.borrow().journal.len(),4);
 // Same private snapshot now has actual updated session; reply is real native
 // encryption/peer decrypt, not published/durable/authorized production output.
 let next=decode(next_fixture_view(&fixture_owner.borrow())).unwrap_or_else(|e|panic!("{e:?}"));let next_gate=gate(&next.0.borrow().view);let(mut next_stage,_signed)=next.into_staging(next_gate.clone()).unwrap_or_else(|_|panic!());
 let reply=message_encrypt_with_native_retention(b"native decoded reply",&alice,&bob,&mut next_stage.sessions,&mut next_stage.identity,SystemTime::now(),&mut rng,Some(&next_gate.1)).now_or_never().unwrap().unwrap();assert!(next_gate.0.borrow().generated_wire);assert_eq!(g.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert_eq!(g.0.borrow().journal.len(),4);
 let received=message_decrypt(&reply,&bob,&alice,&mut a.session_store,&mut a.identity_store,&mut a.pre_key_store,&a.signed_pre_key_store,&mut a.kyber_pre_key_store,&mut rng).now_or_never().unwrap().unwrap();assert_eq!(received,b"native decoded reply");assert!(crate::open_production().is_err());
}
#[test]fn cohort_actual_established_session_decode_local_peer_registration_binding(){
 let(a,b,alice,bob,_)=packet();let mut i=input(&a,&bob,*b.get_identity_key_pair().now_or_never().unwrap().unwrap().identity_key(),KyberPolicy::LastResort);assert!(decode(i).is_ok());
 i=input(&a,&bob,*b.get_identity_key_pair().now_or_never().unwrap().unwrap().identity_key(),KyberPolicy::LastResort);if let Payload::LocalIdentity{registration,..}=&mut i.rows[0].payload{*registration+=1;}assert!(matches!(decode(i),Err(DecodeError::Binding)));let _=alice;
}
#[test]fn cohort_bound_preflight_count_row_total_before_decoder(){
 for which in 0..3{let(mut i,_,_,_)=receiver_input();match which{0=>{while i.rows.len()<=MAX_ROWS{i.rows.push(AuthenticatedRow{view:i.view.clone(),version:1,payload:Payload::Ec{id:999.into(),body:EcPayload::Missing}});}},1=>{if let Payload::PeerIdentity{key,..}=&mut i.rows[1].payload{*key=secret(vec![0;MAX_ROW_BYTES+1]);}},_=>{i.rows.retain(|r|matches!(r.payload,Payload::LocalIdentity{..}));for n in 0..17{i.rows.push(AuthenticatedRow{view:i.view.clone(),version:1,payload:Payload::Session{address:ProtocolAddress::new(format!("fixture-{n}"),DeviceId::new(1).unwrap()),body:Some(secret(vec![0;MAX_ROW_BYTES]))}});}}}let before=DECODED_RELEASES.with(Cell::get);assert!(matches!(decode(i),Err(DecodeError::Bound)));assert_eq!(DECODED_RELEASES.with(Cell::get),before);}
}
#[test]fn cohort_foreign_same_numeric_view_stale_version_and_missing_authority(){
 for failure in 0..2{let(mut i,_,_,_)=receiver_input();match failure{0=>i.rows[1].view=view(),_=>i.rows[1].version=0};assert!(matches!(decode(i),Err(DecodeError::Binding)));}assert!(matches!(acquire_authenticated_input(),Err(DecodeError::RequiredAuthenticatedCohort)));
}
#[test]fn cohort_corrupt_id_signature_and_partial_decode_cleanup(){
 for kind in 0..3{let(mut i,_,_,_)=receiver_input();match kind{0=>{if let Payload::PeerIdentity{key,..}=&mut i.rows[1].payload{*key=secret(vec![0xff]);}},1=>{for r in &mut i.rows{if let Payload::Ec{id,..}=&mut r.payload{*id=999.into();break;}}},_=>{for r in &mut i.rows{if let Payload::Signed{id,body,..}=&mut r.payload{let record=SignedPreKeyRecord::deserialize(body.bytes()).unwrap();let bad=SignedPreKeyRecord::new(*id,record.timestamp().unwrap(),&record.key_pair().unwrap(),&[0;64]);*body=secret(bad.serialize().unwrap());break;}}}}let releases=INPUT_RELEASES.with(Cell::get);let drops=DECODED_RELEASES.with(Cell::get);assert!(decode(i).is_err());assert!(INPUT_RELEASES.with(Cell::get)>releases);assert_eq!(DECODED_RELEASES.with(Cell::get),drops+1);}
}
#[test]fn cohort_signed_revoke_ec_tombstone_missing_and_one_time_reuse(){
 let(i,_,_,_)=receiver_input();let owner=decode(i).unwrap_or_else(|_|panic!());let c=owner.0.clone();let ec=*c.borrow().ec.keys().next().unwrap();let signed=*c.borrow().signed.keys().next().unwrap();let kyber=*c.borrow().kyber.keys().next().unwrap();let mut ec_store=EcProjection(c.clone());let mut k=KyberProjection(c.clone());let s=SignedProjection(c.clone());let mut rng=OsRng.unwrap_err();let base=KeyPair::generate(&mut rng).public_key;
 ec_store.remove_pre_key(ec).now_or_never().unwrap().unwrap();assert!(matches!(ec_store.get_pre_key(ec).now_or_never().unwrap(),Err(SignalProtocolError::InvalidPreKeyId)));assert!(matches!(ec_store.remove_pre_key(ec).now_or_never().unwrap(),Err(SignalProtocolError::InvalidPreKeyId)));c.borrow_mut().ec.insert(ec,EcEntry::Missing);assert!(ec_store.get_pre_key(ec).now_or_never().unwrap().is_err());
 k.mark_kyber_pre_key_used(kyber,signed,&base).now_or_never().unwrap().unwrap();assert!(k.get_kyber_pre_key(kyber).now_or_never().unwrap().is_err());assert!(k.mark_kyber_pre_key_used(kyber,signed,&base).now_or_never().unwrap().is_err());c.borrow_mut().signed.get_mut(&signed).unwrap().policy=SignedPolicy::Revoked;assert!(s.get_signed_pre_key(signed).now_or_never().unwrap().is_err());
}
#[test]fn cohort_last_resort_dedup_bound_and_inconsistent_policy(){
 let(mut i,_,_,_)=receiver_input();for r in &mut i.rows{if let Payload::Kyber{policy,..}=&mut r.payload{*policy=KyberPolicy::LastResort;}}let owner=decode(i).unwrap_or_else(|_|panic!());let c=owner.0.clone();let signed=*c.borrow().signed.keys().next().unwrap();let kyber=*c.borrow().kyber.keys().next().unwrap();let mut k=KyberProjection(c);let mut rng=OsRng.unwrap_err();for _ in 0..MAX_USES{let base=KeyPair::generate(&mut rng).public_key;k.mark_kyber_pre_key_used(kyber,signed,&base).now_or_never().unwrap().unwrap();assert!(k.mark_kyber_pre_key_used(kyber,signed,&base).now_or_never().unwrap().is_err());}assert!(k.get_kyber_pre_key(kyber).now_or_never().unwrap().is_ok());assert!(k.mark_kyber_pre_key_used(kyber,signed,&KeyPair::generate(&mut rng).public_key).now_or_never().unwrap().is_err());
 let(mut bad,_,_,_)=receiver_input();for r in &mut bad.rows{if let Payload::Kyber{policy,..}=&mut r.payload{*policy=KyberPolicy::OneTimeConsumed;}}assert!(matches!(decode(bad),Err(DecodeError::Policy)));
}
#[test]fn cohort_final_owner_lifetime_not_secure_zeroization_claim(){
 let(i,_,_,_)=receiver_input();let owner=decode(i).unwrap_or_else(|_|panic!());let drops=Rc::new(Cell::new(0));owner.0.borrow_mut().drop_count=Some(drops.clone());let g=gate(&owner.0.borrow().view);let(stage,signed)=owner.into_staging(g).unwrap_or_else(|_|panic!());drop(stage);assert_eq!(drops.get(),0);drop(signed);assert_eq!(drops.get(),1);
}

#[test]fn cohort_controlled_lifetime_replacement_budget_and_source_binding(){
 let(i,_,_,_)=receiver_input();let owner=decode(i).unwrap_or_else(|_|panic!());let c=owner.0.clone();let g=gate(&c.borrow().view);
 let slot=RecordSlot::LocalIdentity;let old=c.borrow().lifetime.serialized_bytes;
 assert!(replacement_budget(&mut c.borrow_mut(),slot.clone(),&vec![0;MAX_ROW_BYTES+1]).is_err());assert_eq!(c.borrow().lifetime.serialized_bytes,old);
 let missing=RecordSlot::Session(ProtocolAddress::new("not-selected".into(),DeviceId::new(1).unwrap()));assert!(replacement_budget(&mut c.borrow_mut(),missing,&[1]).is_err());
 c.borrow_mut().lifetime.serialized_bytes=MAX_INPUT_BYTES;let old_length=*c.borrow().serialized_lengths.get(&slot).unwrap();assert!(replacement_budget(&mut c.borrow_mut(),slot,&vec![0;old_length+1]).is_err());assert_eq!(c.borrow().lifetime.serialized_bytes,MAX_INPUT_BYTES);
 c.borrow_mut().lifetime.source_abi[0]^=1;assert!(matches!(owner.into_staging(g),Err(DecodeError::Binding)));
}

#[test]fn abi4_lifetime_actual_decoded_snapshot_protocol_then_required_store_preserves_owner(){
 let(i,a,b,w)=receiver_input();let g=gate(&i.view);let mut snapshot=super::super::platform::fixture_cohort_snapshot(i,g,w.serialize(),[10;32],false).unwrap_or_else(|_|panic!("cfgtest view"));
 let mut rng=OsRng.unwrap_err();snapshot.execute_receive(&a,&b,&w,&mut rng).now_or_never().unwrap().unwrap_or_else(|_|panic!("actual selected receive"));
 let snapshot=super::super::platform::fixture_closed_retention(snapshot);let retained=super::super::platform::fixture_cohort_gate(&snapshot);assert_eq!(retained.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert_eq!(retained.0.borrow().journal.len(),4);assert!(matches!(super::super::platform::NativeStoreBridge::open_platform(),Err(super::super::platform::PortError::RequiredCheckedSqlProducer)));assert!(crate::open_production().is_err());
}
#[test]fn abi4_lifetime_required_before_decode_returns_input_and_original_wire(){
 let(i,_,_,w)=receiver_input();let g=gate(&i.view);let before=DECODED_RELEASES.with(Cell::get);match super::super::platform::fixture_cohort_snapshot(i,g,w.serialize(),[10;32],true){Err(f)=>{let e=f.error();let g=f.gate();let input_returned=f.input().is_some();assert!(matches!(e,super::super::platform::PortError::RequiredNativeSourceAuthentication));assert!(input_returned);assert_eq!(g.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert!(g.0.borrow().journal.is_empty());assert_eq!(DECODED_RELEASES.with(Cell::get),before);},Ok(_)=>panic!("required admission")}
}
#[test]fn abi4_lifetime_source_mismatch_drops_decoded_not_original_wire(){
 let(i,_,_,w)=receiver_input();let g=gate(&i.view);let before=DECODED_RELEASES.with(Cell::get);match super::super::platform::fixture_cohort_snapshot(i,g,w.serialize(),[11;32],false){Err(f)=>{let e=f.error();let g=f.gate();let input_returned=f.input().is_some();assert!(matches!(e,super::super::platform::PortError::Binding));assert!(!input_returned);assert_eq!(g.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert_eq!(DECODED_RELEASES.with(Cell::get),before+1);},Ok(_)=>panic!("wrong source")}
}
#[test]fn abi4_lifetime_unknown_input_retained_without_decoder_or_cipher_replacement(){
 let(i,_,_,w)=receiver_input();let g=gate(&i.view);g.1.fixture_unknown();match super::super::platform::fixture_cohort_snapshot(i,g,w.serialize(),[10;32],false){Err(f)=>{let e=f.error();let g=f.gate();let input_returned=f.input().is_some();assert!(matches!(e,super::super::platform::PortError::Unknown));assert!(input_returned);assert_eq!(g.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert!(g.0.borrow().phase==Phase::Unknown);},Ok(_)=>panic!("unknown admitted")}
}

#[cfg(feature="abi5-final-native-link")]
#[test]fn abi4_final_actual_protocol_snapshot_then_linked_normal_c_required(){
 let(i,a,b,w)=receiver_input();let g=gate(&i.view);let mut snapshot=super::super::platform::fixture_cohort_snapshot(i,g,w.serialize(),[10;32],false).unwrap_or_else(|_|panic!("explicit cfgtest view"));let mut rng=OsRng.unwrap_err();snapshot.execute_receive(&a,&b,&w,&mut rng).now_or_never().unwrap().unwrap_or_else(|_|panic!("selected actual protocol"));super::super::platform::fixture_actual_final_store_required(&snapshot);let retained=super::super::platform::fixture_cohort_gate(&snapshot);assert_eq!(retained.0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));assert_eq!(retained.0.borrow().journal.len(),4);assert!(crate::open_production().is_err());
}

#[test]fn r13_borrowing_preflight_before_owned_slot_clones_and_map_reservations(){
 for session in [false,true]{for length in [129,256*1024]{
  let(mut i,_,_,_)=receiver_input();for row in &mut i.rows{match &mut row.payload{
   Payload::PeerIdentity{address,..} if !session=>*address=ProtocolAddress::new("x".repeat(length),DeviceId::new(1).unwrap()),
   Payload::Session{address,..} if session=>*address=ProtocolAddress::new("x".repeat(length),DeviceId::new(1).unwrap()),_=>{}}}
  let c=SLOT_CLONES.with(Cell::get);let m=MAP_RESERVATIONS.with(Cell::get);
  assert!(matches!(decode(i),Err(DecodeError::Bound)));assert_eq!(SLOT_CLONES.with(Cell::get),c);assert_eq!(MAP_RESERVATIONS.with(Cell::get),m);
 }}
 let(mut i,_,_,_)=receiver_input();for row in &mut i.rows{match &mut row.payload{Payload::PeerIdentity{address,..}|Payload::Session{address,..}=>*address=ProtocolAddress::new("x".repeat(128),DeviceId::new(1).unwrap()),_=>{}}}
 let c=SLOT_CLONES.with(Cell::get);let m=MAP_RESERVATIONS.with(Cell::get);assert!(decode(i).is_ok());assert_eq!(SLOT_CLONES.with(Cell::get)-c,4);assert_eq!(MAP_RESERVATIONS.with(Cell::get)-m,2);
}
#[test]fn r13_preflight_version_row_length_and_policy_before_owned_metadata(){
 for which in 0..3{
  let(mut i,_,_,_)=receiver_input();match which{
   0=>i.rows.last_mut().unwrap().version=0,
   1=>{for r in &mut i.rows{if let Payload::Session{body,..}=&mut r.payload{*body=Some(secret(vec![0;MAX_ROW_BYTES+1]));}}},
   _=>{for r in &mut i.rows{if let Payload::Kyber{body,..}=&mut r.payload{*body=None;}}}
  }
  let c=SLOT_CLONES.with(Cell::get);let m=MAP_RESERVATIONS.with(Cell::get);assert!(decode(i).is_err());assert_eq!(SLOT_CLONES.with(Cell::get),c);assert_eq!(MAP_RESERVATIONS.with(Cell::get),m);
 }
}
#[test]fn r13_predecode_actual_owners_survive_return_retry_then_explicit_release(){
 use super::super::platform as platform;
 for unknown in [false,true]{
  let(i,_,_,w)=receiver_input();let weak=Rc::downgrade(&i.view);let buffers=i.rows.iter().filter(|r|input_len(&r.payload)>0).count();let g=gate(&i.view);
  if unknown{g.1.fixture_unknown();}
  let drops=INPUT_RELEASES.with(Cell::get);let leases=platform::fixture_lease_releases();
  let failed=platform::fixture_cohort_snapshot(i,g,w.serialize(),[10;32],!unknown).err().expect("predecode refusal");
  assert!(failed.input().is_some());assert!(std::ptr::eq(weak.as_ptr(),Rc::as_ptr(&failed.input().unwrap().view)));assert_eq!(INPUT_RELEASES.with(Cell::get),drops);assert_eq!(platform::fixture_lease_releases(),leases);
  let failed=failed.retry_same_unavailable(w.serialize()).err().expect("same unavailable lease");
  assert!(matches!(failed.error(),platform::PortError::Unknown) == unknown);assert_eq!(INPUT_RELEASES.with(Cell::get),drops);assert_eq!(platform::fixture_lease_releases(),leases);assert_eq!(failed.gate().0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));
  drop(failed);assert_eq!(INPUT_RELEASES.with(Cell::get),drops+buffers);assert_eq!(platform::fixture_lease_releases(),leases+1);assert!(weak.upgrade().is_none());
 }
}
#[test]fn r13_codec_failure_consumes_and_cleans_input_but_returns_lease_and_wire(){
 use super::super::platform as platform;
 let(mut i,_,_,w)=receiver_input();for r in &mut i.rows{if let Payload::LocalIdentity{pair,..}=&mut r.payload{*pair=secret(vec![0]);}}
 let weak=Rc::downgrade(&i.view);let buffers=i.rows.iter().filter(|r|input_len(&r.payload)>0).count();let g=gate(&i.view);let drops=INPUT_RELEASES.with(Cell::get);let leases=platform::fixture_lease_releases();
 let failed=platform::fixture_cohort_snapshot(i,g,w.serialize(),[10;32],false).err().expect("codec failure");
 assert!(matches!(failed.error(),platform::PortError::Authentication));assert!(failed.input().is_none());assert_eq!(INPUT_RELEASES.with(Cell::get),drops+buffers);assert!(weak.upgrade().is_none());assert_eq!(platform::fixture_lease_releases(),leases);assert_eq!(failed.gate().0.borrow().original_ciphertext.as_deref(),Some(w.serialize()));drop(failed);assert_eq!(platform::fixture_lease_releases(),leases+1);
}
