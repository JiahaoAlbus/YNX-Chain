//! Normal single-worker ownership adapter. Selectors route; they never authorize.
mod view;
use crate::{NativeProductEngine,NativeProductOperation,NativeProductPending,NativeProductDelivery,NativeProductError,NativeProductCommit};
use libsignal_protocol::{ProtocolAddress,CiphertextMessage};
use std::{rc::Rc,task::{Context,Poll},time::SystemTime};

#[derive(Clone)]pub enum ControllerError { Native(NativeProductError), Capacity, InvalidSelector, WrongPhase, NotOpen, OpenPreviouslyRefused, AdmissionClosed, RequiredLifecycle }
#[derive(Clone)] pub struct RoutingSelector { owner:Rc<()>, id:u64 }
impl RoutingSelector { pub fn routing_id(&self)->u64 { self.id } }
struct Slot<T> { id:u64, value:T }
struct Inventory<T> { owner:Rc<()>, slots:Vec<Option<Slot<T>>>, next:u64 }
impl<T> Inventory<T> {
 fn new(limit:usize)->Result<Self,ControllerError> {
  if limit==0||limit>32 { return Err(ControllerError::Capacity) }
  let mut slots=Vec::new();slots.try_reserve_exact(limit).map_err(|_|ControllerError::Capacity)?;
  slots.resize_with(limit,||None);Ok(Self{owner:Rc::new(()),slots,next:0})
 }
 fn vacant(&self)->Result<usize,ControllerError> { if self.next==u64::MAX{return Err(ControllerError::Capacity)} self.slots.iter().position(Option::is_none).ok_or(ControllerError::Capacity) }
 fn insert_reserved(&mut self,index:usize,value:T)->RoutingSelector {
  // Called only after vacant(), with the exclusive same-controller borrow.
  self.next+=1;self.slots[index]=Some(Slot{id:self.next,value});RoutingSelector{owner:self.owner.clone(),id:self.next}
 }
 fn index(&self,s:&RoutingSelector)->Result<usize,ControllerError> {
  if !Rc::ptr_eq(&self.owner,&s.owner){return Err(ControllerError::InvalidSelector)}
  self.slots.iter().position(|x|x.as_ref().is_some_and(|v|v.id==s.id)).ok_or(ControllerError::InvalidSelector)
 }
}
enum Owned { #[cfg(feature="predevice-cold-v1")] ColdRecovery(crate::private_custodian_ffi::ColdRecovery), Operation(Rc<std::cell::RefCell<NativeProductOperation>>), Message(MessageOwned), Pending(NativeProductPending), Delivery{pending:NativeProductPending,delivery:NativeProductDelivery}, RetainedDelivery{pending:NativeProductPending,delivery:Option<NativeProductDelivery>,cause:NativeProductError}, #[cfg(feature="abi5-final-native-link")] OwnKey(crate::private_custodian_ffi::NativeOwnKeyCustody), #[cfg(feature="abi5-final-native-link")] LocalGenesis(crate::private_custodian_ffi::LocalGenesisReservation) }
/// Rc inventory and underlying engine keep this controller on one local executor.
/// No pointer factory, public authority constructor, JNI object or Send conversion.
pub struct NativeProductController { engine:Option<NativeProductEngine>, inventory:Inventory<Owned>, open_attempted:bool, admission_closed:bool,#[cfg(feature="abi5-final-native-link")]message_open_failure:Option<crate::staging::platform::OwnedMessageOriginal> }
impl NativeProductController {
 pub fn new(limit:usize)->Result<Self,ControllerError> { Ok(Self{engine:None,inventory:Inventory::new(limit)?,open_attempted:false,admission_closed:false,#[cfg(feature="abi5-final-native-link")]message_open_failure:None}) }
 pub fn open_native(&mut self)->Result<(),ControllerError> {
  if self.admission_closed{return Err(ControllerError::AdmissionClosed)}
  if self.engine.is_some(){return Ok(())}
  if self.open_attempted{return Err(ControllerError::OpenPreviouslyRefused)}
  self.open_attempted=true;self.engine=Some(NativeProductEngine::open_native().map_err(ControllerError::Native)?);Ok(())
 }
 /// Stops new local admission only. NOT shutdown, rollback, or durable recovery.
 pub fn block_new_operations(&mut self) { self.admission_closed=true; }
 pub fn acquire(&mut self)->Result<RoutingSelector,ControllerError> {
  if self.admission_closed{return Err(ControllerError::AdmissionClosed)}
  let index=self.inventory.vacant()?; // capacity reserved BEFORE native effects
  let engine=self.engine.as_mut().ok_or(ControllerError::NotOpen)?;
  let op=engine.acquire_operation().map_err(ControllerError::Native)?;
  Ok(self.inventory.insert_reserved(index,Owned::Operation(Rc::new(std::cell::RefCell::new(op)))))
 }
 pub async fn prepare_send<R:rand::Rng+rand::CryptoRng>(&mut self,s:&RoutingSelector,remote:&ProtocolAddress,local:&ProtocolAddress,clear:&[u8],now:SystemTime,rng:&mut R)->Result<(),ControllerError> {
  if self.admission_closed{return Err(ControllerError::AdmissionClosed)}
  let i=self.inventory.index(s)?;
  match &mut self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?.value {
   Owned::Operation(op)=>op.try_borrow_mut().map_err(|_|ControllerError::RequiredLifecycle)?.prepare_send(remote,local,clear,now,rng).await.map_err(ControllerError::Native),_=>Err(ControllerError::WrongPhase)
  }
 }
 pub async fn prepare_receive<R:rand::Rng+rand::CryptoRng>(&mut self,s:&RoutingSelector,remote:&ProtocolAddress,local:&ProtocolAddress,wire:&CiphertextMessage,rng:&mut R)->Result<(),ControllerError> {
  if self.admission_closed{return Err(ControllerError::AdmissionClosed)}
  let i=self.inventory.index(s)?;
  match &mut self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?.value {
   Owned::Operation(op)=>op.try_borrow_mut().map_err(|_|ControllerError::RequiredLifecycle)?.prepare_receive(remote,local,wire,rng).await.map_err(ControllerError::Native),_=>Err(ControllerError::WrongPhase)
  }
 }
 pub fn retain(&mut self,s:&RoutingSelector)->Result<(),ControllerError> {
  if self.admission_closed{return Err(ControllerError::AdmissionClosed)}
  let i=self.inventory.index(s)?;let engine=self.engine.as_mut().ok_or(ControllerError::NotOpen)?;
  let slot=self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?;
  let pending=match &mut slot.value{Owned::Operation(op)=>engine.retain_owned_operation(&mut *op.try_borrow_mut().map_err(|_|ControllerError::RequiredLifecycle)?).map_err(ControllerError::Native)?,_=>return Err(ControllerError::WrongPhase)};
  // Same slot remains occupied through every checked callback/unwind. On
  // success the operation's snapshot is already owned by receiver custody.
  slot.value=Owned::Pending(pending);Ok(())
 }
 pub fn poll(&mut self,s:&RoutingSelector,cx:&mut Context<'_>)->Poll<Result<NativeProductCommit,ControllerError>> {
  let i=match self.inventory.index(s){Ok(i)=>i,Err(e)=>return Poll::Ready(Err(e))};
  let Some(engine)=self.engine.as_mut() else{return Poll::Ready(Err(ControllerError::NotOpen))};
  let Some(slot)=self.inventory.slots[i].as_mut() else{return Poll::Ready(Err(ControllerError::InvalidSelector))};
  match &mut slot.value { Owned::Pending(pending)=>engine.poll_same_pending(pending,cx).map(|r|r.map_err(ControllerError::Native)),Owned::RetainedDelivery{..}=>Poll::Ready(Err(ControllerError::Native(NativeProductError::Unknown))),_=>Poll::Ready(Err(ControllerError::WrongPhase)) }
 }
 pub fn consume(&mut self,s:&RoutingSelector)->Result<(),ControllerError> {
  let i=self.inventory.index(s)?;let engine=self.engine.as_mut().ok_or(ControllerError::NotOpen)?;
  let slot=self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?;
  let result=match &mut slot.value {Owned::Pending(pending)=>engine.consume_committed(pending),Owned::RetainedDelivery{..}=>return Err(ControllerError::Native(NativeProductError::Unknown)),_=>return Err(ControllerError::WrongPhase)};
  let delivery=match result {Ok(v)=>v,Err(failure)=>{if failure.uncertain {let delivery=failure.delivery;let Slot{id,value}=self.inventory.slots[i].take().ok_or(ControllerError::InvalidSelector)?;let Owned::Pending(pending)=value else{unreachable!("exclusive phase borrow")};self.inventory.slots[i]=Some(Slot{id,value:Owned::RetainedDelivery{pending,delivery,cause:failure.error.clone()}});}return Err(ControllerError::Native(if failure.uncertain{NativeProductError::Unknown}else{failure.error}));}};
  let Slot{id,value}=self.inventory.slots[i].take().ok_or(ControllerError::InvalidSelector)?;
  let Owned::Pending(pending)=value else{unreachable!("exclusive phase borrow")};
  self.inventory.slots[i]=Some(Slot{id,value:Owned::Delivery{pending,delivery}});Ok(())
 }
 pub fn delivery(&mut self,s:&RoutingSelector)->Result<&NativeProductDelivery,ControllerError> {
  let i=self.inventory.index(s)?;let engine=self.engine.as_mut().ok_or(ControllerError::NotOpen)?;
  match &self.inventory.slots[i].as_ref().ok_or(ControllerError::InvalidSelector)?.value {
   Owned::RetainedDelivery{..}=>Err(ControllerError::Native(NativeProductError::Unknown)),
   Owned::Message(MessageOwned{failure:Some(cause),failure_unknown,..})=>Err(ControllerError::Native(if *failure_unknown{NativeProductError::Unknown}else{cause.clone()})),
   Owned::Delivery{pending,delivery}|Owned::Message(MessageOwned{pending:Some(pending),delivery:Some(delivery),..})=>{engine.validate_delivery(pending).map_err(ControllerError::Native)?;Ok(delivery)},
   _=>Err(ControllerError::WrongPhase),
  }
 }
 pub fn retire_consumed(&mut self,s:&RoutingSelector)->Result<(),ControllerError> {
  let i=self.inventory.index(s)?;let engine=self.engine.as_mut().ok_or(ControllerError::NotOpen)?;
  match &mut self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?.value {Owned::RetainedDelivery{..}=>return Err(ControllerError::Native(NativeProductError::Unknown)),Owned::Message(MessageOwned{failure:Some(cause),failure_unknown,..})=>return Err(ControllerError::Native(if *failure_unknown{NativeProductError::Unknown}else{cause.clone()})),Owned::Delivery{pending,..}=>engine.retire_consumed(pending).map_err(ControllerError::Native)?,Owned::Message(MessageOwned{pending:Some(pending),delivery:Some(_),..})=>engine.retire_consumed(pending).map_err(ControllerError::Native)?,_=>return Err(ControllerError::WrongPhase)};
  self.inventory.slots[i]=None;Ok(())
 }
 /// No implemented lifecycle source: preserve SAME owner and return explicit gap.
 pub fn cancel(&mut self,s:&RoutingSelector)->Result<(),ControllerError> {self.inventory.index(s)?;Err(ControllerError::RequiredLifecycle)}
 pub fn recover(&mut self,s:&RoutingSelector)->Result<(),ControllerError> {self.inventory.index(s)?;Err(ControllerError::RequiredLifecycle)}
}
// No custom destructor claims recovery. Underlying real owners retain their
// fail-closed Drop behavior; process death/UNKNOWN durable anchor remains Required.
#[cfg(test)]mod tests {
 use super::*;
 #[test]fn r32_controller_bounds_before_native(){assert!(matches!(NativeProductController::new(0),Err(ControllerError::Capacity)));assert!(matches!(NativeProductController::new(33),Err(ControllerError::Capacity)));let mut c=NativeProductController::new(1).unwrap_or_else(|_|panic!("allocation"));assert!(matches!(c.acquire(),Err(ControllerError::NotOpen)));assert_eq!(c.inventory.next,0);}
 #[test]fn r32_controller_open_real_required_sticky(){let mut c=NativeProductController::new(1).unwrap_or_else(|_|panic!("allocation"));assert!(matches!(c.open_native(),Err(ControllerError::Native(NativeProductError::RequiredRoots(_)))));assert!(matches!(c.open_native(),Err(ControllerError::OpenPreviouslyRefused)));assert!(c.engine.is_none());}
 #[test]fn r32_controller_closing_no_new_effect(){let mut c=NativeProductController::new(1).unwrap_or_else(|_|panic!("allocation"));c.block_new_operations();assert!(matches!(c.open_native(),Err(ControllerError::AdmissionClosed)));assert!(matches!(c.acquire(),Err(ControllerError::AdmissionClosed)));assert!(!c.open_attempted);}
 #[test]fn r32_controller_routing_capacity_cross_owner_stale(){let mut a=Inventory::new(1).unwrap_or_else(|_|panic!("allocation"));let b:Inventory<usize>=Inventory::new(1).unwrap_or_else(|_|panic!("allocation"));let s=a.insert_reserved(0,7usize);assert!(matches!(a.vacant(),Err(ControllerError::Capacity)));assert!(matches!(b.index(&s),Err(ControllerError::InvalidSelector)));a.slots[0]=None;let t=a.insert_reserved(a.vacant().unwrap_or_else(|_|panic!("vacancy")),9);assert!(matches!(a.index(&s),Err(ControllerError::InvalidSelector)));assert_eq!(t.routing_id(),2);}
 #[test]fn r32_controller_fixed_inventory_drop(){struct Value(Rc<std::cell::Cell<usize>>);impl Drop for Value{fn drop(&mut self){self.0.set(self.0.get()+1)}}let n=Rc::new(std::cell::Cell::new(0));{let mut a=Inventory::new(2).unwrap_or_else(|_|panic!("allocation"));a.insert_reserved(0,Value(n.clone()));a.insert_reserved(1,Value(n.clone()));assert_eq!(a.slots.len(),2);}assert_eq!(n.get(),2);}
}

impl NativeProductController{pub(crate)fn close_unopened_no_effect(&mut self)->Result<(),ControllerError>{if self.engine.is_some()||self.inventory.slots.iter().any(Option::is_some){return Err(ControllerError::RequiredLifecycle)}self.admission_closed=true;Ok(())}}

#[cfg(feature="abi5-final-native-link")]
impl NativeProductController {
 pub(crate) fn reserve_own_key(&mut self, original:crate::private_custodian_ffi::NativeOwnKeyCustody)
  ->Result<RoutingSelector,(ControllerError,crate::private_custodian_ffi::NativeOwnKeyCustody)>{
  if self.admission_closed{return Err((ControllerError::AdmissionClosed,original))}
  if !original.is_unopened(){return Err((ControllerError::WrongPhase,original))}
  let index=match self.inventory.vacant(){Ok(i)=>i,Err(e)=>return Err((e,original))};
  Ok(self.inventory.insert_reserved(index,Owned::OwnKey(original)))
 }
 pub(crate) fn own_key_mut(&mut self,s:&RoutingSelector)->Result<&mut crate::private_custodian_ffi::NativeOwnKeyCustody,ControllerError>{
  let i=self.inventory.index(s)?;
  match &mut self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?.value{Owned::OwnKey(owner)=>Ok(owner),_=>Err(ControllerError::WrongPhase)}
 }
}

#[cfg(feature="abi5-final-native-link")]
impl NativeProductController {
 pub(crate) fn reserve_local_genesis(&mut self,original:crate::private_custodian_ffi::LocalGenesisReservation)
  ->Result<RoutingSelector,(ControllerError,crate::private_custodian_ffi::LocalGenesisReservation)>{
  if self.admission_closed{return Err((ControllerError::AdmissionClosed,original))}
  let index=match self.inventory.vacant(){Ok(i)=>i,Err(e)=>return Err((e,original))};
  Ok(self.inventory.insert_reserved(index,Owned::LocalGenesis(original)))
 }
 pub(crate) fn local_genesis_required(&self,s:&RoutingSelector)->Result<(),ControllerError>{
  let i=self.inventory.index(s)?;
  let slot=self.inventory.slots[i].as_ref().ok_or(ControllerError::InvalidSelector)?;
  match &slot.value{
   Owned::LocalGenesis(owner)=>{if self.admission_closed{return Err(ControllerError::AdmissionClosed)}owner.durable_once_required().map_err(local_custody_error)},
   _=>Err(ControllerError::WrongPhase),
  }
 }
}
#[cfg(all(test,feature="abi5-final-native-link"))]
mod r41_reservation_controls {
 use super::*;
 use crate::private_custodian_ffi::{LocalGenesisInput,LocalGenesisReservation,CustodyError};
 fn input()->LocalGenesisReservation{
  let original=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".to_owned(),1,vec![9],30).unwrap_or_else(|_|panic!("structural public input"));
  LocalGenesisReservation::retain(original)
 }
 #[test] fn r41_shared_inventory_before_generation_and_no_exit(){
  let mut c=NativeProductController::new(1).unwrap_or_else(|_|panic!("inventory"));
  let s=c.reserve_local_genesis(input()).unwrap_or_else(|_|panic!("reserve"));
  assert!(matches!(c.local_genesis_required(&s),Err(ControllerError::RequiredLifecycle)));
  assert!(matches!(c.close_unopened_no_effect(),Err(ControllerError::RequiredLifecycle)));
  assert!(matches!(c.reserve_local_genesis(input()),Err((ControllerError::Capacity,_))));
  assert_eq!(c.inventory.next,1);assert!(c.engine.is_none());
 }
 #[test] fn r41_closing_keeps_original_slot_and_rejects_new(){
  let mut c=NativeProductController::new(2).unwrap_or_else(|_|panic!("inventory"));
  let s=c.reserve_local_genesis(input()).unwrap_or_else(|_|panic!("reserve"));
  let index=c.inventory.index(&s).unwrap_or_else(|_|panic!("same selector"));
  c.block_new_operations();
  assert!(matches!(c.local_genesis_required(&s),Err(ControllerError::AdmissionClosed)));
  assert!(matches!(c.reserve_local_genesis(input()),Err((ControllerError::AdmissionClosed,_))));
  assert_eq!(c.inventory.index(&s).unwrap_or_else(|_|panic!("retained")),index);
  assert_eq!(c.inventory.next,1);assert!(matches!(c.close_unopened_no_effect(),Err(ControllerError::RequiredLifecycle)));
 }
 #[test] fn r41_cross_controller_selector_cannot_route(){
  let mut a=NativeProductController::new(1).unwrap_or_else(|_|panic!("inventory"));
  let b=NativeProductController::new(1).unwrap_or_else(|_|panic!("inventory"));
  let s=a.reserve_local_genesis(input()).unwrap_or_else(|_|panic!("reserve"));
  assert!(matches!(b.local_genesis_required(&s),Err(ControllerError::InvalidSelector)));
 }
 #[test] fn r41_invalid_input_returns_original_allocation(){
  let association=vec![3;4097];let p=association.as_ptr();
  let (error,original)=match LocalGenesisInput::checked("bad".to_owned(),0,association,0){Err(v)=>v,Ok(_)=>panic!("invalid accepted")};
  assert_eq!(error,CustodyError::Bounds);
  // No effect/key/protector call occurred; original metadata is returned.
  drop(original);let _=p;
 }
}

#[cfg(feature="abi5-final-native-link")]
impl NativeProductController{
 pub(crate)fn local_genesis_owner_mut(&mut self,s:&RoutingSelector)->Result<&mut crate::private_custodian_ffi::LocalGenesisReservation,ControllerError>{
  self.local_genesis_failure(s)?;if self.admission_closed{return Err(ControllerError::AdmissionClosed)}let i=self.inventory.index(s)?;match &mut self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?.value{Owned::LocalGenesis(owner)=>Ok(owner),_=>Err(ControllerError::WrongPhase)}
 }
}

#[cfg(feature="abi5-final-native-link")]
pub(crate) fn local_custody_error(e:crate::private_custodian_ffi::CustodyError)->ControllerError{
 use crate::private_custodian_ffi::CustodyError;
 match e{CustodyError::Unknown|CustodyError::Foreign(_)=>ControllerError::Native(NativeProductError::Unknown),CustodyError::Thread=>ControllerError::Native(NativeProductError::Binding),_=>ControllerError::RequiredLifecycle}
}

// Test observation of custody only, not a production borrow bypass. UNKNOWN
// continues to reject local_genesis_owner_mut through local_genesis_failure.
#[cfg(all(test,feature="abi5-final-native-link"))]impl NativeProductController{
 pub(crate)fn fixture_local_binding_retention(&self,s:&RoutingSelector)->Result<(usize,Option<[u8;32]>,bool,bool),ControllerError>{
  let i=self.inventory.index(s)?;
  match &self.inventory.slots[i].as_ref().ok_or(ControllerError::InvalidSelector)?.value{
   Owned::LocalGenesis(owner)=>Ok(owner.fixture_binding_retention()),_=>Err(ControllerError::WrongPhase),
  }
 }
}
#[cfg(feature="abi5-final-native-link")]
impl NativeProductController{
 pub(crate)fn local_genesis_failure(&self,s:&RoutingSelector)->Result<(),ControllerError>{
  let i=self.inventory.index(s)?;match &self.inventory.slots[i].as_ref().ok_or(ControllerError::InvalidSelector)?.value{Owned::LocalGenesis(owner)=>owner.current_local().map_err(local_custody_error),_=>Err(ControllerError::WrongPhase)}
 }
 /// Closing forbids fresh effects, NOT same-original local readback recovery.
 /// This cannot generate/seal/commit a different pair or issue a receipt.
 pub(crate)fn recover_local_genesis_original(&mut self,s:&RoutingSelector)->Result<(),ControllerError>{
  let i=self.inventory.index(s)?;match &mut self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?.value{Owned::LocalGenesis(owner)=>owner.recover_original_cipher().map_err(local_custody_error),_=>Err(ControllerError::WrongPhase)}
 }
}
#[cfg(all(test,feature="abi5-final-native-link"))]
mod r44_closing_controls{
 use super::*;use crate::private_custodian_ffi::{LocalGenesisInput,LocalGenesisReservation};
 #[test]fn r44_closing_preserves_unknown_recovery_route(){
  let mut c=NativeProductController::new(1).unwrap_or_else(|_|panic!("inventory"));
  let original=LocalGenesisReservation::retain(LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".to_owned(),1,vec![9],30).unwrap_or_else(|_|panic!("metadata")));
  let s=c.reserve_local_genesis(original).unwrap_or_else(|_|panic!("reserve"));
  let path=std::ffi::CString::new("relative-public-refusal").unwrap();
  assert!(matches!(c.local_genesis_owner_mut(&s).unwrap_or_else(|_|panic!("same owner")).reserve_predevice(&path,[1;16],[2;16]),Err(crate::private_custodian_ffi::CustodyError::Unknown)));
  c.block_new_operations();
  assert!(matches!(c.local_genesis_owner_mut(&s),Err(ControllerError::Native(NativeProductError::Unknown))));
  assert!(matches!(c.recover_local_genesis_original(&s),Err(ControllerError::Native(NativeProductError::Unknown))));
  assert!(matches!(c.close_unopened_no_effect(),Err(ControllerError::RequiredLifecycle)));
  assert_eq!(c.inventory.next,1);assert_eq!(c.inventory.index(&s).unwrap_or_else(|_|panic!("retained route")),0);
 }
}
#[cfg(feature="abi5-final-native-link")]
impl NativeProductController{
 pub(crate)fn local_genesis_readback_complete(&self,s:&RoutingSelector)->Result<bool,ControllerError>{let i=self.inventory.index(s)?;match &self.inventory.slots[i].as_ref().ok_or(ControllerError::InvalidSelector)?.value{Owned::LocalGenesis(owner)=>owner.local_pair_readback_complete().map_err(local_custody_error),_=>Err(ControllerError::WrongPhase)}}
}

#[cfg(test)]impl NativeProductController{pub(crate)fn open_attempted_for_r48_test(&self)->bool{self.open_attempted}}

#[cfg(test)]impl NativeProductController{pub(crate)fn inventory_for_r51_test(&self)->(usize,u64){(self.inventory.slots.iter().filter(|s|s.is_some()).count(),self.inventory.next)}}

struct MessageOwned{failure_unknown:bool,failure:Option<NativeProductError>,failed_delivery:Option<NativeProductDelivery>,operation:Rc<std::cell::RefCell<NativeProductOperation>>,job:crate::product_message::MessageJob,pending:Option<NativeProductPending>,delivery:Option<NativeProductDelivery>}
#[derive(Debug,PartialEq,Eq)]pub(crate)enum MessageAdvance{Held,Committed}
impl NativeProductController{
 pub(crate)fn acquire_message(&mut self)->Result<RoutingSelector,ControllerError>{if self.inventory.next>=i64::MAX as u64{return Err(ControllerError::Capacity)}self.acquire()}
 fn message_index(&self,raw:i64)->Result<usize,ControllerError>{if raw<=0{return Err(ControllerError::InvalidSelector)}self.inventory.slots.iter().position(|x|x.as_ref().is_some_and(|s|s.id==raw as u64)).ok_or(ControllerError::InvalidSelector)}
 pub(crate)fn submit_message(&mut self,raw:i64,input:crate::product_message::MessageInput)->Result<MessageAdvance,ControllerError>{
  if self.admission_closed{return Err(ControllerError::AdmissionClosed)}
  if self.engine.is_none(){return Err(ControllerError::NotOpen)}
  let i=self.message_index(raw)?;let slot=self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?;
  if let Owned::Message(held)=&slot.value{
   if let Some(cause)=&held.failure{return Err(ControllerError::Native(if held.failure_unknown{NativeProductError::Unknown}else{cause.clone()}))}
   if !held.job.same_original(&input){return Err(ControllerError::Native(NativeProductError::Binding))}
   return match held.job.progress(){crate::product_message::Progress::Stopped(e)=>Err(ControllerError::Native(e)),_=>Ok(if held.delivery.is_some(){MessageAdvance::Committed}else{MessageAdvance::Held})}
  }
  let Owned::Operation(original)=&slot.value else{return Err(ControllerError::WrongPhase)};
  let operation=original.clone();
  // Job creation does not poll or move the operation out of its existing slot.
  // Any allocation/unwind/Required failure leaves original custody intact.
  let job=crate::product_message::MessageJob::new(operation.clone(),input).map_err(|(e,_original_input)|ControllerError::Native(e))?;
  slot.value=Owned::Message(MessageOwned{failure_unknown:false,failure:None,failed_delivery:None,operation,job,pending:None,delivery:None});Ok(MessageAdvance::Held)
 }
 pub(crate)fn advance_message(&mut self,raw:i64)->Result<MessageAdvance,ControllerError>{
  let i=self.message_index(raw)?;let engine=self.engine.as_mut().ok_or(ControllerError::NotOpen)?;
  let slot=self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?;
  let Owned::Message(held)=&mut slot.value else{return Err(ControllerError::WrongPhase)};
  if let Some(cause)=&held.failure{return Err(ControllerError::Native(if held.failure_unknown{NativeProductError::Unknown}else{cause.clone()}))}
  if held.delivery.is_some(){return Ok(MessageAdvance::Committed)}
  if held.pending.is_none(){
   match held.job.poll(){crate::product_message::Progress::Pending=>return Ok(MessageAdvance::Held),crate::product_message::Progress::Stopped(e)=>return Err(ControllerError::Native(e)),crate::product_message::Progress::Prepared=>{}}
   let mut operation=held.operation.try_borrow_mut().map_err(|_|ControllerError::RequiredLifecycle)?;
   held.pending=Some(engine.retain_owned_operation(&mut operation).map_err(ControllerError::Native)?);
  }
  let pending=held.pending.as_mut().ok_or(ControllerError::WrongPhase)?;
  let waker=held.job.waker();let mut cx=Context::from_waker(&waker);
  match engine.poll_same_pending(pending,&mut cx){
   Poll::Pending=>Ok(MessageAdvance::Held),Poll::Ready(Err(e))=>Err(ControllerError::Native(e)),
   Poll::Ready(Ok(NativeProductCommit::Committed))=>{match engine.consume_committed(pending){Ok(delivery)=>{held.delivery=Some(delivery);Ok(MessageAdvance::Committed)},Err(failure)=>{held.failed_delivery=failure.delivery;held.failure_unknown=failure.uncertain;held.failure=Some(failure.error.clone());Err(ControllerError::Native(if failure.uncertain{NativeProductError::Unknown}else{failure.error}))}}},
   Poll::Ready(Ok(NativeProductCommit::Unknown))=>Err(ControllerError::Native(NativeProductError::Unknown)),
   Poll::Ready(Ok(NativeProductCommit::Required))=>Err(ControllerError::Native(NativeProductError::RequiredReceipt)),
   Poll::Ready(Ok(NativeProductCommit::Held))=>Ok(MessageAdvance::Held),
   Poll::Ready(Ok(NativeProductCommit::Rejected))=>Err(ControllerError::Native(NativeProductError::Rejected)),
  }
 }
}
#[cfg(test)]mod r52_route_controls{
 use super::*;
 #[test]fn r52_untrusted_selector_cannot_create_operation(){let mut c=NativeProductController::new(2).unwrap_or_else(|_|panic!("inventory"));for id in [-1,0,1,i64::MAX]{assert!(matches!(c.advance_message(id),Err(ControllerError::InvalidSelector)));}assert_eq!(c.inventory_for_r51_test(),(0,0));assert!(matches!(c.acquire_message(),Err(ControllerError::NotOpen)));assert_eq!(c.inventory_for_r51_test(),(0,0));}
}

impl NativeProductController{
 /// Bounded application output, never keys/state. Repeated authorized reads
 /// return the same retained payload; they do not consume a second receipt.
 /// This does NOT retire the slot. Failed allocation/fence keeps all originals.
 pub(crate)fn copy_message_output(&mut self,raw:i64)->Result<zeroize::Zeroizing<Vec<u8>>,ControllerError>{
  let i=self.message_index(raw)?;let engine=self.engine.as_mut().ok_or(ControllerError::NotOpen)?;
  let slot=self.inventory.slots[i].as_ref().ok_or(ControllerError::InvalidSelector)?;
  if let Owned::Message(MessageOwned{failure:Some(cause),failure_unknown,..})=&slot.value{return Err(ControllerError::Native(if *failure_unknown{NativeProductError::Unknown}else{cause.clone()}))}
  let Owned::Message(MessageOwned{pending:Some(pending),delivery:Some(delivery),job,..})=&slot.value else{return Err(ControllerError::WrongPhase)};
  engine.validate_delivery(pending).map_err(ControllerError::Native)?;
  let output=delivery.encode_owned_output(job.logical()).map_err(ControllerError::Native)?;
  // Allocation is not authority. Revalidate before returning owned bytes.
  engine.validate_delivery(pending).map_err(ControllerError::Native)?;
  Ok(output)
 }
}

#[cfg(feature="abi5-final-native-link")]impl NativeProductController{
 pub(crate)fn local_recovery_loan(&mut self,s:&RoutingSelector)->Result<crate::private_custodian_ffi::RecoveryLoan<'_>,ControllerError>{
  if self.admission_closed{return Err(ControllerError::AdmissionClosed)}
  let i=self.inventory.index(s)?;match &mut self.inventory.slots[i].as_mut().ok_or(ControllerError::InvalidSelector)?.value{Owned::LocalGenesis(owner)=>owner.recovery_loan().map_err(local_custody_error),_=>Err(ControllerError::WrongPhase)}
 }
}

#[cfg(feature="predevice-cold-v1")]mod cold_install;

impl NativeProductController {
 // Only an actually consumed Message delivery can be retired by the product
 // message export. Local keys/genesis/pending and arbitrary selectors refuse.
 pub(crate)fn retire_message_output(&mut self,raw:i64)->Result<(),ControllerError>{
  let i=self.message_index(raw)?;
  if let Some(Slot{value:Owned::Message(MessageOwned{failure:Some(cause),failure_unknown,..}),..})=&self.inventory.slots[i]{return Err(ControllerError::Native(if *failure_unknown{NativeProductError::Unknown}else{cause.clone()}))}
  if !matches!(self.inventory.slots[i].as_ref().map(|s|&s.value),Some(Owned::Message(MessageOwned{pending:Some(_),delivery:Some(_),..}))){return Err(ControllerError::WrongPhase)}
  self.copy_message_output(raw)?; // Same native completion/current fence.
  let selector=RoutingSelector{owner:self.inventory.owner.clone(),id:raw as u64};
  self.retire_consumed(&selector)
 }
}

#[cfg(feature="abi5-final-native-link")]impl NativeProductController{
 pub(crate)fn begin_persistent_message(&mut self,session:&crate::staging::platform::MessageSessionOwner,input:crate::product_message::MessageInput)->Result<RoutingSelector,ControllerError>{
  if self.admission_closed{return Err(ControllerError::AdmissionClosed)}if self.engine.is_some()||self.message_open_failure.is_some(){return Err(ControllerError::Native(NativeProductError::Held))}
  if self.inventory.next>=i64::MAX as u64{return Err(ControllerError::Capacity)}self.inventory.vacant()?;
  let engine=match NativeProductEngine::from_persistent_session(session,&input){Ok(e)=>e,Err(f)=>{let error=match f.error{crate::staging::platform::SourceOwnerError::Required=>NativeProductError::RequiredSource,_=>NativeProductError::Unknown};let held=f.owner;if held.has_custody(){self.message_open_failure=Some(held);return Err(ControllerError::Native(NativeProductError::Unknown))}return Err(ControllerError::Native(error))}};
  self.engine=Some(engine);let selector=self.acquire_message()?;self.submit_message(selector.routing_id()as i64,input)?;Ok(selector)
 }
 pub(crate)fn close_persistent_operation(&mut self)->Result<(),ControllerError>{
  if self.inventory.slots.iter().any(|s|s.as_ref().is_some_and(|s|matches!(s.value,Owned::Operation(_)|Owned::Message(_)|Owned::Pending(_)|Owned::Delivery{..}|Owned::RetainedDelivery{..}))){return Err(ControllerError::RequiredLifecycle)}
  if let Some(held)=self.message_open_failure.as_mut(){held.close(None).map_err(|_|ControllerError::Native(NativeProductError::Unknown))?;}self.message_open_failure.take();
  if let Some(engine)=self.engine.as_mut(){engine.close_persistent_operation().map_err(ControllerError::Native)?;}self.engine.take();Ok(())
 }
}
