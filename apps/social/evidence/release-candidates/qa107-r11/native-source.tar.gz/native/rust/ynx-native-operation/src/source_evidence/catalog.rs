//! Signed catalog integrity and ordered revocation replay, NOT account authority.
use super::*;
use sha2::{Digest,Sha256};
use std::collections::HashMap;
#[derive(Serialize,Deserialize,PartialEq,Eq)]#[serde(deny_unknown_fields,rename_all="PascalCase")]
struct Binding{issuer:String,actor:String,account:String,device:String,identity:String,key:String,source:String,store:String,restore:String,schema:String,inode:String,operation:String,intent:String,generation:u64,base_revision:u64,next_revision:u64,base_digest:String,candidate_digest:String}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="PascalCase")]
struct Record{binding:Binding,kind:String,revoked_through:u64,proof:String}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields)]
struct Proof{version:u32,issuer:Envelope,anchor:Envelope}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
struct Body{version:u32,scope:Scope,kind:String,binding:Binding,revoked_through:u64}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
struct Anchor{version:u32,scope:Scope,issuer_envelope_digest:String,sequence:u64,disposition:String}
fn hash(raw:&[u8])->String{let h=Sha256::digest(raw);let mut out=String::with_capacity(64);for b in h{use std::fmt::Write;write!(&mut out,"{b:02x}").expect("String write")}out}
fn same_device(a:&Binding,b:&Binding)->bool{a.issuer==b.issuer&&a.account==b.account&&a.device==b.device}
fn same_store(a:&Binding,b:&Binding)->bool{same_device(a,b)&&a.source==b.source&&a.store==b.store&&a.restore==b.restore&&a.schema==b.schema&&a.inode==b.inode}
fn same_grant(a:&Binding,b:&Binding)->bool{same_store(a,b)&&a.actor==b.actor&&a.identity==b.identity&&a.key==b.key&&a.generation==b.generation}
fn validate(r:&Record)->Result<(),Error>{
 let b=&r.binding;
 if ![&b.issuer,&b.actor,&b.account,&b.device,&b.identity,&b.key,&b.source,&b.store,&b.restore,&b.schema,&b.inode].iter().all(|s|ascii(s,512))||b.generation==0{return Err(Error::Binding)}
 match r.kind.as_str(){
 "grant"|"revoke"=>{if !b.operation.is_empty()||!b.intent.is_empty()||b.base_revision!=0||b.next_revision!=0||!b.base_digest.is_empty()||!b.candidate_digest.is_empty()||if r.kind=="grant"{r.revoked_through!=0}else{r.revoked_through==0||r.revoked_through>b.generation}{return Err(Error::Binding)}},
 "inflight"|"unknown"|"final"=>{if !ascii(&b.operation,512)||!ascii(&b.intent,512)||b.next_revision<=b.base_revision||r.revoked_through!=0||!digest(&b.base_digest)||!digest(&b.candidate_digest){return Err(Error::Binding)}},
 _=>return Err(Error::Binding)}Ok(())
}
fn transition(rows:&[Record],r:&Record)->Result<(),Error>{
 let mut grant:Option<&Record>=None;let mut revoked=0;let mut operations=HashMap::new();
 for p in rows.iter().filter(|p|same_device(&p.binding,&r.binding)){
  if p.kind=="grant"&&grant.is_none_or(|g|p.binding.generation>g.binding.generation){grant=Some(p)}
  if p.kind=="revoke"{revoked=revoked.max(p.revoked_through)}
  if !p.binding.operation.is_empty(){operations.insert(p.binding.operation.as_str(),p);}
 }
 match r.kind.as_str(){
 "grant"=>{if r.binding.generation<=revoked||grant.is_some_and(|g|r.binding.generation<=g.binding.generation){return Err(Error::Binding)}},
 "revoke"=>{if grant.is_none_or(|g|!same_grant(&g.binding,&r.binding))||r.revoked_through<=revoked{return Err(Error::Binding)}},
 _=>{if let Some(last)=operations.get(r.binding.operation.as_str()){
  if last.binding!=r.binding||last.kind=="final"||r.kind=="inflight"||last.kind==r.kind&&last.proof==r.proof{return Err(Error::Binding)}
 }else{
  if r.kind!="inflight"||grant.is_none_or(|g|!same_grant(&g.binding,&r.binding))||r.binding.generation<=revoked||operations.values().any(|p|p.kind!="final"){return Err(Error::Binding)}
  if let Some(last)=rows.iter().rev().find(|p|p.kind=="final"&&same_store(&p.binding,&r.binding)){if r.binding.base_revision!=last.binding.next_revision||r.binding.base_digest!=last.binding.candidate_digest{return Err(Error::Binding)}}
 }}}
 Ok(())
}
pub(super)fn verify(raw:&[u8],issuer:&Credential,anchor:&Credential,h:&History)->Result<(),Error>{
 // ABI1 whole carrier stays <=393216. Larger supplier catalogs need a separately
 // reviewed bounded streaming transport, not silent truncation/admission.
 if raw.len()>393216||h.records>4096||hash(raw)!=h.catalog_digest{return Err(Error::Bounds)}
 let mut rows=Vec::new();let mut proof_ids=std::collections::HashSet::new();
 if raw.is_empty(){return if h.records==0{Ok(())}else{Err(Error::Binding)}}
 if raw.last()!=Some(&b'\n'){return Err(Error::Canonical)}
 for line in raw.split_inclusive(|b|*b==b'\n'){
  if line.len()>49152||rows.len()>=4096{return Err(Error::Bounds)}
  let r:Record=canonical(&line[..line.len()-1],49151)?;validate(&r)?;
  let b=&r.binding;if b.issuer!=issuer.authority||b.source!=issuer.scope.source||b.store!=issuer.scope.store||b.schema!=issuer.scope.schema||b.inode!=issuer.scope.inode||b.restore!=issuer.scope.restore{return Err(Error::Binding)}
  if r.proof.len()>32768_usize.div_ceil(3)*4{return Err(Error::Bounds)}
  let proof=base64::engine::general_purpose::STANDARD.decode(&r.proof).map_err(|_|Error::Canonical)?;
  if proof.is_empty()||proof.len()>32768||base64::engine::general_purpose::STANDARD.encode(&proof)!=r.proof||!proof_ids.insert(hash(&proof)){return Err(Error::Canonical)}
  let p:Proof=canonical(&proof,32768)?;if p.version!=1{return Err(Error::Binding)}
  let ib=verify_envelope(&p.issuer,"record-issuer",&issuer.public)?;let body:Body=canonical(&ib,32768)?;
  if body.version!=1||body.scope!=issuer.scope||body.kind!=r.kind||body.binding!=r.binding||body.revoked_through!=r.revoked_through{return Err(Error::Binding)}
  let ab=verify_envelope(&p.anchor,"record-anchor",&anchor.public)?;let a:Anchor=canonical(&ab,32768)?;
  let disposition=match r.kind.as_str(){"grant"=>"GRANT_RECORDED","revoke"=>"REVOKE_RECORDED","inflight"=>"INFLIGHT_RECORDED","unknown"=>"UNKNOWN_RECORDED","final"=>"FINAL_RECORDED",_=>return Err(Error::Binding)};
  let original=serde_json::to_vec(&p.issuer).map_err(|_|Error::Canonical)?;
  if a.version!=1||a.scope!=anchor.scope||a.sequence!=rows.len() as u64+1||a.disposition!=disposition||a.issuer_envelope_digest!=hash(&original){return Err(Error::Binding)}
  transition(&rows,&r)?;rows.push(r);current(h,now_ms()?)?;
 }
 if rows.len() as u64!=h.records{return Err(Error::Binding)}Ok(())
}
#[cfg(test)]mod catalog_controls{
 use super::*;
 fn row(kind:&str,g:u64,op:&str)->Record{Record{binding:Binding{issuer:"i".into(),actor:"a".into(),account:"c".into(),device:"d".into(),identity:"id".into(),key:"k".into(),source:"s".into(),store:"s".into(),restore:"r".into(),schema:"s".into(),inode:"n".into(),operation:op.into(),intent:if op.is_empty(){""}else{"intent"}.into(),generation:g,base_revision:0,next_revision:if op.is_empty(){0}else{1},base_digest:if op.is_empty(){String::new()}else{"a".repeat(64)},candidate_digest:if op.is_empty(){String::new()}else{"b".repeat(64)}},kind:kind.into(),revoked_through:if kind=="revoke"{g}else{0},proof:kind.into()}}
 #[test]fn catalog_controls_revocation_and_unknown_order(){let mut rows=vec![row("grant",1,"")];let inflight=row("inflight",1,"op");assert!(transition(&rows,&inflight).is_ok());rows.push(inflight);rows.push(row("unknown",1,"op"));assert!(transition(&rows,&row("inflight",1,"op")).is_err());assert!(transition(&rows,&row("inflight",1,"other")).is_err());let revoked=row("revoke",1,"");assert!(transition(&rows,&revoked).is_ok());rows.push(revoked);assert!(transition(&rows,&row("final",1,"op")).is_ok());assert!(transition(&rows,&row("grant",1,"")).is_err());assert!(transition(&rows,&row("grant",2,"")).is_ok());}
 #[test]fn catalog_controls_binding_shape(){assert!(validate(&row("grant",1,"")).is_ok());assert!(validate(&row("unknown",1,"op")).is_ok());let mut r=row("unknown",1,"op");r.binding.candidate_digest="A".repeat(64);assert!(validate(&r).is_err());assert_eq!(hash(b""),"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");}
}
