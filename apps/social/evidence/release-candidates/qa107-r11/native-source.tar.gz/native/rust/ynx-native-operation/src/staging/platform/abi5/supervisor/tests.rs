//! Real selected SessionCipher preparation + private synthetic foreign dispatch.
//! No actual native business issuer or C pointer producer is constructed.
use super::*;
use super::super::controls::Control;
fn setup()->(NativeStoreBridge,super::super::super::super::NativePendingHandle){let(mut b,mut s,a,local,wire)=super::super::super::super::tests::setup();super::super::super::super::tests::prepare(&mut s,&a,&local,&wire);let h=b.retain_prepared(s).unwrap_or_else(|_|panic!("actual snapshot retention"));(b,h)}
fn resources(b:&NativeStoreBridge,h:&super::super::super::super::NativePendingHandle)->NativeIssuedResources{NativeIssuedResources{proof:NativeIssuerProof::ControlledOnly,store:ptr::null_mut(),lease:ptr::null(),intent:ptr::null(),journal:vec![ptr::null();b.pending[&h.slot].snapshot.stage.gate.0.borrow().journal.len()],queue:IssuedQueue::Inbox(ptr::null()),actor:b.actor,issuer:b.issuer.clone(),bound:PhantomData}}
fn control(q:&mut NativeActorRegistry<'_>,t:Ticket)->Rc<std::cell::RefCell<Control>>{let c=Rc::new(std::cell::RefCell::new(Control::new()));q.slots[t.index].owner.as_mut().unwrap().controlled=Some(c.clone());c}
fn owner<'a,'op>(q:&'a NativeActorRegistry<'op>,t:Ticket)->&'a ForeignSlots<'op>{q.slots[t.index].owner.as_ref().unwrap()}
#[test]fn r21_owned_business_guard_drop_shutdown_recovery_preserves_actual_wire_journal(){
 let(mut b,h)=setup();let old=b.pending[&h.slot].snapshot.stage.gate.0.borrow();let wire=old.original_ciphertext.as_ref().unwrap().as_ptr();let journal=old.journal.as_ptr();let length=old.journal.len();drop(old);let mut r=resources(&b,&h);let lease_ptr=&r as *const _;
 let mut q=b.owned_supervisor().unwrap_or_else(|_|panic!());let t=q.bind_original(&mut b,&h,&mut r).unwrap_or_else(|_|panic!());assert!(b.pending.is_empty());assert_eq!(b.retained_bytes,0);let c=control(&mut q,t);
 {let mut op=q.operation(t).unwrap_or_else(|_|panic!());assert!(matches!(op.prepare(),Ok(MechanicalStatus::Prepared)));assert!(matches!(op.begin(),Ok(MechanicalStatus::Prepared)));}
 let before=c.borrow().calls;let same=owner(&q,t).write;assert!(!same.is_null());assert!(owner(&q,t).unknown);assert_eq!(owner(&q,t).original.snapshot.stage.gate.0.borrow().original_ciphertext.as_ref().unwrap().as_ptr(),wire);assert_eq!(owner(&q,t).original.snapshot.stage.gate.0.borrow().journal.as_ptr(),journal);assert_eq!(owner(&q,t).original.snapshot.stage.gate.0.borrow().journal.len(),length);assert_eq!(&*owner(&q,t).original.resources as *const _,lease_ptr);
 q=match q.shutdown(){Err(q)=>q,Ok(())=>panic!("lost business owner")};{let mut op=q.operation(t).unwrap_or_else(|_|panic!());assert!(matches!(op.prepare(),Err(PortError::Cancelled)));assert!(matches!(op.begin(),Err(PortError::Cancelled)));assert!(matches!(op.finish(),Err(PortError::Cancelled)));assert!(matches!(op.lookup(),Err(PortError::Cancelled)));assert!(matches!(op.publish(),Err(PortError::Cancelled)));}assert_eq!(c.borrow().calls,before);assert_eq!(owner(&q,t).write,same);
 {let mut cc=c.borrow_mut();cc.response(Action::Cancel,3,false);cc.response(Action::WriteDrop,UNKNOWN,false);}
 {let mut op=q.operation(t).unwrap_or_else(|_|panic!());assert!(matches!(op.recover_same_owner(),Ok(MechanicalStatus::HeldCleanup(3))));}assert_eq!(owner(&q,t).write,same);assert_eq!(owner(&q,t).cleanup_primary,Some(3));
 {let mut op=q.operation(t).unwrap_or_else(|_|panic!());assert!(matches!(op.recover_same_owner(),Ok(MechanicalStatus::Unknown)));}assert!(owner(&q,t).all_empty());let before=c.borrow().calls;
 {let mut op=q.operation(t).unwrap_or_else(|_|panic!());assert!(matches!(op.recover_same_owner(),Ok(MechanicalStatus::Unknown)));}assert_eq!(c.borrow().calls,before);assert!(owner(&q,t).unknown);q=match q.shutdown(){Err(q)=>q,Ok(())=>panic!("local disposal is not durable recovery")};q.fixture_teardown();
}
#[test]fn r21_owned_failed_begin_take_observe_failure_keeps_full_original(){
 let(mut b,h)=setup();let mut r=resources(&b,&h);let mut q=NativeActorRegistry::for_bridge(&b,1).unwrap_or_else(|_|panic!());let t=q.bind_original(&mut b,&h,&mut r).unwrap_or_else(|_|panic!());let c=control(&mut q,t);
 {let mut cc=c.borrow_mut();cc.stash=true;cc.response(Action::Begin,3,false);cc.response(Action::Take,4,false);}
 {let mut op=q.operation(t).unwrap_or_else(|_|panic!());assert!(op.prepare().is_ok());assert!(matches!(op.begin(),Ok(MechanicalStatus::HeldCleanup(3))));}
 assert!(owner(&q,t).store_cleanup_pending&&owner(&q,t).cleanup.is_null());assert_eq!(owner(&q,t).cleanup_primary,Some(3));assert!(owner(&q,t).unknown);
 c.borrow_mut().response(Action::Observe,UNKNOWN,false);{let mut op=q.operation(t).unwrap_or_else(|_|panic!());assert!(matches!(op.recover_same_owner(),Ok(MechanicalStatus::HeldCleanup(3))));}let same=owner(&q,t).cleanup;assert!(!same.is_null());assert_eq!(c.borrow().count(Action::CleanupDrop),0);assert!(owner(&q,t).observation.is_none());
 {let mut op=q.operation(t).unwrap_or_else(|_|panic!());assert!(matches!(op.recover_same_owner(),Ok(MechanicalStatus::Unknown)));}assert!(owner(&q,t).all_empty());assert_eq!(owner(&q,t).cleanup_primary,Some(3));assert_eq!(owner(&q,t).original.snapshot.stage.gate.0.borrow().journal.len(),4);q.fixture_teardown();
}
#[test]fn r21_capacity_and_closing_before_transfer_or_foreign_effect(){
 let(mut b,h)=setup();let mut r=resources(&b,&h);
 // Native original resource owners live OUTSIDE/longer than supervisor.
 let(_,mut s,a,local,w)=super::super::super::super::tests::setup();super::super::super::super::tests::prepare(&mut s,&a,&local,&w);let next=b.retain_prepared(s).unwrap_or_else(|_|panic!());let mut r2=resources(&b,&next);let mut r3=resources(&b,&next);
 let mut q=NativeActorRegistry::for_bridge(&b,1).unwrap_or_else(|_|panic!());let t=q.bind_original(&mut b,&h,&mut r).unwrap_or_else(|_|panic!());let c=control(&mut q,t);let before=c.borrow().calls;let before_bytes=b.retained_bytes;
 assert!(matches!(q.bind_original(&mut b,&next,&mut r2),Err(PortError::Capacity)));assert!(b.pending.contains_key(&next.slot));assert_eq!(b.retained_bytes,before_bytes);assert_eq!(c.borrow().calls,before);
 q=match q.shutdown(){Err(q)=>q,Ok(())=>panic!()};assert!(matches!(q.bind_original(&mut b,&next,&mut r3),Err(PortError::Cancelled)));assert!(b.pending.contains_key(&next.slot));assert_eq!(c.borrow().calls,before);assert_eq!(owner(&q,t).original.snapshot.stage.gate.0.borrow().journal.len(),4);q.fixture_teardown();
}
#[test]fn r21_same_actor_resource_borrow_binding_before_transfer(){
 let(mut b,h)=setup();let mut r=resources(&b,&h);r.actor+=1;let mut q=NativeActorRegistry::for_bridge(&b,1).unwrap_or_else(|_|panic!());assert!(matches!(q.bind_original(&mut b,&h,&mut r),Err(PortError::Binding)));assert!(b.pending.contains_key(&h.slot));assert!(q.slots.iter().all(|s|s.owner.is_none()));assert!(q.shutdown().is_ok());
 assert!(NativeStoreBridge::open_platform().is_err());assert!(crate::open_production().is_err()); // No production issuer factory added.
}
#[test]fn r21_normal_receiving_entry_empty_supervisor_shutdown_only(){let(b,_h)=setup();let q=b.owned_supervisor().unwrap_or_else(|_|panic!());assert!(q.slots.iter().all(|s|s.owner.is_none()));assert!(q.shutdown().is_ok());assert_eq!(b.pending.len(),1);}
