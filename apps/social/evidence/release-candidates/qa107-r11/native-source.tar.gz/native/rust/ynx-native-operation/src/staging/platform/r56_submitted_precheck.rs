//! Selected libsignal preparation plus PRIVATE state-machine controls only.
//! The submission-boundary interruption is modeled, not a real SQL commit,
//! device authorization, process-death recovery or two-client acceptance.
use super::*;
use std::{io::Write,process::Command,task::Waker};

fn prepared()->(NativeStoreBridge,NativePendingHandle){
 let(mut bridge,mut snapshot,remote,local,wire)=tests::setup();
 tests::prepare(&mut snapshot,&remote,&local,&wire);
 let pending=bridge.retain_prepared(snapshot).unwrap_or_else(|_|panic!("retain same fixture snapshot"));
 (bridge,pending)
}
fn poll(bridge:&mut NativeStoreBridge,pending:&mut NativePendingHandle)->Poll<Result<FinalStatus,PortError>>{
 bridge.poll_final(pending,&mut Context::from_waker(Waker::noop()))
}
fn transition(gate:&Gate,mode:&str){match mode{
 "cancel"=>gate.1.cancel(),"revoke"=>gate.1.fixture_revoke(),"rebind"=>gate.1.fixture_rebind(4),_=>panic!("unselected control"),
}}

#[test]fn r56_unsubmitted_terminal_precheck_remains_definite_rejection(){
 for mode in ["cancel","revoke","rebind"]{
  let(mut bridge,mut pending)=prepared();
  let gate=bridge.pending[&pending.slot].snapshot.stage.gate.clone();transition(&gate,mode);
  assert!(matches!(poll(&mut bridge,&mut pending),Poll::Ready(Err(_))));
  let retained=&bridge.pending[&pending.slot];
  assert!(!retained.submitted&&retained.definitely_not_applied);
  assert!(matches!(retained.completion,Completion::Rejected));
  assert!(!matches!(gate.0.borrow().phase,Phase::Unknown));
  if let NativeBackend::Fixture(sql)=&bridge.backend{assert_eq!((sql.submissions,sql.receipts,sql.lookups,sql.queues.len()),(0,0,0,0));}
  bridge.retire(&mut pending,RetireAcknowledgement::DefiniteRejection).unwrap_or_else(|_|panic!("known unsubmitted rejection"));
 }
}

#[test]fn r56_child_unresolved_submitted_precheck(){
 let Ok(mode)=std::env::var("YNX_R56_CHILD_MODE")else{return};
 let(mut bridge,mut pending)=prepared();
 // Model interruption after the irreversible submission marker and before a
 // result was recorded. Do not fabricate an applied receipt or SQL outcome.
 let original={let retained=bridge.pending.get_mut(&pending.slot).unwrap();retained.submitted=true;
  let state=retained.snapshot.stage.gate.0.borrow();
  (state.original_ciphertext.as_ref().unwrap().as_ptr(),state.journal.as_ptr(),state.journal.len(),retained.reserved_bytes)};
 let gate=bridge.pending[&pending.slot].snapshot.stage.gate.clone();
 transition(&gate,&mode);
 assert!(!gate.1.has_uncertain_outcome(),"control must not pre-set scope UNKNOWN");
 assert!(validate_computation(&bridge.pending[&pending.slot].snapshot).is_err());
 for _ in 0..2{assert!(matches!(poll(&mut bridge,&mut pending),Poll::Ready(Ok(FinalStatus::Unknown))));}
 let retained=&bridge.pending[&pending.slot];
 assert!(retained.submitted&&!retained.definitely_not_applied&&!retained.consumed);
 assert!(matches!(retained.completion,Completion::Unknown));
 let state=retained.snapshot.stage.gate.0.borrow();
 assert!(state.phase==Phase::Unknown);
 assert_eq!((state.original_ciphertext.as_ref().unwrap().as_ptr(),state.journal.as_ptr(),state.journal.len(),retained.reserved_bytes),original);
 drop(state);
 assert!(matches!(bridge.cancel(&mut pending),Err(PortError::Unknown)));
 assert!(matches!(bridge.consume_once(&mut pending),Err(PortError::Unknown)));
 for ack in [RetireAcknowledgement::DefiniteRejection,RetireAcknowledgement::ConsumedOutput]{assert!(matches!(bridge.retire(&mut pending,ack),Err(PortError::Unknown)));}
 if let NativeBackend::Fixture(sql)=&bridge.backend{assert_eq!((sql.submissions,sql.receipts,sql.lookups,sql.queues.len()),(0,0,0,0));}else{panic!("private fixture only")}
 println!("R56-UNRESOLVED-CHECKED-{mode}");std::io::stdout().flush().unwrap();
 // Existing fail-stop policy must still reject dropping unresolved custody.
 drop(bridge);panic!("unresolved custody was silently discarded");
}

#[test]fn r56_submitted_terminal_precheck_retains_unknown_without_resubmission(){
 use std::os::unix::process::ExitStatusExt;
 let exact=format!("{}::r56_child_unresolved_submitted_precheck",module_path!().split_once("::").unwrap().1);
 for mode in ["cancel","revoke","rebind"]{
  let result=Command::new(std::env::current_exe().unwrap()).args(["--exact",&exact,"--nocapture"]).env("YNX_R56_CHILD_MODE",mode).output().unwrap();
  assert!(String::from_utf8_lossy(&result.stdout).contains(&format!("R56-UNRESOLVED-CHECKED-{mode}")),"child did not complete control: {}",String::from_utf8_lossy(&result.stderr));
  assert_eq!(result.status.signal(),Some(6),"existing unresolved-owner fail-stop changed");
 }
}

#[test]fn r56_known_fixture_receipt_is_not_reclassified_unknown(){
 for mode in ["cancel","revoke","rebind"]{
  let(mut bridge,mut pending)=prepared();
  assert!(matches!(poll(&mut bridge,&mut pending),Poll::Ready(Ok(FinalStatus::FixtureApplied))));
  let gate=bridge.pending[&pending.slot].snapshot.stage.gate.clone();transition(&gate,mode);
  assert!(matches!(poll(&mut bridge,&mut pending),Poll::Ready(Err(_))));
  assert!(matches!(bridge.pending[&pending.slot].completion,Completion::FixtureApplied));
  assert!(!matches!(gate.0.borrow().phase,Phase::Unknown));
  assert!(bridge.consume_once(&mut pending).is_err());
  if let NativeBackend::Fixture(sql)=&bridge.backend{assert_eq!((sql.submissions,sql.receipts,sql.lookups,sql.queues.len()),(1,1,0,1));}
  // Test-only disposal after observing the recorded synthetic terminal result.
  // This is not a production acknowledgement or a real authenticated receipt.
  drop(bridge.pending.remove(&pending.slot));
 }
}
