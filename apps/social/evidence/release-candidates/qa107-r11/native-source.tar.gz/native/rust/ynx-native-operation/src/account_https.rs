//! Fixed-origin native HTTPS transport. TLS bytes are NOT an account capability.
//! No redirect, proxy, shared cookie jar, environment endpoint or automatic retry.
use std::{io::{Read,Write},net::{TcpStream,ToSocketAddrs,SocketAddr},sync::{Arc,OnceLock,mpsc},time::{Instant,Duration,SystemTime,UNIX_EPOCH}};
use rustls_platform_verifier::BuilderVerifierExt;
use zeroize::Zeroizing;
const HOST:&str="social.ynxweb4.com";
// Transport route only; canonical TLS identity and all admission stay unchanged.
#[derive(Clone,Copy,PartialEq,Eq,Debug)]
pub(crate) enum ConnectPeer { SystemDns, M1Qa }
impl ConnectPeer {
 fn fixed(self)->Option<SocketAddr>{match self{Self::SystemDns=>None,Self::M1Qa=>Some(SocketAddr::from(([43,134,23,58],443)))}}
}
std::thread_local!{static PREPARING_PEER:std::cell::Cell<ConnectPeer>=const{std::cell::Cell::new(ConnectPeer::SystemDns)};}
// One synchronous worker entry only. Panic/refusal also resets the route; no
// transport choice is stored in an authority, request body or global DNS table.
pub(crate) fn with_prepare_peer<R>(peer:ConnectPeer,f:impl FnOnce()->R)->R{
 struct Reset;impl Drop for Reset{fn drop(&mut self){PREPARING_PEER.with(|v|v.set(ConnectPeer::SystemDns));}}
 PREPARING_PEER.with(|v|v.set(peer));let _reset=Reset;f()
}
pub(crate) fn take_prepare_peer()->ConnectPeer{PREPARING_PEER.with(|v|v.replace(ConnectPeer::SystemDns))}

const HEADER_LIMIT:usize=16384;
const BODY_LIMIT:usize=65536;
#[derive(Clone,Copy,PartialEq,Eq,Debug)]
pub(crate) enum Error{Window,Cancelled,Busy,Io,Tls,Protocol,Bounds,Unknown}
#[derive(Clone,Copy)]pub(crate) enum Action{Capture,Join}
impl Action{fn path(self)->&'static str{match self{Self::Capture=>"/m1qa/v4/first-device/account-capture",Self::Join=>"/m1qa/v4/first-device/account-join"}}}
// Only local request liveness. This type neither verifies nor authorizes account
// facts. Callers retain the actual RecoveryLoan and independently gate service
// instance/current before lending any credential to exchange().
pub(crate) struct Window{pub(crate) start:Instant,pub(crate) budget:Duration,pub(crate) issued:i64,pub(crate) expires:i64}
impl Window{
 pub(crate) fn remaining(&self)->Result<Duration,Error>{
  let wall=SystemTime::now().duration_since(UNIX_EPOCH).map_err(|_|Error::Window)?.as_millis();
  if wall>i64::MAX as u128 || (wall as i64)<self.issued || (wall as i64)>=self.expires{return Err(Error::Window)}
  let rest=self.budget.checked_sub(self.start.elapsed()).ok_or(Error::Window)?;
  let rest=rest.min(Duration::from_millis((self.expires-wall as i64)as u64));
  if rest.is_zero(){Err(Error::Window)}else{Ok(rest)}
 }
}
struct Resolve{reply:mpsc::SyncSender<Result<Vec<SocketAddr>,Error>>}
// At most one OS DNS operation plus one queued request. No credentials/owners
// enter this thread. Stuck OS DNS cannot accumulate unbounded worker threads.
fn resolve(window:&Window,live:&mut impl FnMut()->Result<(),Error>)->Result<Vec<SocketAddr>,Error>{
 static RESOLVER:OnceLock<Result<mpsc::SyncSender<Resolve>,Error>>=OnceLock::new();
 let sender=RESOLVER.get_or_init(||{
  let(tx,rx)=mpsc::sync_channel::<Resolve>(1);
  std::thread::Builder::new().name("ynx-fixed-peer-dns".into()).spawn(move||{
   while let Ok(job)=rx.recv(){let answer=(HOST,443).to_socket_addrs().map(|v|v.take(16).collect()).map_err(|_|Error::Io);let _=job.reply.try_send(answer);}
  }).map_err(|_|Error::Io)?;Ok(tx)
 });
 let tx=sender.as_ref().map_err(|e|*e)?;
 let(answer,rx)=mpsc::sync_channel(1);live()?;window.remaining()?;
 tx.try_send(Resolve{reply:answer}).map_err(|_|Error::Busy)?;
 loop{live()?;let remaining=window.remaining()?;match rx.recv_timeout(remaining.min(Duration::from_millis(100))){Ok(v)=>return v,Err(mpsc::RecvTimeoutError::Timeout)=>{},Err(_)=>return Err(Error::Io)}}
}
// PRIVATE returned bytes; no Debug, Serialize or JNI/JS publication. A later
// qualified receiver still needs independent instance/current and ROLE proofs.
pub(crate) struct UnadmittedResponse{pub(crate) body:Zeroizing<Vec<u8>>,pub(crate) exporter:Option<String>,pub(crate) eligibility:Option<Zeroizing<Vec<u8>>>}
// Bound EVERY socket read/write, including rustls complete_io's internal loop;
// an outer handshake check alone cannot fence a peer dripping handshake bytes.
struct CheckedSocket<'a,F:FnMut()->Result<(),Error>>{tcp:TcpStream,window:&'a Window,live:&'a mut F,stopped:Option<Error>}
impl<F:FnMut()->Result<(),Error>> CheckedSocket<'_,F>{
 fn check(&mut self)->std::io::Result<Duration>{
  let result=(self.live)().and_then(|_|self.window.remaining());
  match result{Ok(v)=>Ok(v),Err(e)=>{if self.stopped.is_none(){self.stopped=Some(e)}Err(std::io::Error::other("original transport stopped"))}}
 }
}
impl<F:FnMut()->Result<(),Error>> Read for CheckedSocket<'_,F>{
 fn read(&mut self,b:&mut[u8])->std::io::Result<usize>{let d=self.check()?;self.tcp.set_read_timeout(Some(d.min(Duration::from_millis(100))))?;self.tcp.read(b)}
}
impl<F:FnMut()->Result<(),Error>> Write for CheckedSocket<'_,F>{
 fn write(&mut self,b:&[u8])->std::io::Result<usize>{let d=self.check()?;self.tcp.set_write_timeout(Some(d.min(Duration::from_millis(100))))?;self.tcp.write(b)}
 fn flush(&mut self)->std::io::Result<()>{self.check()?;self.tcp.flush()}
}
fn request(action:Action,cookie:&[u8],body:&[u8])->Result<Zeroizing<Vec<u8>>,Error>{
 if cookie.is_empty()||cookie.len()>8192||!cookie.iter().all(|b|matches!(*b,0x21..=0x7e)|(*b==b' '))||body.is_empty()||body.len()>8192{return Err(Error::Bounds)}
 let mut out=Zeroizing::new(Vec::with_capacity(cookie.len()+body.len()+400));
 write!(&mut *out,"POST {} HTTP/1.0\r\nHost: {}\r\nOrigin: https://{}\r\nContent-Type: application/json\r\nAccept: application/json\r\nAccept-Encoding: identity\r\nCache-Control: no-store\r\nConnection: close\r\nCookie: ",action.path(),HOST,HOST).map_err(|_|Error::Io)?;
 out.extend_from_slice(cookie);write!(&mut *out,"\r\nContent-Length: {}\r\n\r\n",body.len()).map_err(|_|Error::Io)?;out.extend_from_slice(body);Ok(out)
}
fn header(bytes:&[u8])->Result<Option<usize>,Error>{
 if bytes.len()>HEADER_LIMIT{return Err(Error::Bounds)}
 let text=std::str::from_utf8(bytes).map_err(|_|Error::Protocol)?;
 let mut lines=text.split("\r\n");let first=lines.next().ok_or(Error::Protocol)?;
 let mut status=first.splitn(3,' ');
 if !matches!(status.next(),Some("HTTP/1.0"|"HTTP/1.1"))||status.next()!=Some("200"){return Err(Error::Protocol)}
 let mut content_length=None;let mut content_type=false;let mut content_encoding=false;let mut fields=0;
 for line in lines{if line.is_empty(){continue}fields+=1;if fields>64||line.starts_with([' ','\t']){return Err(Error::Bounds)}
  let(k,v)=line.split_once(':').ok_or(Error::Protocol)?;
  if k.is_empty()||!k.bytes().all(|b|b.is_ascii_alphanumeric()||b==b'-')||v.bytes().any(|b|b<32&&b!=9||b==127){return Err(Error::Protocol)}
  let v=v.trim();
  if k.eq_ignore_ascii_case("content-length"){
   if content_length.is_some()||v.is_empty()||!v.bytes().all(|b|b.is_ascii_digit()){return Err(Error::Protocol)}
   let n=v.parse::<usize>().map_err(|_|Error::Bounds)?;if n>BODY_LIMIT{return Err(Error::Bounds)}content_length=Some(n);
  }else if k.eq_ignore_ascii_case("content-type"){
   if content_type||!(v.eq_ignore_ascii_case("application/json")||v.eq_ignore_ascii_case("application/json; charset=utf-8")){return Err(Error::Protocol)}content_type=true;
  }else if k.eq_ignore_ascii_case("content-encoding"){
   if content_encoding||!v.eq_ignore_ascii_case("identity"){return Err(Error::Protocol)}content_encoding=true;
  }else if k.eq_ignore_ascii_case("transfer-encoding")||k.eq_ignore_ascii_case("location")||k.eq_ignore_ascii_case("set-cookie"){return Err(Error::Protocol)}
 }
 if !content_type{return Err(Error::Protocol)}Ok(content_length)
}
fn receive(input:&mut impl Read,mut check:impl FnMut()->Result<(),Error>)->Result<UnadmittedResponse,Error>{
 let mut raw=Zeroizing::new(Vec::new());let mut split=None;let mut expected=None;let mut buf=Zeroizing::new([0u8;2048]);
 loop{
  check()?;
  let n=match input.read(&mut *buf){Ok(n)=>n,Err(e)if matches!(e.kind(),std::io::ErrorKind::TimedOut|std::io::ErrorKind::WouldBlock)=>continue,Err(_)=>return Err(Error::Io)};
  if n==0{break}
  if raw.len().checked_add(n).filter(|n|*n<=HEADER_LIMIT+BODY_LIMIT).is_none(){return Err(Error::Bounds)}raw.extend_from_slice(&buf[..n]);
  if split.is_none(){
   if let Some(at)=raw.windows(4).position(|v|v==b"\r\n\r\n"){if at+4>HEADER_LIMIT{return Err(Error::Bounds)}expected=header(&raw[..at+2])?;split=Some(at+4)}else if raw.len()>HEADER_LIMIT{return Err(Error::Bounds)}
  }
  if let Some(at)=split{let size=raw.len()-at;if size>BODY_LIMIT||expected.is_some_and(|n|size>n){return Err(Error::Bounds)}}
 }
 check()?;let at=split.ok_or(Error::Protocol)?;let body=&raw[at..];
 if body.is_empty()||expected.is_some_and(|n|n!=body.len())||std::str::from_utf8(body).is_err(){return Err(Error::Protocol)}
 Ok(UnadmittedResponse{eligibility:eligibility_header(&raw[..at])?,exporter:None,body:Zeroizing::new(body.to_vec())})
}
// One physical exchange only. On error after dispatch the caller must retain
// original uncertainty; this function never retries HTTP, rotates cookie or
// claims NOT_APPLIED. Liveness callback is NOT an authority supplier.
pub(crate) fn exchange_bound(action:Action,cookie:&[u8],body:&[u8],window:&Window,bootstrap:&crate::account_instance::Bootstrap,nonce:&[u8;32],connect_peer:ConnectPeer,mut live:impl FnMut()->Result<(),Error>)->Result<UnadmittedResponse,Error>{
 bootstrap.current().map_err(|_|Error::Window)?;let wire=request(action,cookie,body)?;live()?;window.remaining()?;
 let peers=match connect_peer.fixed(){Some(peer)=>{live()?;window.remaining()?;vec![peer]},None=>resolve(window,&mut live)?};
 let peer=peers.first().ok_or(Error::Io)?; // no failover/re-dispatch
 live()?;
 let socket=TcpStream::connect_timeout(peer,window.remaining()?.min(Duration::from_secs(3))).map_err(|_|Error::Io)?;
 socket.set_read_timeout(Some(Duration::from_millis(100))).map_err(|_|Error::Io)?;
 socket.set_write_timeout(Some(window.remaining()?.min(Duration::from_secs(1)))).map_err(|_|Error::Io)?;
 let config=rustls::ClientConfig::builder_with_provider(Arc::new(rustls::crypto::ring::default_provider()))
  .with_protocol_versions(&[&rustls::version::TLS13]).map_err(|_|Error::Tls)?
  .with_platform_verifier().map_err(|_|Error::Tls)?.with_no_client_auth();
 let name=rustls::pki_types::ServerName::try_from(HOST).map_err(|_|Error::Tls)?;
 let conn=rustls::ClientConnection::new(Arc::new(config),name).map_err(|_|Error::Tls)?;
 let socket=CheckedSocket{tcp:socket,window,live:&mut live,stopped:None};
 let mut tls=rustls::StreamOwned::new(conn,socket);
 while tls.conn.is_handshaking(){match tls.conn.complete_io(&mut tls.sock){Ok(_)=>{},Err(e)if matches!(e.kind(),std::io::ErrorKind::TimedOut|std::io::ErrorKind::WouldBlock)=>{},Err(_)=>return Err(tls.sock.stopped.unwrap_or(Error::Tls))}}
 let certificate=tls.conn.peer_certificates().and_then(|v|v.first()).ok_or(Error::Tls)?;
 bootstrap.peer(certificate.as_ref()).map_err(|_|Error::Tls)?;
 let mut material=tls.conn.export_keying_material([0u8;32],b"EXPORTER-YNX-SOCIAL-NATIVE-ACCOUNT-V1",Some(nonce)).map_err(|_|Error::Tls)?;
 let exporter=crate::account_instance::hash(&material);material.fill(0);
 // Platform peer success is not instance/profile admission. This raw component
 // has no public entry; genuine caller admission must precede exchange.
 tls.sock.check().map_err(|_|tls.sock.stopped.unwrap_or(Error::Unknown))?;
 tls.write_all(&wire).map_err(|_|tls.sock.stopped.unwrap_or(Error::Unknown))?;
 tls.flush().map_err(|_|tls.sock.stopped.unwrap_or(Error::Unknown))?;
 let result=receive(&mut tls,||window.remaining().map(|_|()));
 let mut response=publish_response(result,tls.sock.stopped,window,tls.sock.live)?;
 bootstrap.current().map_err(|_|Error::Window)?;window.remaining()?;
 response.exporter=Some(exporter);Ok(response)
}
// This is the production publication seam, including buffered TLS completion.
// Earlier socket/parser errors win. Refusal drops the Zeroizing response without
// retrying IO or renewing the original clock budget.
fn publish_response(result:Result<UnadmittedResponse,Error>,stopped:Option<Error>,window:&Window,live:&mut impl FnMut()->Result<(),Error>)->Result<UnadmittedResponse,Error>{
 if let Some(error)=stopped{return Err(error)}
 let response=result?;
 live()?;
 window.remaining()?;
 Ok(response)
}
#[cfg(test)]mod controls{
 use super::*;
 #[test]fn aht_publication_buffered_completion_cancel(){
  let cancelled=std::cell::Cell::new(false);let w=current_window();
  let mut live=||if cancelled.get(){Err(Error::Cancelled)}else{Ok(())};
  live().unwrap(); // Last physical socket check was successful.
  struct Buffered<'a>{bytes:std::io::Cursor<&'static [u8]>,cancelled:&'a std::cell::Cell<bool>,reads:usize}
  impl Read for Buffered<'_>{fn read(&mut self,out:&mut[u8])->std::io::Result<usize>{self.reads+=1;let n=self.bytes.read(out)?;if n==0{self.cancelled.set(true)}Ok(n)}}
  let mut buffered=Buffered{bytes:std::io::Cursor::new(b"HTTP/1.0 200 OK\r\nContent-Type: application/json\r\nContent-Length: 2\r\n\r\n{}"),cancelled:&cancelled,reads:0};
  // Identical clock-only receive callback to exchange, not a test-aware fence.
  let result=receive(&mut buffered,||w.remaining().map(|_|()));
  assert!(result.is_ok());let reads=buffered.reads;
  assert!(matches!(publish_response(result,None,&w,&mut live),Err(Error::Cancelled)));
  assert_eq!(buffered.reads,reads);
 }
 #[test]fn aht_publication_original_window_and_success(){
  for (w,valid) in [(current_window(),true),(Window{start:Instant::now()-Duration::from_secs(2),budget:Duration::from_secs(1),issued:0,expires:i64::MAX},false),(Window{start:Instant::now(),budget:Duration::from_secs(5),issued:i64::MAX-1,expires:i64::MAX},false)]{
   let response=Ok(UnadmittedResponse{eligibility:None,exporter:None,body:Zeroizing::new(b"{}".to_vec())});let mut calls=0;
   let result=publish_response(response,None,&w,&mut ||{calls+=1;Ok(())});
   assert_eq!(calls,1);if valid{assert!(result.is_ok())}else{assert!(matches!(result,Err(Error::Window)))}
  }
 }
 #[test]fn aht_publication_preserves_first_error(){
  let w=current_window();let mut calls=0;let mut live=||{calls+=1;Err(Error::Cancelled)};
  assert!(matches!(publish_response(Err(Error::Protocol),Some(Error::Window),&w,&mut live),Err(Error::Window)));
  assert!(matches!(publish_response(Err(Error::Protocol),None,&w,&mut live),Err(Error::Protocol)));
  assert_eq!(calls,0);
 }
 fn socket_pair()->(TcpStream,TcpStream){
  let listener=std::net::TcpListener::bind("127.0.0.1:0").expect("PUBLIC loopback listener");
  let sender=TcpStream::connect(listener.local_addr().expect("PUBLIC address")).expect("PUBLIC connect");
  let(receiver,_)=listener.accept().expect("PUBLIC accept");(sender,receiver)
 }
 fn current_window()->Window{Window{start:Instant::now(),budget:Duration::from_secs(5),issued:0,expires:i64::MAX}}
 #[test]fn account_https_socket_cancel_checks_each_io(){
  // Local PUBLIC bytes only, no external peer, TLS identity or credentials.
  let(mut peer,tcp)=socket_pair();peer.write_all(b"ab").expect("PUBLIC write");
  let cancelled=std::cell::Cell::new(false);let w=current_window();
  let mut live=||if cancelled.get(){Err(Error::Cancelled)}else{Ok(())};
  let mut socket=CheckedSocket{tcp,window:&w,live:&mut live,stopped:None};
  let mut b=[0];assert_eq!(socket.read(&mut b).unwrap(),1);assert_eq!(b,b"a"[..]);
  cancelled.set(true);assert!(socket.read(&mut b).is_err());assert_eq!(b,b"a"[..]);
  assert!(socket.write(b"public").is_err());assert!(socket.flush().is_err());
  assert_eq!(socket.stopped,Some(Error::Cancelled));
 }
 #[test]fn account_https_socket_original_budget_and_wall_lower_bound(){
  for w in [Window{start:Instant::now()-Duration::from_secs(2),budget:Duration::from_secs(1),issued:0,expires:i64::MAX},Window{start:Instant::now(),budget:Duration::from_secs(5),issued:i64::MAX-1,expires:i64::MAX}]{
   let(mut peer,tcp)=socket_pair();peer.write_all(b"x").unwrap();let mut live=||Ok(());
   let mut socket=CheckedSocket{tcp,window:&w,live:&mut live,stopped:None};let mut b=[0];
   assert!(socket.read(&mut b).is_err());assert_eq!(b,[0]);assert!(socket.write(b"x").is_err());
   assert_eq!(socket.stopped,Some(Error::Window));
  }
 }
 #[test]fn account_https_exact_body_and_header_caps(){
  for size in [BODY_LIMIT,BODY_LIMIT+1]{
   let mut raw=b"HTTP/1.0 200 OK\r\nContent-Type: application/json\r\n\r\n".to_vec();raw.resize(raw.len()+size,b'x');
   let result=receive(&mut std::io::Cursor::new(raw),||Ok(()));
   if size==BODY_LIMIT{assert_eq!(result.unwrap().body.len(),BODY_LIMIT)}else{assert!(matches!(result,Err(Error::Bounds)))}
  }
  for total in [HEADER_LIMIT,HEADER_LIMIT+1]{
   let mut raw=b"HTTP/1.0 200 OK\r\nContent-Type: application/json\r\nX-Public: ".to_vec();raw.resize(total-4,b'x');raw.extend_from_slice(b"\r\n\r\n{}");
   let result=receive(&mut std::io::Cursor::new(raw),||Ok(()));
   if total==HEADER_LIMIT{assert_eq!(&*result.unwrap().body,b"{}")}else{assert!(matches!(result,Err(Error::Bounds)))}
  }
 }
 #[test]fn account_https_late_receive_cancellation_keeps_refusal(){
  let mut calls=0;let mut input=std::io::Cursor::new(b"HTTP/1.0 200 OK\r\nContent-Type: application/json\r\n\r\n{}");
  assert!(matches!(receive(&mut input,||{calls+=1;if calls>=2{Err(Error::Cancelled)}else{Ok(())}}),Err(Error::Cancelled)));
  assert_eq!(calls,2);
 }
 #[test]fn account_https_fixed_request(){let v=request(Action::Capture,b"a=b",b"{}").unwrap();assert!(v.starts_with(b"POST /m1qa/v4/first-device/account-capture HTTP/1.0\r\nHost: social.ynxweb4.com\r\n"));assert!(request(Action::Join,b"a=b\r\nX:y",b"{}").is_err());assert!(request(Action::Join,&vec![b'x';8193],b"{}").is_err());}
 #[test]fn account_https_strict_response(){for bad in ["HTTP/1.1 302 Found\r\nContent-Type: application/json\r\n", "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nTransfer-Encoding: chunked\r\n","HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 2\r\nContent-Length: 2\r\n","HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nSet-Cookie: x=y\r\n"]{assert!(header(bad.as_bytes()).is_err())}
 let mut input=std::io::Cursor::new(b"HTTP/1.0 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: 2\r\n\r\n{}");let output=receive(&mut input,||Ok(())).unwrap();assert_eq!(&*output.body,b"{}");
 let mut input=std::io::Cursor::new(b"HTTP/1.0 200 OK\r\nContent-Type: application/json\r\nContent-Length: 1\r\n\r\n{}");assert!(receive(&mut input,||Ok(())).is_err());}
 #[test]fn account_https_cancel_and_original_clock(){let mut input=std::io::Cursor::new(b"HTTP/1.0 200 OK\r\nContent-Type: application/json\r\n\r\n{}");assert!(matches!(receive(&mut input,||Err(Error::Cancelled)),Err(Error::Cancelled)));let w=Window{start:Instant::now()-Duration::from_secs(2),budget:Duration::from_secs(1),issued:0,expires:i64::MAX};assert!(w.remaining().is_err());}
}
// Existing A M1 v2 transport header. It is opaque evidence, never a grant.
// Product host must forward the exact original signed bytes, not reserialize.
fn eligibility_header(raw:&[u8])->Result<Option<Zeroizing<Vec<u8>>>,Error>{
 use base64::{Engine as _,engine::general_purpose::URL_SAFE_NO_PAD as B64};
 let text=std::str::from_utf8(raw).map_err(|_|Error::Protocol)?;let mut out=None;
 for line in text.split("\r\n").skip(1){
  let Some((key,value))=line.split_once(':')else{continue};
  if key.eq_ignore_ascii_case("x-ynx-social-account-eligibility-v1"){return Err(Error::Protocol)}
  if key.eq_ignore_ascii_case("x-ynx-social-account-eligibility-v2"){
   if out.is_some(){return Err(Error::Protocol)}let value=value.trim();if value.is_empty()||value.len()>10923{return Err(Error::Bounds)}
   let bytes=Zeroizing::new(B64.decode(value).map_err(|_|Error::Protocol)?);
   if bytes.is_empty()||bytes.len()>8192||B64.encode(&*bytes)!=value||std::str::from_utf8(&bytes).is_err(){return Err(Error::Protocol)}out=Some(bytes);
  }
 }
 Ok(out)
}
#[cfg(test)]mod instance_r2_controls_http{
 use super::*;use base64::{Engine as _,engine::general_purpose::URL_SAFE_NO_PAD as B64};
 #[test]fn exact_m1_pending_header_retained_private(){let encoded=B64.encode(b"PUBLIC ONLY");let wire=format!("HTTP/1.0 200 OK\r\nContent-Type: application/json\r\nx-ynx-social-account-eligibility-v2: {encoded}\r\nContent-Length: 2\r\n\r\n{{}}");let r=receive(&mut std::io::Cursor::new(wire.into_bytes()),||Ok(())).unwrap();assert_eq!(r.eligibility.unwrap().as_slice(),b"PUBLIC ONLY");}
 #[test]fn pending_header_v1_duplicate_padding_and_bound_refuse(){for h in ["x-ynx-social-account-eligibility-v1: e30".to_string(),"x-ynx-social-account-eligibility-v2: e30\r\nx-ynx-social-account-eligibility-v2: e30".into(),"x-ynx-social-account-eligibility-v2: e30=".into(),format!("x-ynx-social-account-eligibility-v2: {}",B64.encode(vec![b'x';8193]))]{let wire=format!("HTTP/1.0 200 OK\r\nContent-Type: application/json\r\n{h}\r\n\r\n{{}}");assert!(receive(&mut std::io::Cursor::new(wire.into_bytes()),||Ok(())).is_err());}}
}
