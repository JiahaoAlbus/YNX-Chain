//! Exact frozen ABI5 private native call closure. No JNI/public issuer.
//! Successful C mechanics never construct Rust authority or final receipt.
use super::*;
use libsignal_protocol::GenericSignedPreKey;
use std::{marker::PhantomData,ptr,rc::Rc};
use super::super::{NativeSnapshotHandle,NativeStoreBridge,Retained,PortError,validate_computation};
macro_rules! opaque {($($n:ident),*)=>{$(#[repr(C)]struct $n{_opaque:[u8;0],#[cfg(test)]_controlled:u8})*};}
opaque!(Admission,Lease,Intent,Step,Inbound,Outbound,Pending,Write,Finish,Lookup,VerifiedCommit);
#[path="cleanup_port.rs"]mod cleanup_port;
use cleanup_port::{Store,Cleanup,Observation as CleanupObservation,veil_native_take_cleanup,veil_native_cleanup_observe,veil_native_cleanup_drop};
#[link(name="veil_abi5_store",kind="static")]
unsafe extern "C"{
 fn veil_store_open_required(a:*const Admission,s:*mut *mut Store)->i32;
 fn veil_store_close(s:*mut Store)->i32;
 fn veil_store_destroy(s:*mut *mut Store)->i32;
 fn veil_native_prepare_intent(s:*mut Store,l:*const Lease,i:*const Intent,p:*mut *mut Pending)->i32;
 fn veil_native_pending_drop(p:*mut *mut Pending)->i32;
 fn veil_native_begin_checked_write(s:*mut Store,l:*const Lease,i:*const Intent,w:*mut *mut Write)->i32;
 fn veil_native_apply_ordered_step(w:*mut Write,s:*const Step)->i32;
 fn veil_native_append_inbox(w:*mut Write,i:*const Inbound)->i32;
 fn veil_native_append_outbox(w:*mut Write,o:*const Outbound)->i32;
 fn veil_native_finish_commit(w:*mut *mut Write,r:*mut *mut Finish)->i32;
 fn veil_native_finish_publish_once(r:*mut Finish,o:*mut *mut VerifiedCommit)->i32;
 fn veil_native_lookup_operation(s:*mut Store,l:*const Lease,i:*const Intent,r:*mut *mut Lookup)->i32;
 fn veil_native_lookup_publish_once(r:*mut Lookup,o:*mut *mut VerifiedCommit)->i32;
 fn veil_native_cancel_operation(w:*mut Write,i:*const Intent)->i32;
 fn veil_native_checked_write_drop(w:*mut *mut Write)->i32;
 fn veil_native_finish_result_drop(r:*mut *mut Finish)->i32;
 fn veil_native_lookup_result_drop(r:*mut *mut Lookup)->i32;
}
const OK:i32=0;const REQUIRED:i32=1;const UNKNOWN:i32=8;
pub(super) fn require_original_store()->Result<Infallible,Dependency>{
 let mut store=ptr::null_mut();
 // SAFETY: normal frozen C accepts absent admission and clears valid output;
 // no DB path/pointer, key, bool or metadata is passed as authorization.
 let status=unsafe{veil_store_open_required(ptr::null(),&mut store)};
 if status==REQUIRED&&store.is_null(){Err(Dependency::OriginalNativeStoreLease)}else{Err(Dependency::NativeAbiInvariant)}
}
// Genuine retained prepared ownership, never a marker for a pointer/status.
// Normal construction remains private to the same original owning sequence.
enum NativeIssuerProof{Qualified(model_a_owner::NativeResourceProof),#[cfg(test)]ControlledOnly}
impl NativeIssuerProof{
 fn current(&mut self)->Result<(),model_a_owner::Error>{match self{Self::Qualified(p)=>p.current(),#[cfg(test)]Self::ControlledOnly=>Err(model_a_owner::Error::Required)}}
 fn close(&mut self)->Result<(),model_a_owner::Error>{match self{Self::Qualified(p)=>p.close(),#[cfg(test)]Self::ControlledOnly=>Err(model_a_owner::Error::Required)}}
}
// This owner is the store-opening stage of the SAME prepared operation. It
// retains the original Prepared/Root borrow across partial outputs and cleanup.
// It does not invent the missing NativeStoreBridge/snapshot actor enrollment.
pub(crate)struct OpenedNativeOriginal<'prepared,'op>{
 prepared:&'prepared model_a_owner::PreparedOwner<'op>,proof:Option<NativeIssuerProof>,
 store:*mut Store,lease:*const Lease,intent:*const Intent,
 plan:crate::source_infrastructure::platform::NativePlan,
 thread:std::thread::ThreadId,unknown:bool,store_closed:bool,close_refused:bool,
}
pub(crate)struct NativeOpenFailure<'prepared,'op>{error:model_a_owner::Error,retained:NativeOpenRetained<'prepared,'op>}
enum NativeOpenRetained<'prepared,'op>{Inputs(Option<model_a_owner::NativeResourceInputs<'prepared,'op>>),Opened(OpenedNativeOriginal<'prepared,'op>)}
impl NativeOpenFailure<'_,'_>{
 pub(crate)fn error(&self)->&model_a_owner::Error{&self.error}
 pub(crate)fn close(&mut self)->Result<(),model_a_owner::Error>{match &mut self.retained{NativeOpenRetained::Inputs(Some(i))=>i.close(),NativeOpenRetained::Inputs(None)=>Ok(()),NativeOpenRetained::Opened(o)=>o.close()}}
}
impl<'op>model_a_owner::PreparedOwner<'op>{
 // Normal consumer entry: caller already owns this SAME genuine Prepared.
 // Failure retains any returned native resource and original borrow until close.
 pub(crate)fn open_native_original(&mut self)->Result<OpenedNativeOriginal<'_,'op>,NativeOpenFailure<'_,'op>>{
  let inputs=self.native_resource_inputs().map_err(|e|NativeOpenFailure{error:e.error,retained:NativeOpenRetained::Inputs(e.retained)})?;
  OpenedNativeOriginal::from_prepared(inputs)
 }
}
impl<'prepared,'op>OpenedNativeOriginal<'prepared,'op>{
 fn from_prepared(inputs:model_a_owner::NativeResourceInputs<'prepared,'op>)->Result<Self,NativeOpenFailure<'prepared,'op>>{
  let model_a_owner::NativeResourceInputs{proof,prepared,admission,lease,intent,plan}=inputs;
  let mut owner=Self{prepared,proof:Some(NativeIssuerProof::Qualified(proof)),store:ptr::null_mut(),lease,intent,plan,thread:std::thread::current().id(),unknown:false,store_closed:false,close_refused:false};
  if let Err(error)=owner.current(){return Err(NativeOpenFailure{error,retained:NativeOpenRetained::Opened(owner)})}
  // Original protected enter is called once BEFORE possible DB initialization.
  // Even a refusal after this invocation preserves conservative uncertainty.
  if let Err(error)=prepared.enter_original(){owner.unknown=true;return Err(NativeOpenFailure{error,retained:NativeOpenRetained::Opened(owner)})}
  if let Err(error)=owner.current(){owner.unknown=true;return Err(NativeOpenFailure{error,retained:NativeOpenRetained::Opened(owner)})}
  let status=unsafe{veil_store_open_required(admission,&mut owner.store)};
  if status!=OK||owner.store.is_null(){owner.unknown=true;return Err(NativeOpenFailure{error:model_a_owner::Error::Unknown,retained:NativeOpenRetained::Opened(owner)})}
  if let Err(error)=owner.current(){owner.unknown=true;return Err(NativeOpenFailure{error,retained:NativeOpenRetained::Opened(owner)})}Ok(owner)
 }
 pub(crate)fn current(&mut self)->Result<(),model_a_owner::Error>{
  if self.thread!=std::thread::current().id(){return Err(model_a_owner::Error::Thread)}
  if self.unknown||self.store_closed||self.close_refused{return Err(model_a_owner::Error::Unknown)}
  let result=self.prepared.original_current().and_then(|_|self.proof.as_mut().ok_or(model_a_owner::Error::AbiInvariant)?.current()).and_then(|_|self.prepared.original_current());
  if result.is_err(){self.unknown=true;}result
 }
 pub(crate)fn close(&mut self)->Result<(),model_a_owner::Error>{
  if self.thread!=std::thread::current().id(){return Err(model_a_owner::Error::Thread)}
  // A refused close may already have changed native phase. No blind replay.
  if self.close_refused{return Err(model_a_owner::Error::Unknown)}
  if !self.store.is_null(){
   if !self.store_closed{let status=unsafe{veil_store_close(self.store)};if status!=OK{self.unknown=true;self.close_refused=true;return Err(model_a_owner::Error::Unknown)}self.store_closed=true;}
   let original=self.store;let status=unsafe{veil_store_destroy(&mut self.store)};
   if status!=OK||!self.store.is_null(){if self.store!=original{std::process::abort();}self.unknown=true;self.close_refused=true;return Err(model_a_owner::Error::Unknown)}
  }
  // Explicit RAM disposal never resets UNKNOWN or proves durable terminal.
  if let Some(proof)=self.proof.as_mut(){proof.close()?;}self.proof.take();Ok(())
 }
}
impl Drop for OpenedNativeOriginal<'_,'_>{fn drop(&mut self){if !self.store.is_null(){std::process::abort();}}}
// The native issuer must own SAME snapshot, immutable original intent, sealed
// ordered journal+one queue, source lease and C lifetimes in one actor registry.
// Private pointers here have NO getters or byte/metadata factory.
// Original resources still require the missing SAME native bridge/snapshot
// enrollment before actor composition. The store-opening owner above cannot
// choose an actor or turn Rc inventory identity into authority.
struct NativeIssuedResources{
 proof:NativeIssuerProof,store:*mut Store,lease:*const Lease,intent:*const Intent,
 journal:Vec<*const Step>,queue:IssuedQueue,actor:u64,issuer:Rc<()>,
 bound:PhantomData<Rc<()>>,
}
enum IssuedQueue{Inbox(*const Inbound),Outbox(*const Outbound)}
enum SnapshotCustody<'op>{Retained(Retained,PhantomData<&'op ()>),#[cfg(test)]Borrowed(&'op NativeSnapshotHandle)}
impl std::ops::Deref for SnapshotCustody<'_>{type Target=NativeSnapshotHandle;fn deref(&self)->&Self::Target{match self{Self::Retained(r,_)=>&r.snapshot,#[cfg(test)]Self::Borrowed(s)=>s}}}
enum ResourceCustody<'op>{Borrowed(&'op mut NativeIssuedResources),#[cfg(test)]FixtureOwned(NativeIssuedResources)}
impl std::ops::Deref for ResourceCustody<'_>{type Target=NativeIssuedResources;fn deref(&self)->&Self::Target{match self{Self::Borrowed(r)=>r,#[cfg(test)]Self::FixtureOwned(r)=>r}}}
struct IssuedOriginal<'op>{snapshot:SnapshotCustody<'op>,resources:ResourceCustody<'op>,actor:PhantomData<Rc<()>>}
impl std::ops::Deref for IssuedOriginal<'_>{type Target=NativeIssuedResources;fn deref(&self)->&Self::Target{&self.resources}}
enum OriginalCustody<'op>{Owned(IssuedOriginal<'op>),#[cfg(test)]Borrowed(&'op IssuedOriginal<'op>)}
impl<'op> std::ops::Deref for OriginalCustody<'op>{type Target=IssuedOriginal<'op>;fn deref(&self)->&Self::Target{match self{Self::Owned(o)=>o,#[cfg(test)]Self::Borrowed(o)=>o}}}
// Owned foreign slots remain in the operation's private actor retention. No
// automatic Rust Drop claims rollback succeeded or discards uncertain owners.
// No production constructor exists; registry ownership/retirement bridge is
// REQUIRED before issued non-null slots may be admitted, not left to callers.
struct ForeignSlots<'op>{
 original:OriginalCustody<'op>,pending:*mut Pending,write:*mut Write,
 finish:*mut Finish,lookup:*mut Lookup,commit:Option<super::super::NativeVerifiedFinalCommit>,unverified_commit:Option<model_a_owner::FinalOwner>,cleanup:*mut Cleanup,store_cleanup_pending:bool,cleanup_primary:Option<i32>,unknown:bool,local_finished:bool,lifecycle:Lifecycle,observation:Option<CleanupObservation>,#[cfg(test)]controlled:Option<Rc<std::cell::RefCell<controls::Control>>>,
}
#[derive(Clone,Copy,PartialEq,Eq)]enum Lifecycle{Fresh,Preparing,Prepared,Beginning,Writing,Finishing,Finished,Published,LookingUp,LookedUp,Held,Released}
#[derive(Clone,Copy,PartialEq,Eq)]enum Action{Prepare,PendingDrop,Begin,Step,Inbox,Outbox,Finish,Lookup,Cancel,WriteDrop,FinishDrop,LookupDrop,Take,Observe,CleanupDrop}
// Dispatch substitution is private cfg(test) only. Normal code has ONLY the
// exact linked C implementation; no callback registration/authority interface.
macro_rules! foreign{($owner:expr,$action:expr,$native:expr)=>{{
 #[cfg(test)]{if $owner.controlled.is_some(){$owner.controlled_call($action)}else{$native}}
 #[cfg(not(test))]{$native}
}}}
#[derive(Clone,Copy,PartialEq,Eq)]enum MechanicalStatus{Required,Prepared,LocalCommittedOnly,VerifiedCommitRetained,Unknown,NativeError(i32),HeldCleanup(i32)}
impl<'op> ForeignSlots<'op>{
 fn all_empty(&self)->bool{self.pending.is_null()&&self.write.is_null()&&self.finish.is_null()&&self.lookup.is_null()&&self.commit.is_none()&&self.unverified_commit.is_none()&&self.cleanup.is_null()&&!self.store_cleanup_pending}
 fn observe_status(&mut self,status:i32){if status==UNKNOWN{self.mark_unknown();}if status!=OK&&self.cleanup_primary.is_none(){self.cleanup_primary=Some(status);}}
 fn admit(&mut self,expected:Lifecycle)->Result<(),PortError>{
  if super::super::uncertain(&self.original.snapshot.stage.gate){self.mark_unknown();}
  if self.unknown{return Err(PortError::Unknown)}
  if self.lifecycle!=expected||self.local_finished||!self.cleanup.is_null()||self.store_cleanup_pending{return Err(PortError::Rejected)}
  match expected{
   Lifecycle::Fresh=>if !self.all_empty(){return Err(PortError::Rejected)},
   Lifecycle::Prepared=>if self.pending.is_null()||!self.write.is_null()||!self.finish.is_null()||!self.lookup.is_null(){return Err(PortError::Rejected)},
   Lifecycle::Writing=>if self.write.is_null()||!self.pending.is_null()||!self.finish.is_null()||!self.lookup.is_null(){return Err(PortError::Rejected)},
   _=>return Err(PortError::Rejected)
  }
  self.fence()
 }
 fn fence(&mut self)->Result<(),PortError>{
  if super::super::uncertain(&self.original.snapshot.stage.gate){self.mark_unknown();return Err(PortError::Unknown)}
  if !self.cleanup.is_null()||self.store_cleanup_pending{return Err(PortError::Unknown)}
  validate_computation(&self.original.snapshot)
 }
 fn mark_unknown(&mut self){self.unknown=true;self.original.snapshot.stage.gate.0.borrow_mut().phase=super::super::super::Phase::Unknown;}
 fn resource_current(&mut self)->Result<(),PortError>{
  let result=match &mut self.original{OriginalCustody::Owned(o)=>match &mut o.resources{ResourceCustody::Borrowed(r)=>r.proof.current(),#[cfg(test)]ResourceCustody::FixtureOwned(r)=>r.proof.current()},#[cfg(test)]OriginalCustody::Borrowed(_)=>Ok(())};
  if result.is_err(){self.mark_unknown();return Err(PortError::Unknown)}Ok(())
 }
 fn take_failed_operation_cleanup(&mut self,primary:i32)->MechanicalStatus{
  self.observe_status(primary);self.lifecycle=Lifecycle::Held;
  // Never overwrite a previously transferred unique owner. Store borrow/pin
  // remains registry-held even if take itself refuses (e.g. wrong thread).
  if !self.cleanup.is_null(){self.mark_unknown();return MechanicalStatus::HeldCleanup(primary)}
  self.store_cleanup_pending=true;
  let status=foreign!(self,Action::Take,unsafe{veil_native_take_cleanup(self.original.store,&mut self.cleanup)});self.observe_status(status);
  if status==OK{self.store_cleanup_pending=false;}
  if status!=OK||!self.cleanup.is_null(){self.mark_unknown();MechanicalStatus::HeldCleanup(primary)}else{self.classify(primary)}
 }
 fn retry_cleanup_owner(&mut self)->MechanicalStatus{
  if self.store_cleanup_pending{
   if !self.cleanup.is_null(){self.mark_unknown();return MechanicalStatus::HeldCleanup(self.cleanup_primary.unwrap_or(UNKNOWN))}
   let status=foreign!(self,Action::Take,unsafe{veil_native_take_cleanup(self.original.store,&mut self.cleanup)});self.observe_status(status);
   if status!=OK{self.mark_unknown();return MechanicalStatus::HeldCleanup(self.cleanup_primary.unwrap_or(status))}
   self.store_cleanup_pending=false;
  }
  if !self.cleanup.is_null(){
   // Observation is diagnostic only; no field mints abort/authority/receipt.
   let mut observation=CleanupObservation{primary:OK,rollback:OK,unknown_fence:REQUIRED,actual_autocommit:0};
   let observed=foreign!(self,Action::Observe,unsafe{veil_native_cleanup_observe(self.cleanup,&mut observation)});self.observe_status(observed);
   #[cfg(test)]if observed==OK&&self.controlled.is_some(){observation=self.controlled_observation();}
   if observed==OK{self.observe_status(observation.primary);self.observe_status(observation.rollback);self.observe_status(observation.unknown_fence);self.observation=Some(observation);}
   if observed!=OK{self.mark_unknown();return MechanicalStatus::HeldCleanup(self.cleanup_primary.unwrap_or(observed))}
   let original=self.cleanup;
   // C retries actual rollback + required durable CAS UNKNOWN denial. A
   // failed drop keeps the exact owner; no release of original store borrow.
   let status=foreign!(self,Action::CleanupDrop,unsafe{veil_native_cleanup_drop(&mut self.cleanup)});self.observe_status(status);
   if status!=OK||!self.cleanup.is_null(){
    self.mark_unknown();
    if self.cleanup!=original{return MechanicalStatus::HeldCleanup(7)}
    return MechanicalStatus::HeldCleanup(self.cleanup_primary.unwrap_or(status));
   }
  }
  // Successful disposal is not business success / NotApplied. Rust UNKNOWN
  // is deliberately retained after recovery-owner release.
  self.classify(self.cleanup_primary.unwrap_or(OK))
 }
 fn classify(&mut self,status:i32)->MechanicalStatus{
  self.observe_status(status);
  if self.unknown{return MechanicalStatus::Unknown}
  if status==REQUIRED{MechanicalStatus::Required}else{MechanicalStatus::NativeError(status)}
 }
 fn prepare(&mut self)->Result<MechanicalStatus,PortError>{
  self.admit(Lifecycle::Fresh)?;self.lifecycle=Lifecycle::Preparing;
  let status=foreign!(self,Action::Prepare,unsafe{veil_native_prepare_intent(self.original.store,self.original.lease,self.original.intent,&mut self.pending)});self.observe_status(status);
  if status==OK&&!self.pending.is_null(){self.lifecycle=Lifecycle::Prepared;Ok(MechanicalStatus::Prepared)}else{self.lifecycle=Lifecycle::Held;Ok(self.classify(status))}
 }
 fn begin_original_journal(&mut self)->Result<MechanicalStatus,PortError>{
  self.admit(Lifecycle::Prepared)?;
  // Admission and bounded reservation BEFORE pending release, CAS or BEGIN.
  if self.original.journal.len()>32{return Err(PortError::Capacity)}
  self.lifecycle=Lifecycle::Beginning;
  let release=foreign!(self,Action::PendingDrop,unsafe{veil_native_pending_drop(&mut self.pending)});self.observe_status(release);
  if release!=OK||!self.pending.is_null(){self.lifecycle=Lifecycle::Held;return Ok(MechanicalStatus::HeldCleanup(self.cleanup_primary.unwrap_or(release)))}
  self.fence()?;
  let status=foreign!(self,Action::Begin,unsafe{veil_native_begin_checked_write(self.original.store,self.original.lease,self.original.intent,&mut self.write)});self.observe_status(status);
  if status!=OK||self.write.is_null(){return Ok(self.take_failed_operation_cleanup(status))}
  // Indexed borrow avoids retaining a mutable callback scope across steps.
  for n in 0..self.original.journal.len(){
   self.fence()?;let step=self.original.journal[n];
   let status=foreign!(self,Action::Step,unsafe{veil_native_apply_ordered_step(self.write,step)});self.observe_status(status);
   if status!=OK{self.lifecycle=Lifecycle::Held;return Ok(self.classify(status))}
  }
  self.fence()?;
  let status=match self.original.queue{IssuedQueue::Inbox(q)=>foreign!(self,Action::Inbox,unsafe{veil_native_append_inbox(self.write,q)}),IssuedQueue::Outbox(q)=>foreign!(self,Action::Outbox,unsafe{veil_native_append_outbox(self.write,q)})};self.observe_status(status);
  if status==OK{self.lifecycle=Lifecycle::Writing;Ok(MechanicalStatus::Prepared)}else{self.lifecycle=Lifecycle::Held;Ok(self.classify(status))}
 }
 fn finish_original(&mut self)->Result<MechanicalStatus,PortError>{
  self.admit(Lifecycle::Writing)?;self.lifecycle=Lifecycle::Finishing;
  let status=foreign!(self,Action::Finish,unsafe{veil_native_finish_commit(&mut self.write,&mut self.finish)});self.observe_status(status);
  if !self.finish.is_null(){self.local_finished=true;if status!=OK{self.mark_unknown();}}
  if status==OK&&!self.finish.is_null(){self.lifecycle=Lifecycle::Finished;Ok(MechanicalStatus::LocalCommittedOnly)}else{self.lifecycle=Lifecycle::Held;Ok(self.classify(status))}
 }
 fn lookup_original(&mut self)->Result<MechanicalStatus,PortError>{
  // Exact authenticated recovery remains REQUIRED. No local phase reset.
  self.admit(Lifecycle::Fresh)?;self.lifecycle=Lifecycle::LookingUp;
  let status=foreign!(self,Action::Lookup,unsafe{veil_native_lookup_operation(self.original.store,self.original.lease,self.original.intent,&mut self.lookup)});self.observe_status(status);
  if status==OK&&!self.lookup.is_null(){self.lifecycle=Lifecycle::LookedUp;Ok(MechanicalStatus::LocalCommittedOnly)}else{Ok(self.take_failed_operation_cleanup(status))}
 }
 fn publish_once(&mut self)->Result<MechanicalStatus,PortError>{
  self.fence()?;self.resource_current()?;
  if let Some(commit)=self.commit.as_ref(){
   if commit.owner.current().is_err(){self.mark_unknown();return Err(PortError::Unknown)}
   return Ok(MechanicalStatus::VerifiedCommitRetained);
  }
  if self.lifecycle!=Lifecycle::Finished&&self.lifecycle!=Lifecycle::LookedUp{return Err(PortError::Rejected)}
  // Each result's C once latch owns invocation; no retries/reacquisition when
  // the call or late fence is uncertain. Store sole returned custody BEFORE
  // any late validation. SQL completion alone never constructs this proof.
  self.lifecycle=Lifecycle::Held;let mut raw=ptr::null_mut();
  let status=if !self.finish.is_null(){unsafe{veil_native_finish_publish_once(self.finish,&mut raw)}}else if !self.lookup.is_null(){unsafe{veil_native_lookup_publish_once(self.lookup,&mut raw)}}else{return Err(PortError::Binding)};
  self.observe_status(status);
  if status!=OK{if !raw.is_null(){std::process::abort();}return Ok(self.classify(status))}
  let Some(raw)=std::ptr::NonNull::new(raw)else{self.mark_unknown();return Err(PortError::Unknown)};
  let Some(intent)=std::ptr::NonNull::new(self.original.intent.cast_mut())else{std::process::abort()};
  let owner=model_a_owner::FinalOwner::adopt_published(raw,intent);
  // Retain the RAM root even when its own independently current borrow fails.
  self.unverified_commit=Some(owner);
  if self.unverified_commit.as_ref().expect("same owning output").current().is_err(){self.mark_unknown();return Err(PortError::Unknown)}
  self.commit=Some(super::super::NativeVerifiedFinalCommit{owner:self.unverified_commit.take().expect("verified same output")});
  self.fence()?;self.resource_current()?;self.lifecycle=Lifecycle::Published;
  Ok(MechanicalStatus::VerifiedCommitRetained)
 }
 fn prepare_verified_delivery(&mut self)->Result<(),PortError>{
  self.fence()?;self.resource_current()?;
  if self.lifecycle!=Lifecycle::Published||self.unknown||!self.pending.is_null()||!self.write.is_null()||!self.cleanup.is_null()||self.store_cleanup_pending||self.unverified_commit.is_some(){return Err(PortError::Unknown)}
  let proof=self.commit.as_ref().ok_or(PortError::RequiredOnceReceipt)?;
  if proof.current().is_err(){self.mark_unknown();return Err(PortError::Unknown)}
  // Retained final root is independent of result RAM. Refused RAM disposal
  // keeps BOTH proof and original slot; it never becomes a commit receipt.
  let status=foreign!(self,Action::FinishDrop,unsafe{veil_native_finish_result_drop(&mut self.finish)});self.observe_status(status);
  if status!=OK||!self.finish.is_null(){self.mark_unknown();return Err(PortError::Unknown)}
  let status=foreign!(self,Action::LookupDrop,unsafe{veil_native_lookup_result_drop(&mut self.lookup)});self.observe_status(status);
  if status!=OK||!self.lookup.is_null(){self.mark_unknown();return Err(PortError::Unknown)}
  if self.commit.as_ref().expect("same proof").current().is_err(){self.mark_unknown();return Err(PortError::Unknown)}
  self.fence()?;self.resource_current()
 }
 fn cancel_and_release_ram(&mut self)->MechanicalStatus{
  self.lifecycle=Lifecycle::Held;
  if super::super::uncertain(&self.original.snapshot.stage.gate){self.mark_unknown();}
  // Observe EVERY status before selecting a retained-owner disposition.
  if !self.write.is_null(){
   let st=foreign!(self,Action::Cancel,unsafe{veil_native_cancel_operation(self.write,self.original.intent)});self.observe_status(st);
   let st=foreign!(self,Action::WriteDrop,unsafe{veil_native_checked_write_drop(&mut self.write)});self.observe_status(st);
  }
  let st=foreign!(self,Action::FinishDrop,unsafe{veil_native_finish_result_drop(&mut self.finish)});self.observe_status(st);
  let st=foreign!(self,Action::LookupDrop,unsafe{veil_native_lookup_result_drop(&mut self.lookup)});self.observe_status(st);
  let st=foreign!(self,Action::PendingDrop,unsafe{veil_native_pending_drop(&mut self.pending)});self.observe_status(st);
  if let Some(owner)=self.unverified_commit.as_mut(){if owner.close().is_err(){self.mark_unknown();return MechanicalStatus::HeldCleanup(self.cleanup_primary.unwrap_or(UNKNOWN))}self.unverified_commit.take();}
  if let Some(commit)=self.commit.as_mut(){if commit.owner.close().is_err(){self.mark_unknown();return MechanicalStatus::HeldCleanup(self.cleanup_primary.unwrap_or(UNKNOWN))}self.commit.take();}
  let cleanup=self.retry_cleanup_owner();
  let primary=self.cleanup_primary.unwrap_or(OK);
  if !self.all_empty()||matches!(cleanup,MechanicalStatus::HeldCleanup(_)){MechanicalStatus::HeldCleanup(primary)}else{self.lifecycle=Lifecycle::Released;self.classify(primary)}
 }

}
#[cfg(test)]pub(super) fn require_after_actual_computation(snapshot:&NativeSnapshotHandle)->Result<Infallible,PortError>{
 validate_computation(snapshot)?;
 match require_original_store(){Ok(never)=>match never{},Err(_)=>Err(PortError::RequiredCheckedSqlProducer)}
}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn abi5_final_actual_normal_store_source_missing(){assert!(matches!(require_original_store(),Err(Dependency::OriginalNativeStoreLease)));}
 #[test]fn abi5_final_actual_unissued_prepare_step_queue_commit_lookup_no_receipt(){
  let(mut p,mut w,mut f,mut l,mut receipt)=(ptr::null_mut(),ptr::null_mut(),ptr::null_mut(),ptr::null_mut(),ptr::null_mut());
  // SAFETY: exact frozen normal ABI accepts null/unissued inputs, valid output
  // slots. No fake non-null handle/fixture lease is ever constructed.
  unsafe{
   assert_eq!(veil_native_prepare_intent(ptr::null_mut(),ptr::null(),ptr::null(),&mut p),REQUIRED);
   assert_eq!(veil_native_begin_checked_write(ptr::null_mut(),ptr::null(),ptr::null(),&mut w),REQUIRED);
   assert_eq!(veil_native_apply_ordered_step(w,ptr::null()),REQUIRED);
   assert_eq!(veil_native_append_inbox(w,ptr::null()),REQUIRED);assert_eq!(veil_native_append_outbox(w,ptr::null()),REQUIRED);
   assert_eq!(veil_native_finish_commit(&mut w,&mut f),REQUIRED);
   assert_eq!(veil_native_finish_publish_once(f,&mut receipt),REQUIRED);
   assert_eq!(veil_native_lookup_operation(ptr::null_mut(),ptr::null(),ptr::null(),&mut l),REQUIRED);
   assert_eq!(veil_native_lookup_publish_once(l,&mut receipt),REQUIRED);
  }
  assert!(p.is_null()&&w.is_null()&&f.is_null()&&l.is_null()&&receipt.is_null());
 }
 #[test]fn abi5_final_actual_null_cleanup_is_not_durable_rollback_receipt(){
  let(mut p,mut w,mut f,mut l)=(ptr::null_mut(),ptr::null_mut(),ptr::null_mut(),ptr::null_mut());
  unsafe{assert_eq!(veil_native_pending_drop(&mut p),OK);assert_eq!(veil_native_checked_write_drop(&mut w),OK);assert_eq!(veil_native_finish_result_drop(&mut f),OK);assert_eq!(veil_native_lookup_result_drop(&mut l),OK);assert_eq!(veil_native_cancel_operation(w,ptr::null()),REQUIRED);}
 }
}

// Extends the EXISTING native actor registry, not a second demo actor.
#[path="supervisor.rs"]mod supervisor;
pub(super)use supervisor::NativeActorRegistry;
pub(super)fn supervisor_for_bridge<'op>(b:&NativeStoreBridge)->Result<NativeActorRegistry<'op>,PortError>{NativeActorRegistry::for_bridge(b,32)}
#[cfg(test)]mod cleanup_tests{
 use super::*;
 #[test]fn abi5_actual_normal_null_cleanup_refusal_and_disposal_only(){
  let mut owner=ptr::null_mut();let mut o=CleanupObservation{primary:0,rollback:0,unknown_fence:0,actual_autocommit:0};
  unsafe{assert_eq!(veil_native_take_cleanup(ptr::null_mut(),&mut owner),REQUIRED);assert!(owner.is_null());assert_eq!(veil_native_cleanup_observe(owner,&mut o),2);assert_eq!(veil_native_cleanup_drop(&mut owner),OK);assert!(owner.is_null());}
 }
}

#[cfg(test)]#[path="controls.rs"]mod controls;

// Source SPI is private static LINK, not a metadata issuer.
#[path="source.rs"]mod source;

// Model A private normal ownership bodies; genuine accepted/held constructors absent.
#[path="model_a_owner.rs"]mod model_a_owner;
pub(crate) use model_a_owner::{HeldOriginal as SourceHeldOriginal,PreparedOwner as SourcePreparedOwner,CommitOwner as SourceCommitOwner,Error as SourceOwnerError};

#[repr(C)]#[derive(Clone,Copy)]pub(crate)struct SnapshotBytes{pub(crate)data:*const u8,pub(crate)size:usize}
#[repr(C)]pub(crate)struct SnapshotUsed{pub(crate)signed_id:u32,pub(crate)public_key:SnapshotBytes}
#[repr(C)]pub(crate)struct SnapshotRow{pub(crate)kind:u32,pub(crate)id:u32,pub(crate)device:u32,pub(crate)policy:u32,pub(crate)registration:u32,pub(crate)version:u64,pub(crate)name:SnapshotBytes,pub(crate)body:SnapshotBytes,pub(crate)used:*const SnapshotUsed,pub(crate)used_count:usize}
#[repr(C)]pub(crate)struct SnapshotProjection{pub(crate)binding:[u64;11],pub(crate)actor:u64,pub(crate)source_abi:[u8;32],pub(crate)reserved_bytes:usize,pub(crate)queue:u32,pub(crate)inbound_wire:SnapshotBytes,pub(crate)rows:*const SnapshotRow,pub(crate)row_count:usize,lease:*const Lease,intent:*const Intent}
// Pure address grammar only. A result is UNADMITTED metadata; only the owning
// same-snapshot route transfer above can attach it to NativeMessageRoute.
fn message_address_metadata(raw:&[u8],device:u32)->Option<(String,u8)>{
 if raw.is_empty()||raw.len()>128||raw.contains(&0)||device==0||device>127{return None}
 Some((std::str::from_utf8(raw).ok()?.to_owned(),u8::try_from(device).ok()?))
}
#[repr(C)]struct MessageRouteProjection{binding:[u64;11],logical:[u8;16],direction:u32,local_name:SnapshotBytes,remote_name:SnapshotBytes,local_device:u32,remote_device:u32}
unsafe extern "C"{
 fn ynx_source_client_snapshot_message_route(h:*mut std::ffi::c_void,logical:*const u8,direction:u32,out:*mut MessageRouteProjection)->i32;
 fn ynx_source_client_snapshot_current(h:*mut std::ffi::c_void)->i32;
 fn ynx_source_client_snapshot_projection(h:*mut std::ffi::c_void,p:*mut SnapshotProjection)->i32;
 fn ynx_source_client_snapshot_close(h:*mut *mut std::ffi::c_void)->i32;
}
// Private static provider's real retained snapshot owner. Neither metadata nor
// an arbitrary C pointer constructs this type; sole acquisition is from the
// live same-original Prepared operation below. Explicit close, no Drop erase.
pub(crate)struct NativeSnapshotOwner{handle:std::cell::Cell<*mut std::ffi::c_void>,thread:std::thread::ThreadId,unknown:std::cell::Cell<bool>,retained_intent:std::cell::Cell<*const Intent>,unverified_final:std::cell::RefCell<Option<model_a_owner::FinalOwner>>}
pub(crate)struct SnapshotAcquireFailure{pub(crate)error:model_a_owner::Error,pub(crate)retained:Option<Rc<NativeSnapshotOwner>>}
impl NativeSnapshotOwner{
 fn acquire(prepared:&model_a_owner::PreparedOwner<'_>)->Result<Rc<Self>,SnapshotAcquireFailure>{
  let mut out=ptr::null_mut();let s=prepared.acquire_original_snapshot(&mut out).map_err(|error|SnapshotAcquireFailure{error,retained:None})?;
  let retained=(!out.is_null()).then(||Rc::new(Self{handle:std::cell::Cell::new(out),thread:std::thread::current().id(),unknown:std::cell::Cell::new(s!=OK),retained_intent:std::cell::Cell::new(ptr::null()),unverified_final:std::cell::RefCell::new(None)}));
  match(s,retained){(OK,Some(owner))=>match owner.current(){Ok(())=>Ok(owner),Err(error)=>Err(SnapshotAcquireFailure{error,retained:Some(owner)})},(OK,None)=>Err(SnapshotAcquireFailure{error:model_a_owner::Error::AbiInvariant,retained:None}),(REQUIRED,None)=>Err(SnapshotAcquireFailure{error:model_a_owner::Error::Required,retained:None}),(_,retained)=>Err(SnapshotAcquireFailure{error:model_a_owner::Error::Unknown,retained})}
 }
 pub(crate)fn current(&self)->Result<(),model_a_owner::Error>{
  if self.thread!=std::thread::current().id(){return Err(model_a_owner::Error::Thread)}if self.unknown.get()||self.handle.get().is_null(){return Err(model_a_owner::Error::Unknown)}
  if unsafe{ynx_source_client_snapshot_current(self.handle.get())}!=OK{self.unknown.set(true);return Err(model_a_owner::Error::Unknown)}Ok(())
 }
 pub(crate)fn message_route(&self,logical:&[u8;16],direction:crate::product_message::Direction,binding:&[u64;11])->Result<(libsignal_protocol::ProtocolAddress,libsignal_protocol::ProtocolAddress),model_a_owner::Error>{
  self.current()?;let selected=match direction{crate::product_message::Direction::Send=>1,crate::product_message::Direction::Receive=>2};
  let mut p=MessageRouteProjection{binding:[0;11],logical:[0;16],direction:0,local_name:SnapshotBytes{data:ptr::null(),size:0},remote_name:SnapshotBytes{data:ptr::null(),size:0},local_device:0,remote_device:0};
  let status=unsafe{ynx_source_client_snapshot_message_route(self.handle.get(),logical.as_ptr(),selected,&mut p)};
  if status==REQUIRED{return Err(model_a_owner::Error::Required)}
  // Foreign refusal already quarantined the same C snapshot. Preserve its
  // uncertainty before inspecting a projection that was not returned OK.
  if status!=OK{self.unknown.set(true);return Err(model_a_owner::Error::Unknown)}
  let result=(||{
   if p.binding!=*binding||p.logical!=*logical||p.direction!=selected{return Err(model_a_owner::Error::Association)}
   fn address(b:SnapshotBytes,device:u32)->Result<libsignal_protocol::ProtocolAddress,model_a_owner::Error>{
    if b.size==0||b.size>128||b.data.is_null(){return Err(model_a_owner::Error::Association)}
    let raw=unsafe{std::slice::from_raw_parts(b.data,b.size)};
    let (name,id)=message_address_metadata(raw,device).ok_or(model_a_owner::Error::Association)?;
    let device=libsignal_protocol::DeviceId::new(id).map_err(|_|model_a_owner::Error::Association)?;
    Ok(libsignal_protocol::ProtocolAddress::new(name,device))
   }
   let local=address(p.local_name,p.local_device)?;let remote=address(p.remote_name,p.remote_device)?;
   if local==remote{return Err(model_a_owner::Error::Association)}self.current()?;Ok((local,remote))
  })();if result.is_err(){self.unknown.set(true);}result
 }
 fn raw_projection(&self)->Result<SnapshotProjection,model_a_owner::Error>{
  self.current()?;let mut p=SnapshotProjection{binding:[0;11],actor:0,source_abi:[0;32],reserved_bytes:0,queue:0,inbound_wire:SnapshotBytes{data:ptr::null(),size:0},rows:ptr::null(),row_count:0,lease:ptr::null(),intent:ptr::null()};
  let s=unsafe{ynx_source_client_snapshot_projection(self.handle.get(),&mut p)};
  if s!=OK||p.rows.is_null()||p.row_count==0||p.row_count>64||p.actor==0||p.reserved_bytes==0||p.reserved_bytes>8*1024*1024||p.lease.is_null()||p.intent.is_null(){self.unknown.set(true);return Err(model_a_owner::Error::Unknown)}self.current()?;Ok(p)
 }
 fn close(&self)->Result<(),model_a_owner::Error>{
  if self.thread!=std::thread::current().id(){return Err(model_a_owner::Error::Thread)}{let mut held=self.unverified_final.try_borrow_mut().map_err(|_|model_a_owner::Error::Association)?;if let Some(final_owner)=held.as_mut(){final_owner.close()?;}held.take();}let original=self.handle.get();if original.is_null(){return Ok(())}let mut out=original;
  let s=unsafe{ynx_source_client_snapshot_close(&mut out)};if s==OK&&out.is_null(){self.handle.set(ptr::null_mut());return Ok(())}if out!=original{std::process::abort();}self.unknown.set(true);Err(model_a_owner::Error::Unknown)
 }
}
impl Drop for NativeSnapshotOwner{fn drop(&mut self){if !self.handle.get().is_null(){std::process::abort();}}}

// Scoped normal bridge retains the Rust original/Prepared borrow as well as
// real C snapshot+store+proof owners. Nothing can outlive this initial borrow.
pub(crate)struct ScopedNativeOriginal<'prepared,'op>{
 prepared:&'prepared model_a_owner::PreparedOwner<'op>,snapshot:Rc<NativeSnapshotOwner>,bridge:Option<NativeStoreBridge>,resources:NativeIssuedResources,
 thread:std::thread::ThreadId,unknown:bool,store_closed:bool,close_refused:bool,
}
pub(crate)struct ScopedNativeFailure<'prepared,'op>{pub(crate)error:model_a_owner::Error,retained:ScopedFailureCustody<'prepared,'op>}
enum ScopedFailureCustody<'prepared,'op>{Snapshot(Option<Rc<NativeSnapshotOwner>>),Open{snapshot:Rc<NativeSnapshotOwner>,failure:NativeOpenFailure<'prepared,'op>},Opened{snapshot:Rc<NativeSnapshotOwner>,opened:OpenedNativeOriginal<'prepared,'op>},Built(ScopedNativeOriginal<'prepared,'op>)}
impl ScopedNativeFailure<'_,'_>{
 pub(crate)fn close(&mut self)->Result<(),model_a_owner::Error>{match &mut self.retained{
  ScopedFailureCustody::Snapshot(owner)=>{if let Some(o)=owner{if Rc::strong_count(o)!=1{return Err(model_a_owner::Error::Association)}o.close()?;}owner.take();Ok(())},
  ScopedFailureCustody::Open{snapshot,failure}=>{failure.close()?;if Rc::strong_count(snapshot)!=1{return Err(model_a_owner::Error::Association)}snapshot.close()},
  ScopedFailureCustody::Opened{snapshot,opened}=>{opened.close()?;if Rc::strong_count(snapshot)!=1{return Err(model_a_owner::Error::Association)}snapshot.close()},
  ScopedFailureCustody::Built(owner)=>owner.close(),
 }}
}
impl<'op>model_a_owner::PreparedOwner<'op>{
 pub(crate)fn open_scoped_native(&mut self)->Result<ScopedNativeOriginal<'_,'op>,ScopedNativeFailure<'_,'op>>{
  let snapshot=NativeSnapshotOwner::acquire(self).map_err(|e|ScopedNativeFailure{error:e.error,retained:ScopedFailureCustody::Snapshot(e.retained)})?;
  let mut opened=match self.open_native_original(){Ok(o)=>o,Err(failure)=>return Err(ScopedNativeFailure{error:model_a_owner::Error::Unknown,retained:ScopedFailureCustody::Open{snapshot,failure}})};
  let p=match snapshot.projection(){Ok(p)=>p,Err(error)=>return Err(ScopedNativeFailure{error,retained:ScopedFailureCustody::Opened{snapshot,opened}})};
  if p.lease!=opened.lease||p.intent!=opened.intent||p.intent.cast::<std::ffi::c_void>()!=opened.plan.intent||(p.queue==1)!=(!opened.plan.inbox.is_null()){
   return Err(ScopedNativeFailure{error:model_a_owner::Error::Association,retained:ScopedFailureCustody::Opened{snapshot,opened}})
  }
  let bridge=match NativeStoreBridge::from_qualified_snapshot(snapshot.clone()){Ok(b)=>b,Err(_)=>return Err(ScopedNativeFailure{error:model_a_owner::Error::Unknown,retained:ScopedFailureCustody::Opened{snapshot,opened}})};
  let resources=NativeIssuedResources{proof:opened.proof.take().expect("actual retained proof"),store:std::mem::replace(&mut opened.store,ptr::null_mut()),lease:opened.lease,intent:opened.intent,journal:opened.plan.journal.iter().map(|p|p.cast::<Step>()).collect(),queue:if !opened.plan.inbox.is_null(){IssuedQueue::Inbox(opened.plan.inbox.cast())}else{IssuedQueue::Outbox(opened.plan.outbox.cast())},actor:bridge.actor,issuer:bridge.issuer.clone(),bound:PhantomData};
  let mut owner=ScopedNativeOriginal{prepared:opened.prepared,snapshot,bridge:Some(bridge),resources,thread:opened.thread,unknown:opened.unknown,store_closed:false,close_refused:false};
  if let Err(error)=owner.current(){return Err(ScopedNativeFailure{error,retained:ScopedFailureCustody::Built(owner)})}Ok(owner)
 }
}
impl ScopedNativeOriginal<'_,'_>{
 pub(crate)fn current(&mut self)->Result<(),model_a_owner::Error>{
  if self.thread!=std::thread::current().id(){return Err(model_a_owner::Error::Thread)}if self.unknown||self.close_refused||self.store_closed{return Err(model_a_owner::Error::Unknown)}
  let result=self.prepared.original_current().and_then(|_|self.snapshot.current()).and_then(|_|self.resources.proof.current()).and_then(|_|self.prepared.original_current());if result.is_err(){self.unknown=true;}result
 }
 pub(crate)fn acquire_operation(&mut self)->Result<NativeSnapshotHandle,PortError>{
  self.current().map_err(|_|PortError::Unknown)?;let result=self.bridge.as_mut().ok_or(PortError::Retired)?.acquire_snapshot();
  if self.current().is_err(){self.unknown=true;return Err(PortError::Unknown)}result
 }
 pub(crate)fn close(&mut self)->Result<(),model_a_owner::Error>{
  if self.thread!=std::thread::current().id(){return Err(model_a_owner::Error::Thread)}if self.close_refused{return Err(model_a_owner::Error::Unknown)}
  // Reject close while a decoded cohort, active snapshot or pending owner still
  // borrows the genuine platform reservation. No forced Drop of other owners.
  if let Some(b)=&self.bridge{if !b.pending.is_empty()||Rc::strong_count(&self.snapshot)!=2{return Err(model_a_owner::Error::Association)}}
  if !self.resources.store.is_null(){if !self.store_closed{if unsafe{veil_store_close(self.resources.store)}!=OK{self.close_refused=true;self.unknown=true;return Err(model_a_owner::Error::Unknown)}self.store_closed=true;}
   let original=self.resources.store;let s=unsafe{veil_store_destroy(&mut self.resources.store)};if s!=OK||!self.resources.store.is_null(){if self.resources.store!=original{std::process::abort();}self.close_refused=true;self.unknown=true;return Err(model_a_owner::Error::Unknown)}
  }
  self.resources.proof.close()?;self.bridge.take();self.snapshot.close()
 }
}
impl Drop for ScopedNativeOriginal<'_,'_>{fn drop(&mut self){if !self.resources.store.is_null(){std::process::abort();}}}

pub(crate)struct NativeSnapshotRow{pub(crate)kind:u32,pub(crate)id:u32,pub(crate)device:u32,pub(crate)policy:u32,pub(crate)registration:u32,pub(crate)version:u64,pub(crate)name:Vec<u8>,pub(crate)body:zeroize::Zeroizing<Vec<u8>>,pub(crate)used:Vec<(u32,Vec<u8>)>}
pub(crate)struct NativeSnapshotData{pub(crate)binding:[u64;11],pub(crate)actor:u64,pub(crate)source_abi:[u8;32],pub(crate)reserved_bytes:usize,pub(crate)queue:u32,pub(crate)inbound_wire:zeroize::Zeroizing<Vec<u8>>,pub(crate)rows:Vec<NativeSnapshotRow>,lease:*const Lease,intent:*const Intent}
impl NativeSnapshotOwner{
 pub(crate)fn projection(&self)->Result<NativeSnapshotData,model_a_owner::Error>{
  // A failed authenticated projection never permits a later fresh read to
  // replace the same retained original. Preserve the first error separately.
  let result=self.projection_inner();
  if result.is_err(){self.unknown.set(true);}
  result
 }
 fn projection_inner(&self)->Result<NativeSnapshotData,model_a_owner::Error>{
  fn copy(b:SnapshotBytes,max:usize)->Result<Vec<u8>,model_a_owner::Error>{if b.size>max||(b.size>0&&b.data.is_null()){return Err(model_a_owner::Error::Association)}Ok(if b.size==0{Vec::new()}else{unsafe{std::slice::from_raw_parts(b.data,b.size)}.to_vec()})}
  let p=self.raw_projection()?;let raw=unsafe{std::slice::from_raw_parts(p.rows,p.row_count)};let mut rows=Vec::with_capacity(raw.len());let mut total=0usize;
  for r in raw{if r.used_count>16||(r.used_count>0&&r.used.is_null()){return Err(model_a_owner::Error::Association)}let body=zeroize::Zeroizing::new(copy(r.body,65536)?);total=total.checked_add(body.len()).ok_or(model_a_owner::Error::Capacity)?;if total>1048576{return Err(model_a_owner::Error::Capacity)}let mut used=Vec::with_capacity(r.used_count);if r.used_count>0{for u in unsafe{std::slice::from_raw_parts(r.used,r.used_count)}{used.push((u.signed_id,copy(u.public_key,64)?));}}
   rows.push(NativeSnapshotRow{kind:r.kind,id:r.id,device:r.device,policy:r.policy,registration:r.registration,version:r.version,name:copy(r.name,128)?,body,used});}
  let inbound_wire=zeroize::Zeroizing::new(copy(p.inbound_wire,1048576)?);if !matches!(p.queue,1|2)||(p.queue==1&&inbound_wire.is_empty())||(p.queue==2&&!inbound_wire.is_empty()){return Err(model_a_owner::Error::Association)}
  self.current()?;Ok(NativeSnapshotData{binding:p.binding,actor:p.actor,source_abi:p.source_abi,reserved_bytes:p.reserved_bytes,queue:p.queue,inbound_wire,rows,lease:p.lease,intent:p.intent})
 }
}

// Classification of original owned dispatch only, never receipt/Applied.
#[derive(Clone,Copy)]pub(crate)enum NativeFinalAction{Prepare,Begin,Finish,Lookup,Publish}
#[derive(Clone,Copy,Debug,PartialEq,Eq)]pub(crate)enum NativeFinalObservation{Required,Prepared,LocalCommittedOnly,VerifiedCommitRetained,Unknown,NativeError(i32),HeldCleanup(i32)}
fn final_observation(s:MechanicalStatus)->NativeFinalObservation{match s{MechanicalStatus::Required=>NativeFinalObservation::Required,MechanicalStatus::Prepared=>NativeFinalObservation::Prepared,MechanicalStatus::LocalCommittedOnly=>NativeFinalObservation::LocalCommittedOnly,MechanicalStatus::VerifiedCommitRetained=>NativeFinalObservation::VerifiedCommitRetained,MechanicalStatus::Unknown=>NativeFinalObservation::Unknown,MechanicalStatus::NativeError(e)=>NativeFinalObservation::NativeError(e),MechanicalStatus::HeldCleanup(e)=>NativeFinalObservation::HeldCleanup(e)}}
// Registry borrows resources and bridge from disjoint actual owner fields;
// no self reference, raw authority constructor or lifetime extension.
pub(crate)struct ScopedNativeFinalRequest<'request,'prepared,'op>{registry:Option<supervisor::NativeActorRegistry<'request>>,bridge:&'request mut NativeStoreBridge,prepared:&'prepared model_a_owner::PreparedOwner<'op>,snapshot:&'request Rc<NativeSnapshotOwner>,thread:std::thread::ThreadId,unknown:&'request mut bool,ticket:supervisor::Ticket}
impl<'prepared,'op>ScopedNativeOriginal<'prepared,'op>{
 pub(crate)fn retain_computed(&mut self,snapshot:&mut Option<NativeSnapshotHandle>)->Result<super::super::NativePendingHandle,PortError>{
  self.current().map_err(|_|PortError::Unknown)?;
  self.bridge.as_mut().ok_or(PortError::Retired)?.retain_in_place(snapshot)
 }
 pub(crate)fn bind_pending<'request>(&'request mut self,h:&super::super::NativePendingHandle)->Result<ScopedNativeFinalRequest<'request,'prepared,'op>,PortError>{
  self.current().map_err(|_|PortError::Unknown)?;let b=self.bridge.as_mut().ok_or(PortError::Retired)?;
  let mut registry=supervisor::NativeActorRegistry::for_bridge(b,32)?;
  // All bind failures precede ledger/resource move. An empty registry Drop
  // releases its active inventory identity; caller keeps SAME pending owner.
  let ticket=registry.bind_original(b,h,&mut self.resources)?;
  Ok(ScopedNativeFinalRequest{registry:Some(registry),bridge:b,prepared:self.prepared,snapshot:&self.snapshot,thread:self.thread,unknown:&mut self.unknown,ticket})
 }
}
impl ScopedNativeFinalRequest<'_,'_,'_>{
 fn current(&mut self)->Result<(),PortError>{
  if self.thread!=std::thread::current().id(){return Err(PortError::Binding)}
  if *self.unknown{return Err(PortError::Unknown)}
  let r=self.prepared.original_current().and_then(|_|self.snapshot.current());
  if r.is_err(){if let Some(registry)=&mut self.registry{registry.observe_late_failure(self.ticket)?;}*self.unknown=true;return Err(PortError::Unknown)}
  self.registry.as_mut().ok_or(PortError::Retired)?.current_original(self.ticket)
 }
 pub(crate)fn dispatch(&mut self,action:NativeFinalAction)->Result<NativeFinalObservation,PortError>{
  self.current()?;let result=self.registry.as_mut().ok_or(PortError::Retired)?.dispatch_retained(self.ticket,action);
  if self.current().is_err(){*self.unknown=true;return Err(PortError::Unknown)}
  result.map(final_observation)
 }
 // Normal first-device caller borrows actual final custody before verifying
 // accepted-device originals. The returned value remains held on late UNKNOWN;
 // mathematical device evidence is UNADMITTED and does not create an owner.
 pub(crate)fn with_device_evidence<R>(&mut self,loan:&mut crate::private_custodian_ffi::RecoveryLoan<'_>,input:&crate::message_evidence::MessageOpenInput,records:&crate::message_evidence::OriginalDeviceRecords,run:impl for<'a,'b>FnOnce(&crate::message_evidence::UnadmittedDeviceEvidence<'a>,&'b model_a_owner::FinalOwner)->R)->Result<Result<Result<R,crate::private_custodian_ffi::CustodyError>,(crate::private_custodian_ffi::CustodyError,Option<Result<R,crate::private_custodian_ffi::CustodyError>>)>,(PortError,Option<Result<Result<R,crate::private_custodian_ffi::CustodyError>,(crate::private_custodian_ffi::CustodyError,Option<Result<R,crate::private_custodian_ffi::CustodyError>>)>>)>{
  self.current().map_err(|e|(e,None))?;
  let result=self.registry.as_mut().ok_or((PortError::Retired,None))?.with_final_owner(self.ticket,|owner|loan.with_native_final_device_evidence(input,records,owner,|evidence|run(evidence,owner)).map_err(|failure|(failure.error,failure.retained)));
  match result{
   Ok(value)=>match self.current(){Ok(())=>Ok(value),Err(e)=>{*self.unknown=true;Err((e,Some(value)))}},
   Err(failure)=>{if failure.1.is_some(){*self.unknown=true;}Err(failure)},
  }
 }
 // Actual first-device final caller retains independent device custody while
 // its original request is live. All late outer/inner results preserve the
 // acquired owner for explicit release; none is flattened into a status flag.
 pub(crate)fn acquire_device_owner(&mut self,loan:&mut crate::private_custodian_ffi::RecoveryLoan<'_>,input:&crate::message_evidence::MessageOpenInput,records:&crate::message_evidence::OriginalDeviceRecords)->DeviceOwnerFinalResult{
  self.with_device_evidence(loan,input,records,|evidence,root|model_a_owner::AcceptedDeviceOwner::acquire(root,evidence))
 }
 // Explicit delivery after actual independently verified publication. This
 // consumes no message output and performs no new effect or re-encryption.
 pub(crate)fn deliver_verified_commit(&mut self)->Result<(),PortError>{
  self.current()?;
  self.registry.as_mut().ok_or(PortError::Retired)?.deliver_verified_to_ledger(self.ticket,self.bridge)?;
  self.registry.as_mut().expect("same emptied registry").close_empty()?;
  self.registry.take();Ok(())
 }
 pub(crate)fn recover_same_owner(&mut self)->Result<NativeFinalObservation,PortError>{
  if self.thread!=std::thread::current().id(){return Err(PortError::Binding)}
  // Cleanup can inspect expired/UNKNOWN SAME custody, never dispatch a write.
  self.registry.as_mut().ok_or(PortError::Retired)?.recover_retained(self.ticket).map(final_observation)
 }
 pub(crate)fn try_close(&mut self)->Result<(),PortError>{
  if self.thread!=std::thread::current().id(){return Err(PortError::Binding)}
  self.registry.as_mut().ok_or(PortError::Retired)?.close_empty()?;
  self.registry.take();Ok(())
 }
 pub(crate)fn same_pending(&self,h:&super::super::NativePendingHandle)->Result<(),PortError>{self.registry.as_ref().ok_or(PortError::Retired)?.same_original_pending(self.ticket,self.bridge,h)}
}

pub(crate)use model_a_owner::FinalOwner as NativeFinalCommitOwner;

// These aliases preserve nested uncertainty/custody, not new capability DTOs.
type DeviceOwnerAcquisition=Result<model_a_owner::AcceptedDeviceOwner,(model_a_owner::Error,Option<model_a_owner::AcceptedDeviceOwner>)>;
type DeviceOwnerEvidenceResult=Result<DeviceOwnerAcquisition,crate::private_custodian_ffi::CustodyError>;
type DeviceOwnerBorrowResult=Result<DeviceOwnerEvidenceResult,(crate::private_custodian_ffi::CustodyError,Option<DeviceOwnerEvidenceResult>)>;
type DeviceOwnerFinalResult=Result<DeviceOwnerBorrowResult,(PortError,Option<DeviceOwnerBorrowResult>)>;

pub(crate)use model_a_owner::AcceptedDeviceOwner;

#[cfg(feature="abi5-final-native-link")]pub(crate)use model_a_owner::{MessageSessionOwner,PersistentMessageProjection};

// Owned per-operation continuation: no self-reference or extended Rust borrow.
// Every raw resource is retained by actual C Prepared/session ownership.
pub(crate)struct OwnedMessageOriginal{prepared:Option<model_a_owner::PreparedOwner<'static>>,snapshot:Option<Rc<NativeSnapshotOwner>>,resources:Option<NativeIssuedResources>,store:*mut Store,proof:Option<NativeIssuerProof>,thread:std::thread::ThreadId,unknown:bool,store_closed:bool,close_refused:bool}
pub(crate)struct OwnedMessageOpenFailure{pub(crate)error:model_a_owner::Error,pub(crate)owner:OwnedMessageOriginal}
impl OwnedMessageOriginal{
 pub(crate)fn open(session:&model_a_owner::MessageSessionOwner,input:&crate::product_message::MessageInput)->Result<(Self,NativeStoreBridge),OwnedMessageOpenFailure>{
  let prepared=match session.prepare_operation(input){Ok(p)=>p,Err(error)=>return Err(OwnedMessageOpenFailure{error,owner:Self{prepared:None,snapshot:None,resources:None,store:ptr::null_mut(),proof:None,thread:std::thread::current().id(),unknown:false,store_closed:false,close_refused:false}})};
  let mut owner=Self{prepared:Some(prepared),snapshot:None,resources:None,store:ptr::null_mut(),proof:None,thread:std::thread::current().id(),unknown:false,store_closed:false,close_refused:false};
  let result=(||{
   owner.prepared.as_ref().unwrap().original_current()?;
   let acquired=NativeSnapshotOwner::acquire(owner.prepared.as_ref().unwrap()).map_err(|e|{owner.snapshot=e.retained;e.error})?;owner.snapshot=Some(acquired);
   let model_a_owner::DetachedMessageInputs{proof,admission,lease,intent,plan}=owner.prepared.as_mut().unwrap().detached_message_inputs()?;owner.proof=Some(NativeIssuerProof::Qualified(proof));
   owner.current()?;owner.prepared.as_ref().unwrap().enter_original()?;owner.current()?;
   let s=unsafe{veil_store_open_required(admission,&mut owner.store)};if s!=OK||owner.store.is_null(){return Err(model_a_owner::Error::Unknown)}owner.current()?;
   let snapshot=owner.snapshot.as_ref().unwrap();let p=snapshot.projection()?;if p.lease!=lease||p.intent!=intent||p.intent.cast::<std::ffi::c_void>()!=plan.intent||(p.queue==1)!=(!plan.inbox.is_null()){return Err(model_a_owner::Error::Association)}
   let bridge=NativeStoreBridge::from_qualified_snapshot(snapshot.clone()).map_err(|_|model_a_owner::Error::Unknown)?;
   owner.resources=Some(NativeIssuedResources{proof:owner.proof.take().unwrap(),store:std::mem::replace(&mut owner.store,ptr::null_mut()),lease,intent,journal:plan.journal.iter().map(|p|p.cast::<Step>()).collect(),queue:if !plan.inbox.is_null(){IssuedQueue::Inbox(plan.inbox.cast())}else{IssuedQueue::Outbox(plan.outbox.cast())},actor:bridge.actor,issuer:bridge.issuer.clone(),bound:PhantomData});owner.current()?;Ok(bridge)
  })();match result{Ok(bridge)=>Ok((owner,bridge)),Err(error)=>{owner.unknown=true;Err(OwnedMessageOpenFailure{error,owner})}}
 }
 pub(crate)fn current(&mut self)->Result<(),model_a_owner::Error>{
  if self.thread!=std::thread::current().id(){return Err(model_a_owner::Error::Thread)}if self.unknown||self.close_refused||self.store_closed{return Err(model_a_owner::Error::Unknown)}
  let r=(||{self.prepared.as_ref().ok_or(model_a_owner::Error::Required)?.original_current()?;if let Some(s)=&self.snapshot{s.current()?;}if let Some(p)=self.proof.as_mut(){p.current()?;}if let Some(r)=self.resources.as_mut(){r.proof.current()?;}self.prepared.as_ref().unwrap().original_current()})();if r.is_err(){self.unknown=true;}r
 }
 pub(crate)fn has_custody(&self)->bool{self.prepared.is_some()||self.snapshot.is_some()||self.resources.is_some()||self.proof.is_some()||!self.store.is_null()}
 pub(crate)fn close(&mut self,bridge:Option<&NativeStoreBridge>)->Result<(),model_a_owner::Error>{
  if self.thread!=std::thread::current().id(){return Err(model_a_owner::Error::Thread)}if self.close_refused{return Err(model_a_owner::Error::Unknown)}
  if let Some(b)=bridge{if !b.pending.is_empty()||b.custody.borrow().active.is_some(){return Err(model_a_owner::Error::Association)}}
  if let Some(s)=&self.snapshot{let expected=if bridge.is_some(){2}else{1};if Rc::strong_count(s)!=expected{return Err(model_a_owner::Error::Association)}}
  let store=if let Some(r)=self.resources.as_mut(){&mut r.store}else{&mut self.store};
  if !store.is_null(){if !self.store_closed{if unsafe{veil_store_close(*store)}!=OK{self.unknown=true;self.close_refused=true;return Err(model_a_owner::Error::Unknown)}self.store_closed=true;}let original=*store;if unsafe{veil_store_destroy(store)}!=OK||!store.is_null(){if *store!=original{std::process::abort()}self.unknown=true;self.close_refused=true;return Err(model_a_owner::Error::Unknown)}}
  if let Some(r)=self.resources.as_mut(){r.proof.close()?;}self.resources.take();if let Some(p)=self.proof.as_mut(){p.close()?;}self.proof.take();
  if let Some(s)=&self.snapshot{s.close()?;}self.snapshot.take();if let Some(p)=self.prepared.as_mut(){p.release()?;}self.prepared.take();Ok(())
 }
}
impl Drop for OwnedMessageOriginal{fn drop(&mut self){if self.prepared.is_some()||self.snapshot.is_some()||self.resources.is_some()||self.proof.is_some()||!self.store.is_null(){std::process::abort()}}}

#[repr(C)]struct ComputedStepRaw{kind:u32,id:u32,extra_id:u32,device:u32,name:SnapshotBytes,body:SnapshotBytes}
struct ComputedStepOwned{kind:u32,id:u32,extra_id:u32,device:u32,name:Vec<u8>,body:zeroize::Zeroizing<Vec<u8>>}
unsafe extern "C"{fn ynx_source_client_snapshot_protected_lookup(h:*mut std::ffi::c_void,out:*mut *mut VerifiedCommit)->i32;fn ynx_source_client_snapshot_protected_commit(h:*mut std::ffi::c_void,steps:*const ComputedStepRaw,count:usize,queue:u32,wire:SnapshotBytes,out:*mut *mut VerifiedCommit)->i32;}
impl NativeSnapshotOwner{
 pub(in crate::staging::platform)fn protected_commit(&self,snapshot:&NativeSnapshotHandle,steps:&[super::super::NativeSqlStep<'_>])->Result<super::super::NativeVerifiedFinalCommit,PortError>{
  validate_computation(snapshot)?;self.current().map_err(|_|PortError::Unknown)?;let projection=self.raw_projection().map_err(|_|PortError::Unknown)?;if projection.binding!=snapshot.stage.gate.0.borrow().binding||projection.source_abi!=snapshot.lease.binding.source_abi{return Err(PortError::Binding)}
  if steps.len()>33{return Err(PortError::Capacity)}let mut owned=Vec::new();owned.try_reserve_exact(steps.len()).map_err(|_|PortError::Capacity)?;let mut wire=None;let mut queue=0u32;
  for step in steps{
   use super::super::NativeSqlStep as S;let(kind,id,extra_id,address,body)=match step{
    S::Identity(a,k)=>(1,0,0,Some(*a),k.serialize().to_vec()),
    S::EcSave(id,r)=>(2,u32::from(*id),0,None,r.serialize().map_err(|_|PortError::Authentication)?),
    S::EcRemove(id)=>(3,u32::from(*id),0,None,Vec::new()),
    S::KyberSave(id,r)=>(4,u32::from(*id),0,None,r.serialize().map_err(|_|PortError::Authentication)?),
    S::KyberUsed(id,s,k)=>(5,u32::from(*id),u32::from(*s),None,k.serialize().to_vec()),
    S::Session(a,r)=>(6,0,0,Some(*a),r.serialize().map_err(|_|PortError::Authentication)?),
    S::Inbox(w)=>{if wire.is_some(){return Err(PortError::Binding)}wire=Some(*w);queue=1;continue},
    S::Outbox(w)=>{if wire.is_some(){return Err(PortError::Binding)}wire=Some(*w);queue=2;continue},
   };
   let body=zeroize::Zeroizing::new(body);let(name,device)=match address{Some(a)=>(a.name().as_bytes().to_vec(),u32::from(a.device_id())),None=>(Vec::new(),0)};if name.len()>128||body.len()>65536{return Err(PortError::Capacity)}owned.push(ComputedStepOwned{kind,id,extra_id,device,name,body});
  }
  let wire=wire.ok_or(PortError::Binding)?;if queue!=projection.queue||wire.is_empty()||wire.len()>1048576||owned.len()>32{return Err(PortError::Binding)}
  let raw:Vec<_>=owned.iter().map(|v|ComputedStepRaw{kind:v.kind,id:v.id,extra_id:v.extra_id,device:v.device,name:SnapshotBytes{data:v.name.as_ptr(),size:v.name.len()},body:SnapshotBytes{data:v.body.as_ptr(),size:v.body.len()}}).collect();
  self.current().map_err(|_|PortError::Unknown)?;self.retained_intent.set(projection.intent);let mut out=ptr::null_mut();let s=unsafe{ynx_source_client_snapshot_protected_commit(self.handle.get(),if raw.is_empty(){ptr::null()}else{raw.as_ptr()},raw.len(),queue,SnapshotBytes{data:wire.as_ptr(),size:wire.len()},&mut out)};
  // Custody before late validation; a partial foreign final cannot disappear.
  if let Some(handle)=std::ptr::NonNull::new(out){let intent=std::ptr::NonNull::new(projection.intent.cast_mut()).ok_or(PortError::Binding)?;*self.unverified_final.borrow_mut()=Some(model_a_owner::FinalOwner::adopt_published(handle,intent));}
  if s!=OK||self.unverified_final.borrow().is_none(){self.unknown.set(true);return Err(PortError::Unknown)}
  if self.unverified_final.borrow().as_ref().unwrap().current().is_err()||self.current().is_err(){self.unknown.set(true);return Err(PortError::Unknown)}
  let owner=self.unverified_final.borrow_mut().take().unwrap();Ok(super::super::NativeVerifiedFinalCommit{owner})
 }
 pub(in crate::staging::platform)fn protected_lookup(&self,snapshot:&NativeSnapshotHandle)->Result<super::super::NativeVerifiedFinalCommit,PortError>{
  validate_computation(snapshot)?;self.lookup_retained_original()
 }
 // Recovery observation is not operation permission. On scope uncertainty,
 // retain any independently returned final but never return an applied proof.
 pub(in crate::staging::platform)fn observe_unknown_lookup(&self){
  self.unknown.set(true);let _=self.lookup_retained_original();
 }
 fn lookup_retained_original(&self)->Result<super::super::NativeVerifiedFinalCommit,PortError>{
  if self.thread!=std::thread::current().id(){return Err(PortError::Unknown)}
  let intent=std::ptr::NonNull::new(self.retained_intent.get().cast_mut()).ok_or(PortError::RequiredCheckedSqlProducer)?;
  let mut held=self.unverified_final.try_borrow_mut().map_err(|_|PortError::Held)?;
  // An already returned partial final cannot be overwritten or re-published.
  if held.is_some(){return Err(PortError::Unknown)}
  let mut out=ptr::null_mut();let s=unsafe{ynx_source_client_snapshot_protected_lookup(self.handle.get(),&mut out)};
  if let Some(handle)=std::ptr::NonNull::new(out){*held=Some(model_a_owner::FinalOwner::adopt_published(handle,intent));}
  if s!=OK||held.is_none(){if s==REQUIRED&&!self.unknown.get(){return Err(PortError::RequiredCheckedSqlProducer)}self.unknown.set(true);return Err(PortError::Unknown)}
  if held.as_ref().unwrap().current().is_err()||self.current().is_err(){self.unknown.set(true);return Err(PortError::Unknown)}
  Ok(super::super::NativeVerifiedFinalCommit{owner:held.take().unwrap()})
 }
 pub(in crate::staging::platform)fn verify_final_binding(&self,b:&super::super::LeaseBinding,proof:&super::super::NativeVerifiedFinalCommit)->Result<(),PortError>{
  self.current().map_err(|_|PortError::Unknown)?;let p=self.raw_projection().map_err(|_|PortError::Unknown)?;let raw=p.binding;let expected=super::super::LeaseBinding{store:raw[0]as u128,session:raw[1]as u128,incarnation:raw[2],generation:raw[3],operation:raw[4],context:raw[5],route:raw[6],device_authorization:raw[7],revocation_checkpoint:raw[8],source_abi:p.source_abi};if *b!=expected{return Err(PortError::Binding)}proof.owner.matches_intent(p.intent).map_err(|_|PortError::Unknown)?;self.current().map_err(|_|PortError::Unknown)
 }
}
