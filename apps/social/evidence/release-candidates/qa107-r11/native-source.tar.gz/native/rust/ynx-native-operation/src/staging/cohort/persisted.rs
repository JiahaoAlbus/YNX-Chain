//! NEW APPLICATION STORAGE SCHEMA YNXPS001/v1, independent review required.
//! Raw storage decoding is unauthenticated, NEVER a cohort/source grant.
//! Upstream record serialization/crypto/wire remain unchanged.
use super::*;
const MAGIC:&[u8;8]=b"YNXPS001";
const HEADER:usize=16;
const ROW_HEADER:usize=24;
const TUPLE:usize=37;
#[derive(Debug,PartialEq,Eq)]pub(super) enum CodecError{Encoding,Version,Kind,Policy,Bound,Duplicate,Order,Allocation,SelectedRecord,SlotBinding}
// Scalar structural expectations only, NEVER source admission/capability.
#[derive(Clone,Copy)]pub(super) struct StructuralCellExpectation{pub(super)kind:u8,pub(super)id:u32,pub(super)version:u64}
#[derive(Clone,Copy,PartialEq,Eq,PartialOrd,Ord)]pub(super) struct UsedTuple{signed:u32,base:[u8;33]}
pub(super) enum UnverifiedEc{Record(Zeroizing<Vec<u8>>),Missing,Tombstone}
pub(super) enum UnverifiedCell{
 Ec{id:u32,version:u64,state:UnverifiedEc},
 Signed{id:u32,version:u64,record:Zeroizing<Vec<u8>>,policy:SignedPolicy},
 Kyber{id:u32,version:u64,record:Option<Zeroizing<Vec<u8>>>,policy:KyberPolicy,used:Vec<UsedTuple>},
}
pub(super) struct UnauthenticatedStorage{cells:Vec<UnverifiedCell>}
enum Uses<'a>{Encoded(&'a[u8]),Typed(&'a[UsedTuple])}
impl Uses<'_>{
 fn len(&self)->usize{match self{Self::Encoded(v)=>v.len()/TUPLE,Self::Typed(v)=>v.len()}}
 fn at(&self,i:usize)->UsedTuple{match self{Self::Typed(v)=>v[i],Self::Encoded(v)=>{let b=&v[i*TUPLE..(i+1)*TUPLE];UsedTuple{signed:u32::from_be_bytes(b[..4].try_into().unwrap()),base:b[4..].try_into().unwrap()}}}}
}
struct BorrowedRow<'a>{kind:u8,state:u8,policy:u8,id:u32,version:u64,record:&'a[u8],uses:Uses<'a>}
impl UnverifiedCell{
 fn view(&self)->BorrowedRow<'_>{match self{
  Self::Ec{id,version,state}=>{let(state,record)=match state{UnverifiedEc::Record(v)=>(1,v.as_slice()),UnverifiedEc::Missing=>(2,&[][..]),UnverifiedEc::Tombstone=>(3,&[][..])};BorrowedRow{kind:1,state,policy:0,id:*id,version:*version,record,uses:Uses::Typed(&[])}},
  Self::Signed{id,version,record,policy}=>BorrowedRow{kind:2,state:1,policy:match policy{SignedPolicy::ReceiveAllowed=>1,SignedPolicy::Revoked=>2},id:*id,version:*version,record,uses:Uses::Typed(&[])},
  Self::Kyber{id,version,record,policy,used}=>BorrowedRow{kind:3,state:if record.is_some(){1}else{2},policy:match policy{KyberPolicy::OneTimeAvailable=>1,KyberPolicy::OneTimeConsumed=>2,KyberPolicy::LastResort=>3},id:*id,version:*version,record:record.as_deref().map_or(&[],|v|v.as_slice()),uses:Uses::Typed(used)},
 }}
}
fn reserve<T>(n:usize)->Result<Vec<T>,CodecError>{let mut v=Vec::new();v.try_reserve_exact(n).map_err(|_|CodecError::Allocation)?;Ok(v)}
fn record_copy(v:&[u8])->Result<Zeroizing<Vec<u8>>,CodecError>{let mut out=Zeroizing::new(reserve(v.len())?);out.extend_from_slice(v);#[cfg(test)]RECORD_COPIES.with(|n|n.set(n.get()+1));Ok(out)}
fn row_len(r:&BorrowedRow<'_>)->Result<usize,CodecError>{ROW_HEADER.checked_add(r.record.len()).and_then(|n|r.uses.len().checked_mul(TUPLE).and_then(|u|n.checked_add(u))).ok_or(CodecError::Bound)}
fn validate(rows:&[BorrowedRow<'_>])->Result<usize,CodecError>{
 if rows.len()>MAX_ROWS{return Err(CodecError::Bound)}let mut size=HEADER;let mut previous=None;
 for r in rows{
  if r.version==0{return Err(CodecError::Version)}
  let key=(r.kind,r.id);if let Some(old)=previous{if old==key{return Err(CodecError::Duplicate)}if old>key{return Err(CodecError::Order)}}previous=Some(key);
  if r.uses.len()>MAX_USES||row_len(r)?>MAX_ROW_BYTES{return Err(CodecError::Bound)}
  let valid=match r.kind{
   1=>r.policy==0&&r.uses.len()==0&&match r.state{1=>!r.record.is_empty(),2|3=>r.record.is_empty(),_=>false},
   2=>r.state==1&&matches!(r.policy,1|2)&&!r.record.is_empty()&&r.uses.len()==0,
   3=>match r.policy{1=>r.state==1&&!r.record.is_empty()&&r.uses.len()==0,2=>r.state==2&&r.record.is_empty()&&r.uses.len()==1,3=>r.state==1&&!r.record.is_empty(),_=>false},
   _=>return Err(CodecError::Kind),
  };if !valid{return Err(CodecError::Policy)}
  let mut old=None;for i in 0..r.uses.len(){let t=r.uses.at(i);if let Some(prior)=old{if t==prior{return Err(CodecError::Duplicate)}if t<prior{return Err(CodecError::Order)}}old=Some(t);
   if t.base[0]!=5{return Err(CodecError::Encoding)}let public=IdentityKey::decode(&t.base).map_err(|_|CodecError::Encoding)?;if public.serialize().as_ref()!=t.base.as_slice(){return Err(CodecError::Encoding)}
   // A protected cell is independently bound to (kind,id). Cross-row signed
   // presence/current policy is checked on the genuine complete cohort, NOT
   // inferred or required from this unauthenticated sparse storage frame.
  }
  size=size.checked_add(row_len(r)?).ok_or(CodecError::Bound)?;if size>MAX_INPUT_BYTES{return Err(CodecError::Bound)}
 }
 Ok(size)
}
struct Cursor<'a>{bytes:&'a[u8],at:usize}
impl<'a> Cursor<'a>{fn take(&mut self,n:usize)->Result<&'a[u8],CodecError>{let end=self.at.checked_add(n).ok_or(CodecError::Bound)?;let b=self.bytes.get(self.at..end).ok_or(CodecError::Encoding)?;self.at=end;Ok(b)}}
fn borrowed_rows(bytes:&[u8],expected:Option<StructuralCellExpectation>)->Result<Vec<BorrowedRow<'_>>,CodecError>{
 if bytes.len()>MAX_INPUT_BYTES{return Err(CodecError::Bound)}let mut c=Cursor{bytes,at:0};let h=c.take(HEADER)?;
 if &h[..8]!=MAGIC{return Err(CodecError::Encoding)}if u16::from_be_bytes(h[8..10].try_into().unwrap())!=1{return Err(CodecError::Version)}let count=u16::from_be_bytes(h[10..12].try_into().unwrap())as usize;if count>MAX_ROWS{return Err(CodecError::Bound)}
 if u32::from_be_bytes(h[12..16].try_into().unwrap())as usize!=bytes.len()-HEADER{return Err(CodecError::Encoding)}
 if expected.is_some()&&count!=1{return Err(CodecError::SlotBinding)}
 // Bounded borrowed metadata only. No secret byte copy until complete validation.
 let mut rows=reserve(count)?;for _ in 0..count{let h=c.take(ROW_HEADER)?;if h[3]!=0||h[21..24]!=[0,0,0]{return Err(CodecError::Encoding)}let n=u32::from_be_bytes(h[16..20].try_into().unwrap())as usize;let used=h[20]as usize;
  if used>MAX_USES||n>MAX_ROW_BYTES||ROW_HEADER.checked_add(n).and_then(|v|v.checked_add(used*TUPLE)).ok_or(CodecError::Bound)?>MAX_ROW_BYTES{return Err(CodecError::Bound)}
  if let Some(e)=expected{if h[0]!=e.kind||u32::from_be_bytes(h[4..8].try_into().unwrap())!=e.id||u64::from_be_bytes(h[8..16].try_into().unwrap())!=e.version{return Err(CodecError::SlotBinding)}}
  rows.push(BorrowedRow{kind:h[0],state:h[1],policy:h[2],id:u32::from_be_bytes(h[4..8].try_into().unwrap()),version:u64::from_be_bytes(h[8..16].try_into().unwrap()),record:c.take(n)?,uses:Uses::Encoded(c.take(used*TUPLE)?)});
 }
 if c.at!=bytes.len(){return Err(CodecError::Encoding)}validate(&rows)?;
 Ok(rows)
}
fn own_rows(rows:Vec<BorrowedRow<'_>>)->Result<UnauthenticatedStorage,CodecError>{
 let mut cells=reserve(rows.len())?;for r in rows{let cell=match r.kind{
  1=>UnverifiedCell::Ec{id:r.id,version:r.version,state:match r.state{1=>UnverifiedEc::Record(record_copy(r.record)?),2=>UnverifiedEc::Missing,3=>UnverifiedEc::Tombstone,_=>unreachable!()}},
  2=>UnverifiedCell::Signed{id:r.id,version:r.version,record:record_copy(r.record)?,policy:if r.policy==1{SignedPolicy::ReceiveAllowed}else{SignedPolicy::Revoked}},
  3=>{let mut used=reserve(r.uses.len())?;for i in 0..r.uses.len(){used.push(r.uses.at(i));}UnverifiedCell::Kyber{id:r.id,version:r.version,record:if r.state==1{Some(record_copy(r.record)?)}else{None},policy:match r.policy{1=>KyberPolicy::OneTimeAvailable,2=>KyberPolicy::OneTimeConsumed,_=>KyberPolicy::LastResort},used}},_=>unreachable!(),
 };cells.push(cell);}
 Ok(UnauthenticatedStorage{cells})
}
pub(super) fn decode(bytes:&[u8])->Result<UnauthenticatedStorage,CodecError>{own_rows(borrowed_rows(bytes,None)?)}
pub(super) fn decode_single(bytes:&[u8],expected:StructuralCellExpectation)->Result<SelectedUnverifiedEntry,CodecError>{
 let storage=own_rows(borrowed_rows(bytes,Some(expected))?)?;
 let mut selected=storage.decode_selected()?;
 // Count was checked before ANY record copy/selected parse. Move sole owner.
 selected.entries.pop().ok_or(CodecError::SlotBinding)
}
pub(super) fn encode(input:&UnauthenticatedStorage)->Result<Zeroizing<Vec<u8>>,CodecError>{
 let mut rows=reserve(input.cells.len().min(MAX_ROWS))?;if input.cells.len()>MAX_ROWS{return Err(CodecError::Bound)}for cell in &input.cells{rows.push(cell.view());}let size=validate(&rows)?;
 let mut out=Zeroizing::new(reserve(size)?);out.extend_from_slice(MAGIC);out.extend_from_slice(&1u16.to_be_bytes());out.extend_from_slice(&(rows.len()as u16).to_be_bytes());out.extend_from_slice(&((size-HEADER)as u32).to_be_bytes());
 for r in rows{out.extend_from_slice(&[r.kind,r.state,r.policy,0]);out.extend_from_slice(&r.id.to_be_bytes());out.extend_from_slice(&r.version.to_be_bytes());out.extend_from_slice(&(r.record.len()as u32).to_be_bytes());out.extend_from_slice(&[r.uses.len()as u8,0,0,0]);out.extend_from_slice(r.record);for i in 0..r.uses.len(){let t=r.uses.at(i);out.extend_from_slice(&t.signed.to_be_bytes());out.extend_from_slice(&t.base);}}
 Ok(out)
}
enum SelectedUnverified{Ec(PreKeyRecord),Missing,Tombstone,Signed(SignedPreKeyRecord),Kyber(Option<KyberPreKeyRecord>)}
// This owner is only shape-decoded storage. No authenticated cohort constructor.
pub(super) struct SelectedUnverifiedEntry{metadata:UnverifiedCell,record:SelectedUnverified}
pub(super) struct SelectedUnverifiedOwner{entries:Vec<SelectedUnverifiedEntry>}
impl UnauthenticatedStorage{
 pub(super) fn decode_selected(self)->Result<SelectedUnverifiedOwner,CodecError>{
  let mut rows=reserve(self.cells.len().min(MAX_ROWS))?;if self.cells.len()>MAX_ROWS{return Err(CodecError::Bound)}for cell in &self.cells{rows.push(cell.view());}validate(&rows)?;
  let mut entries=reserve(rows.len())?;drop(rows);
  for metadata in self.cells{let row=metadata.view();
   #[cfg(test)]if !row.record.is_empty(){SELECTED_PARSES.with(|n|n.set(n.get()+1));}
   let record=match row.kind{
   1=>match row.state{1=>{let r=PreKeyRecord::deserialize(row.record).map_err(|_|CodecError::SelectedRecord)?;if r.id().map_err(|_|CodecError::SelectedRecord)?!=PreKeyId::from(row.id){return Err(CodecError::SelectedRecord)}pair_consistent(&r.key_pair().map_err(|_|CodecError::SelectedRecord)?).map_err(|_|CodecError::SelectedRecord)?;SelectedUnverified::Ec(r)},2=>SelectedUnverified::Missing,_=>SelectedUnverified::Tombstone},
   2=>{let r=SignedPreKeyRecord::deserialize(row.record).map_err(|_|CodecError::SelectedRecord)?;if r.id().map_err(|_|CodecError::SelectedRecord)?!=SignedPreKeyId::from(row.id){return Err(CodecError::SelectedRecord)}pair_consistent(&r.key_pair().map_err(|_|CodecError::SelectedRecord)?).map_err(|_|CodecError::SelectedRecord)?;SelectedUnverified::Signed(r)},
   3=>{let r=if row.state==1{let r=KyberPreKeyRecord::deserialize(row.record).map_err(|_|CodecError::SelectedRecord)?;if r.id().map_err(|_|CodecError::SelectedRecord)?!=KyberPreKeyId::from(row.id){return Err(CodecError::SelectedRecord)}let pair=r.key_pair().map_err(|_|CodecError::SelectedRecord)?;if pair.public_key.key_type()!=kem::KeyType::Kyber1024||pair.secret_key.key_type()!=kem::KeyType::Kyber1024{return Err(CodecError::SelectedRecord)}Some(r)}else{None};SelectedUnverified::Kyber(r)},_=>unreachable!(),
  };entries.push(SelectedUnverifiedEntry{metadata,record});}
  // Upstream runtime allocations are ordinary lifetime-owned, NOT allwipe/lock.
  // Signature/identity/current version/source provenance is checked later ONLY
  // by the genuine protected provider + existing authenticated cohort decoder.
  Ok(SelectedUnverifiedOwner{entries})
 }
}
// Conversion of an application USED SET only. NEVER reorder a journal.
pub(super) fn canonical_used_from_receive(used:&[(SignedPreKeyId,PublicKey)])->Result<Vec<UsedTuple>,CodecError>{
 if used.len()>MAX_USES{return Err(CodecError::Bound)}let mut out=reserve(used.len())?;
 for(id,key)in used{let b=key.serialize();let base:[u8;33]=b.as_ref().try_into().map_err(|_|CodecError::Encoding)?;out.push(UsedTuple{signed:u32::from(*id),base});}
 out.sort_unstable();check_used_set(&out)?;Ok(out)
}
fn check_used_set(used:&[UsedTuple])->Result<(),CodecError>{
 if used.len()>MAX_USES{return Err(CodecError::Bound)}
 for(i,t)in used.iter().enumerate(){if i>0{if used[i-1]==*t{return Err(CodecError::Duplicate)}if used[i-1]>*t{return Err(CodecError::Order)}}if t.base[0]!=5{return Err(CodecError::Encoding)}let p=IdentityKey::decode(&t.base).map_err(|_|CodecError::Encoding)?;if p.serialize().as_ref()!=t.base.as_slice(){return Err(CodecError::Encoding)}}Ok(())
}
pub(super) fn receive_used_from_canonical(used:&[UsedTuple])->Result<Vec<(SignedPreKeyId,PublicKey)>,CodecError>{
 check_used_set(used)?;let mut out=reserve(used.len())?;for t in used{let p=IdentityKey::decode(&t.base).map_err(|_|CodecError::Encoding)?;out.push((SignedPreKeyId::from(t.signed),*p.public_key()));}Ok(out)
}
impl SelectedUnverifiedEntry{
 // Projection of SAME metadata owner: no grant or authenticated cohort minted.
 pub(super) fn used_for_cohort(&self)->Result<Option<Vec<(SignedPreKeyId,PublicKey)>>,CodecError>{match &self.metadata{UnverifiedCell::Kyber{used,..}=>receive_used_from_canonical(used).map(Some),_=>Ok(None)}}
}
impl Drop for UnverifiedCell{fn drop(&mut self){#[cfg(test)]METADATA_DROPS.with(|n|n.set(n.get()+1));}}
impl Drop for SelectedUnverifiedEntry{fn drop(&mut self){#[cfg(test)]ENTRY_DROPS.with(|n|n.set(n.get()+1));}}
#[cfg(test)]thread_local!{static RECORD_COPIES:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};static SELECTED_PARSES:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};static METADATA_DROPS:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};static ENTRY_DROPS:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}
#[cfg(test)]mod tests;
#[cfg(test)]mod typed_tests;
