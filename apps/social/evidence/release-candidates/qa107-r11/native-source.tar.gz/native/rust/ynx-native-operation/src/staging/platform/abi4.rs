//! Explicit ABI4 closed consumer. Native issuer and result bridge REQUIRED.
//! No C pointer, source hash, SQL OK or projected bytes issue a native lease.
use std::convert::Infallible;
const ABI:u32=4;
const HEADER_SHA256:&str="c69ded3aef2d4cf18e63165a372ce2b1d2f211a6bdf25432375c70c06344883e";
const PRIVATE_HEADER_SHA256:&str="cdb15e9cf0cb37eb49200791d79279ed572459a14958831dd4acee2790be752e";
const ANDROID_ARCHIVE_SHA256:&str="cbc0265b31d547df5b89c73d3e5e5700d101fe218aefe6eda6d035116a6712d8";
pub(super) enum Dependency{OriginalNativeStoreLease,CohortIssuer,ProtectedIntentIssuer,IndependentCas,FinalOnceReceiptTransfer,NativeAbiInvariant}
pub(super) fn require_open()->Result<Infallible,Dependency>{
 #[cfg(feature="abi4-final-native-link")]return linked::require_original_store();
 #[cfg(not(feature="abi4-final-native-link"))]Err(Dependency::OriginalNativeStoreLease)
}
#[cfg(feature="abi4-final-native-link")]
#[allow(unsafe_code)] // Narrow reviewed candidate FFI, no public pointer issuer.
mod linked;

// Deliberately no success handle implementation: exact ABI4 has no admitted
// constructor into Rust NativeVerifiedAuthority/NativeVerifiedFinalCommit.
// Do not add getters, public authority traits, runtime callback registration,
// fixture linker into normal, or infer success from a non-null C pointer.

#[cfg(all(test,feature="abi4-final-native-link"))]pub(super) fn require_after_actual_computation(s:&super::NativeSnapshotHandle)->Result<Infallible,super::PortError>{linked::require_after_actual_computation(s)}
