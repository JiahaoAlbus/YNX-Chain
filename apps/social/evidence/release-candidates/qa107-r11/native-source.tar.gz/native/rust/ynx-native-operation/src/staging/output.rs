//! NEW private application delivery framing, not Signal encoding or authority.
use super::*;
use crate::NativeProductError;
#[derive(Clone,Copy,Debug,PartialEq,Eq)]pub(crate) enum SelectedWireKind{Signal,PreKey}
impl SelectedWireKind{
 pub(super)fn from_selected(wire:&CiphertextMessage)->R<Self>{match wire{
  CiphertextMessage::SignalMessage(_)=>Ok(Self::Signal),CiphertextMessage::PreKeySignalMessage(_)=>Ok(Self::PreKey),_=>Err(stopped()),
 }}
}
// YNXO / version1 / direction1=outgoing2=incoming / kind1=text2=Signal3=PreKey
// / reserved0 / original logical16 / BE32 length / exact body. New APP schema.
// A valid encoding never proves authentication, durable receipt, or currentness.
pub(super)fn encode(logical:&[u8;16],outbound:bool,kind:SelectedWireKind,body:&[u8])->Result<zeroize::Zeroizing<Vec<u8>>,NativeProductError>{
 let limit=if outbound{MAX_WIRE}else{crate::product_message::MAX_TEXT};
 if logical==&[0;16]{return Err(NativeProductError::Binding)}
 if body.is_empty()||body.len()>limit{return Err(NativeProductError::Capacity)}
 if !outbound&&std::str::from_utf8(body).is_err(){return Err(NativeProductError::Rejected)}
 let mut frame=zeroize::Zeroizing::new(Vec::new());frame.try_reserve_exact(28+body.len()).map_err(|_|NativeProductError::Capacity)?;
 frame.extend_from_slice(b"YNXO");frame.extend_from_slice(&[1,if outbound{1}else{2},if !outbound{1}else{match kind{SelectedWireKind::Signal=>2,SelectedWireKind::PreKey=>3}},0]);
 frame.extend_from_slice(logical);frame.extend_from_slice(&(body.len()as u32).to_be_bytes());frame.extend_from_slice(body);Ok(frame)
}
#[cfg(test)]mod tests{
 use super::*;
 fn gate()->Gate{let binding=[1,2,3,0,5,6,7,8,9,0,2];Gate(Rc::new(RefCell::new(Pending{phase:Phase::Working,binding,bytes:0,journal:Vec::new(),original_ciphertext:None,generated_wire:false,selected_wire_kind:None,plaintext:None,trigger:None,pending:false})),Rc::new(spqr::ynx_operation::CallScope::fixture(binding)))}
 fn public_wire()->CiphertextMessage{let mut wire=vec![0x44,0x0a,33,5,9];wire.extend([0;31]);wire.extend([0x10,0,0x22,1,0]);wire.extend([0;8]);CiphertextMessage::SignalMessage(SignalMessage::try_from(wire.as_slice()).expect("public shape only, zero MAC"))}
 #[test]fn r53_actual_retainer_preserves_selected_kind_and_unknown(){let g=gate();let w=public_wire();g.retain_generated(&w).unwrap();g.1.fixture_unknown();g.retain_generated(&w).unwrap();let p=g.0.borrow();assert!(p.phase==Phase::Unknown);assert!(p.generated_wire);assert_eq!(p.selected_wire_kind,Some(SelectedWireKind::Signal));assert_eq!(p.original_ciphertext.as_deref(),Some(w.serialize()));assert!(p.journal.is_empty());}
 #[test]fn r53_inbound_selected_retention_matches_same_original(){let g=gate();let w=public_wire();g.retain_selected_inbound(&w).unwrap();assert_eq!(g.0.borrow().selected_wire_kind,Some(SelectedWireKind::Signal));assert!(!g.0.borrow().generated_wire);let old=g.0.borrow().original_ciphertext.clone();assert!(g.retain_inbound(b"different").is_err());assert_eq!(g.0.borrow().original_ciphertext,old);}
 #[test]fn r53_output_exact_type_logical_and_repeat(){for (kind,tag) in [(SelectedWireKind::Signal,2),(SelectedWireKind::PreKey,3)]{let a=encode(&[9;16],true,kind,b"PUBLIC dummy cipher").unwrap();let b=encode(&[9;16],true,kind,b"PUBLIC dummy cipher").unwrap();assert_eq!(a,b);assert_eq!(&a[..8],&[b'Y',b'N',b'X',b'O',1,1,tag,0]);assert_eq!(&a[8..24],&[9;16]);assert_eq!(u32::from_be_bytes(a[24..28].try_into().unwrap())as usize,a.len()-28);assert_eq!(&a[28..],b"PUBLIC dummy cipher");}}
 #[test]fn r53_output_bounds_utf8_and_no_metadata_authority(){let k=SelectedWireKind::Signal;assert!(encode(&[0;16],true,k,b"x").is_err());assert!(encode(&[1;16],true,k,&[]).is_err());assert!(encode(&[1;16],true,k,&vec![1;MAX_WIRE]).is_ok());assert!(encode(&[1;16],true,k,&vec![1;MAX_WIRE+1]).is_err());assert!(encode(&[1;16],false,k,&vec![b'x';crate::product_message::MAX_TEXT]).is_ok());assert!(encode(&[1;16],false,k,&vec![b'x';crate::product_message::MAX_TEXT+1]).is_err());assert!(encode(&[1;16],false,k,&[255]).is_err());assert!(matches!(crate::NativeProductEngine::open_native(),Err(NativeProductError::RequiredRoots(_))));}
}
