//! Restricted original-owner recovery loan. No generation, seal or commit API.
use super::*;
#[derive(Clone,Copy,PartialEq,Eq)]pub(crate)enum RecoveryTopology{Refused,Held,Existing}
pub(super)struct RecoveryState{input:jni::refs::Global<jni::objects::JObject<'static>>,path_attempted:bool,capture_attempted:bool,first:Option<i32>,authenticated:Option<AuthenticatedPair>}
// Constructed ONLY after both selected authenticated unseals return success.
// This is local key custody, never identity/device/source authorization.
struct AuthenticatedPair;
pub(crate)struct LocalPublicPair<'a>{pub(crate)classic:[u8;33],pub(crate)pq:[u8;2592],pub(crate)operation:&'a[u8;32],pub(crate)alias:&'a str,pub(crate)generation:u64,pub(crate)association:&'a[u8]}
pub(crate)struct RecoveryLoan<'a>(pub(super) &'a mut LocalGenesisReservation);
impl LocalGenesisReservation{pub(crate)fn recovery_loan(&mut self)->Result<RecoveryLoan<'_>,CustodyError>{if self.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}Ok(RecoveryLoan(self))}}
impl RecoveryLoan<'_>{
 #[cfg(test)]pub(crate)fn rcj_recovery_first(&self)->Option<i32>{self.0.first_recovery_failure}
 #[cfg(test)]pub(crate)fn rcj_has_recovery(&self)->bool{self.0.recovery.is_some()}
 #[cfg(feature="predevice-reconciliation-v3")]
 pub(crate)fn prepare_original_local_disposition(&mut self)->Result<(),CustodyError>{
  #[cfg(feature="predevice-cold-v1")]if self.topology()==RecoveryTopology::Existing{
   let ids=self.0.local_ids.as_ref().ok_or(CustodyError::Phase)?;let mut op=[0;16];let mut inc=[0;16];op.copy_from_slice(&ids[..16]);inc.copy_from_slice(&ids[16..]);
   return self.0.existing_reader.as_mut().ok_or(CustodyError::Phase)?.prepare_cold(&self.0.input,op,inc).map_err(|_|CustodyError::Unknown)
  }
  self.reconcile_original_local_store().map(|_|())
 }
 #[cfg(feature="predevice-reconciliation-v3")]
 pub(crate)fn discharge_original_local_store(&mut self)->Result<(),CustodyError>{
  #[cfg(feature="predevice-cold-v1")]if self.topology()==RecoveryTopology::Existing{
   self.prepare_original_local_disposition()?;
   return self.0.existing_reader.as_mut().ok_or(CustodyError::Phase)?.discharge_cold().map_err(|_|CustodyError::Unknown)
  }
  self.reconcile_original_local_store()?.discharge_store()
 }
 #[cfg(feature="predevice-reconciliation-v3")]
 pub(crate)fn original_local_store_stage(&self)->Result<predevice_port::LocalStoreStage,CustodyError>{
  if self.0.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  #[cfg(feature="predevice-cold-v1")]if self.topology()==RecoveryTopology::Existing{return self.0.existing_reader.as_ref().ok_or(CustodyError::Phase)?.cold_stage().map_err(|_|CustodyError::Unknown)}
  self.0.predevice.as_ref().ok_or(CustodyError::Phase)?.local_store_stage()
 }
 #[cfg(feature="predevice-reconciliation-v3")]
 fn reconcile_original_local_store(&mut self)->Result<predevice_port::HeldDisposition<'_>,CustodyError>{
  if self.0.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  let owner=self.0.predevice.as_mut().ok_or(CustodyError::Phase)?;
  owner.reconcile_v3(&self.0.input)
 }
 /// Borrow only the existing original owner. Missing ownership cannot be
 /// repaired by opening a replacement store or manufacturing an operation.
 pub(crate)fn retain_predevice_reconciliation(&mut self)->Result<predevice_port::RetainedReconciliation<'_>,CustodyError>{
  if self.0.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  self.0.predevice.as_mut().ok_or(CustodyError::Phase)?.retain_reconciliation()
 }
 pub(crate)fn command(&self)->Result<&jni::refs::Global<jni::objects::JObject<'static>>,CustodyError>{self.0.original_java_command()}
 pub(crate)fn matches(&self,alias:&str,generation:i64,association:&[u8],ids:&[u8])->bool{generation>0&&self.0.input.alias==alias&&self.0.input.generation==generation as u64&&self.0.input.association==association&&self.0.local_ids.as_ref().is_some_and(|v|v.as_slice()==ids)&&!self.0.local_ids_failed&&self.0.id_binding==OriginalIdBinding::Acknowledged}
 pub(crate)fn topology(&self)->RecoveryTopology{self.0.predevice.as_ref().map(|p|p.recovery_topology()).unwrap_or(RecoveryTopology::Refused)}
 pub(crate)fn start(&mut self,input:jni::refs::Global<jni::objects::JObject<'static>>)->Result<RecoveryTopology,CustodyError>{
  if self.0.recovery.is_some(){return Err(CustodyError::Unknown)}
  self.0.recovery=Some(RecoveryState{input,path_attempted:false,capture_attempted:false,first:None,authenticated:None});
  let topology=self.topology();if topology==RecoveryTopology::Refused{self.fail(16);return Err(CustodyError::Unknown)}Ok(topology)
 }
 pub(crate)fn input(&self)->Result<&jni::refs::Global<jni::objects::JObject<'static>>,CustodyError>{self.0.recovery.as_ref().map(|s|&s.input).ok_or(CustodyError::Phase)}
 pub(crate)fn fail(&mut self,code:i32){
  // Disposition may begin before a read-existing RecoveryState is installed.
  // Always retain the primary on the original owner, never just in that view.
  if self.0.first_recovery_failure.is_none(){self.0.first_recovery_failure=Some(code)}
  if let Some(s)=self.0.recovery.as_mut(){if s.first.is_none(){s.first=Some(code)}}
 }
 pub(crate)fn open_existing(&mut self,path:&std::ffi::CStr)->Result<(),CustodyError>{
  if self.topology()!=RecoveryTopology::Existing{return Err(CustodyError::Unknown)}
  let s=self.0.recovery.as_mut().ok_or(CustodyError::Phase)?;
  if s.first.is_some()||s.path_attempted||self.0.existing_reader.is_some(){return Err(CustodyError::Unknown)}
  s.path_attempted=true;self.0.existing_reader=Some(predevice_port::ExistingReader::unopened());
  if self.0.existing_reader.as_mut().ok_or(CustodyError::Phase)?.open_once(path).is_err(){self.fail(16);return Err(CustodyError::Unknown)}Ok(())
 }
 pub(crate)fn capture(&mut self)->Result<(),CustodyError>{
  let s=self.0.recovery.as_mut().ok_or(CustodyError::Phase)?;if s.first.is_some()||s.capture_attempted{return Err(CustodyError::Unknown)}s.capture_attempted=true;
  let result=match self.topology(){
   RecoveryTopology::Held=>self.0.predevice.as_mut().ok_or(CustodyError::Phase)?.capture_for_recovery(&self.0.input),
   RecoveryTopology::Existing=>{let ids=self.0.local_ids.as_ref().ok_or(CustodyError::Phase)?;let mut op=[0;16];let mut inc=[0;16];op.copy_from_slice(&ids[..16]);inc.copy_from_slice(&ids[16..]);self.0.existing_reader.as_mut().ok_or(CustodyError::Phase)?.capture_original(&self.0.input,op,inc).map(|_|()).map_err(|_|CustodyError::Unknown)},
   RecoveryTopology::Refused=>Err(CustodyError::Unknown),
  };if result.is_err(){self.fail(16)}result
 }
}
impl RecoveryLoan<'_>{
 fn captured(&self)->Result<(),CustodyError>{
  if self.0.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  let s=self.0.recovery.as_ref().ok_or(CustodyError::Phase)?;
  if s.first.is_some()||self.0.reload_failure.is_some(){return Err(CustodyError::Unknown)}
  if !s.capture_attempted||self.0.id_binding!=OriginalIdBinding::Acknowledged||self.0.local_ids_failed{return Err(CustodyError::Phase)}
  Ok(())
 }
 // Caller holds the original actor OUTSIDE its TLS RefCell borrow while C
 // invokes platform callbacks. The exact worker Env/Context was checked by JNI.
 // Original C UNKNOWN is NOT cleared or converted into permission to commit.
 pub(crate)unsafe fn authenticate_captured(&mut self,env:*mut jni::sys::JNIEnv,context:jni::sys::jobject)->Result<(),CustodyError>{
  self.captured()?;
  if env.is_null()||context.is_null(){return Err(CustodyError::Bounds)}
  if self.0.reload_attempted||self.0.classic.is_some(){return Err(CustodyError::Phase)}
  if self.0.custody.is_some()&&self.topology()!=RecoveryTopology::Held{return Err(CustodyError::Phase)}
  self.0.reload_attempted=true;
  let result=(||->Result<(),CustodyError>{
   let wire=match self.topology(){
    RecoveryTopology::Held=>self.0.predevice.as_mut().ok_or(CustodyError::Phase)?.capture_original_journal(&self.0.input)?,
    RecoveryTopology::Existing=>{let ids=self.0.local_ids.as_ref().ok_or(CustodyError::Phase)?;let mut op=[0;16];let mut inc=[0;16];op.copy_from_slice(&ids[..16]);inc.copy_from_slice(&ids[16..]);self.0.existing_reader.as_mut().ok_or(CustodyError::Phase)?.capture_original(&self.0.input,op,inc).map_err(|_|CustodyError::Unknown)?},
    RecoveryTopology::Refused=>return Err(CustodyError::Phase),
   };
   if let Some(custody)=self.0.custody.as_mut(){
    // Generated Held owner stays installed; authenticate its exact original
    // ciphertext using its actual protector, not its resident plaintext.
    custody.authenticate_held_original(wire)?;
   }else{
    let projection=reload_projection::UnverifiedProjection::decode(wire,&self.0.input)?;
    self.0.custody=Some(NativeOwnKeyCustody::reserve_existing_reload(projection.binding));
    let custody=self.0.custody.as_mut().ok_or(CustodyError::Phase)?;
    custody.load_unverified_pair(wire,projection.pq_public)?;
    unsafe{custody.initialize(env,context,LocalProtectionMode::RestoreLocalLookup,0)}?;
    custody.reload_both()?;
   }
   self.0.recovery.as_mut().ok_or(CustodyError::Phase)?.authenticated=Some(AuthenticatedPair);
   Ok(())
  })();
  if result.is_err(){self.fail(16)}result
 }
 pub(crate)fn public_pair(&self)->Result<LocalPublicPair<'_>,CustodyError>{
  self.captured()?;
  if self.0.recovery.as_ref().and_then(|s|s.authenticated.as_ref()).is_none(){return Err(CustodyError::Phase)}
  let custody=self.0.custody.as_ref().ok_or(CustodyError::Phase)?;custody.live()?;
  if custody.pq.is_null()||custody.platform.is_null(){return Err(CustodyError::Phase)}
  let classic:[u8;33]=custody.classic.as_ref().ok_or(CustodyError::Phase)?.public_identity().serialize().as_ref().try_into().map_err(|_|CustodyError::Pair)?;
  let mut pq=[0;2592];let code=unsafe{veil_own_public(custody.pq,pq.as_mut_ptr())};
  if code!=0{return Err(CustodyError::Foreign(code))}
  if classic!=custody.binding.classic||pq!=custody.pq_public{return Err(CustodyError::Pair)}
  Ok(LocalPublicPair{classic,pq,operation:self.0.local_ids.as_ref().ok_or(CustodyError::Phase)?,alias:&self.0.input.alias,generation:self.0.input.generation,association:&self.0.input.association})
 }
}
#[cfg(test)]mod tests{
 use super::*;
 fn original()->LocalGenesisReservation{LocalGenesisReservation::retain(LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public input")))}
 #[test]fn r62_missing_capture_cannot_project_or_unseal(){let mut owner=original();let mut loan=owner.recovery_loan().unwrap();assert!(matches!(loan.public_pair(),Err(CustodyError::Phase)));assert!(matches!(unsafe{loan.authenticate_captured(std::ptr::null_mut(),std::ptr::null_mut())},Err(CustodyError::Phase)));assert!(owner.custody.is_none()&&!owner.reload_attempted);}
 #[test]fn r62_c_unknown_remains_original_without_fake_authenticated_pair(){let mut owner=original();assert!(owner.reserve_predevice(&std::ffi::CString::new("relative").unwrap(),[1;16],[2;16]).is_err());assert!(matches!(owner.recovery_loan().unwrap().public_pair(),Err(CustodyError::Phase)));assert!(matches!(owner.current_local(),Err(CustodyError::Unknown)));assert!(owner.custody.is_none()&&!owner.reload_attempted);}
 #[test]fn r60_none_topology_never_creates_reader(){let mut original=original();assert!(original.recovery_loan().unwrap_or_else(|_|panic!("same thread")).topology()==RecoveryTopology::Refused);assert!(original.existing_reader.is_none()&&original.predevice.is_none()&&original.recovery.is_none());}
 #[test]fn r60_actual_failed_open_keeps_original_unknown_and_no_reader(){let mut original=original();assert!(matches!(original.reserve_predevice(&std::ffi::CString::new("relative").unwrap(),[1;16],[2;16]),Err(CustodyError::Unknown)));assert!(original.recovery_loan().unwrap_or_else(|_|panic!("same thread")).topology()==RecoveryTopology::Existing);assert!(matches!(original.current_local(),Err(CustodyError::Unknown)));assert!(original.existing_reader.is_none()&&original.recovery.is_none());}
}

// cfg(test) scalar binding fixture only; no Global/C owner/provider/authority.
#[cfg(test)]pub(crate)fn r61_fixture_original_matches(alias:&str)->bool{
 let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public fixture"));
 let mut original=LocalGenesisReservation::retain(input);original.local_ids=Some([7;32]);original.id_binding=OriginalIdBinding::Acknowledged;
 original.recovery_loan().unwrap_or_else(|_|panic!("same thread")).matches(alias,1,&[7],&[7;32])
}

#[cfg(feature="abi5-final-native-link")]
impl RecoveryLoan<'_>{
 pub(crate)fn first_device_source_ready(&self)->Result<bool,CustodyError>{
  self.captured()?;if self.0.recovery.as_ref().and_then(|s|s.authenticated.as_ref()).is_none(){return Err(CustodyError::Phase)}
  let Some(p)=self.0.source_request.as_ref()else{return Ok(false)};p.has_complete_account_input()
 }
 pub(crate)fn close_original_signing_guard(&mut self)->Result<(),CustodyError>{
  if self.0.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  let result=self.0.source_request.as_mut().ok_or(CustodyError::Phase)?.close_signing();
  if result.is_err(){if let Some(c)=self.0.custody.as_mut(){c.unknown=true}}result
 }
 pub(crate)fn invalidate_first_device_signing(&mut self)->Result<(),CustodyError>{
  if self.0.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  if let Some(p)=self.0.source_request.as_mut(){p.invalidate_signing()}
  if let Some(c)=self.0.custody.as_mut(){c.unknown=true}
  Ok(())
 }
 pub(crate)fn sign_first_device_original(&mut self)->Result<(),CustodyError>{
  self.captured()?;let public=self.public_pair()?;let transaction=*public.operation;
  let classic=public.classic;let pq=public.pq;
  let source_nonce=self.original_source_nonce()?;
  let original=self.0.source_request.as_mut().ok_or(CustodyError::Phase)?;
  original.check_original_signing_pair(&classic,&pq,&transaction)?;
  // These are disjoint fields in the SAME original reservation. No second
  // actor, whole-loan shared borrow, pointer qualifier or lease reconstruction.
  let mut parts=original.signing_parts(&classic,&pq,&source_nonce)?;
  let custody=self.0.custody.as_mut().ok_or(CustodyError::Phase)?;
  paired_proof::sign_original_pairs(&mut parts,custody,&mut self.0.type4_attempts,&transaction,&classic,&pq)
 }
}


#[cfg(feature="abi5-final-native-link")]
impl RecoveryLoan<'_>{
 // Same loan, same original facts, no sign/enter/acquire. Output callback only
 // constructs public JNI arrays; it may NOT perform Java callbacks/reentry.
 pub(crate)fn with_first_device_signatures<R>(&mut self,output:impl FnOnce(&paired_proof::FirstDeviceSignatureView<'_>)->Result<R,CustodyError>)->Result<R,CustodyError>{
  self.captured()?;let public=self.public_pair()?;let transaction=*public.operation;let classic=public.classic;let pq=public.pq;
  let original=self.0.source_request.as_mut().ok_or(CustodyError::Phase)?;
  let parts=original.retained_signing_parts()?;
  let custody=self.0.custody.as_mut().ok_or(CustodyError::Phase)?;
  let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||{
   let held=paired_proof::observe_original_pairs(&parts,custody,&self.0.type4_attempts,&transaction,&classic,&pq)?;
   let raw=parts.input.bootstrap_raw()?;
   let view=paired_proof::FirstDeviceSignatureView::borrowed(&held,&transaction,raw.nonce,parts.issuer,parts.target);
   let result=output(&view)?;
   parts.guard.current(&parts.input).map_err(|_|CustodyError::Unknown)?;
   Ok(result)
  }));
  match result{Ok(Ok(v))=>Ok(v),Ok(Err(e))=>{parts.guard.invalidate();custody.unknown=true;Err(e)},Err(p)=>{parts.guard.invalidate();custody.unknown=true;std::panic::resume_unwind(p)}}
 }
 pub(crate)fn recheck_first_device_signatures(&mut self)->Result<(),CustodyError>{self.with_first_device_signatures(|_|Ok(()))}
}

