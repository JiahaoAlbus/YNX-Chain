//! Real read-only product/native bridge entry, NOT a messaging facade or grant.
//! No owner/secret/handle/JSON pointer is returned. No old protocol fallback.
use crate::{open_production,OperationError,RequiredProvider};
const ABI:u32=1;
const REQUIRED:u32=1;
const NOT_ADMITTED:u32=2;
fn required_mask(providers:&[RequiredProvider;4])->u32{
 providers.iter().fold(0,|bits,p|bits|match p{
  RequiredProvider::NativeDeviceAuthorityV1=>1,
  RequiredProvider::TrustedRevocationCheckpointV1=>2,
  RequiredProvider::ProtectedAtomicSessionInboxOutboxCommitV1=>4,
  RequiredProvider::SourceBoundDurableObserverProvenanceV1=>8,
 })
}
// The only unsafe allowance is versioned C symbol export, no unsafe body or
// callback/pointer construction. These scalar diagnostics cannot issue trust.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
pub extern "C" fn ynx_social_crypto_engine_abi_version_v1()->u32{ABI}
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
pub extern "C" fn ynx_social_crypto_engine_probe_v1()->u32{
 match open_production(){Err(OperationError::Required(_))=>REQUIRED,_=>NOT_ADMITTED}
}
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
pub extern "C" fn ynx_social_crypto_engine_required_providers_v1()->u32{
 match open_production(){Err(OperationError::Required(providers))=>required_mask(&providers),_=>u32::MAX}
}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn r30_product_entry_actual_core_refuses_without_roots(){
  assert!(matches!(open_production(),Err(OperationError::Required(_))));
  assert_eq!(ynx_social_crypto_engine_probe_v1(),REQUIRED);
 }
 #[test]fn r30_product_entry_diagnostic_mask_matches_actual_required_list(){
  let Err(OperationError::Required(p))=open_production()else{panic!("normal source unexpectedly admitted")};
  assert_eq!(ynx_social_crypto_engine_required_providers_v1(),required_mask(&p));assert_eq!(required_mask(&p),15);
 }
 #[test]fn r30_product_entry_abi_is_not_message_or_authority_handle(){
  assert_eq!(ynx_social_crypto_engine_abi_version_v1(),1);assert_ne!(ynx_social_crypto_engine_probe_v1(),0);
 }
}
