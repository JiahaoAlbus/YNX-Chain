//! Private bounded cleanup custody, NOT a production actor/issuer factory.
//! Slots are admitted before effects; operations never own detachable capsules.
//! Forced destruction aborts, while explicit shutdown returns the SAME custody.
use super::{SourceStoreBorrow,SourceCleanupOwner,Disposition};
use std::{marker::PhantomData,rc::Rc,thread::{self,ThreadId},sync::atomic::{AtomicU64,Ordering}};
const MAX:usize=32;
static NEXT:AtomicU64=AtomicU64::new(1);
#[derive(Debug,Clone,Copy,PartialEq,Eq)]enum Error{Capacity,Allocation,Thread,Stale,Duplicate,Bound,Unresolved,IdentityExhausted,Closing,NoFailure}
#[derive(Clone,Copy)]struct Ticket{actor:u64,index:usize,generation:u64}
enum State<'s>{Vacant,Reserved(Option<&'s mut SourceStoreBorrow>),Held(SourceCleanupOwner<'s>)}
struct Slot<'s>{generation:u64,state:State<'s>}
struct Quarantine<'s>{id:u64,thread:ThreadId,slots:Vec<Slot<'s>>,closing:bool,actor:PhantomData<Rc<()>>}
struct Operation<'a,'s>{registry:&'a mut Quarantine<'s>,ticket:Ticket}
fn check_thread(expected:ThreadId)->Result<(),Error>{if thread::current().id()==expected{Ok(())}else{Err(Error::Thread)}}
impl<'s> Quarantine<'s>{
 fn try_new(capacity:usize)->Result<Self,Error>{Self::allocate(capacity,false)}
 // Injection is confined to cfg(test); normal cannot select allocation failure.
 fn allocate(capacity:usize,#[cfg(test)]fail_allocation:bool,#[cfg(not(test))]_unused:bool)->Result<Self,Error>{
  if capacity==0||capacity>MAX{return Err(Error::Capacity)}
  let mut slots=Vec::new();
  #[cfg(test)]if fail_allocation{slots.try_reserve_exact(usize::MAX).map_err(|_|Error::Allocation)?;}
  slots.try_reserve_exact(capacity).map_err(|_|Error::Allocation)?;
  for _ in 0..capacity{slots.push(Slot{generation:0,state:State::Vacant});}
  let id=NEXT.fetch_update(Ordering::Relaxed,Ordering::Relaxed,|v|v.checked_add(1)).map_err(|_|Error::IdentityExhausted)?;
  Ok(Self{id,thread:thread::current().id(),slots,closing:false,actor:PhantomData})
 }
 fn reserve(&mut self)->Result<Ticket,Error>{
  check_thread(self.thread)?;if self.closing{return Err(Error::Closing)}
  let (index,slot)=self.slots.iter_mut().enumerate().find(|(_,s)|matches!(s.state,State::Vacant)).ok_or(Error::Capacity)?;
  let generation=slot.generation.checked_add(1).ok_or(Error::IdentityExhausted)?;
  slot.generation=generation;slot.state=State::Reserved(None);
  Ok(Ticket{actor:self.id,index,generation})
 }
 fn slot(&mut self,t:Ticket)->Result<&mut Slot<'s>,Error>{
  check_thread(self.thread)?;
  if t.actor!=self.id{return Err(Error::Stale)}
  let s=self.slots.get_mut(t.index).ok_or(Error::Stale)?;
  if s.generation!=t.generation||matches!(s.state,State::Vacant){return Err(Error::Stale)}Ok(s)
 }
 fn operation(&mut self,t:Ticket)->Result<Operation<'_,'s>,Error>{
  let closing=self.closing;let s=self.slot(t)?;
  if closing&&!matches!(s.state,State::Held(_)){return Err(Error::Closing)}
  Ok(Operation{registry:self,ticket:t})
 }
 fn cancel_unbound(&mut self,t:Ticket)->Result<(),Error>{let s=self.slot(t)?;if !matches!(s.state,State::Reserved(None)){return Err(Error::Bound)}s.state=State::Vacant;Ok(())}
 fn retire(&mut self,t:Ticket)->Result<Disposition,Error>{
  let s=self.slot(t)?;
  let report=match &mut s.state{State::Held(o) if o.fully_released()=>o.retry(),_=>return Err(Error::Unresolved)};
  s.state=State::Vacant;Ok(report)
 }
 fn shutdown(mut self)->Result<(),Self>{
  // Irreversible local closing state: no new or pre-reserved unbound effect.
  self.closing=true;
  if check_thread(self.thread).is_err()||self.slots.iter().any(|s|!matches!(s.state,State::Vacant)){Err(self)}else{Ok(())}
 }
}
impl<'a,'s> Operation<'a,'s>{
 // Normal source descriptor has no constructor. This is custody, not admission.
 // Rejection returns the FULL original exclusive borrow; no pointer exposure.
 fn bind(&mut self,source:&'s mut SourceStoreBorrow)->Result<(),(Error,&'s mut SourceStoreBorrow)>{
  if self.registry.closing{return Err((Error::Closing,source))}
  match self.registry.slot(self.ticket){Ok(s)=>match &mut s.state{State::Reserved(x) if x.is_none()=>{*x=Some(source);Ok(())},_=>Err((Error::Duplicate,source))},Err(e)=>Err((e,source))}
 }
 fn failed_source(&mut self,primary:i32)->Result<(),Error>{
  if primary==0{return Err(Error::NoFailure)}
  let s=self.registry.slot(self.ticket)?;
  match &mut s.state{State::Reserved(x)=>{let source=x.take().ok_or(Error::Bound)?;
   // Original exclusive source borrow, no synthetic proof or C handle cast.
   s.state=State::Held(unsafe{SourceCleanupOwner::from_failed_source(source,primary)});Ok(())},_=>Err(Error::Duplicate)}
 }
 fn retry(&mut self)->Result<Disposition,Error>{match &mut self.registry.slot(self.ticket)?.state{State::Held(o)=>Ok(o.retry()),_=>Err(Error::Bound)}}
}
impl Drop for Operation<'_,'_>{fn drop(&mut self){
 // An interrupted bound operation is conservatively UNKNOWN. This transfers
 // ownership into the already allocated slot, and invokes NO foreign function.
 let s=match self.registry.slot(self.ticket){Ok(s)=>s,Err(_)=>std::process::abort()};
 if let State::Reserved(x)=&mut s.state{if let Some(source)=x.take(){s.state=State::Held(unsafe{SourceCleanupOwner::from_failed_source(source,0)});}}
}}
impl Drop for Quarantine<'_>{fn drop(&mut self){
 // Explicit shutdown refuses while any bound/pending owner remains. Rust Drop
 // cannot return custody; forced destruction is fail-stop, not local rollback,
 // leak, or a durable reconciliation receipt. Process-death recovery REQUIRED.
 if self.slots.iter().any(|s|match &s.state{State::Reserved(Some(_))=>true,State::Held(o)=>!o.fully_released(),_=>false}){std::process::abort();}
}}
#[cfg(all(test,veil_source_fixture))]mod controls;
#[cfg(all(test,veil_source_fixture))]mod repair_controls;
