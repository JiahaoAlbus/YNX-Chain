//! Same original controller product observation/routing. Never an auth factory.
#![allow(unsafe_code)]
use super::*;
use jni::objects::JByteArray;
const MAX_VIEW:usize=16384;
const STALE:i32=80;
#[derive(Default)]struct Views{epoch:i64,previous:Option<Vec<u8>>,next:i64,listeners:[Option<i64>;16]}
thread_local!{static VIEWS:RefCell<Views>=RefCell::new(Views::default());}
#[derive(serde::Serialize)]#[serde(untagged)]enum AuthorizedProjection{Missing(&'static str),#[cfg(feature="abi5-final-native-link")]Session(crate::staging::platform::PersistentMessageProjection)}
#[derive(serde::Serialize)]struct ReadModel<T>{version:u32,owner_status:i32,closed:bool,inventory:T,authorized_projection:AuthorizedProjection,#[serde(skip_serializing_if="Option::is_none")]accepted_device:Option<crate::message_evidence::AcceptedDeviceProjection>}
fn current()->Result<(i64,Vec<u8>),i32>{
 thread_check(false)?;
 let bytes=LOCAL.with(|cell|{
  let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;let owner=local.as_mut().ok_or(NOT_OPEN)?;
  // A device observation is available only under actual independent current.
  // It does not substitute for the message-purpose/protected session owner.
  let mut accepted_device=None;let mut authorized_projection=AuthorizedProjection::Missing("not-supplied");
  #[cfg(feature="abi5-final-native-link")]
  if !owner.closed&&!matches!(owner_status(owner),16|PANIC_RETAINED){
   if let Some(session)=owner.message_session.as_ref(){
    match session.public_projection(){Ok(p)=>authorized_projection=AuthorizedProjection::Session(p),Err(error)=>{let code=device_owner_error(&error);if code==16||code==PANIC_RETAINED{owner.status=code;owner.exit=ExitEligibility::Missing;}return Err(code)}}
   }
   if let Some(device)=owner.accepted_device.as_ref(){
    match device.public_projection(){Ok(p)=>accepted_device=Some(p),Err(error)=>{let code=device_owner_error(&error);if code==16||code==PANIC_RETAINED{owner.status=code;owner.exit=ExitEligibility::Missing;}return Err(code)}}
   }
  }
  let inventory=owner.controller.product_inventory_view().map_err(controller_error)?;
  serde_json::to_vec(&ReadModel{version:1,owner_status:owner_status(owner),closed:owner.closed,inventory,authorized_projection,accepted_device}).map_err(|_|20)
 })?;
 if bytes.len()>MAX_VIEW{return Err(20)}
 VIEWS.with(|cell|{let mut views=cell.try_borrow_mut().map_err(|_|BUSY)?;
  if views.previous.as_ref()!=Some(&bytes){views.epoch=views.epoch.checked_add(1).ok_or(20)?;views.previous=Some(bytes.clone());}
  Ok((views.epoch,bytes))
 })
}
fn subscribe()->Result<i64,i32>{
 current()?;
 VIEWS.with(|cell|{let mut v=cell.try_borrow_mut().map_err(|_|BUSY)?;let slot=v.listeners.iter().position(Option::is_none).ok_or(20)?;v.next=v.next.checked_add(1).ok_or(20)?;let id=v.next;v.listeners[slot]=Some(id);Ok(id)})
}
fn poll(token:i64,after:i64)->Result<i64,i32>{
 let(epoch,_)=current()?;
 VIEWS.with(|cell|{let v=cell.try_borrow().map_err(|_|BUSY)?;if token<=0||!v.listeners.contains(&Some(token)){return Err(27)}if after<0||after>epoch{return Err(STALE)}Ok(if epoch>after{epoch}else{0})})
}
fn unsubscribe(token:i64)->Result<(),i32>{
 thread_check(false)?;
 VIEWS.with(|cell|{let mut v=cell.try_borrow_mut().map_err(|_|BUSY)?;let i=v.listeners.iter().position(|s|*s==Some(token)).filter(|_|token>0).ok_or(27)?;v.listeners[i]=None;Ok(())})
}
fn signed(f:impl FnOnce()->Result<i64,i32>)->i64{let mut out=0;let code=boundary(||match f(){Ok(v)=>{out=v;0},Err(e)=>e});if code==0{out}else{-(code as i64)}}
unsafe fn read(env_raw:*mut jni::sys::JNIEnv,out_raw:jni::sys::jbyteArray)->Result<i64,i32>{
 let(epoch,bytes)=current()?;
 if env_raw.is_null()||out_raw.is_null(){return Err(32)}
 let mut env=unsafe{jni::EnvUnowned::from_raw(env_raw)};
 let result=env.with_env_no_catch(|env|->jni::errors::Result<Result<i64,i32>>{
  if env.exception_check(){return Ok(Err(32))}
  let out=unsafe{JByteArray::from_raw(env,out_raw)};
  if env.get_array_length(&out)?!=MAX_VIEW as i32{return Ok(Err(32))}
  // Epoch prefixes the JSON as an 8-byte big-endian integer; atomically one
  // captured model, no second query to pair an epoch with another snapshot.
  if bytes.len()+8>MAX_VIEW{return Ok(Err(20))}
  let now_epoch=match current(){Ok((value,_))=>value,Err(code)=>return Ok(Err(code))};if now_epoch!=epoch{return Ok(Err(STALE))}
  let mut encoded=Vec::<i8>::new();encoded.try_reserve_exact(bytes.len()+8).map_err(|_|jni::errors::Error::NullPtr("product projection allocation"))?;
  encoded.extend(epoch.to_be_bytes().iter().map(|v|*v as i8));encoded.extend(bytes.iter().map(|v|*v as i8));
  env.set_byte_array_region(&out,0,&encoded)?;Ok(Ok(encoded.len()as i64))
 }).into_outcome();
 match result{jni::Outcome::Ok(v)=>v,jni::Outcome::Err(_)=>Err(32),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
unsafe fn execute(env:*mut jni::sys::JNIEnv,epoch:i64,action:i32,selector:i64,input:jni::sys::jbyteArray)->Result<i64,i32>{
 if current()?.0!=epoch{return Err(STALE)}
 let class=std::ptr::null_mut();
 let code=match action{
  1=>{#[cfg(feature="abi5-final-native-link")]if !input.is_null(){return unsafe{begin_persistent_message_jni(env,input)}}let result=Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeAcquireMessageOperation(env,class);return if result>0{Ok(result)}else{Err((-result)as i32)}},
  2=>Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativePrepareSend(env,class,selector,input),
  3=>Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeAdvanceMessage(env,class,selector),
  4=>Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativePrepareReceive(env,class,selector,input),
  _=>return Err(32),
 };
 // Native messages keep all original validation/route/device/source gates.
 // Caller epoch/selector never constructs a capability or claims delivery.
 if code==0||code==30{Ok(code as i64)}else{Err(code)}
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeProductPortsAbiVersion(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i32{boundary(||1)}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeReadProductSnapshot(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,out:jni::sys::jbyteArray)->i64{signed(||unsafe{read(e,out)})}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeSubscribeProductInvalidation(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i64{signed(subscribe)}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativePollProductInvalidation(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,token:i64,after:i64)->i64{signed(||poll(token,after))}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeUnsubscribeProductInvalidation(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,token:i64)->i32{boundary(||unsubscribe(token).map(|_|0).unwrap_or_else(|e|e))}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeExecuteProduct(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,epoch:i64,action:i32,selector:i64,input:jni::sys::jbyteArray)->i64{signed(||unsafe{execute(e,epoch,action,selector,input)})}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeReceiveOpaqueEvent(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,epoch:i64,selector:i64,input:jni::sys::jbyteArray)->i64{signed(||unsafe{execute(e,epoch,4,selector,input)})}
#[cfg(test)]mod product_ports_controls{
 use super::*;
 #[test]fn product_ports_controls_same_owner_view_subscription_and_root_refusal(){std::thread::spawn(||{
  assert!(matches!(current(),Err(21)));assert!(LOCAL.with(|c|c.borrow().is_none()));
  assert_eq!(open(),1);let(epoch,bytes)=current().unwrap();assert!(epoch>0);
  let view:serde_json::Value=serde_json::from_slice(&bytes).unwrap();assert_eq!(view["inventory"]["engine_present"],false);assert_eq!(view["inventory"]["open_attempted"],true);
  let token=subscribe().unwrap();assert_eq!(poll(token,epoch),Ok(0));
  assert_eq!(unsafe{execute(std::ptr::null_mut(),epoch-1,1,0,std::ptr::null_mut())},Err(STALE));
  assert_eq!(unsafe{execute(std::ptr::null_mut(),epoch,1,0,std::ptr::null_mut())},Err(1));
  LOCAL.with(|cell|cell.borrow_mut().as_mut().unwrap().controller.block_new_operations());
  let newer=poll(token,epoch).unwrap();assert!(newer>epoch);assert_eq!(poll(token,newer),Ok(0));
  for _ in 1..16{subscribe().unwrap();}assert_eq!(subscribe(),Err(20));
  unsubscribe(token).unwrap();assert_eq!(poll(token,newer),Err(27));assert!(subscribe().unwrap()>token);
  assert_eq!(close(),24);assert_eq!(release_no_effect_for_exit(),36);assert!(current().is_err());
 }).join().unwrap();}
}

// Additive output transport over the SAME consumed pending. No input can open
// an engine/session or manufacture delivery, route, currentness or permission.
const MAX_OUTPUT: usize = crate::product_message::HEADER + crate::product_message::MAX_CIPHER;
fn output_epoch(expected:i64,actual:i64)->Result<(),i32>{if expected<=0||actual<=0||expected!=actual{Err(STALE)}else{Ok(())}}
fn output_capacity(capacity: usize, length: usize) -> Result<(), i32> {
 if length < crate::product_message::HEADER || length > MAX_OUTPUT || capacity < length || capacity > MAX_OUTPUT { Err(32) } else { Ok(()) }
}
fn copy_output(epoch: i64, selector: i64) -> Result<zeroize::Zeroizing<Vec<u8>>, i32> {
 output_epoch(epoch,current()?.0)?;
 let bytes=LOCAL.with(|cell|{
  let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;
  let owner=local.as_mut().ok_or(NOT_OPEN)?;
  let status=owner_status(owner); if status != 0 { return Err(status) }
  match owner.controller.copy_message_output(selector) {
   Ok(bytes)=>Ok(bytes), Err(error)=>{
    let code=controller_error(error);
    if code==16||code==PANIC_RETAINED { owner.status=code;owner.exit=ExitEligibility::Missing; }
    Err(code)
   }
  }
 })?;
 output_epoch(epoch,current()?.0)?;
 Ok(bytes)
}
unsafe fn copy_output_jni(raw_env:*mut jni::sys::JNIEnv,epoch:i64,selector:i64,raw_out:jni::sys::jbyteArray)->Result<i64,i32>{
 if raw_env.is_null()||raw_out.is_null(){return Err(32)}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(raw_env)};
 let result=unowned.with_env_no_catch(|env|->jni::errors::Result<Result<i64,i32>>{
  if env.exception_check(){return Ok(Err(32))}
  let out=unsafe{JByteArray::from_raw(env,raw_out)};
  let capacity=env.get_array_length(&out)?;
  if capacity<0||capacity as usize>MAX_OUTPUT{return Ok(Err(32))}
  let bytes=match copy_output(epoch,selector){Ok(bytes)=>bytes,Err(code)=>return Ok(Err(code))};
  if let Err(code)=output_capacity(capacity as usize,bytes.len()){return Ok(Err(code))}
  let mut signed=zeroize::Zeroizing::new(Vec::<i8>::new());
  signed.try_reserve_exact(bytes.len()).map_err(|_|jni::errors::Error::NullPtr("message output allocation"))?;
  signed.extend(bytes.iter().map(|b|*b as i8));
  // Final same-original read validation before the only Java output effect.
  // A second retained read does not re-encrypt or consume another receipt.
  let final_bytes=match copy_output(epoch,selector){Ok(bytes)=>bytes,Err(code)=>return Ok(Err(code))};
  if final_bytes.as_slice()!=bytes.as_slice(){return Ok(Err(19))}
  env.set_byte_array_region(&out,0,&signed)?;
  if env.exception_check(){return Ok(Err(32))}
  Ok(Ok(bytes.len() as i64))
 }).into_outcome();
 match result{jni::Outcome::Ok(v)=>v,jni::Outcome::Err(_)=>Err(32),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
fn retire_output(epoch:i64,selector:i64)->Result<(),i32>{
 output_epoch(epoch,current()?.0)?;
 LOCAL.with(|cell|{
  let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;
  let owner=local.as_mut().ok_or(NOT_OPEN)?;
  let status=owner_status(owner);if status!=0{return Err(status)}
  match owner.controller.retire_message_output(selector){Ok(())=>{#[cfg(feature="abi5-final-native-link")]owner.controller.close_persistent_operation().map_err(|error|{let code=controller_error(error);if code==16||code==PANIC_RETAINED{owner.status=code;owner.exit=ExitEligibility::Missing;}code})?;Ok(())},Err(error)=>{
   let code=controller_error(error);if code==16||code==PANIC_RETAINED{owner.status=code;owner.exit=ExitEligibility::Missing;}Err(code)
  }}
 })
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeCopyMessageOutput(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,epoch:i64,selector:i64,out:jni::sys::jbyteArray)->i64{signed(||unsafe{copy_output_jni(e,epoch,selector,out)})}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeRetireMessageOutput(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,epoch:i64,selector:i64)->i32{boundary(||retire_output(epoch,selector).map(|_|0).unwrap_or_else(|code|code))}

// Software transport presence only; never root/session/device authorization.
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeMessageOutputAbiVersion(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i32{boundary(||1)}

// Additive bounded original PUBLIC registration delivery. Never authority.
fn install_enrollment_records(records:crate::message_enrollment::OriginalEnrollmentRecords)->Result<(),i32>{
 thread_check(false)?;
 LOCAL.with(|cell|{
  let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;
  let owner=local.as_mut().ok_or(NOT_OPEN)?;
  let status=owner_status(owner);if status==16||status==PANIC_RETAINED{return Err(status)}
  if owner.closed{return Err(CLOSED_NO_EFFECT)}
  if owner.enrollment_records.is_some()||owner.genesis.is_some()||owner.active_local_stage.is_some(){return Err(30)}
  let view=owner.controller.product_inventory_view().map_err(controller_error)?;
  let inventory=serde_json::to_value(&view).map_err(|_|20)?;
  // Refuse all pre-existing custody, not merely active message selectors.
  if view.engine_present||view.admission_closed||!inventory.get("entries").and_then(serde_json::Value::as_array).is_some_and(Vec::is_empty){return Err(30)}
  owner.enrollment_records=Some(records);Ok(())
 })
}
unsafe fn install_enrollment_jni(raw_env:*mut jni::sys::JNIEnv,raw_input:jni::sys::jbyteArray)->Result<(),i32>{
 thread_check(false)?;
 if raw_env.is_null()||raw_input.is_null(){return Err(32)}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(raw_env)};
 let result=unowned.with_env_no_catch(|env|->jni::errors::Result<Result<(),i32>>{
  if env.exception_check(){return Ok(Err(32))}
  let input=unsafe{JByteArray::from_raw(env,raw_input)};
  let size=env.get_array_length(&input)?;if !(1..=393216).contains(&size){return Ok(Err(32))}
  let raw=zeroize::Zeroizing::new(env.convert_byte_array(&input)?);
  if env.exception_check(){return Ok(Err(32))}
  let records=match crate::message_enrollment::OriginalEnrollmentRecords::parse(&raw){Ok(r)=>r,Err(_)=>return Ok(Err(32))};
  Ok(install_enrollment_records(records))
 }).into_outcome();
 match result{jni::Outcome::Ok(v)=>v,jni::Outcome::Err(_)=>Err(32),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeInstallMessageEnrollmentRecords(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,input:jni::sys::jbyteArray)->i32{boundary(||unsafe{install_enrollment_jni(e,input)}.map(|_|0).unwrap_or_else(|e|e))}

#[cfg(feature="abi5-final-native-link")]
fn device_owner_error(e:&crate::staging::platform::SourceOwnerError)->i32{use crate::staging::platform::SourceOwnerError as E;match e{E::Required=>4,E::Unknown=>16,E::Thread=>WRONG_THREAD,E::Association=>19,E::Capacity=>20,E::AbiInvariant=>PANIC_RETAINED,E::Foreign(_)=>16}}
#[cfg(feature="abi5-final-native-link")]
fn restore_device_records(records:crate::message_evidence::OriginalDeviceRecords)->Result<(),i32>{
 thread_check(false)?;
 LOCAL.with(|cell|{
  let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;let owner=local.as_mut().ok_or(NOT_OPEN)?;
  let code=owner_status(owner);if code==16||code==PANIC_RETAINED{return Err(code)}if owner.closed{return Err(CLOSED_NO_EFFECT)}
  if owner.accepted_device.is_some()||owner.message_session.is_some()||owner.active_local_stage.is_some(){return Err(30)}
  let selector=owner.genesis.as_ref().ok_or(43)?;
  let acquired={let mut native=owner.controller.local_recovery_loan(selector).map_err(controller_error)?;native.restore_accepted_device(records)};
  match acquired{
   Ok(device)=>{owner.accepted_device=Some(device);owner.exit=ExitEligibility::Missing;Ok(())},
   Err((error,retained))=>{let code=device_owner_error(&error);if let Some(device)=retained{owner.accepted_device=Some(device);owner.status=16;owner.exit=ExitEligibility::Missing;return Err(16)}if code==16||code==PANIC_RETAINED{owner.status=code;owner.exit=ExitEligibility::Missing;}Err(code)}
  }
 })
}
#[cfg(feature="abi5-final-native-link")]
unsafe fn restore_device_jni(e:*mut jni::sys::JNIEnv,input:jni::sys::jbyteArray)->Result<(),i32>{
 thread_check(false)?;if e.is_null()||input.is_null(){return Err(32)}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(e)};
 let result=unowned.with_env_no_catch(|env|->jni::errors::Result<Result<(),i32>>{
  if env.exception_check(){return Ok(Err(32))}let array=unsafe{JByteArray::from_raw(env,input)};
  if !(1..=393216).contains(&env.get_array_length(&array)?){return Ok(Err(32))}
  let bytes=zeroize::Zeroizing::new(env.convert_byte_array(&array)?);if env.exception_check(){return Ok(Err(32))}
  let records=match crate::message_evidence::OriginalDeviceRecords::parse(&bytes){Ok(r)=>r,Err(_)=>return Ok(Err(32))};
  Ok(restore_device_records(records))
 }).into_outcome();match result{jni::Outcome::Ok(v)=>v,jni::Outcome::Err(_)=>Err(32),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
#[cfg(feature="abi5-final-native-link")]
fn device_current()->Result<(),i32>{
 thread_check(false)?;LOCAL.with(|cell|{let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;let owner=local.as_mut().ok_or(NOT_OPEN)?;
  let code=owner_status(owner);if code==16||code==PANIC_RETAINED{return Err(code)}if owner.closed{return Err(CLOSED_NO_EFFECT)}let device=owner.accepted_device.as_ref().ok_or(4)?;
  match device.current(){Ok(())=>Ok(()),Err(error)=>{let code=device_owner_error(&error);if code==16||code==PANIC_RETAINED{owner.status=code;owner.exit=ExitEligibility::Missing;}Err(code)}}
 })
}
#[cfg(feature="abi5-final-native-link")]
fn release_device()->Result<(),i32>{
 thread_check(false)?;LOCAL.with(|cell|{let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;let owner=local.as_mut().ok_or(NOT_OPEN)?;
  let Some(device)=owner.accepted_device.as_mut()else{return Ok(())};
  match device.release(){Ok(())=>{owner.accepted_device.take();Ok(())},Err(error)=>{owner.status=16;owner.exit=ExitEligibility::Missing;Err(device_owner_error(&error))}}
 })
}
#[cfg(feature="abi5-final-native-link")]
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeAcquireAcceptedDevice(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,input:jni::sys::jbyteArray)->i32{boundary(||unsafe{restore_device_jni(e,input)}.map(|_|0).unwrap_or_else(|c|c))}
#[cfg(feature="abi5-final-native-link")]
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeRestoreAcceptedDevice(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,input:jni::sys::jbyteArray)->i32{boundary(||unsafe{restore_device_jni(e,input)}.map(|_|0).unwrap_or_else(|c|c))}
#[cfg(feature="abi5-final-native-link")]
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeAcceptedDeviceCurrent(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i32{boundary(||device_current().map(|_|0).unwrap_or_else(|c|c))}
#[cfg(feature="abi5-final-native-link")]
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeReleaseAcceptedDevice(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i32{boundary(||release_device().map(|_|0).unwrap_or_else(|c|c))}

#[cfg(feature="abi5-final-native-link")]
fn open_persistent_message(input:crate::message_evidence::MessageOpenInput)->Result<(),i32>{
 thread_check(false)?;LOCAL.with(|cell|{let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;let owner=local.as_mut().ok_or(NOT_OPEN)?;
 let code=owner_status(owner);if code==16||code==PANIC_RETAINED{return Err(code)}if owner.closed{return Err(CLOSED_NO_EFFECT)}if owner.message_session.is_some()||owner.active_local_stage.is_some(){return Err(30)}
 let enrollment=owner.enrollment_records.as_ref().ok_or(4)?;let device=owner.accepted_device.take().ok_or(4)?;
 match crate::staging::platform::MessageSessionOwner::acquire(device,&input,enrollment){
  Ok(session)=>{owner.message_session=Some(session);if owner.status==1{owner.status=0;}owner.exit=ExitEligibility::Missing;Ok(())},
  Err(failure)=>{let code=device_owner_error(&failure.error);owner.accepted_device=failure.device;owner.message_session=failure.session;
   if owner.message_session.is_some()||code==16||code==PANIC_RETAINED{owner.status=if code==PANIC_RETAINED{code}else{16};owner.exit=ExitEligibility::Missing;return Err(owner.status)}Err(code)}
 }
 })
}
#[cfg(feature="abi5-final-native-link")]
unsafe fn open_persistent_message_jni(e:*mut jni::sys::JNIEnv,input:jni::sys::jbyteArray)->Result<(),i32>{
 thread_check(false)?;if e.is_null()||input.is_null(){return Err(32)}let mut unowned=unsafe{jni::EnvUnowned::from_raw(e)};
 let result=unowned.with_env_no_catch(|env|->jni::errors::Result<Result<(),i32>>{if env.exception_check(){return Ok(Err(32))}let array=unsafe{JByteArray::from_raw(env,input)};if !(1..=393216).contains(&env.get_array_length(&array)?){return Ok(Err(32))}let bytes=zeroize::Zeroizing::new(env.convert_byte_array(&array)?);if env.exception_check(){return Ok(Err(32))}let input=match crate::message_evidence::MessageOpenInput::parse(&bytes){Ok(v)=>v,Err(_)=>return Ok(Err(32))};Ok(open_persistent_message(input))}).into_outcome();match result{jni::Outcome::Ok(v)=>v,jni::Outcome::Err(_)=>Err(32),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
#[cfg(feature="abi5-final-native-link")]
fn persistent_message_current()->Result<(),i32>{thread_check(false)?;LOCAL.with(|cell|{let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;let owner=local.as_mut().ok_or(NOT_OPEN)?;let code=owner_status(owner);if code==16||code==PANIC_RETAINED{return Err(code)}if owner.closed{return Err(CLOSED_NO_EFFECT)}let session=owner.message_session.as_ref().ok_or(4)?;match session.current(){Ok(())=>Ok(()),Err(error)=>{let code=device_owner_error(&error);if code==16||code==PANIC_RETAINED{owner.status=code;owner.exit=ExitEligibility::Missing;}Err(code)}}})}
#[cfg(feature="abi5-final-native-link")]
fn close_persistent_message()->Result<(),i32>{thread_check(false)?;LOCAL.with(|cell|{let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;let owner=local.as_mut().ok_or(NOT_OPEN)?;if let Err(error)=owner.controller.close_persistent_operation(){let code=controller_error(error);if code==16||code==25{owner.status=code;owner.exit=ExitEligibility::Missing;}return Err(code)}let Some(session)=owner.message_session.as_mut()else{return Ok(())};match session.release(){Ok(())=>{owner.message_session.take();Ok(())},Err(error)=>{owner.status=16;owner.exit=ExitEligibility::Missing;Err(device_owner_error(&error))}}})}
#[cfg(feature="abi5-final-native-link")]
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeOpenMessageSession(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,input:jni::sys::jbyteArray)->i32{boundary(||unsafe{open_persistent_message_jni(e,input)}.map(|_|0).unwrap_or_else(|e|e))}
#[cfg(feature="abi5-final-native-link")]
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeMessageSessionCurrent(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i32{boundary(||persistent_message_current().map(|_|0).unwrap_or_else(|e|e))}
#[cfg(feature="abi5-final-native-link")]
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeCloseMessageSession(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i32{boundary(||close_persistent_message().map(|_|0).unwrap_or_else(|e|e))}

// One normal worker call binds the actual original YNXM before source acquire.
// UI framing/selector is untrusted; selected destination stays Native-owned.
#[cfg(feature="abi5-final-native-link")]unsafe fn begin_persistent_message_jni(e:*mut jni::sys::JNIEnv,input:jni::sys::jbyteArray)->Result<i64,i32>{
 thread_check(false)?;if e.is_null()||input.is_null(){return Err(32)}let mut unowned=unsafe{jni::EnvUnowned::from_raw(e)};
 let result=unowned.with_env_no_catch(|env|->jni::errors::Result<Result<i64,i32>>{
  if env.exception_check(){return Ok(Err(32))}let array=unsafe{JByteArray::from_raw(env,input)};let size=env.get_array_length(&array)?;if size<crate::product_message::HEADER as i32||size as usize>crate::product_message::MAX_INPUT{return Ok(Err(32))}
  let raw=zeroize::Zeroizing::new(env.convert_byte_array(&array)?);if env.exception_check(){return Ok(Err(32))}let direction=match raw.get(5){Some(1)=>crate::product_message::Direction::Send,Some(2)=>crate::product_message::Direction::Receive,_=>return Ok(Err(32))};let input=match crate::product_message::MessageInput::decode(raw,direction){Ok(v)=>v,Err(_)=>return Ok(Err(32))};
  Ok(LOCAL.with(|cell|{let mut local=cell.try_borrow_mut().map_err(|_|BUSY)?;let owner=local.as_mut().ok_or(NOT_OPEN)?;let code=owner_status(owner);if code!=0{return Err(code)}if owner.closed{return Err(CLOSED_NO_EFFECT)}let session=owner.message_session.as_ref().ok_or(4)?;
   match owner.controller.begin_persistent_message(session,input){Ok(selector)=>{owner.exit=ExitEligibility::Missing;Ok(selector.routing_id()as i64)},Err(error)=>{let code=controller_error(error);if code==16||code==PANIC_RETAINED{owner.status=code;owner.exit=ExitEligibility::Missing;}Err(code)}}
  }))
 }).into_outcome();match result{jni::Outcome::Ok(v)=>v,jni::Outcome::Err(_)=>Err(32),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
#[cfg(feature="abi5-final-native-link")]#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeBeginMessageOperation(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,input:jni::sys::jbyteArray)->i64{signed(||unsafe{begin_persistent_message_jni(e,input)})}
