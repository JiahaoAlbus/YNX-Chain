//! PRIVATE v2 OriginalSource/Identity Native-purpose plane. No wire export,
//! signing API, public DTO constructor or caller-installable approving callback.
//! Root/profile opt-in AND authenticated policy originals are necessary;
//! this is not the v1 provenance table and not an enforcing storage capability.
use super::{Error,Envelope,Pair,FixedStartupSourceEvidence,approved_profiles,canonical,verify_envelope};
use serde::{Serialize,Deserialize};
use sha2::{Digest,Sha256};
use std::{cell::{Cell,RefCell},collections::HashMap,marker::PhantomData,rc::Rc,thread::{self,ThreadId},time::{Duration,Instant}};

#[derive(Debug,Clone,Copy,PartialEq,Eq,Serialize,Deserialize)]
pub(crate) enum CorePurposeV2 { FirstDeviceCore,MessageCore }
#[derive(Debug,Clone,Copy,PartialEq,Eq)]
pub(crate) enum CoreOperationV2 { InitializeStorage,SealRecord,ReadRecord,WriteRecord,QueueNonce,CompareAndSwap }
impl CoreOperationV2 {fn bit(self)->u32{1u32<<(self as u32)}}
// Diagnostics only; these values never authenticate a capability or an owner.
pub(crate) struct CoreOwnerDiagnosticV2{pub(crate) first_cause:Option<Error>,pub(crate) uncertain:bool,pub(crate) retired:bool,pub(crate) cleanup_complete:bool,pub(crate) children:usize}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields)]
struct PolicyOriginalV2 {
 version:u32,plane:String,bootstrap:String,root:[u8;32],registration:[u8;32],source:[u8;32],namespace:[u8;32],
 account:[u8;32],device:[u8;32],association:[u8;32],storage_generation:u64,key_use:String,
 first_device_operations:u32,message_operations:u32,issuer_credential:[u8;32],anchor_credential:[u8;32],
 generation:u64,not_before_ms:i64,expires_ms:i64,max_current_age_ms:i64,
}
#[derive(Serialize,Deserialize,PartialEq,Eq)]#[serde(deny_unknown_fields)]
struct CurrentOriginalV2 {
 version:u32,plane:String,policy:[u8;32],generation:u64,head:[u8;32],floor:u64,revoked:bool,
 issued_ms:i64,expires_ms:i64,accepted_relation:Option<[u8;32]>,
}
fn digest(b:&[u8])->[u8;32]{Sha256::digest(b).into()}
fn policy_shape(p:&PolicyOriginalV2)->Result<(),Error>{
 if p.version!=2||p.plane!="OriginalSourceIdentity.NativeCore"||p.key_use!="selected-storage-record-head-journal-queue-nonce-seal-CAS"
  ||p.generation==0||p.storage_generation==0||p.not_before_ms<0||p.expires_ms<=p.not_before_ms
  ||p.max_current_age_ms<=0||p.max_current_age_ms>30000||p.first_device_operations==0
  ||p.first_device_operations&!63!=0||p.message_operations==0||p.message_operations&!62!=0
  ||[p.root,p.registration,p.source,p.namespace,p.account,p.device,p.association,p.issuer_credential,p.anchor_credential].iter().any(|x|*x==[0;32]){return Err(Error::Binding)}Ok(())
}
fn check_window(now:i64,not_before:i64,expires:i64)->Result<(),Error>{
 if not_before<0||expires<=not_before||now<not_before||now>=expires{Err(Error::Window)}else{Ok(())}
}
// Matching input only. Private rights never arise from this struct alone.
pub(crate) struct CoreOriginalIntakeV2<'a>{
 pub(crate) originals:[&'a[u8];6],pub(crate) classic:&'a[u8;33],pub(crate) pq:&'a[u8],
 pub(crate) account_original:&'a[u8],pub(crate) association_original:&'a[u8],
 pub(crate) operation_original:&'a[u8],pub(crate) operation:CoreOperationV2,
 // M1 supplies the explicit low-level set for one recognized high-level intent.
 // The set is frozen at issuance, never broadened by later storage gates.
 pub(crate) requested_operations:u32,
 pub(crate) accepted_relation_original:Option<&'a[u8]>,
 pub(crate) storage_generation:u64,pub(crate) monotonic_deadline:Instant,
}

// Recognized native owner; construction is only through the authenticated
// original-plane intake below. Current originals cannot be replaced by flags.
pub(crate) struct NativePurposeIdentityOwnerV2{
 source:Rc<FixedStartupSourceEvidence>,policy:PolicyOriginalV2,approval:Box<[u8]>,
 issuer_current:RefCell<Box<[u8]>>,anchor_current:RefCell<Box<[u8]>>,current:RefCell<CurrentOriginalV2>,
 thread:ThreadId,wall_floor:Cell<i64>,generation_floor:Cell<u64>,counter_floor:Cell<u64>,
 observed:Cell<Instant>,budget:Cell<Duration>,retired:Cell<bool>,unknown:Cell<bool>,first:RefCell<Option<Error>>,
 children:Cell<usize>,entered:RefCell<HashMap<[u8;32],Vec<Box<[u8]>>>>,operations:RefCell<HashMap<[u8;32],Rc<CoreOperationStateV2>>>,retained_bytes:Cell<usize>,close_selected:Cell<bool>,closed:Cell<bool>,local:PhantomData<Rc<()>>,
}
impl FixedStartupSourceEvidence {
 pub(crate) fn authenticate_native_purpose_v2(self:&Rc<Self>,approval:&[u8],issuer_current:&[u8],anchor_current:&[u8])->Result<NativePurposeIdentityOwnerV2,Error>{
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let profile=approved_profiles().iter().find(|p|p.bootstrap==self.selected_bootstrap).ok_or(Error::ProfileRequired)?;
  // Trusted release-owned opt-in is a separate authority operand. Even a
  // mathematically valid Source/admin/message-policy signature cannot opt in.
  let approved=profile.native_core_approval_original.ok_or(Error::ProfileRequired)?;
  if approval.is_empty()||approval.len()>65536||approval!=approved{return Err(Error::Binding)}
  let envelope:Envelope=canonical(approval,65536)?;
  // Existing OriginalSource verification suite/frame; no new signing domain.
  let body=verify_envelope(&envelope,"credential",&Pair{classic:profile.classic.into(),pq:profile.pq.into()})?;
  let policy:PolicyOriginalV2=canonical(&body,32768)?;policy_shape(&policy)?;
  if policy.bootstrap!=self.selected_bootstrap||policy.issuer_credential!=digest(&self.issuer_raw)||policy.anchor_credential!=digest(&self.anchor_raw){return Err(Error::Binding)}
  let now=super::now_ms()?;check_window(now,policy.not_before_ms,policy.expires_ms)?;
  let state=self.verify_native_current_v2(&policy,digest(approval),issuer_current,anchor_current,now)?;
  let owner=NativePurposeIdentityOwnerV2{source:Rc::clone(self),generation_floor:Cell::new(state.generation),counter_floor:Cell::new(state.floor),current:RefCell::new(state),policy,approval:approval.into(),issuer_current:RefCell::new(issuer_current.into()),anchor_current:RefCell::new(anchor_current.into()),thread:thread::current().id(),wall_floor:Cell::new(now),observed:Cell::new(Instant::now()),budget:Cell::new(Duration::ZERO),retired:Cell::new(false),unknown:Cell::new(false),first:RefCell::new(None),children:Cell::new(0),entered:RefCell::new(HashMap::new()),operations:RefCell::new(HashMap::new()),retained_bytes:Cell::new(0),close_selected:Cell::new(false),closed:Cell::new(false),local:PhantomData};
  owner.set_budget(now)?;owner.assert_current_v2()?;Ok(owner)
 }
 fn verify_native_current_v2(&self,p:&PolicyOriginalV2,policy_digest:[u8;32],issuer_raw:&[u8],anchor_raw:&[u8],now:i64)->Result<CurrentOriginalV2,Error>{
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;
  let i:Envelope=canonical(issuer_raw,65536)?;let a:Envelope=canonical(anchor_raw,65536)?;
  let ib=verify_envelope(&i,"record-issuer",&self.issuer.public)?;let ab=verify_envelope(&a,"record-anchor",&self.anchor.public)?;
  // Distinct approved domains must affirm EXACTLY the same original state.
  if ib!=ab{return Err(Error::Binding)}let current:CurrentOriginalV2=canonical(&ib,32768)?;
  check_window(now,current.issued_ms,current.expires_ms)?;
  if current.version!=2||current.plane!="OriginalSourceIdentity.NativeCore.Current"||current.policy!=policy_digest||current.generation!=p.generation
   ||current.head==[0;32]||current.revoked||current.expires_ms>p.expires_ms||current.expires_ms-current.issued_ms>p.max_current_age_ms
   ||current.accepted_relation==Some([0;32]){return Err(Error::Binding)}
  self.recheck_originals(&self.manifest,&self.issuer_raw,&self.anchor_raw)?;Ok(current)
 }
}
impl NativePurposeIdentityOwnerV2{
 fn latch(&self,e:Error)->Error{if self.first.borrow().is_none(){*self.first.borrow_mut()=Some(e);}self.unknown.set(true);self.first.borrow().as_ref().copied().unwrap_or(e)}
 pub(crate) fn unresolved_v2(&self)->bool{self.unknown.get()}
 pub(crate) fn diagnostic_v2(&self)->CoreOwnerDiagnosticV2{CoreOwnerDiagnosticV2{first_cause:*self.first.borrow(),uncertain:self.unknown.get(),retired:self.retired.get(),cleanup_complete:self.closed.get(),children:self.children.get()}}
 fn set_budget(&self,now:i64)->Result<(),Error>{let state=self.current.borrow();check_window(now,state.issued_ms,state.expires_ms)?;self.budget.set(Duration::from_millis((state.expires_ms-now)as u64));self.observed.set(Instant::now());Ok(())}
 pub(crate) fn assert_current_v2(&self)->Result<(),Error>{
  let result=(||{
   if self.thread!=thread::current().id()||self.retired.get()||self.unknown.get()||self.closed.get(){return Err(Error::Binding)}
   let now=super::now_ms()?;if now<self.wall_floor.get()||self.observed.get().elapsed()>=self.budget.get(){return Err(Error::Window)}
   check_window(now,self.policy.not_before_ms,self.policy.expires_ms)?;
   let state=self.source.verify_native_current_v2(&self.policy,digest(&self.approval),&self.issuer_current.borrow(),&self.anchor_current.borrow(),now)?;
   if state!=*self.current.borrow()||state.generation<self.generation_floor.get()||state.floor<self.counter_floor.get(){return Err(Error::Binding)}
   let after=super::now_ms()?;check_window(after,state.issued_ms,state.expires_ms)?;check_window(after,self.policy.not_before_ms,self.policy.expires_ms)?;
   if after<now||self.observed.get().elapsed()>=self.budget.get(){return Err(Error::Window)}self.wall_floor.set(after);Ok(())
  })();result.map_err(|e|self.latch(e))
 }
 // Privileged native owner refresh only: a new signed pair must be current,
 // same-policy/generation and nondecreasing floor. Existing child deadlines
 // are NEVER extended by refreshing the parent.
 pub(crate) fn refresh_current_v2(&mut self,issuer:&[u8],anchor:&[u8])->Result<(),Error>{
  self.assert_current_v2()?;let before=super::now_ms()?;
  let state=self.source.verify_native_current_v2(&self.policy,digest(&self.approval),issuer,anchor,before).map_err(|e|self.latch(e))?;
  if state.generation!=self.generation_floor.get()||state.floor<self.counter_floor.get(){return Err(self.latch(Error::Binding))}
  let after=super::now_ms()?;check_window(after,state.issued_ms,state.expires_ms).map_err(|e|self.latch(e))?;
  if after<before{return Err(self.latch(Error::Window))}
  self.counter_floor.set(state.floor);*self.issuer_current.borrow_mut()=issuer.into();*self.anchor_current.borrow_mut()=anchor.into();*self.current.borrow_mut()=state;
  self.wall_floor.set(after);self.set_budget(after)?;self.assert_current_v2()
 }
 fn match_intake(&self,purpose:CorePurposeV2,input:&CoreOriginalIntakeV2<'_>)->Result<(),Error>{
  self.assert_current_v2()?;
  if input.originals.iter().chain([&input.account_original,&input.association_original,&input.operation_original]).any(|b|b.is_empty()||b.len()>1048576)
   ||input.classic[0]!=5||input.pq.len()!=2592||input.storage_generation!=self.policy.storage_generation||Instant::now()>=input.monotonic_deadline{return Err(Error::Binding)}
  let p=&self.policy;
  for(raw,expected)in [(input.originals[0],p.root),(input.originals[1],p.registration),(input.originals[3],p.source),(input.originals[4],p.namespace),(input.account_original,p.account),(input.association_original,p.association)]{if digest(raw)!=expected{return Err(Error::Binding)}}
  let mut device=Sha256::new();device.update(input.classic);device.update(input.pq);if <[u8;32]>::from(device.finalize())!=p.device{return Err(Error::Binding)}
  let mask=match purpose{CorePurposeV2::FirstDeviceCore=>p.first_device_operations,CorePurposeV2::MessageCore=>p.message_operations};
  if input.requested_operations==0||input.requested_operations&!mask!=0||input.requested_operations&input.operation.bit()==0{return Err(Error::Binding)}
  let accepted=self.current.borrow().accepted_relation;
  if input.accepted_relation_original.is_some_and(|b|b.is_empty()||b.len()>65536){return Err(Error::Bounds)}
  if purpose==CorePurposeV2::MessageCore{
   let relation=input.accepted_relation_original.ok_or(Error::Binding)?;
   if relation.is_empty()||relation.len()>65536||accepted!=Some(digest(relation)){return Err(Error::Binding)}
  }
  self.assert_current_v2()
 }
 fn issue<'p>(&'p self,purpose:CorePurposeV2,input:&CoreOriginalIntakeV2<'_>)->Result<NativeCoreRightsV2<'p>,Error>{
  self.match_intake(purpose,input)?;let id=digest(input.operation_original);
  let budget=input.monotonic_deadline.saturating_duration_since(Instant::now());
  if budget.is_zero()||self.entered.borrow().contains_key(&id){return Err(Error::Binding)}
  if self.entered.borrow().len()>=4096||self.children.get()>=32{return Err(Error::Bounds)}
  let retain:Vec<Box<[u8]>>=input.originals.iter().copied().chain([input.account_original,input.association_original,input.operation_original]).chain(input.accepted_relation_original).map(Box::<[u8]>::from).collect();
  let bytes=retain.iter().map(|b|b.len()).sum::<usize>();let total=self.retained_bytes.get().checked_add(bytes).ok_or(Error::Bounds)?;if total>67108864{return Err(Error::Bounds)}
  // Retain complete matching originals before the irreversible once selection.
  let originals=input.originals.map(|b|Box::<[u8]>::from(b));
  let state=Rc::new(CoreOperationStateV2{purpose,operations:input.requested_operations,originals,association:input.association_original.into(),account:input.account_original.into(),intent:input.operation_original.into(),id,deadline:input.monotonic_deadline,relation:self.current.borrow().accepted_relation,retired:Cell::new(false),close_selected:Cell::new(false),closed:Cell::new(false),unknown:Cell::new(false),first:Cell::new(None),children:Cell::new(0),local:PhantomData});
  let mut rights=NativeCoreRightsV2{parent:self,state:Rc::clone(&state)};
  // Parent keeps exact entered originals even if a late fence fails and the
  // rights wrapper is drained. UNKNOWN cannot erase intent then retry it.
  self.entered.borrow_mut().insert(id,retain);self.operations.borrow_mut().insert(id,state);self.retained_bytes.set(total);self.children.set(self.children.get()+1);
  if rights.assert_current_v2().is_err(){rights.unknown.set(true);let _=rights.close_once_v2();return Err(self.latch(Error::Window))}Ok(rights)
 }
 pub(crate) fn issue_first_device_core_rights_v2<'p>(&'p self,input:&CoreOriginalIntakeV2<'_>)->Result<NativeCoreRightsV2<'p>,Error>{self.issue(CorePurposeV2::FirstDeviceCore,input)}
 pub(crate) fn issue_message_core_rights_v2<'p>(&'p self,input:&CoreOriginalIntakeV2<'_>)->Result<NativeCoreRightsV2<'p>,Error>{self.issue(CorePurposeV2::MessageCore,input)}
 pub(crate) fn match_context_originals_v2(&self,originals:&[&[u8];6],association:&[u8],account:&[u8],generation:u64)->Result<(),Error>{
  self.assert_current_v2()?;if generation!=self.policy.storage_generation||digest(association)!=self.policy.association||digest(account)!=self.policy.account||originals.iter().any(|b|b.is_empty()||b.len()>1048576){return Err(Error::Binding)}
  for(raw,expected)in[(originals[0],self.policy.root),(originals[1],self.policy.registration),(originals[3],self.policy.source),(originals[4],self.policy.namespace)]{if digest(raw)!=expected{return Err(Error::Binding)}}self.assert_current_v2()
 }
 // These are matching facts from an already current genuine device parent.
 // They do not acquire that parent or confer an enforcing resource capability.
 pub(crate) fn match_device_binding_v2(&self,root:&[u8;32],registration:&[u8;32],classic:&[u8;33],pq:&[u8])->Result<(),Error>{
  self.assert_current_v2()?;let mut hash=Sha256::new();hash.update(classic);hash.update(pq);
  if *root!=self.policy.root||*registration!=self.policy.registration||classic[0]!=5||pq.len()!=2592||<[u8;32]>::from(hash.finalize())!=self.policy.device{return Err(Error::Binding)}self.assert_current_v2()
 }
 pub(crate) fn message_relation_current_v2(&self,raw:&[u8])->Result<(),Error>{
  self.assert_current_v2()?;if raw.is_empty()||raw.len()>65536||self.current.borrow().accepted_relation!=Some(digest(raw)){return Err(Error::Binding)}self.assert_current_v2()
 }
 pub(crate) fn operation_budget_v2(&self)->Result<Duration,Error>{self.assert_current_v2()?;self.budget.get().checked_sub(self.observed.get().elapsed()).filter(|b|!b.is_zero()).ok_or(Error::Window)}
 // Retain the single issued record for a native operation spanning C entries.
 // Reborrowing never runs issue again or changes its intent/mask/deadline.
 pub(crate) fn retain_first_device_core_v2(&self,input:&CoreOriginalIntakeV2<'_>)->Result<[u8;32],Error>{
  let rights=self.issue_first_device_core_rights_v2(input)?;Ok(rights.id)
 }
 pub(crate) fn retain_message_core_v2(&self,input:&CoreOriginalIntakeV2<'_>)->Result<[u8;32],Error>{
  let rights=self.issue_message_core_rights_v2(input)?;Ok(rights.id)
 }
 pub(crate) fn reborrow_operation_v2(&self,id:&[u8;32])->Result<NativeCoreRightsV2<'_>,Error>{
  self.assert_current_v2()?;
  let state=self.operations.borrow().get(id).cloned().ok_or(Error::Binding)?;
  let rights=NativeCoreRightsV2{parent:self,state};rights.assert_current_v2()?;Ok(rights)
 }
 // Inventory/thread/children are checked during cleanup without demanding
 // business freshness. The exact record stays in entered even after drain.
 pub(crate) fn operation_diagnostic_v2(&self,id:&[u8;32])->Result<CoreOwnerDiagnosticV2,Error>{
  if self.thread!=thread::current().id(){return Err(Error::Binding)}
  let state=self.operations.borrow().get(id).cloned().ok_or(Error::Binding)?;
  Ok(NativeCoreRightsV2{parent:self,state}.diagnostic_v2())
 }
 pub(crate) fn return_operation_child_v2(&self,id:&[u8;32])->Result<(),Error>{
  if self.thread!=thread::current().id(){return Err(Error::Binding)}
  let state=self.operations.borrow().get(id).cloned().ok_or(Error::Binding)?;
  NativeCoreRightsV2{parent:self,state}.return_enforcing_child_v2()
 }
 pub(crate) fn close_operation_v2(&self,id:&[u8;32])->Result<(),Error>{
  if self.thread!=thread::current().id(){return Err(Error::Binding)}
  let state=self.operations.borrow().get(id).cloned().ok_or(Error::Binding)?;
  NativeCoreRightsV2{parent:self,state}.close_once_v2()
 }
 pub(crate) fn retire_v2(&self){self.retired.set(true)}
 pub(crate) fn close_once_v2(&mut self)->Result<(),Error>{self.retire_v2();if self.children.get()!=0{return Err(Error::Binding)}if self.close_selected.replace(true){return if self.closed.get(){Ok(())}else{Err(Error::Binding)}}self.closed.set(true);if self.unknown.get(){Err(Error::Binding)}else{Ok(())}}
}

#[cfg(test)]mod public_controls{
 use super::*;
 // No approved profile or signatures: actual private parser/rule primitives.
 fn policy()->PolicyOriginalV2{PolicyOriginalV2{version:2,plane:"OriginalSourceIdentity.NativeCore".into(),bootstrap:"PUBLIC".into(),root:[1;32],registration:[2;32],source:[3;32],namespace:[4;32],account:[5;32],device:[6;32],association:[7;32],storage_generation:1,key_use:"selected-storage-record-head-journal-queue-nonce-seal-CAS".into(),first_device_operations:63,message_operations:62,issuer_credential:[8;32],anchor_credential:[9;32],generation:1,not_before_ms:50,expires_ms:300,max_current_age_ms:100}}
 #[test]fn actual_purpose_and_operations_are_not_source_admin_message_grants(){
  let mut p=policy();assert!(policy_shape(&p).is_ok());
  for purpose in ["SOURCE_PROOF_ARTIFACT_V1","SOCIAL_MESSAGE_ASSOCIATION_AND_FINAL_V1","Register","Update","Revoke","wallet-product-session-v2-admission-publisher/v1"]{p.plane=purpose.into();assert!(policy_shape(&p).is_err());}
  p=policy();p.message_operations|=CoreOperationV2::InitializeStorage.bit();assert!(policy_shape(&p).is_err());
  p=policy();p.first_device_operations|=128;assert!(policy_shape(&p).is_err());
  p=policy();p.key_use="all-identity-and-ratchet-keys".into();assert!(policy_shape(&p).is_err());
 }
 #[test]fn actual_half_open_bounds_and_canonical_fail_closed(){
  assert!(check_window(50,50,100).is_ok());assert!(check_window(100,50,100).is_err());assert!(check_window(49,50,100).is_err());assert!(check_window(50,100,50).is_err());
  let bytes=serde_json::to_vec(&policy()).unwrap();let _:PolicyOriginalV2=canonical(&bytes,32768).unwrap();
  let mut spaced=bytes.clone();spaced.push(b' ');assert!(canonical::<PolicyOriginalV2>(&spaced,32768).is_err());
  assert!(canonical::<PolicyOriginalV2>(b"{\"version\":2,\"version\":2}",32768).is_err());
 }
}
// Rights loan is lifetime-bound to the original plane. No C repr, export or
// private-key accessor. M1 must add genuine enforcing resources before effects.
pub(crate) struct NativeCoreRightsV2<'p>{
 parent:&'p NativePurposeIdentityOwnerV2,state:Rc<CoreOperationStateV2>,
}
// State is retained by its authenticated plane. Rc preserves lifetime only;
// neither this private state nor a digest can independently authorize a gate.
pub(crate) struct CoreOperationStateV2{
 purpose:CorePurposeV2,operations:u32,
 originals:[Box<[u8]>;6],association:Box<[u8]>,account:Box<[u8]>,intent:Box<[u8]>,id:[u8;32],deadline:Instant,relation:Option<[u8;32]>,
 retired:Cell<bool>,close_selected:Cell<bool>,closed:Cell<bool>,unknown:Cell<bool>,first:Cell<Option<Error>>,children:Cell<usize>,local:PhantomData<Rc<()>>,
}
impl std::ops::Deref for NativeCoreRightsV2<'_>{type Target=CoreOperationStateV2;fn deref(&self)->&Self::Target{&self.state}}
impl NativeCoreRightsV2<'_>{
 pub(crate) fn unresolved_v2(&self)->bool{self.unknown.get()||self.parent.unresolved_v2()}
 pub(crate) fn diagnostic_v2(&self)->CoreOwnerDiagnosticV2{CoreOwnerDiagnosticV2{first_cause:self.first.get().or(self.parent.diagnostic_v2().first_cause),uncertain:self.unresolved_v2(),retired:self.retired.get(),cleanup_complete:self.closed.get(),children:self.children.get()}}
 fn latch(&self,e:Error)->Error{if self.first.get().is_none(){self.first.set(Some(e))}self.unknown.set(true);self.first.get().unwrap_or(e)}
 pub(crate) fn assert_current_v2(&self)->Result<(),Error>{
  if self.retired.get()||self.closed.get()||self.unknown.get(){return Err(self.first.get().unwrap_or(Error::Binding))}
  if Instant::now()>=self.deadline{return Err(self.latch(Error::Window))}
  self.parent.assert_current_v2().map_err(|e|self.latch(e))?;
  if digest(&self.intent)!=self.id||!self.parent.entered.borrow().contains_key(&self.id)||self.relation!=self.parent.current.borrow().accepted_relation{return Err(Error::Binding)}Ok(())
 }
 pub(crate) fn matches_v2(&self,purpose:CorePurposeV2,operation:CoreOperationV2,originals:&[&[u8];6],association:&[u8],account:&[u8],intent:&[u8])->Result<(),Error>{
  self.assert_current_v2()?;if self.purpose!=purpose||self.operations&operation.bit()==0||self.originals.iter().zip(originals).any(|(a,b)|a.as_ref()!=*b)||self.association.as_ref()!=association||self.account.as_ref()!=account||self.intent.as_ref()!=intent{return Err(Error::Binding)}self.assert_current_v2()
 }
 pub(crate) fn check_gate_v2(&self,operation:CoreOperationV2)->Result<(),Error>{
  let originals=std::array::from_fn(|i|self.originals[i].as_ref());
  self.matches_v2(self.purpose,operation,&originals,&self.association,&self.account,&self.intent)
 }
 pub(crate) fn association_matches_v2(&self,raw:&[u8])->Result<(),Error>{
  self.assert_current_v2()?;if raw!=self.association.as_ref(){return Err(Error::Binding)}self.assert_current_v2()
 }
 pub(crate) fn borrow_enforcing_child_v2(&self)->Result<(),Error>{
  self.assert_current_v2()?;let prior=self.children.get();if prior>=32{return Err(Error::Bounds)}self.children.set(prior+1);
  if let Err(e)=self.assert_current_v2(){
   // No external child/effect was published: roll back ONLY our RAM increment.
   // Keep prior children and UNKNOWN; caller never receives a phantom borrower.
   self.children.set(prior);self.unknown.set(true);return Err(e)
  }Ok(())
 }
 #[cfg(test)]pub(crate) fn public_test_children(&self)->usize{self.children.get()}
 pub(crate) fn return_enforcing_child_v2(&self)->Result<(),Error>{if self.children.get()==0{return Err(Error::Binding)}self.children.set(self.children.get()-1);Ok(())}
 pub(crate) fn retire_v2(&self){self.retired.set(true)}
 pub(crate) fn close_once_v2(&mut self)->Result<(),Error>{self.retire_v2();if self.children.get()!=0{return Err(Error::Binding)}if self.close_selected.replace(true){return if self.closed.get(){Ok(())}else{Err(Error::Binding)}}if self.parent.children.get()==0{self.unknown.set(true);return Err(Error::Binding)}self.parent.children.set(self.parent.children.get()-1);self.closed.set(true);if self.unknown.get(){Err(Error::Binding)}else{Ok(())}}
}
