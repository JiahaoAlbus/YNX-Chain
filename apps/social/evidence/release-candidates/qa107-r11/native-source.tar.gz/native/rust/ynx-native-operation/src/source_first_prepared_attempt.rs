//! Storage-only binding. Parsing does not authorize any key operation.
use super::*;
impl SourceAttemptBinding {
 // Normal storage projection from actual retained loan+verified credentials.
 // No caller coordinates/frame, authority/crypto dispatch or nonce reservation.
 pub(super)fn original_first_prepared(loan:&crate::private_custodian_ffi::RecoveryLoan<'_>,credential:&crate::source_evidence::VerifiedFirstPreparedHolderCredential)->Result<Self,SourceError>{
  let input=loan.original_provider_input().map_err(|_|SourceError::Pair)?;
  let frame=input.storage_frame(credential).map_err(|_|SourceError::Pair)?;
  let prefix=b"YNX/SOCIAL/SOURCE-PROOF/V1\0";
  let name=*frame.get(prefix.len()).ok_or(SourceError::Bounds)? as usize;
  let start=prefix.len()+1+name+4;
  let raw=frame.get(start..).ok_or(SourceError::Bounds)?;
  let c=crate::source_evidence::first_prepared_storage_coordinates(raw).map_err(|_|SourceError::Bounds)?;
  input.matches_coordinates(&c).map_err(|_|SourceError::Pair)?;
  let(role,custodian,_,_,classic,pq)=credential.storage();
  let binding=Self::bounded_first_prepared(c.operation.as_bytes(),c.nonce,c.sequence,c.head,role,custodian,*classic,pq,&frame)?;
  input.recheck().map_err(|_|SourceError::Pair)?;credential.recheck().map_err(|_|SourceError::Pair)?;Ok(binding)
 }

 pub(super) fn bounded_first_prepared(operation:&[u8],nonce:[u8;32],sequence:u64,head:[u8;32],role:SourceRole,custodian:&[u8],classic_public:[u8;33],pq_public:&[u8;2592],frame:&[u8])->Result<Self,SourceError>{
  let ascii=|s:&[u8],max:usize|!s.is_empty()&&s.len()<=max&&s.iter().all(|b|(33..=126).contains(b));
  let prefix=b"YNX/SOCIAL/SOURCE-PROOF/V1\0";
  if !ascii(operation,128)||!ascii(custodian,512)||classic_public[0]!=5||frame.len()>49152||!frame.starts_with(prefix){return Err(SourceError::Bounds)}
  let size=*frame.get(prefix.len()).ok_or(SourceError::Bounds)? as usize;
  let start=prefix.len()+1;let end=start+size;
  let expected:&[u8]=match role{SourceRole::Issuer=>b"first-prepared-issuer",SourceRole::Anchor=>b"first-prepared-anchor"};
  if frame.len()<end+4||&frame[start..end]!=expected{return Err(SourceError::Bounds)}
  let length=u32::from_be_bytes(frame[end..end+4].try_into().map_err(|_|SourceError::Bounds)?)as usize;
  if length==0||length>32768||frame.len()!=end+4+length{return Err(SourceError::Bounds)}
  let c=crate::source_evidence::first_prepared_storage_coordinates(&frame[end+4..]).map_err(|_|SourceError::Bounds)?;
  if c.operation.as_bytes()!=operation||c.nonce!=nonce||c.sequence!=sequence||c.head!=head||(role==SourceRole::Anchor&&c.anchor_custodian.as_bytes()!=custodian){return Err(SourceError::Bounds)}
  Ok(Self{purpose:SourcePurpose::FirstPrepared,operation:operation.to_vec(),nonce,sequence,head,role,custodian:custodian.to_vec(),classic_public,pq_public:Box::new(*pq_public),frame:frame.to_vec()})
 }
}
#[cfg(test)]mod controls{
 use super::*;
 #[test]#[ignore="requires separately generated PUBLIC Go body"]
 fn actual_go_pending_storage_binding(){
  let dir=std::env::var("YNX_SOCIAL_PUBLIC_PENDING_VECTOR_DIR").unwrap();
  let raw=std::fs::read(std::path::Path::new(&dir).join("pending-body.json")).unwrap();
  let c=crate::source_evidence::first_prepared_storage_coordinates(&raw).unwrap();
  let mut pk=[1;33];pk[0]=5;
  for (role,name,custodian) in [(SourceRole::Issuer,"first-prepared-issuer","PUBLIC-issuer"),(SourceRole::Anchor,"first-prepared-anchor",c.anchor_custodian.as_str())]{
   let mut f=b"YNX/SOCIAL/SOURCE-PROOF/V1\0".to_vec();f.push(name.len()as u8);f.extend(name.as_bytes());f.extend((raw.len()as u32).to_be_bytes());f.extend(&raw);
   let make=|op:&[u8],nonce,seq,head,cust:&[u8],frame:&[u8]|SourceAttemptBinding::bounded_first_prepared(op,nonce,seq,head,role,cust,pk,&[2;2592],frame);
   let b=make(c.operation.as_bytes(),c.nonce,c.sequence,c.head,custodian.as_bytes(),&f).unwrap();
   assert!(b.purpose==SourcePurpose::FirstPrepared);
   assert!(!source_frame_matches(role,&f));
   assert!(make(b"replacement",c.nonce,c.sequence,c.head,custodian.as_bytes(),&f).is_err());
   assert!(make(c.operation.as_bytes(),[0;32],c.sequence,c.head,custodian.as_bytes(),&f).is_err());
   assert!(make(c.operation.as_bytes(),c.nonce,c.sequence+1,c.head,custodian.as_bytes(),&f).is_err());
   assert!(make(c.operation.as_bytes(),c.nonce,c.sequence,[0;32],custodian.as_bytes(),&f).is_err());
   if role==SourceRole::Anchor{assert!(make(c.operation.as_bytes(),c.nonce,c.sequence,c.head,b"other",&f).is_err());}
   f.push(0);assert!(make(c.operation.as_bytes(),c.nonce,c.sequence,c.head,custodian.as_bytes(),&f).is_err());
  }
 }
}
#[cfg(test)]mod outcome_cross_controls{
 use super::*;
 use std::io::Write;
 #[test]#[ignore="requires separately supplied PUBLIC Go body and fresh PUBLIC output directory"]
 fn public_pending_partial_outcomes_for_go(){
  let input=std::env::var("YNX_SOCIAL_PUBLIC_PENDING_VECTOR_DIR").unwrap();
  let output=std::env::var("YNX_SOCIAL_PUBLIC_PENDING_OUTCOME_DIR").unwrap();
  let raw=std::fs::read(std::path::Path::new(&input).join("pending-body.json")).unwrap();
  let c=crate::source_evidence::first_prepared_storage_coordinates(&raw).unwrap();
  for (index,role,name,custodian) in [(0,SourceRole::Issuer,"first-prepared-issuer","PUBLIC-issuer"),(1,SourceRole::Anchor,"first-prepared-anchor",c.anchor_custodian.as_str())]{
   let mut f=b"YNX/SOCIAL/SOURCE-PROOF/V1\0".to_vec();f.push(name.len()as u8);f.extend(name.as_bytes());f.extend((raw.len()as u32).to_be_bytes());f.extend(&raw);
   let mut pk=[index+1;33];pk[0]=5;
   let original=SourceAttemptBinding::bounded_first_prepared(c.operation.as_bytes(),c.nonce,c.sequence,c.head,role,custodian.as_bytes(),pk,&[index+1;2592],&f).unwrap();
   let mut attempt=RetainedSourceAttempt::new(original);
   // PUBLIC diagnostic bytes, NOT valid signatures or approved credentials.
   attempt.run_once(|_|Ok(vec![0xa5;64].into_boxed_slice()),|_,_,_|17);
   assert_eq!(attempt.phase,AttemptPhase::Partial);
   let outcome=attempt.encode_unverified_outcome().unwrap();
   attempt.run_once(|_|panic!("second classic dispatch"),|_,_,_|panic!("second PQ dispatch"));
   assert_eq!(attempt.encode_unverified_outcome().unwrap(),outcome);
   let path=std::path::Path::new(&output).join(format!("{name}.outcome"));
   let mut options=std::fs::OpenOptions::new();options.write(true).create_new(true);
   #[cfg(unix)]{use std::os::unix::fs::OpenOptionsExt;options.mode(0o600);}
   let mut file=options.open(path).unwrap();file.write_all(&outcome).unwrap();file.sync_all().unwrap();
  }
 }
}
