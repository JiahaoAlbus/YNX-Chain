//! Actual non-null C capsules; synthetic test-TU supplier, never admission.
use super::*;
use super::super::source_owner_controls::{Driver,OwnerObservation,Failure,veil_fixture_abi5_owner_create,veil_fixture_abi5_owner_allow_rollback,veil_fixture_abi5_owner_observe,veil_fixture_abi5_owner_driver_drop,veil_store_close,veil_store_destroy};
use std::{ffi::CString,ptr};
fn actual(mode:Failure,primary:i32,name:&str,full:bool,interrupted:bool){
 let mut q=Quarantine::try_new(if full{32}else{1}).unwrap();
 // Admission reservation happens BEFORE test fixture creates foreign effects.
 // Production bind-before-effects needs the real same-actor descriptor port.
 let t=q.reserve().unwrap();let mut others=Vec::new();
 if full{for _ in 1..32{others.push(q.reserve().unwrap());}assert!(matches!(q.reserve(),Err(Error::Capacity)));}
 let root=std::env::var_os("VEIL_R17_FIXTURE_OUTPUT").unwrap();let file=std::path::PathBuf::from(root).join(name);assert!(!file.exists());let file=CString::new(file.to_str().unwrap()).unwrap();
 let mut store=ptr::null_mut();let mut driver=ptr::null_mut();
 unsafe{
  assert_eq!(veil_fixture_abi5_owner_create(file.as_ptr(),mode,&mut store,&mut driver),primary);
  let mut borrow=super::super::SourceStoreBorrow::fixture_owned(store);
  let mut op=q.operation(t).unwrap();assert!(op.bind(&mut borrow).is_ok());
  if !interrupted{assert_eq!(op.failed_source(primary),Ok(()));assert_eq!(op.failed_source(99),Err(Error::Duplicate));assert_eq!(op.retry(),Ok(Disposition::Held{primary,last:8}));}
  drop(op); // SAME capsule/source borrow retained; no auto foreign cleanup.
  let (same,calls)=match &q.slots[t.index].state{State::Held(o)=>(o.handle,o.foreign_calls),_=>panic!("custody lost")};
  if !interrupted{assert!(!same.is_null());assert_eq!(calls,[1,1,1]);}
  assert_eq!(q.retire(t),Err(Error::Unresolved));
  q=match q.shutdown(){Err(q)=>q,Ok(())=>panic!("shutdown discarded uncertainty")};
  assert_eq!(match &q.slots[t.index].state{State::Held(o)=>o.handle,_=>panic!()},same);
  assert_eq!(veil_store_close(store),5);
  let mut obs=OwnerObservation::default();assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut obs),0);
  assert_eq!((obs.source_refs,obs.source_lock_held,obs.actual_autocommit,obs.sticky_unknown),(1,1,0,1));
  assert_eq!(veil_fixture_abi5_owner_allow_rollback(driver,1),0);
  let p=primary;
  let mut recovery=q.operation(t).unwrap();assert_eq!(recovery.retry(),Ok(Disposition::Released{primary:p,unknown:true}));drop(recovery);
  let calls_after=match &q.slots[t.index].state{State::Held(o)=>o.foreign_calls,_=>panic!()};assert_eq!(calls_after,if interrupted{[1,1,1]}else{[1,2,2]});
  let mut recovery=q.operation(t).unwrap();assert_eq!(recovery.retry(),Ok(Disposition::Released{primary:p,unknown:true}));drop(recovery);
  assert_eq!(match &q.slots[t.index].state{State::Held(o)=>o.foreign_calls,_=>panic!()},calls_after);
  assert_eq!(q.retire(t),Ok(Disposition::Released{primary:p,unknown:true}));assert_eq!(q.operation(t).err(),Some(Error::Stale));
  for t in others{q.cancel_unbound(t).unwrap();}
  assert!(q.shutdown().is_ok());
  assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut obs),0);
  assert_eq!((obs.source_refs,obs.source_lock_held,obs.actual_autocommit,obs.sticky_unknown,obs.source_holds,obs.producer_borrows),(0,0,1,1,0,0));
  assert_eq!(veil_store_close(store),0);assert_eq!(veil_store_destroy(&mut store),0);assert!(store.is_null());assert_eq!(veil_fixture_abi5_owner_driver_drop(&mut driver,store),0);assert!(driver.is_null());
 }
}
#[test]fn r19_actual_c_schema_drop_transfer_shutdown_recovery(){actual(Failure::SchemaSql,3,"r19-schema.sqlite",false,false)}
#[test]fn r19_actual_c_unknown_full_admission_preserves_owner(){actual(Failure::CommitUnknown,8,"r19-full.sqlite",true,false)}
#[test]fn r19_actual_c_interrupted_bound_operation_quarantines(){actual(Failure::SchemaSql,3,"r19-interrupted.sqlite",false,true)}
#[test]fn r19_preallocation_failure_capacity_thread_and_stale(){
 assert!(matches!(Quarantine::allocate(1,true),Err(Error::Allocation)));assert!(matches!(Quarantine::try_new(33),Err(Error::Capacity)));
 let mut q=Quarantine::try_new(1).unwrap();let t=q.reserve().unwrap();assert!(matches!(q.reserve(),Err(Error::Capacity)));q.cancel_unbound(t).unwrap();let next=q.reserve().unwrap();assert!(matches!(q.operation(t),Err(Error::Stale)));
 let mut other=Quarantine::try_new(1).unwrap();assert!(matches!(other.operation(next),Err(Error::Stale)));assert!(other.shutdown().is_ok());
 let expected=q.thread;assert_eq!(std::thread::spawn(move||check_thread(expected)).join().unwrap(),Err(Error::Thread));
 q.cancel_unbound(next).unwrap();assert!(q.shutdown().is_ok());
}
#[test]fn r19_actual_c_forced_drop_failstop_child(){
 if std::env::var_os("VEIL_R19_ABORT_CHILD").is_none(){return;}
 let mut q=Quarantine::try_new(1).unwrap();let t=q.reserve().unwrap();let root=std::env::var_os("VEIL_R17_FIXTURE_OUTPUT").unwrap();let file=CString::new(std::path::PathBuf::from(root).join("r19-forced.sqlite").to_str().unwrap()).unwrap();let mut store=ptr::null_mut();let mut driver=ptr::null_mut();
 unsafe{assert_eq!(veil_fixture_abi5_owner_create(file.as_ptr(),Failure::SchemaSql,&mut store,&mut driver),3);let mut borrow=super::super::SourceStoreBorrow::fixture_owned(store);let mut op=q.operation(t).unwrap();assert!(op.bind(&mut borrow).is_ok());op.failed_source(3).unwrap();assert_eq!(op.retry(),Ok(Disposition::Held{primary:3,last:8}));drop(op);drop(q);}
 panic!("forced unresolved destructor returned");
}
