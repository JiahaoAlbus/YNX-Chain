//! PRIVATE frozen-v4 custodian consumption, local protection NOT device authority.
#![allow(unsafe_code)]
use crate::private_own_key::{NativeClassicOwnKey,SerializedClassicOwnKey};
use std::{ffi::{c_char,c_void,CString},marker::PhantomData,rc::Rc,thread::ThreadId};
use zeroize::Zeroizing;
mod predevice_port;
mod reload_projection;
mod paired_proof;
pub(crate)use paired_proof::source_request::OriginalProviderInput;
mod held_reload;
#[cfg(all(test,feature="predevice-reconciliation-v3"))]pub(crate)mod rcj_fixtures;
#[repr(C)]struct PqOpaque{_private:[u8;0]}
#[repr(C)]struct PlatformOpaque{_private:[u8;0]}
#[repr(C)]struct Binding {alias:*const c_char,generation:u64,classic:*const u8,association:*const u8,association_size:usize}
#[repr(C)]struct PqRecord{version:u32,aad_size:u32,aad:[u8;7168],nonce:[u8;12],cipher:[u8;4912]}
#[repr(C)]struct ClassicRecord{version:u32,aad_size:u32,cipher_size:u32,aad:[u8;7168],nonce:[u8;12],cipher:[u8;272]}
#[repr(C)]struct PqProtector{context:*mut c_void,seal:Option<unsafe extern "C" fn(*mut c_void,*const u8,usize,*const u8,usize,*mut u8,*mut u8,*mut usize)->i32>,unseal:Option<unsafe extern "C" fn(*mut c_void,*const u8,usize,*const u8,*const u8,*mut u8,usize,*mut usize)->i32>}
#[repr(C)]struct ClassicProtector{context:*mut c_void,seal:Option<unsafe extern "C" fn(*mut c_void,*const u8,usize,*const u8,usize,*mut u8,*mut u8,usize,*mut usize)->i32>,unseal:Option<unsafe extern "C" fn(*mut c_void,*const u8,usize,*const u8,*const u8,usize,*mut u8,usize,*mut usize)->i32>}
#[link(name="veil_ownkey_custodian_v4",kind="static")]
unsafe extern "C"{
 fn veil_own_android_create_platform(env:*mut jni::sys::JNIEnv,context:jni::sys::jobject,alias:*const c_char,policy:jni::sys::jobject,out:*mut *mut PlatformOpaque,pq:*mut PqProtector,classic:*mut ClassicProtector)->i32;
 fn veil_own_android_lookup_platform(env:*mut jni::sys::JNIEnv,context:jni::sys::jobject,alias:*const c_char,out:*mut *mut PlatformOpaque,pq:*mut PqProtector,classic:*mut ClassicProtector)->i32;
 fn veil_own_android_release(out:*mut *mut PlatformOpaque)->i32;
 fn veil_own_create_sealed(b:*const Binding,p:*const PqProtector,out:*mut *mut PqOpaque,r:*mut PqRecord)->i32;
 fn veil_own_public(owner:*const PqOpaque,out:*mut u8)->i32;
 fn veil_own_sign_public_proof(owner:*const PqOpaque,message:*const u8,length:usize,signature:*mut u8,written:*mut usize)->i32;
 fn veil_own_reload(b:*const Binding,public:*const u8,r:*const PqRecord,p:*const PqProtector,out:*mut *mut PqOpaque)->i32;
 fn veil_own_close(out:*mut *mut PqOpaque)->i32;
 fn veil_own_aad(b:*const Binding,public:*const u8,out:*mut u8,written:*mut usize)->i32;
 fn veil_classic_aad(b:*const Binding,public:*const u8,n:usize,out:*mut u8,written:*mut usize)->i32;
 fn veil_classic_seal_native(b:*const Binding,public:*const u8,clear:*const u8,n:usize,p:*const ClassicProtector,r:*mut ClassicRecord)->i32;
 fn veil_classic_unseal_native(b:*const Binding,public:*const u8,r:*const ClassicRecord,p:*const ClassicProtector,clear:*mut u8,n:usize,written:*mut usize)->i32;
}
#[link(name="veil_ownkey_bootstrap_final",kind="static")]
unsafe extern "C"{
 fn veil_own_android_bootstrap_platform(env:*mut jni::sys::JNIEnv,context:jni::sys::jobject,binding:*const Binding,mode:u32,auth_window_seconds:u32,out:*mut *mut PlatformOpaque,pq:*mut PqProtector,classic:*mut ClassicProtector)->i32;
}
#[derive(Debug,PartialEq,Eq)]pub(crate)enum CustodyError{Bounds,Thread,Phase,Foreign(i32),Unknown,Pair,Memory,RequiredAtomicPairJournal,Abi}
/// Before any RNG/platform/database effect, retain the ORIGINAL local input.
/// Pure storage bookkeeping; NOT a source/device/first-trust capability.
/// A successful inventory reservation is NOT a durable once reservation.
pub(crate) struct LocalGenesisInput {
 alias:String, generation:u64, association:Vec<u8>, window:u32,
}
impl LocalGenesisInput {
 pub(crate) fn checked(alias:String,generation:u64,association:Vec<u8>,window:u32)
  ->Result<Self,(CustodyError,Self)>{
  let original=Self{alias,generation,association,window};
  let prefix="ynx.social.ownkey.v1.";
  if original.generation==0||original.generation>i64::MAX as u64||original.association.is_empty()||original.association.len()>4096||!(1..=120).contains(&original.window)||original.alias.len()!=prefix.len()+32||!original.alias.starts_with(prefix)||!original.alias.as_bytes()[prefix.len()..].iter().all(|c|c.is_ascii_digit()||matches!(c,b'a'..=b'f')){
   return Err((CustodyError::Bounds,original))
  }
  Ok(original)
 }
}
// The actual Java command keeps original prepare/path Outcome and FD owner.
// Held in the SAME inventory cell before Java directory effects, not a second
// registry, source credential, or inferred permission. Never Clone/Send.
struct OriginalJavaCommand<T> { value:T, thread:ThreadId, local:PhantomData<Rc<()>> }
impl<T> OriginalJavaCommand<T> {
 fn retain(value:T)->Self{Self{value,thread:std::thread::current().id(),local:PhantomData}}
 fn borrow(&self)->Result<&T,CustodyError>{if self.thread!=std::thread::current().id(){Err(CustodyError::Thread)}else{Ok(&self.value)}}
}
#[derive(Clone,Copy,PartialEq,Eq)]enum OriginalIdBinding{Unattempted,Attempted,Acknowledged}
pub(crate) struct LocalGenesisReservation {
 first_recovery_failure:Option<i32>,
  source_request:Option<paired_proof::source_request::PendingSourceRequest>,
  type4_attempts:paired_proof::paired_attempt::Type4Slots,recovery:Option<recovery::RecoveryState>,reload_attempted:bool,reload_failure:Option<ReloadFailure>,input:LocalGenesisInput, local_ids:Option<[u8;32]>,local_ids_failed:bool,id_binding:OriginalIdBinding, thread:ThreadId, local:PhantomData<Rc<()>>,
 java_command:Option<OriginalJavaCommand<jni::refs::Global<jni::objects::JObject<'static>>>>,
 java_input:Option<OriginalJavaCommand<jni::refs::Global<jni::objects::JObject<'static>>>>,
 existing_reader:Option<predevice_port::ExistingReader>,predevice:Option<predevice_port::PreDeviceOwner>,classic:Option<NativeClassicOwnKey>,custody:Option<NativeOwnKeyCustody>,
}
impl LocalGenesisReservation {
 pub(crate) fn retain(input:LocalGenesisInput)->Self{Self{first_recovery_failure:None,source_request:None,type4_attempts:paired_proof::paired_attempt::Type4Slots::new(),recovery:None,reload_attempted:false,reload_failure:None,input,local_ids:None,local_ids_failed:false,id_binding:OriginalIdBinding::Unattempted,java_input:None,thread:std::thread::current().id(),local:PhantomData,java_command:None,existing_reader:None,predevice:None,classic:None,custody:None}}
 pub(crate) fn retain_with_java_command(input:LocalGenesisInput,command:jni::refs::Global<jni::objects::JObject<'static>>,java_input:jni::refs::Global<jni::objects::JObject<'static>>)->Self{
  let mut original=Self::retain(input);original.java_command=Some(OriginalJavaCommand::retain(command));original.java_input=Some(OriginalJavaCommand::retain(java_input));original
 }
 // A private lifetime borrow only. Caller cannot keep a LOCAL RefCell borrow
 // across a Java call; make a JVM local ref, release native borrow, then call.
 pub(crate) fn original_java_command(&self)->Result<&jni::refs::Global<jni::objects::JObject<'static>>,CustodyError>{
  if self.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  self.java_command.as_ref().ok_or(CustodyError::Phase)?.borrow()
 }
 pub(crate) fn durable_once_required(&self)->Result<(),CustodyError>{
  self.current_local()?;
  // No actual final Kepler ticket adapter is supplied in this candidate.
  // Do not generate a classic pair or synthesize a successful reservation.
  Err(CustodyError::RequiredAtomicPairJournal)
 }
}

impl LocalGenesisReservation {
 // Public local SQLite intent identifiers, NOT key generation, KDF or trust.
 // Original bytes are installed before OS RNG; a failure cannot retry/reset.
 pub(crate) fn prepare_original_local_intent(&mut self)->Result<(),CustodyError>{
  self.current_local()?;
  if self.local_ids_failed{return Err(CustodyError::Unknown)}
  if self.local_ids.is_some(){return Err(CustodyError::Phase)}
  self.local_ids=Some([0;32]);
  use rand::TryRngCore as _;
  if rand::rngs::OsRng.try_fill_bytes(self.local_ids.as_mut().ok_or(CustodyError::Phase)?).is_err(){self.local_ids_failed=true;return Err(CustodyError::Unknown)}
  Ok(())
 }
 pub(crate) fn reserve_original_context_path(&mut self,path:&std::ffi::CStr)->Result<(),CustodyError>{
  self.current_local()?;
  if self.local_ids_failed{return Err(CustodyError::Unknown)}
  let ids=self.local_ids.as_ref().ok_or(CustodyError::Phase)?;
  let mut operation=[0;16];let mut incarnation=[0;16];operation.copy_from_slice(&ids[..16]);incarnation.copy_from_slice(&ids[16..]);
  self.reserve_predevice(path,operation,incarnation)
 }
 pub(crate) fn local_pair_readback_complete(&self)->Result<bool,CustodyError>{self.current_local()?;match self.predevice.as_ref(){Some(v)=>v.readback_complete(),None=>Ok(false)}}
 pub(crate) fn actual_local_ticket_ready(&self)->Result<(),CustodyError>{
  self.current_local()?;self.predevice.as_ref().ok_or(CustodyError::Phase)?.reserved_ready()
 }
 pub(crate) fn current_local(&self)->Result<(),CustodyError>{
  if self.first_recovery_failure.is_some(){return Err(CustodyError::Unknown)}
  if self.id_binding==OriginalIdBinding::Attempted||self.reload_failure.is_some(){return Err(CustodyError::Unknown)}
  if self.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  if self.local_ids_failed{return Err(CustodyError::Unknown)}
  if let Some(predevice)=self.predevice.as_ref(){predevice.live()?}
  if let Some(custody)=self.custody.as_ref(){custody.live()?}
  Ok(())
 }
 pub(crate) fn recover_original_cipher(&mut self)->Result<(),CustodyError>{
  if self.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  let uncertain=self.current_local().is_err();
  let custody=match self.custody.as_ref(){Some(v)=>v,None=>return Err(if uncertain{CustodyError::Unknown}else{CustodyError::Phase})};
  let pair=custody.borrow_original_encrypted_pair_for_recovery()?;
  self.predevice.as_mut().ok_or(CustodyError::Phase)?.verify_readback(&self.input,&pair)
 }
 pub(crate) fn reserve_predevice(&mut self,path:&std::ffi::CStr,operation:[u8;16],incarnation:[u8;16])->Result<(),CustodyError>{
  self.current_local()?;if self.predevice.is_some(){return Err(CustodyError::Phase)}
  self.predevice=Some(predevice_port::PreDeviceOwner::unopened(operation,incarnation));
  self.predevice.as_mut().ok_or(CustodyError::Phase)?.reserve(path,&self.input)
 }
 /// ONLY called after actual worker Context/UID/CE preflight and original
 /// controller inventory admission plus actual durable reservation success.
 pub(crate) fn generate_after_durable_reserve(&mut self)->Result<(),CustodyError>{
  self.current_local()?;
  if self.classic.is_some()||self.custody.is_some(){return Err(CustodyError::Phase)}
  self.require_original_id_binding()?;
  self.predevice.as_mut().ok_or(CustodyError::Phase)?.claim_generation()?;
  use rand::TryRngCore as _;
  let selected=libsignal_protocol::IdentityKeyPair::generate(&mut rand::rngs::OsRng.unwrap_err());
  self.classic=Some(NativeClassicOwnKey::from_selected(selected).map_err(|_|CustodyError::Pair)?);
  // Retain the actual generated pair BEFORE public binding allocations.
  let public=self.classic.as_ref().ok_or(CustodyError::Phase)?.public_identity().serialize();
  let mut association=Vec::new();association.try_reserve_exact(self.input.association.len()).map_err(|_|CustodyError::Memory)?;association.extend_from_slice(&self.input.association);
  let binding=StorageBinding::new(&self.input.alias,self.input.generation,public.as_ref().try_into().map_err(|_|CustodyError::Pair)?,association)?;
  let original=self.classic.take().ok_or(CustodyError::Phase)?;
  match NativeOwnKeyCustody::reserve(original,binding){Ok(custody)=>{self.custody=Some(custody);Ok(())},Err((original,_))=>{self.classic=Some(original);Err(CustodyError::Pair)}}
 }
 pub(crate) unsafe fn initialize_generated(&mut self,env:*mut jni::sys::JNIEnv,context:jni::sys::jobject)->Result<(),CustodyError>{
  self.current_local()?;let custody=self.custody.as_mut().ok_or(CustodyError::Phase)?;
  unsafe{custody.initialize(env,context,LocalProtectionMode::GenesisLocalCreate,self.input.window)}
 }
 pub(crate) fn seal_generated(&mut self)->Result<(),CustodyError>{self.current_local()?;self.custody.as_mut().ok_or(CustodyError::Phase)?.create_and_seal_both()}
 pub(crate) fn commit_generated(&mut self)->Result<(),CustodyError>{
  self.current_local()?;let custody=self.custody.as_ref().ok_or(CustodyError::Phase)?;
  let pair=custody.borrow_original_encrypted_pair()?;
  let predevice=self.predevice.as_mut().ok_or(CustodyError::Phase)?;
  predevice.commit(&pair)?;predevice.verify_readback(&self.input,&pair)
 }
}

/// Storage binding expectations, NOT native issuer/source/device capability.
pub(crate)struct StorageBinding{alias:CString,generation:u64,classic:[u8;33],association:Vec<u8>}
impl StorageBinding{
 pub(crate)fn new(alias:&str,generation:u64,classic:[u8;33],association:Vec<u8>)->Result<Self,CustodyError>{
  let p="ynx.social.ownkey.v1.";
  if generation==0||generation>i64::MAX as u64||classic[0]!=5||association.is_empty()||association.len()>4096||alias.len()!=p.len()+32||!alias.starts_with(p)||!alias.as_bytes()[p.len()..].iter().all(|c|c.is_ascii_digit()||matches!(c,b'a'..=b'f')){return Err(CustodyError::Bounds)}
  Ok(Self{alias:CString::new(alias).map_err(|_|CustodyError::Bounds)?,generation,classic,association})
 }
 fn ffi(&self)->Binding{Binding{alias:self.alias.as_ptr(),generation:self.generation,classic:self.classic.as_ptr(),association:self.association.as_ptr(),association_size:self.association.len()}}
}
/// Mode chooses LOCAL create vs lookup only. It grants no existing-device trust.
#[derive(Clone,Copy)]pub(crate)enum LocalProtectionMode{GenesisLocalCreate,ExistingLocalLookup,RestoreLocalLookup,RevokedRefuse}
fn bootstrap_mode(mode:LocalProtectionMode)->u32{match mode{LocalProtectionMode::GenesisLocalCreate=>1,LocalProtectionMode::ExistingLocalLookup=>2,LocalProtectionMode::RestoreLocalLookup=>3,LocalProtectionMode::RevokedRefuse=>4}}
fn bootstrap_window(mode:LocalProtectionMode,seconds:u32)->Result<(),CustodyError>{
 match mode{LocalProtectionMode::GenesisLocalCreate if (1..=120).contains(&seconds)=>Ok(()),LocalProtectionMode::ExistingLocalLookup|LocalProtectionMode::RestoreLocalLookup if seconds==0=>Ok(()),_=>Err(CustodyError::Bounds)}
}
/// In the SAME controller inventory before any C/platform effect. No Clone/Send,
/// public pointer factory, or independent 32-entry Rust registry.
pub(crate)struct NativeOwnKeyCustody{
 held_reload:Option<held_reload::HeldReload>,
 classic:Option<NativeClassicOwnKey>,serialized:Option<SerializedClassicOwnKey>,binding:StorageBinding,
 pq:*mut PqOpaque,platform:*mut PlatformOpaque,pqp:PqProtector,cp:ClassicProtector,
 pq_record:PqRecord,classic_record:ClassicRecord,pq_public:[u8;2592],journal:Option<Vec<u8>>,
 thread:ThreadId,platform_attempted:bool,crypto_attempted:bool,mode:Option<LocalProtectionMode>,first:Option<i32>,unknown:bool,local:PhantomData<Rc<()>>,
}
impl NativeOwnKeyCustody{
 pub(crate)fn reserve(classic:NativeClassicOwnKey,binding:StorageBinding)->Result<Self,(NativeClassicOwnKey,StorageBinding)>{
  if classic.public_identity().serialize().as_ref()!=binding.classic{return Err((classic,binding))}
  let mut state=Self::reserve_existing_reload(binding);state.classic=Some(classic);Ok(state)
 }
 pub(crate)fn reserve_existing_reload(binding:StorageBinding)->Self{
  Self{held_reload:None,classic:None,serialized:None,binding,pq:std::ptr::null_mut(),platform:std::ptr::null_mut(),pqp:PqProtector{context:std::ptr::null_mut(),seal:None,unseal:None},cp:ClassicProtector{context:std::ptr::null_mut(),seal:None,unseal:None},pq_record:PqRecord{version:0,aad_size:0,aad:[0;7168],nonce:[0;12],cipher:[0;4912]},classic_record:ClassicRecord{version:0,aad_size:0,cipher_size:0,aad:[0;7168],nonce:[0;12],cipher:[0;272]},pq_public:[0;2592],journal:None,thread:std::thread::current().id(),platform_attempted:false,crypto_attempted:false,mode:None,first:None,unknown:false,local:PhantomData}
 }
 pub(crate)fn is_unopened(&self)->bool{!self.platform_attempted&&!self.crypto_attempted&&self.pq.is_null()&&self.platform.is_null()&&self.journal.is_none()&&self.first.is_none()&&!self.unknown}
 fn live(&self)->Result<(),CustodyError>{if self.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}if self.unknown{return Err(CustodyError::Unknown)}if let Some(v)=self.first{return Err(CustodyError::Foreign(v))}Ok(())}
 fn result(&mut self,status:i32)->Result<(),CustodyError>{if status==5||status==9{self.unknown=true}if status!=0&&self.first.is_none(){self.first=Some(status)}if self.unknown{Err(CustodyError::Unknown)}else if status==0{Ok(())}else{Err(CustodyError::Foreign(status))}}
 /// Safety: exact actual internal JVM worker Env/Context, NEVER UI-derived
 /// native pointers. C publishes retained owner even on post-init Java-primary.
 pub(crate)unsafe fn initialize(&mut self,env:*mut jni::sys::JNIEnv,context:jni::sys::jobject,mode:LocalProtectionMode,auth_window_seconds:u32)->Result<(),CustodyError>{
  self.live()?;if self.platform_attempted{return Err(CustodyError::Phase)}bootstrap_window(mode,auth_window_seconds)?;self.platform_attempted=true;self.mode=Some(mode);
  let original_binding=self.binding.ffi();
  let code=unsafe{veil_own_android_bootstrap_platform(env,context,&original_binding,bootstrap_mode(mode),auth_window_seconds,&mut self.platform,&mut self.pqp,&mut self.cp)};
  self.result(code)?;if self.platform.is_null(){self.unknown=true;return Err(CustodyError::Abi)}Ok(())
 }
 pub(crate)fn create_and_seal_both(&mut self)->Result<(),CustodyError>{
  self.live()?;if self.platform.is_null()||self.crypto_attempted||!matches!(self.mode,Some(LocalProtectionMode::GenesisLocalCreate)){return Err(CustodyError::Phase)}
  self.serialized=Some(self.classic.as_ref().ok_or(CustodyError::Phase)?.serialize_for_native_custody().map_err(|_|CustodyError::Pair)?);
  self.crypto_attempted=true;
  let b=self.binding.ffi();let code=unsafe{veil_own_create_sealed(&b,&self.pqp,&mut self.pq,&mut self.pq_record)};self.result(code)?;
  if self.pq.is_null(){self.unknown=true;return Err(CustodyError::Abi)}
  let code=unsafe{veil_own_public(self.pq,self.pq_public.as_mut_ptr())};self.result(code)?;
  let clear=&self.serialized.as_ref().ok_or(CustodyError::Phase)?.bytes;
  let code=unsafe{veil_classic_seal_native(&b,self.pq_public.as_ptr(),clear.as_ptr(),clear.len(),&self.cp,&mut self.classic_record)};self.result(code)?;
  self.prepare_pair_journal()
 }
 /// Exact protected-frame input remains UNVERIFIED until real C unseal succeeds.
 pub(crate)fn load_unverified_pair(&mut self,wire:&[u8],expected_pq:[u8;2592])->Result<(),CustodyError>{
  self.live()?;if self.crypto_attempted||self.journal.is_some(){return Err(CustodyError::Phase)}
  let(pq,classic)=decode_pair(wire)?;self.validate_records(&pq,&classic,&expected_pq)?;
  let mut owned=Vec::new();owned.try_reserve_exact(wire.len()).map_err(|_|CustodyError::Memory)?;owned.extend_from_slice(wire);
  self.pq_record=pq;self.classic_record=classic;self.pq_public=expected_pq;self.journal=Some(owned);Ok(())
 }
 pub(crate)fn reload_both(&mut self)->Result<(),CustodyError>{
  self.live()?;if self.platform.is_null()||self.crypto_attempted||self.journal.is_none()||!matches!(self.mode,Some(LocalProtectionMode::ExistingLocalLookup|LocalProtectionMode::RestoreLocalLookup)){return Err(CustodyError::Phase)}self.crypto_attempted=true;
  let b=self.binding.ffi();let code=unsafe{veil_own_reload(&b,self.pq_public.as_ptr(),&self.pq_record,&self.pqp,&mut self.pq)};self.result(code)?;
  if self.pq.is_null(){self.unknown=true;return Err(CustodyError::Abi)}
  let n=(self.classic_record.cipher_size as usize).checked_sub(16).ok_or(CustodyError::Bounds)?;
  let mut clear=Zeroizing::new(Vec::new());clear.try_reserve_exact(n).map_err(|_|CustodyError::Memory)?;clear.resize(n,0);let mut written=0;
  let code=unsafe{veil_classic_unseal_native(&b,self.pq_public.as_ptr(),&self.classic_record,&self.cp,clear.as_mut_ptr(),n,&mut written)};self.result(code)?;
  if written!=n{return Err(CustodyError::Abi)}
  let expected=libsignal_protocol::IdentityKey::decode(&self.binding.classic).map_err(|_|CustodyError::Pair)?;
  let selected=SerializedClassicOwnKey::take_native_bytes(clear).map_err(|_|CustodyError::Pair)?.reload_for_native_binding(expected).map_err(|_|CustodyError::Pair)?;
  self.classic=Some(selected);Ok(()) // Local pair only, NO device/restore admission.
 }
 fn validate_records(&self,pq:&PqRecord,c:&ClassicRecord,public:&[u8;2592])->Result<(),CustodyError>{
  let mut a=[0;7168];let mut written=0;let b=self.binding.ffi();let v=unsafe{veil_own_aad(&b,public.as_ptr(),a.as_mut_ptr(),&mut written)};
  if v!=0||written!=pq.aad_size as usize||a[..written]!=pq.aad[..written]{return Err(CustodyError::Pair)}
  written=0;let n=c.cipher_size as usize-16;let v=unsafe{veil_classic_aad(&b,public.as_ptr(),n,a.as_mut_ptr(),&mut written)};
  if v!=0||written!=c.aad_size as usize||a[..written]!=c.aad[..written]{return Err(CustodyError::Pair)}Ok(())
 }
 fn prepare_pair_journal(&mut self)->Result<(),CustodyError>{self.validate_records(&self.pq_record,&self.classic_record,&self.pq_public)?;self.journal=Some(encode_pair(&self.pq_record,&self.classic_record)?);Ok(())}
 fn borrow_original_encrypted_pair(&self)->Result<predevice_port::PairBorrow<'_>,CustodyError>{
  self.live()?;self.borrow_original_encrypted_pair_for_recovery()
 }
 fn borrow_original_encrypted_pair_for_recovery(&self)->Result<predevice_port::PairBorrow<'_>,CustodyError>{
  if self.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}self.validate_records(&self.pq_record,&self.classic_record,&self.pq_public)?;
  let wire=self.journal.as_ref().ok_or(CustodyError::Phase)?;
  let mut cursor=Cursor{bytes:wire,at:0};if cursor.take(8)?!=b"YNXOKJ01"||cursor.n()?!=1{return Err(CustodyError::Bounds)}let pn=cursor.n()?;let cn=cursor.n()?;let pq=cursor.take(pn)?;let classic=cursor.take(cn)?;if cursor.at!=wire.len(){return Err(CustodyError::Bounds)}
  Ok(predevice_port::PairBorrow::from_slices(classic,pq,wire,&self.classic_record.aad[..self.classic_record.aad_size as usize],&self.pq_record.aad[..self.pq_record.aad_size as usize]))
 }
 /// Final authentic guarded atomic CAS/journal supplier has no agreed owning
 /// port for these TWO own-key rows yet. Retain exact encoded frame/owners;
 /// never report Applied/firsttrust from a local codec, fsync or public bool.
 pub(crate)fn commit_pair_journal(&mut self)->Result<(),CustodyError>{self.live()?;Err(CustodyError::RequiredAtomicPairJournal)}
 pub(crate)fn close_known_local(&mut self)->Result<(),CustodyError>{
  self.live()?;if self.journal.is_some(){return Err(CustodyError::RequiredAtomicPairJournal)}
  if !self.pq.is_null(){let prior=self.pq;let v=unsafe{veil_own_close(&mut self.pq)};if(v==0&&!self.pq.is_null())||(v!=0&&self.pq!=prior){self.unknown=true;std::process::abort()}self.result(v)?;}
  if !self.platform.is_null(){let prior=self.platform;let v=unsafe{veil_own_android_release(&mut self.platform)};if(v==0&&!self.platform.is_null())||(v!=0&&self.platform!=prior){self.unknown=true;std::process::abort()}self.result(v)?;}Ok(())
 }
}
impl Drop for NativeOwnKeyCustody{fn drop(&mut self){if !self.pq.is_null()||!self.platform.is_null(){std::process::abort()}/* containment only, NOT durable recovery */}}
fn put32(out:&mut Vec<u8>,n:usize)->Result<(),CustodyError>{out.extend(u32::try_from(n).map_err(|_|CustodyError::Bounds)?.to_be_bytes());Ok(())}
fn encode_pair(pq:&PqRecord,c:&ClassicRecord)->Result<Vec<u8>,CustodyError>{
 if pq.version!=1||c.version!=1||pq.aad_size==0||pq.aad_size>7168||c.aad_size==0||c.aad_size>7168||!(17..=272).contains(&c.cipher_size){return Err(CustodyError::Bounds)}
 let pn=16+pq.aad_size as usize+12+4912;let cn=20+c.aad_size as usize+12+c.cipher_size as usize;
 let mut out=Vec::new();out.try_reserve_exact(20+pn+cn).map_err(|_|CustodyError::Memory)?;
 out.extend(b"YNXOKJ01");put32(&mut out,1)?;put32(&mut out,pn)?;put32(&mut out,cn)?;
 out.extend(b"YNXPQK01");put32(&mut out,1)?;put32(&mut out,pq.aad_size as usize)?;out.extend(&pq.aad[..pq.aad_size as usize]);out.extend(pq.nonce);out.extend(pq.cipher);
 out.extend(b"YNXCLK01");put32(&mut out,1)?;put32(&mut out,c.aad_size as usize)?;put32(&mut out,c.cipher_size as usize)?;out.extend(&c.aad[..c.aad_size as usize]);out.extend(c.nonce);out.extend(&c.cipher[..c.cipher_size as usize]);Ok(out)
}
struct Cursor<'a>{bytes:&'a[u8],at:usize}impl<'a>Cursor<'a>{fn take(&mut self,n:usize)->Result<&'a[u8],CustodyError>{let end=self.at.checked_add(n).ok_or(CustodyError::Bounds)?;let b=self.bytes.get(self.at..end).ok_or(CustodyError::Bounds)?;self.at=end;Ok(b)}fn n(&mut self)->Result<usize,CustodyError>{Ok(u32::from_be_bytes(self.take(4)?.try_into().map_err(|_|CustodyError::Bounds)?)as usize)}}
fn decode_pair(wire:&[u8])->Result<(PqRecord,ClassicRecord),CustodyError>{
 if wire.len()>19600{return Err(CustodyError::Bounds)}let mut q=Cursor{bytes:wire,at:0};if q.take(8)?!=b"YNXOKJ01"||q.n()?!=1{return Err(CustodyError::Bounds)}let pn=q.n()?;let cn=q.n()?;let pw=q.take(pn)?;let cw=q.take(cn)?;if q.at!=wire.len(){return Err(CustodyError::Bounds)}
 let mut p=Cursor{bytes:pw,at:0};if p.take(8)?!=b"YNXPQK01"||p.n()?!=1{return Err(CustodyError::Bounds)}let pa=p.n()?;if !(1..=7168).contains(&pa){return Err(CustodyError::Bounds)}let mut pq=PqRecord{version:1,aad_size:pa as u32,aad:[0;7168],nonce:[0;12],cipher:[0;4912]};pq.aad[..pa].copy_from_slice(p.take(pa)?);pq.nonce.copy_from_slice(p.take(12)?);pq.cipher.copy_from_slice(p.take(4912)?);if p.at!=pw.len(){return Err(CustodyError::Bounds)}
 let mut c=Cursor{bytes:cw,at:0};if c.take(8)?!=b"YNXCLK01"||c.n()?!=1{return Err(CustodyError::Bounds)}let ca=c.n()?;let cc=c.n()?;if !(1..=7168).contains(&ca)||!(17..=272).contains(&cc){return Err(CustodyError::Bounds)}let mut classic=ClassicRecord{version:1,aad_size:ca as u32,cipher_size:cc as u32,aad:[0;7168],nonce:[0;12],cipher:[0;272]};classic.aad[..ca].copy_from_slice(c.take(ca)?);classic.nonce.copy_from_slice(c.take(12)?);classic.cipher[..cc].copy_from_slice(c.take(cc)?);if c.at!=cw.len(){return Err(CustodyError::Bounds)}Ok((pq,classic))
}
#[cfg(test)]mod tests;

#[cfg(test)]mod r44_local_unknown_controls{
 use super::*;
 fn original()->LocalGenesisReservation{LocalGenesisReservation::retain(LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".to_owned(),1,vec![9],30).unwrap_or_else(|_|panic!("public metadata")))}
 #[test]fn r44_actual_c_failure_dominates_every_phase(){
  let mut owner=original();let path=std::ffi::CString::new("relative-public-refusal").unwrap();
  assert!(matches!(owner.reserve_predevice(&path,[1;16],[2;16]),Err(CustodyError::Unknown)));
  assert!(matches!(owner.reserve_predevice(&path,[1;16],[2;16]),Err(CustodyError::Unknown)));
  assert!(matches!(owner.generate_after_durable_reserve(),Err(CustodyError::Unknown)));
  assert!(matches!(unsafe{owner.initialize_generated(std::ptr::null_mut(),std::ptr::null_mut())},Err(CustodyError::Unknown)));
  assert!(matches!(owner.seal_generated(),Err(CustodyError::Unknown)));
  assert!(matches!(owner.commit_generated(),Err(CustodyError::Unknown)));
  assert!(matches!(owner.durable_once_required(),Err(CustodyError::Unknown)));
  assert!(matches!(owner.recover_original_cipher(),Err(CustodyError::Unknown)));
  assert!(owner.classic.is_none()&&owner.custody.is_none());
 }
}

#[cfg(test)]mod r45_command_custody_controls {
 use super::*;
 #[test]fn r45_original_command_sole_owner_lifetime(){
  use std::cell::Cell;
  struct PublicOwner(Rc<Cell<usize>>);
  impl Drop for PublicOwner{fn drop(&mut self){self.0.set(self.0.get()+1)}}
  let drops=Rc::new(Cell::new(0));
  let original=OriginalJavaCommand::retain(PublicOwner(drops.clone()));
  let address=original.borrow().unwrap_or_else(|_|panic!("same executor")) as *const PublicOwner;
  for _ in 0..3{assert_eq!(original.borrow().unwrap_or_else(|_|panic!("same owner")) as *const PublicOwner,address);assert_eq!(drops.get(),0)}
  drop(original);assert_eq!(drops.get(),1);
 }
 #[test]fn r45_missing_java_custody_never_infers_provider(){
  let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".to_owned(),1,vec![1],30).unwrap_or_else(|_|panic!("public metadata"));
  let mut original=LocalGenesisReservation::retain(input);
  assert!(matches!(original.original_java_command(),Err(CustodyError::Phase)));
  assert!(matches!(original.reserve_predevice(&std::ffi::CString::new("relative-public-refusal").unwrap(),[1;16],[2;16]),Err(CustodyError::Unknown)));
  assert!(matches!(original.original_java_command(),Err(CustodyError::Phase)));
  assert!(matches!(original.current_local(),Err(CustodyError::Unknown)));
  assert!(original.classic.is_none()&&original.custody.is_none());
 }
}
#[cfg(test)]mod r46_local_intent_controls{
 use super::*;
 fn input()->LocalGenesisInput{LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".to_owned(),1,vec![1],30).unwrap_or_else(|_|panic!("public local input"))}
 #[test]fn r46_missing_original_intent_has_zero_c_owner(){let mut owner=LocalGenesisReservation::retain(input());let path=std::ffi::CString::new("relative").unwrap();assert!(matches!(owner.reserve_original_context_path(&path),Err(CustodyError::Phase)));assert!(owner.predevice.is_none());assert!(matches!(owner.actual_local_ticket_ready(),Err(CustodyError::Phase)));}
 #[test]fn r46_actual_public_reservation_ticket_not_scalar(){
  use std::os::unix::fs::DirBuilderExt;
  let mut owner=LocalGenesisReservation::retain(input());
  // Explicit public identifiers fixture, never a production issuer.
  owner.local_ids=Some([7;32]);
  let root=std::path::PathBuf::from(std::env::var_os("TMPDIR").unwrap()).join(format!("r46-public-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
  std::fs::DirBuilder::new().mode(0o700).create(&root).unwrap();
  let path=std::ffi::CString::new(root.join("ownkeys.sqlite3").as_os_str().as_encoded_bytes()).unwrap();
  owner.reserve_original_context_path(&path).unwrap();owner.actual_local_ticket_ready().unwrap();
  assert!(matches!(owner.reserve_original_context_path(&path),Err(CustodyError::Phase)));owner.actual_local_ticket_ready().unwrap();
  assert!(owner.classic.is_none()&&owner.custody.is_none());owner.predevice.as_mut().unwrap().close_known().unwrap();
 }
}
#[cfg(test)]mod r48_local_pair_no_effect_controls{
 use super::*;
 fn owner()->LocalGenesisReservation{LocalGenesisReservation::retain(LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".to_owned(),1,vec![1],30).unwrap_or_else(|_|panic!("public metadata")))}
 #[test]fn r48_missing_ticket_never_generates_pair(){let mut owner=owner();assert!(matches!(owner.generate_after_durable_reserve(),Err(CustodyError::Phase)));assert!(owner.classic.is_none()&&owner.custody.is_none());assert!(!owner.local_pair_readback_complete().unwrap());}
 #[test]fn r48_unprepared_chain_no_platform_or_false_completion(){let mut owner=owner();let original=owner.input.association.as_ptr();assert!(matches!(unsafe{owner.initialize_generated(std::ptr::null_mut(),std::ptr::null_mut())},Err(CustodyError::Phase)));assert!(matches!(owner.seal_generated(),Err(CustodyError::Phase)));assert!(matches!(owner.commit_generated(),Err(CustodyError::Phase)));assert_eq!(original,owner.input.association.as_ptr());assert!(!owner.local_pair_readback_complete().unwrap());assert!(owner.classic.is_none()&&owner.custody.is_none());}
}

impl LocalGenesisReservation{
 // PUBLIC correlation, not device/source authority. Exact original retained IDs
 // only. Attempt is sticky before any Java allocation/callback/unwind.
 pub(crate)fn begin_original_id_binding(&mut self)->Result<[u8;32],CustodyError>{
  self.current_local()?;
  if self.id_binding!=OriginalIdBinding::Unattempted{return Err(CustodyError::Phase)}
  let ids=*self.local_ids.as_ref().ok_or(CustodyError::Phase)?;
  self.id_binding=OriginalIdBinding::Attempted;Ok(ids)
 }
 // Called only after the exact Java callback returned1, exception-free, and
 // requireSubmitted postcheck. Acknowledgement is local durability, NOT trust.
 pub(crate)fn acknowledge_original_id_binding(&mut self)->Result<(),CustodyError>{
  if self.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  if self.id_binding!=OriginalIdBinding::Attempted||self.local_ids_failed{return Err(CustodyError::Phase)}
  self.id_binding=OriginalIdBinding::Acknowledged;Ok(())
 }
 fn require_original_id_binding(&self)->Result<(),CustodyError>{
  self.current_local()?;if self.id_binding!=OriginalIdBinding::Acknowledged{return Err(CustodyError::Phase)}Ok(())
 }
}
#[cfg(test)]mod r54_binding_controls{
 use super::*;
 fn owner()->LocalGenesisReservation{LocalGenesisReservation::retain(LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public metadata")))}
 #[test]fn r54_public_ids_attempt_is_sticky_without_ack(){let mut o=owner();o.local_ids=Some([7;32]);let ids=o.begin_original_id_binding().unwrap();assert_eq!(ids,[7;32]);assert!(matches!(o.current_local(),Err(CustodyError::Unknown)));assert!(matches!(o.begin_original_id_binding(),Err(CustodyError::Unknown)));assert!(matches!(o.generate_after_durable_reserve(),Err(CustodyError::Unknown)));assert_eq!(o.local_ids,Some(ids));assert!(o.classic.is_none()&&o.custody.is_none()&&o.predevice.is_none());}
 #[test]fn r54_ack_cannot_create_ticket_or_repeat_attempt(){let mut o=owner();assert!(matches!(o.acknowledge_original_id_binding(),Err(CustodyError::Phase)));o.local_ids=Some([9;32]);o.begin_original_id_binding().unwrap();o.acknowledge_original_id_binding().unwrap();o.require_original_id_binding().unwrap();assert!(matches!(o.begin_original_id_binding(),Err(CustodyError::Phase)));assert!(matches!(o.acknowledge_original_id_binding(),Err(CustodyError::Phase)));assert!(matches!(o.generate_after_durable_reserve(),Err(CustodyError::Phase)));assert!(o.classic.is_none()&&o.custody.is_none()&&o.predevice.is_none());}
 #[test]fn r54_missing_ids_no_attempt_no_effect(){let mut o=owner();assert!(matches!(o.begin_original_id_binding(),Err(CustodyError::Phase)));assert!(o.id_binding==OriginalIdBinding::Unattempted);assert!(o.local_ids.is_none());}
}

// Read-only NONSECRET test observation. Never compiled into the normal library,
// never returns a mutable owner, authority, key, or accepted binding.
#[cfg(test)]impl LocalGenesisReservation{
 pub(crate)fn fixture_binding_retention(&self)->(usize,Option<[u8;32]>,bool,bool){
  (self as *const Self as usize,self.local_ids,self.id_binding==OriginalIdBinding::Attempted,
   self.classic.is_none()&&self.custody.is_none()&&self.predevice.is_none())
 }
}

impl LocalGenesisReservation{
 /// Same HELD store/original op only. Does not reopen/create/reserve or
 /// authenticate encrypted bytes. UNKNOWN retains C result and bounded copy.
 pub(crate)fn capture_original_persisted_ciphertext(&mut self)->Result<&[u8],CustodyError>{
  if self.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  self.predevice.as_mut().ok_or(CustodyError::Phase)?.capture_original_journal(&self.input)
 }
}

#[derive(Debug,PartialEq,Eq)]enum ReloadStage{Capture,Projection,Load,Initialize,Authenticate}
struct ReloadFailure{stage:ReloadStage,cause:CustodyError}
impl LocalGenesisReservation{
 fn keep_reload_failure(&mut self,stage:ReloadStage,cause:CustodyError)->CustodyError{if self.reload_failure.is_none(){self.reload_failure=Some(ReloadFailure{stage,cause})}CustodyError::Unknown}
 /// Same retained C ciphertext -> typed UNVERIFIED projection -> SAME slot's
 /// native reload owner. No platform/key effect or authorization occurs here.
 pub(crate)fn stage_original_captured_reload(&mut self)->Result<(),CustodyError>{
  self.current_local()?;if self.reload_attempted||self.classic.is_some()||self.custody.is_some(){return Err(CustodyError::Phase)}
  self.reload_attempted=true;
  let result=(||->Result<(),(ReloadStage,CustodyError)>{
   let wire=self.predevice.as_mut().ok_or((ReloadStage::Capture,CustodyError::Phase))?.capture_original_journal(&self.input).map_err(|e|(ReloadStage::Capture,e))?;
   let projection=reload_projection::UnverifiedProjection::decode(wire,&self.input).map_err(|e|(ReloadStage::Projection,e))?;
   // Install original reload owner BEFORE load/copy can fail.
   self.custody=Some(NativeOwnKeyCustody::reserve_existing_reload(projection.binding));
   self.custody.as_mut().ok_or((ReloadStage::Load,CustodyError::Phase))?.load_unverified_pair(wire,projection.pq_public).map_err(|e|(ReloadStage::Load,e))
  })();
  result.map_err(|(stage,cause)|self.keep_reload_failure(stage,cause))
 }
 /// Only a genuine same-worker JNI Env/Context supplier may call this unsafe
 /// existing port. Mode is fixed lookup3/window0; never create or reseal.
 pub(crate)unsafe fn initialize_original_reload(&mut self,env:*mut jni::sys::JNIEnv,context:jni::sys::jobject)->Result<(),CustodyError>{
  self.current_local()?;if !self.reload_attempted{return Err(CustodyError::Phase)}
  let result=unsafe{self.custody.as_mut().ok_or(CustodyError::Phase)?.initialize(env,context,LocalProtectionMode::RestoreLocalLookup,0)};
  result.map_err(|e|self.keep_reload_failure(ReloadStage::Initialize,e))
 }
 pub(crate)fn authenticate_original_reload(&mut self)->Result<(),CustodyError>{
  self.current_local()?;if !self.reload_attempted{return Err(CustodyError::Phase)}
  let result=self.custody.as_mut().ok_or(CustodyError::Phase)?.reload_both();
  result.map_err(|e|self.keep_reload_failure(ReloadStage::Authenticate,e))
 }
}

mod recovery;
pub(crate)use recovery::{RecoveryLoan,RecoveryTopology};
#[cfg(feature="predevice-reconciliation-v3")]pub(crate)use predevice_port::LocalStoreStage;

#[cfg(test)]pub(crate)use recovery::r61_fixture_original_matches;

#[cfg(feature="predevice-cold-v1")]mod cold_install;
#[cfg(feature="predevice-cold-v1")]pub(crate)use cold_install::ColdRecovery;
