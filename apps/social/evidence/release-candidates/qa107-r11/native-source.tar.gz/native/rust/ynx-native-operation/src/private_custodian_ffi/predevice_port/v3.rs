//! Whole-component rev3 consumer. No legacy pointer constructor or JNI grant.
use super::*;
#[repr(C)]pub(super)struct Resolution{_private:[u8;0]}
#[repr(C)]#[derive(Default,Clone,Copy,PartialEq,Eq)]
pub(super)struct Report{version:u32,kind:u32,first_failure:u32,cleanup_status:u32,durable_revision:i64}
const _:()={assert!(std::mem::size_of::<Report>()==24);assert!(std::mem::align_of::<Report>()==8);assert!(std::mem::offset_of!(Report,durable_revision)==16);};
unsafe extern "C"{
 fn veil_pd_reconcile_held(ticket:*mut Ticket,out:*mut *mut Resolution,report:*mut Report)->i32;
 pub(super)fn veil_pd_resolution_borrow(resolution:*mut Resolution,callback:extern "C" fn(*const Original,*const Pair,*mut c_void),context:*mut c_void,report:*mut Report)->i32;
 fn veil_pd_resolution_drop(out:*mut *mut Resolution)->i32;
 fn veil_pd_reconcile_cleanup(ticket:*mut Ticket)->i32;
 fn veil_pd_resolution_discharge(resolution:*mut *mut Resolution,ticket:*mut *mut Ticket,report:*mut Report)->i32;
}
// Constructed only after THIS compiled component allocated/reserved the ticket.
// This is allocation provenance, never device/source/cryptographic authority.
struct AllocatedHere;
pub(super)struct State{
 provenance:Option<AllocatedHere>,pointer:*mut Resolution,started:bool,
 report:Option<Report>,native_first:Option<u32>,cleanup:Option<i32>,
 discharged:bool,closed:bool,cleanup_required:bool,
 #[cfg(test)]counts:[u32;6],
 #[cfg(test)]fail_cleanup_once:bool,
 #[cfg(test)]hold_close_child_once:bool,
}
impl State{
 pub(super)fn new()->Self{Self{provenance:None,pointer:std::ptr::null_mut(),started:false,report:None,native_first:None,cleanup:None,discharged:false,closed:false,cleanup_required:false,#[cfg(test)]counts:[0;6],#[cfg(test)]fail_cleanup_once:false,#[cfg(test)]hold_close_child_once:false}}
 pub(super)fn reserved_here(&mut self){self.provenance=Some(AllocatedHere)}
 pub(super)fn started(&self)->bool{self.started}
 fn observe(&mut self,r:&Report){if self.native_first.is_none()&&r.first_failure!=0{self.native_first=Some(r.first_failure)}if r.cleanup_status!=0{self.cleanup=Some(r.cleanup_status as i32)}}
}
// A borrow, not a detached copy/token. Dropping it retains all C owners.
pub(in crate::private_custodian_ffi)struct HeldDisposition<'a>{owner:&'a mut PreDeviceOwner}
#[derive(PartialEq,Eq)]pub(crate)enum LocalStoreStage{Held,StoreClosed}
impl PreDeviceOwner{
 pub(in crate::private_custodian_ffi)fn local_store_stage(&self)->Result<LocalStoreStage,CustodyError>{
  self.thread()?;if self.resolution.provenance.is_none(){return Err(CustodyError::Phase)}
  if self.resolution.closed&&self.store.is_null()&&self.ticket.is_null()&&self.resolution.pointer.is_null(){return Ok(LocalStoreStage::StoreClosed)}
  if !self.resolution.pointer.is_null()&&self.resolution.report.is_some()&&self.capture_error.is_none(){return Ok(LocalStoreStage::Held)}
  Err(CustodyError::Unknown)
 }
 pub(in crate::private_custodian_ffi)fn reconcile_v3(&mut self,input:&LocalGenesisInput)->Result<HeldDisposition<'_>,CustodyError>{
  self.thread()?;
  if self.resolution.provenance.is_none(){return Err(CustodyError::Phase)}
  if self.resolution.discharged{return Ok(HeldDisposition{owner:self})}
  if self.ticket.is_null()||self.store.is_null(){return Err(CustodyError::Phase)}
  self.resolution.started=true; // permanently blocks ordinary commit/reserve/close
  // Retain the cleanup obligation even when RAM disposal succeeds but rollback
  // fails. Both normal RecoveryLoan entry points resume this exact owner.
  if self.resolution.cleanup_required{self.cleanup_reconciliation_v3()?;}
  if !self.result.is_null(){
   let prior=self.result;let code=unsafe{veil_pd_result_drop(&mut self.result)};
   if(code==1&&!self.result.is_null())||(code!=1&&self.result!=prior){std::process::abort()}
   if code!=1{return Err(self.failed(code))}
  }
  if self.resolution.pointer.is_null(){
   #[cfg(test)]{self.resolution.counts[0]+=1;}
   let mut report=Report::default();
   let code=unsafe{veil_pd_reconcile_held(self.ticket,&mut self.resolution.pointer,&mut report)};
   self.resolution.observe(&report);
   if code!=18{if !self.resolution.pointer.is_null(){std::process::abort()}return Err(self.failed(code))}
   if self.resolution.pointer.is_null()||!valid(&report){std::process::abort()}
   self.resolution.report=Some(report);
  }
  let expected=self.resolution.report.ok_or(CustodyError::Phase)?;
  if expected.kind==1{
   #[cfg(test)]{self.resolution.counts[1]+=1;}
   let mut report=Report::default();
   let captured=capture::capture_resolution(self.resolution.pointer,input,&self.operation,&self.incarnation,&mut report);
   // Keep original bytes even if the after-callback C check fails. Never publish
   // callback data as authenticated/terminal on an unsuccessful final return.
   if let Some(data)=captured.out{
    if let Some(old)=&self.captured{if old.journal()!=data.journal()||!old.matches(input){return Err(self.failed(5))}}
    else{self.captured=Some(data)}
   }
   if let Some(error)=captured.error{self.remember_capture_failure(error);self.failed(5);}
   self.resolution.observe(&report);
   if captured.status!=18{self.resolution.report=None;self.resolution.cleanup_required=true;return Err(self.failed(captured.status))}
   if !same(&expected,&report)||self.capture_error.is_some()||self.captured.is_none(){return Err(self.failed(5))}
  }
  Ok(HeldDisposition{owner:self})
 }
 /// Explicit rollback/invalid RAM receipt disposal only; never terminal.
 pub(in crate::private_custodian_ffi)fn cleanup_reconciliation_v3(&mut self)->Result<(),CustodyError>{
  self.thread()?;if self.resolution.provenance.is_none()||self.ticket.is_null(){return Err(CustodyError::Phase)}
  self.resolution.cleanup_required=true;
  if !self.resolution.pointer.is_null(){
   #[cfg(test)]{self.resolution.counts[2]+=1;}
   let prior=self.resolution.pointer;let code=unsafe{veil_pd_resolution_drop(&mut self.resolution.pointer)};
   if(code==1&&!self.resolution.pointer.is_null())||(code!=1&&self.resolution.pointer!=prior){std::process::abort()}
   if code!=1{return Err(self.failed(code))}self.unknown=true;self.resolution.report=None;
  }
  #[cfg(test)]{self.resolution.counts[3]+=1;}
  let code=self.reconciliation_cleanup_call();self.resolution.cleanup=Some(code);
  if code!=1{return Err(self.failed(code))}self.resolution.cleanup_required=false;Ok(())
 }
 fn reconciliation_cleanup_call(&mut self)->i32{
  // PUBLIC test-only foreign-status injection, not a real rollback failure.
  #[cfg(test)]if std::mem::take(&mut self.resolution.fail_cleanup_once){return 4}
  unsafe{veil_pd_reconcile_cleanup(self.ticket)}
 }
}
fn valid(r:&Report)->bool{r.version==3&&(r.kind==1||r.kind==2)&&r.durable_revision>=2}
fn same(a:&Report,b:&Report)->bool{valid(b)&&a.kind==b.kind&&a.durable_revision==b.durable_revision}
#[cfg(test)]thread_local!{static BEFORE_DISCHARGE:std::cell::RefCell<Option<Box<dyn FnOnce()>>>=std::cell::RefCell::new(None);}
impl HeldDisposition<'_>{
 /// Disposes only the local database custody, never Java/protector/keys. It
 /// retains the historical first cause and UNKNOWN even after successful close.
 pub(in crate::private_custodian_ffi)fn discharge_store(&mut self)->Result<(),CustodyError>{
  let o=&mut *self.owner;o.thread()?;
  if o.resolution.closed{return Ok(())}
  if !o.resolution.discharged{
   let expected=o.resolution.report.ok_or(CustodyError::Phase)?;
   if o.resolution.pointer.is_null()||o.ticket.is_null(){return Err(CustodyError::Phase)}
   let old_resolution=o.resolution.pointer;let old_ticket=o.ticket;let mut report=Report::default();
   #[cfg(test)]BEFORE_DISCHARGE.with(|v|{let hook=v.borrow_mut().take();if let Some(hook)=hook{hook();}});
   #[cfg(test)]{o.resolution.counts[4]+=1;}
   let code=unsafe{veil_pd_resolution_discharge(&mut o.resolution.pointer,&mut o.ticket,&mut report)};
   o.resolution.observe(&report);
   if code!=18{
    if o.resolution.pointer!=old_resolution||o.ticket!=old_ticket{std::process::abort()}
    o.resolution.report=None;o.resolution.cleanup_required=true;return Err(o.failed(code))
   }
   if !o.resolution.pointer.is_null()||!o.ticket.is_null()||!same(&expected,&report){std::process::abort()}
   o.resolution.discharged=true;
  }
  if !o.store.is_null(){
   #[cfg(test)]{
    if std::mem::take(&mut o.resolution.hold_close_child_once){
     assert!(o.result.is_null());
     assert_eq!(unsafe{veil_pd_lookup(o.store,o.operation.as_ptr(),&mut o.result)},3);
     assert!(!o.result.is_null());
    }
    o.resolution.counts[5]+=1;
   }
   let prior=o.store;let code=unsafe{veil_pd_close(&mut o.store)};o.resolution.cleanup=Some(code);
   if(code==1&&!o.store.is_null())||(code!=1&&o.store!=prior){std::process::abort()}
   if code!=1{return Err(o.failed(code))}
  }
  o.resolution.closed=true;Ok(())
 }
}
#[cfg(test)]impl PreDeviceOwner{
 pub(in crate::private_custodian_ffi)fn rcj_state(&self)->super::super::rcj_fixtures::Snapshot{
  super::super::rcj_fixtures::Snapshot{store:self.store as usize,ticket:self.ticket as usize,receipt:self.resolution.pointer as usize,first:self.first,unknown:self.unknown,discharged:self.resolution.discharged,closed:self.resolution.closed,cleanup_required:self.resolution.cleanup_required,counts:self.resolution.counts}
 }
 pub(in crate::private_custodian_ffi)fn rcj_arm_cleanup_failure(&mut self){self.resolution.fail_cleanup_once=true;}
 pub(in crate::private_custodian_ffi)fn rcj_arm_close_child(&mut self){self.resolution.hold_close_child_once=true;}
 pub(in crate::private_custodian_ffi)fn rcj_drop_close_child(&mut self){
  assert!(!self.result.is_null());assert_eq!(unsafe{veil_pd_result_drop(&mut self.result)},1);assert!(self.result.is_null());
 }
}

#[cfg(test)]mod v3_consumer_controls{
 use super::*;use std::os::unix::fs::DirBuilderExt;
 fn input()->LocalGenesisInput{match LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30){Ok(v)=>v,Err(_)=>panic!("PUBLIC fixture input")}}
 fn original_at()->(PreDeviceOwner,std::path::PathBuf){
  static NEXT:std::sync::atomic::AtomicU64=std::sync::atomic::AtomicU64::new(0);
  let sequence=NEXT.fetch_add(1,std::sync::atomic::Ordering::Relaxed);
  let dir=std::path::PathBuf::from(std::env::var_os("TMPDIR").expect("external TMP")).join(format!("v3-public-{}-{}-{sequence}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
  std::fs::DirBuilder::new().mode(0o700).create(&dir).unwrap();let path=std::ffi::CString::new(dir.join("pair.sqlite3").as_os_str().as_encoded_bytes()).unwrap();
  let mut o=PreDeviceOwner::unopened([1;16],[2;16]);o.reserve(&path,&input()).unwrap();(o,dir.join("pair.sqlite3"))
 }
 fn original()->PreDeviceOwner{original_at().0}
 #[test]fn rcj_repair_normal_loan_sealed_postcheck_and_discharge_retry(){
  use std::os::unix::fs::PermissionsExt;
  for postcheck in [true,false]{
   let(mut o,path)=original_at();
   let pq=super::super::super::PqRecord{version:1,aad_size:1,aad:[7;7168],nonce:[0;12],cipher:[0;4912]};
   let classic=super::super::super::ClassicRecord{version:1,aad_size:1,cipher_size:17,aad:[8;7168],nonce:[0;12],cipher:[0;272]};
   let wire=super::super::super::encode_pair(&pq,&classic).unwrap();
   let pn=u32::from_be_bytes(wire[12..16].try_into().unwrap())as usize;
   let pair=PairBorrow::from_slices(&wire[20+pn..],&wire[20..20+pn],&wire,&[8],&[7]);
   o.claim_generation().unwrap();o.commit(&pair).unwrap();
   let ticket=o.ticket;let store=o.store;
   let mut reservation=super::super::super::LocalGenesisReservation::retain(input());
   reservation.predevice=Some(o);
   if postcheck{
    let fault_path=path.clone();
    capture::POST_CAPTURE.with(|v|*v.borrow_mut()=Some(Box::new(move||{std::fs::set_permissions(fault_path,std::fs::Permissions::from_mode(0o640)).expect("PUBLIC postcallback custody fault");})));
    assert!(reservation.recovery_loan().unwrap().prepare_original_local_disposition().is_err());
   }else{
    reservation.recovery_loan().unwrap().prepare_original_local_disposition().unwrap();
    let fault_path=path.clone();
    BEFORE_DISCHARGE.with(|v|*v.borrow_mut()=Some(Box::new(move||{std::fs::set_permissions(fault_path,std::fs::Permissions::from_mode(0o640)).expect("PUBLIC actual discharge custody fault");})));
    assert!(reservation.recovery_loan().unwrap().discharge_original_local_store().is_err());
   }
   let o=reservation.predevice.as_ref().unwrap();let first=o.first;
   assert!(first.is_some()&&o.unknown&&o.resolution.cleanup_required);
   assert!(!o.resolution.pointer.is_null());assert_eq!(o.ticket,ticket);assert_eq!(o.store,store);
   assert_eq!(o.captured.as_ref().unwrap().journal(),wire);
   // RAM cleanup may succeed while the original pathname remains invalid;
   // normal reconciliation must still refuse, retaining ticket/store custody.
   assert!(reservation.recovery_loan().unwrap().prepare_original_local_disposition().is_err());
   let o=reservation.predevice.as_ref().unwrap();assert_eq!(o.first,first);assert!(o.resolution.pointer.is_null()&&o.resolution.report.is_none());assert_eq!(o.ticket,ticket);assert_eq!(o.store,store);assert!(o.unknown);
   std::fs::set_permissions(&path,std::fs::Permissions::from_mode(0o600)).unwrap();
   let recovered=reservation.recovery_loan().unwrap().prepare_original_local_disposition();
   if recovered.is_err(){let o=reservation.predevice.as_ref().unwrap();eprintln!("PUBLIC rcj recovery postcheck={postcheck} first={:?} capture={:?} cleanup={:?} nativefirst={:?} report={} pointer={} required={}",o.first,o.capture_error,o.resolution.cleanup,o.resolution.native_first,o.resolution.report.is_some(),!o.resolution.pointer.is_null(),o.resolution.cleanup_required);}
   recovered.unwrap();
   let o=reservation.predevice.as_ref().unwrap();assert_eq!(o.ticket,ticket);assert_eq!(o.store,store);assert_eq!(o.first,first);assert!(o.unknown);assert_eq!(o.captured.as_ref().unwrap().journal(),wire);
   reservation.recovery_loan().unwrap().discharge_original_local_store().unwrap();
   reservation.recovery_loan().unwrap().discharge_original_local_store().unwrap();
   let o=reservation.predevice.as_ref().unwrap();assert!(o.store.is_null()&&o.ticket.is_null()&&o.resolution.closed);assert_eq!(o.first,first);assert!(o.unknown);
  }
 }
 #[test]fn v3_consumer_controls_actual_custody_failure_retains_original(){
  // PUBLIC test-only pathname fault/restoration, never a product recovery API.
  let(mut o,path)=original_at();let moved=path.with_file_name("held-public.sqlite3");
  let store=o.store;let ticket=o.ticket;std::fs::rename(&path,&moved).unwrap();
  assert!(o.reconcile_v3(&input()).is_err());let first=o.first;assert!(first.is_some());
  assert_eq!(o.store,store);assert_eq!(o.ticket,ticket);assert!(o.resolution.pointer.is_null());assert!(o.unknown);
  assert!(o.close_known().is_err());assert_eq!(o.first,first);
  std::fs::rename(&moved,&path).unwrap();o.cleanup_reconciliation_v3().unwrap();
  assert_eq!(o.ticket,ticket);assert!(o.unknown);assert_eq!(o.first,first);
  o.reconcile_v3(&input()).unwrap().discharge_store().unwrap();
  assert!(o.store.is_null()&&o.ticket.is_null());assert!(o.unknown);assert_eq!(o.first,first);
 }
 #[test]fn v3_consumer_controls_actual_fence_keeps_unknown_firstcause(){
  let mut o=original();o.failed(4);o.failed(7);
  {let held=o.reconcile_v3(&input()).unwrap();assert_eq!(held.owner.resolution.report.unwrap().kind,2);}
  assert!(o.unknown);assert_eq!(o.first,Some(4));assert!(!o.ticket.is_null());
  assert!(matches!(o.close_known(),Err(CustodyError::Unknown)));
  o.reconcile_v3(&input()).unwrap().discharge_store().unwrap();
  assert!(o.store.is_null()&&o.ticket.is_null()&&o.resolution.pointer.is_null());assert!(o.unknown);assert_eq!(o.first,Some(4));
  o.reconcile_v3(&input()).unwrap().discharge_store().unwrap();
 }
 #[test]fn v3_consumer_controls_actual_sealed_capture_discharge(){
  let mut o=original();
  let pq=super::super::super::PqRecord{version:1,aad_size:1,aad:[7;7168],nonce:[0;12],cipher:[0;4912]};
  let classic=super::super::super::ClassicRecord{version:1,aad_size:1,cipher_size:17,aad:[8;7168],nonce:[0;12],cipher:[0;272]};
  let wire=super::super::super::encode_pair(&pq,&classic).unwrap();
  let pn=u32::from_be_bytes(wire[12..16].try_into().unwrap())as usize;
  let pair=PairBorrow::from_slices(&wire[20+pn..],&wire[20..20+pn],&wire,&[8],&[7]);
  o.claim_generation().unwrap();o.commit(&pair).unwrap();o.verify_readback(&input(),&pair).unwrap();
  let old_store=o.store;assert!(!o.result.is_null());
  {let held=o.reconcile_v3(&input()).unwrap();assert_eq!(held.owner.store,old_store);assert!(held.owner.result.is_null());assert_eq!(held.owner.captured.as_ref().unwrap().journal(),wire);assert_eq!(held.owner.resolution.report.unwrap().kind,1);}
  assert!(o.commit(&pair).is_err());
  o.reconcile_v3(&input()).unwrap().discharge_store().unwrap();assert!(o.store.is_null());
 }
 #[test]fn v3_consumer_controls_provenance_and_wrongthread_refuse_before_ffi(){
  let mut empty=PreDeviceOwner::unopened([1;16],[2;16]);assert!(matches!(empty.reconcile_v3(&input()),Err(CustodyError::Phase)));assert!(!empty.attempted);
  let mut o=original();let ticket=o.ticket;let thread=o.thread;o.thread=std::thread::spawn(||std::thread::current().id()).join().unwrap();
  assert!(matches!(o.reconcile_v3(&input()),Err(CustodyError::Thread)));assert_eq!(o.ticket,ticket);assert!(!o.resolution.started);
  o.thread=thread;o.reconcile_v3(&input()).unwrap().discharge_store().unwrap();
 }
}
