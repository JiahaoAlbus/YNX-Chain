use super::*;
impl NativeProductController{
 pub(crate)fn cold_install_ready(&self)->Result<(),ControllerError>{
  if self.admission_closed{return Err(ControllerError::AdmissionClosed)}
  if self.inventory.slots.iter().any(Option::is_some){return Err(ControllerError::RequiredLifecycle)}
  self.inventory.vacant().map(|_|())
 }
 pub(crate)fn install_cold(&mut self,value:crate::private_custodian_ffi::ColdRecovery)->Result<(),(ControllerError,crate::private_custodian_ffi::ColdRecovery)>{
  if let Err(e)=self.cold_install_ready(){return Err((e,value))}
  let i=match self.inventory.vacant(){Ok(i)=>i,Err(e)=>return Err((e,value))};
  self.inventory.insert_reserved(i,Owned::ColdRecovery(value));Ok(())
 }
 pub(crate)fn cold_mut(&mut self)->Result<&mut crate::private_custodian_ffi::ColdRecovery,ControllerError>{
  let mut slots=self.inventory.slots.iter_mut().flatten();
  let first=slots.next().ok_or(ControllerError::InvalidSelector)?;
  if slots.next().is_some(){return Err(ControllerError::WrongPhase)}
  match &mut first.value{Owned::ColdRecovery(v)=>Ok(v),_=>Err(ControllerError::WrongPhase)}
 }
 pub(crate)fn retire_cold(&mut self)->Result<(),ControllerError>{
  if !self.cold_mut()?.releasable(){return Err(ControllerError::RequiredLifecycle)}
  let i=self.inventory.slots.iter().position(Option::is_some).ok_or(ControllerError::InvalidSelector)?;
  self.inventory.slots[i]=None;Ok(())
 }
}
#[cfg(test)]mod cold_install_controls{
 use super::*;
 #[test]fn cold_install_controls_empty_inventory_and_closing(){
  let mut c=NativeProductController::new(1).unwrap_or_else(|_|panic!("inventory"));
  assert!(c.cold_install_ready().is_ok());
  let input=crate::private_custodian_ffi::LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public"));
  let original=crate::private_custodian_ffi::LocalGenesisReservation::retain(input);
  assert!(c.reserve_local_genesis(original).is_ok());assert!(c.cold_install_ready().is_err());
  assert!(c.cold_mut().is_err());assert!(c.retire_cold().is_err());assert_eq!(c.inventory_for_r51_test(),(1,1));
  c.block_new_operations();assert!(matches!(c.cold_install_ready(),Err(ControllerError::AdmissionClosed)));
 }
}
