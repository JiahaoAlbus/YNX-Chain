//! Root-verified infrastructure custody credential, NEVER signing permission.
//! No caller alias, generation, custodian or expected public pair is trusted.
use super::*;
use crate::source_infrastructure::SourceRole;

pub(crate)struct VerifiedFirstPreparedHolderCredential{
 raw:Vec<u8>,role:SourceRole,custodian:String,alias:std::ffi::CString,generation:u64,
 authority:String,bootstrap:String,epoch:u64,scope:Scope,
 classic:[u8;33],pq:Box<[u8;2592]>,policy:first_prepared::Issuance,
 started:Instant,remaining:Duration,thread:std::thread::ThreadId,local:PhantomData<Rc<()>>,
}
impl VerifiedFirstPreparedHolderCredential{
 pub(crate)fn verify(raw:&[u8],role:SourceRole)->Result<Self,Error>{
  let started=Instant::now();let at=now_ms()?;
  let envelope:Envelope=canonical(raw,65536)?;
  let expected=match role{SourceRole::Issuer=>"issuer",SourceRole::Anchor=>"anchor"};
  // Actual approved bootstrap profile and selected dual signature verification.
  // Empty release-owned profiles stay ProfileRequired; no runtime pin injection.
  let mut c=credential(&envelope,expected)?;
  let policy=c.first_prepared.take().ok_or(Error::Binding)?;
  if !policy.valid(expected)||!policy.holder_authority(expected,&c.authority){return Err(Error::Binding)}
  let (alias,generation,lower,upper)=policy.holder_storage();
  if at<lower||at>=upper{return Err(Error::Window)}
  let alias=std::ffi::CString::new(alias).map_err(|_|Error::Binding)?;
  let classic=decode(&c.public.classic,33,33)?.try_into().map_err(|_|Error::Binding)?;
  let pq=decode(&c.public.pq,2592,2592)?.into_boxed_slice().try_into().map_err(|_|Error::Binding)?;
  let remaining=Duration::from_millis((upper-at)as u64);
  let verified=Self{raw:raw.to_vec(),role,custodian:c.custodian,alias,generation,authority:c.authority,bootstrap:c.bootstrap,epoch:c.epoch,scope:c.scope,classic,pq,policy,started,remaining,thread:std::thread::current().id(),local:PhantomData};
  verified.recheck()?;Ok(verified)
 }
 pub(crate)fn recheck(&self)->Result<(),Error>{
  if self.thread!=std::thread::current().id()||self.started.elapsed()>=self.remaining{return Err(Error::Window)}
  let (_,_,lower,upper)=self.policy.holder_storage();let at=now_ms()?;
  if at<lower||at>=upper{return Err(Error::Window)}Ok(())
 }
 // Same already root-verified credential, not pointer/alias association alone.
 pub(super)fn matches_original_credential(&self,c:&Credential)->Result<(),Error>{
  self.recheck()?;
  let expected=match self.role{SourceRole::Issuer=>"issuer",SourceRole::Anchor=>"anchor"};
  if c.role!=expected||c.custodian!=self.custodian||c.authority!=self.authority||c.bootstrap!=self.bootstrap||c.epoch!=self.epoch||c.scope!=self.scope||c.first_prepared.as_ref()!=Some(&self.policy)||decode(&c.public.classic,33,33)?.as_slice()!=self.classic||decode(&c.public.pq,2592,2592)?.as_slice()!=self.pq.as_ref(){return Err(Error::Binding)}
  self.recheck()
 }
 pub(crate)fn storage(&self)->(SourceRole,&[u8],&std::ffi::CStr,u64,&[u8;33],&[u8;2592]){
  (self.role,self.custodian.as_bytes(),&self.alias,self.generation,&self.classic,&self.pq)
 }
}

#[cfg(test)]mod controls{
 use super::*;
 #[test]fn unapproved_holder_never_becomes_custody_or_permission(){
  let p: first_prepared::Issuance=serde_json::from_value(serde_json::json!({"version":1,"purpose":"SOURCE_FIRST_PREPARED_DUAL_V1","role":"first-prepared-issuer","realm":"r","deployment":"d","instance":"i","headerSHA256":"a".repeat(64),"directorySchema":"YNX-SOCIAL-FIRST-DIRECTORY-V3","lifecycleSchema":"YNX-SOCIAL-GENESIS-LIFECYCLE-V2","historyAdmission":"EXACT_ACCOUNT_NAMESPACE_COMPLETE_PREFIX_V1","finalization":"SAME_ORIGINAL_OWNER_THROUGH_EFFECT_V1","accountIssuer":"https://wallet-auth.ynxweb4.com","clientId":"c","writerAuthority":"w","keyAlias":"PUBLIC-key","storageGeneration":1,"notBeforeMS":0,"expiresMS":9007199254740991i64})).unwrap();
  let scope=Scope{source:"s".into(),store:"s".into(),schema:"s".into(),inode:"s".into(),restore:"s".into(),source_generation:1,native_restore_incarnation:1};
  let mut pk=[1;33];pk[0]=5;
  let c=Credential{issuance:None,version:1,bootstrap:"PUBLIC-UNAPPROVED".into(),authority:"w".into(),role:"issuer".into(),custodian:"PUBLIC-custodian".into(),epoch:1,scope,public:Pair{classic:B64.encode(pk),pq:B64.encode([2;2592])},history_endpoint:"https://source.invalid/v4/source-authority/current-history".into(),first_enrollment:None,first_prepared:Some(p)};
  let e=Envelope{version:1,role:"credential".into(),body:B64.encode(serde_json::to_vec(&c).unwrap()),signature:Pair{classic:String::new(),pq:String::new()}};
  let raw=serde_json::to_vec(&e).unwrap();
  assert!(matches!(VerifiedFirstPreparedHolderCredential::verify(&raw,SourceRole::Issuer),Err(Error::ProfileRequired)));
  assert!(matches!(VerifiedFirstPreparedHolderCredential::verify(&raw,SourceRole::Anchor),Err(Error::Binding)));
  let mut trailing=raw.clone();trailing.push(b' ');
  assert!(matches!(VerifiedFirstPreparedHolderCredential::verify(&trailing,SourceRole::Issuer),Err(Error::Canonical)));
  assert!(approved_profiles().is_empty());
 }
}

// Independently typed Directory custody; FirstPrepared verification above is
// unchanged. Mathematical credential/storage identity still grants no effect.
pub(crate)struct VerifiedDirectoryHolderCredential{
 raw:Vec<u8>,role:SourceRole,custodian:String,alias:std::ffi::CString,generation:u64,
 authority:String,bootstrap:String,epoch:u64,scope:Scope,
 classic:[u8;33],pq:Box<[u8;2592]>,policy:policy::Issuance,enrollment:policy::FirstEnrollment,
 started:Instant,remaining:Duration,thread:std::thread::ThreadId,local:PhantomData<Rc<()>>,
}
impl VerifiedDirectoryHolderCredential{
 pub(crate)fn verify(raw:&[u8],role:SourceRole)->Result<Self,Error>{
  let started=Instant::now();let at=now_ms()?;let envelope:Envelope=canonical(raw,65536)?;
  let expected=match role{SourceRole::Issuer=>"issuer",SourceRole::Anchor=>"anchor"};
  let mut c=credential(&envelope,expected)?;
  let policy=c.issuance.take().ok_or(Error::Binding)?;let enrollment=c.first_enrollment.take().ok_or(Error::Binding)?;
  if !policy.holder_matches(&enrollment,expected,&c.authority){return Err(Error::Binding)}
  let(alias,generation,lower,upper)=policy.holder_storage();if at<lower||at>=upper{return Err(Error::Window)}
  let alias=std::ffi::CString::new(alias).map_err(|_|Error::Binding)?;
  let classic=decode(&c.public.classic,33,33)?.try_into().map_err(|_|Error::Binding)?;
  let pq=decode(&c.public.pq,2592,2592)?.into_boxed_slice().try_into().map_err(|_|Error::Binding)?;
  let verified=Self{raw:raw.to_vec(),role,custodian:c.custodian,alias,generation,authority:c.authority,bootstrap:c.bootstrap,epoch:c.epoch,scope:c.scope,classic,pq,policy,enrollment,started,remaining:Duration::from_millis((upper-at)as u64),thread:std::thread::current().id(),local:PhantomData};verified.recheck()?;Ok(verified)
 }
 pub(crate)fn recheck(&self)->Result<(),Error>{if self.thread!=std::thread::current().id()||self.started.elapsed()>=self.remaining{return Err(Error::Window)}let(_,_,lower,upper)=self.policy.holder_storage();let at=now_ms()?;if at<lower||at>=upper{return Err(Error::Window)}let role=match self.role{SourceRole::Issuer=>"issuer",SourceRole::Anchor=>"anchor"};if !self.policy.holder_matches(&self.enrollment,role,&self.authority){return Err(Error::Binding)}Ok(())}
 pub(crate)fn storage(&self)->(SourceRole,&[u8],&std::ffi::CStr,u64,&[u8;33],&[u8;2592]){(self.role,self.custodian.as_bytes(),&self.alias,self.generation,&self.classic,&self.pq)}
}

#[cfg(test)]mod directory_custody_delta_controls{
 use super::*;
 #[test]fn malformed_directory_credential_never_reloads_or_grants(){for r in [SourceRole::Issuer,SourceRole::Anchor]{assert!(VerifiedDirectoryHolderCredential::verify(b"{}",r).is_err());assert!(VerifiedDirectoryHolderCredential::verify(b"null",r).is_err());}assert!(approved_profiles().is_empty());}
}

// Scoped storage input, not enrollment or capability. It cannot be constructed
// from public bytes; its parent is the original already verified credential.
use crate::source_infrastructure::VerifiedSealedCredentialBorrow;
impl VerifiedSealedCredentialBorrow<'_>{
 pub(crate)fn recheck(&self)->Result<(),Error>{match self{Self::FirstPrepared(c)=>c.recheck(),Self::Directory(c)=>c.recheck()}}
 pub(crate)fn original_raw(&self)->&[u8]{match self{Self::FirstPrepared(c)=>&c.raw,Self::Directory(c)=>&c.raw}}
 pub(crate)fn purpose(&self)->u32{match self{Self::Directory(_)=>1,Self::FirstPrepared(_)=>2}}
 pub(crate)fn role(&self)->SourceRole{match self{Self::FirstPrepared(c)=>c.role,Self::Directory(c)=>c.role}}
 pub(crate)fn storage(&self)->(SourceRole,&[u8],&std::ffi::CStr,u64,&[u8;33],&[u8;2592]){match self{Self::FirstPrepared(c)=>c.storage(),Self::Directory(c)=>c.storage()}}
 pub(crate)fn fixed_window(&self)->Result<(u64,i64,i64),Error>{
  self.recheck()?;
  let(started,remaining,lower,upper)=match self{
   Self::FirstPrepared(c)=>{let(_,_,l,u)=c.policy.holder_storage();(c.started,c.remaining,l,u)},
   Self::Directory(c)=>{let(_,_,l,u)=c.policy.holder_storage();(c.started,c.remaining,l,u)},
  };
  let left=remaining.checked_sub(started.elapsed()).ok_or(Error::Window)?;
  let ns=u64::try_from(left.as_nanos()).map_err(|_|Error::Window)?;
  if ns==0{return Err(Error::Window)}self.recheck()?;Ok((ns,lower,upper))
 }
}
impl VerifiedFirstPreparedHolderCredential{pub(crate)fn sealed_borrow(&self)->Result<VerifiedSealedCredentialBorrow<'_>,Error>{self.recheck()?;Ok(VerifiedSealedCredentialBorrow::FirstPrepared(self))}}
impl VerifiedDirectoryHolderCredential{pub(crate)fn sealed_borrow(&self)->Result<VerifiedSealedCredentialBorrow<'_>,Error>{self.recheck()?;Ok(VerifiedSealedCredentialBorrow::Directory(self))}}
