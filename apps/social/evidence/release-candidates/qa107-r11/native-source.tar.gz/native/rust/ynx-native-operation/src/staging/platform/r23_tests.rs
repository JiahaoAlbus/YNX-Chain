//! Selected SessionCipher preparation; synthetic SQL and lifecycle controls.
//! Abort proves local containment only, never durable recovery or authority.
use super::*;
use std::{io::Write,process::Command,sync::Arc,task::{Wake,Waker}};
fn prepared()->(NativeStoreBridge,NativePendingHandle){
 let(mut b,mut s,a,l,w)=tests::setup();tests::prepare(&mut s,&a,&l,&w);
 let h=b.retain_prepared(s).unwrap_or_else(|_|panic!("fixture admission"));(b,h)
}
fn sql(b:&mut NativeStoreBridge)->&mut FixtureSql{match &mut b.backend{NativeBackend::Fixture(f)=>f,_=>panic!("fixture only")}}
fn poll(b:&mut NativeStoreBridge,h:&mut NativePendingHandle)->Poll<Result<FinalStatus,PortError>>{b.poll_final(h,&mut Context::from_waker(Waker::noop()))}
fn close(b:&NativeStoreBridge){let q=b.owned_supervisor().unwrap_or_else(|_|panic!());let q=match q.shutdown(){Err(q)=>q,Ok(())=>panic!("ledger must remain held")};drop(q);}
fn allocations(b:&NativeStoreBridge,h:&NativePendingHandle)->(*const u8,*const Mutation,usize){let r=&b.pending[&h.slot];let p=r.snapshot.stage.gate.0.borrow();(p.original_ciphertext.as_ref().unwrap().as_ptr(),p.journal.as_ptr(),r.reserved_bytes)}
#[test]fn r23_closed_ledger_first_submit_zero_effects_and_explicit_safe_retirement(){
 let(mut b,mut h)=prepared();let original=allocations(&b,&h);let count=b.custody.borrow().count();let bytes=b.retained_bytes;close(&b);
 for _ in 0..3{assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Held))));}
 assert_eq!(allocations(&b,&h),original);assert_eq!(b.retained_bytes,bytes);assert_eq!(b.custody.borrow().count(),count);
 assert!(!b.pending[&h.slot].submitted);assert!(!b.pending[&h.slot].definitely_not_applied);assert!(matches!(b.pending[&h.slot].completion,Completion::Prepared));
 let f=sql(&mut b);assert_eq!((f.submissions,f.receipts,f.lookups,f.queues.len()),(0,0,0,0));
 assert!(matches!(b.consume_once(&mut h),Err(PortError::Rejected)));assert!(matches!(b.retire(&mut h,RetireAcknowledgement::DefiniteRejection),Err(PortError::Rejected)));
 b.cancel(&mut h).unwrap_or_else(|_|panic!());b.retire(&mut h,RetireAcknowledgement::DefiniteRejection).unwrap_or_else(|_|panic!());assert!(b.pending.is_empty());assert_eq!(b.custody.borrow().count(),0);
}
#[test]fn r23_closing_preserves_submitted_unknown_same_wire_lookup_and_once_output(){
 let(mut b,mut h)=prepared();let original=allocations(&b,&h);sql(&mut b).unknown_after_apply=true;
 assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));close(&b);sql(&mut b).lookup_pending=true;
 assert!(poll(&mut b,&mut h).is_pending());assert_eq!(allocations(&b,&h),original);
 assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::FixtureApplied))));
 assert_eq!(sql(&mut b).submissions,1);assert_eq!(sql(&mut b).lookups,2);let out=b.consume_once(&mut h).unwrap_or_else(|_|panic!());assert!(!out.ciphertext.is_empty());
 b.retire(&mut h,RetireAcknowledgement::ConsumedOutput).unwrap_or_else(|_|panic!());assert_eq!(b.retained_bytes,0);assert!(b.custody.borrow().closing);
}
thread_local!{static CALLBACK:RefCell<Option<(Gate,usize)>>=const{RefCell::new(None)};}
struct TerminalWake;
impl Wake for TerminalWake{
 fn wake(self:Arc<Self>){self.wake_by_ref();}
 fn wake_by_ref(self:&Arc<Self>){
  let entry=CALLBACK.with(|v|v.borrow().as_ref().map(|(g,n)|(g.clone(),*n)));
  if let Some((g,n))=entry{if n==0{g.1.fixture_unknown();g.1.fixture_rebind(4);}else{g.1.fixture_rebind(4);g.1.fixture_unknown();g.1.fixture_revoke();}g.1.cancel();}
 }
}
#[test]fn r23_child(){
 let Ok(mode)=std::env::var("VEIL_R23_CHILD_MODE")else{return};
 let(mut b,mut h)=prepared();let original=allocations(&b,&h);
 match mode.as_str(){
  "unknown-scope"=>{b.pending[&h.slot].snapshot.stage.gate.1.fixture_unknown();close(&b);assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));assert_eq!(sql(&mut b).submissions,0);},
  "unknown-after-empty"=>{let q=b.owned_supervisor().unwrap_or_else(|_|panic!());drop(q);b.pending[&h.slot].snapshot.stage.gate.1.fixture_unknown();},
  "unknown-submit"=>{sql(&mut b).unknown_after_apply=true;assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));assert_eq!(sql(&mut b).submissions,1);},
  "callback-unknown"|"callback-revoke"=>{
   sql(&mut b).unknown_after_apply=true;assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Unknown))));close(&b);sql(&mut b).lookup_pending=true;
   let gate=b.pending[&h.slot].snapshot.stage.gate.clone();CALLBACK.with(|v|*v.borrow_mut()=Some((gate,usize::from(mode=="callback-revoke"))));
   let w=Waker::from(Arc::new(TerminalWake));assert!(matches!(b.poll_final(&mut h,&mut Context::from_waker(&w)),Poll::Ready(Ok(FinalStatus::Unknown))));CALLBACK.with(|v|*v.borrow_mut()=None);
   assert!(matches!(b.cancel(&mut h),Err(PortError::Unknown)));assert!(matches!(b.consume_once(&mut h),Err(PortError::Unknown)));assert!(matches!(b.retire(&mut h,RetireAcknowledgement::DefiniteRejection),Err(PortError::Unknown)));assert_eq!((sql(&mut b).submissions,sql(&mut b).lookups),(1,1));
  },
  "safe-prepared"=>{close(&b);assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Ok(FinalStatus::Held))));assert_eq!(sql(&mut b).submissions,0);},
  "safe-retired"=>{close(&b);b.cancel(&mut h).unwrap_or_else(|_|panic!());b.retire(&mut h,RetireAcknowledgement::DefiniteRejection).unwrap_or_else(|_|panic!());},
  "safe-definite-error"=>{sql(&mut b).fail_at=Some(0);assert!(matches!(poll(&mut b,&mut h),Poll::Ready(Err(PortError::Rejected))));assert!(b.pending[&h.slot].definitely_not_applied);},
  _=>panic!("unselected child mode"),
 }
 if b.pending.contains_key(&h.slot){assert_eq!(allocations(&b,&h),original);}
 println!("R23-CHECKED-{mode}");std::io::stdout().flush().unwrap();drop(b);
 println!("R23-SAFE-DROP-{mode}");
}
#[test]fn r23_actual_child_drop_and_callback_controls(){
 use std::os::unix::process::ExitStatusExt;
 let output=std::path::PathBuf::from(std::env::var_os("VEIL_R23_CHILD_OUTPUT").expect("fresh owned child evidence directory required"));std::fs::create_dir(&output).unwrap();
 let exact=format!("{}::r23_child",module_path!().split_once("::").unwrap().1);
 for mode in ["unknown-scope","unknown-after-empty","unknown-submit","callback-unknown","callback-revoke","safe-prepared","safe-retired","safe-definite-error"]{
  let result=Command::new(std::env::current_exe().unwrap()).args(["--exact",&exact,"--nocapture"]).env("VEIL_R23_CHILD_MODE",mode).output().unwrap();
  std::fs::write(output.join(format!("{mode}.stdout")),&result.stdout).unwrap();std::fs::write(output.join(format!("{mode}.stderr")),&result.stderr).unwrap();std::fs::write(output.join(format!("{mode}.status")),format!("code={:?} signal={:?}\n",result.status.code(),result.status.signal())).unwrap();
  let text=String::from_utf8_lossy(&result.stdout);assert!(text.contains(&format!("R23-CHECKED-{mode}")),"child did not reach checked original custody: {text}");
  if mode.starts_with("safe-"){assert!(result.status.success());assert!(text.contains(&format!("R23-SAFE-DROP-{mode}")));}else{assert_eq!(result.status.signal(),Some(6));assert!(!text.contains("R23-SAFE-DROP"));}
 }
}
