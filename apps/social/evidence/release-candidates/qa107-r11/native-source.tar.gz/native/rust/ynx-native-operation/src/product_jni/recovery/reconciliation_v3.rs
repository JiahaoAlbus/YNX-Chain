//! Fresh rev3 allocations only. No original factory, Java drain or grant.
use super::*;
// Neither status is nativeReleaseNoEffectForThreadExit(36).
const DISPOSITION_HELD:i32=76;
const LOCAL_STORE_CLOSED:i32=77;
#[cfg(test)]mod accepted_context_controls;
unsafe fn operate(raw:*mut jni::sys::JNIEnv,context_raw:jni::sys::jobject,input_raw:jni::sys::jobject,discharge:bool)->i32{
 if let Err(code)=thread_check(false){return code}
 if raw.is_null()||context_raw.is_null()||input_raw.is_null(){return 43}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(raw)};
 let outcome=unowned.with_env_no_catch(|env|->jni::errors::Result<i32>{
  if env.exception_check(){return Ok(fail())}
  let context=unsafe{JObject::from_raw(env,context_raw)};let input=unsafe{JObject::from_raw(env,input_raw)};
  let command=env.get_field(&input,jni::jni_str!("originalCommand"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;"))?.l()?;
  let retained=env.get_field(&command,jni::jni_str!("retainedAppContext"),jni::jni_sig!("Landroid/content/Context;"))?.l()?;
  if !env.is_same_object(&context,&retained)?{return Ok(43)}
  recovery_callback(||env.call_static_method(jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyPrivateCommand"),jni::jni_str!("validateActualContext"),jni::jni_sig!("(Landroid/content/Context;)V"),&[JValue::Object(&context)]))?;
  // Existing guard checks original command, submission and exact retained IDs.
  // No Java callback is made while the exclusive native loan is held.
  let code=guard_context(env,&input,&command,false,Some(&context))?;if code!=44{return Ok(code)}
  let result=loan(|original|{
   if discharge{original.discharge_original_local_store()?}
   else{original.prepare_original_local_disposition()?;}
   Ok::<(),crate::private_custodian_ffi::CustodyError>(())
  });
  match result{Ok(Ok(()))=>{},Err(25)=>return Ok(25),_=>return Ok(fail())}
  if env.exception_check(){return Ok(fail())}
  if guard_context(env,&input,&command,false,Some(&context))?!=44{return Ok(fail())}
  // After callbacks, reborrow original custody; no refreshed owner/FFI effect.
  match loan(|original|original.original_local_store_stage()){
   Ok(Ok(stage))=>Ok(match stage{
    crate::private_custodian_ffi::LocalStoreStage::Held=>DISPOSITION_HELD,
    crate::private_custodian_ffi::LocalStoreStage::StoreClosed=>LOCAL_STORE_CLOSED,
   }),Err(25)=>Ok(25),_=>Ok(fail())
  }
 }).into_outcome();
 match outcome{jni::Outcome::Ok(code)=>code,jni::Outcome::Err(_)=>fail(),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeLocalDispositionAbiVersion(_e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass)->i32{boundary(||1)}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeReconcileOriginalLocalStore(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject)->i32{boundary(||unsafe{operate(e,context,input,false)})}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeDischargeOriginalLocalStore(e:*mut jni::sys::JNIEnv,_c:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject)->i32{boundary(||unsafe{operate(e,context,input,true)})}
#[cfg(test)]mod v3_jni_controls{
 use super::*;
 #[test]fn v3_jni_controls_no_actor_never_creates_original(){std::thread::spawn(||{
  let e=std::ptr::null_mut();let o=std::ptr::null_mut();
  assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeLocalDispositionAbiVersion(e,o),1);
  assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeReconcileOriginalLocalStore(e,o,o,o),21);
  assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeDischargeOriginalLocalStore(e,o,o,o),21);
  assert!(LOCAL.with(|v|v.borrow().is_none()));
 }).join().unwrap();}
}
