//! JNI scalar/opaque ABI wrapper over the sole NORMAL owning controller.
//! No JNIEnv/object dereference, supplier constructor, key/state export or Java
//! address-to-authority conversion. Generated JDK header is the ABI carrier.
use crate::product_controller::{NativeProductController,ControllerError};
use crate::NativeProductError;
use std::{cell::RefCell,sync::Mutex,thread::ThreadId};
const NOT_OPEN:i32=21; const WRONG_THREAD:i32=22; const BUSY:i32=23;
const EXIT_RELEASED_NO_EFFECT:i32=36;
const CLOSED_NO_EFFECT:i32=24; const PANIC_RETAINED:i32=25;
static OWNER_THREAD:Mutex<Option<ThreadId>>=Mutex::new(None);
enum ExitEligibility{Missing,RootRefusedNoEffect}
static RELEASED:std::sync::atomic::AtomicBool=std::sync::atomic::AtomicBool::new(false);
#[derive(Clone,Copy,Debug,PartialEq,Eq)]enum LocalRustStage{
 TicketReady,PersistOriginalIds,GenerateClassic,InitializePlatform,SealPair,CommitReadback,
 GuardBeforeGeneration,GuardAfterGeneration,GuardAfterInitialize,GuardAfterSeal,GuardAfterCommit,
}
// Private typed cause only. Never a diagnostic permission or JNI/JS payload.
// C first code and Java Throwable remain in their original owners separately.
enum LocalRustCause{
 #[cfg(feature="abi5-final-native-link")] Custody(crate::private_custodian_ffi::CustodyError),
 Controller(ControllerError),PendingJava,NullActualContext,ContainedPanic,
}
struct LocalRustFailure{stage:LocalRustStage,cause:LocalRustCause}
struct LocalOwner { controller:NativeProductController,status:i32,closed:bool,exit:ExitEligibility,genesis:Option<crate::product_controller::RoutingSelector>,first_local_stage_failure:Option<LocalRustFailure>,active_local_stage:Option<LocalRustStage>,enrollment_records:Option<crate::message_enrollment::OriginalEnrollmentRecords>,#[cfg(feature="abi5-final-native-link")]accepted_device:Option<crate::staging::platform::AcceptedDeviceOwner>,#[cfg(feature="abi5-final-native-link")]message_session:Option<crate::staging::platform::MessageSessionOwner> }
fn remember_local_rust_failure(owner:&mut LocalOwner,failure:LocalRustFailure){if owner.first_local_stage_failure.is_none(){owner.first_local_stage_failure=Some(failure)}}
fn retain_local_unknown(owner:&mut LocalOwner,failure:LocalRustFailure)->i32{
 remember_local_rust_failure(owner,failure);if owner.status!=PANIC_RETAINED{owner.status=16}owner.exit=ExitEligibility::Missing;owner.status
}
thread_local! { static LOCAL:RefCell<Option<LocalOwner>>=const{RefCell::new(None)}; }
mod product_ports;
thread_local! { static LOCAL_EXECUTING:std::cell::Cell<bool>=const{std::cell::Cell::new(false)}; }
fn thread_check(bind:bool)->Result<(),i32>{
 if LOCAL_EXECUTING.with(|flag|flag.get()){return Err(BUSY)}
 let mut owner=OWNER_THREAD.lock().map_err(|_|PANIC_RETAINED)?;
 match *owner{Some(t) if t!=std::thread::current().id()=>Err(WRONG_THREAD),Some(_)=>if RELEASED.load(std::sync::atomic::Ordering::Acquire){Err(EXIT_RELEASED_NO_EFFECT)}else{Ok(())},None if bind=>{*owner=Some(std::thread::current().id());Ok(())},None=>Err(NOT_OPEN)}
}
fn native_error(e:NativeProductError)->i32{match e{
 NativeProductError::RequiredRoots(_)=>1,NativeProductError::RequiredStore=>2,NativeProductError::RequiredSnapshot=>3,NativeProductError::RequiredSource=>4,
 NativeProductError::RequiredProtector=>5,NativeProductError::RequiredReceipt=>6,NativeProductError::RequiredBudget=>7,
 NativeProductError::Unknown=>16,NativeProductError::Revoked=>17,NativeProductError::Cancelled=>18,NativeProductError::Binding=>19,NativeProductError::Capacity=>20,
 NativeProductError::PanicRetained=>PANIC_RETAINED,NativeProductError::Consumed=>28,NativeProductError::Retired=>29,NativeProductError::Held=>30,
 NativeProductError::Authentication=>31,NativeProductError::Rejected=>32,
}}
fn controller_error(e:ControllerError)->i32{match e{
 ControllerError::Native(e)=>native_error(e),ControllerError::Capacity=>20,ControllerError::InvalidSelector=>27,ControllerError::WrongPhase=>33,
 ControllerError::NotOpen=>NOT_OPEN,ControllerError::OpenPreviouslyRefused=>26,ControllerError::AdmissionClosed=>34,ControllerError::RequiredLifecycle=>8,
}}
fn open()->i32{
 if let Err(e)=thread_check(true){return e}
 LOCAL.with(|cell|{
  let Ok(mut local)=cell.try_borrow_mut()else{return BUSY};
  if let Some(owner)=local.as_ref(){return owner_status(owner)}
  let controller=match NativeProductController::new(32){Ok(c)=>c,Err(e)=>return controller_error(e)};
  // Install ORIGINAL controller before calling the genuine root constructor.
  *local=Some(LocalOwner{controller,status:PANIC_RETAINED,closed:false,exit:ExitEligibility::Missing,genesis:None,first_local_stage_failure:None,active_local_stage:None,enrollment_records:None,# [cfg(feature="abi5-final-native-link")]accepted_device:None,#[cfg(feature="abi5-final-native-link")]message_session:None});
  let owner=local.as_mut().expect("installed local controller");
  owner.status=match owner.controller.open_native(){Ok(())=>0,Err(ControllerError::Native(NativeProductError::RequiredRoots(_)))=>{owner.exit=ExitEligibility::RootRefusedNoEffect;1},Err(e)=>controller_error(e)};owner.status
 })
}
fn status()->i32{
 if let Err(e)=thread_check(false){return e}
 LOCAL.with(|cell|{let Ok(local)=cell.try_borrow()else{return BUSY};local.as_ref().map(owner_status).unwrap_or(PANIC_RETAINED)})
}
fn close()->i32{
 if let Err(e)=thread_check(false){return e}
 LOCAL.with(|cell|{
  let Ok(mut local)=cell.try_borrow_mut()else{return BUSY};let Some(owner)=local.as_mut()else{return PANIC_RETAINED};
  let observed=owner_status(owner);if observed==16||observed==PANIC_RETAINED{owner.status=observed;owner.exit=ExitEligibility::Missing;return observed}
  #[cfg(feature="abi5-final-native-link")]if owner.accepted_device.is_some()||owner.message_session.is_some(){return 8}
  if owner.closed{return CLOSED_NO_EFFECT}
  if !matches!(owner.exit,ExitEligibility::RootRefusedNoEffect){return 8}
  match owner.controller.close_unopened_no_effect(){Ok(())=>{owner.closed=true;owner.status=CLOSED_NO_EFFECT;CLOSED_NO_EFFECT},Err(e)=>{owner.status=controller_error(e);owner.status}}
 })
}
fn message_required()->i32{
 if let Err(e)=thread_check(false){return e}
 LOCAL.with(|cell|{let Ok(local)=cell.try_borrow()else{return BUSY};let Some(owner)=local.as_ref()else{return PANIC_RETAINED};
  let retained=owner_status(owner);if retained!=0{return retained}
  // Authentic native route/device/source/RNG/message input ports do not exist.
  // Refuse BEFORE inspecting caller array/selector; they cannot mint authority.
  4
 })
}
fn boundary(f:impl FnOnce()->i32)->i32{
 match std::panic::catch_unwind(std::panic::AssertUnwindSafe(f)){
  Ok(code)=>code,Err(payload)=>{
   let _=LOCAL.try_with(|cell|{if let Ok(mut local)=cell.try_borrow_mut(){if let Some(owner)=local.as_mut(){if let Some(stage)=owner.active_local_stage.take(){remember_local_rust_failure(owner,LocalRustFailure{stage,cause:LocalRustCause::ContainedPanic})}#[cfg(feature="predevice-cold-v1")]if let Ok(c)=owner.controller.cold_mut(){c.fail(PANIC_RETAINED);}owner.status=PANIC_RETAINED;owner.exit=ExitEligibility::Missing}}});
   if let Err(_nested)=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||drop(payload))){std::process::abort()}
   PANIC_RETAINED
  }
 }
}
// JNI primitives: jint=int32; jlong=int64; jobject/JNIEnv pointer opaque and
// unused. No field layout, pthread_t or JNI function-table access is guessed.
#[allow(unsafe_code)] #[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeAbiVersion(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{boundary(||2)}
// Feature presence only, never device/source approval or a durable receipt.
// A binary without the real private C/JNI path must not advertise this path.
#[allow(unsafe_code)] #[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeLocalGenesisBindingAbiVersion(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{
 boundary(||{#[cfg(feature="abi5-final-native-link")]{1}#[cfg(not(feature="abi5-final-native-link"))]{0}})
}
#[allow(unsafe_code)] #[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeOpen(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{boundary(open)}
#[allow(unsafe_code)] #[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeStatus(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{boundary(status)}
#[allow(unsafe_code)] #[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeClose(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{boundary(close)}
#[allow(unsafe_code)] #[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativePrepareSend(env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass,selector:i64,payload:jni::sys::jbyteArray)->i32{boundary(||unsafe{prepare_message_input(env,selector,payload,crate::product_message::Direction::Send)})}
#[allow(unsafe_code)] #[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativePrepareReceive(env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass,selector:i64,payload:jni::sys::jbyteArray)->i32{boundary(||unsafe{prepare_message_input(env,selector,payload,crate::product_message::Direction::Receive)})}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn r34_jni_panic_is_not_success(){assert_eq!(boundary(||panic!("public controlled panic")),PANIC_RETAINED)}
 #[test]fn r34_jni_error_mapping_distinct(){assert_eq!(native_error(NativeProductError::Unknown),16);assert_eq!(controller_error(ControllerError::RequiredLifecycle),8);assert_eq!(native_error(NativeProductError::RequiredReceipt),6)}
 #[test]fn r35_closed_retained_state_all_jni_methods(){
  std::thread::spawn(||{
   let env=std::ptr::null_mut();let class=std::ptr::null_mut();
   assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeOpen(env,class),1);
   assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeClose(env,class),24);
   let original=LOCAL.with(|cell|{let local=cell.borrow();&local.as_ref().unwrap().controller as *const NativeProductController});
   assert_eq!(boundary(||panic!("NONSECRET closed-owner contained panic")),25);
   for expected in [25,16]{
    if expected==16{LOCAL.with(|cell|{let mut local=cell.borrow_mut();let owner=local.as_mut().unwrap();owner.status=16;owner.exit=ExitEligibility::Missing;});}
    assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeStatus(env,class),expected);
    assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeOpen(env,class),expected);
    assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeClose(env,class),expected);
    assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativePrepareSend(env,class,0,std::ptr::null_mut()),expected);
    assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativePrepareReceive(env,class,0,std::ptr::null_mut()),expected);
    assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeReleaseNoEffectForThreadExit(env,class),expected);
    assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeAbiVersion(env,class),2);
    LOCAL.with(|cell|{let local=cell.borrow();let owner=local.as_ref().unwrap();assert_eq!(&owner.controller as *const NativeProductController,original);assert!(owner.closed);assert!(matches!(owner.exit,ExitEligibility::Missing));});
    assert!(!RELEASED.load(std::sync::atomic::Ordering::Acquire));
   }
   // Synthetic UNKNOWN classification on an EMPTY controller is not an actual
   // uncertain producer or thread-death recovery test. No worker-exit grant.
  }).join().unwrap();
 }
}

fn owner_status(owner:&LocalOwner)->i32{
 // A contained panic remains dominant over the original C UNKNOWN.
 if owner.status==PANIC_RETAINED{return PANIC_RETAINED}
 #[cfg(feature="abi5-final-native-link")]
 if let Some(s)=owner.genesis.as_ref(){if let Err(ControllerError::Native(NativeProductError::Unknown))=owner.controller.local_genesis_failure(s){return 16}}
 if owner.status==16||owner.status==PANIC_RETAINED{owner.status}else if owner.closed{CLOSED_NO_EFFECT}else{owner.status}
}
fn release_no_effect_for_exit()->i32{
 if let Err(e)=thread_check(false){return e}
 LOCAL.with(|cell|{
  let Ok(mut local)=cell.try_borrow_mut()else{return BUSY};let Some(owner)=local.as_mut()else{return PANIC_RETAINED};
  let observed=owner_status(owner);if observed==16||observed==PANIC_RETAINED{return observed}
  #[cfg(feature="abi5-final-native-link")]if owner.accepted_device.is_some()||owner.message_session.is_some(){return 8}
  if !owner.closed||!matches!(owner.exit,ExitEligibility::RootRefusedNoEffect){return 8}
  if let Err(e)=owner.controller.close_unopened_no_effect(){return controller_error(e)}
  // Typed RootRefusedNoEffect comes ONLY from selected static unavailable
  // root call, not numeric status/UI flags. Recheck no engine/no inventory.
  // The empty controller has no prepared/protector/delivery/foreign owner.
  let released=local.take().expect("same exclusive no-effect owner");drop(released);
  RELEASED.store(true,std::sync::atomic::Ordering::Release);EXIT_RELEASED_NO_EFFECT
 })
}
#[allow(unsafe_code)] #[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeReleaseNoEffectForThreadExit(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{boundary(release_no_effect_for_exit)}

// NEW PRIVATE ABI1, exact supplier-r1 javac-h; old ABI2 unchanged.
fn local_private_status()->i32{
 if let Err(code)=thread_check(false){return code}
 LOCAL.with(|cell|{let Ok(local)=cell.try_borrow()else{return BUSY};let Some(owner)=local.as_ref()else{return PANIC_RETAINED};
  let observed=owner_status(owner);if observed==16||observed==PANIC_RETAINED{return observed}
  if owner.closed{return CLOSED_NO_EFFECT}
  if let Some(selector)=owner.genesis.as_ref(){
   #[cfg(feature="abi5-final-native-link")]
   if matches!(owner.controller.local_genesis_readback_complete(selector),Ok(true)){return 41}
   if observed!=0&&observed!=1&&observed!=44{return observed}44
  }else{40}
 })
}
#[cfg(feature="abi5-final-native-link")]
#[allow(unsafe_code)]
unsafe fn local_private_genesis(env:*mut jni::sys::JNIEnv,class:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject)->i32{
 let raw_env=env;
 if let Err(code)=thread_check(false){return code}
 let prior=local_private_status();if prior!=40{return prior}
 if env.is_null()||class.is_null()||context.is_null()||input.is_null(){return 43}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(env)};
 let outcome=unowned.with_env_no_catch(|env|->jni::errors::Result<i32>{
  let class=unsafe{jni::objects::JClass::from_raw(env,class)};
  let context=unsafe{jni::objects::JObject::from_raw(env,context)};
  let input=unsafe{jni::objects::JObject::from_raw(env,input)};
  // Java input guard validates same command/thread/admission, NOT source auth.
  env.call_method(&input,jni::jni_str!("requireSubmitted"),jni::jni_sig!("()V"),&[])?;
  let command=env.get_field(&input,jni::jni_str!("submittingCommand"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;"))?.l()?;
  let retained=env.get_field(&command,jni::jni_str!("retainedAppContext"),jni::jni_sig!("Landroid/content/Context;"))?.l()?;
  if !env.is_same_object(&context,&retained)?{return Ok(43)}
  env.call_static_method(&class,jni::jni_str!("validateActualContext"),jni::jni_sig!("(Landroid/content/Context;)V"),&[jni::objects::JValue::Object(&context)])?;
  env.call_method(&input,jni::jni_str!("requireSubmitted"),jni::jni_sig!("()V"),&[])?;
  let alias=env.get_field(&input,jni::jni_str!("alias"),jni::jni_sig!("Ljava/lang/String;"))?.l()?;
  let length=env.call_method(&alias,jni::jni_str!("length"),jni::jni_sig!("()I"),&[])?.i()?;
  if length!=("ynx.social.ownkey.v1.".len()+32)as i32{return Ok(43)}
  let generation=env.get_field(&input,jni::jni_str!("storageGeneration"),jni::jni_sig!("J"))?.j()?;
  let window=env.get_field(&input,jni::jni_str!("authWindowSeconds"),jni::jni_sig!("I"))?.i()?;
  if generation<1||!(1..=120).contains(&window){return Ok(43)}
  let association=env.get_field(&input,jni::jni_str!("originalAssociation"),jni::jni_sig!("[B"))?.l()?;
  let association=jni::objects::JByteArray::cast_local(env,association)?;
  let n=env.get_array_length(&association)?;if !(1..=4096).contains(&n){return Ok(43)}
  let alias=jni::objects::JString::cast_local(env,alias)?;
  let alias:String=env.get_string(&alias)?.into();
  let association=env.convert_byte_array(&association)?;
  // All external callbacks completed BEFORE exclusive native inventory borrow.
  env.call_method(&input,jni::jni_str!("requireSubmitted"),jni::jni_sig!("()V"),&[])?;
  // Acquire original command custody BEFORE any Java path preparation.
  // Allocation failure is before directory effects; preserve pending Throwable.
  let global_command=env.new_global_ref(&command)?;
  let global_input=env.new_global_ref(&input)?;
  let checked_input=match crate::private_custodian_ffi::LocalGenesisInput::checked(alias,generation as u64,association,window as u32){Ok(v)=>v,Err(_)=>return Ok(43)};
  let admission=LOCAL.with(|cell|{
   let Ok(mut local)=cell.try_borrow_mut()else{return BUSY};let Some(owner)=local.as_mut()else{return PANIC_RETAINED};
   if owner.status==16||owner.status==PANIC_RETAINED{return owner.status}
   if owner.closed{return CLOSED_NO_EFFECT}
   if owner.genesis.is_some(){return 44}
   let reservation=crate::private_custodian_ffi::LocalGenesisReservation::retain_with_java_command(checked_input,global_command,global_input);
   match owner.controller.reserve_local_genesis(reservation){
    Ok(selector)=>{owner.genesis=Some(selector);owner.exit=ExitEligibility::Missing;let s=owner.genesis.as_ref().expect("same admitted selector");match owner.controller.local_genesis_owner_mut(s).and_then(|r|r.prepare_original_local_intent().map_err(crate::product_controller::local_custody_error)){Ok(())=>44,Err(e)=>{owner.status=controller_error(e);owner.status}}},
    Err((ControllerError::AdmissionClosed,_))=>34,
    Err((_,_))=>43,
   }
  });
  if admission!=44{return Ok(admission)}

  // Same retained input/native IDs and inventory. No LOCAL borrow across Java.
  let binding=with_original_local_execution(|owner|persist_original_ids(owner,|ids|{
   if env.exception_check(){return Err(LocalRustCause::PendingJava)}
   env.call_method(&input,jni::jni_str!("requireSubmitted"),jni::jni_sig!("()V"),&[]).map_err(|_|LocalRustCause::PendingJava)?;
   let array=env.byte_array_from_slice(ids).map_err(|_|LocalRustCause::PendingJava)?;
   let ack=env.call_static_method(jni::jni_str!("com/ynx/social/matrix/VeilLocalGenesisJournalBinding"),jni::jni_str!("persistOriginalNativeIds"),jni::jni_sig!("(Lcom/ynx/social/matrix/VeilLocalGenesisInput;[B)I"),&[jni::objects::JValue::Object(&input),jni::objects::JValue::Object(&array)]).and_then(|v|v.i()).map_err(|_|LocalRustCause::PendingJava)?;
   if env.exception_check(){return Err(LocalRustCause::PendingJava)}
   if ack!=1{return Err(LocalRustCause::Custody(crate::private_custodian_ffi::CustodyError::Foreign(ack)))}
   env.call_method(&input,jni::jni_str!("requireSubmitted"),jni::jni_sig!("()V"),&[]).map_err(|_|LocalRustCause::PendingJava)?;
   if env.exception_check(){return Err(LocalRustCause::PendingJava)}
   Ok(())
  }));
  if binding!=44{return Ok(binding)}

  // No native RefCell borrow spans these REAL Java callbacks. The same cell
  // already holds global_command and original input before directory effects.
  for method in [jni::jni_str!("prepareLocalStore"),jni::jni_str!("useLocalStore")]{
   let result=env.call_method(&command,method,jni::jni_sig!("(Lcom/ynx/social/matrix/VeilLocalGenesisInput;)Lcom/ynx/social/matrix/VeilOwnKeyLocalStoreContext$Outcome;"),&[jni::objects::JValue::Object(&input)])?.l()?;
   if result.is_null(){latch_local_unknown();return Ok(16)}
   let retained_owner=env.call_method(&result,jni::jni_str!("owner"),jni::jni_sig!("()Lcom/ynx/social/matrix/VeilOwnKeyLocalStoreContext$Owner;"),&[])?.l()?;
   let primary=env.call_method(&result,jni::jni_str!("primary"),jni::jni_sig!("()Ljava/lang/Throwable;"),&[])?.l()?;
   if !primary.is_null(){latch_local_unknown();let primary=jni::objects::JThrowable::cast_local(env,primary)?;env.throw(primary)?;return Ok(16)}
   if retained_owner.is_null(){latch_local_unknown();return Ok(16)}
   let state=env.call_method(&result,jni::jni_str!("status"),jni::jni_sig!("()Lcom/ynx/social/matrix/VeilOwnKeyLocalStoreContext$Status;"),&[])?.l()?;
   let name=env.call_method(&state,jni::jni_str!("name"),jni::jni_sig!("()Ljava/lang/String;"),&[])?.l()?;
   let name=jni::objects::JString::cast_local(env,name)?;let name:String=env.get_string(&name)?.into();
   if name!="UNVERIFIED_LOCAL_READY"{latch_local_unknown();return Ok(16)}
  }
  env.call_method(&input,jni::jni_str!("requireSubmitted"),jni::jni_sig!("()V"),&[])?;
if env.exception_check(){latch_local_unknown();return Ok(16)}
  // Entire original controller/inventory stays owned by a local execution
  // guard. LOCAL is NOT borrowed during selected JCA/helper/vtable callbacks.
  Ok(with_original_local_execution(|owner|unsafe{finish_original_local_pair(owner,raw_env,context.as_raw(),||{if env.exception_check(){true}else{env.call_method(&input,jni::jni_str!("requireSubmitted"),jni::jni_sig!("()V"),&[]).is_err()}})}))
 }).into_outcome();

 match outcome{
  jni::Outcome::Ok(code)=>code,
  jni::Outcome::Err(_)=>{LOCAL.with(|cell|{if let Ok(mut local)=cell.try_borrow_mut(){if let Some(owner)=local.as_mut(){owner.status=16;owner.exit=ExitEligibility::Missing}}});16},
  jni::Outcome::Panic(payload)=>std::panic::resume_unwind(payload),
 }
}
#[allow(unsafe_code)]#[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativePrivateAbiVersion(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{boundary(||1)}
#[allow(unsafe_code)]#[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeLocalStatus(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{boundary(local_private_status)}
#[allow(unsafe_code)]#[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeLocalGenesis(env:*mut jni::sys::JNIEnv,class:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject)->i32{
 boundary(||{
  #[cfg(feature="abi5-final-native-link")] {unsafe{local_private_genesis(env,class,context,input)}}
  #[cfg(not(feature="abi5-final-native-link"))] {let _=(env,class,context,input);43}
 })
}
#[cfg(test)]mod r42_private_controls{
 use super::*;
 #[test]fn r42_private_null_refusal_same_existing_actor(){
  std::thread::spawn(||{
   let null=std::ptr::null_mut();assert_eq!(open(),1);
   assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativePrivateAbiVersion(null,std::ptr::null_mut()),1);
   assert_eq!(local_private_status(),40);
   assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeLocalGenesis(null,std::ptr::null_mut(),std::ptr::null_mut(),std::ptr::null_mut()),43);
   LOCAL.with(|cell|{let local=cell.borrow();let owner=local.as_ref().unwrap();assert!(owner.genesis.is_none());assert_eq!(owner.status,1)});
   assert_eq!(close(),24);assert_eq!(local_private_status(),24);
   assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeLocalGenesis(null,std::ptr::null_mut(),std::ptr::null_mut(),std::ptr::null_mut()),24);
  }).join().unwrap();
 }
}

#[cfg(all(test,feature="abi5-final-native-link"))]
mod r44_private_status_controls{
 use super::*;use crate::private_custodian_ffi::{LocalGenesisInput,LocalGenesisReservation};
 #[test]fn r44_private_and_old_status_sync_same_c_unknown(){
  std::thread::spawn(||{
   assert_eq!(open(),1);
   LOCAL.with(|cell|{let mut local=cell.borrow_mut();let owner=local.as_mut().unwrap();
    let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".to_owned(),1,vec![9],30).unwrap_or_else(|_|panic!("metadata"));
    let s=owner.controller.reserve_local_genesis(LocalGenesisReservation::retain(input)).unwrap_or_else(|_|panic!("same inventory"));
    let path=std::ffi::CString::new("relative-public-refusal").unwrap();
    assert!(matches!(owner.controller.local_genesis_owner_mut(&s).unwrap_or_else(|_|panic!("same slot")).reserve_predevice(&path,[1;16],[2;16]),Err(crate::private_custodian_ffi::CustodyError::Unknown)));
    owner.genesis=Some(s);
   });
   assert_eq!(status(),16);assert_eq!(local_private_status(),16);assert_eq!(open(),16);assert_eq!(close(),16);assert_eq!(release_no_effect_for_exit(),16);
  }).join().unwrap();
 }
}

fn latch_local_unknown(){let _=LOCAL.try_with(|cell|{if let Ok(mut local)=cell.try_borrow_mut(){if let Some(owner)=local.as_mut(){owner.status=16;owner.exit=ExitEligibility::Missing}}});}
// EXACT supplier-r2 generated callback ABI. No JNI table or Java factory guessed.
#[cfg(feature="abi5-final-native-link")]
#[allow(unsafe_code)]
unsafe fn store_callback(env:*mut jni::sys::JNIEnv,receiver:jni::sys::jobject,path:jni::sys::jstring,reserve:bool)->i32{
 if let Err(code)=thread_check(false){return code}let prior=local_private_status();if prior!=44{return prior}
 if env.is_null()||receiver.is_null()||(reserve&&path.is_null()){return 43}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(env)};
 let outcome=unowned.with_env_no_catch(|env|->jni::errors::Result<i32>{
  let receiver=unsafe{jni::objects::JObject::from_raw(env,receiver)};
  let command=env.get_field(&receiver,jni::jni_str!("command"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;"))?.l()?;
  let input=env.get_field(&receiver,jni::jni_str!("input"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilLocalGenesisInput;"))?.l()?;
  let original_input=env.get_field(&command,jni::jni_str!("originalInput"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilLocalGenesisInput;"))?.l()?;
  let original_callback=env.get_field(&command,jni::jni_str!("storeCallbacks"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyLocalStoreCallbacks;"))?.l()?;
  if !env.is_same_object(&input,&original_input)?||!env.is_same_object(&receiver,&original_callback)?{return Ok(43)}
  env.call_method(&input,jni::jni_str!("requireSubmitted"),jni::jni_sig!("()V"),&[])?;
  let active=env.get_field(&receiver,jni::jni_str!("pathActive"),jni::jni_sig!("Z"))?.z()?;
  let attempted=env.get_field(&receiver,jni::jni_str!("pathAttempted"),jni::jni_sig!("Z"))?.z()?;
  if reserve&&(!active||!attempted){return Ok(43)}
  let path=if reserve{let path=unsafe{jni::objects::JString::from_raw(env,path)};let n=env.call_method(&path,jni::jni_str!("length"),jni::jni_sig!("()I"),&[])?.i()?;if !(1..=4096).contains(&n){return Ok(43)}let path:String=env.get_string(&path)?.into();match std::ffi::CString::new(path){Ok(p)=>Some(p),Err(_)=>return Ok(43)}}else{None};
  // User-controlled/guard callbacks finished; native borrow begins only now.
  LOCAL.with(|cell|->jni::errors::Result<i32>{
   let Ok(mut local)=cell.try_borrow_mut()else{return Ok(BUSY)};let Some(owner)=local.as_mut()else{return Ok(PANIC_RETAINED)};
   let observed=owner_status(owner);if observed==16||observed==25{return Ok(observed)}if owner.closed{return Ok(24)}
   let Some(selector)=owner.genesis.as_ref()else{return Ok(43)};
   let original=match owner.controller.local_genesis_owner_mut(selector){Ok(v)=>v,Err(e)=>return Ok(controller_error(e))};
   let global=match original.original_java_command(){Ok(v)=>v,Err(_)=>return Ok(43)};
   if !env.is_same_object(&command,global.as_obj())?{return Ok(43)}
   if let Some(path)=path.as_ref(){if let Err(e)=original.reserve_original_context_path(path){owner.status=controller_error(crate::product_controller::local_custody_error(e));owner.exit=ExitEligibility::Missing;return Ok(owner.status)}}
   Ok(44) // Coherence only; caller separately checks actual held native ticket.
  })
 }).into_outcome();
 match outcome{jni::Outcome::Ok(code)=>code,jni::Outcome::Err(_)=>{latch_local_unknown();16},jni::Outcome::Panic(payload)=>std::panic::resume_unwind(payload)}
}
#[allow(unsafe_code)]#[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyLocalStoreCallbacks_nativeStoreCallbackAbiVersion(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{boundary(||1)}
#[allow(unsafe_code)]#[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyLocalStoreCallbacks_nativeRevalidate(env:*mut jni::sys::JNIEnv,receiver:jni::sys::jobject)->i32{boundary(||{
 #[cfg(feature="abi5-final-native-link")] {unsafe{store_callback(env,receiver,std::ptr::null_mut(),false)}}
 #[cfg(not(feature="abi5-final-native-link"))] {let _=(env,receiver);43}
})}
#[allow(unsafe_code)]#[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_matrix_VeilOwnKeyLocalStoreCallbacks_nativeReserveDatabase(env:*mut jni::sys::JNIEnv,receiver:jni::sys::jobject,path:jni::sys::jstring)->i32{boundary(||{
 #[cfg(feature="abi5-final-native-link")] {unsafe{store_callback(env,receiver,path,true)}}
 #[cfg(not(feature="abi5-final-native-link"))] {let _=(env,receiver,path);43}
})}
#[cfg(test)]mod r46_callback_controls{
 use super::*;
 #[test]fn r46_exact_callback_abi_null_no_fake_ticket(){std::thread::spawn(||{
  assert_eq!(open(),1);let null: *mut jni::sys::JNIEnv=std::ptr::null_mut();let object:jni::sys::jobject=std::ptr::null_mut();
  assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyLocalStoreCallbacks_nativeStoreCallbackAbiVersion(null,object),1);
  assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyLocalStoreCallbacks_nativeRevalidate(null,object),40);
  assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyLocalStoreCallbacks_nativeReserveDatabase(null,object,object),40);
  LOCAL.with(|cell|{let local=cell.borrow();assert!(local.as_ref().unwrap().genesis.is_none())});assert_eq!(close(),24);
 }).join().unwrap()}
}

// Private same-executor ownership move, NOT a second actor/registry. Original
// inventory/Global/cipher/C owners stay together. Reentry cannot open/close or
// replace it. Restore before returning OR unwinding to the JNI panic boundary.
struct OriginalLocalExecution{original:Option<LocalOwner>}
impl Drop for OriginalLocalExecution{
 fn drop(&mut self){
  let restored=LOCAL.try_with(|cell|{let Ok(mut local)=cell.try_borrow_mut()else{return false};if local.is_some(){return false}*local=self.original.take();true}).unwrap_or(false);
  if !restored{std::process::abort()} // containment only, NOT durable recovery
  LOCAL_EXECUTING.with(|flag|flag.set(false));
 }
}
fn with_original_local_execution(f:impl FnOnce(&mut LocalOwner)->i32)->i32{
 if LOCAL_EXECUTING.with(|flag|flag.get()){return BUSY}
 let original=LOCAL.with(|cell|{let Ok(mut local)=cell.try_borrow_mut()else{return Err(BUSY)};let original=local.take().ok_or(PANIC_RETAINED)?;LOCAL_EXECUTING.with(|flag|flag.set(true));Ok(original)});
 let original=match original{Ok(v)=>v,Err(code)=>return code};
 let mut guard=OriginalLocalExecution{original:Some(original)};
 f(guard.original.as_mut().expect("sole original execution owner"))
}
#[cfg(feature="abi5-final-native-link")]
#[allow(unsafe_code)]
unsafe fn finish_original_local_pair(owner:&mut LocalOwner,env:*mut jni::sys::JNIEnv,context:jni::sys::jobject,mut pending:impl FnMut()->bool)->i32{
 let observed=owner_status(owner);if observed==16||observed==25{return observed}if owner.closed{return 24}
 // No resolution/retry port: a prior Rust failure cannot start another pair.
 if owner.first_local_stage_failure.is_some(){return owner.status}
 owner.active_local_stage=Some(LocalRustStage::GuardBeforeGeneration);
 let blocked=pending();owner.active_local_stage=None;
 if blocked{return retain_local_unknown(owner,LocalRustFailure{stage:LocalRustStage::GuardBeforeGeneration,cause:LocalRustCause::PendingJava})}
 owner.active_local_stage=Some(LocalRustStage::TicketReady);
 let ticket=check_original_local_ticket(owner);owner.active_local_stage=None;
 if let Err(code)=ticket{return code}
 let Some(selector)=owner.genesis.as_ref()else{return 43};
 if env.is_null()||context.is_null(){return retain_local_unknown(owner,LocalRustFailure{stage:LocalRustStage::InitializePlatform,cause:LocalRustCause::NullActualContext})}
 let result=(||->Result<(),LocalRustFailure>{
  let original=owner.controller.local_genesis_owner_mut(selector).map_err(|cause|LocalRustFailure{stage:LocalRustStage::TicketReady,cause:LocalRustCause::Controller(cause)})?;
  owner.active_local_stage=Some(LocalRustStage::GenerateClassic);
  original.generate_after_durable_reserve().map_err(|cause|LocalRustFailure{stage:LocalRustStage::GenerateClassic,cause:LocalRustCause::Custody(cause)})?;
  owner.active_local_stage=Some(LocalRustStage::GuardAfterGeneration);
  if pending(){return Err(LocalRustFailure{stage:LocalRustStage::GuardAfterGeneration,cause:LocalRustCause::PendingJava})}
  owner.active_local_stage=Some(LocalRustStage::InitializePlatform);
  unsafe{original.initialize_generated(env,context)}.map_err(|cause|LocalRustFailure{stage:LocalRustStage::InitializePlatform,cause:LocalRustCause::Custody(cause)})?;
  owner.active_local_stage=Some(LocalRustStage::GuardAfterInitialize);
  if pending(){return Err(LocalRustFailure{stage:LocalRustStage::GuardAfterInitialize,cause:LocalRustCause::PendingJava})}
  owner.active_local_stage=Some(LocalRustStage::SealPair);
  original.seal_generated().map_err(|cause|LocalRustFailure{stage:LocalRustStage::SealPair,cause:LocalRustCause::Custody(cause)})?;
  owner.active_local_stage=Some(LocalRustStage::GuardAfterSeal);
  if pending(){return Err(LocalRustFailure{stage:LocalRustStage::GuardAfterSeal,cause:LocalRustCause::PendingJava})}
  owner.active_local_stage=Some(LocalRustStage::CommitReadback);
  original.commit_generated().map_err(|cause|LocalRustFailure{stage:LocalRustStage::CommitReadback,cause:LocalRustCause::Custody(cause)})?;
  owner.active_local_stage=Some(LocalRustStage::GuardAfterCommit);
  if pending(){return Err(LocalRustFailure{stage:LocalRustStage::GuardAfterCommit,cause:LocalRustCause::PendingJava})}
  Ok(())
 })();
 owner.active_local_stage=None;owner.exit=ExitEligibility::Missing;
 match result{Ok(())=>41,Err(failure)=>retain_local_unknown(owner,failure)}
}
#[cfg(feature="abi5-final-native-link")]
fn check_original_local_ticket(owner:&mut LocalOwner)->Result<(),i32>{
 if owner.first_local_stage_failure.is_some(){return Err(owner.status)}
 let Some(selector)=owner.genesis.as_ref()else{return Err(43)};
 let ready=(||->Result<(),LocalRustFailure>{
  let original=owner.controller.local_genesis_owner_mut(selector).map_err(|cause|LocalRustFailure{stage:LocalRustStage::TicketReady,cause:LocalRustCause::Controller(cause)})?;
  original.actual_local_ticket_ready().map_err(|cause|LocalRustFailure{stage:LocalRustStage::TicketReady,cause:LocalRustCause::Custody(cause)})
 })();
 if let Err(failure)=ready{
  // Preserve exact gate cause without pretending known missing-ticket means
  // generated/committed UNKNOWN. Inventory remains occupied; no exit grant.
  let code=match &failure.cause{
   LocalRustCause::Custody(crate::private_custodian_ffi::CustodyError::Unknown|crate::private_custodian_ffi::CustodyError::Foreign(_))=>16,
   LocalRustCause::Custody(crate::private_custodian_ffi::CustodyError::Thread)=>19,
   LocalRustCause::Controller(ControllerError::Native(NativeProductError::Unknown))=>16,
   LocalRustCause::Controller(ControllerError::AdmissionClosed)=>34,
   LocalRustCause::Controller(ControllerError::InvalidSelector)=>27,
   _=>8,
  };
  remember_local_rust_failure(owner,failure);owner.status=code;owner.exit=ExitEligibility::Missing;return Err(code)
 }
 Ok(())
}
#[cfg(test)]mod r48_execution_controls{
 use super::*;
 #[test]fn r48_same_controller_reentry_and_unwind_restore(){std::thread::spawn(||{
  assert_eq!(open(),1);
  let before=LOCAL.with(|cell|{let local=cell.borrow();local.as_ref().unwrap().controller.open_attempted_for_r48_test()});
  assert!(before);
  assert_eq!(with_original_local_execution(|owner|{assert!(owner.controller.open_attempted_for_r48_test());assert_eq!(open(),BUSY);assert_eq!(status(),BUSY);assert_eq!(close(),BUSY);assert_eq!(release_no_effect_for_exit(),BUSY);assert!(LOCAL.with(|cell|cell.borrow().is_none()));73}),73);
  assert_eq!(status(),1);assert!(!LOCAL_EXECUTING.with(|flag|flag.get()));
  assert_eq!(boundary(||with_original_local_execution(|owner|{owner.exit=ExitEligibility::Missing;panic!("NONSECRET original execution unwind")})),PANIC_RETAINED);
  assert_eq!(status(),PANIC_RETAINED);assert_eq!(release_no_effect_for_exit(),PANIC_RETAINED);assert!(!LOCAL_EXECUTING.with(|flag|flag.get()));
  LOCAL.with(|cell|{let local=cell.borrow();assert!(local.as_ref().unwrap().controller.open_attempted_for_r48_test())});
 }).join().unwrap()}
}
#[cfg(all(test,feature="abi5-final-native-link"))]mod r49_first_cause_controls{
 use super::*;use crate::private_custodian_ffi::{LocalGenesisInput,LocalGenesisReservation,CustodyError};
 fn owner()->LocalOwner{
  let mut owner=LocalOwner{controller:NativeProductController::new(1).unwrap_or_else(|_|panic!("public inventory")),status:1,closed:false,exit:ExitEligibility::Missing,genesis:None,first_local_stage_failure:None,active_local_stage:None,enrollment_records:None,# [cfg(feature="abi5-final-native-link")]accepted_device:None,#[cfg(feature="abi5-final-native-link")]message_session:None};
  let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".to_owned(),1,vec![1],30).unwrap_or_else(|_|panic!("public metadata"));
  owner.genesis=Some(owner.controller.reserve_local_genesis(LocalGenesisReservation::retain(input)).unwrap_or_else(|_|panic!("same inventory")));owner
 }
 #[test]fn r49_raw_first_pair_memory_phase_not_replaced(){
  // NONSECRET injected Rust errors only, not real OOM/platform/crypto faults.
  for (expected,first) in [(0,CustodyError::Pair),(1,CustodyError::Memory),(2,CustodyError::Phase)]{
   let mut owner=owner();let slot=owner.genesis.as_ref().unwrap().routing_id();
   assert_eq!(retain_local_unknown(&mut owner,LocalRustFailure{stage:LocalRustStage::GenerateClassic,cause:LocalRustCause::Custody(first)}),16);
   assert_eq!(retain_local_unknown(&mut owner,LocalRustFailure{stage:LocalRustStage::InitializePlatform,cause:LocalRustCause::Custody(CustodyError::Foreign(9))}),16);
   assert_eq!(retain_local_unknown(&mut owner,LocalRustFailure{stage:LocalRustStage::GuardAfterSeal,cause:LocalRustCause::PendingJava}),16);
   let failure=owner.first_local_stage_failure.as_ref().unwrap();assert_eq!(failure.stage,LocalRustStage::GenerateClassic);
   let actual=match &failure.cause{LocalRustCause::Custody(CustodyError::Pair)=>0,LocalRustCause::Custody(CustodyError::Memory)=>1,LocalRustCause::Custody(CustodyError::Phase)=>2,_=>panic!("raw cause lost")};assert_eq!(actual,expected);
   assert_eq!(owner.genesis.as_ref().unwrap().routing_id(),slot);assert!(!owner.controller.local_genesis_readback_complete(owner.genesis.as_ref().unwrap()).unwrap_or_else(|_|panic!("same retained slot")));
  }
 }
 #[test]fn r49_actual_missing_ticket_records_phase_without_retry(){
  let mut owner=owner();
  assert_eq!(check_original_local_ticket(&mut owner).unwrap_err(),8);
  let first=owner.first_local_stage_failure.as_ref().unwrap();assert_eq!(first.stage,LocalRustStage::TicketReady);assert!(matches!(first.cause,LocalRustCause::Custody(CustodyError::Phase)));
  let original_failure=owner.first_local_stage_failure.as_ref().unwrap() as *const LocalRustFailure;assert_eq!(check_original_local_ticket(&mut owner).unwrap_err(),8);assert_eq!(original_failure,owner.first_local_stage_failure.as_ref().unwrap() as *const LocalRustFailure);
  assert!(!owner.controller.local_genesis_readback_complete(owner.genesis.as_ref().unwrap()).unwrap_or_else(|_|panic!("same retained slot")));assert!(matches!(owner.exit,ExitEligibility::Missing));
 }
 #[test]fn r49_first_cause_survives_actual_guard_unwind(){std::thread::spawn(||{
  assert_eq!(open(),1);
  assert_eq!(boundary(||with_original_local_execution(|owner|{
   retain_local_unknown(owner,LocalRustFailure{stage:LocalRustStage::GenerateClassic,cause:LocalRustCause::Custody(CustodyError::Memory)});
   owner.active_local_stage=Some(LocalRustStage::InitializePlatform);panic!("NONSECRET later contained panic")
  })),PANIC_RETAINED);
  assert_eq!(status(),PANIC_RETAINED);assert_eq!(release_no_effect_for_exit(),PANIC_RETAINED);
  LOCAL.with(|cell|{let local=cell.borrow();let owner=local.as_ref().unwrap();let first=owner.first_local_stage_failure.as_ref().unwrap();assert_eq!(first.stage,LocalRustStage::GenerateClassic);assert!(matches!(first.cause,LocalRustCause::Custody(CustodyError::Memory)));assert!(owner.active_local_stage.is_none())});
 }).join().unwrap()}
}

#[cfg(all(test,feature="abi5-final-native-link"))]
#[allow(unsafe_code)]
mod r51_review_controls{
 use super::*;
 use crate::private_custodian_ffi::{LocalGenesisInput,LocalGenesisReservation,CustodyError};
 fn isolated(name:&str,f:impl FnOnce()){
  if std::env::var("VEIL_R51_CHILD").as_deref()==Ok(name){f();return}
  let full=format!("product_jni::r51_review_controls::{name}");
  let output=std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact",&full,"--nocapture"]).env("VEIL_R51_CHILD",name).output().unwrap();
  assert!(output.status.success(),"child {:?}\n{}\n{}",output.status,String::from_utf8_lossy(&output.stdout),String::from_utf8_lossy(&output.stderr));
 }
 fn reservation()->LocalGenesisReservation{
  LocalGenesisReservation::retain(LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".to_owned(),1,vec![9],30).unwrap_or_else(|_|panic!("public metadata")))
 }
 fn install()->u64{LOCAL.with(|cell|{
  let mut local=cell.borrow_mut();let owner=local.as_mut().unwrap();
  let selector=owner.controller.reserve_local_genesis(reservation()).unwrap_or_else(|_|panic!("inventory"));let id=selector.routing_id();owner.genesis=Some(selector);id
 })}
 fn disposition(){
  assert_eq!(status(),25);assert_eq!(open(),25);assert_eq!(local_private_status(),25);
  assert_eq!(message_required(),25);assert_eq!(close(),25);assert_eq!(close(),25);assert_eq!(release_no_effect_for_exit(),25);
  let env: *mut jni::sys::JNIEnv=std::ptr::null_mut();let object:jni::sys::jobject=std::ptr::null_mut();
  assert_eq!(Java_com_ynx_social_matrix_VeilOwnKeyPrivateCommand_nativeLocalGenesis(env,object,object,object),25);
 }
 #[test]fn r51_c_unknown_then_panic_same_owner_all_entries(){isolated("r51_c_unknown_then_panic_same_owner_all_entries",||{
  assert_eq!(open(),1);let id=install();
  LOCAL.with(|cell|{let mut local=cell.borrow_mut();let owner=local.as_mut().unwrap();let s=owner.genesis.as_ref().unwrap();
   let path=std::ffi::CString::new("relative-public-refusal").unwrap();
   assert!(matches!(owner.controller.local_genesis_owner_mut(s).unwrap_or_else(|_|panic!("same slot")).reserve_predevice(&path,[1;16],[2;16]),Err(CustodyError::Unknown)));
   remember_local_rust_failure(owner,LocalRustFailure{stage:LocalRustStage::TicketReady,cause:LocalRustCause::Custody(CustodyError::Unknown)});
  });
  assert_eq!(status(),16);
  let first=LOCAL.with(|cell|cell.borrow().as_ref().unwrap().first_local_stage_failure.as_ref().unwrap() as *const LocalRustFailure);
  assert_eq!(boundary(||with_original_local_execution(|owner|{owner.active_local_stage=Some(LocalRustStage::GuardBeforeGeneration);panic!("NONSECRET combined original C UNKNOWN and panic")})),25);
  disposition();
  LOCAL.with(|cell|{let local=cell.borrow();let owner=local.as_ref().unwrap();assert_eq!(owner.genesis.as_ref().unwrap().routing_id(),id);assert_eq!(owner.controller.inventory_for_r51_test(),(1,1));
   assert!(matches!(owner.controller.local_genesis_failure(owner.genesis.as_ref().unwrap()),Err(ControllerError::Native(NativeProductError::Unknown))));
   let cause=owner.first_local_stage_failure.as_ref().unwrap();assert_eq!(first,cause as *const LocalRustFailure);assert_eq!(cause.stage,LocalRustStage::TicketReady);assert!(matches!(cause.cause,LocalRustCause::Custody(CustodyError::Unknown)));assert!(owner.active_local_stage.is_none());
  });
 })}
 #[test]fn r51_actual_first_fence_panic_records_stage(){isolated("r51_actual_first_fence_panic_records_stage",||{
  assert_eq!(open(),1);let id=install();
  assert_eq!(boundary(||with_original_local_execution(|owner|unsafe{finish_original_local_pair(owner,std::ptr::null_mut(),std::ptr::null_mut(),||panic!("NONSECRET first fence panic before JNI/keygen"))})),25);
  disposition();
  assert_eq!(with_original_local_execution(|owner|unsafe{finish_original_local_pair(owner,std::ptr::null_mut(),std::ptr::null_mut(),||panic!("must not retry fence"))}),25);
  LOCAL.with(|cell|{let local=cell.borrow();let owner=local.as_ref().unwrap();assert_eq!(owner.genesis.as_ref().unwrap().routing_id(),id);assert_eq!(owner.controller.inventory_for_r51_test(),(1,1));let first=owner.first_local_stage_failure.as_ref().unwrap();assert_eq!(first.stage,LocalRustStage::GuardBeforeGeneration);assert!(matches!(first.cause,LocalRustCause::ContainedPanic));assert!(owner.active_local_stage.is_none());});
 })}
 #[test]fn r51_normal_fence_and_gate_clear_active_stage(){
  for blocked in [false,true]{
   let mut owner=LocalOwner{controller:NativeProductController::new(1).unwrap_or_else(|_|panic!("inventory")),status:1,closed:false,exit:ExitEligibility::Missing,genesis:None,first_local_stage_failure:None,active_local_stage:None,enrollment_records:None,# [cfg(feature="abi5-final-native-link")]accepted_device:None,#[cfg(feature="abi5-final-native-link")]message_session:None};
   owner.genesis=Some(owner.controller.reserve_local_genesis(reservation()).unwrap_or_else(|_|panic!("inventory")));
   let code=unsafe{finish_original_local_pair(&mut owner,std::ptr::null_mut(),std::ptr::null_mut(),||blocked)};
   assert_eq!(code,if blocked{16}else{8});assert!(owner.active_local_stage.is_none());assert_eq!(owner.controller.inventory_for_r51_test(),(1,1));
   let first=owner.first_local_stage_failure.as_ref().unwrap();assert_eq!(first.stage,if blocked{LocalRustStage::GuardBeforeGeneration}else{LocalRustStage::TicketReady});
  }
 }
}

// Message ABI1 application framing is independent of root/device admission.
fn message_ingress_precheck()->Result<(),i32>{
 thread_check(false)?;
 LOCAL.with(|cell|{let local=cell.try_borrow().map_err(|_|BUSY)?;let owner=local.as_ref().ok_or(PANIC_RETAINED)?;let code=owner_status(owner);if code==0||code==1{Ok(())}else{Err(code)}})
}
fn message_result(owner:&mut LocalOwner,result:Result<crate::product_controller::MessageAdvance,ControllerError>)->i32{
 match result{Ok(crate::product_controller::MessageAdvance::Committed)=>0,Ok(crate::product_controller::MessageAdvance::Held)=>30,Err(e)=>{let code=controller_error(e);if code==25||code==16{if owner.status!=25{owner.status=code}owner.exit=ExitEligibility::Missing;owner.status}else{code}}}
}
#[allow(unsafe_code)]
unsafe fn prepare_message_input(raw_env:*mut jni::sys::JNIEnv,selector:i64,raw:jni::sys::jbyteArray,direction:crate::product_message::Direction)->i32{
 if let Err(code)=message_ingress_precheck(){return code}
 if selector<=0{return 27}if raw_env.is_null()||raw.is_null(){return 32}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(raw_env)};
 let outcome=unowned.with_env_no_catch(|env|->jni::errors::Result<i32>{
  if env.exception_check(){return Ok(32)}
  let array=unsafe{jni::objects::JByteArray::from_raw(env,raw)};
  let n=env.get_array_length(&array)?;
  let max=crate::product_message::HEADER+match direction{crate::product_message::Direction::Send=>crate::product_message::MAX_TEXT,crate::product_message::Direction::Receive=>crate::product_message::MAX_CIPHER};
  if n<crate::product_message::HEADER as i32||n as usize>max{return Ok(32)}
  let mut signed=zeroize::Zeroizing::new(Vec::<i8>::new());
  if signed.try_reserve_exact(n as usize).is_err(){return Ok(20)}signed.resize(n as usize,0);
  env.get_byte_array_region(&array,0,&mut signed[..])?;
  if env.exception_check(){return Ok(32)}
  let mut bytes=zeroize::Zeroizing::new(Vec::<u8>::new());
  if bytes.try_reserve_exact(n as usize).is_err(){return Ok(20)}bytes.extend(signed.iter().map(|b|*b as u8));
  let input=match crate::product_message::MessageInput::decode(bytes,direction){Ok(v)=>v,Err(_)=>return Ok(32)};
  // JNI references and caller arrays are not retained by the async task.
  Ok(with_original_local_execution(|owner|{let code=owner_status(owner);if code!=0{return code}let result=owner.controller.submit_message(selector,input);message_result(owner,result)}))
 }).into_outcome();
 match outcome{jni::Outcome::Ok(code)=>code,jni::Outcome::Err(_)=>32,jni::Outcome::Panic(payload)=>std::panic::resume_unwind(payload)}
}
#[allow(unsafe_code)]#[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeMessageAbiVersion(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{boundary(||1)}
#[allow(unsafe_code)]#[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeAcquireMessageOperation(env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i64{
 let mut selector=0i64;
 let code=boundary(||{if let Err(code)=message_ingress_precheck(){return code}with_original_local_execution(|owner|{
  let code=owner_status(owner);if code!=0{return code}
  if !unsafe{message_env_ready(env)}{return 32}
  match owner.controller.acquire_message(){Ok(s)=>{selector=s.routing_id() as i64;owner.exit=ExitEligibility::Missing;0},Err(e)=>controller_error(e)}
 })});
 if code==0{selector}else{-(code as i64)}
}
#[allow(unsafe_code)]#[unsafe(no_mangle)]
pub extern "system" fn Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeAdvanceMessage(env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass,selector:i64)->i32{
 boundary(||{if let Err(code)=thread_check(false){return code}with_original_local_execution(|owner|{
  let code=owner_status(owner);if code==25{return code}if code!=0&&code!=16{return code}
  // Existing UNKNOWN can query only this retained selector; never acquire/send.
  if !unsafe{message_env_ready(env)}{return 32}
  let result=owner.controller.advance_message(selector);message_result(owner,result)
 })})
}
#[cfg(test)]mod r52_jni_controls{
 use super::*;
 #[test]fn r52_message_missing_root_and_negative_selector_no_authority(){std::thread::spawn(||{
  assert_eq!(open(),1);let env=std::ptr::null_mut();let class=std::ptr::null_mut();
  assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeMessageAbiVersion(env,class),1);
  assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeAcquireMessageOperation(env,class),-1);
  assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativePrepareSend(env,class,0,std::ptr::null_mut()),27);
  assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativePrepareReceive(env,class,1,std::ptr::null_mut()),32);
  assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeAdvanceMessage(env,class,1),1);
  LOCAL.with(|cell|assert_eq!(cell.borrow().as_ref().unwrap().controller.inventory_for_r51_test(),(0,0)));
 }).join().unwrap()}
}

#[allow(unsafe_code)]
unsafe fn message_env_ready(raw:*mut jni::sys::JNIEnv)->bool{
 if raw.is_null(){return false}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(raw)};
 match unowned.with_env_no_catch(|env|->jni::errors::Result<bool>{Ok(!env.exception_check())}).into_outcome(){jni::Outcome::Ok(v)=>v,jni::Outcome::Err(_)=>false,jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}

#[cfg(feature="abi5-final-native-link")]
fn persist_original_ids(owner:&mut LocalOwner,callback:impl FnOnce(&[u8;32])->Result<(),LocalRustCause>)->i32{
 let observed=owner_status(owner);if observed==16||observed==25{return observed}if owner.closed{return 24}
 if owner.first_local_stage_failure.is_some(){return owner.status}
 let Some(selector)=owner.genesis.as_ref()else{return 43};
 owner.active_local_stage=Some(LocalRustStage::PersistOriginalIds);
 let result=(||->Result<(),LocalRustCause>{
  let original=owner.controller.local_genesis_owner_mut(selector).map_err(LocalRustCause::Controller)?;
  let ids=original.begin_original_id_binding().map_err(LocalRustCause::Custody)?;
  callback(&ids)?;
  original.acknowledge_original_id_binding().map_err(LocalRustCause::Custody)
 })();
 owner.active_local_stage=None;owner.exit=ExitEligibility::Missing;
 match result{Ok(())=>44,Err(cause)=>retain_local_unknown(owner,LocalRustFailure{stage:LocalRustStage::PersistOriginalIds,cause})}
}
#[cfg(all(test,feature="abi5-final-native-link"))]mod r54_callback_controls{
 use super::*;use crate::private_custodian_ffi::{LocalGenesisInput,LocalGenesisReservation,CustodyError};
 fn owner()->LocalOwner{
  let mut controller=NativeProductController::new(1).unwrap_or_else(|_|panic!("inventory"));
  let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public metadata"));
  let selector=controller.reserve_local_genesis(LocalGenesisReservation::retain(input)).unwrap_or_else(|_|panic!("reservation"));
  controller.local_genesis_owner_mut(&selector).unwrap_or_else(|_|panic!("same owner")).prepare_original_local_intent().unwrap();
  LocalOwner{controller,status:1,closed:false,exit:ExitEligibility::Missing,genesis:Some(selector),first_local_stage_failure:None,active_local_stage:None,enrollment_records:None,# [cfg(feature="abi5-final-native-link")]accepted_device:None,#[cfg(feature="abi5-final-native-link")]message_session:None}
 }
 #[test]fn r54_binding_abi_has_no_owner_effect(){
  LOCAL.with(|cell|assert!(cell.borrow().is_none()));
  assert_eq!(Java_com_ynx_social_veil_VeilNativeProductControllerBridge_nativeLocalGenesisBindingAbiVersion(std::ptr::null_mut(),std::ptr::null_mut()),1);
  LOCAL.with(|cell|assert!(cell.borrow().is_none()));
 }
 #[test]fn r54_callback_error_preserves_first_owner_and_blocks_repeat(){
  let mut o=owner();let s=o.genesis.as_ref().unwrap().clone();let id=s.routing_id();
  let before=o.controller.fixture_local_binding_retention(&s).unwrap_or_else(|_|panic!("observation"));let mut calls=0;
  assert_eq!(persist_original_ids(&mut o,|ids|{assert_eq!(Some(*ids),before.1);calls+=1;Err(LocalRustCause::PendingJava)}),16);
  assert!(matches!(o.controller.local_genesis_owner_mut(&s),Err(ControllerError::Native(NativeProductError::Unknown))));
  assert_eq!(persist_original_ids(&mut o,|_|{calls+=1;Ok(())}),16);assert_eq!(calls,1);assert_eq!(o.genesis.as_ref().unwrap().routing_id(),id);
  let after=o.controller.fixture_local_binding_retention(&s).unwrap_or_else(|_|panic!("retained observation"));
  assert_eq!((before.0,before.1),(after.0,after.1));assert!(!before.2&&after.2&&after.3);
  assert!(matches!(o.first_local_stage_failure.as_ref().unwrap().cause,LocalRustCause::PendingJava));assert!(o.active_local_stage.is_none());
 }
 #[test]fn r54_callback_panic_retains_attempt_and_active_stage(){
  let o=owner();let s=o.genesis.as_ref().unwrap().clone();let id=s.routing_id();
  let before=o.controller.fixture_local_binding_retention(&s).unwrap_or_else(|_|panic!("observation"));
  LOCAL.with(|cell|{assert!(cell.borrow().is_none());*cell.borrow_mut()=Some(o)});
  let mut calls=0;
  assert_eq!(boundary(||with_original_local_execution(|o|persist_original_ids(o,|ids|{
   assert_eq!(Some(*ids),before.1);calls+=1;panic!("NONSECRET callback unwind")
  }))),PANIC_RETAINED);
  assert_eq!(with_original_local_execution(|o|persist_original_ids(o,|_|{calls+=1;Ok(())})),PANIC_RETAINED);assert_eq!(calls,1);
  LOCAL.with(|cell|{
   let mut local=cell.borrow_mut();let o=local.as_mut().unwrap();assert_eq!(o.genesis.as_ref().unwrap().routing_id(),id);
   assert!(matches!(o.controller.local_genesis_owner_mut(&s),Err(ControllerError::Native(NativeProductError::Unknown))));
   let after=o.controller.fixture_local_binding_retention(&s).unwrap_or_else(|_|panic!("retained observation"));
   assert_eq!((before.0,before.1),(after.0,after.1));assert!(!before.2&&after.2&&after.3);
   let first=o.first_local_stage_failure.as_ref().unwrap();assert_eq!(first.stage,LocalRustStage::PersistOriginalIds);assert!(matches!(first.cause,LocalRustCause::ContainedPanic));
   assert!(o.active_local_stage.is_none());assert_eq!(o.status,PANIC_RETAINED);
   // No C/store/key effects occurred; release test-local public-only custody.
   local.take();
  });
 }
 #[test]fn r54_ack_still_requires_real_ticket_and_closed_calls_nothing(){let mut o=owner();assert_eq!(persist_original_ids(&mut o,|_|Ok(())),44);assert_eq!(check_original_local_ticket(&mut o).unwrap_err(),8);let mut o=owner();o.closed=true;assert_eq!(persist_original_ids(&mut o,|_|panic!("closed callback")),24);assert!(o.first_local_stage_failure.is_none());}
}

#[cfg(feature="abi5-final-native-link")]mod recovery;

#[cfg(feature="predevice-cold-v1")]mod cold_install;
