//! Exact FINAL ABI4 private native call closure. No JNI/public issuer.
//! Successful C mechanics never construct Rust authority or final receipt.
use super::*;
use std::{marker::PhantomData,ptr,rc::Rc};
use super::super::{NativeSnapshotHandle,PortError,validate_computation};
macro_rules! opaque {($($n:ident),*)=>{$(#[repr(C)]struct $n{_opaque:[u8;0]})*};}
opaque!(Admission,Store,Lease,Intent,Step,Inbound,Outbound,Pending,Write,Finish,Lookup,VerifiedCommit);
#[link(name="veil_final_store",kind="static")]
unsafe extern "C"{
 fn veil_store_open_required(a:*const Admission,s:*mut *mut Store)->i32;
 fn veil_native_prepare_intent(s:*mut Store,l:*const Lease,i:*const Intent,p:*mut *mut Pending)->i32;
 fn veil_native_pending_drop(p:*mut *mut Pending)->i32;
 fn veil_native_begin_checked_write(s:*mut Store,l:*const Lease,i:*const Intent,w:*mut *mut Write)->i32;
 fn veil_native_apply_ordered_step(w:*mut Write,s:*const Step)->i32;
 fn veil_native_append_inbox(w:*mut Write,i:*const Inbound)->i32;
 fn veil_native_append_outbox(w:*mut Write,o:*const Outbound)->i32;
 fn veil_native_finish_commit(w:*mut *mut Write,r:*mut *mut Finish)->i32;
 fn veil_native_finish_publish_once(r:*mut Finish,o:*mut *mut VerifiedCommit)->i32;
 fn veil_native_lookup_operation(s:*mut Store,l:*const Lease,i:*const Intent,r:*mut *mut Lookup)->i32;
 fn veil_native_lookup_publish_once(r:*mut Lookup,o:*mut *mut VerifiedCommit)->i32;
 fn veil_native_cancel_operation(w:*mut Write,i:*const Intent)->i32;
 fn veil_native_checked_write_drop(w:*mut *mut Write)->i32;
 fn veil_native_finish_result_drop(r:*mut *mut Finish)->i32;
 fn veil_native_lookup_result_drop(r:*mut *mut Lookup)->i32;
}
const OK:i32=0;const REQUIRED:i32=1;const UNKNOWN:i32=8;
pub(super) fn require_original_store()->Result<Infallible,Dependency>{
 let mut store=ptr::null_mut();
 // SAFETY: normal frozen C accepts absent admission and clears valid output;
 // no DB path/pointer, key, bool or metadata is passed as authorization.
 let status=unsafe{veil_store_open_required(ptr::null(),&mut store)};
 if status==REQUIRED&&store.is_null(){Err(Dependency::OriginalNativeStoreLease)}else{Err(Dependency::NativeAbiInvariant)}
}
// No variants/factory. Only future genuinely admitted private native link may
// replace this seam after ownership/source review. cfg(test) does NOT issue it.
enum NativeIssuerProof{}
// The native issuer must own SAME snapshot, immutable original intent, sealed
// ordered journal+one queue, source lease and C lifetimes in one actor registry.
// Private pointers here have NO getters or byte/metadata factory.
struct IssuedOriginal<'op>{
 proof:NativeIssuerProof,snapshot:&'op NativeSnapshotHandle,
 store:*mut Store,lease:*const Lease,intent:*const Intent,
 journal:Vec<*const Step>,queue:IssuedQueue,actor:PhantomData<Rc<()>>,
}
enum IssuedQueue{Inbox(*const Inbound),Outbox(*const Outbound)}
// Owned foreign slots remain in the operation's private actor retention. No
// automatic Rust Drop claims rollback succeeded or discards uncertain owners.
// No production constructor exists; registry ownership/retirement bridge is
// REQUIRED before issued non-null slots may be admitted, not left to callers.
struct ForeignSlots<'op>{
 original:&'op IssuedOriginal<'op>,pending:*mut Pending,write:*mut Write,
 finish:*mut Finish,lookup:*mut Lookup,unknown:bool,local_finished:bool,
}
#[derive(PartialEq,Eq)]enum MechanicalStatus{Required,Prepared,LocalCommittedOnly,Unknown,NativeError(i32),HeldCleanup(i32)}
impl<'op> ForeignSlots<'op>{
 fn fence(&self)->Result<(),PortError>{validate_computation(self.original.snapshot)}
 fn classify(&mut self,status:i32)->MechanicalStatus{
  if status==UNKNOWN{self.unknown=true;self.original.snapshot.stage.gate.0.borrow_mut().phase=super::super::super::Phase::Unknown;}
  if self.unknown{return MechanicalStatus::Unknown}
  if status==REQUIRED{MechanicalStatus::Required}else{MechanicalStatus::NativeError(status)}
 }
 fn prepare(&mut self)->Result<MechanicalStatus,PortError>{
  self.fence()?;if self.unknown{return Ok(MechanicalStatus::Unknown)}
  // SAFETY: unreachable without private issued owner and same actor pins.
  let status=unsafe{veil_native_prepare_intent(self.original.store,self.original.lease,self.original.intent,&mut self.pending)};
  if status==OK&&!self.pending.is_null(){Ok(MechanicalStatus::Prepared)}else{Ok(self.classify(status))}
 }
 fn begin_original_journal(&mut self)->Result<MechanicalStatus,PortError>{
  self.fence()?;if self.unknown{return Ok(MechanicalStatus::Unknown)}
  // Release RAM pending BEFORE begin; disk original candidate never deleted.
  let release=unsafe{veil_native_pending_drop(&mut self.pending)};
  if release!=OK||!self.pending.is_null(){return Ok(MechanicalStatus::HeldCleanup(release))}
  self.fence()?;
  let status=unsafe{veil_native_begin_checked_write(self.original.store,self.original.lease,self.original.intent,&mut self.write)};
  if status!=OK||self.write.is_null(){return Ok(self.classify(status))}
  if self.original.journal.len()>32{return Err(PortError::Capacity)}
  // Original issuer binds sequence/kind/id/version/policy to original journal;
  // no sorting/coalescing or serializer/key slice callback is introduced.
  for step in &self.original.journal{
   self.fence()?;let status=unsafe{veil_native_apply_ordered_step(self.write,*step)};
   if status!=OK{return Ok(self.classify(status))}
  }
  self.fence()?;
  let status=unsafe{match self.original.queue{IssuedQueue::Inbox(q)=>veil_native_append_inbox(self.write,q),IssuedQueue::Outbox(q)=>veil_native_append_outbox(self.write,q)}};
  if status==OK{Ok(MechanicalStatus::Prepared)}else{Ok(self.classify(status))}
 }
 fn finish_original(&mut self)->Result<MechanicalStatus,PortError>{
  self.fence()?;if self.unknown{return Ok(MechanicalStatus::Unknown)}
  if self.local_finished{return Err(PortError::Consumed)}
  let status=unsafe{veil_native_finish_commit(&mut self.write,&mut self.finish)};
  // A non-null capsule ON ERROR is owned too. Do NOT lose it, retry finish,
  // claim rollback resolves independent CAS, or turn local OK into Applied.
  if !self.finish.is_null(){self.local_finished=true;if status!=OK{self.unknown=true;self.original.snapshot.stage.gate.0.borrow_mut().phase=super::super::super::Phase::Unknown;}}
  if status==OK&&!self.finish.is_null(){Ok(MechanicalStatus::LocalCommittedOnly)}else{Ok(self.classify(status))}
 }
 fn lookup_original(&mut self)->Result<MechanicalStatus,PortError>{
  // Normal computation UNKNOWN cannot authorize recovery. Real source registry
  // recover_committed resolution MUST be supplied before this fenced call.
  self.fence()?;
  if !self.write.is_null()||!self.finish.is_null()||!self.lookup.is_null(){return Err(PortError::Rejected)}
  let status=unsafe{veil_native_lookup_operation(self.original.store,self.original.lease,self.original.intent,&mut self.lookup)};
  // No apply/encrypt/generation reset in lookup, even for PREPARED result.
  if status==OK&&!self.lookup.is_null(){Ok(MechanicalStatus::LocalCommittedOnly)}else{Ok(self.classify(status))}
 }
 fn publish_once(&mut self)->Result<Infallible,PortError>{
  self.fence()?;
  // Final header exposes no admitted Rust verified-receipt ownership transfer
  // or destruction endpoint. Refuse BEFORE irreversible publish side effect;
  // the exact C entrypoints are declared and null refusal is actually tested.
  Err(PortError::RequiredCheckedSqlProducer)
 }
 fn cancel_and_release_ram(&mut self)->MechanicalStatus{
  // This is synchronous under native actor/provider guards. Earliest foreign
  // status preserved; a cleanup refusal retains every non-null pointer here.
  let mut primary=OK;
  if !self.write.is_null(){primary=unsafe{veil_native_cancel_operation(self.write,self.original.intent)};let st=unsafe{veil_native_checked_write_drop(&mut self.write)};if primary==OK{primary=st;}}
  for (slot,dropper) in [(&mut self.finish,veil_native_finish_result_drop as unsafe extern "C" fn(*mut *mut Finish)->i32)]{let st=unsafe{dropper(slot)};if primary==OK{primary=st;}}
  let st=unsafe{veil_native_lookup_result_drop(&mut self.lookup)};if primary==OK{primary=st;}
  let st=unsafe{veil_native_pending_drop(&mut self.pending)};if primary==OK{primary=st;}
  if !self.pending.is_null()||!self.write.is_null()||!self.finish.is_null()||!self.lookup.is_null(){MechanicalStatus::HeldCleanup(primary)}else{self.classify(primary)}
 }
}
#[cfg(test)]pub(super) fn require_after_actual_computation(snapshot:&NativeSnapshotHandle)->Result<Infallible,PortError>{
 validate_computation(snapshot)?;
 match require_original_store(){Ok(never)=>match never{},Err(_)=>Err(PortError::RequiredCheckedSqlProducer)}
}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn abi4_final_actual_normal_store_source_missing(){assert!(matches!(require_original_store(),Err(Dependency::OriginalNativeStoreLease)));}
 #[test]fn abi4_final_actual_unissued_prepare_step_queue_commit_lookup_no_receipt(){
  let(mut p,mut w,mut f,mut l,mut receipt)=(ptr::null_mut(),ptr::null_mut(),ptr::null_mut(),ptr::null_mut(),ptr::null_mut());
  // SAFETY: exact frozen normal ABI accepts null/unissued inputs, valid output
  // slots. No fake non-null handle/fixture lease is ever constructed.
  unsafe{
   assert_eq!(veil_native_prepare_intent(ptr::null_mut(),ptr::null(),ptr::null(),&mut p),REQUIRED);
   assert_eq!(veil_native_begin_checked_write(ptr::null_mut(),ptr::null(),ptr::null(),&mut w),REQUIRED);
   assert_eq!(veil_native_apply_ordered_step(w,ptr::null()),REQUIRED);
   assert_eq!(veil_native_append_inbox(w,ptr::null()),REQUIRED);assert_eq!(veil_native_append_outbox(w,ptr::null()),REQUIRED);
   assert_eq!(veil_native_finish_commit(&mut w,&mut f),REQUIRED);
   assert_eq!(veil_native_finish_publish_once(f,&mut receipt),REQUIRED);
   assert_eq!(veil_native_lookup_operation(ptr::null_mut(),ptr::null(),ptr::null(),&mut l),REQUIRED);
   assert_eq!(veil_native_lookup_publish_once(l,&mut receipt),REQUIRED);
  }
  assert!(p.is_null()&&w.is_null()&&f.is_null()&&l.is_null()&&receipt.is_null());
 }
 #[test]fn abi4_final_actual_null_cleanup_is_not_durable_rollback_receipt(){
  let(mut p,mut w,mut f,mut l)=(ptr::null_mut(),ptr::null_mut(),ptr::null_mut(),ptr::null_mut());
  unsafe{assert_eq!(veil_native_pending_drop(&mut p),OK);assert_eq!(veil_native_checked_write_drop(&mut w),OK);assert_eq!(veil_native_finish_result_drop(&mut f),OK);assert_eq!(veil_native_lookup_result_drop(&mut l),OK);assert_eq!(veil_native_cancel_operation(w,ptr::null()),REQUIRED);}
 }
}
