//! Explicit ABI5 closed consumer. Native issuer and result bridge REQUIRED.
//! No C pointer, source hash, SQL OK or projected bytes issue a native lease.
use std::convert::Infallible;
const ABI:u32=5;
const HEADER_SHA256:&str="2bf311e05acaa079787ed1a976b24bee6ca2150d1860c7bf5a5ac140682c1b8a";
const PRIVATE_HEADER_SHA256:&str="abab9b5d9e2e17ffbbe69e0e0200ba5a0262bed832bc22cb14f10f41cede9ab6";
// Host consumer candidate only; Android consumer execution NOT_RUN.
pub(super) enum Dependency{OriginalNativeStoreLease,CohortIssuer,ProtectedIntentIssuer,IndependentCas,FinalOnceReceiptTransfer,NativeAbiInvariant}
pub(super) fn require_open()->Result<Infallible,Dependency>{
 #[cfg(feature="abi5-final-native-link")]return linked::require_original_store();
 #[cfg(not(feature="abi5-final-native-link"))]Err(Dependency::OriginalNativeStoreLease)
}
#[cfg(feature="abi5-final-native-link")]
#[allow(unsafe_code)] // Narrow reviewed candidate FFI, no public pointer issuer.
mod linked;
#[cfg(feature="abi5-final-native-link")]
pub(crate) use linked::{SourceHeldOriginal,SourcePreparedOwner,SourceCommitOwner,SourceOwnerError};

// Deliberately no success handle implementation: exact ABI5 has no admitted
// constructor into Rust NativeVerifiedAuthority/NativeVerifiedFinalCommit.
// Do not add getters, public authority traits, runtime callback registration,
// fixture linker into normal, or infer success from a non-null C pointer.

#[cfg(all(test,feature="abi5-final-native-link"))]pub(super) fn require_after_actual_computation(s:&super::NativeSnapshotHandle)->Result<Infallible,super::PortError>{linked::require_after_actual_computation(s)}

#[cfg(feature="abi5-final-native-link")]pub(super)type NativeActorSupervisor<'op>=linked::NativeActorRegistry<'op>;
#[cfg(feature="abi5-final-native-link")]pub(super)fn retain_actual_actor<'op>(b:&super::NativeStoreBridge)->Result<NativeActorSupervisor<'op>,super::PortError>{linked::supervisor_for_bridge(b)}

#[cfg(feature="abi5-final-native-link")]pub(crate)use linked::{NativeSnapshotOwner,NativeSnapshotData,SnapshotBytes,ScopedNativeOriginal,ScopedNativeFailure};

#[cfg(feature="abi5-final-native-link")]pub(crate)use linked::{ScopedNativeFinalRequest,NativeFinalAction,NativeFinalObservation};

#[cfg(feature="abi5-final-native-link")]pub(crate)use linked::NativeFinalCommitOwner;

#[cfg(feature="abi5-final-native-link")]pub(crate)use linked::AcceptedDeviceOwner;

#[cfg(feature="abi5-final-native-link")]pub(crate)use linked::{MessageSessionOwner,PersistentMessageProjection};

#[cfg(feature="abi5-final-native-link")]pub(crate)use linked::{OwnedMessageOriginal,OwnedMessageOpenFailure};
