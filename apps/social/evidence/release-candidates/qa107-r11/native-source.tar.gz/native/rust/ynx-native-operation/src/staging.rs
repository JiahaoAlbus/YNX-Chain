//! Dormant operation-private snapshot adapters. No live backing-store reference.
//! Production snapshot acquisition and final fenced producer are REQUIRED.
use async_trait::async_trait;
use libsignal_protocol::*;
use std::{cell::RefCell, rc::Rc};
type R<T> = libsignal_protocol::error::Result<T>;
const MAX_MUTATIONS: usize = 32;
const MAX_BYTES: usize = 4 * 1024 * 1024;
const MAX_WIRE: usize = 1024 * 1024;
#[derive(Clone, Copy, PartialEq, Eq)]
enum Phase { Working, Prepared, Rejected, Unknown, Applied }
// No Debug/Clone/serialization/public byte getters on pending state or journal.
#[derive(Clone)]
enum Mutation {
    Identity(ProtocolAddress, IdentityKey),
    PreKeySave(PreKeyId, PreKeyRecord), PreKeyRemove(PreKeyId),
    KyberSave(KyberPreKeyId, KyberPreKeyRecord),
    KyberUsed(KyberPreKeyId, SignedPreKeyId, PublicKey),
    Session(ProtocolAddress, SessionRecord),
}
struct Pending {
    phase: Phase, binding: [u64; 11], bytes: usize, journal: Vec<Mutation>,
    original_ciphertext: Option<Vec<u8>>, generated_wire: bool, selected_wire_kind: Option<output::SelectedWireKind>, plaintext: Option<Vec<u8>>,
    #[cfg(test)] trigger: Option<(usize, usize)>,
    #[cfg(test)] pending: bool,
}
#[derive(Clone)]
struct Gate(Rc<RefCell<Pending>>, Rc<spqr::ynx_operation::CallScope>);
fn stopped() -> SignalProtocolError {
    SignalProtocolError::InvalidState("native-staging", "operation unavailable".into())
}
impl Gate {
    fn retain_inbound(&self, wire:&[u8])->R<()> {
        self.sync_uncertainty();
        if wire.is_empty()||wire.len()>MAX_WIRE {return Err(stopped())}
        {let mut p=self.0.borrow_mut();if let Some(old)=&p.original_ciphertext {if old.as_slice()!=wire{return Err(stopped())}}else{p.original_ciphertext=Some(wire.to_vec());}}
        self.check()
    }
    fn retain_selected_inbound(&self,wire:&CiphertextMessage)->R<()> {
        self.retain_inbound(wire.serialize())?;
        let kind=output::SelectedWireKind::from_selected(wire)?;
        let mut p=self.0.borrow_mut();
        if p.selected_wire_kind.is_some_and(|old|old!=kind){return Err(stopped())}
        p.selected_wire_kind=Some(kind);Ok(())
    }
    fn sync_uncertainty(&self){if self.1.has_uncertain_outcome(){self.0.borrow_mut().phase=Phase::Unknown;}}
    fn retain_generated(&self,wire:&CiphertextMessage)->R<()> {
        self.sync_uncertainty();
        let mut p=self.0.borrow_mut();
        if let Some(old)=&p.original_ciphertext {if old.as_slice()!=wire.serialize(){return Err(stopped());}}else{p.original_ciphertext=Some(wire.serialize().to_vec());}
        let kind=output::SelectedWireKind::from_selected(wire)?;
        if p.selected_wire_kind.is_some_and(|old|old!=kind){return Err(stopped())}
        p.selected_wire_kind=Some(kind);p.generated_wire=true;
        // Retain exact generated ciphertext even on a policy overrun, then
        // deny admission; this is NOT an all-allocation/memory ceiling.
        if wire.serialize().len()>MAX_WIRE {if p.phase!=Phase::Unknown{p.phase=Phase::Rejected;}return Err(stopped());}
        Ok(())
    }
    fn check(&self) -> R<()> {
        self.sync_uncertainty();
        if self.0.borrow().phase == Phase::Working && self.1.is_live() { Ok(()) } else { Err(stopped()) }
    }
    // Called before the mutation; serialization is native only and bounded.
    fn reserve(&self, bytes: usize) -> R<()> {
        self.check()?;
        let mut p=self.0.borrow_mut();
        if p.journal.len() >= MAX_MUTATIONS || bytes > MAX_BYTES.saturating_sub(p.bytes) {
            p.phase=Phase::Rejected; return Err(stopped());
        }
        p.bytes+=bytes; Ok(())
    }
    async fn append(&self, m: Mutation) -> R<()> {
        self.check()?;
        let mut p=self.0.borrow_mut(); p.journal.push(m);
        #[cfg(test)] if let Some((at, terminal))=p.trigger {
            if p.journal.len()==at { p.phase=if terminal==3 {Phase::Unknown} else {Phase::Rejected}; }
        }
        #[cfg(test)] let transition=p.trigger.filter(|(at,_)|*at==p.journal.len()).map(|(_,v)|v);
        #[cfg(test)] let pending=p.pending;
        drop(p);
        #[cfg(test)] if let Some(v)=transition {match v {0=>self.1.cancel(),1=>self.1.fixture_revoke(),2=>self.1.fixture_rebind(4),_=>self.1.fixture_unknown()}}
        #[cfg(test)] if pending {let mut ready=false;std::future::poll_fn(|cx|{if ready{std::task::Poll::Ready(())}else{ready=true;cx.waker().wake_by_ref();std::task::Poll::Pending}}).await;}
        Ok(())
    }
    fn failed(&self) { self.sync_uncertainty();let mut p=self.0.borrow_mut(); if p.phase!=Phase::Unknown {p.phase=Phase::Rejected;} }
}
// SnapshotBox is never constructible via public caller-provided stores. A real
// producer must supply owned isolated snapshots AND source/auth/CAS binding.
struct Identity { snapshot: Box<dyn IdentityKeyStore>, gate: Gate }
struct EC { snapshot: Box<dyn PreKeyStore>, gate: Gate }
struct Kyber { snapshot: Box<dyn KyberPreKeyStore>, gate: Gate }
struct Sessions { snapshot: Box<dyn SessionStore>, gate: Gate }
#[async_trait(?Send)] impl IdentityKeyStore for Identity {
 async fn get_identity_key_pair(&self)->R<IdentityKeyPair>{self.gate.check()?;let r=self.snapshot.get_identity_key_pair().await;self.gate.check()?;r}
 async fn get_local_registration_id(&self)->R<u32>{self.gate.check()?;let r=self.snapshot.get_local_registration_id().await;self.gate.check()?;r}
 async fn get_identity(&self,a:&ProtocolAddress)->R<Option<IdentityKey>>{self.gate.check()?;let r=self.snapshot.get_identity(a).await;self.gate.check()?;r}
 async fn is_trusted_identity(&self,a:&ProtocolAddress,k:&IdentityKey,d:Direction)->R<bool>{self.gate.check()?;let r=self.snapshot.is_trusted_identity(a,k,d).await;self.gate.check()?;r}
 async fn save_identity(&mut self,a:&ProtocolAddress,k:&IdentityKey)->R<IdentityChange>{
  self.gate.reserve(a.name().len()+k.serialize().len()+32)?;
  let r=self.snapshot.save_identity(a,k).await;
  match r {Ok(v)=>{self.gate.append(Mutation::Identity(a.clone(),*k)).await?;Ok(v)},Err(e)=>{self.gate.failed();Err(e)}}
 }
}
#[async_trait(?Send)] impl PreKeyStore for EC {
 async fn get_pre_key(&self,id:PreKeyId)->R<PreKeyRecord>{self.gate.check()?;let r=self.snapshot.get_pre_key(id).await;self.gate.check()?;r}
 async fn save_pre_key(&mut self,id:PreKeyId,r:&PreKeyRecord)->R<()>{self.gate.reserve(r.serialize()?.len()+16)?;match self.snapshot.save_pre_key(id,r).await{Ok(())=>self.gate.append(Mutation::PreKeySave(id,r.clone())).await,Err(e)=>{self.gate.failed();Err(e)}}}
 async fn remove_pre_key(&mut self,id:PreKeyId)->R<()>{self.gate.reserve(16)?;match self.snapshot.remove_pre_key(id).await{Ok(())=>self.gate.append(Mutation::PreKeyRemove(id)).await,Err(e)=>{self.gate.failed();Err(e)}}}
}
#[async_trait(?Send)] impl KyberPreKeyStore for Kyber {
 async fn get_kyber_pre_key(&self,id:KyberPreKeyId)->R<KyberPreKeyRecord>{self.gate.check()?;let r=self.snapshot.get_kyber_pre_key(id).await;self.gate.check()?;r}
 async fn save_kyber_pre_key(&mut self,id:KyberPreKeyId,r:&KyberPreKeyRecord)->R<()>{self.gate.reserve(r.serialize()?.len()+16)?;match self.snapshot.save_kyber_pre_key(id,r).await{Ok(())=>self.gate.append(Mutation::KyberSave(id,r.clone())).await,Err(e)=>{self.gate.failed();Err(e)}}}
 async fn mark_kyber_pre_key_used(&mut self,k:KyberPreKeyId,e:SignedPreKeyId,b:&PublicKey)->R<()>{
  self.gate.reserve(b.serialize().len()+32)?;
  // Preserve the snapshot provider's actual one-time/last-resort validation.
  // A live-store probe here would itself consume state and is forbidden.
  match self.snapshot.mark_kyber_pre_key_used(k,e,b).await{Ok(())=>self.gate.append(Mutation::KyberUsed(k,e,*b)).await,Err(err)=>{self.gate.failed();Err(err)}}
 }
}
#[async_trait(?Send)] impl SessionStore for Sessions {
 fn retain_native_ciphertext(&mut self,wire:&CiphertextMessage)->R<()>{self.gate.retain_generated(wire)}
 async fn load_session(&self,a:&ProtocolAddress)->R<Option<SessionRecord>>{self.gate.check()?;let r=self.snapshot.load_session(a).await;self.gate.check()?;r}
 async fn store_session(&mut self,a:&ProtocolAddress,r:&SessionRecord)->R<()>{
  self.gate.reserve(r.serialize()?.len()+a.name().len()+32)?;
  match self.snapshot.store_session(a,r).await{Ok(())=>self.gate.append(Mutation::Session(a.clone(),r.clone())).await,Err(e)=>{self.gate.failed();Err(e)}}
 }
}
struct StagedOperation { identity: Identity, ec: EC, kyber: Kyber, sessions: Sessions, gate: Gate }
impl StagedOperation {
 // Called only after actual protocol success. This is preparation, NOT commit,
 // authenticated source proof, device authorization, or capability issuance.
 fn prepare(&mut self, wire: &[u8], plaintext: Option<Vec<u8>>) -> R<()> {
  self.gate.check()?;
  let mut p=self.gate.0.borrow_mut();
  if wire.is_empty() || wire.len()>MAX_WIRE || plaintext.as_ref().is_some_and(|v|v.len()>MAX_WIRE) {p.phase=Phase::Rejected;return Err(stopped());}
  if let Some(original)=&p.original_ciphertext {if original.as_slice()!=wire{p.phase=Phase::Rejected;return Err(stopped());}}
  else {p.original_ciphertext=Some(wire.to_vec());}
  p.plaintext=plaintext; p.phase=Phase::Prepared; Ok(())
 }
 fn reject(&mut self) {self.gate.failed();}
 // Unknown is sticky. It cannot be converted to NOT_APPLIED by cancellation.
 fn cancel(&mut self) {self.gate.failed();}
 fn final_producer(&mut self) -> Result<(), crate::OperationError> {
  // There is intentionally no trait implemented by a fixture here.
  Err(crate::OperationError::Required([
   crate::RequiredProvider::NativeDeviceAuthorityV1,
   crate::RequiredProvider::TrustedRevocationCheckpointV1,
   crate::RequiredProvider::ProtectedAtomicSessionInboxOutboxCommitV1,
   crate::RequiredProvider::SourceBoundDurableObserverProvenanceV1,
  ]))
 }
}
#[cfg(test)] mod tests;

pub(crate) mod platform;

impl Drop for StagedOperation {fn drop(&mut self){self.gate.sync_uncertainty();}}

pub(crate) mod cohort;

// Native product actor facade; constructors delegate unchanged genuine gates.
pub(crate) mod product_facade;

pub(crate) mod output;
