//! Same existing recovery owner, not a second actor or an authorization factory.
//! Only public request material is retained. No signing occurs in this module.
use super::*;
use crate::source_evidence::{self,SourceSelection,UnadmittedSourceEvidence};
use base64::{Engine as _,engine::general_purpose::URL_SAFE_NO_PAD as B64};
use rand::TryRngCore;
use sha2::Digest as _;
use std::time::{Duration,Instant};

pub(in crate::private_custodian_ffi) struct PendingSourceFacts {
 selection:SourceSelection, operation:String, proposal:Box<[u8]>,
 issuer:Box<[u8]>,target:Box<[u8]>,nonce:[u8;32],ready:bool,entropy_attempted:bool,
 issued:i64,expires:i64,started:Instant,remaining:Duration,
 cancelled:bool,evidence:Option<UnadmittedSourceEvidence>,account_lifetime:Option<crate::account_evidence::RequestLifetime>,
 account_borrow:Option<jni::objects::Global<jni::objects::JObject<'static>>>,
 account_attempt:Option<std::rc::Rc<crate::account_instance::Attempt>>,
 account_evidence:Option<crate::account_evidence::UnadmittedAccountEvidence>,
}
pub(in crate::private_custodian_ffi)struct PendingSourceRequest{
 facts:PendingSourceFacts,
 #[cfg(feature="abi5-final-native-link")]signing:Option<crate::source_infrastructure::platform::OriginalSigningGuard>,
 #[cfg(feature="abi5-final-native-link")]signing_acquire_attempted:bool,
}
impl std::ops::Deref for PendingSourceRequest{type Target=PendingSourceFacts;fn deref(&self)->&Self::Target{&self.facts}}
impl std::ops::DerefMut for PendingSourceRequest{fn deref_mut(&mut self)->&mut Self::Target{&mut self.facts}}
impl PendingSourceFacts {
 // Private shared ordering body, not a caller-provided authorization hook.
 // Tests supply only PUBLIC entropy/time substitutes; production uses OsRng.
 fn publish_nonce(&mut self,entropy:impl FnOnce(&mut [u8;32])->Result<(),CustodyError>,clock:impl FnOnce()->Result<i64,CustodyError>)->Result<[u8;32],CustodyError>{
  if !self.entropy_attempted {
   self.entropy_attempted=true;
   entropy(&mut self.nonce)?;
   self.ready=true;
  }
  self.live(clock()?)?;
  Ok(self.nonce)
 }

 fn check(&self,selection:&SourceSelection,issuer:&[u8],target:&[u8])->Result<(),CustodyError>{
  if &self.selection!=selection||self.issuer.as_ref()!=issuer||self.target.as_ref()!=target{return Err(CustodyError::Pair)}
  self.live(source_evidence::now_ms().map_err(|_|CustodyError::Phase)?)
 }
 fn live(&self,now:i64)->Result<(),CustodyError>{
  // RNG failure remains retained and cannot be retried with a new nonce.
  if !self.ready{return Err(CustodyError::Unknown)}
  if self.cancelled||now<self.issued||now>=self.expires||self.started.elapsed()>=self.remaining{return Err(CustodyError::Phase)}
  Ok(())
 }
 fn matches_pair(&self,classic:&[u8],pq:&[u8],ids:&[u8;32])->bool{
  &self.proposal[..33]==classic&&&self.proposal[33..2625]==pq&&&self.proposal[2625..]==ids
 }
}
fn pair_messages<'a>(issuer:&'a[u8],target:&'a[u8],classic:&[u8],pq:&[u8],now:i64)->Result<(i64,i64),CustodyError>{
 let i=Type4::parse(issuer)?;let t=Type4::parse(target)?;
 if !i.issuer||t.issuer||i.transcript!=t.transcript||i.classic!=classic||t.classic!=classic||i.pq!=pq||t.pq!=pq{return Err(CustodyError::Pair)}
 let a=frame::<16>(i.transcript,3)?;
 // This first-device request cannot silently become add/revoke/migration.
 if a[3]!=b"enroll"{return Err(CustodyError::Phase)}
 let issued=number(a[11],0)? as i64;let expires=number(a[12],0)? as i64;
 if now<issued||now>=expires{return Err(CustodyError::Phase)}
 Ok((issued,expires))
}
impl recovery::RecoveryLoan<'_>{
 /// Normal private entry. Parses untrusted prepared messages, but derives the
 /// pair and operation from this actual authenticated local custody owner.
 /// The selection is NOT admitted; the response still needs pinned profiles.
 pub(crate) fn begin_source_current_request(&mut self,selection:SourceSelection,issuer:&[u8],target:&[u8])->Result<[u8;32],CustodyError>{
  if self.0.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  let public=self.public_pair()?;
  let started=Instant::now();
  let now=source_evidence::now_ms().map_err(|_|CustodyError::Phase)?;
  let (issued,expires)=pair_messages(issuer,target,&public.classic,&public.pq,now)?;
  first_genesis::inspect(issuer,target)?;
  if let Some(p)=self.0.source_request.as_ref(){
   p.check(&selection,issuer,target)?;
   if !p.matches_pair(&public.classic,&public.pq,public.operation){return Err(CustodyError::Pair)}
   return Ok(p.nonce)
  }
  let operation=format!("fd1-{}",B64.encode(public.operation));
  let mut proposal=Vec::with_capacity(2657);proposal.extend(public.classic);proposal.extend(public.pq);proposal.extend(public.operation);
  // Retain before entropy attempt. Failure leaves the same unusable request;
  // no entropy retry, replacing intent, or clearing genesis UNKNOWN.
  self.0.source_request=Some(PendingSourceRequest{facts:PendingSourceFacts{selection,operation,proposal:proposal.into_boxed_slice(),issuer:issuer.into(),target:target.into(),nonce:[0;32],ready:false,entropy_attempted:false,issued,expires,started,remaining:Duration::from_millis((expires-now) as u64),cancelled:false,evidence:None,account_lifetime:None,account_borrow:None,account_attempt:None,account_evidence:None},#[cfg(feature="abi5-final-native-link")]signing:None,#[cfg(feature="abi5-final-native-link")]signing_acquire_attempted:false});
  let p=self.0.source_request.as_mut().ok_or(CustodyError::Phase)?;
  p.publish_nonce(|nonce|rand::rngs::OsRng.try_fill_bytes(nonce).map_err(|_|CustodyError::Unknown),||source_evidence::now_ms().map_err(|_|CustodyError::Phase))
 }
 /// Read-only transport nonce; not a proof, permission, or pointer export.
 pub(crate) fn original_source_nonce(&self)->Result<[u8;32],CustodyError>{
  if self.0.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  let public=self.public_pair()?;let p=self.0.source_request.as_ref().ok_or(CustodyError::Phase)?;
  p.live(source_evidence::now_ms().map_err(|_|CustodyError::Phase)?)?;
  if !p.matches_pair(&public.classic,&public.pq,public.operation){return Err(CustodyError::Pair)}Ok(p.nonce)
 }
 /// Borrow the actual retained request clock, not caller timestamps. Lazy
 /// installation preserves ORIGINAL started/budget, including elapsed time.
 pub(crate) fn retain_original_account_lifetime(&mut self)->Result<&crate::account_evidence::RequestLifetime,CustodyError>{
  self.original_source_nonce()?;
  let p=self.0.source_request.as_mut().ok_or(CustodyError::Phase)?;
  if p.account_lifetime.is_none(){p.account_lifetime=Some(crate::account_evidence::RequestLifetime::retain(p.started,p.remaining));}
  p.account_lifetime.as_ref().ok_or(CustodyError::Phase)
 }
 /// Normal response consumer.
 /// No caller-supplied expected nonce/keys/operation.
 /// Evidence remains UNADMITTED and owned; no AuthorizedType4 is constructed.
 pub(crate) fn accept_source_current_response(&mut self,raw:&[u8])->Result<(),source_evidence::Error>{
  self.original_source_nonce().map_err(|_|source_evidence::Error::Binding)?;
  let p=self.0.source_request.as_mut().ok_or(source_evidence::Error::Binding)?;
  let evidence=p.selection.verify(raw,&p.operation,&p.proposal,&p.issuer,&p.target,&p.nonce)?;
  #[cfg(feature="abi5-final-native-link")]if p.signing_acquire_attempted{return Err(source_evidence::Error::Binding)}
  // Once the same request has retained the new pending proof, a refresh may
  // never silently downgrade it to the earlier unadmitted source-only carrier.
  if p.evidence.as_ref().is_some_and(|old|old.has_pending())&&!evidence.has_pending(){return Err(source_evidence::Error::Binding)}
  // Pending v1 remains legacy observation; it cannot replace the complete
  // exact-prefix custody already retained by this SAME immutable request.
  if p.evidence.as_ref().is_some_and(|old|old.has_namespace_prefix())&&!evidence.has_namespace_prefix(){return Err(source_evidence::Error::Binding)}
  // The initial source-only intake precedes account capture. After genuine
  // account facts have been retained, a refresh MUST carry the new pending
  // proof; a second source-only response cannot complete this next phase.
  if p.account_evidence.is_some()&&!evidence.has_pending(){return Err(source_evidence::Error::Binding)}
  if let Some(account)=p.account_evidence.as_ref(){evidence.check_pending_account(account)?;}
  first_genesis::inspect(&p.issuer,&p.target).map_err(|_|source_evidence::Error::Binding)?.check_source(&evidence)?;
  evidence.recheck(&p.operation)?;
  p.live(source_evidence::now_ms()?).map_err(|_|source_evidence::Error::Window)?;
  // No callbacks or foreign effects occur between these checks and retention.
  p.evidence=Some(evidence);Ok(())
 }
 /// Final publication fence, after ALL Java callbacks. This does not resolve
 /// UNKNOWN or authorize signing; both retained lifetimes must remain valid.
 pub(crate) fn recheck_source_current_evidence(&self)->Result<(),source_evidence::Error>{
  self.original_source_nonce().map_err(|_|source_evidence::Error::Binding)?;
  let p=self.0.source_request.as_ref().ok_or(source_evidence::Error::Binding)?;
  let e=p.evidence.as_ref().ok_or(source_evidence::Error::Binding)?;
  e.recheck(&p.operation)?;
  // Account intake may precede the pending source refresh. Once independently
  // verified account facts are retained, every source publication (including
  // the post-Java-callback fence) must keep the SAME capture/join current.
  // No account yet is not device authorization and remains unadmitted.
  if let Some(account)=p.account_evidence.as_ref(){
   account.recheck_with_original(&p.operation,p.account_attempt.as_deref()).map_err(|_|source_evidence::Error::Binding)?;
   if e.has_pending(){e.check_pending_account(account)?;}
  }
  Ok(())
 }
 pub(crate) fn cancel_source_current_request(&mut self)->Result<(),CustodyError>{
  if self.0.thread!=std::thread::current().id(){return Err(CustodyError::Thread)}
  let p=self.0.source_request.as_mut().ok_or(CustodyError::Phase)?;p.cancelled=true;if let Some(owner)=&p.account_lifetime{owner.cancel();}
  #[cfg(feature="abi5-final-native-link")]if let Some(guard)=&p.signing{guard.invalidate();}
  Ok(())
 }
}
#[cfg(test)]mod request_controls{
 use super::*;
 fn message(role:&[u8],purpose:&[u8],nonce:u8)->Vec<u8>{
  fn f(kind:u8,fields:&[&[u8]])->Vec<u8>{let mut v=b"YPA1".to_vec();v.extend([kind,1]);v.extend((fields.len()as u16).to_be_bytes());for(i,b)in fields.iter().enumerate(){v.extend(((i+1)as u16).to_be_bytes());v.extend((b.len()as u32).to_be_bytes());v.extend(*b)}v}
  let mut c=[9;33];c[0]=5;let one=1u64.to_be_bytes();let two=2u64.to_be_bytes();let p=f(1,&[b"identity",b"device",b"LIBSIGNAL-0.104.0-XEDDSA-CANDIDATE",&c,b"ML-DSA-87",&[7;2592],&one,&one,&one,&[1;32],&[2;32],b"route"]);
  let a=f(3,&[b"YNX-SOCIAL",b"realm",&one,b"enroll",&p,&p,&[1;32],&[2;32],&one,&two,&[nonce;32],&100u64.to_be_bytes(),&200u64.to_be_bytes(),&[4;32],b"set",b""]);
  f(4,&[b"YNX/SOCIAL/PQ-AUTH/SIGN/V1",purpose,role,&a])
 }
 fn selection()->SourceSelection{SourceSelection::checked(br#"{"source":"s","store":"s","schema":"s","inode":"s","restore":"s","sourceGeneration":1,"nativeRestoreIncarnation":1}"#,&"a".repeat(64),&"b".repeat(64)).unwrap()}
 #[test]fn request_controls_same_original_pair_and_messages(){
  let i=message(b"issuer",b"authorization",3);let t=message(b"target",b"possession",3);let mut c=[9;33];c[0]=5;
  assert_eq!(pair_messages(&i,&t,&c,&[7;2592],100),Ok((100,200)));
  assert!(pair_messages(&i,&message(b"target",b"possession",4),&c,&[7;2592],100).is_err());
  assert!(pair_messages(&t,&i,&c,&[7;2592],100).is_err());assert!(pair_messages(&i,&t,&c,&[8;2592],100).is_err());
  assert!(pair_messages(&i,&t,&c,&[7;2592],99).is_err());assert!(pair_messages(&i,&t,&c,&[7;2592],200).is_err());
 }
 #[test]fn request_controls_failed_entropy_cancel_and_pair_retention(){
  let mut p=PendingSourceRequest{facts:PendingSourceFacts{selection:selection(),operation:"original".into(),proposal:vec![7;2657].into_boxed_slice(),issuer:vec![1].into_boxed_slice(),target:vec![2].into_boxed_slice(),nonce:[9;32],ready:false,entropy_attempted:true,issued:100,expires:200,started:Instant::now(),remaining:Duration::from_secs(30),cancelled:false,evidence:None,account_lifetime:None,account_borrow:None,account_attempt:None,account_evidence:None},#[cfg(feature="abi5-final-native-link")]signing:None,#[cfg(feature="abi5-final-native-link")]signing_acquire_attempted:false};
  assert_eq!(p.live(100),Err(CustodyError::Unknown));p.cancelled=true;assert_eq!(p.live(100),Err(CustodyError::Unknown));
  assert_eq!(p.nonce,[9;32]);assert_eq!(p.proposal.len(),2657);
  p.ready=true;assert_eq!(p.live(100),Err(CustodyError::Phase));p.cancelled=false;assert_eq!(p.live(100),Ok(()));
  assert!(p.matches_pair(&[7;33],&[7;2592],&[7;32]));assert!(!p.matches_pair(&[7;33],&[7;2592],&[8;32]));
 }
 #[test]fn request_controls_response_cannot_fill_expectations(){
  let s=selection();assert!(matches!(s.verify(b"{}","original",&[0;2657],b"i",b"t",&[9;32]),Err(source_evidence::Error::Canonical)));
  assert!(SourceSelection::checked(b"{}",&"a".repeat(64),&"b".repeat(64)).is_err());
 }
}
#[cfg(test)]mod nonce_publication_controls{
 use super::*;use std::cell::Cell;
 fn original()->PendingSourceRequest{
  PendingSourceRequest{facts:PendingSourceFacts{selection:SourceSelection::checked(br#"{"source":"s","store":"s","schema":"s","inode":"s","restore":"s","sourceGeneration":1,"nativeRestoreIncarnation":1}"#,&"a".repeat(64),&"b".repeat(64)).unwrap(),operation:"original".into(),proposal:vec![7;2657].into_boxed_slice(),issuer:vec![1].into_boxed_slice(),target:vec![2].into_boxed_slice(),nonce:[0;32],ready:false,entropy_attempted:false,issued:100,expires:200,started:Instant::now(),remaining:Duration::from_secs(30),cancelled:false,evidence:None,account_lifetime:None,account_borrow:None,account_attempt:None,account_evidence:None},#[cfg(feature="abi5-final-native-link")]signing:None,#[cfg(feature="abi5-final-native-link")]signing_acquire_attempted:false}
 }
 #[test]fn postcallback_controls_cancel_keeps_original(){
  let p=std::cell::RefCell::new(original());p.borrow_mut().publish_nonce(|n|{n.fill(7);Ok(())},||Ok(150)).unwrap();
  assert_eq!(source_evidence::after_callbacks(||{p.borrow_mut().cancelled=true;Ok(())},||p.borrow().live(150)),Err(CustodyError::Phase));
  assert_eq!(p.borrow().nonce,[7;32]);assert!(p.borrow().entropy_attempted);assert_eq!(p.borrow().operation,"original");
 }
 #[test]fn nonce_publication_controls_post_entropy_wall_fence_and_once(){
  for (after,expected) in [(200,Err(CustodyError::Phase)),(199,Ok([7;32])),(99,Err(CustodyError::Phase))]{
   let mut p=original();let calls=Cell::new(0);let clock=Cell::new(100);
   assert_eq!(p.publish_nonce(|out|{calls.set(calls.get()+1);out.fill(7);clock.set(after);Ok(())},||Ok(clock.get())),expected);
   assert_eq!(calls.get(),1);assert_eq!(p.nonce,[7;32]);assert!(p.entropy_attempted);
   let _=p.publish_nonce(|_|{calls.set(calls.get()+1);panic!("must never retry entropy")},||Ok(after));
   assert_eq!(calls.get(),1);assert_eq!(p.nonce,[7;32]);
  }
 }
 #[test]fn nonce_publication_controls_original_monotonic_and_entropy_failure(){
  let mut p=original();p.started=Instant::now()-Duration::from_secs(31);
  assert_eq!(p.publish_nonce(|n|{n.fill(8);Ok(())},||Ok(150)),Err(CustodyError::Phase));assert_eq!(p.nonce,[8;32]);
  let mut p=original();assert_eq!(p.publish_nonce(|n|{n[0]=9;Err(CustodyError::Unknown)},||Ok(150)),Err(CustodyError::Unknown));
  assert_eq!(p.publish_nonce(|_|panic!("failed attempt retained"),||Ok(150)),Err(CustodyError::Unknown));assert_eq!(p.nonce[0],9);
 }
}

impl recovery::RecoveryLoan<'_>{
 // Local request retention only, no account source or service-instance proof.
 pub(crate) fn account_transport_window(&self,issuer:&[u8],target:&[u8])->Result<crate::account_https::Window,CustodyError>{
  self.original_source_nonce()?;
  let p=self.0.source_request.as_ref().ok_or(CustodyError::Phase)?;
  if p.issuer.as_ref()!=issuer||p.target.as_ref()!=target{return Err(CustodyError::Pair)}
  Ok(crate::account_https::Window{start:p.started,budget:p.remaining,issued:p.issued,expires:p.expires})
 }
 pub(crate) fn hold_account_transport_borrow(&mut self,env:&mut jni::Env<'_>,borrow:jni::objects::Global<jni::objects::JObject<'static>>)->jni::errors::Result<bool>{
  if self.original_source_nonce().is_err(){return Ok(false)}
  let Some(p)=self.0.source_request.as_mut()else{return Ok(false)};
  if let Some(old)=p.account_borrow.as_ref(){return env.is_same_object(old.as_obj(),borrow.as_obj())}
  p.account_borrow=Some(borrow);Ok(true)
 }
}

#[derive(serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct AccountOriginalBody{operation:String,proposal:String,nonce:String,#[serde(rename="requestDigest")]request_digest:String,#[serde(rename="issuedAtMs")]issued:String,#[serde(rename="expiresMs")]expires:String}
impl recovery::RecoveryLoan<'_>{
 pub(crate) fn begin_account_exchange(&mut self,bootstrap:crate::account_instance::Bootstrap,cookie:zeroize::Zeroizing<Vec<u8>>,body:zeroize::Zeroizing<Vec<u8>>,revision:u64)->Result<std::rc::Rc<crate::account_instance::Attempt>,CustodyError>{
  self.original_source_nonce()?;
  let p=self.0.source_request.as_mut().ok_or(CustodyError::Phase)?;
  if p.account_attempt.is_some(){return Err(CustodyError::Unknown)}
  if body.is_empty()||body.len()>8192||cookie.len()>8192{return Err(CustodyError::Bounds)}
  let wire:AccountOriginalBody=serde_json::from_slice(&body).map_err(|_|CustodyError::Pair)?;
  let i=Type4::parse(&p.issuer)?;let a=frame::<16>(i.transcript,3)?;let principal=principal(a[4])?;
  let nonce:[u8;32]=a[10].try_into().map_err(|_|CustodyError::Pair)?;
  let digest=crate::account_instance::hash(&p.proposal);
  if wire.operation!=p.operation||wire.proposal!=B64.encode(&p.proposal)||wire.nonce!=B64.encode(nonce)||wire.request_digest!=B64.encode(sha2::Sha256::digest(&p.proposal))||wire.issued!=p.issued.to_string()||wire.expires!=p.expires.to_string(){return Err(CustodyError::Pair)}
  let login=crate::account_instance::login_digest(&cookie).map_err(|_|CustodyError::Pair)?;
  let identity=std::str::from_utf8(principal[0]).map_err(|_|CustodyError::Pair)?;
  let device=std::str::from_utf8(principal[1]).map_err(|_|CustodyError::Pair)?;
  let commitment=|role:&str,bytes:&[u8]|{let mut v=format!("YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_{role}_V1\n").into_bytes();v.extend(bytes);crate::account_instance::hash(&v)};
  if revision==0||revision>((1u64<<53)-1)||p.issued<0||p.expires as u64>((1u64<<53)-1){return Err(CustodyError::Pair)}
  let expected=serde_json::json!({"requestId":p.operation,"operation":p.operation,"loginInstanceDigest":login,"nativeRequestDigest":crate::account_instance::hash(&body),"challengeNonce":wire.nonce,"challengeRequestDigest":digest,"preparedRevision":revision.to_string(),"identity":identity,"device":device,"issuerMessageDigest":commitment("ISSUER",&p.issuer),"targetMessageDigest":commitment("TARGET",&p.target)});
  let request=crate::account_instance::Request{expected,nonce,body,cookie,issued:p.issued as u64,expires:p.expires as u64};
  let window=crate::account_https::Window{start:p.started,budget:p.remaining,issued:p.issued,expires:p.expires};
  p.live(source_evidence::now_ms().map_err(|_|CustodyError::Phase)?)?;
  let attempt=crate::account_instance::Attempt::new(bootstrap,request,window);p.account_attempt=Some(attempt.clone());Ok(attempt)
 }
}
impl recovery::RecoveryLoan<'_>{
 /// Called by the actual account JNI after SAME capture/join, before returning.
 /// Independently acquired account expectations, not eligibility-filled values.
 pub(crate)fn complete_account_exchange(&mut self)->Result<(),CustodyError>{
  self.recheck_source_current_evidence().map_err(|_|CustodyError::Phase)?;
  self.retain_original_account_lifetime()?;
  let p=self.0.source_request.as_mut().ok_or(CustodyError::Phase)?;
  let a=p.account_attempt.as_ref().ok_or(CustodyError::Phase)?;
  let evidence=a.verify_received_pending(p.account_lifetime.as_ref().ok_or(CustodyError::Phase)?,&p.issuer,&p.target).map_err(|_|CustodyError::Unknown)?;
  evidence.recheck(&p.operation).map_err(|_|CustodyError::Phase)?;
  let source=p.evidence.as_ref().ok_or(CustodyError::Phase)?;
  if source.has_pending(){source.check_pending_account(&evidence).map_err(|_|CustodyError::Phase)?;}
  p.account_evidence=Some(evidence);
  self.recheck_account_exchange()
 }
 pub(crate)fn recheck_account_exchange(&self)->Result<(),CustodyError>{
  self.recheck_source_current_evidence().map_err(|_|CustodyError::Phase)?;
  let p=self.0.source_request.as_ref().ok_or(CustodyError::Phase)?;
  p.account_attempt.as_ref().ok_or(CustodyError::Phase)?.recheck().map_err(|_|CustodyError::Unknown)?;
  p.account_evidence.as_ref().ok_or(CustodyError::Phase)?.recheck(&p.operation).map_err(|_|CustodyError::Phase)?;
  let source=p.evidence.as_ref().ok_or(CustodyError::Phase)?;
  if source.has_pending(){source.check_pending_account(p.account_evidence.as_ref().ok_or(CustodyError::Phase)?).map_err(|_|CustodyError::Phase)?;}
  // NativeSigningAuthorization remains unavailable: directory absence,
  // authoritative effect/once/account exclusion must still be supplied.
  Ok(())
 }
}

// Borrowed directly from the original RecoveryLoan, not a DTO, cloned request,
// accepted owner or signing capability. Shared borrow prevents replacement or
// cancellation mutation through this loan until the synchronous projection ends.
pub(crate)struct OriginalProviderInput<'a>{request:&'a PendingSourceFacts}
impl OriginalProviderInput<'_>{
 // Borrow the SAME immutable operation window. No new Instant, grace or
 // profile expiration may replace this original budget.
 pub(crate)fn operation_window(&self)->Result<crate::account_https::Window,CustodyError>{
  self.recheck()?;let p=self.request;
  let original=crate::account_https::Window{start:p.started,budget:p.remaining,issued:p.issued,expires:p.expires};
  original.remaining().map_err(|_|CustodyError::Phase)?;self.recheck()?;Ok(original)
 }
 pub(crate)fn bootstrap_raw(&self)->Result<crate::account_instance::OriginalBootstrapRaw<'_>,CustodyError>{
  self.recheck()?;let raw=self.request.account_attempt.as_ref().ok_or(CustodyError::Phase)?.original_bootstrap_raw().map_err(|_|CustodyError::Unknown)?;self.recheck()?;Ok(raw)
 }
 pub(crate)fn source_raw(&self)->Result<&[u8],CustodyError>{
  self.recheck()?;let p=self.request;let raw=p.evidence.as_ref().ok_or(CustodyError::Phase)?.original_raw(&p.operation).map_err(|_|CustodyError::Pair)?;self.recheck()?;Ok(raw)
 }
 pub(crate)fn recheck(&self)->Result<(),CustodyError>{
  let p=self.request;p.live(source_evidence::now_ms().map_err(|_|CustodyError::Phase)?)?;
  let original=p.account_attempt.as_ref().ok_or(CustodyError::Phase)?;
  original.recheck().map_err(|_|CustodyError::Unknown)?;
  let account=p.account_evidence.as_ref().ok_or(CustodyError::Phase)?;
  account.recheck_with_original(&p.operation,Some(original)).map_err(|_|CustodyError::Phase)?;
  let source=p.evidence.as_ref().ok_or(CustodyError::Phase)?;
  if !source.has_pending(){return Err(CustodyError::Phase)}
  source.check_pending_account(account).map_err(|_|CustodyError::Pair)?;
  p.live(source_evidence::now_ms().map_err(|_|CustodyError::Phase)?)
 }
 pub(crate)fn storage_frame(&self,credential:&crate::source_evidence::VerifiedFirstPreparedHolderCredential)->Result<Vec<u8>,CustodyError>{
  self.recheck()?;let p=self.request;
  let frame=p.evidence.as_ref().ok_or(CustodyError::Phase)?.original_storage_frame(&p.operation,credential).map_err(|_|CustodyError::Pair)?;
  // The caller's private bounded parser validates this retained frame; original
  // operation/nonce are checked from this retained request, never supplied strings.
  self.recheck()?;Ok(frame)
 }
 pub(crate)fn namespace_prefix(&self)->Result<&[u8],CustodyError>{
  self.recheck()?;let p=self.request;
  let raw=p.evidence.as_ref().ok_or(CustodyError::Phase)?.original_namespace_prefix(&p.operation,p.account_evidence.as_ref().ok_or(CustodyError::Phase)?).map_err(|_|CustodyError::Pair)?;
  self.recheck()?;Ok(raw)
 }
 pub(crate)fn matches_coordinates(&self,c:&source_evidence::FirstPreparedStorageCoordinates)->Result<(),CustodyError>{self.recheck()?;if c.operation!=self.request.operation||c.nonce!=self.request.nonce{return Err(CustodyError::Pair)}self.recheck()}
}
impl recovery::RecoveryLoan<'_>{
 pub(crate)fn original_provider_input(&self)->Result<OriginalProviderInput<'_>,CustodyError>{
  self.original_source_nonce()?;let input=OriginalProviderInput{request:&self.0.source_request.as_ref().ok_or(CustodyError::Phase)?.facts};input.recheck()?;Ok(input)
 }
}

#[cfg(feature="abi5-final-native-link")]
impl OriginalProviderInput<'_>{
 // Restricted original comparison, not a bytes-to-authorization constructor.
 pub(in crate::private_custodian_ffi)fn check_signing_pair(&self,classic:&[u8],pq:&[u8],ids:&[u8;32])->Result<(),CustodyError>{
  self.recheck()?;let p=self.request;if !p.matches_pair(classic,pq,ids){return Err(CustodyError::Pair)}
  pair_messages(&p.issuer,&p.target,classic,pq,source_evidence::now_ms().map_err(|_|CustodyError::Phase)?)?;
  first_genesis::inspect(&p.issuer,&p.target)?.check_source(p.evidence.as_ref().ok_or(CustodyError::Phase)?).map_err(|_|CustodyError::Pair)?;self.recheck()
 }
}
#[cfg(feature="abi5-final-native-link")]
pub(in crate::private_custodian_ffi)struct OriginalSigningParts<'a>{
 pub(in crate::private_custodian_ffi)input:OriginalProviderInput<'a>,
 pub(in crate::private_custodian_ffi)guard:&'a mut crate::source_infrastructure::platform::OriginalSigningGuard,
 pub(in crate::private_custodian_ffi)issuer:&'a[u8],pub(in crate::private_custodian_ffi)target:&'a[u8],
}
#[cfg(feature="abi5-final-native-link")]
impl PendingSourceRequest{
 pub(in crate::private_custodian_ffi)fn signing_parts(&mut self,native_classic:&[u8;33],native_pq:&[u8;2592],source_nonce:&[u8;32])->Result<OriginalSigningParts<'_>,CustodyError>{
  let input=OriginalProviderInput{request:&self.facts};input.recheck()?;
  // Tuple/nonce arrive from this same RecoveryLoan's real live custody. The
  // retained request comparison is provenance only, never a Core grant.
  if self.facts.proposal.len()!=2657||&self.facts.proposal[..33]!=native_classic||&self.facts.proposal[33..2625]!=native_pq||&self.facts.nonce!=source_nonce{return Err(CustodyError::Pair)}
  if self.signing.is_none(){
   if self.signing_acquire_attempted{return Err(CustodyError::Unknown)}
   // Retain attempt BEFORE qualified acquisition; partial out is retained in
   // this SAME request, never discarded or acquired again on refusal.
   self.signing_acquire_attempted=true;
   match crate::source_infrastructure::platform::OriginalSigningGuard::acquire(&input,native_classic,native_pq,source_nonce){
    Ok(owner)=>self.signing=Some(owner),
    Err(f)=>{self.signing=f.retained;return Err(match f.error{crate::source_infrastructure::platform::Error::Required=>CustodyError::Phase,_=>CustodyError::Unknown})}
   }
  }
  let guard=self.signing.as_mut().ok_or(CustodyError::Unknown)?;
  guard.current(&input).map_err(|_|CustodyError::Unknown)?;
  Ok(OriginalSigningParts{input,guard,issuer:&self.facts.issuer,target:&self.facts.target})
 }
 pub(in crate::private_custodian_ffi)fn invalidate_signing(&mut self){if let Some(g)=self.signing.as_ref(){g.invalidate()}}
 pub(in crate::private_custodian_ffi)fn close_signing(&mut self)->Result<(),CustodyError>{
  // Cleanup permitted when expired/cancelled; the attempt flag never resets.
  if let Some(owner)=self.signing.as_mut(){owner.close().map_err(|_|CustodyError::Unknown)?;}self.signing=None;Ok(())
 }
}

#[cfg(feature="abi5-final-native-link")]
impl PendingSourceRequest{
 pub(in crate::private_custodian_ffi)fn check_original_signing_pair(&self,classic:&[u8],pq:&[u8],ids:&[u8;32])->Result<(),CustodyError>{OriginalProviderInput{request:&self.facts}.check_signing_pair(classic,pq,ids)}
 pub(in crate::private_custodian_ffi)fn has_complete_account_input(&self)->Result<bool,CustodyError>{
  self.facts.live(source_evidence::now_ms().map_err(|_|CustodyError::Phase)?)?;
  if self.facts.account_evidence.is_none()||!self.facts.evidence.as_ref().is_some_and(|e|e.has_namespace_prefix()){return Ok(false)}
  OriginalProviderInput{request:&self.facts}.recheck()?;Ok(true)
 }
}


#[cfg(feature="abi5-final-native-link")]
impl PendingSourceRequest{
 // Observe only an ALREADY retained qualified guard. No acquisition/entry or
 // latch reset, even after a previous Required/partial/close outcome.
 pub(in crate::private_custodian_ffi)fn retained_signing_parts(&mut self)->Result<OriginalSigningParts<'_>,CustodyError>{
  let input=OriginalProviderInput{request:&self.facts};input.recheck()?;
  let guard=self.signing.as_mut().ok_or(CustodyError::Phase)?;
  guard.current(&input).map_err(|_|CustodyError::Unknown)?;
  Ok(OriginalSigningParts{input,guard,issuer:&self.facts.issuer,target:&self.facts.target})
 }
}
impl recovery::RecoveryLoan<'_>{
 // Object identity is checked against the ORIGINAL retained global reference,
 // never against a new caller DTO. Cleanup may use it after expiry/cancel.
 pub(crate)fn matches_original_account_borrow(&self,env:&mut jni::Env<'_>,borrow:&jni::objects::JObject<'_>)->jni::errors::Result<bool>{
  let Some(old)=self.0.source_request.as_ref().and_then(|p|p.account_borrow.as_ref())else{return Ok(false)};
  env.is_same_object(old.as_obj(),borrow)
 }
}



// Callback result is retained even when the final original-current fence fails.
// This carrier owns cleanup only; it cannot create a message qualification.
pub(crate)struct MessageOriginalFailure<R>{pub(crate)error:CustodyError,pub(crate)retained:Option<R>}
impl recovery::RecoveryLoan<'_>{
 pub(crate)fn with_message_evidence<R>(&mut self,issuer_credential:&[u8],anchor_credential:&[u8],purpose:&[u8],association_issuer:&[u8],association_anchor:&[u8],run:impl for<'a>FnOnce(&crate::message_evidence::MessageEvidence<'a>)->R)->Result<R,MessageOriginalFailure<R>>{
  let result=(||->Result<R,CustodyError>{
   self.recheck_account_exchange()?;
   let p=self.0.source_request.as_ref().ok_or(CustodyError::Phase)?;
   let source=p.evidence.as_ref().ok_or(CustodyError::Phase)?;
   let original=p.account_attempt.as_ref().ok_or(CustodyError::Phase)?;
   let keys=source.message_keys(&p.operation,issuer_credential,anchor_credential).map_err(|_|CustodyError::Pair)?;
   let evidence=crate::message_evidence::verify_association(keys,purpose,association_issuer,association_anchor,original).map_err(|_|CustodyError::Pair)?;
   evidence.recheck().map_err(|_|CustodyError::Phase)?;
   Ok(run(&evidence))
  })();
  let value=result.map_err(|error|MessageOriginalFailure{error,retained:None})?;
  // All parsed evidence borrows ended, but the same original request remains.
  if let Err(error)=self.recheck_account_exchange(){self.fail(16);return Err(MessageOriginalFailure{error,retained:Some(value)})}
  Ok(value)
 }
}

impl recovery::RecoveryLoan<'_>{
 fn with_device_original_evidence<R>(&mut self,input:&crate::message_evidence::MessageOpenInput,records:&crate::message_evidence::OriginalDeviceRecords,independent:&crate::message_evidence::IndependentCommitOriginals<'_>,run:impl for<'a>FnOnce(&crate::message_evidence::UnadmittedDeviceEvidence<'a>)->R)->Result<Result<R,CustodyError>,MessageOriginalFailure<Result<R,CustodyError>>>{
  let(classic,pq)={let p=self.public_pair().map_err(|error|MessageOriginalFailure{error,retained:None})?;(p.classic.to_vec(),p.pq.to_vec())};
  self.with_message_evidence(&input.issuer_credential,&input.anchor_credential,&input.purpose_authorization,&input.association_issuer,&input.association_anchor,|evidence|{
   let verified=evidence.verify_device_records(records,independent,&classic,&pq).map_err(|_|CustodyError::Pair)?;
   Ok(run(&verified))
  })
 }
}

impl recovery::RecoveryLoan<'_>{
 #[cfg(feature="abi5-final-native-link")]
 pub(crate)fn with_native_final_device_evidence<R>(&mut self,input:&crate::message_evidence::MessageOpenInput,records:&crate::message_evidence::OriginalDeviceRecords,owner:&crate::staging::platform::QualifiedFinalEvidenceOwner,run:impl for<'a>FnOnce(&crate::message_evidence::UnadmittedDeviceEvidence<'a>)->R)->Result<Result<R,CustodyError>,MessageOriginalFailure<Result<R,CustodyError>>>{
  match owner.with_independent_originals(|originals|self.with_device_original_evidence(input,records,originals,run)){
   Ok(result)=>result,
   Err((_,Some(Ok(result))))=>Err(MessageOriginalFailure{error:CustodyError::Pair,retained:Some(result)}),
   Err((_,Some(Err(failure))))=>Err(failure),
   Err((_,None))=>Err(MessageOriginalFailure{error:CustodyError::Pair,retained:None}),
  }
 }
}

#[cfg(feature="abi5-final-native-link")]
impl RecoveryLoan<'_>{
 // Original Native recovered key custody is the source of device public keys.
 // No first-init/account Attempt is borrowed or renewed for persistent restore.
 pub(crate)fn restore_accepted_device(&mut self,records:crate::message_evidence::OriginalDeviceRecords)->Result<crate::staging::platform::AcceptedDeviceOwner,(crate::staging::platform::SourceOwnerError,Option<crate::staging::platform::AcceptedDeviceOwner>)>{
  let pair=self.public_pair().map_err(|_|(crate::staging::platform::SourceOwnerError::Association,None))?;
  let result=crate::staging::platform::AcceptedDeviceOwner::restore(records,&pair.classic,&pair.pq);
  if self.public_pair().is_err(){self.fail(16);return match result{Ok(owner)=>Err((crate::staging::platform::SourceOwnerError::Unknown,Some(owner))),Err(e)=>Err(e)}}
  result
 }
}
