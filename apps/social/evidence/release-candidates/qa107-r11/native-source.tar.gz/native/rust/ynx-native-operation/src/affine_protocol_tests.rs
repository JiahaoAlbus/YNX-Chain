//! Actual pinned SessionCipher, fixture Stores; no native trust/capability proof.
use super::*;
use async_trait::async_trait;
use spqr::ynx_operation::CallScope;
use std::{future::{Future,poll_fn},pin::Pin,sync::Arc,task::{Context,Poll,Wake,Waker}};
struct Noop;
impl Wake for Noop{fn wake(self:Arc<Self>) {}}
fn scope(node:&Node,op:u64,direction:u64)->CallScope{CallScope::fixture([node.core.owner,node.core.current.session,node.incarnation,node.core.current.state_generation,op,node.core.current.context,node.core.current.route,node.core.current.device_authorization,node.core.current.checkpoint,0,direction])}
struct YieldStore<'a>{inner:&'a mut InMemSessionStore,scope:&'a CallScope,at_store:bool}
async fn yield_once(){let mut ready=false;poll_fn(|cx|{if ready{Poll::Ready(())}else{ready=true;cx.waker().wake_by_ref();Poll::Pending}}).await}
#[async_trait(?Send)]
impl SessionStore for YieldStore<'_>{
    async fn load_session(&self,address:&ProtocolAddress)->libsignal_protocol::error::Result<Option<SessionRecord>>{
        if !self.at_store{yield_once().await;}
        self.inner.load_session(address).await
    }
    async fn store_session(&mut self,address:&ProtocolAddress,record:&SessionRecord)->libsignal_protocol::error::Result<()>{
        if self.at_store{yield_once().await;}
        if !self.scope.is_live(){return Err(SignalProtocolError::InvalidState("fixture-final-store","binding rejected".into()));}
        self.inner.store_session(address,record).await
    }
}
fn run<F:Future>(f:F)->F::Output{let mut f=Box::pin(f);let w=Waker::from(Arc::new(Noop));let mut cx=Context::from_waker(&w);for _ in 0..16{if let Poll::Ready(v)=f.as_mut().poll(&mut cx){return v}}panic!("bounded pending count exceeded")}
#[test]
fn actual_bidirectional_async_hooks_and_tls_isolation(){
    let(mut a,mut b)=pair();let mut counts=[0;4];let mut fresh_events=[0;4];
    for i in 0..160u64{
        for dir in 0..2{let(sender,receiver)=if dir==0{(&mut a,&mut b)}else{(&mut b,&mut a)};
            let send_scope=scope(sender,i*4+dir*2+1,1);let recv_scope=scope(receiver,i*4+dir*2+2,2);
            let mut rng=OsRng.unwrap_err();let mut store=YieldStore{inner:&mut sender.store.session_store,scope:&send_scope,at_store:i%2==0};
            // Deliberately forge old thread-local diagnostics. Explicit hooks do not read them.
            let(result,_)=spqr::ynx_observer::observe(||{
                spqr::ynx_observer::consumed(true);spqr::ynx_observer::authenticated();
                run(send_scope.guard(message_encrypt_with_scope(b"actual async core",&sender.remote,&sender.local,&mut store,&mut sender.store.identity_store,SystemTime::now(),&mut rng,Some(&send_scope)))).expect("operation-affine guardian")
            });let wire=result.unwrap();
            let mut rng=OsRng.unwrap_err();let mut store=YieldStore{inner:&mut receiver.store.session_store,scope:&recv_scope,at_store:i%2!=0};
            let clear=run(recv_scope.guard(message_decrypt_with_scope(&wire,&receiver.remote,&receiver.local,&mut store,&mut receiver.store.identity_store,&mut receiver.store.pre_key_store,&receiver.store.signed_pre_key_store,&mut receiver.store.kyber_pre_key_store,&mut rng,Some(&recv_scope)))).expect("operation-affine guardian").unwrap();
            assert_eq!(clear,b"actual async core");let sd=send_scope.fixture_diagnostics();let rd=recv_scope.fixture_diagnostics();assert!(sd.0&&sd.1&&rd.0&&rd.1);
            counts[dir as usize*2]+=usize::from(sd.2);counts[dir as usize*2+1]+=usize::from(rd.2);fresh_events[dir as usize*2]+=usize::from(sd.3);fresh_events[dir as usize*2+1]+=usize::from(rd.3);
        }
    }
    // Matching fresh SCKA contribution in THIS invocation, not epoch-ledger history.
    assert!(fresh_events.iter().all(|c|*c>0),"actual fresh SCKA hooks for every direction: {fresh_events:?}");
    assert_eq!(counts,[0;4],"upstream selected epoch precedes newly incorporated epoch; NEVER admit on fresh metadata alone");
    eprintln!("nonsecret hook counts: fresh={fresh_events:?}, same-call selected-fresh={counts:?}; trusted cross-operation lineage REQUIRED");
    assert!(a.core.capabilities.is_empty()&&b.core.capabilities.is_empty());
    assert!(CallScope::open_production().is_err());
}
#[test]
fn actual_async_wrong_operation_revoke_cancel_before_final_store(){
    for mutation in 0..13{for at_store in [false,true]{let(mut a,_b)=pair();let before=a.state();let scope=scope(&a,51,1);let mut rng=OsRng.unwrap_err();
        let mut store=YieldStore{inner:&mut a.store.session_store,scope:&scope,at_store};
        let mut f=Box::pin(scope.guard(message_encrypt_with_scope(b"must reject",&a.remote,&a.local,&mut store,&mut a.store.identity_store,SystemTime::now(),&mut rng,Some(&scope))));
        let w=Waker::from(Arc::new(Noop));let mut cx=Context::from_waker(&w);assert!(f.as_mut().poll(&mut cx).is_pending());
        match mutation{0..=10=>scope.fixture_rebind(mutation),11=>scope.fixture_revoke(),_=>scope.cancel()}
        assert!(run(f).is_err());drop(store);assert!(before==a.state());
    }}
}
#[test]
fn actual_mac_failure_does_not_authenticate_scope(){
    let(mut a,mut b)=pair();let sent=a.send("MAC fixture",Fault::None).unwrap();let mut wire=sent.bytes;*wire.last_mut().unwrap()^=1;
    let cipher=CiphertextMessage::SignalMessage(SignalMessage::try_from(wire.as_slice()).unwrap());let scope=scope(&b,91,2);let before=b.state();let mut rng=OsRng.unwrap_err();
    let mut store=YieldStore{inner:&mut b.store.session_store,scope:&scope,at_store:false};
    let result=run(scope.guard(message_decrypt_with_scope(&cipher,&b.remote,&b.local,&mut store,&mut b.store.identity_store,&mut b.store.pre_key_store,&b.store.signed_pre_key_store,&mut b.store.kyber_pre_key_store,&mut rng,Some(&scope)))).expect("operation-affine guardian");
    assert!(result.is_err());drop(store);assert!(!scope.fixture_diagnostics().1);assert!(before==b.state());
}

#[test]
fn actual_native_pending_is_cancel_woken_without_manual_progress(){
    use std::sync::mpsc;use std::time::Duration;
    struct Notify{tx:mpsc::Sender<()>,scope:Arc<CallScope>}
    impl Wake for Notify{fn wake(self:Arc<Self>){let _=self.scope.classification();self.tx.send(()).unwrap();}}
    struct ParkStore<'a>{inner:&'a mut InMemSessionStore,entered:mpsc::Sender<()>}
    #[async_trait(?Send)]impl SessionStore for ParkStore<'_>{
        async fn load_session(&self,_:&ProtocolAddress)->libsignal_protocol::error::Result<Option<SessionRecord>>{
            let mut notified=false;poll_fn(|_|{if !notified{self.entered.send(()).unwrap();notified=true;}Poll::<()>::Pending}).await;
            unreachable!("load fixture never wakes; operation cancellation owns notification")
        }
        async fn store_session(&mut self,a:&ProtocolAddress,r:&SessionRecord)->libsignal_protocol::error::Result<()>{self.inner.store_session(a,r).await}
    }
    for transition in 0..4{let(context_tx,context_rx)=mpsc::channel();let(entered_tx,entered_rx)=mpsc::channel();let(wake_tx,wake_rx)=mpsc::channel();let(parked_tx,parked_rx)=mpsc::channel();
        let worker=std::thread::spawn(move||{let(mut a,_b)=pair();let owner=Arc::new(scope(&a,123,1));context_tx.send(owner.clone()).unwrap();let before=a.state();let mut store=ParkStore{inner:&mut a.store.session_store,entered:entered_tx};let mut rng=OsRng.unwrap_err();
            let mut f=Box::pin(owner.guard(message_encrypt_with_scope(b"parked native",&a.remote,&a.local,&mut store,&mut a.store.identity_store,SystemTime::now(),&mut rng,Some(&owner))));
            let w=Waker::from(Arc::new(Notify{tx:wake_tx,scope:owner.clone()}));let mut cx=Context::from_waker(&w);assert!(f.as_mut().poll(&mut cx).is_pending());parked_tx.send(()).unwrap();
            wake_rx.recv_timeout(Duration::from_secs(2)).expect("executor notification required; native task never selfwakes");
            let expected=match transition{0=>spqr::ynx_operation::Stopped::Cancelled,1=>spqr::ynx_operation::Stopped::Revoked,2=>spqr::ynx_operation::Stopped::Binding,_=>spqr::ynx_operation::Stopped::Unknown};
            assert!(matches!(f.as_mut().poll(&mut cx),Poll::Ready(Err(e)) if e==expected));drop(f);drop(store);assert!(before==a.state());
        });let scope=context_rx.recv_timeout(Duration::from_secs(3)).unwrap();entered_rx.recv_timeout(Duration::from_secs(3)).unwrap();parked_rx.recv_timeout(Duration::from_secs(3)).unwrap();match transition{0=>scope.cancel(),1=>scope.fixture_revoke(),2=>scope.fixture_rebind(4),_=>scope.fixture_unknown()}worker.join().unwrap();
    }
}
