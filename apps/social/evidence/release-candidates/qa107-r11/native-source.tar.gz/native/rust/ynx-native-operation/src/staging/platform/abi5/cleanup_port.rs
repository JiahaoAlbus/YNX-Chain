//! Exact ABI5 cleanup call/retention mechanics; no authority or output receipt.
use std::{marker::PhantomData,ptr,rc::Rc};
#[repr(C)]pub(super)struct Store{pub(super)_opaque:[u8;0],#[cfg(test)]pub(super)_controlled:u8}
#[repr(C)]pub(super)struct Cleanup{pub(super)_opaque:[u8;0],#[cfg(test)]pub(super)_controlled:u8}
#[derive(Clone,Copy)]#[repr(C)]pub(super)struct Observation{pub(super)primary:i32,pub(super)rollback:i32,pub(super)unknown_fence:i32,pub(super)actual_autocommit:i32}
#[link(name="veil_abi5_store",kind="static")]
unsafe extern "C"{
 pub(super)fn veil_native_take_cleanup(s:*mut Store,c:*mut *mut Cleanup)->i32;
 pub(super)fn veil_native_cleanup_observe(c:*mut Cleanup,o:*mut Observation)->i32;
 pub(super)fn veil_native_cleanup_drop(c:*mut *mut Cleanup)->i32;
}
// Mechanical borrow only; successful disposal is NOT NotApplied/authority.
// No normal safe constructor. The owning native actor must keep the original
// immutable intent/store source borrow alive, on its original thread, until
// the retained handle AND any store-side pending transfer are released.
// Rust borrow of the original native actor descriptor, not a reference to C
// allocation bytes or an issuer. No normal descriptor constructor is supplied.
pub(super)struct SourceStoreBorrow{store:*mut Store,actor:PhantomData<Rc<()>>}
#[cfg(test)]impl SourceStoreBorrow{
 pub(super)unsafe fn fixture_owned(store:*mut Store)->Self{Self{store,actor:PhantomData}}
}
pub(super)struct SourceCleanupOwner<'store>{
 store:*mut Store,handle:*mut Cleanup,pending:bool,first_primary:Option<i32>,cleanup_primary:Option<i32>,unknown:bool,
 observation:Option<Observation>,
 #[cfg(all(test,veil_source_fixture))]foreign_calls:[u64;3],
 borrow:PhantomData<&'store mut SourceStoreBorrow>,actor:PhantomData<Rc<()>>,
}
#[derive(Debug,PartialEq,Eq)]pub(super)enum Disposition{Held{primary:i32,last:i32},Released{primary:i32,unknown:bool},Unrecorded{last:i32,disposed:bool,unknown:bool}}
impl<'store>SourceCleanupOwner<'store>{
 // SAFETY: caller owns exact original non-null C store on its owner thread;
 // no close/destroy/second take is permitted while this exclusive borrow lives.
 // Never constructs an issuer/receipt or reinterprets an authority payload.
 // Failed-source cleanup may preserve SQL3 while the native store is UNKNOWN.
 // Conservatively retain uncertainty for this topology from construction.
 // Rollback/observation OK disposes RAM, never proves source resolution.
 pub(super)unsafe fn from_failed_source(store:&'store mut SourceStoreBorrow,primary:i32)->Self{
  Self{store:store.store,handle:ptr::null_mut(),pending:true,first_primary:if primary!=0{Some(primary)}else{None},cleanup_primary:None,unknown:true,observation:None,
   #[cfg(all(test,veil_source_fixture))]foreign_calls:[0;3],
   borrow:PhantomData,actor:PhantomData}
 }
 fn status(&mut self,status:i32){if status==8{self.unknown=true;}if status!=0&&self.cleanup_primary.is_none(){self.cleanup_primary=Some(status);}}
 fn held(&self,last:i32)->Disposition{match self.first_primary{Some(primary)=>Disposition::Held{primary,last},None=>Disposition::Unrecorded{last,disposed:false,unknown:true}}}
 pub(super)fn retry(&mut self)->Disposition{
  if self.pending{
   if !self.handle.is_null(){self.unknown=true;return self.held(7)}
   #[cfg(all(test,veil_source_fixture))]{self.foreign_calls[0]+=1;}
   let st=unsafe{veil_native_take_cleanup(self.store,&mut self.handle)};self.status(st);
   if st!=0{return self.held(st)}self.pending=false;
  }
  if !self.handle.is_null(){
   let mut o=Observation{primary:0,rollback:0,unknown_fence:1,actual_autocommit:0};
   #[cfg(all(test,veil_source_fixture))]{self.foreign_calls[1]+=1;}
   let st=unsafe{veil_native_cleanup_observe(self.handle,&mut o)};self.status(st);
   if st!=0{self.unknown=true;return self.held(st)}
   // Native observation can fill an UNRECORDED original error, never replace
   // an already recorded first source error with later cleanup diagnostics.
   if o.primary!=0{if self.first_primary.is_none(){self.first_primary=Some(o.primary);}else if self.first_primary!=Some(o.primary){self.unknown=true;}}
   self.status(o.rollback);self.status(o.unknown_fence);self.observation=Some(o);
   let same=self.handle;
   #[cfg(all(test,veil_source_fixture))]{self.foreign_calls[2]+=1;}
   let st=unsafe{veil_native_cleanup_drop(&mut self.handle)};self.status(st);
   if st!=0||!self.handle.is_null(){self.unknown=true;if self.handle!=same{return self.held(7)}return self.held(st)}
  }
  match self.first_primary{Some(primary)=>Disposition::Released{primary,unknown:self.unknown},None=>Disposition::Unrecorded{last:self.cleanup_primary.unwrap_or(0),disposed:true,unknown:true}}
 }
 pub(super)fn fully_released(&self)->bool{!self.pending&&self.handle.is_null()}
 // No automatic Drop calls/claim: a failed owner remains actor-retained. Final
 // actor shutdown quarantine is REQUIRED; this candidate does not issue it.
}

// Exact test TU only, never linked into normal Cargo/SDK archive.
#[cfg(all(test,veil_source_fixture))]
#[path="source_owner_controls.rs"]mod source_owner_controls;

// Forced destruction is not a recovery operation. Explicit shutdown must retain
// unresolved custody. No FFI/rollback/re-encryption is performed by Drop.
impl Drop for SourceCleanupOwner<'_>{fn drop(&mut self){if !self.fully_released(){std::process::abort();}}}
mod quarantine;
