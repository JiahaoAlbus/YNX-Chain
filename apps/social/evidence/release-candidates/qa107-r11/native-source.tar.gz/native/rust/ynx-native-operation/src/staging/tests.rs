//! Entire provider construction and commit below are cfg(test), not native trust.
use super::*;
#[path="../upstream_test_support.rs"] mod upstream;
use futures_util::FutureExt;
use rand::{rngs::OsRng,TryRngCore as _};
use std::time::SystemTime;
struct FixtureBacking { store: InMemSignalProtocolStore, generation:u64 }
fn stage(b:&FixtureBacking,wire:Option<&[u8]>,trigger:Option<(usize,usize)>)->StagedOperation {
 let gate=Gate(Rc::new(RefCell::new(Pending {phase:Phase::Working,binding:[1,2,3,b.generation,5,6,7,8,9,0,2],bytes:0,journal:Vec::new(),original_ciphertext:wire.map(|w|w.to_vec()),generated_wire:false,selected_wire_kind:None,plaintext:None,trigger,pending:false})),Rc::new(spqr::ynx_operation::CallScope::fixture([1,2,3,b.generation,5,6,7,8,9,0,2])));
 // Real upstream stores are cloned into isolated snapshots; there is NO live
 // backing reference in any adapter, and no constructor in non-test code.
 StagedOperation {identity:Identity{snapshot:Box::new(b.store.identity_store.clone()),gate:gate.clone()},ec:EC{snapshot:Box::new(b.store.pre_key_store.clone()),gate:gate.clone()},kyber:Kyber{snapshot:Box::new(b.store.kyber_pre_key_store.clone()),gate:gate.clone()},sessions:Sessions{snapshot:Box::new(b.store.session_store.clone()),gate:gate.clone()},gate}
}
fn setup()->(InMemSignalProtocolStore,FixtureBacking,ProtocolAddress,ProtocolAddress,CiphertextMessage){
 let mut a=upstream::test_in_memory_protocol_store().unwrap();let mut b=upstream::test_in_memory_protocol_store().unwrap();let mut rng=OsRng.unwrap_err();
 let bundle=upstream::create_pre_key_bundle(&mut b,&mut rng).now_or_never().unwrap().unwrap();
 let alice=ProtocolAddress::new("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa".into(),DeviceId::new(1).unwrap());let bob=ProtocolAddress::new("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb".into(),bundle.device_id().unwrap());
 process_prekey_bundle(&bob,&alice,&mut a.session_store,&mut a.identity_store,&bundle,SystemTime::now(),&mut rng).now_or_never().unwrap().unwrap();
 let wire=upstream::encrypt(&mut a,&bob,&alice,"staged initial").now_or_never().unwrap().unwrap();
 (a,FixtureBacking{store:b,generation:0},alice,bob,wire)
}
fn run<F:std::future::Future>(f:F)->F::Output {let mut f=Box::pin(f);let w=std::task::Waker::noop();let mut cx=std::task::Context::from_waker(w);for _ in 0..32{if let std::task::Poll::Ready(v)=f.as_mut().poll(&mut cx){return v}}panic!("bounded native pending")}
fn receive(s:&mut StagedOperation,b:&FixtureBacking,alice:&ProtocolAddress,bob:&ProtocolAddress,w:&CiphertextMessage)->R<()> {
 let mut rng=OsRng.unwrap_err();let scope=s.gate.1.clone();
 let r=run(scope.guard(async {
  let clear=message_decrypt_with_scope(w,alice,bob,&mut s.sessions,&mut s.identity,&mut s.ec,&b.store.signed_pre_key_store,&mut s.kyber,&mut rng,Some(&scope)).await?;
  s.prepare(w.serialize(),Some(clear))
 }));
 match r {Ok(Ok(()))=>Ok(()),Ok(Err(e))=>{s.reject();Err(e)},Err(_)=>{s.reject();Err(stopped())}}
}
// Single synthetic in-memory replacement, not SQLite, durable/native receipt,
// authenticated source lease or capability. CAS/no-side-effect assertions only.
fn fixture_commit(s:&mut StagedOperation,b:&mut FixtureBacking,fault:usize)->Result<(),crate::OperationError>{
 let mut p=s.gate.0.borrow_mut();
 if p.phase!=Phase::Prepared{return Err(if p.phase==Phase::Unknown{crate::OperationError::Unknown}else{crate::OperationError::CommitFailed});}
 if p.binding[3]!=b.generation{p.phase=Phase::Rejected;return Err(crate::OperationError::Binding);}
 if fault==1{p.phase=Phase::Rejected;return Err(crate::OperationError::CommitFailed);}
 if fault==2{p.phase=Phase::Rejected;return Err(crate::OperationError::Revoked);}
 // Apply the journal to a private clone, then replace the whole fixture once.
 let mut next=InMemSignalProtocolStore::new(b.store.get_identity_key_pair().now_or_never().unwrap().unwrap(),b.store.get_local_registration_id().now_or_never().unwrap().unwrap()).unwrap();
 next.identity_store=b.store.identity_store.clone();next.pre_key_store=b.store.pre_key_store.clone();next.kyber_pre_key_store=b.store.kyber_pre_key_store.clone();next.session_store=b.store.session_store.clone();next.signed_pre_key_store=b.store.signed_pre_key_store.clone();
 for m in &p.journal{let r=match m{
 Mutation::Identity(a,k)=>next.save_identity(a,k).now_or_never().unwrap().map(|_|()),
 Mutation::PreKeySave(id,r)=>next.save_pre_key(*id,r).now_or_never().unwrap(),
 Mutation::PreKeyRemove(id)=>next.remove_pre_key(*id).now_or_never().unwrap(),
 Mutation::KyberSave(id,r)=>next.save_kyber_pre_key(*id,r).now_or_never().unwrap(),
 Mutation::KyberUsed(k,e,key)=>next.mark_kyber_pre_key_used(*k,*e,key).now_or_never().unwrap(),
 Mutation::Session(a,r)=>next.store_session(a,r).now_or_never().unwrap()};if r.is_err(){p.phase=Phase::Rejected;return Err(crate::OperationError::CommitFailed);}}
 b.store=next;b.generation+=1;p.phase=if fault==3{Phase::Unknown}else{Phase::Applied};
 if fault==3{Err(crate::OperationError::Unknown)}else{Ok(())}
}
fn unchanged(b:&FixtureBacking,a:&ProtocolAddress,ec:PreKeyId,k:KyberPreKeyId,e:SignedPreKeyId,base:&PublicKey){
 assert!(b.store.get_identity(a).now_or_never().unwrap().unwrap().is_none());
 assert!(b.store.load_session(a).now_or_never().unwrap().unwrap().is_none());
 assert!(b.store.get_pre_key(ec).now_or_never().unwrap().is_ok());
 let mut probe=b.store.kyber_pre_key_store.clone();assert!(probe.mark_kyber_pre_key_used(k,e,base).now_or_never().unwrap().is_ok());assert_eq!(b.generation,0);
}
#[test]fn real_initial_prekey_all_earlier_effects_staged_and_cancel_rollback(){
 for at in 1..=4{for terminal in 0..4{for pending in [false,true]{
 let(_a,b,alice,bob,w)=setup();let ec=*b.store.all_pre_key_ids().next().unwrap();let k=*b.store.all_kyber_pre_key_ids().next().unwrap();let e=*b.store.all_signed_pre_key_ids().next().unwrap();let base=match &w{CiphertextMessage::PreKeySignalMessage(p)=>*p.base_key(),_=>panic!()};
 let mut s=stage(&b,Some(w.serialize()),Some((at,terminal)));s.gate.0.borrow_mut().pending=pending;assert!(receive(&mut s,&b,&alice,&bob,&w).is_err());
 assert_eq!(s.gate.0.borrow().journal.len(),at);s.cancel();
 if terminal==3{assert!(s.gate.0.borrow().phase==Phase::Unknown);}
 unchanged(&b,&alice,ec,k,e,&base);assert!(s.final_producer().is_err());
 }}}
}
#[test]fn real_prekey_staged_success_failure_and_fixture_atomic_interop(){
 for fault in 0..=3{let(mut a,mut b,alice,bob,w)=setup();let ec=*b.store.all_pre_key_ids().next().unwrap();let k=*b.store.all_kyber_pre_key_ids().next().unwrap();let e=*b.store.all_signed_pre_key_ids().next().unwrap();let base=match &w{CiphertextMessage::PreKeySignalMessage(p)=>*p.base_key(),_=>panic!()};
 let mut s=stage(&b,Some(w.serialize()),None);receive(&mut s,&b,&alice,&bob,&w).unwrap();assert_eq!(s.gate.0.borrow().journal.len(),4);unchanged(&b,&alice,ec,k,e,&base);
 assert!(s.final_producer().is_err());let result=fixture_commit(&mut s,&mut b,fault);
 if fault==1||fault==2{assert!(result.is_err());unchanged(&b,&alice,ec,k,e,&base);}else{
 assert_eq!(b.generation,1);assert!(b.store.get_pre_key(ec).now_or_never().unwrap().is_err());assert!(b.store.get_identity(&alice).now_or_never().unwrap().unwrap().is_some());
 let reply=upstream::encrypt(&mut b.store,&alice,&bob,"after fixture transaction").now_or_never().unwrap().unwrap();assert_eq!(upstream::decrypt(&mut a,&bob,&alice,&reply).now_or_never().unwrap().unwrap(),b"after fixture transaction");
 if fault==3{assert_eq!(result,Err(crate::OperationError::Unknown));let original=s.gate.0.borrow().original_ciphertext.clone().unwrap();s.cancel();assert!(s.gate.0.borrow().phase==Phase::Unknown);assert_eq!(original,w.serialize());assert_eq!(fixture_commit(&mut s,&mut b,0),Err(crate::OperationError::Unknown));assert_eq!(b.generation,1);}else{result.unwrap();assert!(fixture_commit(&mut s,&mut b,0).is_err());}
 }
 }}
#[test]fn real_auth_failure_and_stale_snapshot_cas_do_not_publish(){
 let(_a,mut b,alice,bob,w)=setup();let mut bytes=w.serialize().to_vec();*bytes.last_mut().unwrap()^=1;
 let bad=CiphertextMessage::PreKeySignalMessage(PreKeySignalMessage::try_from(bytes.as_slice()).unwrap());let mut s=stage(&b,Some(&bytes),None);assert!(receive(&mut s,&b,&alice,&bob,&bad).is_err());assert_eq!(b.generation,0);assert!(b.store.get_identity(&alice).now_or_never().unwrap().unwrap().is_none());assert!(fixture_commit(&mut s,&mut b,0).is_err());
 let mut s=stage(&b,Some(w.serialize()),None);receive(&mut s,&b,&alice,&bob,&w).unwrap();b.generation=1;assert_eq!(fixture_commit(&mut s,&mut b,0),Err(crate::OperationError::Binding));assert!(b.store.get_identity(&alice).now_or_never().unwrap().unwrap().is_none());
}
#[test]fn bounded_mutations_and_wire_fail_closed(){
 let(_a,b,alice,_bob,w)=setup();let mut s=stage(&b,Some(w.serialize()),None);let pair=b.store.get_identity_key_pair().now_or_never().unwrap().unwrap();
 for _ in 0..MAX_MUTATIONS{s.identity.save_identity(&alice,pair.identity_key()).now_or_never().unwrap().unwrap();}
 assert!(s.identity.save_identity(&alice,pair.identity_key()).now_or_never().unwrap().is_err());assert!(s.gate.0.borrow().phase==Phase::Rejected);assert!(b.store.get_identity(&alice).now_or_never().unwrap().unwrap().is_none());
 let mut s=stage(&b,None,None);assert!(s.prepare(&vec![0;MAX_WIRE+1],None).is_err());
}
#[test]fn real_send_unknown_owns_exact_original_cipher_no_regeneration(){
 let(mut a,mut peer,local,remote,initial)=setup();upstream::decrypt(&mut peer.store,&local,&remote,&initial).now_or_never().unwrap().unwrap();let reply=upstream::encrypt(&mut peer.store,&local,&remote,"establish").now_or_never().unwrap().unwrap();upstream::decrypt(&mut a,&remote,&local,&reply).now_or_never().unwrap().unwrap();let mut b=FixtureBacking{store:a,generation:0};let mut s=stage(&b,None,None);let mut rng=OsRng.unwrap_err();
 let wire=message_encrypt_with_scope(b"unknown staged send",&remote,&local,&mut s.sessions,&mut s.identity,SystemTime::now(),&mut rng,Some(&s.gate.1)).now_or_never().unwrap().unwrap();s.prepare(wire.serialize(),None).unwrap();let before=b.store.load_session(&remote).now_or_never().unwrap().unwrap().unwrap().serialize().unwrap();
 assert_eq!(fixture_commit(&mut s,&mut b,3),Err(crate::OperationError::Unknown));let after=b.store.load_session(&remote).now_or_never().unwrap().unwrap().unwrap().serialize().unwrap();assert_ne!(before,after);
 for _ in 0..3{assert_eq!(s.gate.0.borrow().original_ciphertext.as_deref().unwrap(),wire.serialize());assert!(message_encrypt_with_scope(b"must not regenerate",&remote,&local,&mut s.sessions,&mut s.identity,SystemTime::now(),&mut rng,Some(&s.gate.1)).now_or_never().unwrap().is_err());assert_eq!(after,b.store.load_session(&remote).now_or_never().unwrap().unwrap().unwrap().serialize().unwrap());}
 s.cancel();assert!(s.gate.0.borrow().phase==Phase::Unknown);assert!(crate::open_production().is_err());
}
#[test]fn independent_scope_unknown_receive_pending_prepared_and_drop_sticky(){
 for schedule in 0..3{let(_a,b,alice,bob,w)=setup();let mut s=stage(&b,Some(w.serialize()),None);
 if schedule==0{s.gate.1.fixture_unknown();assert!(receive(&mut s,&b,&alice,&bob,&w).is_err());}
 else if schedule==1{
  s.gate.0.borrow_mut().pending=true;let owner=s.gate.1.clone();let mut rng=OsRng.unwrap_err();
  let mut f=Box::pin(owner.guard(message_decrypt_with_scope(&w,&alice,&bob,&mut s.sessions,&mut s.identity,&mut s.ec,&b.store.signed_pre_key_store,&mut s.kyber,&mut rng,Some(&owner))));let waker=std::task::Waker::noop();let mut cx=std::task::Context::from_waker(waker);assert!(f.as_mut().poll(&mut cx).is_pending());owner.fixture_unknown();assert!(matches!(run(f),Err(spqr::ynx_operation::Stopped::Unknown)));s.reject();
 }else{receive(&mut s,&b,&alice,&bob,&w).unwrap();s.gate.1.fixture_unknown();s.reject();}
 s.gate.1.fixture_revoke();s.cancel();let retained=s.gate.0.clone();let before=retained.borrow().journal.len();assert!(retained.borrow().phase==Phase::Unknown);assert_eq!(retained.borrow().original_ciphertext.as_deref(),Some(w.serialize()));drop(s);assert!(retained.borrow().phase==Phase::Unknown);assert_eq!(retained.borrow().journal.len(),before);assert!(b.store.get_identity(&alice).now_or_never().unwrap().unwrap().is_none());assert!(b.store.load_session(&alice).now_or_never().unwrap().unwrap().is_none());
 }
}
struct ScopeOnlyIdentity<'a>{inner:&'a mut Identity,scope:Rc<spqr::ynx_operation::CallScope>,pending:bool}
#[async_trait(?Send)]impl IdentityKeyStore for ScopeOnlyIdentity<'_>{
 async fn get_identity_key_pair(&self)->R<IdentityKeyPair>{self.inner.get_identity_key_pair().await}
 async fn get_local_registration_id(&self)->R<u32>{self.inner.get_local_registration_id().await}
 async fn get_identity(&self,a:&ProtocolAddress)->R<Option<IdentityKey>>{self.inner.get_identity(a).await}
 async fn is_trusted_identity(&self,a:&ProtocolAddress,k:&IdentityKey,d:Direction)->R<bool>{self.inner.is_trusted_identity(a,k,d).await}
 async fn save_identity(&mut self,a:&ProtocolAddress,k:&IdentityKey)->R<IdentityChange>{let r=self.inner.save_identity(a,k).await?;self.scope.fixture_unknown();if self.pending{let mut done=false;std::future::poll_fn(|cx|if done{std::task::Poll::Ready(())}else{done=true;cx.waker().wake_by_ref();std::task::Poll::Pending}).await;}Ok(r)}
}
struct ScopeOnlySessions<'a>{inner:&'a mut Sessions,scope:Rc<spqr::ynx_operation::CallScope>,pending:bool}
#[async_trait(?Send)]impl SessionStore for ScopeOnlySessions<'_>{
 fn retain_native_ciphertext(&mut self,w:&CiphertextMessage)->R<()>{self.inner.retain_native_ciphertext(w)}
 async fn load_session(&self,a:&ProtocolAddress)->R<Option<SessionRecord>>{self.inner.load_session(a).await}
 async fn store_session(&mut self,a:&ProtocolAddress,r:&SessionRecord)->R<()>{self.inner.store_session(a,r).await?;self.scope.fixture_unknown();if self.pending{let mut done=false;std::future::poll_fn(|cx|if done{std::task::Poll::Ready(())}else{done=true;cx.waker().wake_by_ref();std::task::Poll::Pending}).await;}Ok(())}
}
#[test]fn actual_established_send_scope_only_unknown_retains_generated_wire_at_both_awaits(){
 for identity in [false,true]{for pending in [false,true]{
 let(mut a,mut peer,local,remote,initial)=setup();upstream::decrypt(&mut peer.store,&local,&remote,&initial).now_or_never().unwrap().unwrap();let reply=upstream::encrypt(&mut peer.store,&local,&remote,"establish").now_or_never().unwrap().unwrap();upstream::decrypt(&mut a,&remote,&local,&reply).now_or_never().unwrap().unwrap();let mut b=FixtureBacking{store:a,generation:0};let before=b.store.load_session(&remote).now_or_never().unwrap().unwrap().unwrap().serialize().unwrap();let mut s=stage(&b,None,None);let owner=s.gate.1.clone();let mut rng=OsRng.unwrap_err();
 let result=if identity{let mut ids=ScopeOnlyIdentity{inner:&mut s.identity,scope:owner.clone(),pending};run(owner.guard(message_encrypt_with_native_retention(b"retained native wire",&remote,&local,&mut s.sessions,&mut ids,SystemTime::now(),&mut rng,Some(&owner))))}else{let mut sessions=ScopeOnlySessions{inner:&mut s.sessions,scope:owner.clone(),pending};run(owner.guard(message_encrypt_with_native_retention(b"retained native wire",&remote,&local,&mut sessions,&mut s.identity,SystemTime::now(),&mut rng,Some(&owner))))};assert!(result.is_err()||result.unwrap().is_err());s.reject();let original=s.gate.0.borrow().original_ciphertext.clone().expect("generated wire retained BEFORE awaits");assert!(s.gate.0.borrow().generated_wire);assert!(s.gate.0.borrow().phase==Phase::Unknown);assert_eq!(s.gate.0.borrow().journal.len(),if identity{1}else{2});let msg=CiphertextMessage::SignalMessage(SignalMessage::try_from(original.as_slice()).unwrap());assert_eq!(upstream::decrypt(&mut peer.store,&local,&remote,&msg).now_or_never().unwrap().unwrap(),b"retained native wire");
 owner.cancel();owner.fixture_revoke();s.cancel();assert!(s.gate.0.borrow().phase==Phase::Unknown);assert!(message_encrypt_with_native_retention(b"must not regenerate",&remote,&local,&mut s.sessions,&mut s.identity,SystemTime::now(),&mut rng,Some(&owner)).now_or_never().unwrap().is_err());assert_eq!(s.gate.0.borrow().original_ciphertext.as_deref(),Some(original.as_slice()));assert_eq!(b.store.load_session(&remote).now_or_never().unwrap().unwrap().unwrap().serialize().unwrap(),before);assert!(fixture_commit(&mut s,&mut b,0).is_err());
 }}
}
