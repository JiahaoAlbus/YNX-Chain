//! Same-custody sealed-record verification; never replace the generated pair.
use super::*;
#[derive(Debug,PartialEq,Eq)]enum Stage{Reserved,Pq,Classic,Dispose,Verified}
pub(super)struct HeldReload{pq:*mut PqOpaque,stage:Stage}
impl Drop for HeldReload{fn drop(&mut self){if !self.pq.is_null(){std::process::abort()}/* containment, not recovery */}}
impl NativeOwnKeyCustody{
 pub(super)fn authenticate_held_original(&mut self,wire:&[u8])->Result<(),CustodyError>{
  self.live()?;
  if self.platform.is_null()||!self.platform_attempted||!self.crypto_attempted||self.classic.is_none()||self.pq.is_null()||self.held_reload.is_some(){return Err(CustodyError::Phase)}
  self.verify_held_records(wire)
 }
 // Internal body also exercised with explicitly test-only protector callbacks.
 // It does not manufacture the original platform or authenticated marker.
 fn verify_held_records(&mut self,wire:&[u8])->Result<(),CustodyError>{
  self.live()?;
  if self.held_reload.is_some()||self.classic.is_none()||self.pq.is_null()||self.pqp.unseal.is_none()||self.cp.unseal.is_none(){return Err(CustodyError::Phase)}
  if self.journal.as_deref()!=Some(wire){return Err(CustodyError::Pair)}
  self.validate_records(&self.pq_record,&self.classic_record,&self.pq_public)?;
  // Same inventory owns this extra native verification resource. The C global
  // capacity32 remains enforced; allocation failure never releases originals.
  self.held_reload=Some(HeldReload{pq:std::ptr::null_mut(),stage:Stage::Reserved});
  let b=self.binding.ffi();
  self.held_reload.as_mut().ok_or(CustodyError::Phase)?.stage=Stage::Pq;
  let code=unsafe{veil_own_reload(&b,self.pq_public.as_ptr(),&self.pq_record,&self.pqp,&mut self.held_reload.as_mut().ok_or(CustodyError::Phase)?.pq)};
  self.result(code)?;
  let pointer=self.held_reload.as_ref().ok_or(CustodyError::Phase)?.pq;
  if pointer.is_null(){self.unknown=true;return Err(CustodyError::Abi)}
  self.held_reload.as_mut().ok_or(CustodyError::Phase)?.stage=Stage::Classic;
  let result=(||->Result<(),CustodyError>{
   let n=(self.classic_record.cipher_size as usize).checked_sub(16).ok_or(CustodyError::Bounds)?;
   let mut clear=Zeroizing::new(Vec::new());clear.try_reserve_exact(n).map_err(|_|CustodyError::Memory)?;clear.resize(n,0);let mut written=0;
   let code=unsafe{veil_classic_unseal_native(&b,self.pq_public.as_ptr(),&self.classic_record,&self.cp,clear.as_mut_ptr(),n,&mut written)};
   self.result(code)?;if written!=n{return Err(CustodyError::Abi)}
   let expected=self.classic.as_ref().ok_or(CustodyError::Phase)?.public_identity();
   let verified=SerializedClassicOwnKey::take_native_bytes(clear).map_err(|_|CustodyError::Pair)?.reload_for_native_binding(expected).map_err(|_|CustodyError::Pair)?;
   if verified.public_identity().serialize().as_ref()!=self.binding.classic{return Err(CustodyError::Pair)}
   let mut public=[0;2592];let code=unsafe{veil_own_public(pointer,public.as_mut_ptr())};self.result(code)?;
   if public!=self.pq_public{return Err(CustodyError::Pair)}Ok(())
  })();
  if let Err(error)=result{self.unknown=true;return Err(error)}
  let verification=self.held_reload.as_mut().ok_or(CustodyError::Phase)?;verification.stage=Stage::Dispose;
  let prior=verification.pq;let code=unsafe{veil_own_close(&mut verification.pq)};
  if(code==0&&!verification.pq.is_null())||(code!=0&&verification.pq!=prior){std::process::abort()}
  self.result(code)?;
  self.held_reload.as_mut().ok_or(CustodyError::Phase)?.stage=Stage::Verified;
  Ok(())
 }
}
#[cfg(test)]mod tests{
 use super::*;
 struct Counts{pq:usize,classic:usize,pq_seal:usize,classic_seal:usize,fail_pq:bool,fail_classic:bool}
 unsafe extern "C" fn seal_pq(ctx: *mut c_void,_:*const u8,_:usize,clear:*const u8,n:usize,nonce:*mut u8,out:*mut u8,w:*mut usize)->i32{unsafe{(*(ctx as *mut Counts)).pq_seal+=1;}if n!=4896{return 1}unsafe{std::ptr::copy_nonoverlapping(clear,out,n);std::ptr::write_bytes(out.add(n),0,16);std::ptr::write_bytes(nonce,0,12);*w=n+16;}0}
 unsafe extern "C" fn open_pq(ctx:*mut c_void,_:*const u8,_:usize,_:*const u8,cipher:*const u8,clear:*mut u8,n:usize,w:*mut usize)->i32{let c=unsafe{&mut*(ctx as *mut Counts)};c.pq+=1;if c.fail_pq{return 4}unsafe{std::ptr::copy_nonoverlapping(cipher,clear,n);*w=n;}0}
 unsafe extern "C" fn seal_c(ctx: *mut c_void,_:*const u8,_:usize,clear:*const u8,n:usize,nonce:*mut u8,out:*mut u8,cap:usize,w:*mut usize)->i32{unsafe{(*(ctx as *mut Counts)).classic_seal+=1;}if cap!=n+16{return 1}unsafe{std::ptr::copy_nonoverlapping(clear,out,n);std::ptr::write_bytes(out.add(n),0,16);std::ptr::write_bytes(nonce,0,12);*w=cap;}0}
 unsafe extern "C" fn open_c(ctx:*mut c_void,_:*const u8,_:usize,_:*const u8,cipher:*const u8,n:usize,clear:*mut u8,cap:usize,w:*mut usize)->i32{let c=unsafe{&mut*(ctx as *mut Counts)};c.classic+=1;if c.fail_classic{return 4}if n!=cap+16{return 1}unsafe{std::ptr::copy_nonoverlapping(cipher,clear,cap);*w=cap;}0}
 // Copy protection exists ONLY in cfg(test). No platform pointer, Android
 // provenance, authenticated marker or authorization is manufactured.
 struct Fixture{owner:NativeOwnKeyCustody,counts:Box<Counts>}
 impl Drop for Fixture{fn drop(&mut self){if let Some(v)=self.owner.held_reload.as_mut(){if !v.pq.is_null(){assert_eq!(unsafe{veil_own_close(&mut v.pq)},0)}}if !self.owner.pq.is_null(){assert_eq!(unsafe{veil_own_close(&mut self.owner.pq)},0)}use zeroize::Zeroize;self.owner.pq_record.cipher.zeroize();self.owner.classic_record.cipher.zeroize();if let Some(w)=self.owner.journal.as_mut(){w.zeroize()}}}
 fn fixture()->Fixture{
  let private=libsignal_protocol::PrivateKey::deserialize(&[29;32]).unwrap();let selected=libsignal_protocol::IdentityKeyPair::new(private.public_key().unwrap().into(),private);let classic=NativeClassicOwnKey::from_selected(selected).unwrap();let pk=classic.public_identity().serialize();
  let binding=StorageBinding::new("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef",1,pk.as_ref().try_into().unwrap(),vec![7]).unwrap();let owner=match NativeOwnKeyCustody::reserve(classic,binding){Ok(v)=>v,Err(_)=>panic!("pair")};
  let mut f=Fixture{owner,counts:Box::new(Counts{pq:0,classic:0,pq_seal:0,classic_seal:0,fail_pq:false,fail_classic:false})};let ctx=&mut*f.counts as *mut Counts as *mut c_void;
  f.owner.pqp=PqProtector{context:ctx,seal:Some(seal_pq),unseal:Some(open_pq)};f.owner.cp=ClassicProtector{context:ctx,seal:Some(seal_c),unseal:Some(open_c)};
  let b=f.owner.binding.ffi();assert_eq!(unsafe{veil_own_create_sealed(&b,&f.owner.pqp,&mut f.owner.pq,&mut f.owner.pq_record)},0);assert_eq!(unsafe{veil_own_public(f.owner.pq,f.owner.pq_public.as_mut_ptr())},0);
  f.owner.serialized=Some(f.owner.classic.as_ref().unwrap().serialize_for_native_custody().unwrap());let clear=&f.owner.serialized.as_ref().unwrap().bytes;
  assert_eq!(unsafe{veil_classic_seal_native(&b,f.owner.pq_public.as_ptr(),clear.as_ptr(),clear.len(),&f.owner.cp,&mut f.owner.classic_record)},0);f.owner.prepare_pair_journal().unwrap();f.owner.crypto_attempted=true;f
 }
 #[test]fn r63_retained_generated_shape_verifies_without_replacement(){
  let mut f=fixture();let pq=f.owner.pq;let classic=f.owner.classic.as_ref().unwrap() as *const _;let public=f.owner.classic.as_ref().unwrap().public_identity();let wire=f.owner.journal.as_ref().unwrap().clone();let journal=f.owner.journal.as_ref().unwrap().as_ptr();
  f.owner.verify_held_records(&wire).unwrap();assert_eq!(f.owner.pq,pq);assert_eq!(f.owner.classic.as_ref().unwrap()as *const _,classic);assert_eq!(f.owner.classic.as_ref().unwrap().public_identity(),public);assert_eq!(f.owner.journal.as_ref().unwrap().as_ptr(),journal);assert_eq!(f.owner.journal.as_deref(),Some(wire.as_slice()));assert_eq!((f.counts.pq,f.counts.classic),(1,1));assert_eq!(f.owner.held_reload.as_ref().unwrap().stage,Stage::Verified);assert!(f.owner.held_reload.as_ref().unwrap().pq.is_null());assert!(matches!(f.owner.verify_held_records(&wire),Err(CustodyError::Phase)));assert_eq!((f.counts.pq,f.counts.classic),(1,1));assert!(f.owner.platform.is_null());
 }
 #[test]fn r63_each_unseal_failure_keeps_original_and_verification_owner(){
  for fail_pq in [true,false]{let mut f=fixture();f.counts.fail_pq=fail_pq;f.counts.fail_classic=!fail_pq;let pointer=f.owner.pq;let wire=f.owner.journal.as_ref().unwrap().clone();assert!(f.owner.verify_held_records(&wire).is_err());assert_eq!(f.owner.pq,pointer);assert!(f.owner.classic.is_some());assert_eq!(f.owner.journal.as_deref(),Some(wire.as_slice()));assert_eq!(f.owner.first,Some(4));assert_eq!(f.owner.held_reload.as_ref().unwrap().pq.is_null(),fail_pq);let before=(f.counts.pq,f.counts.classic);assert!(f.owner.verify_held_records(&wire).is_err());assert_eq!((f.counts.pq,f.counts.classic),before);}
 }
 #[test]fn r63_wrong_wire_and_missing_platform_never_unseal(){let mut f=fixture();let wire=f.owner.journal.as_ref().unwrap().clone();assert!(matches!(f.owner.authenticate_held_original(&wire),Err(CustodyError::Phase)));let mut wrong=wire;wrong[0]^=1;assert!(matches!(f.owner.verify_held_records(&wrong),Err(CustodyError::Pair)));assert!(f.owner.held_reload.is_none());assert_eq!((f.counts.pq,f.counts.classic),(0,0));}
 #[test]fn r63_actual_store_committed_held_capture_same_pair_and_ids(){
  use std::os::unix::fs::DirBuilderExt;
  let mut f=fixture();let original_pq=f.owner.pq;let original_classic=f.owner.classic.as_ref().unwrap()as *const _;
  let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public fixture"));
  let dir=std::path::PathBuf::from(std::env::var_os("TMPDIR").unwrap()).join(format!("r63-pair-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));std::fs::DirBuilder::new().mode(0o700).create(&dir).unwrap();let path=CString::new(dir.join("pair.sqlite3").as_os_str().as_encoded_bytes()).unwrap();
  let mut held=predevice_port::PreDeviceOwner::unopened([31;16],[32;16]);held.reserve(&path,&input).unwrap();held.claim_generation().unwrap();let pair=f.owner.borrow_original_encrypted_pair().unwrap();held.commit(&pair).unwrap();held.verify_readback(&input,&pair).unwrap();assert!(held.readback_complete().unwrap());assert!(held.recovery_topology()==RecoveryTopology::Held);
  held.capture_for_recovery(&input).unwrap();let wire=held.capture_original_journal(&input).unwrap();assert_eq!(Some(wire),f.owner.journal.as_deref());f.owner.verify_held_records(wire).unwrap();
  assert_eq!(f.owner.pq,original_pq);assert_eq!(f.owner.classic.as_ref().unwrap()as *const _,original_classic);assert_eq!((f.counts.pq_seal,f.counts.classic_seal),(1,1));assert_eq!((f.counts.pq,f.counts.classic),(1,1));
  // Preserve the original one-shot result: capture checks its original
  // operation/incarnation/input binding; do NOT issue a second lookup.
  assert!(held.readback_complete().unwrap());
  assert!(held.recovery_topology()==RecoveryTopology::Held);
  let retained=held.capture_original_journal(&input).unwrap();
  assert_eq!(Some(retained),f.owner.journal.as_deref());
  assert_eq!(f.owner.pq,original_pq);
  assert_eq!(f.owner.classic.as_ref().unwrap()as *const _,original_classic);
  assert!(!f.owner.unknown);assert_eq!(f.owner.first,None);
  assert_eq!(f.owner.held_reload.as_ref().unwrap().stage,Stage::Verified);
  assert_eq!((f.counts.pq_seal,f.counts.classic_seal),(1,1));
  assert_eq!((f.counts.pq,f.counts.classic),(1,1));
  held.close_known().unwrap();
 }
}
