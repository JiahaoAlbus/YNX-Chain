//! Whole-component cold ABI1. Store-local disposition, never Java release/trust.
use super::*;
#[repr(C)]pub(in crate::private_custodian_ffi::predevice_port)struct Owner{_private:[u8;0]}
#[repr(C)]struct Disposition{_private:[u8;0]}
#[repr(C)]#[derive(Default,Clone,Copy)]
pub(in crate::private_custodian_ffi::predevice_port)struct Report{
 abi:u32,kind:u32,first_failure:u32,cleanup_status:u32,ownership:u32,stage:u32,
 observed_revision:i64,durable_revision:i64,
}
const _:()={assert!(std::mem::size_of::<Report>()==40);assert!(std::mem::align_of::<Report>()==8);};
unsafe extern "C"{
 fn veil_pd_cold_acquire(store:*mut *mut Store,original:*const Original,out:*mut *mut Owner,report:*mut Report)->u32;
 pub(in crate::private_custodian_ffi::predevice_port)fn veil_pd_cold_borrow(owner:*mut Owner,callback:extern "C" fn(*const Original,*const Pair,*mut c_void),context:*mut c_void,report:*mut Report)->u32;
 fn veil_pd_cold_resolve(owner:*mut Owner,out:*mut *mut Disposition,report:*mut Report)->u32;
 fn veil_pd_cold_disposition_drop(out:*mut *mut Disposition)->u32;
 fn veil_pd_cold_discharge(owner:*mut *mut Owner,out:*mut *mut Disposition,report:*mut Report)->u32;
 fn veil_pd_cold_cleanup(owner:*mut *mut Owner,report:*mut Report)->u32;
}
struct Expected{alias:Vec<u8>,association:Vec<u8>,generation:u64}
impl Expected{
 fn retain(input:&LocalGenesisInput)->Result<Self,ReaderError>{
  fn copy(v:&[u8])->Result<Vec<u8>,ReaderError>{let mut out=Vec::new();out.try_reserve_exact(v.len()).map_err(|_|ReaderError::Unavailable)?;out.extend_from_slice(v);Ok(out)}
  Ok(Self{alias:copy(input.alias.as_bytes())?,association:copy(&input.association)?,generation:input.generation})
 }
 fn matches(&self,input:&LocalGenesisInput)->bool{self.alias==input.alias.as_bytes()&&self.association==input.association&&self.generation==input.generation}
}
pub(super)struct State{
 expected:Option<Expected>,
 owner:*mut Owner,receipt:*mut Disposition,report:Report,attempted:bool,
 closed:bool,cleanup_only:bool,
}
impl State{
 pub(super)fn new()->Self{Self{expected:None,owner:std::ptr::null_mut(),receipt:std::ptr::null_mut(),report:Report::default(),attempted:false,closed:false,cleanup_only:false}}
 pub(super)fn started(&self)->bool{self.attempted}
 pub(super)fn held(&self)->bool{!self.owner.is_null()||!self.receipt.is_null()}
}
impl ExistingReader{
 fn cold_failure(&mut self,status:u32)->ReaderError{
  // Report's original primary precedes the current cleanup/status diagnostic.
  if self.cold.report.first_failure!=0{self.record(self.cold.report.first_failure as i32)}
  self.record(status as i32);
  if self.cold.report.ownership==4||status==25{self.cold.cleanup_only=true}
  if status==25{self.ambiguous_close=true}
  ReaderError::Foreign(status as i32)
 }
 fn acquire_cold(&mut self,input:&LocalGenesisInput,operation:[u8;16],incarnation:[u8;16])->Result<(),ReaderError>{
  self.on_thread()?;
  if self.cold.attempted{
   if self.read_binding!=Some((operation,incarnation))||!self.cold.expected.as_ref().is_some_and(|e|e.matches(input)){return Err(ReaderError::Foreign(21))}
   if self.cold.closed||self.cold.cleanup_only{return Err(ReaderError::Quarantined)}
   if let Some(first)=self.first{return Err(ReaderError::Foreign(first))}
   return if self.cold.owner.is_null(){Err(ReaderError::Unavailable)}else{Ok(())}
  }
  if self.first.is_some()||self.ambiguous_close||self.open_status!=Some(11)||self.store.is_null()||!self.result.is_null()||self.read_binding.is_some(){return Err(ReaderError::Unavailable)}
  self.cold.expected=Some(Expected::retain(input)?);
  self.read_binding=Some((operation,incarnation));self.cold.attempted=true;
  let original=Original{operation,incarnation,storage_generation:input.generation as i64,protected_record_version:1,alias:Bytes::borrow(input.alias.as_bytes()),original_association:Bytes::borrow(&input.association),classic_aad:Bytes::none(),pq_aad:Bytes::none()};
  let before=self.store;
  let status=unsafe{veil_pd_cold_acquire(&mut self.store,&original,&mut self.cold.owner,&mut self.cold.report)};
  // Error may publish custody. Never infer ownership from numeric status alone.
  if (!self.cold.owner.is_null()&&!self.store.is_null())||(self.cold.owner.is_null()&&self.store!=before){std::process::abort()}
  if status!=1{return Err(self.cold_failure(status))}
  if self.cold.owner.is_null()||!self.store.is_null()||self.cold.report.abi!=1{std::process::abort()}
  Ok(())
 }
 pub(in crate::private_custodian_ffi)fn capture_cold(&mut self,input:&LocalGenesisInput,operation:[u8;16],incarnation:[u8;16])->Result<&[u8],ReaderError>{
  self.acquire_cold(input,operation,incarnation)?;
  if self.captured.as_ref().is_some_and(|c|!c.matches(input)){self.record(21);return Err(ReaderError::Foreign(21))}
  if self.captured.is_none(){
   let got=super::super::capture::capture_cold_owner(self.cold.owner,input,&operation,&incarnation,&mut self.cold.report);
   self.captured=got.out;self.capture_failure=got.error;
   if self.capture_failure.is_some(){self.record(21)}
   if got.status!=2{return Err(self.cold_failure(got.status as u32))}
   if self.capture_failure.is_some(){return Err(ReaderError::Foreign(21))}
  }
  self.captured.as_ref().map(|c|c.journal()).ok_or(ReaderError::Unavailable)
 }
 pub(in crate::private_custodian_ffi)fn prepare_cold(&mut self,input:&LocalGenesisInput,operation:[u8;16],incarnation:[u8;16])->Result<(),ReaderError>{
  self.on_thread()?;
  if self.cold.closed{
   return if self.read_binding==Some((operation,incarnation))&&self.cold.expected.as_ref().is_some_and(|e|e.matches(input)){Ok(())}else{Err(ReaderError::Foreign(21))}
  }
  if self.cold.cleanup_only{
   // Normal repeated reconcile can dispose error custody, never report terminal.
   // The first error remains even when all local handles have been cleaned.
   let primary=self.first.unwrap_or(19);
   self.cleanup_cold()?;
   return Err(ReaderError::Foreign(primary))
  }
  self.acquire_cold(input,operation,incarnation)?;
  if !self.cold.receipt.is_null(){return Ok(())}
  let status=unsafe{veil_pd_cold_resolve(self.cold.owner,&mut self.cold.receipt,&mut self.cold.report)};
  if status!=3{if !self.cold.receipt.is_null(){std::process::abort()}return Err(self.cold_failure(status))}
  if self.cold.receipt.is_null()||self.cold.report.abi!=1||!matches!(self.cold.report.kind,1|2){std::process::abort()}
  Ok(())
 }
 pub(in crate::private_custodian_ffi)fn discharge_cold(&mut self)->Result<(),ReaderError>{
  self.on_thread()?;
  if self.cold.closed{return Ok(())}
  if self.cold.cleanup_only||self.cold.owner.is_null()||self.cold.receipt.is_null(){return Err(ReaderError::Unavailable)}
  let owner=self.cold.owner;let receipt=self.cold.receipt;
  let status=unsafe{veil_pd_cold_discharge(&mut self.cold.owner,&mut self.cold.receipt,&mut self.cold.report)};
  if status!=4{
   if self.cold.owner!=owner||self.cold.receipt!=receipt{std::process::abort()}
   // Failed discharge cannot be retried as a terminal success.
   self.cold.cleanup_only=true;return Err(self.cold_failure(status))
  }
  if !self.cold.owner.is_null()||!self.cold.receipt.is_null(){std::process::abort()}
  self.cold.closed=true;Ok(())
 }
 pub(in crate::private_custodian_ffi)fn cold_stage(&self)->Result<super::super::v3::LocalStoreStage,ReaderError>{
  self.on_thread()?;
  if self.cold.closed{return Ok(super::super::v3::LocalStoreStage::StoreClosed)}
  if self.cold.cleanup_only||self.cold.receipt.is_null(){return Err(ReaderError::Unavailable)}
  Ok(super::super::v3::LocalStoreStage::Held)
 }
 pub(in crate::private_custodian_ffi)fn cleanup_cold(&mut self)->Result<Cleanup,ReaderError>{
  self.on_thread()?;
  // No terminal/recovery interpretation. Explicit RAM receipt drop then cleanup.
  self.cold.cleanup_only=true;
  if !self.cold.receipt.is_null(){
   let prior=self.cold.receipt;let status=unsafe{veil_pd_cold_disposition_drop(&mut self.cold.receipt)};
   if(status==5&&!self.cold.receipt.is_null())||(status!=5&&self.cold.receipt!=prior){std::process::abort()}
   if status!=5{self.cold_failure(status);return Ok(Cleanup::Retained(status as i32))}
  }
  if self.cold.owner.is_null(){
   // Pre-publication acquire failure still owns the original existing Store.
   if self.store.is_null(){return Ok(Cleanup::NoHandle)}
   if self.ambiguous_close{return Ok(Cleanup::Quarantined)}
   let prior=self.store;let status=unsafe{veil_pd_close(&mut self.store)};
   if(status==1&&!self.store.is_null())||(status!=1&&self.store!=prior){std::process::abort()}
   self.cleanup_status=Some(status);
   if status==1{return Ok(Cleanup::Released)}
   self.record(status);if status==15{self.ambiguous_close=true}
   return Ok(Cleanup::Retained(status))
  }
  if self.ambiguous_close{return Ok(Cleanup::Quarantined)}
  let prior=self.cold.owner;let status=unsafe{veil_pd_cold_cleanup(&mut self.cold.owner,&mut self.cold.report)};
  if(status==6&&!self.cold.owner.is_null())||(status!=6&&self.cold.owner!=prior){std::process::abort()}
  self.cleanup_status=Some(status as i32);
  if status==6{return Ok(Cleanup::Released)}
  self.cold_failure(status);Ok(if status==25{Cleanup::Quarantined}else{Cleanup::Retained(status as i32)})
 }
}
#[cfg(test)]mod cold_receiver_controls{
 use super::*;
 #[test]fn cold_receiver_controls_layout_and_unopened_refusal(){
  assert_eq!(std::mem::size_of::<Report>(),40);assert_eq!(std::mem::align_of::<Report>(),8);
  let mut r=ExistingReader::unopened();
  let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public metadata"));
  assert_eq!(r.prepare_cold(&input,[1;16],[2;16]),Err(ReaderError::Unavailable));
  assert!(!r.cold.started());assert!(!r.cold.held());
 }
 #[test]fn cold_receiver_controls_real_reserved_existing_fence_discharge(){
  use std::os::unix::fs::DirBuilderExt;
  let dir=std::path::PathBuf::from(std::env::var_os("TMPDIR").expect("external TMPDIR")).join(format!("cold-public-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
  std::fs::DirBuilder::new().mode(0o700).create(&dir).unwrap();
  let path=std::ffi::CString::new(dir.join("pair.sqlite3").as_os_str().as_encoded_bytes()).unwrap();
  let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public metadata"));
  let mut original=PreDeviceOwner::unopened([1;16],[2;16]);
  original.reserve(&path,&input).unwrap();original.close_known().unwrap();
  let mut r=ExistingReader::unopened();r.open_once(&path).unwrap();
  r.prepare_cold(&input,[1;16],[2;16]).unwrap();
  assert!(r.store.is_null());assert!(!r.cold.owner.is_null());assert_eq!(r.cold.report.kind,2);
  let receipt=r.cold.receipt;r.prepare_cold(&input,[1;16],[2;16]).unwrap();assert_eq!(r.cold.receipt,receipt);
  r.discharge_cold().unwrap();assert!(matches!(r.cold_stage(),Ok(super::super::super::v3::LocalStoreStage::StoreClosed)));
  assert!(!r.cold.held());r.discharge_cold().unwrap();
 }
 fn reserved()->(std::ffi::CString,LocalGenesisInput){
  use std::os::unix::fs::DirBuilderExt;
  let dir=std::path::PathBuf::from(std::env::var_os("TMPDIR").unwrap()).join(format!("cold-join-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
  std::fs::DirBuilder::new().mode(0o700).create(&dir).unwrap();
  let path=std::ffi::CString::new(dir.join("pair.sqlite3").as_os_str().as_encoded_bytes()).unwrap();
  let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public metadata"));
  let mut original=PreDeviceOwner::unopened([1;16],[2;16]);original.reserve(&path,&input).unwrap();original.close_known().unwrap();(path,input)
 }
 #[test]fn cold_receiver_controls_actual_normal_loan_routes_existing(){
  // Public original-journal fixture only, not a constructed authentication grant.
  let(path,input)=reserved();
  let mut reservation=crate::private_custodian_ffi::LocalGenesisReservation::retain(input);
  let mut failed=PreDeviceOwner::unopened([1;16],[2;16]);
  assert!(failed.reserve(&std::ffi::CString::new("relative").unwrap(),&reservation.input).is_err());
  let original_primary=failed.first;assert_eq!(original_primary,Some(10));
  reservation.predevice=Some(failed);
  let mut ids=[0;32];ids[..16].fill(1);ids[16..].fill(2);reservation.local_ids=Some(ids);
  let mut reader=ExistingReader::unopened();reader.open_once(&path).unwrap();reservation.existing_reader=Some(reader);
  let mut loan=reservation.recovery_loan().unwrap();
  loan.prepare_original_local_disposition().unwrap();
  assert!(matches!(loan.original_local_store_stage(),Ok(super::super::super::v3::LocalStoreStage::Held)));
  loan.discharge_original_local_store().unwrap();
  assert!(matches!(loan.original_local_store_stage(),Ok(super::super::super::v3::LocalStoreStage::StoreClosed)));
  assert!(reservation.predevice.as_ref().unwrap().unknown);
  assert_eq!(reservation.predevice.as_ref().unwrap().first,original_primary);
 }
 #[test]fn cold_receiver_controls_actual_mismatch_retains_then_cleanup(){
  let(path,input)=reserved();let mut r=ExistingReader::unopened();r.open_once(&path).unwrap();
  assert!(r.prepare_cold(&input,[9;16],[2;16]).is_err());
  let primary=r.first;assert!(primary.is_some());
  // Whether failure happened before or after publication, one custody remains.
  assert!(r.cold.held()||!r.store.is_null());
  assert!(matches!(r.cleanup(),Ok(Cleanup::Released)));
  assert_eq!(r.first,primary);assert!(!r.cold.held()&&r.store.is_null());
  assert!(r.prepare_cold(&input,[1;16],[2;16]).is_err());
  assert_eq!(r.first,primary);assert!(r.cold_stage().is_err());
 }
}

#[cfg(test)]mod cold_sealed_controls{
 use super::*;
 static NEXT:std::sync::atomic::AtomicU64=std::sync::atomic::AtomicU64::new(0);
 fn input()->LocalGenesisInput{LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public metadata"))}
 fn sealed()->(std::ffi::CString,Vec<u8>){
  use std::os::unix::fs::DirBuilderExt;
  let dir=std::path::PathBuf::from(std::env::var_os("TMPDIR").unwrap()).join(format!("sealed-public-{}-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos(),NEXT.fetch_add(1,std::sync::atomic::Ordering::Relaxed)));
  std::fs::DirBuilder::new().mode(0o700).create(&dir).unwrap();
  let path=std::ffi::CString::new(dir.join("pair.sqlite3").as_os_str().as_encoded_bytes()).unwrap();
  let mut pq=crate::private_custodian_ffi::PqRecord{version:1,aad_size:1,aad:[0;7168],nonce:[0;12],cipher:[0;4912]};pq.aad[0]=7;
  let mut classic=crate::private_custodian_ffi::ClassicRecord{version:1,aad_size:1,cipher_size:17,aad:[0;7168],nonce:[0;12],cipher:[0;272]};classic.aad[0]=8;
  let wire=crate::private_custodian_ffi::encode_pair(&pq,&classic).unwrap();
  let pn=u32::from_be_bytes(wire[12..16].try_into().unwrap())as usize;
  let cn=u32::from_be_bytes(wire[16..20].try_into().unwrap())as usize;
  let pair=PairBorrow::from_slices(&wire[20+pn..20+pn+cn],&wire[20..20+pn],&wire,&classic.aad[..1],&pq.aad[..1]);
  let mut owner=PreDeviceOwner::unopened([1;16],[2;16]);owner.reserve(&path,&input()).unwrap();owner.claim_generation().unwrap();owner.commit(&pair).unwrap();owner.close_known().unwrap();
  (path,wire)
 }
 fn loan_owner(path:&CStr)->crate::private_custodian_ffi::LocalGenesisReservation{
  let mut out=crate::private_custodian_ffi::LocalGenesisReservation::retain(input());
  let mut failed=PreDeviceOwner::unopened([1;16],[2;16]);assert!(failed.reserve(&std::ffi::CString::new("relative").unwrap(),&out.input).is_err());
  out.predevice=Some(failed);let mut ids=[0;32];ids[..16].fill(1);ids[16..].fill(2);out.local_ids=Some(ids);
  let mut reader=ExistingReader::unopened();reader.open_once(path).unwrap();out.existing_reader=Some(reader);out
 }
 #[test]fn cold_sealed_controls_normal_loan_repeats_after_publication_failure(){
  let(path,wire)=sealed();let mut original=loan_owner(&path);
  assert_eq!(original.existing_reader.as_mut().unwrap().capture_original(&input(),[1;16],[2;16]).unwrap(),wire);
  let primary=original.predevice.as_ref().unwrap().first;
  {
   let mut loan=original.recovery_loan().unwrap();loan.prepare_original_local_disposition().unwrap();loan.discharge_original_local_store().unwrap();
   // Same failure-recording path used after failed JNI Context/Throwable guard.
   loan.fail(43);
   for _ in 0..2{loan.prepare_original_local_disposition().unwrap();loan.discharge_original_local_store().unwrap();assert!(matches!(loan.original_local_store_stage(),Ok(super::super::super::v3::LocalStoreStage::StoreClosed)));}
  }
  let r=original.existing_reader.as_ref().unwrap();assert!(!r.cold.held());assert_eq!(r.cold.report.kind,1);assert_eq!(r.cold.report.durable_revision,2);
  assert_eq!(original.first_recovery_failure,Some(43));assert_eq!(original.predevice.as_ref().unwrap().first,primary);assert!(original.predevice.as_ref().unwrap().unknown);
  // Exact original fields remain required even after C pointers have gone.
  original.local_ids.as_mut().unwrap()[0]^=1;
  assert!(original.recovery_loan().unwrap().prepare_original_local_disposition().is_err());
  original.local_ids.as_mut().unwrap()[0]^=1;original.input.association[0]^=1;
  assert!(original.recovery_loan().unwrap().discharge_original_local_store().is_err());
 }
 #[test]fn cold_sealed_controls_postborrow_inode_failure_retains_bytes_and_owner(){
  let(path,wire)=sealed();let mut r=ExistingReader::unopened();r.open_once(&path).unwrap();
  let p=std::path::PathBuf::from(path.to_str().unwrap());let replacement=p.with_extension("replacement");let saved=p.with_extension("original");
  std::fs::copy(&p,&replacement).unwrap();
  super::super::super::capture::POST_CAPTURE.with(|slot|*slot.borrow_mut()=Some(Box::new(move||{
   std::fs::rename(&p,&saved).unwrap();std::fs::rename(&replacement,&p).unwrap();
  })));
  assert!(r.capture_original(&input(),[1;16],[2;16]).is_err());
  assert!(!r.cold.owner.is_null());assert_eq!(r.captured.as_ref().unwrap().journal(),wire);
  let owner=r.cold.owner;let first=r.first;assert!(first.is_some());
  assert!(r.capture_original(&input(),[1;16],[2;16]).is_err());assert_eq!(r.cold.owner,owner);assert_eq!(r.first,first);
  assert!(matches!(r.cleanup(),Ok(Cleanup::Released)));assert_eq!(r.first,first);assert!(r.cold_stage().is_err());
  assert!(r.prepare_cold(&input(),[1;16],[2;16]).is_err());
 }
 #[test]fn cold_sealed_controls_unverified_cipher_does_not_install_protector(){
  let(path,wire)=sealed();let mut original=loan_owner(&path);
  assert_eq!(original.existing_reader.as_mut().unwrap().capture_original(&input(),[1;16],[2;16]).unwrap(),wire);
  assert!(original.custody.is_none()&&!original.reload_attempted);
  assert!(matches!(unsafe{original.recovery_loan().unwrap().authenticate_captured(std::ptr::null_mut(),std::ptr::null_mut())},Err(CustodyError::Phase)));
  assert!(original.custody.is_none()&&!original.reload_attempted);
  assert!(matches!(original.existing_reader.as_mut().unwrap().cleanup(),Ok(Cleanup::Released)));
 }
}
