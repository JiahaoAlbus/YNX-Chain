//! Separate signed first-prepared capability. This module does not create a
//! device permission or broaden the old source-envelope signing role gate.
use super::*;
use sha2::{Digest, Sha256};

const MAX_INTEGER:u64=(1u64<<53)-1;
const ISSUER_ROLE:&str="first-prepared-issuer";
const ANCHOR_ROLE:&str="first-prepared-anchor";

#[derive(Clone,Serialize,Deserialize,PartialEq,Eq)]
#[serde(deny_unknown_fields,rename_all="camelCase")]
pub(super)struct Issuance {
 version:u64,purpose:String,role:String,realm:String,deployment:String,instance:String,
 #[serde(rename="headerSHA256")]header:String,
 directory_schema:String,lifecycle_schema:String,history_admission:String,finalization:String,
 account_issuer:String,client_id:String,writer_authority:String,key_alias:String,storage_generation:u64,
 #[serde(rename="notBeforeMS")]not_before:i64,
 #[serde(rename="expiresMS")]expires:i64,
}

impl Issuance {
 pub(super)fn holder_storage(&self)->(&str,u64,i64,i64){(&self.key_alias,self.storage_generation,self.not_before,self.expires)}
 // Shared writer is the issuer, not the independently authorized anchor.
 // Anchor-to-issuer association is checked by the joint policy/pending path.
 pub(super)fn holder_authority(&self,role:&str,authority:&str)->bool{match role{"issuer"=>self.writer_authority==authority,"anchor"=>true,_=>false}}
 pub(super)fn valid(&self,credential_role:&str)->bool {
  let role=match credential_role{"issuer"=>ISSUER_ROLE,"anchor"=>ANCHOR_ROLE,_=>return false};
  self.version==1&&self.purpose=="SOURCE_FIRST_PREPARED_DUAL_V1"&&self.role==role&&
  ascii(&self.realm,128)&&ascii(&self.deployment,512)&&ascii(&self.instance,512)&&digest(&self.header)&&self.header.bytes().any(|b|b!=b'0')&&
  self.directory_schema=="YNX-SOCIAL-FIRST-DIRECTORY-V3"&&self.lifecycle_schema=="YNX-SOCIAL-GENESIS-LIFECYCLE-V2"&&self.history_admission=="EXACT_ACCOUNT_NAMESPACE_COMPLETE_PREFIX_V1"&&self.finalization=="SAME_ORIGINAL_OWNER_THROUGH_EFFECT_V1"&&
  self.account_issuer=="https://wallet-auth.ynxweb4.com"&&ascii(&self.client_id,128)&&ascii(&self.writer_authority,512)&&ascii(&self.key_alias,128)&&
  self.storage_generation>0&&self.storage_generation<=MAX_INTEGER&&self.not_before>=0&&self.expires>self.not_before&&(self.expires as u64)<=MAX_INTEGER
 }
}

fn pair_valid(issuer:&Issuance,anchor:&Issuance)->bool {
 if !issuer.valid("issuer")||!anchor.valid("anchor"){return false}
 let mut i=issuer.clone();let mut a=anchor.clone();
 for p in [&mut i,&mut a]{p.role.clear();p.key_alias.clear();p.storage_generation=0;p.not_before=0;p.expires=0;}
 i==a
}

pub(super)fn policy_digest(issuer:&Issuance,anchor:&Issuance)->Result<String,Error> {
 if !pair_valid(issuer,anchor){return Err(Error::Binding)}
 let mut h=Sha256::new();h.update(b"YNX/SOCIAL/FIRST-PREPARED-POLICY/V1\0");
 for p in [issuer,anchor]{
  let raw=serde_json::to_string(p).map_err(|_|Error::Canonical)?;
  let raw=raw.replace('&',"\\u0026").replace('<',"\\u003c").replace('>',"\\u003e").replace('\u{2028}',"\\u2028").replace('\u{2029}',"\\u2029");
  if raw.len()>32768{return Err(Error::Bounds)}
  h.update((raw.len() as u32).to_be_bytes());h.update(raw.as_bytes());
 }
 Ok(h.finalize().iter().map(|b|format!("{b:02x}")).collect())
}

impl Issuance {
 pub(super) fn pending_coordinates(&self,authority:&str,realm:&str,account_issuer:&str,client:&str,deployment:&str,instance:&str,header:&str,issued:i64,expires:i64)->bool {
  self.deployment==deployment&&self.instance==instance&&self.header==header&&self.writer_authority==authority&&self.realm==realm&&self.account_issuer==account_issuer&&self.client_id==client&&issued>=self.not_before&&expires<=self.expires
 }
}

#[cfg(test)]mod controls {
 use super::*;
 pub(super)fn fixture()->(Issuance,Issuance){
  let i=Issuance{version:1,purpose:"SOURCE_FIRST_PREPARED_DUAL_V1".into(),role:ISSUER_ROLE.into(),realm:"PUBLIC-realm".into(),deployment:"PUBLIC-deployment".into(),instance:"PUBLIC-instance".into(),header:"a".repeat(64),directory_schema:"YNX-SOCIAL-FIRST-DIRECTORY-V3".into(),lifecycle_schema:"YNX-SOCIAL-GENESIS-LIFECYCLE-V2".into(),history_admission:"EXACT_ACCOUNT_NAMESPACE_COMPLETE_PREFIX_V1".into(),finalization:"SAME_ORIGINAL_OWNER_THROUGH_EFFECT_V1".into(),account_issuer:"https://wallet-auth.ynxweb4.com".into(),client_id:"PUBLIC-client".into(),writer_authority:"PUBLIC-writer".into(),key_alias:"PUBLIC-issuer-key".into(),storage_generation:1,not_before:100,expires:200000};
  let mut a=i.clone();a.role=ANCHOR_ROLE.into();a.key_alias="PUBLIC-anchor-key".into();a.storage_generation=2;(i,a)
 }
 #[test]fn first_prepared_policy_distinct_capability(){
  let(i,a)=fixture();assert!(pair_valid(&i,&a));assert!(!i.valid("anchor"));assert!(!a.valid("issuer"));assert!(!i.valid("other"));
  for name in ["purpose","role","lifecycle","admission","finalization","generation","window","unsafe-window","header","client"]{
   let mut p=i.clone();match name{
    "purpose"=>p.purpose="SOURCE_PROOF_ARTIFACT_V1".into(),"role"=>p.role="directory-checkpoint".into(),"lifecycle"=>p.lifecycle_schema="YNX-SOCIAL-GENESIS-LIFECYCLE-V1".into(),"admission"=>p.history_admission="FIRST_ACCOUNT_ORIGINS_DUAL_PROOFS_CHECKPOINT_V1".into(),"finalization"=>p.finalization="SAME_INODE_SINGLE_WRITER_SOURCE_EXPIRY_V1".into(),"generation"=>p.storage_generation=0,"window"=>p.expires=p.not_before,"unsafe-window"=>p.expires=1i64<<53,"header"=>p.header="0".repeat(64),"client"=>p.client_id.clear(),_=>unreachable!(),
   }assert!(!p.valid("issuer"),"{name}");
  }
  let first=policy_digest(&i,&a).unwrap();assert_eq!(first,"93ca5035ac301f529ffeef0715a57a495240b777b80dfc75f78b028659fe131d");let mut a=a.clone();a.storage_generation+=1;assert_ne!(first,policy_digest(&i,&a).unwrap());
  a.client_id="PUBLIC-other-client".into();assert!(!pair_valid(&i,&a));
 }
 #[test]fn first_prepared_policy_canonical_rejects_unknown_duplicate(){
  let(i,_)=fixture();let raw=serde_json::to_vec(&i).unwrap();assert!(canonical::<Issuance>(&raw,32768).is_ok());
  let text=String::from_utf8(raw).unwrap();
  for changed in [format!(" {text}"),text.replacen("\"version\":1","\"version\":1,\"version\":1",1),text.replacen("\"version\":1","\"version\":1,\"unknown\":true",1)]{assert!(canonical::<Issuance>(changed.as_bytes(),32768).is_err());}
 }
}
#[cfg(test)]mod pending_coordinate_regression{
 use super::*;
 #[test]fn independent_policy_deployment_coordinates(){
  let raw=br#"{"version":1,"purpose":"SOURCE_FIRST_PREPARED_DUAL_V1","role":"first-prepared-issuer","realm":"r","deployment":"d","instance":"i","headerSHA256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","directorySchema":"YNX-SOCIAL-FIRST-DIRECTORY-V3","lifecycleSchema":"YNX-SOCIAL-GENESIS-LIFECYCLE-V2","historyAdmission":"EXACT_ACCOUNT_NAMESPACE_COMPLETE_PREFIX_V1","finalization":"SAME_ORIGINAL_OWNER_THROUGH_EFFECT_V1","accountIssuer":"https://wallet-auth.ynxweb4.com","clientId":"c","writerAuthority":"w","keyAlias":"k","storageGeneration":1,"notBeforeMS":100,"expiresMS":200}"#;
  let p:Issuance=canonical(raw,32768).unwrap();
  let check=|d:&str,i:&str,h:&str|p.pending_coordinates("w","r","https://wallet-auth.ynxweb4.com","c",d,i,h,100,199);
  assert!(check("d","i",&"a".repeat(64)));
  assert!(!check("other","i",&"a".repeat(64)));
  assert!(!check("d","other",&"a".repeat(64)));
  assert!(!check("d","i",&"b".repeat(64)));
 }
}
#[cfg(test)]mod independent_holder_authority_controls{
 use super::*;
 #[test]fn common_writer_preserves_independent_anchor_authority(){
  let(i,a)=controls::fixture();
  let issuer="PUBLIC-writer";let anchor="PUBLIC-independent-anchor";
  assert_ne!(issuer,anchor);assert!(pair_valid(&i,&a));
  assert!(i.holder_authority("issuer",issuer));
  assert!(!i.holder_authority("issuer",anchor));
  assert!(a.holder_authority("anchor",anchor));
  assert!(!a.holder_authority("unknown",anchor));
  // Pair/pending still bind BOTH policies to the common actual issuer.
  assert!(a.pending_coordinates(issuer,"PUBLIC-realm","https://wallet-auth.ynxweb4.com","PUBLIC-client","PUBLIC-deployment","PUBLIC-instance",&"a".repeat(64),100,1000));
  assert!(!a.pending_coordinates(anchor,"PUBLIC-realm","https://wallet-auth.ynxweb4.com","PUBLIC-client","PUBLIC-deployment","PUBLIC-instance",&"a".repeat(64),100,1000));
 }
}
