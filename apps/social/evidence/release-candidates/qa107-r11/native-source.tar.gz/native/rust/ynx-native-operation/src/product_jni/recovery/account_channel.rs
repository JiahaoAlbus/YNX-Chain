//! Actual same LOCAL/recovery/request intake. Not an account authorization.
use super::*;
std::thread_local!{static PENDING_M1QA_PEER:std::cell::Cell<Option<u64>>=const{std::cell::Cell::new(None)};}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilNativeAccountChannel_nativeSelectM1QaPeer(_env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass)->i32{
 boundary(||{if let Err(code)=thread_check(false){return code}let id=match LOCAL.with(|cell|{let local=cell.try_borrow().map_err(|_|BUSY)?;let owner=local.as_ref().ok_or(NOT_OPEN)?;if owner.closed{return Err(CLOSED_NO_EFFECT)};owner.genesis.as_ref().map(|g|g.routing_id()).ok_or(43)}){Ok(id)=>id,Err(code)=>return code};PENDING_M1QA_PEER.with(|v|{if v.get().is_some(){43}else{v.set(Some(id));0}})})
}
const INSTANCE_REQUIRED:i32=203;
const ACCOUNT_FACTS_UNADMITTED:i32=204;
fn private_bytes(env:&mut jni::Env<'_>,borrow:&JObject<'_>,cookie:bool)->jni::errors::Result<Option<zeroize::Zeroizing<Vec<u8>>>>{
 let raw=if cookie{recovery_callback(||env.call_method(borrow,jni::jni_str!("cookieForNative"),jni::jni_sig!("()[B"),&[]))?}else{recovery_callback(||env.call_method(borrow,jni::jni_str!("bodyForNative"),jni::jni_sig!("()[B"),&[]))?}.l()?;
 let array=JByteArray::cast_local(env,raw)?;
 let n=env.get_array_length(&array)?;if !(1..=8192).contains(&n){return Ok(None)}
 let owned=zeroize::Zeroizing::new(env.convert_byte_array(&array)?);
 env.set_byte_array_region(&array,0,&vec![0i8;n as usize])?;
 Ok(Some(owned))
}
// Signal's pinned companion fork defaults revocation off. Enable it explicitly
// before platform initialization; never interpret JNI failure as success.
#[cfg(any(target_os="android",test))]
fn configure_platform_revocation(env:&mut jni::Env<'_>)->jni::errors::Result<bool>{
 if env.exception_check(){return Ok(false)}
 recovery_callback(||env.call_static_method(jni::jni_str!("org/rustls/platformverifier/CertificateVerifier"),jni::jni_str!("setShouldCheckRevocation"),jni::jni_sig!("(Z)V"),&[jni::objects::JValue::Bool(true)]))?.v()?;
 recovery_callback(||env.call_static_method(jni::jni_str!("org/rustls/platformverifier/CertificateVerifier"),jni::jni_str!("getShouldCheckRevocation"),jni::jni_sig!("()Z"),&[]))?.z()
}
fn current(env:&mut jni::Env<'_>,borrow:&JObject<'_>)->jni::errors::Result<()>{
 recovery_callback(||env.call_method(borrow,jni::jni_str!("requireCurrent"),jni::jni_sig!("()V"),&[]))?;Ok(())
}
fn public_bytes(env:&mut jni::Env<'_>,borrow:&JObject<'_>,issuer:bool)->jni::errors::Result<Option<Vec<u8>>>{
 let raw=if issuer{recovery_callback(||env.call_method(borrow,jni::jni_str!("issuerForNative"),jni::jni_sig!("()[B"),&[]))?}else{recovery_callback(||env.call_method(borrow,jni::jni_str!("targetForNative"),jni::jni_sig!("()[B"),&[]))?}.l()?;
 let array=JByteArray::cast_local(env,raw)?;
 if !(1..=65536).contains(&env.get_array_length(&array)?){return Ok(None)}
 Ok(Some(env.convert_byte_array(&array)?))
}
unsafe fn prepare(raw:*mut jni::sys::JNIEnv,context_raw:jni::sys::jobject,input_raw:jni::sys::jobject,borrow_raw:jni::sys::jobject)->i32{
 if let Err(code)=thread_check(false){return code}
 if raw.is_null()||context_raw.is_null()||input_raw.is_null()||borrow_raw.is_null(){return 43}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(raw)};
 let result=unowned.with_env_no_catch(|env|->jni::errors::Result<i32>{
  if env.exception_check(){return Ok(16)}
  let context=unsafe{JObject::from_raw(env,context_raw)};let input=unsafe{JObject::from_raw(env,input_raw)};let borrowed=unsafe{JObject::from_raw(env,borrow_raw)};
  if !env.is_instance_of(&borrowed,jni::jni_str!("com/ynx/social/matrix/VeilSocialLoginClient$AccountChannelBorrow"))?{return Ok(43)}
  let command=env.get_field(&input,jni::jni_str!("originalCommand"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;"))?.l()?;
  let code=guard_context(env,&input,&command,true,Some(&context))?;if code!=44{return Ok(code)}
  current(env,&borrowed)?;
  let Some(issuer)=public_bytes(env,&borrowed,true)?else{return Ok(43)};
  let Some(target)=public_bytes(env,&borrowed,false)?else{return Ok(43)};
  let window=match loan(|r|r.account_transport_window(&issuer,&target)){Ok(Ok(w))=>w,Err(c)=>return Ok(c),_=>return Ok(43)};
  current(env,&borrowed)?;
  #[cfg(target_os="android")]{
   if !configure_platform_revocation(env)?{return Ok(fail())}
   // Existing selected platform verifier. No fake root or permissive verifier.
   // The Kotlin verifier companion must be packaged before runtime use.
   let context_copy=env.new_local_ref(&context)?;
   recovery_callback(||rustls_platform_verifier::android::init_with_env(env,context_copy))?;
  }
  let global=env.new_global_ref(&borrowed)?;
  let retained=match loan(|r|r.hold_account_transport_borrow(env,global)){Ok(v)=>v?,Err(c)=>return Ok(c)};
  if !retained{return Ok(43)}
  // ALL Java callbacks precede final same-request/native window revalidation.
  current(env,&borrowed)?;
  if guard_context(env,&input,&command,true,Some(&context))?!=44{return Ok(fail())}
  if window.remaining().is_err(){return Ok(16)}
  match loan(|r|r.account_transport_window(&issuer,&target)){Ok(Ok(_))=>{},Err(c)=>return Ok(c),_=>return Ok(16)}
  #[cfg(feature="abi5-final-native-link")]{
   // A second normal call after the exact pending-prefix refresh uses retained
   // account facts; it never repeats HTTP capture/nonce/bootstrap acquisition.
   match loan(|r|r.first_device_source_ready()){
    Ok(Ok(true))=>{
     if !matches!(loan(|r|r.sign_first_device_original()),Ok(Ok(()))){return Ok(fail())}
     let late=(||->jni::errors::Result<bool>{
      current(env,&borrowed)?;
      if guard_context(env,&input,&command,true,Some(&context))?!=44{return Ok(false)}
      Ok(matches!(loan(|r|r.recheck_account_exchange()),Ok(Ok(()))))
     })();
     match late{Ok(true)=>{},other=>{
      let _=loan(|r|r.invalidate_first_device_signing());
      match other{Err(e)=>return Err(e),_=>return Ok(fail())}
     }}
     // Signatures remain in same private attempts. Neither output nor JNI204
     // is a device grant/receipt; server participant/finalize still missing.
     return Ok(ACCOUNT_FACTS_UNADMITTED)
    },Ok(Ok(false))=>{},_=>return Ok(fail()),
   }
  }
  // Independent release-owned R2 bootstrap, NEVER response/Java supplied roots.
  // Unconfigured production still refuses before reading cookies or any HTTP.
  let bootstrap=match crate::account_instance::Bootstrap::selected(){Ok(v)=>v,Err(crate::account_instance::Error::Required)=>return Ok(INSTANCE_REQUIRED),Err(_)=>return Ok(fail())};
  let Some(cookie)=private_bytes(env,&borrowed,true)?else{return Ok(43)};
  let Some(body)=private_bytes(env,&borrowed,false)?else{return Ok(43)};
  let revision=recovery_callback(||env.call_method(&borrowed,jni::jni_str!("revisionForNative"),jni::jni_sig!("()J"),&[]))?.j()?;
  if !(1..=9007199254740991).contains(&revision){return Ok(43)}
  current(env,&borrowed)?;
  if guard_context(env,&input,&command,true,Some(&context))?!=44{return Ok(fail())}
  let attempt=match loan(|r|r.begin_account_exchange(bootstrap,cookie,body,revision as u64)){Ok(Ok(v))=>v,Err(c)=>return Ok(c),_=>return Ok(fail())};
  let result=attempt.run(||{
   if env.exception_check(){return Err(crate::account_https::Error::Cancelled)}
   if current(env,&borrowed).is_err(){return Err(crate::account_https::Error::Cancelled)}
   if !matches!(guard_context(env,&input,&command,true,Some(&context)),Ok(44)){return Err(crate::account_https::Error::Cancelled)}
   match loan(|r|r.account_transport_window(&issuer,&target)){Ok(Ok(w))=>w.remaining().map(|_|()),_=>Err(crate::account_https::Error::Cancelled)}
  });
  // All callbacks precede final same-original native lifetime fence. Failure
  // retains capture/partial/UNKNOWN; it does not retry, sign or clear genesis.
  if result.is_err(){return Ok(fail())}
  if !matches!(loan(|r|r.complete_account_exchange()),Ok(Ok(()))){return Ok(fail())}
  current(env,&borrowed)?;
  if guard_context(env,&input,&command,true,Some(&context))?!=44{return Ok(fail())}
  match loan(|r|r.account_transport_window(&issuer,&target)){Ok(Ok(w))if w.remaining().is_ok()&&attempt.recheck().is_ok()&&matches!(loan(|r|r.recheck_account_exchange()),Ok(Ok(())))=>Ok(ACCOUNT_FACTS_UNADMITTED),Err(c)=>Ok(c),_=>Ok(fail())}
 }).into_outcome();
 match result{jni::Outcome::Ok(code)=>code,jni::Outcome::Err(_)=>fail(),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilNativeAccountChannel_nativePrepare(env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject,borrow:jni::sys::jobject)->i32{boundary(||{let selected=PENDING_M1QA_PEER.with(|v|v.replace(None));let peer=if let Some(id)=selected{let same=LOCAL.with(|cell|cell.try_borrow().ok().and_then(|local|local.as_ref().map(|owner|!owner.closed&&owner.genesis.as_ref().is_some_and(|g|g.routing_id()==id))).unwrap_or(false));if !same{return 43}crate::account_https::ConnectPeer::M1Qa}else{crate::account_https::ConnectPeer::SystemDns};crate::account_https::with_prepare_peer(peer,||unsafe{prepare(env,context,input,borrow)})})}
#[cfg(test)]mod controls{
 use super::*;
 #[test]fn account_channel_no_actor_before_jni(){std::thread::spawn(||{
  assert_eq!(Java_com_ynx_social_matrix_VeilNativeAccountChannel_nativePrepare(std::ptr::null_mut(),std::ptr::null_mut(),std::ptr::null_mut(),std::ptr::null_mut(),std::ptr::null_mut()),21);assert!(LOCAL.with(|l|l.borrow().is_none()));
 }).join().unwrap()}
}
#[cfg(test)]mod provider_controls{
 use super::*;use std::ffi::{c_void,CString};
 #[link(name="jvm")]unsafe extern "C"{fn JNI_CreateJavaVM(vm:*mut *mut jni::sys::JavaVM,env:*mut *mut c_void,args:*mut c_void)->i32;}
 #[test]fn provider_jvm_revocation_normal_helper(){
  let path=std::env::var("VEIL_PUBLIC_PROVIDER_CLASSES").expect("explicit PUBLIC fixture classpath required");
  let option=CString::new(format!("-Djava.class.path={path}")).unwrap();
  let mut options=[jni::sys::JavaVMOption{optionString:option.as_ptr() as *mut _,extraInfo:std::ptr::null_mut()}];
  let mut args=jni::sys::JavaVMInitArgs{version:jni::sys::JNI_VERSION_1_8,nOptions:1,options:options.as_mut_ptr(),ignoreUnrecognized:false};
  let mut vm=std::ptr::null_mut();let mut raw=std::ptr::null_mut();
  assert_eq!(unsafe{JNI_CreateJavaVM(&mut vm,&mut raw,&mut args as *mut _ as *mut c_void)},0);
  let mut unowned=unsafe{jni::EnvUnowned::from_raw(raw as *mut jni::sys::JNIEnv)};
  let result=unowned.with_env_no_catch(|env|->jni::errors::Result<()>{
   for mode in 0..4{
    env.set_static_field(jni::jni_str!("org/rustls/platformverifier/CertificateVerifier"),jni::jni_str!("mode"),jni::jni_sig!("I"),JValue::Int(mode))?;
    let before=env.get_static_field(jni::jni_str!("org/rustls/platformverifier/CertificateVerifier"),jni::jni_str!("calls"),jni::jni_sig!("I"))?.i()?;
    let outcome=configure_platform_revocation(env);
    if mode<2{assert_eq!(outcome?,mode==0)}else{assert!(outcome.is_err());assert!(env.exception_check());
     // Pending throwable is retained and prevents a second effect.
     assert!(!configure_platform_revocation(env)?);assert!(env.exception_check());env.exception_clear();
    }
    let after=env.get_static_field(jni::jni_str!("org/rustls/platformverifier/CertificateVerifier"),jni::jni_str!("calls"),jni::jni_sig!("I"))?.i()?;
    assert_eq!(after,before+1);assert!(!LOCAL_EXECUTING.with(|v|v.get()));
   }
   Ok(())
  }).into_outcome();
  match result{jni::Outcome::Ok(())=>{},_=>panic!("PUBLIC provider control failed")}
 }
}


// Actual NORMAL JNI observation entry, public carrier only. Eight byte arrays:
// issuer classic/PQ, target classic/PQ, original operation32, nonce32, I/T wires.
// The wires retain original principals/epoch/deadline; never a device grant.
unsafe fn observe_signatures(raw:*mut jni::sys::JNIEnv,context_raw:jni::sys::jobject,input_raw:jni::sys::jobject,borrow_raw:jni::sys::jobject)->jni::sys::jobjectArray{
 if thread_check(false).is_err()||raw.is_null()||context_raw.is_null()||input_raw.is_null()||borrow_raw.is_null(){return std::ptr::null_mut()}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(raw)};
 let result=unowned.with_env_no_catch(|env|->jni::errors::Result<jni::sys::jobjectArray>{
  if env.exception_check(){return Ok(std::ptr::null_mut())}
  let context=unsafe{JObject::from_raw(env,context_raw)};let input=unsafe{JObject::from_raw(env,input_raw)};let borrowed=unsafe{JObject::from_raw(env,borrow_raw)};
  let mut output_attempted=false;
  let outcome=(||->jni::errors::Result<jni::sys::jobjectArray>{
   let command=env.get_field(&input,jni::jni_str!("originalCommand"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;"))?.l()?;
   current(env,&borrowed)?;
   if guard_context(env,&input,&command,true,Some(&context))?!=44{return Ok(std::ptr::null_mut())}
   if !matches!(loan(|r|r.matches_original_account_borrow(env,&borrowed)),Ok(Ok(true))){return Ok(std::ptr::null_mut())}
   let mut java_error:Option<jni::errors::Error>=None;
   #[cfg(feature="abi5-final-native-link")]
   let observed=loan(|r|r.with_first_device_signatures(|v|{
    output_attempted=true;
    let built=(||->jni::errors::Result<jni::sys::jobjectArray>{
     // JNI allocation/array operations do not execute arbitrary Java callbacks.
     let array=env.new_object_array(8,jni::jni_str!("[B"),JObject::null())?;
     for (index,bytes)in v.public_parts().into_iter().enumerate(){let part=env.byte_array_from_slice(bytes)?;env.set_object_array_element(&array,index,&part)?;}
     Ok(array.into_raw())
    })();
    match built{Ok(v)=>Ok(v),Err(e)=>{java_error=Some(e);Err(crate::private_custodian_ffi::CustodyError::Unknown)}}
   }));
   #[cfg(not(feature="abi5-final-native-link"))]
   let observed:Result<Result<jni::sys::jobjectArray,crate::private_custodian_ffi::CustodyError>,i32>=Ok(Err(crate::private_custodian_ffi::CustodyError::Phase));
   if let Some(e)=java_error{return Err(e)}
   let out=match observed{Ok(Ok(v))=>v,_=>return Ok(std::ptr::null_mut())};
   // No public array escapes before ALL late Java/native fences on same owner.
   current(env,&borrowed)?;
   if guard_context(env,&input,&command,true,Some(&context))?!=44{return Ok(std::ptr::null_mut())}
   #[cfg(feature="abi5-final-native-link")]
   if !matches!(loan(|r|r.recheck_first_device_signatures()),Ok(Ok(()))){return Ok(std::ptr::null_mut())}
   Ok(out)
  })();
  if output_attempted&&!matches!(outcome,Ok(p)if !p.is_null()){
   #[cfg(feature="abi5-final-native-link")]let _=loan(|r|r.invalidate_first_device_signing());
  }
  outcome
 }).into_outcome();
 match result{jni::Outcome::Ok(out)=>out,jni::Outcome::Err(_)=>std::ptr::null_mut(),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilNativeAccountChannel_nativeObserveSignatures(env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject,borrow:jni::sys::jobject)->jni::sys::jobjectArray{
 let mut out=std::ptr::null_mut();let code=boundary(||{out=unsafe{observe_signatures(env,context,input,borrow)};if out.is_null(){16}else{0}});if code==0{out}else{std::ptr::null_mut()}
}
// Cleanup uses original immutable object identities, not the expired liveness
// predicate; it cannot manufacture a fresh owner or terminal/server permission.
unsafe fn close_signatures(raw:*mut jni::sys::JNIEnv,context_raw:jni::sys::jobject,input_raw:jni::sys::jobject,borrow_raw:jni::sys::jobject)->i32{
 if let Err(code)=thread_check(false){return code}if raw.is_null()||context_raw.is_null()||input_raw.is_null()||borrow_raw.is_null(){return 43}
 let mut unowned=unsafe{jni::EnvUnowned::from_raw(raw)};
 let outcome=unowned.with_env_no_catch(|env|->jni::errors::Result<i32>{
  if env.exception_check(){return Ok(16)}
  let context=unsafe{JObject::from_raw(env,context_raw)};let input=unsafe{JObject::from_raw(env,input_raw)};let borrowed=unsafe{JObject::from_raw(env,borrow_raw)};
  let command=env.get_field(&input,jni::jni_str!("originalCommand"),jni::jni_sig!("Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;"))?.l()?;
  let actual_context=env.get_field(&command,jni::jni_str!("retainedAppContext"),jni::jni_sig!("Landroid/content/Context;"))?.l()?;
  if !env.is_same_object(&context,&actual_context)?{return Ok(43)}
  let binding=loan(|r|->jni::errors::Result<bool>{
   if !env.is_same_object(r.command().map_err(|_|jni::errors::Error::NullPtr("original command"))?.as_obj(),&command)?{return Ok(false)}
   if !env.is_same_object(r.input().map_err(|_|jni::errors::Error::NullPtr("original input"))?.as_obj(),&input)?{return Ok(false)}
   r.matches_original_account_borrow(env,&borrowed)
  });
  if !matches!(binding,Ok(Ok(true))){return Ok(43)}
  #[cfg(feature="abi5-final-native-link")]{return Ok(match loan(|r|r.close_original_signing_guard()){Ok(Ok(()))=>44,_=>16})}
  #[cfg(not(feature="abi5-final-native-link"))]Ok(INSTANCE_REQUIRED)
 }).into_outcome();
 match outcome{jni::Outcome::Ok(code)=>code,jni::Outcome::Err(_)=>16,jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
}
#[unsafe(no_mangle)]pub extern "system" fn Java_com_ynx_social_matrix_VeilNativeAccountChannel_nativeCloseSignatures(env:*mut jni::sys::JNIEnv,_class:jni::sys::jclass,context:jni::sys::jobject,input:jni::sys::jobject,borrow:jni::sys::jobject)->i32{boundary(||unsafe{close_signatures(env,context,input,borrow)})}

