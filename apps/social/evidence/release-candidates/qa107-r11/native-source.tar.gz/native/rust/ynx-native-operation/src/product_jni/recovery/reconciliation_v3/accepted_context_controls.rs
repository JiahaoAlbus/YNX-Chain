//! PUBLIC host JVM plus normal C owner. No authentication/key material.
use super::*;
use std::ffi::{CString,c_void};
use std::os::unix::fs::{DirBuilderExt,PermissionsExt};
#[link(name="jvm")]unsafe extern "C"{fn JNI_CreateJavaVM(vm:*mut *mut jni::sys::JavaVM,env:*mut *mut c_void,args:*mut c_void)->i32;}
extern "system" fn reenter(raw:*mut jni::sys::JNIEnv,_class:jni::sys::jclass,c:jni::sys::jobject,i:jni::sys::jobject)->i32{boundary(||unsafe{operate(raw,c,i,true)})}
fn inspect()->crate::private_custodian_ffi::rcj_fixtures::Snapshot{loan(|r|r.rcj_snapshot()).unwrap()}
#[test]fn rcj_accepted_context_normal_jni_fault_matrix(){
 let cp=CString::new(format!("-Djava.class.path={}",std::env::var("VEIL_RCJ_JVM_CLASSES").expect("PUBLIC classes path"))).unwrap();
 let mut opt=jni::sys::JavaVMOption{optionString:cp.as_ptr()as*mut _,extraInfo:std::ptr::null_mut()};
 let mut args=jni::sys::JavaVMInitArgs{version:jni::sys::JNI_VERSION_1_8,nOptions:1,options:&mut opt,ignoreUnrecognized:false};
 let mut vm=std::ptr::null_mut();let mut raw: *mut c_void=std::ptr::null_mut();
 assert_eq!(unsafe{JNI_CreateJavaVM(&mut vm,&mut raw,&mut args as *mut _ as *mut _)},0);
 let env_raw=raw as *mut jni::sys::JNIEnv;
 let mut u=unsafe{jni::EnvUnowned::from_raw(env_raw)};
 let outcome=u.with_env_no_catch(|env|->jni::errors::Result<()>{
  let method=unsafe{jni::NativeMethod::from_raw_parts(jni::jni_str!("nativeReenter"),jni::jni_str!("(Landroid/content/Context;Lcom/ynx/social/matrix/VeilLocalRecoveryInput;)I"),reenter as *mut c_void)};
  unsafe{env.register_native_methods(jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyPrivateCommand"),&[method])}?;
  for mode in [0,1,2,4,5,6,3,7,8]{
   let context=env.new_object(jni::jni_str!("android/content/Context"),jni::jni_sig!("()V"),&[])?;
   env.set_field(&context,jni::jni_str!("mode"),jni::jni_sig!("I"),JValue::Int(if mode==7{1}else{mode}))?;
   let command=env.new_object(jni::jni_str!("com/ynx/social/matrix/VeilOwnKeyPrivateCommand"),jni::jni_sig!("(Landroid/content/Context;)V"),&[JValue::Object(&context)])?;
   let input=env.new_object(jni::jni_str!("com/ynx/social/matrix/VeilLocalRecoveryInput"),jni::jni_sig!("(Lcom/ynx/social/matrix/VeilOwnKeyPrivateCommand;)V"),&[JValue::Object(&command)])?;
   let dir=std::path::PathBuf::from(std::env::var_os("TMPDIR").unwrap()).join(format!("rcj-jvm-{}-{mode}",std::process::id()));std::fs::DirBuilder::new().mode(0o700).create(&dir).unwrap();
   let path=dir.join("pair.sqlite3");let cpath=CString::new(path.as_os_str().as_encoded_bytes()).unwrap();
   let mut original=crate::private_custodian_ffi::rcj_fixtures::original(env.new_global_ref(&command)?,env.new_global_ref(&input)?,&cpath);
   if mode!=7{original.recovery_loan().unwrap().start(env.new_global_ref(&input)?).unwrap_or_else(|_|panic!("PUBLIC same owner"));}
   assert_eq!(open(),1);
   LOCAL.with(|c|{let mut v=c.borrow_mut();let o=v.as_mut().unwrap();o.exit=ExitEligibility::Missing;o.genesis=Some(o.controller.reserve_local_genesis(original).unwrap_or_else(|_|panic!("PUBLIC inventory")));});
   let before=inspect();assert!(before.store!=0&&before.ticket!=0);
   assert_eq!(loan(|r|r.rcj_has_recovery()).unwrap(),mode!=7);
   let call=|discharge|boundary(||unsafe{operate(env_raw,context.as_raw(),input.as_raw(),discharge)});
   if mode==4{
    let _pending=env.throw_new(jni::jni_str!("java/lang/IllegalStateException"),jni::jni_str!("PUBLIC already pending"));
    assert!(env.exception_check(),"fixture must install real pending Throwable");
    assert_eq!(call(true),16);assert!(env.exception_check());env.exception_clear();
    assert_eq!(inspect().counts,before.counts);assert_eq!(inspect().store,before.store);
   }else if mode==5{
    loan(|r|r.rcj_arm_close_child()).unwrap();assert_eq!(call(true),16);
    let failed=inspect();assert!(failed.discharged&&!failed.closed&&failed.store==before.store&&failed.ticket==0);
    assert_eq!(failed.counts[4],1);assert_eq!(failed.counts[5],1);
    loan(|r|r.rcj_drop_close_child()).unwrap();assert_eq!(call(true),77);
    let done=inspect();assert!(done.closed&&done.store==0);assert_eq!(done.counts[4],1);assert_eq!(done.counts[5],2);assert_eq!(done.first,failed.first);assert!(done.unknown);
   }else if mode==6{
    assert_eq!(call(false),76);let held=inspect();assert!(held.receipt!=0);
    // Cause a real pre-borrow C custody failure, retaining its invalid receipt.
    std::fs::set_permissions(&path,std::fs::Permissions::from_mode(0o640)).unwrap();assert_eq!(call(false),16);
    std::fs::set_permissions(&path,std::fs::Permissions::from_mode(0o600)).unwrap();
    let failed=inspect();loan(|r|r.rcj_arm_cleanup_failure()).unwrap();
    // Controlled foreign-status failure: NOT an actual SQLite rollback fault.
    assert_eq!(call(false),16);let cleanup=inspect();assert!(cleanup.cleanup_required&&cleanup.receipt==0);assert_eq!(cleanup.store,failed.store);assert_eq!(cleanup.ticket,failed.ticket);assert_eq!(cleanup.first,failed.first);
    assert_eq!(call(false),76);assert_eq!(call(true),77);assert_eq!(inspect().first,failed.first);
   }else if mode==8{
    assert_eq!(call(true),77);let complete=inspect();
    env.set_field(&context,jni::jni_str!("checks"),jni::jni_sig!("I"),JValue::Int(0))?;
    env.set_field(&context,jni::jni_str!("mode"),jni::jni_sig!("I"),JValue::Int(2))?;
    assert_eq!(call(true),16);assert!(env.exception_check());env.exception_clear();
    assert_eq!(inspect(),complete,"already-closed postcheck refusal cannot resurrect C custody");
    assert_eq!(loan(|r|r.rcj_recovery_first()).unwrap(),Some(16));
   }else{
    let result=call(true);
    if mode==1||mode==2||mode==7{assert_eq!(result,16);let done=inspect();assert!(done.closed&&done.discharged&&done.store==0);assert_eq!(done.counts[4],1);assert_eq!(loan(|r|r.rcj_recovery_first()).unwrap(),Some(16));
     eprintln!("PUBLIC mode={mode} pending_after_callback={}",env.exception_check());
     assert!(env.exception_check(),"original callback Throwable remains pending");
     if env.exception_check(){env.exception_clear();}
     env.set_field(&context,jni::jni_str!("valid"),jni::jni_sig!("Z"),JValue::Bool(true))?;
    }else{assert_eq!(result,77);}
    if mode==3{assert_eq!(env.get_field(&context,jni::jni_str!("nested"),jni::jni_sig!("I"))?.i()?,23,"reentrant normal JNI must be busy, not nested discharge success");}
   }
   if env.exception_check(){env.exception_clear();}
   env.set_field(&context,jni::jni_str!("valid"),jni::jni_sig!("Z"),JValue::Bool(true))?;
   assert_eq!(call(true),77);let done=inspect();assert!(done.closed&&done.store==0&&done.ticket==0&&done.receipt==0);let counts=done.counts;
   assert_eq!(call(true),77);assert_eq!(inspect().counts,counts,"closed retries must not repeat any C effect");
   assert_ne!(release_no_effect_for_exit(),36,"store-only disposal is not global thread exit");
   // Fixture teardown only after all actual C owners disposed; not production release.
   LOCAL.with(|c|drop(c.borrow_mut().take()));
   eprintln!("PUBLIC accepted-owner JNI case {mode} complete; no device/keys/grant");
  }
  Ok(())
 }).into_outcome();
 match outcome{jni::Outcome::Ok(())=>{},jni::Outcome::Err(e)=>panic!("PUBLIC JNI error {e:?}"),jni::Outcome::Panic(p)=>std::panic::resume_unwind(p)}
 assert_eq!(unsafe{((**vm).v1_4.DestroyJavaVM)(vm)},0);
}
