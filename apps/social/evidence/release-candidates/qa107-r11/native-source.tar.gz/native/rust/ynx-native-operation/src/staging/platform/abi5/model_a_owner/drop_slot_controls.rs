//! NONSECRET generic byte slots only. No native owner/proof/test grant.
use super::*;
use std::{fs,process::Command,os::unix::process::ExitStatusExt};
const CHILD:&str="staging::platform::abi5::linked::model_a_owner::drop_slot_controls::r29_drop_slot_child";
#[test]fn r29_drop_slot_child(){
 let Some(case)=std::env::var_os("R29_DROP_CHILD")else{return};
 let case=case.to_str().unwrap();let(mut a,mut b)=(1u8,2u8);let original=&mut a as *mut u8;let changed=&mut b as *mut u8;
 let state=Rc::new(RefCell::new(Diagnostics{first:Some(3),unknown:false,refs:1,original_intent:None}));
 match case{
  "ok-null"=>{assert_eq!(drop_disposition(OK,original,ptr::null_mut(),&state),Ok(()));assert_eq!(state.borrow().first,Some(3));assert!(!state.borrow().unknown);},
  "ok-unchanged"=>{let _=drop_disposition(OK,original,original,&state);},
  "ok-changed"=>{let _=drop_disposition(OK,original,changed,&state);},
  "error-unchanged"=>{assert_eq!(drop_disposition(3,original,original,&state),Err(Error::Foreign(3)));assert_eq!(state.borrow().first,Some(3));},
  "error-changed"=>{let _=drop_disposition(3,original,changed,&state);},
  "error-owning-output"=>{let _=output(3,original,&state);},
  _=>panic!("unknown public disposition case"),
 }
 // This is ONLY a fixture continuation marker, never an additional C call.
 // Invalid slots must not return to this point or permit a subsequent FFI.
 eprintln!("R29_SUBSEQUENT_FIXTURE_MARKER");
}
#[test]fn r29_drop_slot_actual_child_abort_before_continuation(){
 let root=std::env::var_os("R29_CONTROL_DIR").expect("dedicated fresh control output required");
 let root=std::path::PathBuf::from(root);
 for (case,abort) in [("ok-null",false),("ok-unchanged",true),("ok-changed",true),("error-unchanged",false),("error-changed",true),("error-owning-output",true)]{
  let out=root.join(case);fs::create_dir(&out).unwrap();
  let result=Command::new(std::env::current_exe().unwrap()).args(["--exact",CHILD,"--nocapture","--test-threads=1"]).env("R29_DROP_CHILD",case).current_dir(&out).output().unwrap();
  fs::write(out.join("stdout.raw"),&result.stdout).unwrap();fs::write(out.join("stderr.raw"),&result.stderr).unwrap();
  fs::write(out.join("status.txt"),format!("case={case}\ncode={:?}\nsignal={:?}\n",result.status.code(),result.status.signal())).unwrap();
  let stderr=String::from_utf8(result.stderr).unwrap();
  if abort{
   assert_eq!(result.status.signal(),Some(6),"{case}: expected actual SIGABRT: {stderr}");
   assert!(!stderr.contains("R29_SUBSEQUENT_FIXTURE_MARKER"),"{case}: invalid slot returned");
   if case!="error-owning-output"{assert!(stderr.contains("R29_UNKNOWN_LATCHED_BEFORE_ABORT"),"{case}: missing latch-before-abort branch");}
  }else{assert!(result.status.success(),"{case}: {stderr}");assert!(stderr.contains("R29_SUBSEQUENT_FIXTURE_MARKER"));}
 }
}
#[test]fn r29_drop_slot_successful_ram_disposal_keeps_unknown(){
 let mut byte=9u8;let original=&mut byte as *mut u8;
 let state=Rc::new(RefCell::new(Diagnostics{first:Some(3),unknown:true,refs:1,original_intent:None}));
 assert_eq!(drop_disposition(OK,original,ptr::null_mut(),&state),Ok(()));
 assert!(state.borrow().unknown);assert_eq!(state.borrow().first,Some(3));assert_eq!(state.borrow().refs,1);
 assert_eq!(drop_disposition(3,original,original,&state),Err(Error::Unknown));
}
