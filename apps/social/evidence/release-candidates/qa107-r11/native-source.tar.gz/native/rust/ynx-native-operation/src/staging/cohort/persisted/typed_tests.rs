//! Public/dummy bytes only; actual copy/parse/drop counters, not authority.
use super::*;
fn ec(id:u32,version:u64,state:UnverifiedEc)->UnverifiedCell{UnverifiedCell::Ec{id,version,state}}
fn frame(cells:Vec<UnverifiedCell>)->Zeroizing<Vec<u8>>{encode(&UnauthenticatedStorage{cells}).unwrap()}
fn expected(kind:u8,id:u32,version:u64)->StructuralCellExpectation{StructuralCellExpectation{kind,id,version}}
fn reset(){RECORD_COPIES.with(|n|n.set(0));SELECTED_PARSES.with(|n|n.set(0));METADATA_DROPS.with(|n|n.set(0));ENTRY_DROPS.with(|n|n.set(0));}
fn counts()->(usize,usize,usize,usize){(RECORD_COPIES.with(|n|n.get()),SELECTED_PARSES.with(|n|n.get()),METADATA_DROPS.with(|n|n.get()),ENTRY_DROPS.with(|n|n.get()))}
fn tuple(signed:u32)->UsedTuple{let mut base=[0;33];base[0]=5;base[1]=9;UsedTuple{signed,base}}
#[test]fn typed_cell_single_slot_rejects_before_copy_and_selected_parse(){
 let input=frame(vec![ec(7,9,UnverifiedEc::Record(Zeroizing::new(vec![1])))]);
 for e in [expected(2,7,9),expected(1,8,9),expected(1,7,10)]{reset();assert!(matches!(decode_single(&input,e),Err(CodecError::SlotBinding)));assert_eq!(counts(),(0,0,0,0));}
 for cells in [vec![],vec![ec(7,9,UnverifiedEc::Missing),ec(8,9,UnverifiedEc::Tombstone)]]{let input=frame(cells);reset();assert!(matches!(decode_single(&input,expected(1,7,9)),Err(CodecError::SlotBinding)));assert_eq!(counts(),(0,0,0,0));}
}
#[test]fn typed_cell_selected_entry_owns_exact_metadata_transfer_and_drop(){
 let input=frame(vec![ec(7,9,UnverifiedEc::Tombstone)]);reset();let entry=decode_single(&input,expected(1,7,9)).unwrap();assert!(matches!(entry.metadata,UnverifiedCell::Ec{id:7,version:9,state:UnverifiedEc::Tombstone}));assert!(matches!(entry.record,SelectedUnverified::Tombstone));assert_eq!(counts(),(0,0,0,0));
 let owner=SelectedUnverifiedOwner{entries:vec![entry]};assert_eq!(owner.entries.len(),1);drop(owner);assert_eq!(counts(),(0,0,1,1));assert!(matches!(acquire_authenticated_input(),Err(DecodeError::RequiredAuthenticatedCohort)));
}
#[test]fn typed_cell_partial_selected_error_drops_metadata_without_grant(){
 let input=frame(vec![ec(1,3,UnverifiedEc::Missing),ec(2,4,UnverifiedEc::Record(Zeroizing::new(vec![1])))]);reset();let storage=decode(&input).unwrap();assert_eq!(counts().0,1);assert!(matches!(storage.decode_selected(),Err(CodecError::SelectedRecord)));assert_eq!(counts(),(1,1,2,1));
 let input=frame(vec![ec(2,4,UnverifiedEc::Record(Zeroizing::new(vec![1])))]);reset();assert!(matches!(decode_single(&input,expected(1,2,4)),Err(CodecError::SelectedRecord)));assert_eq!(counts(),(1,1,1,0));
}
#[test]fn typed_cell_consumed_used_set_retains_all_and_deterministic_conversion(){
 let input=frame(vec![UnverifiedCell::Kyber{id:8,version:12,record:None,policy:KyberPolicy::OneTimeConsumed,used:vec![tuple(4)]}]);let entry=decode_single(&input,expected(3,8,12)).unwrap();assert!(matches!(entry.metadata,UnverifiedCell::Kyber{id:8,version:12,record:None,policy:KyberPolicy::OneTimeConsumed,..}));assert!(matches!(entry.record,SelectedUnverified::Kyber(None)));let cohort=entry.used_for_cohort().unwrap().unwrap();assert_eq!(cohort.len(),1);assert!(canonical_used_from_receive(&cohort).unwrap()==vec![tuple(4)]);
 let canonical:Vec<_>=(0..16).map(tuple).collect();let mut receive=receive_used_from_canonical(&canonical).unwrap();receive.reverse();let original=receive.clone();let exported=canonical_used_from_receive(&receive).unwrap();assert!(exported==canonical);assert_eq!(receive,original);let restored=receive_used_from_canonical(&exported).unwrap();assert_eq!(restored.len(),16);assert!(canonical_used_from_receive(&restored).unwrap()==canonical);
}
#[test]fn typed_cell_used_set_duplicate_order_and_capacity_refuse_no_dedup(){
 let canonical=vec![tuple(1),tuple(2)];let mut receive=receive_used_from_canonical(&canonical).unwrap();receive.push(receive[0]);assert!(matches!(canonical_used_from_receive(&receive),Err(CodecError::Duplicate)));assert_eq!(receive.len(),3);
 assert!(matches!(receive_used_from_canonical(&[tuple(2),tuple(1)]),Err(CodecError::Order)));assert!(matches!(receive_used_from_canonical(&vec![tuple(1);17]),Err(CodecError::Bound)));let mut receive=receive_used_from_canonical(&canonical).unwrap();receive.extend(std::iter::repeat_n(receive[0],15));assert!(matches!(canonical_used_from_receive(&receive),Err(CodecError::Bound)));
}
