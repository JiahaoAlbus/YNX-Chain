//! PRIVATE same-store lookup/capture. All captured data remains UNVERIFIED.
//! No reopened-store constructor, public pointer, grant or restore success.
use super::*;
use zeroize::Zeroizing;
#[derive(Debug,PartialEq,Eq)]pub(super)enum CaptureFailure{Input(CustodyError),Panic,CallbackCardinality,NullBorrow,NullResult,Foreign(i32)}
pub(super)struct StoredCiphertext{journal:Zeroizing<Vec<u8>>,alias:Vec<u8>,association:Vec<u8>,generation:u64}
impl StoredCiphertext{
 pub(super)fn journal(&self)->&[u8]{&self.journal}
 pub(super)fn matches(&self,input:&LocalGenesisInput)->bool{self.generation==input.generation&&self.alias==input.alias.as_bytes()&&self.association==input.association}
}
impl PreDeviceOwner{
 pub(super)fn capture_original_pair(&mut self,input:&LocalGenesisInput)->Result<&StoredCiphertext,CustodyError>{
  self.thread()?;
  if let Some(old)=self.captured.as_ref(){
   if !old.matches(input){self.remember_capture_failure(CaptureFailure::Input(CustodyError::Pair));return Err(self.failed(5))}
   if self.unknown{return Err(CustodyError::Unknown)}
   return Ok(self.captured.as_ref().expect("same captured owner"))
  }
  if self.capture_attempted{return Err(if self.unknown{CustodyError::Unknown}else{CustodyError::Phase})}
  if self.store.is_null(){return Err(CustodyError::Phase)}
  self.capture_attempted=true;
  if self.result.is_null(){
   let code=unsafe{veil_pd_lookup(self.store,self.operation.as_ptr(),&mut self.result)};
   if code!=3{self.remember_capture_failure(CaptureFailure::Foreign(code));if !self.result.is_null(){self.unknown=true;std::process::abort()}return Err(self.failed(code))}
   if self.result.is_null(){self.remember_capture_failure(CaptureFailure::NullResult);return Err(self.failed(9))}
  }
  // Result is already in original owner BEFORE borrow/postcheck/copy failure.
  let mut captured=Capture{input,operation:&self.operation,incarnation:&self.incarnation,out:None,error:None,calls:0};
  let code=unsafe{veil_pd_result_borrow(self.result,capture,&mut captured as *mut _ as *mut c_void)};
  // Preserve bytes even when C's AFTER-callback custody check fails.
  let Capture{out,error,calls,..}=captured;
  self.captured=out;
  // Callback failure happened BEFORE the foreign postcheck; preserve it first.
  if let Some(error)=error{self.remember_capture_failure(error)}
  // A foreign precheck refusal legitimately invokes no callback. Preserve
  // that actual refusal rather than inventing a malformed callback first.
  if calls!=1&&(code==3||calls!=0){self.remember_capture_failure(CaptureFailure::CallbackCardinality)}
  if code!=3{self.remember_capture_failure(CaptureFailure::Foreign(code));return Err(self.failed(code))}
  if self.capture_error.is_some()||self.captured.is_none(){return Err(self.failed(5))}
  if self.unknown{return Err(CustodyError::Unknown)}
  Ok(self.captured.as_ref().expect("captured before classification"))
 }
}
struct Capture<'a>{input:&'a LocalGenesisInput,operation:&'a[u8;16],incarnation:&'a[u8;16],out:Option<StoredCiphertext>,error:Option<CaptureFailure>,calls:usize}
fn copy(bytes:&[u8])->Result<Vec<u8>,CustodyError>{let mut out=Vec::new();out.try_reserve_exact(bytes.len()).map_err(|_|CustodyError::Memory)?;out.extend_from_slice(bytes);Ok(out)}
// FFI pointers are from the pinned private C result's synchronous borrow only.
// All lengths checked before slice construction/allocation; no borrow escapes.
unsafe fn bounded<'a>(b:Bytes,max:usize)->Result<&'a[u8],CustodyError>{if b.bytes.is_null()||b.size==0||b.size>max{return Err(CustodyError::Bounds)}Ok(unsafe{std::slice::from_raw_parts(b.bytes,b.size)})}
unsafe fn checked(original:&Original,pair:&Pair,target:&Capture<'_>)->Result<StoredCiphertext,CustodyError>{
 if original.operation!=*target.operation||original.incarnation!=*target.incarnation||original.storage_generation!=target.input.generation as i64||original.protected_record_version!=1{return Err(CustodyError::Pair)}
 let(alias,association,oa,op,ca,pa,c,p,j)=unsafe{(bounded(original.alias,256)?,bounded(original.original_association,4096)?,bounded(original.classic_aad,8192)?,bounded(original.pq_aad,8192)?,bounded(pair.classic_aad,8192)?,bounded(pair.pq_aad,8192)?,bounded(pair.classic_record,19600)?,bounded(pair.pq_record,19600)?,bounded(pair.original_journal,19600)?)};
 if alias!=target.input.alias.as_bytes()||association!=target.input.association||oa!=ca||op!=pa||c.len().checked_add(p.len()).is_none_or(|n|n>19600){return Err(CustodyError::Pair)}
 let mut cursor=super::super::Cursor{bytes:j,at:0};
 if cursor.take(8)?!=b"YNXOKJ01"||cursor.n()?!=1{return Err(CustodyError::Bounds)}
 let pn=cursor.n()?;let cn=cursor.n()?;
 if cursor.take(pn)?!=p||cursor.take(cn)?!=c||cursor.at!=j.len(){return Err(CustodyError::Pair)}
 let (pq,classic)=super::super::decode_pair(j)?;
 if pq.aad_size as usize!=pa.len()||classic.aad_size as usize!=ca.len()||&pq.aad[..pa.len()]!=pa||&classic.aad[..ca.len()]!=ca{return Err(CustodyError::Pair)}
 // Owned copy budget <=19600+256+4096. Ciphertext only; no plaintext/keys.
 Ok(StoredCiphertext{journal:Zeroizing::new(copy(j)?),alias:copy(alias)?,association:copy(association)?,generation:target.input.generation})
}
extern "C" fn capture(original:*const Original,pair:*const Pair,context:*mut c_void){
 if context.is_null(){return}let target=unsafe{&mut*(context as *mut Capture<'_>)};
 target.calls=target.calls.saturating_add(1);
 if target.calls!=1{target.remember(CaptureFailure::CallbackCardinality);return}
 if original.is_null()||pair.is_null(){target.remember(CaptureFailure::NullBorrow);return}
 match std::panic::catch_unwind(std::panic::AssertUnwindSafe(||unsafe{checked(&*original,&*pair,target)})){
  Ok(Ok(out))=>{target.out=Some(out);
   #[cfg(test)] POST_CAPTURE.with(|v|{let hook=v.borrow_mut().take();if let Some(hook)=hook{hook();}});
  },Ok(Err(e))=>target.remember(CaptureFailure::Input(e)),Err(payload)=>{target.remember(CaptureFailure::Panic);if std::panic::catch_unwind(std::panic::AssertUnwindSafe(||drop(payload))).is_err(){std::process::abort()}}
 }
}
#[cfg(test)]thread_local!{pub(super)static POST_CAPTURE:std::cell::RefCell<Option<Box<dyn FnOnce()>>>=std::cell::RefCell::new(None);}
#[cfg(test)]mod tests{
 use super::*;use std::ffi::CString;use std::os::unix::{fs::DirBuilderExt,process::ExitStatusExt};
 fn input(a:u8)->LocalGenesisInput{LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![a],30).unwrap_or_else(|_|panic!("public input"))}
 fn path()->CString{let root=std::path::PathBuf::from(std::env::var_os("TMPDIR").expect("external TMP"));let dir=root.join(format!("r56-public-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));std::fs::DirBuilder::new().mode(0o700).create(&dir).unwrap();CString::new(dir.join("pair.sqlite3").as_os_str().as_encoded_bytes()).unwrap()}
 fn fixture()->(PreDeviceOwner,Vec<u8>){
  // Selected NORMAL C storage, entirely dummy unauthenticated encrypted shapes.
  // No selected key RNG, protector, MAC verification or authority producer.
  let mut pq=super::super::super::PqRecord{version:1,aad_size:1,aad:[0;7168],nonce:[0;12],cipher:[0;4912]};pq.aad[0]=7;
  let mut classic=super::super::super::ClassicRecord{version:1,aad_size:1,cipher_size:17,aad:[0;7168],nonce:[0;12],cipher:[0;272]};classic.aad[0]=8;
  let wire=super::super::super::encode_pair(&pq,&classic).unwrap();let pn=u32::from_be_bytes(wire[12..16].try_into().unwrap())as usize;let cn=u32::from_be_bytes(wire[16..20].try_into().unwrap())as usize;
  let pair=PairBorrow::from_slices(&wire[20+pn..20+pn+cn],&wire[20..20+pn],&wire,&classic.aad[..1],&pq.aad[..1]);
  let mut owner=PreDeviceOwner::unopened([1;16],[2;16]);owner.reserve(&path(),&input(7)).unwrap();owner.claim_generation().unwrap();owner.commit(&pair).unwrap();(owner,wire)
 }
 #[test]fn r56_actual_c_lookup_keeps_result_same_wire_and_no_readback_promotion(){let(mut o,wire)=fixture();let first=o.capture_original_pair(&input(7)).unwrap().journal().as_ptr();assert_eq!(o.capture_original_pair(&input(7)).unwrap().journal(),wire);let result=o.result;assert!(!result.is_null());assert_eq!(o.capture_original_pair(&input(7)).unwrap().journal().as_ptr(),first);assert_eq!(o.result,result);assert!(!o.readback_complete().unwrap());o.close_known().unwrap();assert!(o.result.is_null()&&o.ticket.is_null()&&o.store.is_null());}
 #[test]fn r56_unopened_lookup_has_no_open_or_reserve(){let mut o=PreDeviceOwner::unopened([1;16],[2;16]);assert!(matches!(o.capture_original_pair(&input(7)),Err(CustodyError::Phase)));assert!(o.store.is_null()&&o.ticket.is_null()&&o.result.is_null()&&!o.capture_attempted);}
 #[test]fn r56_changed_binding_retains_c_owner_and_unknown(){
  if std::env::var("VEIL_R56_CHILD").as_deref()==Ok("binding"){
   let(mut o,wire)=fixture();o.capture_original_pair(&input(7)).unwrap();let result=o.result;let store=o.store;
   assert!(matches!(o.capture_original_pair(&input(8)),Err(CustodyError::Unknown)));assert_eq!(o.first,Some(5));assert_eq!(o.result,result);assert_eq!(o.store,store);assert_eq!(o.captured.as_ref().unwrap().journal(),wire);
   assert!(matches!(o.capture_original_pair(&input(7)),Err(CustodyError::Unknown)));assert!(matches!(o.close_known(),Err(CustodyError::Unknown)));
   eprintln!("R56_PUBLIC_ASSERTIONS_COMPLETE_HELD_UNKNOWN");drop(o);panic!("UNKNOWN owner must not silently drop")
  }
  let output=std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact","private_custodian_ffi::predevice_port::capture::tests::r56_changed_binding_retains_c_owner_and_unknown","--nocapture"]).env("VEIL_R56_CHILD","binding").output().unwrap();
  eprintln!("child signal={:?} {}",output.status.signal(),String::from_utf8_lossy(&output.stderr));assert_eq!(output.status.signal(),Some(6));assert!(String::from_utf8_lossy(&output.stderr).contains("R56_PUBLIC_ASSERTIONS_COMPLETE_HELD_UNKNOWN"));
 }
}

impl Capture<'_>{fn remember(&mut self,error:CaptureFailure){if self.error.is_none(){self.error=Some(error)}}}
impl PreDeviceOwner{pub(super)fn remember_capture_failure(&mut self,error:CaptureFailure){if self.capture_error.is_none(){self.capture_error=Some(error)}}}
#[cfg(test)]mod r57_diagnostics{
 use super::*;
 #[test]fn r57_callback_first_error_not_overwritten(){let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public metadata"));let op=[1;16];let inc=[2;16];let mut c=Capture{input:&input,operation:&op,incarnation:&inc,out:None,error:None,calls:0};capture(std::ptr::null(),std::ptr::null(),&mut c as *mut _ as *mut c_void);assert!(matches!(c.error,Some(CaptureFailure::NullBorrow)));capture(std::ptr::null(),std::ptr::null(),&mut c as *mut _ as *mut c_void);assert!(matches!(c.error,Some(CaptureFailure::NullBorrow)));assert_eq!(c.calls,2);assert!(c.out.is_none());}
 #[test]fn r57_owner_retains_typed_memory_before_later_foreign(){let mut o=PreDeviceOwner::unopened([1;16],[2;16]);o.remember_capture_failure(CaptureFailure::Input(CustodyError::Memory));o.remember_capture_failure(CaptureFailure::Foreign(10));o.failed(10);o.failed(7);assert!(matches!(o.capture_error,Some(CaptureFailure::Input(CustodyError::Memory))));assert_eq!(o.first,Some(10));assert!(o.unknown);assert!(o.store.is_null()&&o.result.is_null());}
}

// Same checked callback for the new whole-component result owner; no raw view escapes.
pub(super)struct ExistingCapture{pub out:Option<StoredCiphertext>,pub error:Option<CaptureFailure>,pub status:i32}
pub(super)fn capture_existing_result(result:*mut ResultOwner,input:&LocalGenesisInput,operation:&[u8;16],incarnation:&[u8;16])->ExistingCapture{
 let mut target=Capture{input,operation,incarnation,out:None,error:None,calls:0};
 let status=unsafe{veil_pd_result_borrow(result,capture,&mut target as *mut _ as *mut c_void)};
 // Same rule as the retained original owner's capture: a failed C precheck
 // with zero callbacks is a foreign refusal, not a callback shape failure.
 if target.calls!=1&&(status==3||target.calls!=0){target.remember(CaptureFailure::CallbackCardinality)}
 ExistingCapture{out:target.out,error:target.error,status}
}

impl PreDeviceOwner{pub(in crate::private_custodian_ffi)fn capture_for_recovery(&mut self,input:&LocalGenesisInput)->Result<(),CustodyError>{self.capture_original_pair(input).map(|_|())}}

#[cfg(test)]mod recovery_refusal_controls{
 use super::*;
 #[test]fn actual_c_precheck_refusal_is_not_a_fabricated_callback_failure(){
  let input=LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30).unwrap_or_else(|_|panic!("public input"));
  // Actual selected C rejects an absent result before invoking the callback.
  // This creates no store, ciphertext, keys, authority or recovery success.
  let captured=capture_existing_result(std::ptr::null_mut(),&input,&[1;16],&[2;16]);
  assert_ne!(captured.status,3);
  assert!(captured.out.is_none());
  assert!(captured.error.is_none());
 }
}

#[cfg(feature="predevice-reconciliation-v3")]
pub(super)fn capture_resolution(result:*mut super::v3::Resolution,input:&LocalGenesisInput,operation:&[u8;16],incarnation:&[u8;16],report:&mut super::v3::Report)->ExistingCapture{
 let mut target=Capture{input,operation,incarnation,out:None,error:None,calls:0};
 let status=unsafe{super::v3::veil_pd_resolution_borrow(result,capture,&mut target as *mut _ as *mut c_void,report)};
 // A foreign precheck refusal legitimately invokes no callback. Preserve its
 // UNKNOWN status, not a fabricated permanent malformed-callback diagnosis.
 if target.calls!=1&&(status==18||target.calls!=0){target.remember(CaptureFailure::CallbackCardinality)}
 ExistingCapture{out:target.out,error:target.error,status}
}

#[cfg(feature="predevice-cold-v1")]
pub(super)fn capture_cold_owner(owner:*mut super::existing::cold::Owner,input:&LocalGenesisInput,operation:&[u8;16],incarnation:&[u8;16],report:&mut super::existing::cold::Report)->ExistingCapture{
 let mut target=Capture{input,operation,incarnation,out:None,error:None,calls:0};
 let status=unsafe{super::existing::cold::veil_pd_cold_borrow(owner,capture,&mut target as *mut _ as *mut c_void,report)}as i32;
 if target.calls!=1&&(status==2||target.calls!=0){target.remember(CaptureFailure::CallbackCardinality)}
 ExistingCapture{out:target.out,error:target.error,status}
}
