//! Native-only typed message path over the EXISTING selected actor/store.
//! Constructors delegate genuine provider gates. No public state/key factory.
use super::platform::{NativeSnapshotHandle,NativeStoreBridge,NativePendingHandle,PortError,FinalStatus,RetireAcknowledgement};
use libsignal_protocol::{CiphertextMessage,ProtocolAddress};
use std::{task::{Context,Poll},time::SystemTime};
use crate::{NativeOperations,OperationError,RequiredProvider};

#[derive(Clone,Debug,PartialEq,Eq)]pub enum NativeProductError{
 RequiredRoots([RequiredProvider;4]),RequiredSource,RequiredStore,RequiredSnapshot,RequiredProtector,RequiredBudget,RequiredReceipt,
 PanicRetained,Authentication,Binding,Capacity,Unknown,Revoked,Cancelled,Rejected,Consumed,Retired,Held,
}
fn map(e:PortError)->NativeProductError{match e{
 PortError::RequiredNativeSnapshotLease=>NativeProductError::RequiredSnapshot,
 PortError::RequiredNativeSourceAuthentication=>NativeProductError::RequiredSource,
 PortError::RequiredCheckedSqlProducer=>NativeProductError::RequiredStore,
 PortError::RequiredNoetherNativeRecordProtector=>NativeProductError::RequiredProtector,
 PortError::RequiredSnapshotBudget=>NativeProductError::RequiredBudget,
 PortError::RequiredOnceReceipt=>NativeProductError::RequiredReceipt,
 PortError::PanicRetained=>NativeProductError::PanicRetained,
 PortError::Binding=>NativeProductError::Binding,PortError::Capacity=>NativeProductError::Capacity,
 PortError::Authentication=>NativeProductError::Authentication,PortError::Unknown=>NativeProductError::Unknown,
 PortError::Revoked=>NativeProductError::Revoked,PortError::Cancelled=>NativeProductError::Cancelled,
 PortError::Rejected=>NativeProductError::Rejected,PortError::Consumed=>NativeProductError::Consumed,
 PortError::Retired=>NativeProductError::Retired,PortError::Held=>NativeProductError::Held,
}}
pub struct NativeProductEngine{bridge:NativeStoreBridge,authority:Option<NativeOperations>,#[cfg(feature="abi5-final-native-link")]original:Option<super::platform::OwnedMessageOriginal>,unclaimed:Option<NativeProductOperation>}
pub struct NativeProductOperation{snapshot:Option<NativeSnapshotHandle>,attempted:bool}
pub struct NativeProductPending{native:NativePendingHandle}
pub struct NativeProductRetainFailure{pub error:NativeProductError,operation:NativeProductOperation}
impl NativeProductRetainFailure{pub fn into_original(self)->NativeProductOperation{self.operation}}
impl NativeProductRetainFailure{pub(crate) fn into_controller_parts(self)->(NativeProductError,NativeProductOperation){(self.error,self.operation)}}
#[derive(Debug,PartialEq,Eq)]pub enum NativeProductCommit{Committed,Unknown,Required,Held,Rejected}
/// Message payload only. NO session keys, ratchet, store, JNI pointer or lease.
/// Native bridge must restrict plaintext display to the authenticated recipient.
pub struct NativeProductConsumeFailure{pub error:NativeProductError,pub(crate) delivery:Option<NativeProductDelivery>,pub(crate) uncertain:bool}
fn retained_consumption(result:Result<NativeProductDelivery,NativeProductError>,late:Result<(),NativeProductError>)->Result<NativeProductDelivery,NativeProductConsumeFailure>{match (result,late){(Ok(delivery),Ok(()))=>Ok(delivery),(Ok(delivery),Err(_))=>Err(NativeProductConsumeFailure{error:NativeProductError::Unknown,delivery:Some(delivery),uncertain:true}),(Err(error),late)=>Err(NativeProductConsumeFailure{error,delivery:None,uncertain:late.is_err()})}}
pub struct NativeProductDelivery{ciphertext:Vec<u8>,plaintext:Option<zeroize::Zeroizing<Vec<u8>>>,kind:Option<super::output::SelectedWireKind>,outbound:bool}
impl NativeProductDelivery{
 pub fn ciphertext(&self)->&[u8]{&self.ciphertext}
 pub fn recipient_plaintext(&self)->Option<&[u8]>{self.plaintext.as_ref().map(|p|p.as_slice())}
}
impl NativeProductEngine{
 /// Normal real roots ONLY; current provider bodies return Required.
 /// No caller flag, product probe, fixture or public tuple can open this.
 pub fn open_native()->Result<Self,NativeProductError>{
  let authority=match crate::open_production(){
   Ok(owner)=>owner,Err(OperationError::Required(providers))=>return Err(NativeProductError::RequiredRoots(providers)),
   Err(OperationError::Unknown)=>return Err(NativeProductError::Unknown),Err(OperationError::Revoked)=>return Err(NativeProductError::Revoked),
   Err(_)=>return Err(NativeProductError::RequiredSource),
  };
  let bridge=NativeStoreBridge::open_platform().map_err(map)?;Ok(Self{bridge,authority:Some(authority),#[cfg(feature="abi5-final-native-link")]original:None,unclaimed:None})
 }
 /// Actual authenticated cohort/lease factory is still missing. No substitute.
 pub fn acquire_operation(&mut self)->Result<NativeProductOperation,NativeProductError>{
  self.current_original()?;let result=self.bridge.acquire_snapshot().map(|snapshot|NativeProductOperation{snapshot:Some(snapshot),attempted:false}).map_err(map);if self.current_original().is_err(){if let Ok(operation)=result{self.unclaimed=Some(operation);}return Err(NativeProductError::Unknown)}result
 }
 /// Moves the SAME computed snapshot/wire/journal into SAME bridge custody.
 /// Rejected retention returns the COMPLETE original; it never re-encrypts.
 pub fn retain_operation(&mut self,mut operation:NativeProductOperation)->Result<NativeProductPending,NativeProductRetainFailure>{
  let Some(snapshot)=operation.snapshot.take()else{return Err(NativeProductRetainFailure{error:NativeProductError::Consumed,operation})};
  match self.bridge.retain_prepared(snapshot){
   Ok(native)=>Ok(NativeProductPending{native}),
   Err(failure)=>{let(error,snapshot)=failure.into_product_parts();operation.snapshot=Some(snapshot);Err(NativeProductRetainFailure{error:map(error),operation})},
  }
 }
 pub(crate) fn retain_owned_operation(&mut self,operation:&mut NativeProductOperation)->Result<NativeProductPending,NativeProductError>{
  self.bridge.retain_in_place(&mut operation.snapshot).map(|native|NativeProductPending{native}).map_err(map)
 }
 /// Polls the existing exact operation; no new operation/CAS/encryption.
 /// UNKNOWN stays same owner. Whole v2 C carrier is NOT composed/adopted yet.
 pub fn poll_same_pending(&mut self,pending:&mut NativeProductPending,cx:&mut Context<'_>)->Poll<Result<NativeProductCommit,NativeProductError>>{
  if let Err(e)=self.current_original(){return Poll::Ready(Err(e))}let result=match self.bridge.poll_final(&mut pending.native,cx){
   Poll::Pending=>Poll::Pending,Poll::Ready(Err(e))=>Poll::Ready(Err(map(e))),
   Poll::Ready(Ok(status))=>Poll::Ready(match status{
    FinalStatus::Applied=>Ok(NativeProductCommit::Committed),FinalStatus::Unknown=>Ok(NativeProductCommit::Unknown),
    FinalStatus::Required=>Ok(NativeProductCommit::Required),FinalStatus::Held=>Ok(NativeProductCommit::Held),FinalStatus::Rejected=>Ok(NativeProductCommit::Rejected),
    #[cfg(test)]FinalStatus::FixtureApplied=>Err(NativeProductError::RequiredReceipt),
   }),
  };if self.current_original().is_err(){return Poll::Ready(Err(NativeProductError::Unknown))}result
 }
 /// Existing consume_once checks genuine final proof and exact pending binding.
 /// No message output is returned merely because preparation/SQL succeeded.
 pub fn consume_committed(&mut self,pending:&mut NativeProductPending)->Result<NativeProductDelivery,NativeProductConsumeFailure>{
  self.current_original().map_err(|error|NativeProductConsumeFailure{error,delivery:None,uncertain:false})?;let result=consume_product_delivery(&mut self.bridge,&mut pending.native);let late=self.current_original();retained_consumption(result,late)
 }
 pub fn retire_consumed(&mut self,pending:&mut NativeProductPending)->Result<(),NativeProductError>{
  self.bridge.retire(&mut pending.native,RetireAcknowledgement::ConsumedOutput).map_err(map)
 }
}
impl NativeProductOperation{
 /// Native executor supplies pinned ProtocolAddress + native CryptoRng.
 /// Neither address nor RNG is source/device authorization; snapshot owns it.
 /// No RNG/key/store export or JS/JNI caller-supplied private state API.
 pub async fn prepare_send<R:rand::Rng+rand::CryptoRng>(&mut self,remote:&ProtocolAddress,local:&ProtocolAddress,clear:&[u8],now:SystemTime,rng:&mut R)->Result<(),NativeProductError>{
  let snapshot=self.snapshot.as_mut().ok_or(NativeProductError::Consumed)?;
  if snapshot.product_outcome_uncertain(){return Err(NativeProductError::Unknown)}
  if self.attempted{return Err(NativeProductError::Consumed)}
  if clear.len()>super::MAX_BYTES{return Err(NativeProductError::Capacity)}
  self.attempted=true;snapshot.execute_send(remote,local,clear,now,rng).await.map_err(map)
 }
 pub async fn prepare_receive<R:rand::Rng+rand::CryptoRng>(&mut self,remote:&ProtocolAddress,local:&ProtocolAddress,wire:&CiphertextMessage,rng:&mut R)->Result<(),NativeProductError>{
  let snapshot=self.snapshot.as_mut().ok_or(NativeProductError::Consumed)?;
  if snapshot.product_outcome_uncertain(){return Err(NativeProductError::Unknown)}
  if self.attempted{return Err(NativeProductError::Consumed)}
  if wire.serialize().len()>super::MAX_WIRE{return Err(NativeProductError::Capacity)}
  self.attempted=true;snapshot.execute_receive(remote,local,wire,rng).await.map_err(map)
 }
}
impl Drop for NativeProductOperation{
 fn drop(&mut self){if self.snapshot.as_ref().is_some_and(NativeSnapshotHandle::product_outcome_uncertain){std::process::abort();}}
}
// Failed/UNKNOWN operations remain returned owners. Abort only prevents silent
// loss of a known-uncertain snapshot; it is NOT durable quarantine/recovery.
// No fixture constructor exists in this module, including cfg(test).
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn r31_product_facade_open_delegates_actual_required_roots(){
  let Err(OperationError::Required(expected))=crate::open_production()else{panic!("unexpected admitted root")};
  assert!(matches!(NativeProductEngine::open_native(),Err(NativeProductError::RequiredRoots(actual))if actual==expected));
 }
 #[test]fn r31_product_facade_real_store_refusal_not_root_or_message(){
  assert!(matches!(NativeStoreBridge::open_platform(),Err(PortError::RequiredCheckedSqlProducer)));
  assert_eq!(map(PortError::Unknown),NativeProductError::Unknown);assert_eq!(map(PortError::RequiredOnceReceipt),NativeProductError::RequiredReceipt);
 }
}

pub(super) fn consume_product_delivery(bridge:&mut NativeStoreBridge,pending:&mut NativePendingHandle)->Result<NativeProductDelivery,NativeProductError>{let output=bridge.consume_product_once(pending).map_err(map)?;let(ciphertext,plaintext,kind,outbound)=output.into_product_parts();Ok(NativeProductDelivery{ciphertext,plaintext:plaintext.map(zeroize::Zeroizing::new),kind,outbound})}

impl NativeProductOperation{
 pub(crate)fn message_route(&self,input:&crate::product_message::MessageInput)->Result<super::platform::NativeMessageRoute,NativeProductError>{
  self.snapshot.as_ref().ok_or(NativeProductError::Consumed)?.message_route(input.logical(),input.direction()).map_err(map)
 }
 pub(crate)async fn prepare_message(&mut self,input:&crate::product_message::MessageInput,route:super::platform::NativeMessageRoute)->Result<(),NativeProductError>{
  self.snapshot.as_ref().ok_or(NativeProductError::Consumed)?.validate_message_route(&route).map_err(map)?;
  if !route.matches(input.logical(),input.direction()){return Err(NativeProductError::Binding)}
  use rand::TryRngCore;
  let mut rng=rand::rngs::OsRng.unwrap_err();
  let prepared=match input.direction(){
   crate::product_message::Direction::Send=>self.prepare_send(route.remote(),route.local(),input.body(),SystemTime::now(),&mut rng).await,
   crate::product_message::Direction::Receive=>self.prepare_receive(route.remote(),route.local(),input.wire().ok_or(NativeProductError::Rejected)?,&mut rng).await,
  };
  // No output or next stage may follow an expired/rebound authenticated route.
  // The original attempted owner is retained even when preparation failed.
  if self.attempted{self.snapshot.as_ref().ok_or(NativeProductError::Consumed)?.finish_message_route(&route).map_err(map)?;}
  prepared
 }
}

impl NativeProductEngine{
 pub(crate)fn validate_delivery(&mut self,pending:&NativeProductPending)->Result<(),NativeProductError>{self.bridge.validate_product_delivery(&pending.native).map_err(map)}
}
impl NativeProductDelivery{
 pub(crate)fn encode_owned_output(&self,logical:&[u8;16])->Result<zeroize::Zeroizing<Vec<u8>>,NativeProductError>{
  let kind=self.kind.ok_or(NativeProductError::Binding)?;
  match (self.outbound,self.plaintext.as_ref()){
   (true,None)=>super::output::encode(logical,true,kind,&self.ciphertext),
   (false,Some(clear))=>super::output::encode(logical,false,kind,clear),
   _=>Err(NativeProductError::Binding),
  }
 }
}

// Normal already-admitted original path. Legacy parameterless open_native
// remains fail-closed; this consumes the existing retained Prepared borrow.
#[cfg(feature="abi5-final-native-link")]
pub(crate)struct NativeOriginalProductEngine<'prepared,'op>{original:super::platform::ScopedNativeOriginal<'prepared,'op>}
#[cfg(feature="abi5-final-native-link")]
pub(crate)struct NativeOriginalProductOperation<'engine,'prepared,'op>{engine:&'engine mut NativeOriginalProductEngine<'prepared,'op>,operation:NativeProductOperation}
#[cfg(feature="abi5-final-native-link")]
impl<'prepared,'op>NativeOriginalProductEngine<'prepared,'op>{
 pub(crate)fn open_original(prepared:&'prepared mut super::platform::SourcePreparedOwner<'op>)->Result<Self,super::platform::ScopedNativeFailure<'prepared,'op>>{prepared.open_scoped_native().map(|original|Self{original})}
 pub(crate)fn acquire_operation(&mut self)->Result<NativeOriginalProductOperation<'_,'prepared,'op>,NativeProductError>{
  let snapshot=self.original.acquire_operation().map_err(map)?;Ok(NativeOriginalProductOperation{engine:self,operation:NativeProductOperation{snapshot:Some(snapshot),attempted:false}})
 }
 pub(crate)fn close(&mut self)->Result<(),super::platform::SourceOwnerError>{self.original.close()}
}

#[cfg(feature="abi5-final-native-link")]
impl NativeOriginalProductOperation<'_,'_,'_>{
 pub(crate)async fn prepare_send<R:rand::Rng+rand::CryptoRng>(&mut self,remote:&ProtocolAddress,local:&ProtocolAddress,clear:&[u8],now:SystemTime,rng:&mut R)->Result<(),NativeProductError>{
  self.engine.original.current().map_err(|_|NativeProductError::Unknown)?;let result=self.operation.prepare_send(remote,local,clear,now,rng).await;
  self.engine.original.current().map_err(|_|NativeProductError::Unknown)?;result
 }
 pub(crate)async fn prepare_receive<R:rand::Rng+rand::CryptoRng>(&mut self,remote:&ProtocolAddress,local:&ProtocolAddress,wire:&CiphertextMessage,rng:&mut R)->Result<(),NativeProductError>{
  self.engine.original.current().map_err(|_|NativeProductError::Unknown)?;let result=self.operation.prepare_receive(remote,local,wire,rng).await;
  self.engine.original.current().map_err(|_|NativeProductError::Unknown)?;result
 }
}

#[cfg(feature="abi5-final-native-link")]
pub(crate)struct NativeOriginalProductRetained<'engine,'prepared,'op>{engine:&'engine mut NativeOriginalProductEngine<'prepared,'op>,pending:NativeProductPending,unknown:bool}
#[cfg(feature="abi5-final-native-link")]
pub(crate)enum NativeOriginalRetainCustody<'engine,'prepared,'op>{Operation(NativeOriginalProductOperation<'engine,'prepared,'op>),Pending(NativeOriginalProductRetained<'engine,'prepared,'op>)}
#[cfg(feature="abi5-final-native-link")]
pub(crate)struct NativeOriginalRetainFailure<'engine,'prepared,'op>{pub(crate)error:NativeProductError,custody:NativeOriginalRetainCustody<'engine,'prepared,'op>}
#[cfg(feature="abi5-final-native-link")]
impl<'engine,'prepared,'op>NativeOriginalRetainFailure<'engine,'prepared,'op>{pub(crate)fn custody(&mut self)->&mut NativeOriginalRetainCustody<'engine,'prepared,'op>{&mut self.custody}}
#[cfg(feature="abi5-final-native-link")]
impl<'engine,'prepared,'op>NativeOriginalProductOperation<'engine,'prepared,'op>{
 pub(crate)fn retain(mut self)->Result<NativeOriginalProductRetained<'engine,'prepared,'op>,NativeOriginalRetainFailure<'engine,'prepared,'op>>{
  let result=self.engine.original.retain_computed(&mut self.operation.snapshot);
  match result{
   Err(error)=>Err(NativeOriginalRetainFailure{error:map(error),custody:NativeOriginalRetainCustody::Operation(self)}),
   Ok(native)=>{let mut retained=NativeOriginalProductRetained{engine:self.engine,pending:NativeProductPending{native},unknown:false};
    if retained.engine.original.current().is_err(){retained.unknown=true;return Err(NativeOriginalRetainFailure{error:NativeProductError::Unknown,custody:NativeOriginalRetainCustody::Pending(retained)})}Ok(retained)
   }
  }
 }
}
#[cfg(feature="abi5-final-native-link")]
pub(crate)struct NativeOriginalProductFinalRequest<'request,'prepared,'op>{request:super::platform::ScopedNativeFinalRequest<'request,'prepared,'op>,pending:&'request mut NativeProductPending}
#[cfg(feature="abi5-final-native-link")]
impl<'engine,'prepared,'op>NativeOriginalProductRetained<'engine,'prepared,'op>{
 pub(crate)fn bind_request<'request>(&'request mut self)->Result<NativeOriginalProductFinalRequest<'request,'prepared,'op>,NativeProductError>{
  if self.unknown{return Err(NativeProductError::Unknown)}
  let request=self.engine.original.bind_pending(&self.pending.native).map_err(map)?;
  Ok(NativeOriginalProductFinalRequest{request,pending:&mut self.pending})
 }
}
#[cfg(feature="abi5-final-native-link")]
impl NativeOriginalProductFinalRequest<'_,'_,'_>{
 pub(crate)fn dispatch(&mut self,action:super::platform::NativeFinalAction)->Result<super::platform::NativeFinalObservation,NativeProductError>{self.request.same_pending(&self.pending.native).map_err(map)?;self.request.dispatch(action).map_err(map)}
 pub(crate)fn recover_same_owner(&mut self)->Result<super::platform::NativeFinalObservation,NativeProductError>{self.request.same_pending(&self.pending.native).map_err(map)?;self.request.recover_same_owner().map_err(map)}
 pub(crate)fn try_close(&mut self)->Result<(),NativeProductError>{self.request.try_close().map_err(map)}
}

impl NativeProductEngine{
 fn current_original(&mut self)->Result<(),NativeProductError>{#[cfg(feature="abi5-final-native-link")]if let Some(original)=self.original.as_mut(){original.current().map_err(|_|NativeProductError::Unknown)?;}Ok(())}
 #[cfg(feature="abi5-final-native-link")]pub(crate)fn from_persistent_session(session:&super::platform::MessageSessionOwner,input:&crate::product_message::MessageInput)->Result<Self,super::platform::OwnedMessageOpenFailure>{
  let(original,bridge)=super::platform::OwnedMessageOriginal::open(session,input)?;Ok(Self{bridge,authority:None,original:Some(original),unclaimed:None})
 }
 #[cfg(feature="abi5-final-native-link")]pub(crate)fn close_persistent_operation(&mut self)->Result<(),NativeProductError>{
  if self.unclaimed.is_some(){return Err(NativeProductError::Held)}let Some(original)=self.original.as_mut()else{return Ok(())};original.close(Some(&self.bridge)).map_err(|_|NativeProductError::Unknown)?;self.original.take();Ok(())
 }
}
