//! Actual SessionCipher with retained whole-record diagnostics ONLY, no trust proof.
use super::*;
use spqr::{selected_lineage::FreshOrigin,ynx_operation::CallScope};
use std::collections::VecDeque;
#[derive(Debug,PartialEq,Eq)]enum Diagnostic{Missing,Bootstrap,Unretained,LaterFixtureOrigin,CachedUnadmitted}
struct History{owner:[u64;3],generation:u64,record:Vec<u8>,origins:VecDeque<FreshOrigin>,restored:bool}
fn owner(n:&Node)->[u64;3]{[n.core.owner,n.core.current.session,n.incarnation]}
impl History{
    fn fixture(n:&Node)->Self{Self{owner:owner(n),generation:n.core.current.state_generation,record:n.state(),origins:VecDeque::new(),restored:false}}
    fn check(&self,n:&Node)->Result<(),OperationError>{
        if self.restored{return Err(OperationError::Unproven)}
        if self.owner!=owner(n)||self.generation!=n.core.current.state_generation||self.record!=n.state(){return Err(OperationError::Binding)}Ok(())
    }
    fn operation(&mut self,n:&mut Node,input:Option<&CiphertextMessage>)->Result<(Vec<u8>,Diagnostic),OperationError>{
        self.check(n)?;let op=n.core.current.operation+1;
        let scope=CallScope::fixture([self.owner[0],self.owner[1],self.owner[2],self.generation,op,n.core.current.context,n.core.current.route,n.core.current.device_authorization,n.core.current.checkpoint,0,if input.is_some(){2}else{1}]);
        let mut rng=OsRng.unwrap_err();
        let result=if let Some(cipher)=input{
            scope.guard(message_decrypt_with_scope(cipher,&n.remote,&n.local,&mut n.store.session_store,&mut n.store.identity_store,&mut n.store.pre_key_store,&n.store.signed_pre_key_store,&mut n.store.kyber_pre_key_store,&mut rng,Some(&scope))).now_or_never().unwrap().map_err(|_|OperationError::Binding)?.map_err(|_|OperationError::Authentication)
        }else{
            scope.guard(message_encrypt_with_scope(b"selected lineage",&n.remote,&n.local,&mut n.store.session_store,&mut n.store.identity_store,SystemTime::now(),&mut rng,Some(&scope))).now_or_never().unwrap().map_err(|_|OperationError::Binding)?.map(|m|m.serialize().to_vec()).map_err(|_|OperationError::Crypto)
        };
        let diagnostic=scope.fixture_take_native_consumed();
        // Only a successful ACTUAL in-memory cipher/store operation advances this
        // cfg(test) diagnostic history. This is not an independently verified commit.
        let bytes=result?;
        let(selected,fresh,present)=diagnostic.expect("actual native KDF carried an opaque trace").fixture_parts();
        let kind=match selected.as_ref(){
            None=>Diagnostic::Missing,
            Some(s) if !present=>Diagnostic::Missing,
            Some(s) if s.fixture_epoch()==0=>Diagnostic::Bootstrap,
            Some(s) if s.fixture_cached()=>Diagnostic::CachedUnadmitted,
            Some(s)=>{
                let b=s.fixture_binding();assert_eq!(&b[..3],&self.owner);assert_eq!(b[3],self.generation);assert_eq!(b[4],op);
                let later=self.origins.iter().any(|o|{let origin=o.fixture_binding();o.fixture_epoch()==s.fixture_epoch()&&origin[..3]==b[..3]&&origin[3]<b[3]&&origin[4]<b[4]});
                if later{Diagnostic::LaterFixtureOrigin}else{Diagnostic::Unretained}
            }
        };
        if let Some(origin)=fresh{let b=origin.fixture_binding();assert_eq!(&b[..3],&self.owner);assert_eq!(b[3],self.generation);assert_eq!(b[4],op);if self.origins.len()==32{self.origins.pop_front();}self.origins.push_back(origin);}
        self.generation+=1;n.core.current.state_generation=self.generation;n.core.current.operation=op;self.record=n.state();
        assert!(n.core.capabilities.is_empty());Ok((bytes,kind))
    }
}
fn cipher(w:&[u8])->CiphertextMessage{CiphertextMessage::SignalMessage(SignalMessage::try_from(w).unwrap())}
fn run_pair(a:&mut Node,b:&mut Node,ha:&mut History,hb:&mut History)->[usize;4]{let mut later=[0;4];for _ in 0..160{
    let(w,d)=ha.operation(a,None).unwrap();later[0]+=usize::from(d==Diagnostic::LaterFixtureOrigin);
    let(clear,d)=hb.operation(b,Some(&cipher(&w))).unwrap();assert_eq!(clear,b"selected lineage");later[1]+=usize::from(d==Diagnostic::LaterFixtureOrigin);
    let(w,d)=hb.operation(b,None).unwrap();later[2]+=usize::from(d==Diagnostic::LaterFixtureOrigin);
    let(clear,d)=ha.operation(a,Some(&cipher(&w))).unwrap();assert_eq!(clear,b"selected lineage");later[3]+=usize::from(d==Diagnostic::LaterFixtureOrigin);
}later}
#[test]fn actual_later_operation_selection_and_bootstrap(){let(mut a,mut b)=pair();let(mut ha,mut hb)=(History::fixture(&a),History::fixture(&b));
    let(w,d)=ha.operation(&mut a,None).unwrap();assert_eq!(d,Diagnostic::Bootstrap);let(_,d)=hb.operation(&mut b,Some(&cipher(&w))).unwrap();assert_eq!(d,Diagnostic::Bootstrap);
    let later=run_pair(&mut a,&mut b,&mut ha,&mut hb);assert!(later.iter().all(|c|*c>0));eprintln!("nonsecret later-operation retained fixture origin counts={later:?}; NOT protected admission");assert!(CallScope::open_production().is_err());
}
#[test]fn actual_cached_ooo_cleartext_but_no_protected_freshness(){let(mut a,mut b)=pair();let(mut ha,mut hb)=(History::fixture(&a),History::fixture(&b));run_pair(&mut a,&mut b,&mut ha,&mut hb);
    let(first,_)=ha.operation(&mut a,None).unwrap();let(second,_)=ha.operation(&mut a,None).unwrap();assert_eq!(hb.operation(&mut b,Some(&cipher(&second))).unwrap().0,b"selected lineage");let(clear,d)=hb.operation(&mut b,Some(&cipher(&first))).unwrap();assert_eq!(clear,b"selected lineage");assert_eq!(d,Diagnostic::CachedUnadmitted);
}
#[test]fn actual_authfail_restore_replacement_and_foreign_store_reject(){let(mut a,mut b)=pair();let(mut ha,mut hb)=(History::fixture(&a),History::fixture(&b));run_pair(&mut a,&mut b,&mut ha,&mut hb);
    let(w,_)=ha.operation(&mut a,None).unwrap();let mut bad=w.clone();*bad.last_mut().unwrap()^=1;let before=b.state();let generation=hb.generation;let origin_count=hb.origins.len();assert!(matches!(hb.operation(&mut b,Some(&cipher(&bad))),Err(OperationError::Authentication)));assert_eq!(hb.generation,generation);assert_eq!(hb.origins.len(),origin_count);assert!(before==b.state());assert!(hb.operation(&mut b,Some(&cipher(&w))).is_ok());
    let(mut c,_d)=pair();let before=c.state();assert!(matches!(ha.operation(&mut c,None),Err(OperationError::Binding)));assert!(before==c.state());
    let earlier=SessionRecord::deserialize(&a.state()).unwrap();ha.operation(&mut a,None).unwrap();a.store.store_session(&a.remote,&earlier).now_or_never().unwrap().unwrap();assert!(matches!(ha.operation(&mut a,None),Err(OperationError::Binding)));
    let record=SessionRecord::deserialize(&b.state()).unwrap();b.store.store_session(&b.remote,&record).now_or_never().unwrap().unwrap();b.incarnation+=1;hb.restored=true;assert!(matches!(hb.operation(&mut b,None),Err(OperationError::Unproven)));
    // Byte-identical silent import with no trusted incarnation notification is
    // indistinguishable to byte continuity alone; production factory stays REQUIRED.
}
#[test]fn public_diagnostic_forgery_cannot_construct_native_selection(){let c=CallScope::fixture([1;11]);c.diagnostic_fresh(8);c.diagnostic_selected(8,true);c.diagnostic_consumed(true);c.diagnostic_authenticated();assert!(c.fixture_take_native_consumed().is_none());assert!(CallScope::open_production().is_err());}
