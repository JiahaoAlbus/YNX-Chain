//! Actual C non-null cleanup lifecycle. Synthetic supplier, no crypto grant.
use super::*;
use std::ffi::CString;
#[repr(C)]pub(in super::super) struct Driver{_opaque:[u8;0]}
#[repr(C)]#[derive(Default)]pub(in super::super) struct OwnerObservation{
 pub(in super::super) source_refs:i32,pub(in super::super) source_lock_held:i32,pub(in super::super) actual_autocommit:i32,pub(in super::super) sticky_unknown:i32,
 pub(in super::super) source_holds:usize,pub(in super::super) producer_borrows:usize,
}
#[derive(Clone,Copy)]#[repr(C)]pub(in super::super) enum Failure{SchemaSql=1,CommitUnknown=2}
unsafe extern "C"{
 pub(in super::super) fn veil_fixture_abi5_owner_create(path:*const std::ffi::c_char,mode:Failure,store:*mut *mut Store,driver:*mut *mut Driver)->i32;
 pub(in super::super) fn veil_fixture_abi5_owner_allow_rollback(driver:*mut Driver,allow:i32)->i32;
 pub(in super::super) fn veil_fixture_abi5_owner_observe(driver:*mut Driver,o:*mut OwnerObservation)->i32;
 pub(in super::super) fn veil_fixture_abi5_owner_driver_drop(driver:*mut *mut Driver,store:*mut Store)->i32;
 pub(in super::super) fn veil_store_close(store:*mut Store)->i32;
 pub(in super::super) fn veil_store_destroy(store:*mut *mut Store)->i32;
}
fn run(mode:Failure,primary:i32,name:&str){
 let root=std::env::var_os("VEIL_R17_FIXTURE_OUTPUT").expect("exclusive output required");
 let path=std::path::PathBuf::from(root).join(name);assert!(!path.exists());
 let path=CString::new(path.to_str().unwrap()).unwrap();
 let mut store=ptr::null_mut();let mut driver=ptr::null_mut();
 unsafe{
  assert_eq!(veil_fixture_abi5_owner_create(path.as_ptr(),mode,&mut store,&mut driver),primary);
  assert!(!store.is_null()&&!driver.is_null());
  let mut o=OwnerObservation::default();assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut o),0);
  assert_eq!((o.source_refs,o.source_lock_held,o.actual_autocommit,o.sticky_unknown),(1,1,0,1));
  assert_eq!(veil_store_close(store),5);
  let same_driver=driver;assert_eq!(veil_fixture_abi5_owner_driver_drop(&mut driver,store),5);assert_eq!(driver,same_driver);
  let mut borrow=SourceStoreBorrow::fixture_owned(store);
  let mut owner=SourceCleanupOwner::from_failed_source(&mut borrow,primary);
  assert_eq!(owner.retry(),Disposition::Held{primary,last:8});
  let same_cleanup=owner.handle;assert!(!same_cleanup.is_null());assert!(!owner.pending);assert!(owner.unknown);
  let obs=owner.observation.unwrap();assert_eq!(obs.primary,primary);assert_eq!(obs.actual_autocommit,0);
  assert_eq!(owner.retry(),Disposition::Held{primary,last:8});assert_eq!(owner.handle,same_cleanup);
  assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut o),0);
  assert_eq!((o.source_refs,o.source_lock_held,o.actual_autocommit,o.sticky_unknown),(1,1,0,1));assert_eq!(o.producer_borrows,1);
  assert_eq!(veil_store_close(store),5);
  assert_eq!(veil_fixture_abi5_owner_allow_rollback(driver,1),0);
  assert_eq!(owner.retry(),Disposition::Released{primary,unknown:true});assert!(owner.fully_released());assert!(owner.handle.is_null());
  assert_eq!(owner.first_primary,Some(primary));assert!(owner.unknown);
  assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut o),0);
  assert_eq!((o.source_refs,o.source_lock_held,o.actual_autocommit,o.sticky_unknown),(0,0,1,1));assert_eq!((o.source_holds,o.producer_borrows),(0,0));
  drop(owner); // Exact original store borrow ends only after capsule disposal.
  assert_eq!(veil_store_close(store),0);assert_eq!(veil_store_destroy(&mut store),0);assert!(store.is_null());
  assert_eq!(veil_fixture_abi5_owner_driver_drop(&mut driver,store),0);assert!(driver.is_null());
 }
}
#[test]fn r17_actual_c_schema_sql_primary_unknown_retained_capsule(){run(Failure::SchemaSql,3,"schema-primary.sqlite")}
#[test]fn r17_actual_c_commit_unknown_retained_capsule(){run(Failure::CommitUnknown,8,"commit-unknown.sqlite")}

// R18-I1: all actual C cleanup statuses succeed on FIRST retry. Neither
// rollback0 nor unknown_fence0 can erase prior source uncertainty.
#[test]fn r18_actual_c_schema_first_success_keeps_unknown_no_repeat_effects(){
 let root=std::env::var_os("VEIL_R17_FIXTURE_OUTPUT").expect("exclusive output required");
 let file=std::path::PathBuf::from(root).join("first-success-primary3.sqlite");assert!(!file.exists());
 let file=CString::new(file.to_str().unwrap()).unwrap();let mut store=ptr::null_mut();let mut driver=ptr::null_mut();
 unsafe{
  assert_eq!(veil_fixture_abi5_owner_create(file.as_ptr(),Failure::SchemaSql,&mut store,&mut driver),3);assert!(!store.is_null()&&!driver.is_null());
  let mut o=OwnerObservation::default();assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut o),0);
  assert_eq!((o.source_refs,o.source_lock_held,o.actual_autocommit,o.sticky_unknown),(1,1,0,1));
  assert_eq!(veil_fixture_abi5_owner_allow_rollback(driver,1),0);
  assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut o),0);assert_eq!((o.actual_autocommit,o.sticky_unknown),(0,1));
  let mut borrow=SourceStoreBorrow::fixture_owned(store);let mut owner=SourceCleanupOwner::from_failed_source(&mut borrow,3);
  assert_eq!(owner.retry(),Disposition::Released{primary:3,unknown:true});assert!(owner.fully_released());assert!(owner.handle.is_null());assert_eq!(owner.first_primary,Some(3));
  let observed=owner.observation.unwrap();assert_eq!((observed.primary,observed.rollback,observed.unknown_fence),(3,0,0));
  assert_eq!(owner.foreign_calls,[1,1,1]);
  assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut o),0);assert_eq!((o.source_refs,o.source_lock_held,o.actual_autocommit,o.sticky_unknown),(0,0,1,1));assert_eq!((o.source_holds,o.producer_borrows),(0,0));
  for _ in 0..2{assert_eq!(owner.retry(),Disposition::Released{primary:3,unknown:true});assert_eq!(owner.foreign_calls,[1,1,1]);}
  assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut o),0);assert_eq!((o.source_refs,o.source_lock_held,o.actual_autocommit,o.sticky_unknown,o.source_holds,o.producer_borrows),(0,0,1,1,0,0));
  drop(owner);assert_eq!(veil_store_close(store),0);assert_eq!(veil_store_destroy(&mut store),0);assert!(store.is_null());assert_eq!(veil_fixture_abi5_owner_driver_drop(&mut driver,store),0);assert!(driver.is_null());
 }
}
