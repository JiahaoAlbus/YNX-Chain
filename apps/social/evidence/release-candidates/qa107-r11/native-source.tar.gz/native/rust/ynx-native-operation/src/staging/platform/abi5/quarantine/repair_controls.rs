//! R20 repairs only. Exact selected non-null C graph, no production issuer.
use super::*;
use super::super::source_owner_controls::{OwnerObservation,Failure,veil_fixture_abi5_owner_create,veil_fixture_abi5_owner_allow_rollback,veil_fixture_abi5_owner_observe,veil_fixture_abi5_owner_driver_drop,veil_store_close,veil_store_destroy};
use std::{ffi::CString,ptr};
fn repaired(mode:Failure,primary:i32,name:&str,recorded:bool){
 let mut q=Quarantine::try_new(2).unwrap();let t=q.reserve().unwrap();let spare=q.reserve().unwrap();
 let file=std::path::PathBuf::from(std::env::var_os("VEIL_R17_FIXTURE_OUTPUT").unwrap()).join(name);assert!(!file.exists());let file=CString::new(file.to_str().unwrap()).unwrap();let mut store=ptr::null_mut();let mut driver=ptr::null_mut();
 unsafe{
  assert_eq!(veil_fixture_abi5_owner_create(file.as_ptr(),mode,&mut store,&mut driver),primary);
  let mut borrow=super::super::SourceStoreBorrow::fixture_owned(store);let mut op=q.operation(t).unwrap();assert!(op.bind(&mut borrow).is_ok());
  if recorded{op.failed_source(primary).unwrap();assert_eq!(op.failed_source(99),Err(Error::Duplicate));}
  else{assert_eq!(op.failed_source(0),Err(Error::NoFailure));}
  drop(op);
  match &q.slots[t.index].state{State::Held(o)=>{assert_eq!(o.first_primary,if recorded{Some(primary)}else{None});assert_eq!(o.cleanup_primary,None);assert!(o.pending&&o.handle.is_null()&&o.unknown);assert_eq!(o.foreign_calls,[0,0,0]);},_=>panic!("owner lost")}
  // Shutdown starts CLOSING even when it returns SAME registry to caller.
  q=match q.shutdown(){Err(q)=>q,Ok(())=>panic!("lost owner")};assert!(q.closing);
  assert!(matches!(q.reserve(),Err(Error::Closing)));assert!(matches!(q.operation(spare),Err(Error::Closing)));
  q.cancel_unbound(spare).unwrap();assert!(matches!(q.reserve(),Err(Error::Closing))); // free capacity still cannot admit
  let mut recovery=q.operation(t).unwrap();assert_eq!(recovery.retry(),Ok(Disposition::Held{primary,last:8}));drop(recovery);
  let (same,calls)=match &q.slots[t.index].state{State::Held(o)=>{assert_eq!(o.first_primary,Some(primary));assert_eq!(o.cleanup_primary,Some(8));assert!(o.unknown);(o.handle,o.foreign_calls)},_=>panic!()};assert!(!same.is_null());assert_eq!(calls,[1,1,1]);
  let mut obs=OwnerObservation::default();assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut obs),0);assert_eq!((obs.source_refs,obs.producer_borrows,obs.actual_autocommit,obs.sticky_unknown),(1,1,0,1));
  q=match q.shutdown(){Err(q)=>q,Ok(())=>panic!("second shutdown released owner")};assert!(q.closing);assert!(matches!(q.reserve(),Err(Error::Closing)));
  assert_eq!(match &q.slots[t.index].state{State::Held(o)=>o.handle,_=>panic!()},same);assert_eq!(veil_store_close(store),5);
  assert_eq!(veil_fixture_abi5_owner_allow_rollback(driver,1),0);
  let mut recovery=q.operation(t).unwrap();assert_eq!(recovery.retry(),Ok(Disposition::Released{primary,unknown:true}));drop(recovery);
  let calls=match &q.slots[t.index].state{State::Held(o)=>{assert_eq!(o.first_primary,Some(primary));assert_eq!(o.cleanup_primary,Some(8));assert!(o.handle.is_null()&&o.unknown);o.foreign_calls},_=>panic!()};assert_eq!(calls,[1,2,2]);
  let mut recovery=q.operation(t).unwrap();assert_eq!(recovery.retry(),Ok(Disposition::Released{primary,unknown:true}));drop(recovery);assert_eq!(match &q.slots[t.index].state{State::Held(o)=>o.foreign_calls,_=>panic!()},calls);
  assert_eq!(q.retire(t),Ok(Disposition::Released{primary,unknown:true}));assert!(matches!(q.reserve(),Err(Error::Closing)));assert!(matches!(q.operation(t),Err(Error::Stale)));assert!(q.shutdown().is_ok());
  assert_eq!(veil_fixture_abi5_owner_observe(driver,&mut obs),0);assert_eq!((obs.source_refs,obs.source_lock_held,obs.actual_autocommit,obs.sticky_unknown,obs.source_holds,obs.producer_borrows),(0,0,1,1,0,0));assert_eq!(veil_store_close(store),0);assert_eq!(veil_store_destroy(&mut store),0);assert!(store.is_null());assert_eq!(veil_fixture_abi5_owner_driver_drop(&mut driver,store),0);assert!(driver.is_null());
 }
}
#[test]fn r20_actual_c_unrecorded_sql_first_primary_same_capsule_closing(){repaired(Failure::SchemaSql,3,"r20-unrecorded-sql.sqlite",false)}
#[test]fn r20_actual_c_unrecorded_unknown_first_primary_same_capsule_closing(){repaired(Failure::CommitUnknown,8,"r20-unrecorded-unknown.sqlite",false)}
#[test]fn r20_actual_c_recorded_primary_preserved_after_shutdown_retry(){repaired(Failure::SchemaSql,3,"r20-recorded.sqlite",true)}
#[test]fn r20_shutdown_closes_unbound_inventory_without_foreign_effects(){let mut q=Quarantine::try_new(2).unwrap();let t=q.reserve().unwrap();q=match q.shutdown(){Err(q)=>q,Ok(())=>panic!("reserved slot still live")};assert!(q.closing);assert!(matches!(q.reserve(),Err(Error::Closing)));assert!(matches!(q.operation(t),Err(Error::Closing)));q.cancel_unbound(t).unwrap();assert!(matches!(q.reserve(),Err(Error::Closing)));assert!(q.shutdown().is_ok());}
