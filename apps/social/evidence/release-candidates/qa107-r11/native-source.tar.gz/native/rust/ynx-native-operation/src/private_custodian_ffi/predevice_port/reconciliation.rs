//! Original-owner evidence retention only. No durable disposition constructor.
//! NotEntered does NOT mean no effect: reserve may already be durable.
use super::*;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super)enum CommitInvocation { NotEntered, Entered, Returned(i32) }
impl CommitInvocation {
    pub(super)fn enter(&mut self) {
        if *self == Self::NotEntered { *self = Self::Entered; }
    }
    pub(super)fn returned(&mut self, status:i32) {
        if *self == Self::Entered { *self = Self::Returned(status); }
    }
}

/// Exclusive borrow of the original custody, not a copied selector or receipt.
/// It cannot open, reserve, retry commit, dispose, or clear the original cause.
pub(in crate::private_custodian_ffi)struct RetainedReconciliation<'a> {
    owner: &'a mut PreDeviceOwner,
}
impl PreDeviceOwner {
    pub(in crate::private_custodian_ffi)fn retain_reconciliation(&mut self)
        -> Result<RetainedReconciliation<'_>,CustodyError> {
        self.thread()?;
        Ok(RetainedReconciliation { owner:self })
    }
}
impl RetainedReconciliation<'_> {
    // Scalar observations are not release/admission conditions. In particular,
    // Returned(3) and readback_verified cannot produce a terminal disposition.
    pub(in crate::private_custodian_ffi)fn original_cause(&self)->Option<i32> { self.owner.first }
    pub(in crate::private_custodian_ffi)fn unresolved(&self)->bool { self.owner.unknown }
    pub(in crate::private_custodian_ffi)fn commit_was_entered(&self)->bool {
        self.owner.commit_invocation != CommitInvocation::NotEntered
    }
}

#[cfg(test)]mod reconciliation_controls {
    use super::*;
    #[test]fn reconciliation_controls_first_return_is_not_replaced() {
        let mut state=CommitInvocation::NotEntered;
        state.enter(); assert_eq!(state,CommitInvocation::Entered);
        state.returned(4); state.enter(); state.returned(3);
        assert_eq!(state,CommitInvocation::Returned(4));
    }
    #[test]fn reconciliation_controls_actual_failed_open_keeps_cause_and_no_commit() {
        let mut owner=PreDeviceOwner::unopened([1;16],[2;16]);
        let input=match LocalGenesisInput::checked("ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef".into(),1,vec![7],30) {
            Ok(input)=>input,
            Err(_)=>panic!("PUBLIC fixture input rejected"),
        };
        assert!(owner.reserve(&std::ffi::CString::new("relative").unwrap(),&input).is_err());
        let first=owner.first; assert!(first.is_some());
        for _ in 0..2 {
            let held=owner.retain_reconciliation().unwrap();
            assert_eq!(held.original_cause(),first);
            assert!(held.unresolved()); assert!(!held.commit_was_entered());
        }
        assert!(matches!(owner.close_known(),Err(CustodyError::Unknown)));
        assert_eq!(owner.first,first);
        assert!(owner.store.is_null()&&owner.ticket.is_null()&&owner.result.is_null());
    }
}
