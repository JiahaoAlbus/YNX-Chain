// Intentionally compile-fails: exact pinned upstream async Store futures are !Send.
use libsignal_protocol::*;
use rand::{rngs::OsRng,TryRngCore as _};
use spqr::ynx_operation::CallScope;
fn require_send<T:Send>(_:T){}
fn cannot_migrate(store:&mut InMemSignalProtocolStore,scope:&CallScope,local:&ProtocolAddress,remote:&ProtocolAddress){
    let mut rng=OsRng.unwrap_err();
    require_send(message_encrypt_with_scope(b"no runtime operation",remote,local,&mut store.session_store,&mut store.identity_store,std::time::SystemTime::now(),&mut rng,Some(scope)));
}
fn main(){}
