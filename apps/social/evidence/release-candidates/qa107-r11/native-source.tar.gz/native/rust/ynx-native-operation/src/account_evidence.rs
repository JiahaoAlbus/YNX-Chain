//! Independently verified A v2 evidence, NOT a signing/effect authority.
//! No approved root provisioned here; caller expectations require original-owner
//! provenance separately. No JNI factory, no response-derived expectations.
#![allow(unsafe_code)]
use base64::{Engine as _,engine::general_purpose::{URL_SAFE_NO_PAD as URL,STANDARD}};
use serde_json::{Value,Map};
use sha2::{Digest,Sha256};
use std::{cell::Cell,marker::PhantomData,rc::{Rc,Weak},time::{Duration,Instant}};
const MAX:u64=(1<<53)-1;
const CLIENT:&str="ynx-social-v1-m1qa-sso-v1";
const ISSUER:&str="https://wallet-auth.ynxweb4.com";
const ORIGIN:&str="https://social.ynxweb4.com";
const ROLE_DOMAIN:&[u8]=b"YNX_CENTRAL_SOCIAL_ACCOUNT_PENDING_ROLE_V2\n";
const RAW_DOMAIN:&[u8]=b"YNX_SOCIAL_ORIGINAL_ACCOUNT_ELIGIBILITY_V2\n";
#[derive(Debug,PartialEq,Eq)]pub(crate)enum Error{Bounds,Canonical,Binding,ProfileRequired,Signature,Window}
struct ApprovedRoot{key:[u8;32]}
// Release/source-owned approval only. Never accept key/header/ENV as root.
fn approved_roots()->&'static[ApprovedRoot]{&[]}
pub(crate)struct Original<'a>{
 pub(crate) lifetime:&'a RequestLifetime,
 pub(crate) account:&'a str,pub(crate) operation:&'a str,pub(crate) association:&'a str,
 pub(crate) challenge_nonce:&'a str,pub(crate) request_digest:&'a str,
 pub(crate) identity:&'a str,pub(crate) device:&'a str,pub(crate) session:&'a str,pub(crate) family:&'a str,
 pub(crate) revision:u64,pub(crate) generation:u64,pub(crate) reserved:u64,
 pub(crate) challenge_issued:u64,pub(crate) challenge_expires:u64,
 pub(crate) issuer_message:&'a[u8],pub(crate) target_message:&'a[u8],
}
pub(crate)struct UnadmittedAccountEvidence{
 raw:Box<[u8]>,role:Box<[u8]>,operation:String,lower:u64,upper:u64,
 challenge_issued:u64,challenge_expires:u64,
 started:Instant,budget:Duration,owner:Weak<Lifetime>,_local:PhantomData<Rc<()>>,
}
struct Lifetime{started:Instant,budget:Duration,cancelled:Cell<bool>}
// No Clone, serialization or time renewal; actual source request owns this.
pub(crate)struct RequestLifetime{inner:Rc<Lifetime>}
impl RequestLifetime{
 pub(crate)fn retain(started:Instant,budget:Duration)->Self{Self{inner:Rc::new(Lifetime{started,budget,cancelled:Cell::new(false)})}}
 pub(crate)fn cancel(&self){self.inner.cancelled.set(true)}
 fn check(&self)->Result<(),Error>{self.inner.check()}
}
impl Lifetime{fn check(&self)->Result<(),Error>{if self.cancelled.get()||self.started.elapsed()>=self.budget{Err(Error::Window)}else{Ok(())}}}
// Shared actual receiving fence. The closure is internal verification work,
// never a supplier authorization callback or a public permit constructor.
fn within_original<T>(owner:&RequestLifetime,verify:impl FnOnce()->Result<T,Error>)->Result<T,Error>{owner.check()?;let out=verify()?;owner.check()?;Ok(out)}
fn canonical(v:&Value)->Result<Vec<u8>,Error>{
 fn order(v:&Value)->Result<Value,Error>{Ok(match v{
  Value::Object(m)=>{let mut keys:Vec<_>=m.keys().collect();keys.sort();let mut out=Map::new();for k in keys{out.insert(k.clone(),order(&m[k])?);}Value::Object(out)},
  Value::Array(a)=>Value::Array(a.iter().map(order).collect::<Result<_,_>>()?),
  Value::Number(n)=>{if n.as_u64().filter(|n|*n<=MAX).is_none(){return Err(Error::Canonical)}v.clone()},
  _=>v.clone(),
 })}
 serde_json::to_vec(&order(v)?).map_err(|_|Error::Canonical)
}
fn parse(raw:&[u8],fields:&[&str])->Result<Value,Error>{
 if raw.is_empty()||raw.len()>8192{return Err(Error::Bounds)}
 let v:Value=serde_json::from_slice(raw).map_err(|_|Error::Canonical)?;
 let m=v.as_object().ok_or(Error::Canonical)?;
 if m.len()!=fields.len()||fields.iter().any(|k|!m.contains_key(*k))||canonical(&v)?!=raw{return Err(Error::Canonical)}Ok(v)
}
fn text<'a>(v:&'a Value,k:&str)->Result<&'a str,Error>{v[k].as_str().filter(|s|!s.is_empty()&&s.len()<=4096).ok_or(Error::Binding)}
fn number(v:&Value,k:&str)->Result<u64,Error>{v[k].as_u64().filter(|n|*n<=MAX).ok_or(Error::Binding)}
// Frozen Go FormatUint -> A p.revision, never a JSON numeric alternative.
fn prepared_revision(v:&Value)->Result<u64,Error>{
 let s=text(v,"preparedRevision")?;
 if s.len()>16||s.starts_with('0')||!s.bytes().all(|b|b.is_ascii_digit()){return Err(Error::Binding)}
 s.parse::<u64>().ok().filter(|n|*n>0&&*n<=MAX).ok_or(Error::Binding)
}
fn challenge_nonce(s:&str)->Result<(),Error>{
 if s.len()!=43{return Err(Error::Binding)}
 let bytes=URL.decode(s).map_err(|_|Error::Binding)?;
 if bytes.len()!=32||URL.encode(&bytes)!=s{return Err(Error::Binding)}Ok(())
}
fn bind_prepared_wire(v:&Value,revision:u64,nonce:&str)->Result<(),Error>{
 challenge_nonce(nonce)?;challenge_nonce(text(v,"challengeNonce")?)?;
 if prepared_revision(v)?!=revision{return Err(Error::Binding)}
 equal(v,"challengeNonce",nonce)
}
fn equal(v:&Value,k:&str,want:&str)->Result<(),Error>{if text(v,k)?!=want{return Err(Error::Binding)}Ok(())}
fn window(lo:u64,hi:u64,cap:u64,now:u64)->Result<(),Error>{if lo>MAX||hi>MAX||hi.checked_sub(lo).filter(|n|*n>0&&*n<=cap).is_none()||now<lo||now>=hi{return Err(Error::Window)}Ok(())}
fn hex(bytes:&[u8])->String{bytes.iter().map(|b|format!("{b:02x}")).collect()}
fn message_digest(role:&str,wire:&[u8])->Result<String,Error>{if wire.is_empty()||wire.len()>49152{return Err(Error::Bounds)}let mut h=Sha256::new();h.update(format!("YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_{role}_V1\n"));h.update(wire);Ok(hex(&h.finalize()))}
unsafe extern "C"{fn crypto_sign_verify_detached(sig:*const u8,msg:*const u8,len:u64,key:*const u8)->i32;}
fn verify(key:&[u8;32],v:&Value,domain:&[u8])->Result<(),Error>{
 let encoded=text(v,"signature")?;let sig=URL.decode(encoded).map_err(|_|Error::Signature)?;
 if sig.len()!=64||URL.encode(&sig)!=encoded{return Err(Error::Signature)}
 let mut body=v.clone();body.as_object_mut().ok_or(Error::Canonical)?.remove("signature");
 let mut msg=domain.to_vec();msg.extend(canonical(&body)?);
 if unsafe{crypto_sign_verify_detached(sig.as_ptr(),msg.as_ptr(),msg.len()as u64,key.as_ptr())}!=0{return Err(Error::Signature)}Ok(())
}
fn public_key(pem:&str)->Result<[u8;32],Error>{
 let inner=pem.strip_prefix("-----BEGIN PUBLIC KEY-----\n").and_then(|s|s.strip_suffix("-----END PUBLIC KEY-----\n").or_else(||s.strip_suffix("-----END PUBLIC KEY-----"))).ok_or(Error::Binding)?;
 let joined=inner.replace('\n',"");let der=STANDARD.decode(&joined).map_err(|_|Error::Binding)?;
 if STANDARD.encode(&der)!=joined||der.len()!=44||der[..12]!=[0x30,0x2a,0x30,5,6,3,0x2b,0x65,0x70,3,0x21,0]{return Err(Error::Binding)}
 der[12..].try_into().map_err(|_|Error::Binding)
}
const ROLE_FIELDS:&[&str]=&["version","purpose","issuer","keyId","publicKey","role","clientId","origin","issuedAtMs","expiresAtMs","registrationNonce","environment","audience","registrationVersion","revokePolicy","signature"];
const RAW_FIELDS:&[&str]=&["version","purpose","issuer","keyId","registrationDigest","associationCommitment","operation","challengeNonce","challengeRequestDigest","preparedRevision","issuerMessageDigest","targetMessageDigest","identity","device","account","clientId","origin","sessionId","familyId","generation","state","reservedAtMs","issuedAtMs","expiresAtMs","signature"];
pub(crate)fn verify_original(role_raw:&[u8],raw:&[u8],original:&Original<'_>)->Result<UnadmittedAccountEvidence,Error>{
 within_original(original.lifetime,||verify_bound(role_raw,raw,original))
}
fn verify_bound(role_raw:&[u8],raw:&[u8],original:&Original<'_>)->Result<UnadmittedAccountEvidence,Error>{
 let started=original.lifetime.inner.started;let at=u64::try_from(crate::source_evidence::now_ms().map_err(|_|Error::Window)?).map_err(|_|Error::Window)?;
 let(lower,upper)=verify_fields_at(role_raw,raw,original,at)?;
 let budget=original.lifetime.inner.budget.min(started.elapsed().checked_add(Duration::from_millis(upper-at)).ok_or(Error::Window)?);
 let out=UnadmittedAccountEvidence{raw:raw.into(),role:role_raw.into(),operation:original.operation.into(),lower,upper,challenge_issued:original.challenge_issued,challenge_expires:original.challenge_expires,started,budget,owner:Rc::downgrade(&original.lifetime.inner),_local:PhantomData};
 out.recheck(original.operation)?;Ok(out)
}
// Same verifier for current receiving and original recorded-time history.
// This function alone retains no lifetime and constructs no accepted owner.
fn verify_fields_at(role_raw:&[u8],raw:&[u8],original:&Original<'_>,at:u64)->Result<(u64,u64),Error>{
 let role=parse(role_raw,ROLE_FIELDS)?;let body=parse(raw,RAW_FIELDS)?;
 if number(&role,"version")?!=2||number(&body,"version")?!=2{return Err(Error::Binding)}
 for v in [&role,&body]{equal(v,"issuer",ISSUER)?;equal(v,"clientId",CLIENT)?;equal(v,"origin",ORIGIN)?;}
 equal(&role,"purpose","central-social-account-pending-role/v2")?;
 equal(&role,"registrationVersion","central-social-account-pending-role/v2")?;
 equal(&role,"role","original-central-social-account-pending-writer")?;
 equal(&role,"environment","testnet")?;equal(&role,"audience","ynx:social:native-first-enrollment")?;
 equal(&role,"revokePolicy","original-operation-barrier-until-authenticated-terminal")?;
 equal(&body,"purpose","social-original-account-eligibility/v2")?;equal(&body,"state","unknown-pending")?;
 let key_id=text(&role,"keyId")?;if key_id.len()>128||!key_id.bytes().all(|b|b.is_ascii_alphanumeric()||b"._:-".contains(&b)){return Err(Error::Binding)}
 let nonce=text(&role,"registrationNonce")?;let nb=URL.decode(nonce).map_err(|_|Error::Binding)?;if nb.len()!=32||URL.encode(nb)!=nonce{return Err(Error::Binding)}
 let root=approved_roots().first().ok_or(Error::ProfileRequired)?;
 verify(&root.key,&role,ROLE_DOMAIN)?;
 verify(&public_key(text(&role,"publicKey")?)?,&body,RAW_DOMAIN)?;
 equal(&body,"keyId",key_id)?;equal(&body,"registrationDigest",&hex(&Sha256::digest(role_raw)))?;
 for(k,v)in[("account",original.account),("operation",original.operation),("associationCommitment",original.association),("challengeNonce",original.challenge_nonce),("challengeRequestDigest",original.request_digest),("identity",original.identity),("device",original.device),("sessionId",original.session),("familyId",original.family)]{equal(&body,k,v)?;}
 bind_prepared_wire(&body,original.revision,original.challenge_nonce)?;
 if original.generation==0||number(&body,"generation")?!=original.generation||number(&body,"reservedAtMs")?!=original.reserved{return Err(Error::Binding)}
 equal(&body,"issuerMessageDigest",&message_digest("ISSUER",original.issuer_message)?)?;
 equal(&body,"targetMessageDigest",&message_digest("TARGET",original.target_message)?)?;
 let ri=number(&role,"issuedAtMs")?;let re=number(&role,"expiresAtMs")?;let bi=number(&body,"issuedAtMs")?;let be=number(&body,"expiresAtMs")?;
 window(ri,re,86400000,at)?;window(bi,be,30000,at)?;window(original.challenge_issued,original.challenge_expires,MAX,at)?;
 if bi<original.reserved||bi<ri||be>re||be>original.challenge_expires{return Err(Error::Window)}
 let lower=ri.max(bi).max(original.challenge_issued);let upper=re.min(be).min(original.challenge_expires);
 Ok((lower,upper))
}
pub(crate)struct HistoricalAccountRecord<'a>{
 pub(crate)issuer:&'a str,pub(crate)account:&'a str,pub(crate)client:&'a str,
 pub(crate)operation:&'a str,pub(crate)identity:&'a str,pub(crate)device:&'a str,
 pub(crate)revision:u64,pub(crate)challenge_nonce:&'a str,pub(crate)challenge_issued:u64,pub(crate)challenge_expires:u64,
 pub(crate)proposal:&'a[u8],pub(crate)issuer_message:&'a[u8],pub(crate)target_message:&'a[u8],pub(crate)recorded:u64,
}
impl UnadmittedAccountEvidence{
 // Authenticates historical bytes at their original recorded time using the
 // SAME already verified exact registration role and existing approved root.
 // No expired historical account is rehydrated as a current RequestLifetime.
 pub(crate)fn verify_namespace_historical(&self,role_raw:&[u8],raw:&[u8],record:&HistoricalAccountRecord<'_>)->Result<(),Error>{
  self.recheck(&self.operation)?;
  if role_raw!=self.role.as_ref()||record.issuer!=ISSUER||record.client!=CLIENT{return Err(Error::Binding)}
  let body=parse(raw,RAW_FIELDS)?;
  let lifetime=RequestLifetime{inner:self.owner.upgrade().ok_or(Error::Window)?};
  let original=Original{lifetime:&lifetime,account:record.account,operation:record.operation,association:text(&body,"associationCommitment")?,challenge_nonce:record.challenge_nonce,request_digest:&hex(&Sha256::digest(record.proposal)),identity:record.identity,device:record.device,session:text(&body,"sessionId")?,family:text(&body,"familyId")?,revision:record.revision,generation:number(&body,"generation")?,reserved:number(&body,"reservedAtMs")?,challenge_issued:record.challenge_issued,challenge_expires:record.challenge_expires,issuer_message:record.issuer_message,target_message:record.target_message};
  verify_fields_at(role_raw,raw,&original,record.recorded)?;
  self.recheck(&self.operation)
 }
 // The source-response publication fence must retain BOTH this verified
 // account lifetime and its actual original capture/join. A still-current
 // source proof cannot replace an expired/unknown account operation.
 pub(crate)fn recheck_with_original(&self,operation:&str,original:Option<&crate::account_instance::Attempt>)->Result<(),Error>{
  self.recheck(operation)?;
  original.ok_or(Error::Binding)?.recheck().map_err(|_|Error::Binding)?;
  self.recheck(operation)
 }
 pub(crate) fn matches_pending_source(&self,operation:&str,raw:&[u8],registration_digest:&str,issuer:&str,account:&str,client:&str,lower:i64,upper:i64)->Result<(),Error>{
  self.recheck(operation)?;
  if raw!=self.raw.as_ref()||registration_digest!=hex(&Sha256::digest(&self.role))||lower<0||upper<=lower||(lower as u64)<self.lower||(upper as u64)>self.upper{return Err(Error::Binding)}
  let body=parse(&self.raw,RAW_FIELDS)?;
  for(k,v)in[("issuer",issuer),("account",account),("clientId",client)]{equal(&body,k,v)?;}
  self.recheck(operation)
 }
 pub(crate) fn matches_pending_prepared(&self,operation:&str,identity:&str,device:&str,revision:u64,nonce:&str,association:&str,proposal_digest:&str,issuer_digest:&str,target_digest:&str,challenge_issued:i64,challenge_expires:i64)->Result<(),Error>{
  self.recheck(operation)?;
  if challenge_issued<0||challenge_expires<0||challenge_issued as u64!=self.challenge_issued||challenge_expires as u64!=self.challenge_expires{return Err(Error::Binding)}
  let body=parse(&self.raw,RAW_FIELDS)?;
  for(k,v)in[("identity",identity),("device",device),("preparedRevision",&revision.to_string()),("challengeNonce",nonce),("associationCommitment",association),("challengeRequestDigest",proposal_digest),("issuerMessageDigest",issuer_digest),("targetMessageDigest",target_digest)]{equal(&body,k,v)?;}
  self.recheck(operation)
 }
 pub(crate)fn recheck(&self,operation:&str)->Result<(),Error>{
 self.owner.upgrade().ok_or(Error::Window)?.check()?;
 let now=u64::try_from(crate::source_evidence::now_ms().map_err(|_|Error::Window)?).map_err(|_|Error::Window)?;
 if operation!=self.operation||self.started.elapsed()>=self.budget{return Err(Error::Window)}window(self.lower,self.upper,MAX,now)
 }
}
#[cfg(test)]mod account_v2_controls{
 use super::*;
 #[test]fn source_publication_requires_same_live_account_original(){
  // PUBLIC lifetime-only fixture, never a signed/approved account or grant.
  let at=crate::source_evidence::now_ms().unwrap() as u64;
  let owner=RequestLifetime::retain(Instant::now(),Duration::from_secs(30));
  let evidence=UnadmittedAccountEvidence{raw:b"PUBLIC unverified".as_slice().into(),role:b"PUBLIC unverified".as_slice().into(),operation:"PUBLIC-original".into(),lower:at-1,upper:at+30000,challenge_issued:at-1,challenge_expires:at+30000,started:owner.inner.started,budget:owner.inner.budget,owner:Rc::downgrade(&owner.inner),_local:PhantomData};
  assert_eq!(evidence.recheck("PUBLIC-original"),Ok(()));
  assert_eq!(evidence.recheck_with_original("PUBLIC-original",None),Err(Error::Binding));
  let outcome=crate::source_evidence::after_callbacks(||{owner.cancel();Ok(())},||evidence.recheck_with_original("PUBLIC-original",None));
  assert_eq!(outcome,Err(Error::Window));
  assert_eq!(evidence.recheck_with_original("replacement",None),Err(Error::Window));
  assert!(approved_roots().is_empty());
 }
 #[test]fn canonical_duplicate_unknown_and_unsafe_integer(){
  assert!(parse(br#"{"a":1,"a":1}"#,&["a"]).is_err());
  assert!(parse(br#"{"a":9007199254740992}"#,&["a"]).is_err());
  assert!(parse(br#"{"b":1,"a":2}"#,&["a","b"]).is_err());
  assert!(parse(br#"{"a":1,"b":2}"#,&["a"]).is_err());
  assert!(parse(br#"{"a":9007199254740991}"#,&["a"]).is_ok());
 }
 #[test]fn independent_type4_domains_and_window(){
  assert_ne!(message_digest("ISSUER",b"PUBLIC").unwrap(),message_digest("TARGET",b"PUBLIC").unwrap());
  assert!(message_digest("ISSUER",&vec![0;49153]).is_err());
  assert!(window(100,200,30000,99).is_err());assert!(window(100,200,30000,100).is_ok());assert!(window(100,200,30000,200).is_err());assert!(approved_roots().is_empty());
 }
 #[test]fn selected_sodium_public_rfc8032_verification(){
  fn bytes(s:&str)->Vec<u8>{s.as_bytes().chunks_exact(2).map(|c|u8::from_str_radix(std::str::from_utf8(c).unwrap(),16).unwrap()).collect()}
  let key=bytes("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a");
  let mut sig=bytes("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b");
  assert_eq!(unsafe{crypto_sign_verify_detached(sig.as_ptr(),b"".as_ptr(),0,key.as_ptr())},0);
  sig[0]^=1;assert_ne!(unsafe{crypto_sign_verify_detached(sig.as_ptr(),b"".as_ptr(),0,key.as_ptr())},0);
 }
}

#[cfg(test)]mod go_public_account_vectors{
 use super::*;
 #[test]
 #[ignore="requires explicitly generated PUBLIC Go vectors, never approved account material"]
 fn go_public_role_and_raw_signatures_match_native(){
  let directory=std::env::var_os("YNX_SOCIAL_PUBLIC_ACCOUNT_VECTOR_DIR").expect("PUBLIC Go vector directory required");
  let directory=std::path::PathBuf::from(directory);
  let root=std::fs::read(directory.join("account-root.bin")).unwrap();let root:[u8;32]=root.try_into().unwrap();
  let role_raw=std::fs::read(directory.join("account-role.json")).unwrap();let raw=std::fs::read(directory.join("account-raw.json")).unwrap();
  let role=parse(&role_raw,ROLE_FIELDS).unwrap();let body=parse(&raw,RAW_FIELDS).unwrap();
  verify(&root,&role,ROLE_DOMAIN).unwrap();verify(&public_key(text(&role,"publicKey").unwrap()).unwrap(),&body,RAW_DOMAIN).unwrap();
  assert_eq!(text(&body,"registrationDigest").unwrap(),hex(&Sha256::digest(&role_raw)));
  equal(&body,"account","PUBLIC-account").unwrap();bind_prepared_wire(&body,1,&URL.encode([2u8;32])).unwrap();
  equal(&body,"issuerMessageDigest",&message_digest("ISSUER",b"PUBLIC-issuer-message").unwrap()).unwrap();
  equal(&body,"targetMessageDigest",&message_digest("TARGET",b"PUBLIC-target-message").unwrap()).unwrap();
  let mut altered=body.clone();altered["account"]=Value::String("PUBLIC-other-account".into());
  assert!(verify(&public_key(text(&role,"publicKey").unwrap()).unwrap(),&altered,RAW_DOMAIN).is_err());
  assert!(approved_roots().is_empty());
 }
}

#[cfg(test)]mod account_wire_matching_controls{
 use super::*;
 #[test]fn exact_go_a_public_fields(){
  // Public zero bytes, NOT a live challenge or a signed eligibility envelope.
  let nonce="AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
  let raw=br#"{"challengeNonce":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","preparedRevision":"9007199254740991"}"#;
  let v=parse(raw,&["challengeNonce","preparedRevision"]).unwrap();
  assert_eq!(bind_prepared_wire(&v,MAX,nonce),Ok(()));
  assert_eq!(bind_prepared_wire(&v,MAX-1,nonce),Err(Error::Binding));
  let first=serde_json::json!({"challengeNonce":nonce,"preparedRevision":"1"});
  assert_eq!(bind_prepared_wire(&first,1,nonce),Ok(()));
 }
 #[test]fn revision_has_one_canonical_string_representation(){
  for value in [serde_json::json!(1),serde_json::json!(1.0),serde_json::json!(null),serde_json::json!(true),serde_json::json!(""),serde_json::json!("0"),serde_json::json!("01"),serde_json::json!("+1"),serde_json::json!(" 1"),serde_json::json!("1e0"),serde_json::json!("1.0"),serde_json::json!("9007199254740992"),serde_json::json!("18446744073709551616"),serde_json::json!("\u{ff11}")]{
   assert_eq!(prepared_revision(&serde_json::json!({"preparedRevision":value})),Err(Error::Binding));
  }
 }
 #[test]fn nonce_is_exact_unpadded_base64url_not_hex(){
  let good=URL.encode([255u8;32]);
  assert_eq!(challenge_nonce(&good),Ok(()));
  for bad in [hex(&[255u8;32]),format!("{good}="),STANDARD.encode([255u8;32]),URL.encode([0u8;31]),URL.encode([0u8;33]),format!("{}B","A".repeat(42))]{
   assert_eq!(challenge_nonce(&bad),Err(Error::Binding));
   let v=serde_json::json!({"preparedRevision":"1","challengeNonce":bad});
   assert_eq!(bind_prepared_wire(&v,1,&good),Err(Error::Binding));
  }
  let other=URL.encode([0u8;32]);
  assert_eq!(bind_prepared_wire(&serde_json::json!({"preparedRevision":"1","challengeNonce":other}),1,&good),Err(Error::Binding));
 }
}

#[cfg(test)]mod original_account_clock_controls{
 use super::*;
 #[test]fn expired_original_rejects_before_work_despite_wall_rollback(){
  let owner=RequestLifetime::retain(Instant::now()-Duration::from_secs(2),Duration::from_secs(1));
  let calls=Cell::new(0);
  for wall in [150,100]{
   let out=within_original(&owner,||{calls.set(calls.get()+1);window(100,200,30000,wall)});
   assert_eq!(out,Err(Error::Window));
  }
  assert_eq!(calls.get(),0);
 }
 #[test]fn slow_actual_receiving_work_cannot_publish_or_renew(){
  let owner=RequestLifetime::retain(Instant::now(),Duration::from_millis(5));
  let out=within_original(&owner,||{std::thread::sleep(Duration::from_millis(15));Ok(())});
  assert_eq!(out,Err(Error::Window));
  assert_eq!(within_original(&owner,||panic!("expired repeat must not invoke work")),Err::<(),_>(Error::Window));
 }
 #[test]fn cancelled_during_work_and_dropped_owner_invalidate_evidence(){
  let owner=RequestLifetime::retain(Instant::now(),Duration::from_secs(30));
  assert_eq!(within_original(&owner,||{owner.cancel();Ok(())}),Err(Error::Window));
  // PUBLIC time-only evidence fixture, not a valid ROLE/raw or admitted proof.
  let owner=RequestLifetime::retain(Instant::now(),Duration::from_secs(30));
  let now=crate::source_evidence::now_ms().unwrap()as u64;
  let evidence=UnadmittedAccountEvidence{raw:Box::new([]),role:Box::new([]),operation:"PUBLIC".into(),lower:now.saturating_sub(100),upper:now+30000,challenge_issued:now.saturating_sub(100),challenge_expires:now+30000,started:owner.inner.started,budget:owner.inner.budget,owner:Rc::downgrade(&owner.inner),_local:PhantomData};
  assert_eq!(evidence.recheck("PUBLIC"),Ok(()));
  drop(owner);assert_eq!(evidence.recheck("PUBLIC"),Err(Error::Window));
 }
}
// Separate independently admitted Central ROLE source. No instance-root or
// incoming header selects this input. Actual release input is not configured.
const APPROVED_PENDING_ROLE_RAW:Option<&[u8]>=None;
pub(crate)fn original_pending_role()->Result<&'static[u8],Error>{APPROVED_PENDING_ROLE_RAW.ok_or(Error::ProfileRequired)}
