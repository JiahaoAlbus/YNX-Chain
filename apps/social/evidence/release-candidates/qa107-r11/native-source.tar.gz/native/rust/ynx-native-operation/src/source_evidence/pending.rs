//! Private dual first-prepared receipt. Successful verification is UNADMITTED:
//! it neither proves complete account history nor constructs a signing permit.
use super::*;
use sha2::{Digest,Sha256};
const MAX:u64=(1u64<<53)-1;
#[path="namespace_prefix.rs"]mod namespace_prefix;
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields)]
pub(super)struct Carrier{version:u64,issuer:Envelope,anchor:Envelope,companion:String,#[serde(default,skip_serializing_if="Option::is_none",rename="namespacePrefix")]namespace_prefix:Option<namespace_prefix::Carrier>}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
struct Namespace{issuer:String,account:String,client_id:String}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields)]
struct Extent{sequence:u64,offset:u64,length:u64,digest:String}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
struct Lifecycle{schema:String,sequence:u64,head_digest:String,state:String,pending_operation:String,ever_committed:bool}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
struct Body{
 schema:String,version:u64,authority:String,realm:String,policy_version:u64,policy_digest:String,
 namespace:Namespace,scope:Scope,operation:String,challenge_nonce:String,
 challenge_issued_ms:i64,challenge_expires_ms:i64,prepared_revision:u64,identity:String,device:String,
 proposal_digest:String,issuer_type4_digest:String,target_type4_digest:String,association_commitment:String,
 eligibility_digest:String,account_registration_digest:String,checkpoint:policy::Checkpoint,
 checkpoint_issuer_digest:String,checkpoint_anchor_digest:String,prepared_event:Extent,
 base_root:String,base_epoch:u64,next_root:String,lifecycle:Lifecycle,native_request_nonce:String,issued_ms:i64,expires_ms:i64,
}
#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields,rename_all="camelCase")]
struct Companion{schema:String,version:u64,proposal:String,issuer_message:String,target_message:String,eligibility_raw:String}

pub(super)struct Evidence{body:Body,raw:Box<[u8]>,eligibility:zeroize::Zeroizing<Vec<u8>>,namespace_prefix:Option<namespace_prefix::Witness>}
pub(super)fn storage_coordinates(raw:&[u8])->Result<FirstPreparedStorageCoordinates,Error>{
 let b:Body=canonical(raw,32768)?;shape(&b)?;
 let(sequence,head,custodian)=b.checkpoint.storage_coordinates();
 let mut digest=[0;32];for(i,x)in digest.iter_mut().enumerate(){*x=u8::from_str_radix(&head[i*2..i*2+2],16).map_err(|_|Error::Binding)?;}
 let nonce=decode(&b.native_request_nonce,32,32)?.try_into().map_err(|_|Error::Binding)?;
 Ok(FirstPreparedStorageCoordinates{operation:b.operation,nonce,sequence,head:digest,anchor_custodian:custodian.into()})
}
fn hash(domain:&[u8],raw:&[u8])->String{let mut h=Sha256::new();h.update(domain);h.update(raw);h.finalize().iter().map(|b|format!("{b:02x}")).collect()}
fn commitment(s:&str)->bool{digest(s)&&s.bytes().any(|b|b!=b'0')}
fn interval(lower:i64,upper:i64,limit:i64)->bool{lower>=0&&upper>lower&&(upper as u64)<=MAX&&upper-lower<=limit}
fn frame(role:&str,body:&[u8])->Result<Vec<u8>,Error>{
 if !["first-prepared-issuer","first-prepared-anchor"].contains(&role)||body.is_empty()||body.len()>32768{return Err(Error::Bounds)}
 let mut v=b"YNX/SOCIAL/SOURCE-PROOF/V1\0".to_vec();v.push(role.len() as u8);v.extend(role.as_bytes());v.extend((body.len()as u32).to_be_bytes());v.extend(body);Ok(v)
}
fn envelope(e:&Envelope,role:&str,key:&Pair)->Result<Vec<u8>,Error>{
 if e.version!=1||e.role!=role{return Err(Error::Binding)}
 let raw=decode(&e.body,1,32768)?;let input=frame(role,&raw)?;
 let pk=decode(&key.classic,33,33)?;if pk[0]!=5{return Err(Error::Bounds)}
 let pq=decode(&key.pq,2592,2592)?;let classic=decode(&e.signature.classic,64,64)?;let post_quantum=decode(&e.signature.pq,4627,4627)?;
 if !libsignal_protocol::PublicKey::deserialize(&pk).map_err(|_|Error::Signature)?.verify_signature(&input,&classic){return Err(Error::Signature)}
 if unsafe{own_selected_verify(pq.as_ptr(),pq.len(),input.as_ptr(),input.len(),post_quantum.as_ptr(),post_quantum.len())}!=1{return Err(Error::Signature)}
 Ok(raw)
}
fn shape(b:&Body)->Result<(),Error>{
 if b.schema!="YNX-SOCIAL-FIRST-PREPARED-V1"||b.version!=1||b.policy_version!=1||!ascii(&b.authority,512)||!ascii(&b.realm,256)||!ascii(&b.namespace.issuer,512)||!ascii(&b.namespace.account,1024)||!ascii(&b.namespace.client_id,128)||!scope_valid(&b.scope)||b.scope.source_generation>MAX||b.scope.native_restore_incarnation>MAX||!ascii(&b.operation,128)||!ascii(&b.identity,128)||!ascii(&b.device,128)||b.prepared_revision==0||b.prepared_revision>MAX{return Err(Error::Binding)}
 for s in [&b.policy_digest,&b.proposal_digest,&b.issuer_type4_digest,&b.target_type4_digest,&b.association_commitment,&b.eligibility_digest,&b.account_registration_digest,&b.checkpoint_issuer_digest,&b.checkpoint_anchor_digest,&b.prepared_event.digest,&b.base_root,&b.next_root,&b.lifecycle.head_digest]{if !commitment(s){return Err(Error::Binding)}}
 if b.issuer_type4_digest==b.target_type4_digest||b.checkpoint_issuer_digest==b.checkpoint_anchor_digest||b.base_root==b.next_root||b.base_epoch==0||b.base_epoch>=MAX{return Err(Error::Binding)}
 for nonce in [&b.challenge_nonce,&b.native_request_nonce]{if decode(nonce,32,32)?.iter().all(|b|*b==0){return Err(Error::Binding)}}
 let e=&b.prepared_event;let l=&b.lifecycle;
 if !b.checkpoint.pending_extent(&b.realm,&b.scope,&b.base_root,b.base_epoch,e.sequence,e.offset,e.length,b.issued_ms,b.expires_ms)||l.schema!="YNX-SOCIAL-GENESIS-LIFECYCLE-V2"||l.sequence==0||l.sequence>MAX||l.state!="SAME_ORIGINAL_PENDING_FIRST"||l.pending_operation!=b.operation||l.ever_committed{return Err(Error::Binding)}
 if !interval(b.issued_ms,b.expires_ms,30000)||!interval(b.challenge_issued_ms,b.challenge_expires_ms,120000)||b.issued_ms<b.challenge_issued_ms||b.expires_ms>b.challenge_expires_ms{return Err(Error::Window)}
 Ok(())
}
fn companion(raw:&[u8],b:&Body,original:&OriginalExpectation<'_>)->Result<zeroize::Zeroizing<Vec<u8>>,Error>{
 let c:Companion=canonical(raw,192*1024)?;
 if c.schema!="YNX-SOCIAL-FIRST-PREPARED-COMPANION-V1"||c.version!=1{return Err(Error::Binding)}
 let proposal=decode(&c.proposal,2657,2657)?;let issuer=decode(&c.issuer_message,1,65536)?;let target=decode(&c.target_message,1,65536)?;
 let eligibility=zeroize::Zeroizing::new(decode(&c.eligibility_raw,1,8192)?);
 if proposal!=original.proposal||issuer!=original.issuer_transcript||target!=original.target_transcript||b.operation!=format!("fd1-{}",B64.encode(&proposal[2625..]))||hash(b"",&proposal)!=b.proposal_digest||hash(b"YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_ISSUER_V1\n",&issuer)!=b.issuer_type4_digest||hash(b"YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_TARGET_V1\n",&target)!=b.target_type4_digest||hash(b"",&eligibility)!=b.eligibility_digest{return Err(Error::Binding)}
 Ok(eligibility)
}
pub(super)fn verify(c:&Carrier,original:&OriginalExpectation<'_>,issuer:&Credential,anchor:&Credential,h:&History,registration:&Registration,history_envelope:&Envelope)->Result<Evidence,Error>{
 if !matches!((c.version,c.namespace_prefix.is_some()),(1,false)|(2,true)){return Err(Error::Binding)}
 let i=issuer.first_prepared.as_ref().ok_or(Error::Binding)?;let a=anchor.first_prepared.as_ref().ok_or(Error::Binding)?;
 let raw=envelope(&c.issuer,"first-prepared-issuer",&issuer.public)?;
 if raw!=envelope(&c.anchor,"first-prepared-anchor",&anchor.public)?{return Err(Error::Binding)}
 let body:Body=canonical(&raw,32768)?;shape(&body)?;
 let signed_body=raw.clone();
 let checkpoint_envelope=registration.directory_checkpoint.as_ref().ok_or(Error::Binding)?;
 let checkpoint_bytes=serde_json::to_vec(checkpoint_envelope).map_err(|_|Error::Canonical)?;
 let history_bytes=serde_json::to_vec(history_envelope).map_err(|_|Error::Canonical)?;
 if body.checkpoint_issuer_digest!=hash(b"",&checkpoint_bytes)||body.checkpoint_anchor_digest!=hash(b"",&history_bytes){return Err(Error::Binding)}
 if body.policy_digest!=first_prepared::policy_digest(i,a)?||body.authority!=issuer.authority||body.scope!=*original.scope||body.operation!=original.operation||decode(&body.native_request_nonce,32,32)?.as_slice()!=original.nonce||h.directory_checkpoint.as_ref()!=Some(&body.checkpoint){return Err(Error::Binding)}
 let (deployment,instance,header)=body.checkpoint.deployment_coordinates();
 for policy in [i,a]{if !policy.pending_coordinates(&body.authority,&body.realm,&body.namespace.issuer,&body.namespace.client_id,deployment,instance,header,body.issued_ms,body.expires_ms){return Err(Error::Binding)}}
 let raw=zeroize::Zeroizing::new(decode(&c.companion,1,192*1024)?);
 let eligibility=companion(&raw,&body,original)?;
 let namespace_prefix=match &c.namespace_prefix{Some(prefix)=>{
  // Route is from the already verified existing source credential policy,
  // never from a prefix DTO or a newly supplied root/route registration.
  let policy=issuer.first_enrollment.as_ref().ok_or(Error::Binding)?;
  let policy=serde_json::to_value(policy).map_err(|_|Error::Canonical)?;
  Some(namespace_prefix::verify(prefix,&body,policy["route"].as_str().ok_or(Error::Binding)?)?)
 },None=>None};
 let evidence=Evidence{body,raw:signed_body.into_boxed_slice(),eligibility,namespace_prefix};evidence.current(now_ms()?)?;Ok(evidence)
}
impl Evidence{
 // Both carriers were independently authenticated by their original verifiers.
 // This checks consistency only; it cannot construct account evidence or owner.
 pub(super)fn server_consistency(&self,account:&crate::account_instance::ServerVerifiedOriginal,prefix:&[u8])->Result<(),Error>{
  self.current(now_ms()?)?;account.current().map_err(|_|Error::Window)?;
  let f=account.frame().map_err(|_|Error::Binding)?;let b=&self.body;
  let text=|v:&serde_json::Value,k:&str|v[k].as_str().map(str::to_owned).ok_or(Error::Binding);
  for(k,expected)in [("issuer",b.namespace.issuer.as_str()),("account",b.namespace.account.as_str()),("clientId",b.namespace.client_id.as_str()),("operation",b.operation.as_str()),("associationCommitment",b.association_commitment.as_str())]{if text(f,k)?!=expected{return Err(Error::Binding)}}
  let c=&f["challenge"];let p=&f["preparedPublicCommitment"];
  for(k,expected)in [("nonce",b.challenge_nonce.as_str()),("requestDigest",b.proposal_digest.as_str())]{if text(c,k)?!=expected{return Err(Error::Binding)}}
  for(k,expected)in [("identity",b.identity.as_str()),("device",b.device.as_str()),("revision",b.prepared_revision.to_string().as_str())]{if text(p,k)?!=expected{return Err(Error::Binding)}}
  if c["issuedAtMs"].as_i64()!=Some(b.challenge_issued_ms)||c["expiresAtMs"].as_i64()!=Some(b.challenge_expires_ms)||hash(b"",&account.proposal)!=b.proposal_digest||hash(b"YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_ISSUER_V1\n",&account.issuer)!=b.issuer_type4_digest||hash(b"YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_TARGET_V1\n",&account.target)!=b.target_type4_digest{return Err(Error::Binding)}
  if self.namespace_prefix.as_ref().ok_or(Error::Binding)?.raw()!=prefix{return Err(Error::Binding)}
  account.current().map_err(|_|Error::Window)?;self.current(now_ms()?)
 }
 pub(super)fn has_namespace_prefix(&self)->bool{self.namespace_prefix.is_some()}
 pub(super)fn retained_storage_body(&self)->&[u8]{&self.raw}

 pub(super)fn restrict_window(&self,window:&mut policy::Window)->Result<(),Error>{window.restrict(self.body.issued_ms,self.body.expires_ms)}
 pub(super)fn current(&self,now:i64)->Result<(),Error>{if now<self.body.issued_ms||now>=self.body.expires_ms{Err(Error::Window)}else{Ok(())}}
 pub(super)fn check_account(&self,account:&crate::account_evidence::UnadmittedAccountEvidence)->Result<(),Error>{
  self.current(now_ms()?)?;
  let b=&self.body;
  account.matches_pending_source(&b.operation,&self.eligibility,&b.account_registration_digest,&b.namespace.issuer,&b.namespace.account,&b.namespace.client_id,b.issued_ms,b.expires_ms).map_err(|_|Error::Binding)?;
  account.matches_pending_prepared(&b.operation,&b.identity,&b.device,b.prepared_revision,&b.challenge_nonce,&b.association_commitment,&b.proposal_digest,&b.issuer_type4_digest,&b.target_type4_digest,b.challenge_issued_ms,b.challenge_expires_ms).map_err(|_|Error::Binding)?;
  if let Some(prefix)=&self.namespace_prefix{prefix.verify_historical(account)?;}
  self.current(now_ms()?)
 }
 // A retained fact view after SAME current account checks, not admission or a
 // capability constructor. Legacy Pending1 has no complete-prefix projection.
 pub(super)fn original_namespace_prefix<'a>(&'a self,account:&crate::account_evidence::UnadmittedAccountEvidence)->Result<&'a[u8],Error>{self.check_account(account)?;let raw=self.namespace_prefix.as_ref().ok_or(Error::Binding)?.raw();self.current(now_ms()?)?;Ok(raw)}
}
#[cfg(test)]mod controls{
 use super::*;
 #[test]fn pending_roles_never_expand_old_gate(){assert!(frame("first-prepared-issuer",b"{}").is_ok());assert!(frame("directory-checkpoint",b"{}").is_err());assert!(signing_input("first-prepared-issuer",b"{}").is_err());}
 #[test]fn pending_windows_half_open_and_original_challenge(){assert!(interval(100,120100,120000));assert!(!interval(100,120101,120000));assert!(!interval(100,100,30000));assert!(!interval(-1,100,30000));}
}

#[cfg(test)]mod go_cross_controls{
 use super::*;
 #[test]#[ignore="requires actual separately generated PUBLIC Go pending bytes"]
 fn pending_actual_go_body_and_companion(){
  let dir=std::env::var("YNX_SOCIAL_PUBLIC_PENDING_VECTOR_DIR").expect("PUBLIC fixture directory");
  let raw=std::fs::read(std::path::Path::new(&dir).join("pending-body.json")).unwrap();
  let payload=std::fs::read(std::path::Path::new(&dir).join("pending-companion.json")).unwrap();
  let body:Body=canonical(&raw,32768).unwrap();shape(&body).unwrap();
  for (file,expected) in [("pending-checkpoint-envelope.json",&body.checkpoint_issuer_digest),("pending-history-envelope.json",&body.checkpoint_anchor_digest)]{
   let raw=std::fs::read(std::path::Path::new(&dir).join(file)).unwrap();let e:Envelope=canonical(&raw,32768).unwrap();
   assert_eq!(&hash(b"",&serde_json::to_vec(&e).unwrap()),expected);
  }
  let c:Companion=canonical(&payload,192*1024).unwrap();
  let proposal=decode(&c.proposal,2657,2657).unwrap();let im=decode(&c.issuer_message,1,65536).unwrap();let tm=decode(&c.target_message,1,65536).unwrap();let nonce:[u8;32]=decode(&body.native_request_nonce,32,32).unwrap().try_into().unwrap();
  let original=OriginalExpectation{operation:&body.operation,proposal:&proposal,issuer_transcript:&im,target_transcript:&tm,scope:&body.scope,nonce:&nonce,head:"PUBLIC-unused",catalog:"PUBLIC-unused"};
  let account=companion(&payload,&body,&original).unwrap();assert!(!account.is_empty());
  let text=String::from_utf8(raw.clone()).unwrap();
  for changed in [format!(" {text}"),text.replacen("\"version\":1","\"version\":1,\"version\":1",1),text.replacen("\"version\":1","\"version\":1,\"unknown\":true",1)]{assert!(canonical::<Body>(changed.as_bytes(),32768).is_err());}
  for case in 0..7{
   let mut changed:Body=canonical(&raw,32768).unwrap();
   match case{0=>changed.prepared_event.offset=u64::MAX,1=>changed.prepared_event.length=512*1024+1,2=>changed.lifecycle.ever_committed=true,3=>changed.challenge_expires_ms=changed.challenge_issued_ms+120001,4=>changed.native_request_nonce=B64.encode([0;32]),5=>changed.checkpoint_issuer_digest=changed.checkpoint_anchor_digest.clone(),_=>changed.prepared_revision=1u64<<53}
   assert!(shape(&changed).is_err());
  }
  let altered=payload.iter().copied().chain([b' ']).collect::<Vec<_>>();assert!(companion(&altered,&body,&original).is_err());
  assert!(approved_profiles().is_empty()); // Fixture never becomes a grant.
 }
}
