//! Fixed synchronous collector transport, not a caller-provided callback table.
use super::*;
use std::{cell::RefCell,sync::atomic::{AtomicU64,Ordering}};
unsafe extern "C" {
 fn ynx_source_collector_identity_v1(owner:u64)->u64;
 fn ynx_source_collector_store_v1(owner:u64,loan:u64,bytes:*const u8,n:usize)->u64;
 fn ynx_source_collector_consume_v1(owner:u64,loan:u64,bytes:*const u8,n:usize,receipt:u64)->i32;
}
struct Held {id:u64,loan:u64,collector:u64,pair:InfrastructurePair,credential:Option<super::first_prepared_holder::HolderCredential>}
thread_local!{static HELD:RefCell<Option<Held>>=const{RefCell::new(None)};}
static NEXT:AtomicU64=AtomicU64::new(1);
// No exported normal constructor. Actual admitted producer must hand its SAME
// pair to this private owning entry on the already-pinned worker, not a DTO.
fn install_owned(pair:InfrastructurePair,credential:Option<super::first_prepared_holder::HolderCredential>)->Result<u64,(InfrastructurePair,Option<super::first_prepared_holder::HolderCredential>)>{
 if pair.thread!=std::thread::current().id()||pair.attempt.is_none(){return Err((pair,credential))}
 #[cfg(feature="abi5-final-native-link")]if pair.attempt.as_ref().is_some_and(|a|a.phase==AttemptPhase::Ready)&&(pair.role_guard.is_none()||credential.as_ref().is_none_or(|c|c.recheck().is_err())){return Err((pair,credential))}
 HELD.with(|slot|{let Ok(mut h)=slot.try_borrow_mut()else{return Err((pair,credential))};if h.is_some(){return Err((pair,credential))}
 let Ok(id)=NEXT.fetch_update(Ordering::SeqCst,Ordering::SeqCst,|v|v.checked_add(1))else{return Err((pair,credential))};
 *h=Some(Held{id,loan:0,collector:0,pair,credential});Ok(id)})
}
fn install(pair:InfrastructurePair)->Result<u64,InfrastructurePair>{install_owned(pair,None).map_err(|(p,_)|p)}

fn guarded(f:impl FnOnce()->i32)->i32{std::panic::catch_unwind(std::panic::AssertUnwindSafe(f)).unwrap_or(5)}
#[unsafe(no_mangle)]pub extern "C" fn ynx_source_native_collect_v1(id:u64)->i32{guarded(||HELD.with(|slot|{
 let Ok(mut guard)=slot.try_borrow_mut()else{return 5};let Some(h)=guard.as_mut()else{return 6};if h.id!=id{return 6}
 let Some(a)=h.pair.attempt.as_ref()else{return 1};
 // Late uncertainty is independent of the retained first error/scratch phase.
 if !a.collection_eligible(){return 5}
 let Ok(bytes)=a.encode_unverified_outcome()else{return 1};
 let collector=unsafe{ynx_source_collector_identity_v1(id)};if collector==0{return 5};if h.collector!=0&&h.collector!=collector{return 6};h.collector=collector;
 if h.loan==0{h.loan=1};let loan=h.loan; // retries retain SAME loan and original result
 let receipt=unsafe{ynx_source_collector_store_v1(id,loan,bytes.as_ptr(),bytes.len())};if receipt==0{return 5}
 if unsafe{ynx_source_collector_consume_v1(id,loan,bytes.as_ptr(),bytes.len(),receipt)}!=0{return 5}
 // Still exclusively borrowed on the same OS thread. No user callback/drop
 // runs between successful consume and removal. used/unknown remain sticky.
 drop(h.pair.attempt.take());0
}))}
#[unsafe(no_mangle)]pub extern "C" fn ynx_source_native_close_v1(id:u64)->i32{guarded(||HELD.with(|slot|{
 let Ok(mut g)=slot.try_borrow_mut()else{return 5};let Some(h)=g.as_mut()else{return 1};if h.id!=id{return 6}
 match h.pair.close(){Ok(())=>{drop(g.take());0},Err(_)=>5}
}))}
#[unsafe(no_mangle)]pub extern "C" fn ynx_source_native_status_v1(id:u64)->i32{guarded(||HELD.with(|slot|{
 let Ok(g)=slot.try_borrow()else{return 5};match g.as_ref(){Some(h)if h.id==id=>if h.pair.attempt.is_some(){2}else if h.pair.used&&h.pair.unknown{3}else{4},_=>6}
}))}
// The separate fixture artifact has no credentials, keys or real signatures.
// Symbols below are entirely absent from normal builds.
#[cfg(feature="source-collector-public-controls")]
#[unsafe(no_mangle)]pub extern "C" fn ynx_source_public_fixture_open_v1(mode:u32)->u64{
 std::panic::catch_unwind(||{
 let role=b"directory-checkpoint";let mut frame=b"YNX/SOCIAL/SOURCE-PROOF/V1\0".to_vec();frame.push(role.len()as u8);frame.extend(role);frame.extend(2u32.to_be_bytes());frame.extend(b"{}");let mut c=[1;33];c[0]=5;
 let b=SourceAttemptBinding::bounded(b"PUBLIC TEST ONLY operation",[2;32],7,[3;32],SourceRole::Issuer,b"PUBLIC TEST ONLY custodian",c,&[4;2592],&frame).unwrap();
 let mut a=RetainedSourceAttempt::new(b);if mode==1{a.cancel()}else{a.run_once(|_|Ok(vec![0x51;64].into_boxed_slice()),|_,out,written|{if mode==2{out.fill(0x52);*written=out.len();0}else if mode==3{5}else{17}})}
 let pair=InfrastructurePair{classic:None,pq:std::ptr::null_mut(),wrapping:std::ptr::null_mut(),role:SourceRole::Issuer,custodian:b"PUBLIC TEST ONLY custodian".to_vec(),thread:std::thread::current().id(),used:true,unknown:true,local:PhantomData,expected:None,attempt:Some(a),#[cfg(feature="abi5-final-native-link")]role_guard:None};
 match pair.retain_for_collection(){Ok(id)=>id,Err(mut pair)=>{drop(pair.attempt.take());0}}
 }).unwrap_or(0)
}
#[cfg(feature="source-collector-public-controls")]
#[unsafe(no_mangle)]pub extern "C" fn ynx_source_public_fixture_drop_v1(id:u64)->i32{guarded(||HELD.with(|slot|{
 let Ok(mut g)=slot.try_borrow_mut()else{return 5};let Some(h)=g.as_mut()else{return 1};if h.id!=id{return 6};drop(h.pair.attempt.take());drop(g.take());0
}))}
#[cfg(feature="source-collector-public-controls")]
#[unsafe(no_mangle)]pub extern "C" fn ynx_source_public_fixture_copy_v1(id:u64,out:*mut u8,cap:usize)->usize{
 std::panic::catch_unwind(||HELD.with(|slot|{let g=slot.borrow();let Some(h)=g.as_ref()else{return 0};if h.id!=id{return 0};let Some(a)=h.pair.attempt.as_ref()else{return 0};let Ok(raw)=a.encode_unverified_outcome()else{return 0};if out.is_null()||cap<raw.len(){return 0};unsafe{std::ptr::copy_nonoverlapping(raw.as_ptr(),out,raw.len())};raw.len()})).unwrap_or(0)
}

// Ownership transfer only: no signing, provisioning, DTO or authority creation.
// Failure returns the same pair, including any unresolved original attempt.
impl InfrastructurePair {
 pub(crate) fn retain_for_collection(self)->Result<u64,Self>{install(self)}
 #[cfg(feature="abi5-final-native-link")]pub(super) fn retain_ready_for_collection(self,c:super::first_prepared_holder::HolderCredential)->Result<u64,(Self,super::first_prepared_holder::HolderCredential)>{install_owned(self,Some(c)).map_err(|(p,c)|(p,c.unwrap()))}
}

// Fixed synchronous Go bridge contract, not a callback table or user permit.
// Main must validate actual pinned dispatch journal SIGNING row + exact intent
// and the matching active call context; absence/refusal never invokes crypto.
#[repr(C)]pub(crate)struct ClaimedIntentRaw{
 operation:*const u8,operation_size:usize,nonce:*const u8,sequence:u64,head:*const u8,role:*const u8,role_size:usize,custodian:*const u8,custodian_size:usize,classic:*const u8,pq:*const u8,frame:*const u8,frame_size:usize,
}
#[cfg(feature="abi5-final-native-link")]
unsafe extern "C"{fn ynx_source_collector_claimed_intent_v1(owner:u64,collector:u64,intent:*const ClaimedIntentRaw)->i32;}
#[cfg(feature="abi5-final-native-link")]
fn claimed_intent(h:&mut Held)->Result<(),SourceError>{
 let a=h.pair.attempt.as_ref().ok_or(SourceError::Closed)?;if a.phase!=AttemptPhase::Ready{return Err(SourceError::Unknown)}
 let b=&a.original;let role:&[u8]=match(b.purpose,b.role){(SourcePurpose::Directory,SourceRole::Issuer)=>b"directory-checkpoint",(SourcePurpose::Directory,SourceRole::Anchor)=>b"current-history",(SourcePurpose::FirstPrepared,SourceRole::Issuer)=>b"first-prepared-issuer",(SourcePurpose::FirstPrepared,SourceRole::Anchor)=>b"first-prepared-anchor"};
 let collector=unsafe{ynx_source_collector_identity_v1(h.id)};if collector==0||h.collector!=0&&h.collector!=collector{return Err(SourceError::Pair)}
 let raw=ClaimedIntentRaw{operation:b.operation.as_ptr(),operation_size:b.operation.len(),nonce:b.nonce.as_ptr(),sequence:b.sequence,head:b.head.as_ptr(),role:role.as_ptr(),role_size:role.len(),custodian:b.custodian.as_ptr(),custodian_size:b.custodian.len(),classic:b.classic_public.as_ptr(),pq:b.pq_public.as_ptr(),frame:b.frame.as_ptr(),frame_size:b.frame.len()};
 if unsafe{ynx_source_collector_claimed_intent_v1(h.id,collector,&raw)}!=0{return Err(SourceError::Unknown)}
 h.collector=collector;Ok(())
}
#[cfg(feature="abi5-final-native-link")]
#[unsafe(no_mangle)]pub extern "C" fn ynx_source_native_run_claimed_v1(id:u64)->i32{guarded(||HELD.with(|slot|{
 let Ok(mut s)=slot.try_borrow_mut()else{return 5};let Some(h)=s.as_mut()else{return 6};if h.id!=id{return 6}
 if h.credential.as_ref().is_none_or(|c|c.recheck().is_err()){h.pair.retain_claimed_unknown();return 5}
 if let Err(_)=claimed_intent(h){h.pair.retain_claimed_unknown();return 5}
 if h.credential.as_ref().is_none_or(|c|c.recheck().is_err()){h.pair.retain_claimed_unknown();return 5}
 let result=h.pair.run_claimed_role();
 if result.is_err(){h.pair.retain_claimed_unknown();return 5}
 if h.credential.as_ref().is_none_or(|c|c.recheck().is_err()){h.pair.unknown=true;if let Some(g)=h.pair.role_guard.as_mut(){g.invalidate()}if let Some(a)=h.pair.attempt.as_mut(){a.fail(AttemptStage::Cancel,SourceError::Unknown)}return 5}
 match result{Ok(())=>0,Err(_)=>5}
}))}

#[cfg(test)]mod late_uncertainty_delta_controls{
 use super::*;
 fn attempt(complete:bool)->RetainedSourceAttempt{let role=b"directory-checkpoint";let mut f=b"YNX/SOCIAL/SOURCE-PROOF/V1\0".to_vec();f.push(role.len()as u8);f.extend(role);f.extend(2u32.to_be_bytes());f.extend(b"{}");let mut k=[1;33];k[0]=5;let b=SourceAttemptBinding::bounded(b"PUBLIC-retention",[2;32],7,[3;32],SourceRole::Issuer,b"PUBLIC-custodian",k,&[4;2592],&f).unwrap();let mut a=RetainedSourceAttempt::new(b);a.run_once(|_|Ok(vec![0x51;64].into_boxed_slice()),|_,out,n|{if complete{out.fill(0x52);*n=out.len();0}else{17}});a}
 #[test]fn known_partial_retains_collection_baseline(){let a=attempt(false);assert!(a.collection_eligible());assert!(!a.uncertain);assert_eq!(a.cause,Some((AttemptStage::Pq,SourceError::Foreign(17))));}
 #[test]fn late_cancel_preserves_first_cause_and_scratch(){let mut a=attempt(false);let bytes=a.encode_unverified_outcome().unwrap();a.fail(AttemptStage::Cancel,SourceError::Unknown);assert!(a.uncertain);assert!(!a.collection_eligible());assert_eq!(a.phase,AttemptPhase::Partial);assert_eq!(a.cause,Some((AttemptStage::Pq,SourceError::Foreign(17))));assert_eq!(a.encode_unverified_outcome().unwrap(),bytes);a.run_once(|_|panic!("repeat classic"),|_,_,_|panic!("repeat pq"));assert!(a.uncertain);}
 #[test]fn late_panic_after_partial_keeps_first_failure(){let mut a=attempt(false);a.fail(AttemptStage::Panic,SourceError::Unknown);assert!(!a.collection_eligible());assert_eq!(a.cause,Some((AttemptStage::Pq,SourceError::Foreign(17))));}
 #[test]fn complete_late_current_failure_is_retained(){let mut a=attempt(true);assert!(a.collection_eligible());let classic=a.classic.as_ref().unwrap().to_vec();let pq=a.pq.clone();a.fail(AttemptStage::Cancel,SourceError::Unknown);assert!(!a.collection_eligible());assert_eq!(a.classic.as_ref().unwrap().as_ref(),classic.as_slice());assert_eq!(a.pq,pq);}
 #[test]fn real_collect_refuses_late_unknown_before_transport(){let mut a=attempt(false);a.fail(AttemptStage::Cancel,SourceError::Unknown);let pair=InfrastructurePair{classic:None,pq:std::ptr::null_mut(),wrapping:std::ptr::null_mut(),role:SourceRole::Issuer,custodian:b"PUBLIC-custodian".to_vec(),thread:std::thread::current().id(),used:true,unknown:true,local:PhantomData,expected:None,attempt:Some(a),#[cfg(feature="abi5-final-native-link")]role_guard:None};let id=match install(pair){Ok(id)=>id,Err(mut p)=>{drop(p.attempt.take());panic!("install refused")}};assert_eq!(ynx_source_native_collect_v1(id),5);assert_eq!(ynx_source_native_status_v1(id),2);assert_eq!(ynx_source_native_close_v1(id),5);HELD.with(|slot|{let mut held=slot.borrow_mut();let h=held.as_mut().unwrap();assert!(h.pair.attempt.as_ref().unwrap().uncertain);assert_eq!(h.loan,0);assert_eq!(h.collector,0);drop(h.pair.attempt.take());drop(held.take());});}
 #[cfg(feature="abi5-final-native-link")]
 #[test]fn ready_claimed_failure_latches_without_reexecution(){let mut a=attempt(false);let original=a.original.clone();a=RetainedSourceAttempt::new(original);let mut pair=InfrastructurePair{classic:None,pq:std::ptr::null_mut(),wrapping:std::ptr::null_mut(),role:SourceRole::Issuer,custodian:b"PUBLIC-custodian".to_vec(),thread:std::thread::current().id(),used:false,unknown:false,local:PhantomData,expected:None,attempt:Some(a),role_guard:None};pair.retain_claimed_unknown();assert!(pair.attempt.as_ref().unwrap().uncertain);assert!(!pair.attempt.as_ref().unwrap().collection_eligible());assert_eq!(pair.run_claimed_role(),Err(SourceError::Unknown));drop(pair.attempt.take());assert!(pair.close().is_ok());}
}
