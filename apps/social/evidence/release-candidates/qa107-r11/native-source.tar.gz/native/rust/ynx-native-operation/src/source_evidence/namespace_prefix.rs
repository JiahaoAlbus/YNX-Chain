//! Exact private directory prefix. This is history evidence, never admission.
use super::*;
use serde::{de::{self,Visitor,MapAccess,SeqAccess},ser::{SerializeMap,SerializeSeq},Deserializer,Serializer};
use serde_json::Value;
use std::{collections::{BTreeMap,BTreeSet},fmt};
use base64::engine::general_purpose::STANDARD;

#[derive(Serialize,Deserialize)]#[serde(deny_unknown_fields)]
pub(super)struct Carrier{version:u64,directory:String}
pub(super)struct Witness{raw:Box<[u8]>,bindings:Vec<Historical>}
struct Historical{role:Vec<u8>,eligibility:Vec<u8>,namespace:(String,String,String),record:Value,recorded:u64,prepared:(u64,u64,u64,[u8;32]),issuer:Vec<u8>,target:Vec<u8>}
struct Row{event:Value,offset:u64,length:u64,digest:[u8;32]}

// Preserve Go's actual object order for byte comparison while rejecting every
// duplicate, including in fields that are not interpreted as capabilities.
enum Ordered{Null,Bool(bool),Number(u64),String(String),Array(Vec<Ordered>),Object(Vec<(String,Ordered)>)}
impl Serialize for Ordered{fn serialize<S:Serializer>(&self,s:S)->Result<S::Ok,S::Error>{match self{
 Self::Null=>s.serialize_unit(),Self::Bool(x)=>s.serialize_bool(*x),Self::Number(x)=>s.serialize_u64(*x),Self::String(x)=>s.serialize_str(x),
 Self::Array(xs)=>{let mut seq=s.serialize_seq(Some(xs.len()))?;for x in xs{seq.serialize_element(x)?;}seq.end()},
 Self::Object(xs)=>{let mut map=s.serialize_map(Some(xs.len()))?;for(k,v)in xs{map.serialize_entry(k,v)?;}map.end()},
}}}
impl<'d>Deserialize<'d>for Ordered{fn deserialize<D:Deserializer<'d>>(d:D)->Result<Self,D::Error>{
 struct V;impl<'d>Visitor<'d>for V{type Value=Ordered;fn expecting(&self,f:&mut fmt::Formatter)->fmt::Result{f.write_str("canonical bounded Go JSON")}
 fn visit_unit<E:de::Error>(self)->Result<Ordered,E>{Ok(Ordered::Null)}
 fn visit_bool<E:de::Error>(self,x:bool)->Result<Ordered,E>{Ok(Ordered::Bool(x))}
 fn visit_u64<E:de::Error>(self,x:u64)->Result<Ordered,E>{if x>MAX{return Err(E::custom("unsafe integer"))}Ok(Ordered::Number(x))}
 fn visit_i64<E:de::Error>(self,x:i64)->Result<Ordered,E>{if x<0{return Err(E::custom("negative integer"))}self.visit_u64(x as u64)}
 fn visit_str<E:de::Error>(self,x:&str)->Result<Ordered,E>{Ok(Ordered::String(x.into()))}
 fn visit_string<E:de::Error>(self,x:String)->Result<Ordered,E>{Ok(Ordered::String(x))}
 fn visit_seq<A:SeqAccess<'d>>(self,mut a:A)->Result<Ordered,A::Error>{let mut xs=Vec::new();while let Some(x)=a.next_element()?{xs.push(x)}Ok(Ordered::Array(xs))}
 fn visit_map<A:MapAccess<'d>>(self,mut a:A)->Result<Ordered,A::Error>{let mut xs=Vec::new();let mut keys=BTreeSet::new();while let Some(k)=a.next_key::<String>()?{if !keys.insert(k.clone()){return Err(de::Error::custom("duplicate field"))}xs.push((k,a.next_value()?));}Ok(Ordered::Object(xs))}
 }d.deserialize_any(V)
}}
fn go_order(v:&Ordered)->Result<(),Error>{
 match v{
 Ordered::Array(xs)=>for x in xs{go_order(x)?;},
 Ordered::Object(xs)=>{
  let has=|key:&str|xs.iter().any(|(k,_)|k==key);
  let keys:Option<&[&str]>=if has("RecordedMS")&&has("Sequence")&&has("Record"){Some(&["GenesisBinding","AccountOperation","RecordedMS","SourceEvidence","Sequence","Previous","Kind","Record","IssuerMessage","TargetMessage","IssuerSignature","TargetSignature"])}
   else if has("Revision")&&has("Proposal")&&has("Leaf"){Some(&["Revision","Operation","Subject","Identity","Device","Generation","Attempt","Binding","Challenge","Proposal","BaseEpoch","BaseRoot","NextRoot","Leaf"])}
   else if has("Schema")&&has("Realm")&&has("Deployment")&&has("Instance"){Some(&["Schema","Realm","Deployment","Instance"])}
   else if has("operation")&&has("nonce")&&has("requestDigest"){Some(&["operation","nonce","requestDigest","issuedAtMs","expiresMs"])}
   else if has("roleRaw")&&has("eligibilityRaw"){Some(&["version","namespace","preparedEvent","roleRaw","eligibilityRaw"])}
   else if has("offset")&&has("length")&&has("digest"){Some(&["sequence","offset","length","digest"])}
   else if xs.len()==3&&has("issuer")&&has("account")&&has("clientId"){Some(&["issuer","account","clientId"])}else{None};
  if let Some(keys)=keys{let mut last=None;for(k,_)in xs{let n=keys.iter().position(|key|*key==k).ok_or(Error::Canonical)?;if last.is_some_and(|old|n<=old){return Err(Error::Canonical)}last=Some(n);}}
  for(_,x)in xs{go_order(x)?;}
 },_=>{}
 }Ok(())
}
fn json(raw:&[u8],limit:usize)->Result<Value,Error>{
 if raw.is_empty()||raw.len()>limit{return Err(Error::Bounds)}
 let ordered:Ordered=serde_json::from_slice(raw).map_err(|_|Error::Canonical)?;
 go_order(&ordered)?;
 let encoded=serde_json::to_string(&ordered).map_err(|_|Error::Canonical)?;
 let encoded=encoded.replace('&',"\\u0026").replace('<',"\\u003c").replace('>',"\\u003e").replace('\u{2028}',"\\u2028").replace('\u{2029}',"\\u2029");
 if encoded.as_bytes()!=raw{return Err(Error::Canonical)}
 serde_json::from_slice(raw).map_err(|_|Error::Canonical)
}
fn fields(v:&Value,required:&[&str],optional:&[&str])->Result<(),Error>{let m=v.as_object().ok_or(Error::Binding)?;if required.iter().any(|k|!m.contains_key(*k))||m.keys().any(|k|!required.contains(&k.as_str())&&!optional.contains(&k.as_str())){return Err(Error::Binding)}Ok(())}
fn text<'a>(v:&'a Value,k:&str,max:usize)->Result<&'a str,Error>{v[k].as_str().filter(|s|ascii(s,max)).ok_or(Error::Binding)}
fn num(v:&Value,k:&str)->Result<u64,Error>{v[k].as_u64().filter(|n|*n<=MAX).ok_or(Error::Binding)}
fn octets(v:&Value,k:&str)->Result<[u8;32],Error>{let a=v[k].as_array().ok_or(Error::Binding)?;if a.len()!=32{return Err(Error::Binding)}let mut out=[0;32];for(i,x)in a.iter().enumerate(){out[i]=x.as_u64().and_then(|n|u8::try_from(n).ok()).ok_or(Error::Binding)?;}Ok(out)}
fn standard(v:&Value,k:&str,max:usize)->Result<Vec<u8>,Error>{let s=v[k].as_str().ok_or(Error::Binding)?;if s.len()>max.div_ceil(3)*4{return Err(Error::Bounds)}let out=STANDARD.decode(s).map_err(|_|Error::Binding)?;if out.len()>max||STANDARD.encode(&out)!=s{return Err(Error::Binding)}Ok(out)}
fn sha(raw:&[u8])->[u8;32]{Sha256::digest(raw).into()}
fn hex(raw:&[u8])->String{raw.iter().map(|b|format!("{b:02x}")).collect()}
fn namespace(v:&Value)->Result<(String,String,String),Error>{fields(v,&["issuer","account","clientId"],&[])?;Ok((text(v,"issuer",512)?.into(),text(v,"account",1024)?.into(),text(v,"clientId",128)?.into()))}
fn frame(domain:&str,fields:&[&[u8]])->Vec<u8>{let mut out=domain.as_bytes().to_vec();out.push(0);for f in fields{out.extend((f.len()as u32).to_be_bytes());out.extend(*f);}out}
fn ypa(kind:u8,fields:&[&[u8]])->Vec<u8>{let mut out=vec![b'Y',b'P',b'A',b'1',kind,1,0,fields.len()as u8];for(i,f)in fields.iter().enumerate(){out.extend(((i+1)as u16).to_be_bytes());out.extend((f.len()as u32).to_be_bytes());out.extend(*f);}out}
fn messages(record:&Value,realm:&str,route:&str)->Result<(Vec<u8>,Vec<u8>),Error>{
 let p=standard(record,"Proposal",2657)?;let op=text(record,"Operation",128)?;
 if p.len()!=2657||p[0]!=5||op!=format!("fd1-{}",B64.encode(&p[2625..])){return Err(Error::Binding)}
 let identity=text(record,"Identity",128)?;let device=text(record,"Device",128)?;
 let leaf=standard(record,"Leaf",65536)?;let one=1u64.to_be_bytes();let base=num(record,"BaseEpoch")?;if base==0||base>=MAX{return Err(Error::Binding)}
 let be=base.to_be_bytes();let next=(base+1).to_be_bytes();let root=octets(record,"BaseRoot")?;let nr=octets(record,"NextRoot")?;
 let expected_leaf=frame("YNX/SOCIAL/FIRST-LEAF/V1",&[identity.as_bytes(),device.as_bytes(),&p[..33],&p[33..2625],&one,&one,route.as_bytes()]);if leaf!=expected_leaf{return Err(Error::Binding)}
 let grant=sha(&frame("YNX/SOCIAL/FIRST-DEVICE-REFERENCE/V1",&[&leaf]));
 let principal=ypa(1,&[identity.as_bytes(),device.as_bytes(),b"LIBSIGNAL-0.104.0-XEDDSA-CANDIDATE",&p[..33],b"ML-DSA-87",&p[33..2625],&one,&one,&next,&nr,&grant,route.as_bytes()]);
 let challenge=&record["Challenge"];fields(challenge,&["operation","nonce","requestDigest","issuedAtMs","expiresMs"],&[])?;
 let nonce=octets(challenge,"nonce")?;let issued=num(challenge,"issuedAtMs")?;let expires=num(challenge,"expiresMs")?;
 if text(challenge,"operation",128)?!=op||octets(challenge,"requestDigest")?!=sha(&p)||nonce==[0;32]||expires<=issued||expires-issued>120000{return Err(Error::Binding)}
 let im=issued.to_be_bytes();let ex=expires.to_be_bytes();let active=frame("YNX/SOCIAL/FIRST-ACTIVE-DEVICE/V1",&[&leaf]);
 let transcript=ypa(3,&[b"YNX-SOCIAL",realm.as_bytes(),&one,b"enroll",&principal,&principal,&root,&nr,&be,&next,&nonce,&im,&ex,&nonce,&active,&[]]);
 Ok((ypa(4,&[b"YNX/SOCIAL/PQ-AUTH/SIGN/V1",b"authorization",b"issuer",&transcript]),ypa(4,&[b"YNX/SOCIAL/PQ-AUTH/SIGN/V1",b"possession",b"target",&transcript])))
}
fn record_shape(r:&Value)->Result<(),Error>{fields(r,&["Revision","Operation","Subject","Identity","Device","Generation","Attempt","Binding","Challenge","Proposal","BaseEpoch","BaseRoot","NextRoot","Leaf"],&[])?;if num(r,"Revision")?==0{return Err(Error::Binding)}for k in ["Operation","Identity","Device"]{text(r,k,128)?;}Ok(())}
#[derive(Clone,PartialEq,Eq)]struct Original{operation:String,revision:u64,proposal:String,issuer:String,target:String,association:String}
#[derive(Default)]struct Fold{sequence:u64,state:String,ever:bool,original:Option<Original>,used:BTreeSet<String>,head:[u8;32]}
#[derive(Serialize)]#[serde(rename_all="camelCase")]
struct Lifecycle<'a>{schema:&'static str,version:u64,sequence:u64,previous:u64,namespace:LifecycleNamespace<'a>,kind:&'a str,operation:&'a str,revision:u64,proposal:&'a str,issuer_message:&'a str,target_message:&'a str,association:&'a str}
#[derive(Serialize)]#[serde(rename_all="camelCase")]struct LifecycleNamespace<'a>{issuer:&'a str,account:&'a str,client_id:&'a str}
fn advance(f:&mut Fold,o:Original,kind:&str,ns:&(String,String,String))->Result<Vec<u8>,Error>{
 let same=f.original.as_ref()==Some(&o);let next=f.sequence.checked_add(1).filter(|n|*n<=MAX).ok_or(Error::Binding)?;
 if [&o.proposal,&o.issuer,&o.target,&o.association].iter().any(|s|!digest(s)||s.bytes().all(|b|b==b'0')){return Err(Error::Binding)}
 match kind{
 "prepare"=>{if f.used.len()>=64||f.used.contains(&o.operation)||f.ever||!f.state.is_empty()||o.revision!=1{return Err(Error::Binding)}f.used.insert(o.operation.clone());f.state="pending".into();},
 "rebase"=>{let old=f.original.as_ref().ok_or(Error::Binding)?;if f.state!="pending"||f.ever||old.revision>=MAX||o.operation!=old.operation||o.revision!=old.revision+1||o.proposal!=old.proposal||o.association!=old.association||o.issuer==old.issuer||o.target==old.target{return Err(Error::Binding)}},
 "commit"=>{if !same||f.ever||f.state!="pending"{return Err(Error::Binding)}f.state="committed".into();f.ever=true;},
 "cancel"=>{if !same||f.ever||f.state!="pending"{return Err(Error::Binding)}f.state="cancel-requested".into();},
 _=>return Err(Error::Binding),
 }
 let wire=Lifecycle{schema:"YNX-SOCIAL-GENESIS-LIFECYCLE-V2",version:2,sequence:next,previous:f.sequence,namespace:LifecycleNamespace{issuer:&ns.0,account:&ns.1,client_id:&ns.2},kind,operation:&o.operation,revision:o.revision,proposal:&o.proposal,issuer_message:&o.issuer,target_message:&o.target,association:&o.association};
 let raw=serde_json::to_vec(&wire).map_err(|_|Error::Canonical)?;if raw.len()>4096{return Err(Error::Bounds)}f.sequence=next;f.original=Some(o);Ok(raw)
}

pub(super)fn verify(c:&Carrier,b:&Body,route:&str)->Result<Witness,Error>{
 if c.version!=1||!ascii(route,256){return Err(Error::Binding)}
 let raw=decode(&c.directory,1,64*1024*1024)?;
 let cp=serde_json::to_value(&b.checkpoint).map_err(|_|Error::Canonical)?;
 if raw.len()as u64!=num(&cp,"bytes")?||!raw.ends_with(b"\n"){return Err(Error::Binding)}
 let mut lines=raw.split_inclusive(|x|*x==b'\n');let header_line=lines.next().ok_or(Error::Binding)?;
 if header_line.len()>4096||hex(&sha(header_line))!=text(&cp,"headerSHA256",64)?{return Err(Error::Binding)}
 let header=json(&header_line[..header_line.len()-1],4095)?;fields(&header,&["Schema","Realm","Deployment","Instance"],&[])?;
 if text(&header,"Schema",128)?!="YNX-SOCIAL-FIRST-DIRECTORY-V3"||text(&header,"Realm",128)?!=b.realm||text(&header,"Deployment",512)?!=text(&cp,"deployment",512)?||text(&header,"Instance",512)?!=text(&cp,"instance",512)?{return Err(Error::Binding)}
 let mut previous=sha(header_line);let mut offset=header_line.len()as u64;let mut rows=Vec::new();
 for line in lines{
  if line.len()>512*1024||!line.ends_with(b"\n")||rows.len()>=4096{return Err(Error::Bounds)}
  let event=json(&line[..line.len()-1],512*1024-1)?;
  fields(&event,&["RecordedMS","SourceEvidence","Sequence","Previous","Kind","Record","IssuerMessage","TargetMessage","IssuerSignature","TargetSignature"],&["GenesisBinding","AccountOperation"])?;
  if num(&event,"Sequence")?!=rows.len()as u64+1||octets(&event,"Previous")?!=previous||num(&event,"RecordedMS")?==0{return Err(Error::Binding)}
  record_shape(&event["Record"])?;
  let source=&event["SourceEvidence"];fields(source,&["Registration","History","Scope","Catalog"],&[])?;
  if source["Scope"]!=serde_json::to_value(&b.scope).map_err(|_|Error::Canonical)?{return Err(Error::Binding)}
  previous=sha(line);rows.push(Row{event,offset,length:line.len()as u64,digest:previous});offset+=line.len()as u64;
 }
 if offset!=num(&cp,"bytes")?||rows.len()as u64!=num(&cp,"sequence")?||hex(&previous)!=text(&cp,"head",64)?{return Err(Error::Binding)}
 let mut bindings=BTreeMap::<String,Historical>::new();
 for(index,row)in rows.iter().enumerate(){if row.event["Kind"]!="genesis-account-bound-v1"{continue}
  let binding=&row.event["GenesisBinding"];fields(binding,&["version","namespace","preparedEvent","roleRaw","eligibilityRaw"],&[])?;
  if num(binding,"version")?!=1{return Err(Error::Binding)}
  let record=&row.event["Record"];let operation=text(record,"Operation",128)?.to_owned();
  if bindings.contains_key(&operation){return Err(Error::Binding)}
  let mut selected=None;for old in &rows[..index]{if old.event["Record"]["Operation"]!=operation{continue}match old.event["Kind"].as_str(){Some("prepared"|"rebased")=>selected=Some(old),Some("committed"|"canceled"|"challenge-canceled")=>return Err(Error::Binding),_=>{}}}
  let selected=selected.ok_or(Error::Binding)?;let extent=&binding["preparedEvent"];fields(extent,&["sequence","offset","length","digest"],&[])?;
  if selected.event["Record"]!=*record||num(extent,"sequence")?!=num(&selected.event,"Sequence")?||num(extent,"offset")?!=selected.offset||num(extent,"length")?!=selected.length||text(extent,"digest",64)?!=hex(&selected.digest){return Err(Error::Binding)}
  let(issuer,target)=messages(record,&b.realm,route)?;
  bindings.insert(operation,Historical{namespace:namespace(&binding["namespace"])?,role:standard(binding,"roleRaw",8192)?,eligibility:standard(binding,"eligibilityRaw",8192)?,record:record.clone(),recorded:num(&row.event,"RecordedMS")?,prepared:(num(&selected.event,"Sequence")?,selected.offset,selected.length,selected.digest),issuer,target});
 }
 let mut folds=BTreeMap::<(String,String,String),Fold>::new();
 for row in &rows{
  let record=&row.event["Record"];let op=text(record,"Operation",128)?;let binding=bindings.get(op).ok_or(Error::Binding)?;
  let eligibility=json(&binding.eligibility,8192)?;let association=text(&eligibility,"associationCommitment",64)?;
  let f=folds.entry(binding.namespace.clone()).or_default();let kind=match text(&row.event,"Kind",64)?{"prepared"=>"prepare","rebased"=>"rebase","committed"=>"commit","canceled"=>"cancel","account-prepared"|"account-selected"|"account-bound"|"genesis-account-bound-v1"=>"",_=>return Err(Error::Binding)};
  let mut lifecycle=Vec::new();
  if !kind.is_empty(){let(im,tm)=messages(record,&b.realm,route)?;let proposal=standard(record,"Proposal",2657)?;
   let o=Original{operation:op.into(),revision:num(record,"Revision")?,proposal:hex(&sha(&proposal)),issuer:hash(b"YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_ISSUER_V1\n",&im),target:hash(b"YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_TARGET_V1\n",&tm),association:association.into()};lifecycle=advance(f,o,kind,&binding.namespace)?;
  }
  if row.event["Kind"]=="genesis-account-bound-v1"&&(f.state!="pending"||f.original.as_ref().is_none_or(|o|o.operation!=op)){return Err(Error::Binding)}
  let mut h=Sha256::new();h.update(b"YNX/SOCIAL/GENESIS-NAMESPACE-HISTORY/V1\0");h.update(f.head);for n in [num(&row.event,"Sequence")?,row.offset,row.length]{h.update(n.to_be_bytes());}h.update(row.digest);h.update((lifecycle.len()as u32).to_be_bytes());h.update(&lifecycle);f.head=h.finalize().into();
 }
 let ns=(b.namespace.issuer.clone(),b.namespace.account.clone(),b.namespace.client_id.clone());let f=folds.get(&ns).ok_or(Error::Binding)?;
 if f.state!="pending"||f.ever||f.sequence!=b.lifecycle.sequence||hex(&f.head)!=b.lifecycle.head_digest||f.original.as_ref().is_none_or(|o|o.operation!=b.operation||o.revision!=b.prepared_revision||o.proposal!=b.proposal_digest||o.issuer!=b.issuer_type4_digest||o.target!=b.target_type4_digest||o.association!=b.association_commitment){return Err(Error::Binding)}
 let current=bindings.get(&b.operation).ok_or(Error::Binding)?;if current.namespace!=ns||sha(&current.eligibility)!=decode_hex(&b.eligibility_digest)?{return Err(Error::Binding)}
 let selected=rows.iter().find(|r|num(&r.event,"Sequence").ok()==Some(b.prepared_event.sequence)).ok_or(Error::Binding)?;
 if !matches!(selected.event["Kind"].as_str(),Some("prepared"|"rebased"))||current.prepared!=(b.prepared_event.sequence,b.prepared_event.offset,b.prepared_event.length,decode_hex(&b.prepared_event.digest)?)||selected.offset!=b.prepared_event.offset||selected.length!=b.prepared_event.length||hex(&selected.digest)!=b.prepared_event.digest||selected.event["Record"]!=current.record||text(&current.record,"Identity",128)?!=b.identity||text(&current.record,"Device",128)?!=b.device||num(&current.record,"BaseEpoch")?!=b.base_epoch||hex(&octets(&current.record,"BaseRoot")?)!=b.base_root||hex(&octets(&current.record,"NextRoot")?)!=b.next_root{return Err(Error::Binding)}
 Ok(Witness{raw:raw.into_boxed_slice(),bindings:bindings.into_values().collect()})
}
fn decode_hex(s:&str)->Result<[u8;32],Error>{if !digest(s){return Err(Error::Binding)}let mut out=[0;32];for(i,x)in out.iter_mut().enumerate(){*x=u8::from_str_radix(&s[i*2..i*2+2],16).map_err(|_|Error::Binding)?;}Ok(out)}
impl Witness{
 pub(super)fn verify_historical(&self,account:&crate::account_evidence::UnadmittedAccountEvidence)->Result<(),Error>{
  for b in &self.bindings{let challenge=&b.record["Challenge"];let nonce=B64.encode(octets(challenge,"nonce")?);let proposal=standard(&b.record,"Proposal",2657)?;
   let original=crate::account_evidence::HistoricalAccountRecord{issuer:&b.namespace.0,account:&b.namespace.1,client:&b.namespace.2,operation:text(&b.record,"Operation",128)?,identity:text(&b.record,"Identity",128)?,device:text(&b.record,"Device",128)?,revision:num(&b.record,"Revision")?,challenge_nonce:&nonce,challenge_issued:num(challenge,"issuedAtMs")?,challenge_expires:num(challenge,"expiresMs")?,proposal:&proposal,issuer_message:&b.issuer,target_message:&b.target,recorded:b.recorded};
   account.verify_namespace_historical(&b.role,&b.eligibility,&original).map_err(|_|Error::Binding)?;
  }Ok(())
 }
 pub(super)fn raw(&self)->&[u8]{&self.raw}
}

#[cfg(test)]mod receiver_controls{
 use super::*;
 fn original(revision:u64)->Original{Original{operation:"fd1-original".into(),revision,proposal:"11".repeat(32),issuer:format!("{revision:064x}"),target:format!("{:064x}",revision+64),association:"22".repeat(32)}}
 fn ns()->(String,String,String){("issuer".into(),"account".into(),"client".into())}
 #[test]fn raw_json_rejects_duplicate_whitespace_and_fraction(){
  assert!(json(br#"{"a":1,"a":2}"#,1024).is_err());
  assert!(json(br#"{ "a":1}"#,1024).is_err());
  assert!(json(br#"{"a":1.0}"#,1024).is_err());
  assert!(json(br#"{"a":9007199254740992}"#,1024).is_err());
  assert!(json(br#"{"a":1}"#,1024).is_ok());
 }
 #[test]fn raw_header_requires_original_go_field_order(){
  assert!(json(br#"{"Schema":"schema","Realm":"realm","Deployment":"deployment","Instance":"instance"}"#,4095).is_ok());
  assert!(json(br#"{"Realm":"realm","Schema":"schema","Deployment":"deployment","Instance":"instance"}"#,4095).is_err());
 }
 #[test]fn directory_carrier_does_not_accept_padding_or_extra_fields(){
  let wire:Carrier=serde_json::from_slice(br#"{"version":1,"directory":"e30K"}"#).unwrap();
  assert_eq!(decode(&wire.directory,1,64).unwrap(),b"{}\n");
  assert!(decode("e30K=",1,64).is_err());
  assert!(serde_json::from_slice::<Carrier>(br#"{"version":1,"directory":"e30K","verified":true}"#).is_err());
 }
 #[test]fn committed_history_cannot_become_pending_again(){
  let mut f=Fold::default();let o=original(1);advance(&mut f,o.clone(),"prepare",&ns()).unwrap();
  advance(&mut f,o,"commit",&ns()).unwrap();assert!(f.ever);assert_eq!(f.state,"committed");
  assert!(advance(&mut f,original(1),"prepare",&ns()).is_err());
  assert!(advance(&mut f,original(2),"rebase",&ns()).is_err());
 }
 #[test]fn cancelled_history_cannot_be_replayed_or_rebased(){
  let mut f=Fold::default();let o=original(1);advance(&mut f,o.clone(),"prepare",&ns()).unwrap();
  advance(&mut f,o,"cancel",&ns()).unwrap();assert!(!f.ever);assert_eq!(f.state,"cancel-requested");
  assert!(advance(&mut f,original(1),"prepare",&ns()).is_err());assert!(advance(&mut f,original(2),"rebase",&ns()).is_err());
 }
 #[test]fn rebase_requires_same_operation_and_next_revision(){
  let mut f=Fold::default();advance(&mut f,original(1),"prepare",&ns()).unwrap();
  let mut foreign=original(2);foreign.operation="fd1-other".into();assert!(advance(&mut f,foreign,"rebase",&ns()).is_err());
  assert!(advance(&mut f,original(3),"rebase",&ns()).is_err());
  advance(&mut f,original(2),"rebase",&ns()).unwrap();assert_eq!(f.sequence,2);assert_eq!(f.state,"pending");
 }
}
