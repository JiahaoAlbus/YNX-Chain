use super::*;
use futures_util::FutureExt;
use libsignal_protocol::*;
use rand::{rngs::OsRng,TryRngCore as _};
use spqr::ynx_observer::{Provenance,QaSessionLedger};
use std::{fs,io::Write,path::PathBuf,sync::atomic::{AtomicU64,Ordering},time::SystemTime};
#[path="upstream_test_support.rs"] mod upstream;
static NEXT_OWNER:AtomicU64=AtomicU64::new(1);
#[derive(Clone,Copy)] enum Fault { None,BeforeCommit,AfterRenameUnknown,RevokeBeforeCommit }
// Synchronous diagnostics ONLY: never a protected capability producer (R2/R3).
struct BoundDiagnostic {
    owner:u64,incarnation:u64,expected_record:Vec<u8>,ledger:QaSessionLedger,
}
struct Node {
    core:Core,store:InMemSignalProtocolStore,local:ProtocolAddress,remote:ProtocolAddress,
    local_pin:Vec<u8>,peer_pin:Vec<u8>,local_registration:u32,peer_registration:u32,
    address_pin:(ProtocolAddress,ProtocolAddress),incarnation:u64,restored:bool,
    diagnostic:BoundDiagnostic,directory:PathBuf,pending:Option<(u64,Vec<u8>)>,
}
struct Outcome { bytes:Vec<u8>,fresh:bool,epoch:Option<u64>,operation:u64 }
impl Drop for Node { fn drop(&mut self) {let _=fs::remove_dir_all(&self.directory);} }
impl Node {
    fn fixture(store:InMemSignalProtocolStore,local:ProtocolAddress,remote:ProtocolAddress,peer_pin:Vec<u8>,peer_registration:u32)->Self {
        let owner=NEXT_OWNER.fetch_add(1,Ordering::SeqCst);
        let local_pair=store.get_identity_key_pair().now_or_never().expect("sync").expect("identity");
        let local_pin=local_pair.identity_key().serialize().to_vec();
        let local_registration=store.get_local_registration_id().now_or_never().expect("sync").expect("registration");
        let record=store.load_session(&remote).now_or_never().expect("sync").expect("load").expect("session");
        let expected_record=record.serialize().expect("serialize");
        let directory=PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../../../test-state-r2").join(format!("{}-{owner}",std::process::id()));
        fs::create_dir_all(&directory).unwrap();
        #[cfg(unix)] {use std::os::unix::fs::PermissionsExt;fs::set_permissions(&directory,fs::Permissions::from_mode(0o700)).unwrap();}
        let n=Self {core:Core {owner,next_slot:0,published_operation:None,current:Binding {session:owner,state_generation:0,operation:0,context:19,route:31,device_authorization:1,checkpoint:0},revoked:false,unknown:false,capabilities:BTreeMap::new()},store,local:local.clone(),remote:remote.clone(),local_pin,peer_pin,local_registration,peer_registration,address_pin:(local,remote),incarnation:owner,restored:false,diagnostic:BoundDiagnostic {owner,incarnation:owner,expected_record,ledger:QaSessionLedger::default()},directory,pending:None};
        n.check().expect("both store/session identity pins and registrations match");n
    }
    fn state(&self)->Vec<u8> {self.store.load_session(&self.remote).now_or_never().unwrap().unwrap().unwrap().serialize().unwrap()}
    fn check(&self)->Result<(),OperationError> {
        if self.core.revoked{return Err(OperationError::Revoked)}
        if self.core.unknown{return Err(OperationError::Unknown)}
        if self.restored{return Err(OperationError::Unproven)}
        if self.local!=self.address_pin.0 || self.remote!=self.address_pin.1{return Err(OperationError::Binding)}
        let pair=self.store.get_identity_key_pair().now_or_never().unwrap().map_err(|_|OperationError::Binding)?;
        let reg=self.store.get_local_registration_id().now_or_never().unwrap().map_err(|_|OperationError::Binding)?;
        let record=self.store.load_session(&self.remote).now_or_never().unwrap().map_err(|_|OperationError::Binding)?.ok_or(OperationError::Binding)?;
        if record.diagnostic_has_previous_sessions(){return Err(OperationError::Unproven)}
        if pair.identity_key().serialize().as_ref()!=self.local_pin.as_slice() || reg!=self.local_registration
          || record.local_identity_key_bytes().map_err(|_|OperationError::Binding)?!=self.local_pin
          || record.remote_identity_key_bytes().map_err(|_|OperationError::Binding)?.as_deref()!=Some(self.peer_pin.as_slice())
          || record.local_registration_id().map_err(|_|OperationError::Binding)?!=self.local_registration
          || record.remote_registration_id().map_err(|_|OperationError::Binding)?!=self.peer_registration
          || self.diagnostic.owner!=self.core.owner || self.diagnostic.incarnation!=self.incarnation
          || record.serialize().map_err(|_|OperationError::Binding)?!=self.diagnostic.expected_record {return Err(OperationError::Binding)}
        Ok(())
    }
    fn send(&mut self,clear:&str,fault:Fault)->Result<Outcome,OperationError>{self.operation(None,clear,fault)}
    fn receive(&mut self,wire:&[u8],fault:Fault)->Result<Outcome,OperationError>{self.operation(Some(wire),"",fault)}
    fn operation(&mut self,input:Option<&[u8]>,clear:&str,fault:Fault)->Result<Outcome,OperationError>{
        self.check()?;
        let before=self.store.load_session(&self.remote).now_or_never().unwrap().unwrap().unwrap();
        let next=Binding {state_generation:self.core.current.state_generation+1,operation:self.core.current.operation+1,checkpoint:self.core.current.checkpoint+1,..self.core.current};
        let (store,core,pending)=(&mut self.store,&mut self.core,&mut self.pending);
        let (local,remote,directory)=(&self.local,&self.remote,&self.directory);
        let local_pin=&self.local_pin;let peer_pin=&self.peer_pin;
        let local_registration=self.local_registration;let peer_registration=self.peer_registration;
        let (result,observation)=self.diagnostic.ledger.operation(||{
            let (bytes,wire)=if let Some(w)=input {
                let msg=CiphertextMessage::SignalMessage(SignalMessage::try_from(w).map_err(|_|OperationError::Authentication)?);
                (upstream::decrypt(store,remote,local,&msg).now_or_never().unwrap().map_err(|_|OperationError::Authentication)?,w.to_vec())
            }else{let msg=upstream::encrypt(store,remote,local,clear).now_or_never().unwrap().map_err(|_|OperationError::Crypto)?;let w=msg.serialize().to_vec();(w.clone(),w)};
            let record=store.load_session(remote).now_or_never().unwrap().map_err(|_|OperationError::Binding)?.ok_or(OperationError::Binding)?;
            let current_identity=store.get_identity_key_pair().now_or_never().unwrap().map_err(|_|OperationError::Binding)?;
            let current_registration=store.get_local_registration_id().now_or_never().unwrap().map_err(|_|OperationError::Binding)?;
            if current_identity.identity_key().serialize().as_ref()!=local_pin.as_slice() || current_registration!=local_registration {return Err(OperationError::Binding)}
            if record.diagnostic_has_previous_sessions() || record.local_identity_key_bytes().map_err(|_|OperationError::Binding)?!=*local_pin
              || record.remote_identity_key_bytes().map_err(|_|OperationError::Binding)?.as_deref()!=Some(peer_pin.as_slice())
              || record.local_registration_id().map_err(|_|OperationError::Binding)?!=local_registration
              || record.remote_registration_id().map_err(|_|OperationError::Binding)?!=peer_registration {return Err(OperationError::Binding)}
            if matches!(fault,Fault::RevokeBeforeCommit){core.revoked=true;core.invalidate();}
            if core.revoked || matches!(fault,Fault::BeforeCommit){
                if matches!(fault,Fault::BeforeCommit){assert!(fs::OpenOptions::new().write(true).create_new(true).open(directory.join("missing-parent/checkpoint")).is_err());}
                store.store_session(remote,&before).now_or_never().unwrap().map_err(|_|OperationError::Crypto)?;
                return Err(if core.revoked{OperationError::Revoked}else{OperationError::CommitFailed})
            }
            let serialized=record.serialize().map_err(|_|OperationError::Crypto)?;
            let mut options=fs::OpenOptions::new();options.write(true).create_new(true);
            #[cfg(unix)]{use std::os::unix::fs::OpenOptionsExt;options.mode(0o600);}
            // Raw secret state only in cfg(test), private owned fixture, removed on Drop.
            let persisted=(||->std::io::Result<()>{let mut f=options.open(directory.join("candidate.tmp"))?;
                for v in [next.session,next.state_generation,next.operation,next.context,next.route,next.device_authorization,next.checkpoint,serialized.len() as u64,wire.len() as u64]{f.write_all(&v.to_le_bytes())?;}
                f.write_all(&serialized)?;f.write_all(&wire)?;f.sync_all()?;fs::rename(directory.join("candidate.tmp"),directory.join("checkpoint"))?;Ok(())})();
            if persisted.is_err() || matches!(fault,Fault::AfterRenameUnknown) || fs::File::open(directory).and_then(|f|f.sync_all()).is_err(){core.unknown=true;core.invalidate();*pending=Some((next.operation,wire));return Err(OperationError::Unknown)}
            core.current=next;core.invalidate();Ok(bytes)
        });
        let bytes=result?;
        self.diagnostic.expected_record=self.state();
        self.check()?; // load/commit identity, registration, address and lineage guard.
        let fresh=observation.as_ref().is_some_and(|o|o.contribution_consumed&&o.authenticated&&matches!(o.provenance,Provenance::FreshInThisOperation|Provenance::FreshFromObservedOperation));
        let epoch=observation.and_then(|o|o.diagnostic_selected_epoch());
        // R2/R3: diagnostics NEVER construct VerifiedFresh/opaque protected capabilities.
        assert!(self.core.capabilities.is_empty());
        Ok(Outcome {bytes,fresh,epoch,operation:next.operation})
    }
    fn restore_file(&mut self,retain_ledger:bool){
        let data=fs::read(self.directory.join("checkpoint")).unwrap();let len=u64::from_le_bytes(data[56..64].try_into().unwrap()) as usize;
        let record=SessionRecord::deserialize(&data[72..72+len]).unwrap();
        self.store.store_session(&self.remote,&record).now_or_never().unwrap().unwrap();
        self.incarnation=NEXT_OWNER.fetch_add(1,Ordering::SeqCst);self.core.invalidate();self.restored=true;
        if !retain_ledger {self.diagnostic=BoundDiagnostic {owner:self.core.owner,incarnation:self.incarnation,expected_record:self.state(),ledger:QaSessionLedger::default()};}
    }
    fn retry_unknown(&self,op:u64)->Result<Vec<u8>,OperationError>{if self.core.revoked{return Err(OperationError::Revoked)}if !self.core.unknown{return Err(OperationError::Binding)}let(id,w)=self.pending.as_ref().ok_or(OperationError::Unknown)?;if *id!=op{return Err(OperationError::Binding)}Ok(w.clone())}
}
fn pair()->(Node,Node){
    let mut a=upstream::test_in_memory_protocol_store().unwrap();let mut b=upstream::test_in_memory_protocol_store().unwrap();let mut rng=OsRng.unwrap_err();
    let bundle=upstream::create_pre_key_bundle(&mut b,&mut rng).now_or_never().unwrap().unwrap();
    let alice=ProtocolAddress::new("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa".into(),DeviceId::new(1).unwrap());
    let bob=ProtocolAddress::new("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb".into(),bundle.device_id().expect("valid actual bundle device"));
    process_prekey_bundle(&bob,&alice,&mut a.session_store,&mut a.identity_store,&bundle,SystemTime::now(),&mut rng).now_or_never().unwrap().unwrap();
    let initial=upstream::encrypt(&mut a,&bob,&alice,"establish").now_or_never().unwrap().unwrap();
    let wrong_local=ProtocolAddress::new(bob.name().into(),DeviceId::new(if u8::from(bob.device_id())==1{2}else{1}).unwrap());
    assert!(upstream::decrypt(&mut b,&alice,&wrong_local,&initial).now_or_never().unwrap().is_err(),"actual ServiceId recipient device field rejects mismatch");
    let wrong_sender=ProtocolAddress::new("cccccccc-cccc-4ccc-8ccc-cccccccccccc".into(),alice.device_id());
    assert!(upstream::decrypt(&mut b,&wrong_sender,&bob,&initial).now_or_never().unwrap().is_err(),"actual ServiceId sender field rejects mismatch");
    let wrong_sender_device=ProtocolAddress::new(alice.name().into(),DeviceId::new(2).unwrap());
    assert!(upstream::decrypt(&mut b,&wrong_sender_device,&bob,&initial).now_or_never().unwrap().is_err(),"actual sender device field rejects mismatch");
    let wrong_recipient=ProtocolAddress::new("dddddddd-dddd-4ddd-8ddd-dddddddddddd".into(),bob.device_id());
    assert!(upstream::decrypt(&mut b,&alice,&wrong_recipient,&initial).now_or_never().unwrap().is_err(),"actual recipient ServiceId field rejects mismatch");
    assert_eq!(upstream::decrypt(&mut b,&alice,&bob,&initial).now_or_never().unwrap().unwrap(),b"establish");
    let reply=upstream::encrypt(&mut b,&alice,&bob,"ready").now_or_never().unwrap().unwrap();
    assert_eq!(upstream::decrypt(&mut a,&bob,&alice,&reply).now_or_never().unwrap().unwrap(),b"ready");
    let ap=a.get_identity_key_pair().now_or_never().unwrap().unwrap().identity_key().serialize().to_vec();let bp=b.get_identity_key_pair().now_or_never().unwrap().unwrap().identity_key().serialize().to_vec();
    let ar=a.get_local_registration_id().now_or_never().unwrap().unwrap();let br=b.get_local_registration_id().now_or_never().unwrap().unwrap();
    (Node::fixture(a,alice.clone(),bob.clone(),bp,br),Node::fixture(b,bob,alice,ap,ar))
}
fn warm(a:&mut Node,b:&mut Node)->[usize;4]{let mut counts=[0;4];for _ in 0..160{
    let sent=a.send("new core",Fault::None).unwrap();counts[0]+=usize::from(sent.fresh);
    let received=b.receive(&sent.bytes,Fault::None).unwrap();assert_eq!(received.bytes,b"new core");counts[1]+=usize::from(received.fresh);
    let sent=b.send("reply",Fault::None).unwrap();counts[2]+=usize::from(sent.fresh);
    let received=a.receive(&sent.bytes,Fault::None).unwrap();assert_eq!(received.bytes,b"reply");counts[3]+=usize::from(received.fresh);
}assert!(counts.iter().all(|c|*c>0),"each sender AND receiver direction observed matched actual contribution lineage");counts}
#[test]fn real_service_id_store_identity_and_four_directions(){let(mut a,mut b)=pair();warm(&mut a,&mut b);assert!(a.core.capabilities.is_empty()&&b.core.capabilities.is_empty());}
#[test]fn foreign_store_session_same_epoch_replacement_and_previous_reject(){
    let(mut a,mut b)=pair();let(mut c,mut d)=pair();warm(&mut a,&mut b);warm(&mut c,&mut d);
    let sent=a.send("epoch A",Fault::None).unwrap();let _=b.receive(&sent.bytes,Fault::None).unwrap();let sent_c=c.send("epoch B",Fault::None).unwrap();let _=d.receive(&sent_c.bytes,Fault::None).unwrap();assert_eq!(sent.epoch,sent_c.epoch);
    std::mem::swap(&mut a.diagnostic,&mut c.diagnostic);assert!(matches!(c.send("borrow ledger",Fault::None),Err(OperationError::Binding)));std::mem::swap(&mut a.diagnostic,&mut c.diagnostic);
    let foreign=c.store.load_session(&c.remote).now_or_never().unwrap().unwrap().unwrap();a.store.store_session(&a.remote,&foreign).now_or_never().unwrap().unwrap();assert!(matches!(a.send("foreign record",Fault::None),Err(OperationError::Binding)));
    let(mut e,mut f)=pair();let earlier=SessionRecord::deserialize(&e.state()).unwrap();warm(&mut e,&mut f);e.store.store_session(&e.remote,&earlier).now_or_never().unwrap().unwrap();assert!(matches!(e.send("same identity replacement",Fault::None),Err(OperationError::Binding)));
    let(mut e,mut f)=pair();warm(&mut e,&mut f);let mut previous=e.store.load_session(&e.remote).now_or_never().unwrap().unwrap().unwrap();previous.archive_current_state().unwrap();e.store.store_session(&e.remote,&previous).now_or_never().unwrap().unwrap();assert!(matches!(e.send("previous",Fault::None),Err(OperationError::Unproven)));
}
#[test]fn actual_mac_commit_revoke_and_unknown_guards(){let(mut a,mut b)=pair();warm(&mut a,&mut b);
    let sent=a.send("authenticated",Fault::None).unwrap();let before=b.state();let mut bad=sent.bytes.clone();*bad.last_mut().unwrap()^=1;assert!(matches!(b.receive(&bad,Fault::None),Err(OperationError::Authentication)));assert!(before==b.state());
    assert!(matches!(b.receive(&sent.bytes,Fault::BeforeCommit),Err(OperationError::CommitFailed)));assert!(before==b.state());assert_eq!(b.receive(&sent.bytes,Fault::None).unwrap().bytes,b"authenticated");assert!(b.receive(&sent.bytes,Fault::None).is_err());
    assert!(matches!(a.send("unknown",Fault::AfterRenameUnknown),Err(OperationError::Unknown)));let op=a.pending.as_ref().unwrap().0;let original=a.retry_unknown(op).unwrap();let state=a.state();assert!(a.retry_unknown(op).unwrap()==original);assert!(a.state()==state);assert!(matches!(a.send("new cipher",Fault::None),Err(OperationError::Unknown)));assert_eq!(b.receive(&original,Fault::None).unwrap().bytes,b"unknown");a.core.revoked=true;assert_eq!(a.retry_unknown(op),Err(OperationError::Revoked));
}
#[test]fn real_durable_record_restore_retained_empty_and_ooo(){let(mut a,mut b)=pair();warm(&mut a,&mut b);
    let first=a.send("first",Fault::None).unwrap();let second=a.send("second",Fault::None).unwrap();assert_eq!(b.receive(&second.bytes,Fault::None).unwrap().bytes,b"second");assert_eq!(b.receive(&first.bytes,Fault::None).unwrap().bytes,b"first");
    a.restore_file(true);assert!(matches!(a.send("retained",Fault::None),Err(OperationError::Unproven)));
    b.restore_file(false);assert!(matches!(b.receive(&first.bytes,Fault::None),Err(OperationError::Unproven)));
}
#[test]fn ordinary_optional_address_never_becomes_protected_admission(){let(mut a,mut b)=pair();warm(&mut a,&mut b);let sent=a.send("ordinary optional address",Fault::None).unwrap();assert!(!SignalMessage::try_from(sent.bytes.as_slice()).unwrap().diagnostic_has_authenticated_addresses(),"actual ordinary wire has no authenticated address field");assert!(a.core.capabilities.is_empty());b.local=ProtocolAddress::new(b.local.name().into(),DeviceId::new(if u8::from(b.local.device_id())==1{2}else{1}).unwrap());assert!(matches!(b.receive(&sent.bytes,Fault::None),Err(OperationError::Binding)));assert!(matches!(open_production(),Err(OperationError::Required(_))));}

#[path="affine_protocol_tests.rs"] mod affine_protocol_tests;

#[path="selected_key_tests.rs"] mod selected_key_tests;

#[path="prekey_callback_tests.rs"] mod prekey_callback_tests;
