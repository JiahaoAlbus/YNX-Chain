//! Private storage projection of Noether's candidate format. NOT an auth grant.
//! No secret key, protector callback, C pointer, or public admission constructor.
use std::{marker::PhantomData, rc::Rc};
const MAGIC:&[u8;8]=b"YNXPQK01";
const DOMAIN:&[u8]=b"YNX/SOCIAL/OWN-PQ-STORAGE/V1";
const PREFIX:&[u8]=b"ynx.social.ownkey.v1.";
const AAD_MAX:usize=7168;
const BINDING_MAX:usize=4096;
const PQ_PUBLIC:usize=2592;
const CIPHER:usize=4912;
const NONCE:usize=12;
const RECORD_MAX:usize=16+AAD_MAX+NONCE+CIPHER;
#[derive(Debug,PartialEq,Eq)]
pub(crate) enum StorageError { Bounds, Format, Association, Memory }
/// Structural expected fields only, NOT source/device trust or rollback proof.
pub(crate) struct ExpectedStorage<'a> {
 pub(crate) alias:&'a [u8],pub(crate) generation:u64,
 pub(crate) classic_public:&'a [u8;33],pub(crate) pq_public:&'a [u8;PQ_PUBLIC],
 pub(crate) owner_association:&'a [u8],
}
/// Ciphertext and public metadata. Native private !Send owner, no byte getter.
/// Tag has NOT been verified; no successful reload or authenticated cohort type.
pub(crate) struct UnverifiedPqStoredRecord {
 wire:Vec<u8>,aad_size:usize,classic_offset:usize,
 local:PhantomData<Rc<()>>,
}
struct Cursor<'a>{bytes:&'a [u8],position:usize}
impl<'a> Cursor<'a>{
 fn take(&mut self,n:usize)->Result<&'a [u8],StorageError>{
  let end=self.position.checked_add(n).ok_or(StorageError::Bounds)?;
  let value=self.bytes.get(self.position..end).ok_or(StorageError::Format)?;
  self.position=end;Ok(value)
 }
 fn u32(&mut self)->Result<u32,StorageError>{Ok(u32::from_be_bytes(self.take(4)?.try_into().map_err(|_|StorageError::Format)?))}
 fn u64(&mut self)->Result<u64,StorageError>{Ok(u64::from_be_bytes(self.take(8)?.try_into().map_err(|_|StorageError::Format)?))}
}
fn alias_valid(alias:&[u8])->bool{
 alias.len()==PREFIX.len()+32&&alias.starts_with(PREFIX)&&alias[PREFIX.len()..].iter().all(|c|c.is_ascii_digit()||matches!(c,b'a'..=b'f'))
}
impl UnverifiedPqStoredRecord {
 pub(crate) fn decode(wire:&[u8],expected:&ExpectedStorage<'_>)->Result<Self,StorageError>{
  if wire.len()>RECORD_MAX||wire.len()<16||!alias_valid(expected.alias)||expected.generation==0||expected.classic_public[0]!=5||expected.owner_association.is_empty()||expected.owner_association.len()>BINDING_MAX{return Err(StorageError::Bounds)}
  let mut outer=Cursor{bytes:wire,position:0};
  if outer.take(8)?!=MAGIC||outer.u32()?!=1{return Err(StorageError::Format)}
  let aad_size=outer.u32()? as usize;
  if aad_size==0||aad_size>AAD_MAX||wire.len()!=16+aad_size+NONCE+CIPHER{return Err(StorageError::Bounds)}
  let aad=outer.take(aad_size)?;let mut inner=Cursor{bytes:aad,position:0};
  if inner.take(DOMAIN.len())?!=DOMAIN||inner.u32()?!=1||inner.u32()?!=87{return Err(StorageError::Format)}
  if inner.u64()?!=expected.generation{return Err(StorageError::Association)}
  let alias_size=inner.u32()? as usize;
  if alias_size!=expected.alias.len()||inner.take(alias_size)?!=expected.alias{return Err(StorageError::Association)}
  let classic_offset=16+inner.position;
  if inner.take(33)?!=expected.classic_public||inner.take(PQ_PUBLIC)?!=expected.pq_public{return Err(StorageError::Association)}
  let binding_size=inner.u32()? as usize;
  if binding_size==0||binding_size>BINDING_MAX||binding_size!=expected.owner_association.len()||inner.take(binding_size)?!=expected.owner_association||inner.position!=aad.len(){return Err(StorageError::Association)}
  outer.take(NONCE)?;outer.take(CIPHER)?;
  // All shape/expected-field checks precede owned allocation. Cipher bytes
  // remain unverified until actual native protector authenticates them.
  let mut owned=Vec::new();owned.try_reserve_exact(wire.len()).map_err(|_|StorageError::Memory)?;owned.extend_from_slice(wire);
  Ok(Self{wire:owned,aad_size,classic_offset,local:PhantomData})
 }
 pub(super) fn classic_matches(&self,selected_public:&[u8])->bool{
  self.wire.get(self.classic_offset..self.classic_offset+33)==Some(selected_public)
 }
 pub(crate) fn encoded_size(&self)->usize{16+self.aad_size+NONCE+CIPHER}
}
#[cfg(test)]mod tests{
 use super::*;
 fn fixture()->(Vec<u8>,[u8;33],[u8;PQ_PUBLIC]){
  let mut classic=[0;33];classic[0]=5;let pq=[0;PQ_PUBLIC];let alias=b"ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef";
  let mut aad=DOMAIN.to_vec();aad.extend(1u32.to_be_bytes());aad.extend(87u32.to_be_bytes());aad.extend(1u64.to_be_bytes());aad.extend((alias.len()as u32).to_be_bytes());aad.extend(alias);aad.extend(classic);aad.extend(pq);aad.extend(1u32.to_be_bytes());aad.push(9);
  let mut wire=MAGIC.to_vec();wire.extend(1u32.to_be_bytes());wire.extend((aad.len()as u32).to_be_bytes());wire.extend(aad);wire.resize(wire.len()+NONCE+CIPHER,0);(wire,classic,pq)
 }
 fn expected<'a>(classic:&'a[u8;33],pq:&'a[u8;PQ_PUBLIC])->ExpectedStorage<'a>{ExpectedStorage{alias:b"ynx.social.ownkey.v1.0123456789abcdef0123456789abcdef",generation:1,classic_public:classic,pq_public:pq,owner_association:&[9]}}
 #[test]fn r36_storage_public_dummy_is_unverified(){let(w,c,p)=fixture();let owner=UnverifiedPqStoredRecord::decode(&w,&expected(&c,&p)).unwrap();assert_eq!(owner.encoded_size(),w.len());assert!(owner.classic_matches(&c));let mut wrong=c;wrong[1]=1;assert!(!owner.classic_matches(&wrong));}
 #[test]fn r36_storage_trailing_refused(){let(mut w,c,p)=fixture();w.push(0);assert!(matches!(UnverifiedPqStoredRecord::decode(&w,&expected(&c,&p)),Err(StorageError::Bounds)));}
 #[test]fn r36_storage_version_refused(){let(mut w,c,p)=fixture();w[11]=2;assert!(matches!(UnverifiedPqStoredRecord::decode(&w,&expected(&c,&p)),Err(StorageError::Format)));}
 #[test]fn r36_storage_each_association_refused(){let(w,c,p)=fixture();let e=expected(&c,&p);let mut changed=expected(&c,&p);changed.generation=2;assert!(matches!(UnverifiedPqStoredRecord::decode(&w,&changed),Err(StorageError::Association)));changed=expected(&c,&p);changed.owner_association=&[8];assert!(matches!(UnverifiedPqStoredRecord::decode(&w,&changed),Err(StorageError::Association)));let mut wrong=c;wrong[1]=1;changed=expected(&wrong,&p);assert!(matches!(UnverifiedPqStoredRecord::decode(&w,&changed),Err(StorageError::Association)));let mut pq=p;pq[0]=1;changed=expected(&c,&pq);assert!(matches!(UnverifiedPqStoredRecord::decode(&w,&changed),Err(StorageError::Association)));assert!(UnverifiedPqStoredRecord::decode(&w,&e).is_ok());}
 #[test]fn r36_storage_missing_bounded(){let(w,c,p)=fixture();for n in [0,15,16,w.len()-1]{assert!(UnverifiedPqStoredRecord::decode(&w[..n],&expected(&c,&p)).is_err());}let huge=vec![0;RECORD_MAX+1];assert!(matches!(UnverifiedPqStoredRecord::decode(&huge,&expected(&c,&p)),Err(StorageError::Bounds)));}
 #[test]fn r36_storage_cipher_not_promoted(){let(mut w,c,p)=fixture();let n=w.len();w[n-1]=1;assert!(UnverifiedPqStoredRecord::decode(&w,&expected(&c,&p)).is_ok());/* structural success deliberately has NO authenticated type/receipt */}
}

#[cfg(test)] impl UnverifiedPqStoredRecord {
    // PUBLIC dummy ciphertext allocation identity for ownership control ONLY;
    // no production pointer getter, key material, constructor or authority.
    pub(crate) fn fixture_public_allocation(&self)->usize { self.wire.as_ptr() as usize }
}
