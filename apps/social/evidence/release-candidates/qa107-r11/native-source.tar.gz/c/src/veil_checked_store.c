#include "veil_checked_store.h"
#include "veil_producer_private.h"
#include "../../protected-source/linux/ynx_source_platform_qualified.h"
#include "veil_store_custody.h"
#include <sqlite3.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

/* Implementation-private ciphertext-only objects. No production factory yet. */
struct veil_authenticated_record { char kind[33], id[1025]; unsigned char *bytes; size_t size; };
struct veil_authenticated_intent {
  char op[37], owner[513], device[513], identity_fp[513], key_alias[513];
  char base_hash[65], next_hash[65], cipher_hash[65];
  int64_t base_rev, next_rev, auth_gen; unsigned char *bytes; size_t size;
};
/* Tags are a native execution plan, NOT source/device authentication. */
enum native_step_tag { IDENTITY, EC_SAVE, EC_REMOVE, KYBER_SAVE, KYBER_USED, SESSION, INBOX, OUTBOX };
struct veil_authenticated_step {
  enum native_step_tag tag; uint32_t sequence;
  const veil_authenticated_record *record; const veil_authenticated_intent *intent;
};
enum phase { OPEN, ACTIVE, FROZEN, ENDED, UNKNOWN, CLOSED };
struct veil_checked_store {
  veil_private_store_binding *binding; veil_custody_watch *custody; sqlite3 *db; pthread_t owner; enum phase phase; int attempt;
  const veil_authenticated_record *records[VEIL_STORE_RECORDS_MAX]; size_t count;
  unsigned char removed[VEIL_STORE_RECORDS_MAX];
  const veil_authenticated_intent *intent;
  uint32_t next_step; int queue_seen;
  size_t snapshot_borrows, producer_borrows, source_holds;
  veil_native_cleanup_handle *cleanup_owner;
  veil_private_effect_guard *source_cleanup;
  veil_store_status source_cleanup_primary;
};
/* Ciphertext coherence only, never authenticated protocol records or a lease. */
struct veil_snapshot_row { char kind[33],id[1025]; unsigned char *bytes;size_t size; };
struct veil_ciphertext_snapshot {
  veil_checked_store *store; pthread_t owner;
  int64_t revision, data_version;
  struct veil_snapshot_row **rows; size_t count, blob_bytes;
};
static int text_ok(const char *s, size_t max) {
  if (!s) return 0;
  size_t n = strnlen(s, max + 1);
  if (!n || n > max) return 0;
  for (size_t i = 0; i < n; i++) if ((unsigned char)s[i] < 33 || (unsigned char)s[i] > 126) return 0;
  return 1;
}
static int hash_ok(const char *s) {
  if (!text_ok(s,64) || strlen(s)!=64) return 0;
  for (int i=0;i<64;i++) if (!((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='f'))) return 0;
  return 1;
}
static int op_ok(const char *s) {
  if (!text_ok(s,36) || strlen(s)!=36) return 0;
  for (int i=0;i<36;i++) {
    if (i==8||i==13||i==18||i==23) { if (s[i]!='-') return 0; }
    else if (!((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='f'))) return 0;
  }
  return 1;
}
static veil_store_status guard(veil_checked_store *s, int frozen_allowed) {
  if (!s) return VEIL_STORE_REQUIRED;
  if (!pthread_equal(s->owner,pthread_self())) return VEIL_STORE_THREAD;
  if (!s->db || s->phase==CLOSED || s->phase==ENDED) return VEIL_STORE_LIFETIME;
  if (s->phase==UNKNOWN) return VEIL_STORE_UNKNOWN;
  if (s->phase==FROZEN && !frozen_allowed) return VEIL_STORE_FROZEN;
  if (s->phase!=ACTIVE && s->phase!=FROZEN) return VEIL_STORE_LIFETIME;
  if (sqlite3_get_autocommit(s->db)) return VEIL_STORE_LIFETIME;
  return VEIL_STORE_OK;
}
static veil_store_status prepare(veil_checked_store *s,const char *sql,sqlite3_stmt **out) {
  *out=NULL;
  return sqlite3_prepare_v2(s->db,sql,-1,out,NULL)==SQLITE_OK ? VEIL_STORE_OK : VEIL_STORE_SQL;
}
static int bind_text(sqlite3_stmt *st,int col,const char *v) {
  return sqlite3_bind_text(st,col,v,(int)strlen(v),SQLITE_STATIC)==SQLITE_OK;
}
static int bind_blob(sqlite3_stmt *st,int col,const void *v,size_t n,size_t ceiling) {
  return v && n && n<=ceiling && n<=INT_MAX && sqlite3_bind_blob(st,col,v,(int)n,SQLITE_STATIC)==SQLITE_OK;
}
static veil_store_status finish(sqlite3_stmt *st,int expected) {
  int rc=sqlite3_step(st), f=sqlite3_finalize(st);
  return rc==expected && f==SQLITE_OK ? VEIL_STORE_OK : VEIL_STORE_SQL;
}
static veil_store_status scalar(veil_checked_store *s,const char *sql,int64_t *out) {
  sqlite3_stmt *st=NULL; if (prepare(s,sql,&st)) return VEIL_STORE_SQL;
  int good=sqlite3_step(st)==SQLITE_ROW && sqlite3_column_type(st,0)==SQLITE_INTEGER;
  if (good) *out=sqlite3_column_int64(st,0);
  good=good && sqlite3_step(st)==SQLITE_DONE;
  int f=sqlite3_finalize(st); return good && f==SQLITE_OK ? VEIL_STORE_OK : VEIL_STORE_SQL;
}
static int same_text(sqlite3_stmt *st,int col,const char *value,size_t max) {
  if (sqlite3_column_type(st,col)!=SQLITE_TEXT) return 0;
  int n=sqlite3_column_bytes(st,col);
  if (n<1 || (size_t)n>max || (size_t)n!=strlen(value)) return 0;
  /* Length/type/budget checked BEFORE requesting materialized data. */
  const unsigned char *p=sqlite3_column_text(st,col);
  return p && memcmp(p,value,(size_t)n)==0;
}
static int same_blob(sqlite3_stmt *st,int col,const unsigned char *bytes,size_t n,size_t max) {
  if (sqlite3_column_type(st,col)!=SQLITE_BLOB || n>max) return 0;
  int actual=sqlite3_column_bytes(st,col);
  if (actual<1 || (size_t)actual>max || (size_t)actual!=n) return 0;
  const void *p=sqlite3_column_blob(st,col);
  return p && memcmp(p,bytes,n)==0;
}
static int same_integer(sqlite3_stmt *st,int col,int64_t n) {
  return sqlite3_column_type(st,col)==SQLITE_INTEGER && sqlite3_column_int64(st,col)==n;
}
veil_store_status veil_store_open_required(const veil_required_native_admission *a,veil_checked_store **out) {
  if(!out)return VEIL_STORE_BOUND;*out=NULL;
  veil_private_store_binding *binding=NULL;const char *path=NULL;
  veil_store_status st=veil_private_store_admit(a,&binding,&path);
  if(st)return st;
  if(!binding||!path||path[0]!='/'||strnlen(path,4097)>4096){
    veil_private_store_release(&binding);return VEIL_STORE_BOUND;
  }
  veil_checked_store *s=calloc(1,sizeof(*s));
  if(!s){veil_private_store_release(&binding);return VEIL_STORE_SQL;}
  s->owner=pthread_self();s->phase=OPEN;s->binding=binding;
  st=veil_custody_watch_open(path,&s->custody);
  if(st){veil_private_store_release(&s->binding);free(s);return st;}
  if(sqlite3_open_v2(path,&s->db,SQLITE_OPEN_READWRITE|SQLITE_OPEN_FULLMUTEX,NULL)!=SQLITE_OK){
    if(s->db)sqlite3_close(s->db);
    veil_custody_watch_drop(&s->custody);veil_private_store_release(&s->binding);free(s);return VEIL_STORE_SQL;
  }
  /* Local path/VFS observation is not an issuer binding. This happens before
   * existing configuration, never CREATE/migrate. Unsupported VFS refuses. */
  st=veil_custody_watch_check(s->db,s->custody);
  if(st){sqlite3_close(s->db);veil_custody_watch_drop(&s->custody);veil_private_store_release(&s->binding);free(s);return st;}
  sqlite3_limit(s->db,SQLITE_LIMIT_LENGTH,VEIL_STORE_CELL_MAX+4096);
  sqlite3_db_config(s->db,SQLITE_DBCONFIG_DEFENSIVE,1,NULL);
  int64_t unsafe=-1;
  if(scalar(s,"SELECT COUNT(*) FROM sqlite_master WHERE type IN ('trigger','view')",&unsafe)
      ||unsafe||sqlite3_exec(s->db,"PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON;",NULL,NULL,NULL)!=SQLITE_OK){
    sqlite3_close(s->db);veil_custody_watch_drop(&s->custody);veil_private_store_release(&s->binding);free(s);return VEIL_STORE_SQL;
  }
  /* Never create/migrate a parallel database or schema. Actual admission must
   * authenticate the original DB identity/schema/restore binding. */
  sqlite3_stmt *q=NULL;
  st=prepare(s,"SELECT records.kind,records.id,records.sealed,checkpoint.revision,veil_checkpoint_intents_v1.op,veil_checkpoint_intents_v1.phase,veil_checkpoint_chunks_v1.part,veil_checkpoint_chunks_v1.bytes,veil_checkpoint_committed_ops_v1.commitment_hash FROM records,checkpoint,veil_checkpoint_intents_v1,veil_checkpoint_chunks_v1,veil_checkpoint_committed_ops_v1 WHERE 0",&q);
  if(!st)st=finish(q,SQLITE_DONE);
  if(st){sqlite3_close(s->db);veil_custody_watch_drop(&s->custody);veil_private_store_release(&s->binding);free(s);return st;}
  *out=s;return VEIL_STORE_OK;
}
veil_store_status veil_store_begin(veil_checked_store *s) {
  if (!s) return VEIL_STORE_REQUIRED;
  if (!pthread_equal(s->owner,pthread_self())) return VEIL_STORE_THREAD;
  if (!s->db || s->phase!=OPEN || s->attempt) return VEIL_STORE_LIFETIME;
  if (!sqlite3_get_autocommit(s->db)) return VEIL_STORE_LIFETIME;
  if (sqlite3_exec(s->db,"BEGIN IMMEDIATE",NULL,NULL,NULL)!=SQLITE_OK) return VEIL_STORE_SQL;
  s->phase=ACTIVE; return VEIL_STORE_OK;
}
static veil_store_status apply_record(veil_checked_store *s,const veil_authenticated_record *r,int ordered_repeat,int native_kind) {
  veil_store_status status=guard(s,0); if (status) return status;
  if (!r || !text_ok(r->kind,32) || (!native_kind && strcmp(r->kind,"SESSION")) || !text_ok(r->id,1024) || r->size<29 || r->size>VEIL_STORE_CELL_MAX) return VEIL_STORE_BOUND;
  size_t replace=s->count;
  for (size_t i=0;i<s->count;i++) if (s->records[i] && !strcmp(s->records[i]->kind,r->kind)&&!strcmp(s->records[i]->id,r->id)) {
    if(!ordered_repeat)return VEIL_STORE_DUPLICATE;
    replace=i;break;
  }
  if (replace==s->count && s->count>=VEIL_STORE_RECORDS_MAX) return VEIL_STORE_BOUND;
  /* SQLite native aggregate preflight, replacing an existing row doesn't add its old bytes. */
  sqlite3_stmt *st=NULL;
  if (prepare(s,"SELECT COUNT(*),COALESCE(SUM(length(sealed)),0) FROM records WHERE NOT(kind=? AND id=?)",&st)) return VEIL_STORE_SQL;
  int good=bind_text(st,1,r->kind)&&bind_text(st,2,r->id)&&sqlite3_step(st)==SQLITE_ROW;
  int64_t rows=-1,total=-1;
  if (good && sqlite3_column_type(st,0)==SQLITE_INTEGER && sqlite3_column_type(st,1)==SQLITE_INTEGER) {
    rows=sqlite3_column_int64(st,0); total=sqlite3_column_int64(st,1);
  }
  sqlite3_finalize(st);
  if (!good || rows<0 || total<0) return VEIL_STORE_SQL;
  if (rows>=VEIL_STORE_RECORDS_MAX || total>VEIL_STORE_TOTAL_MAX || r->size>VEIL_STORE_TOTAL_MAX-(size_t)total) return VEIL_STORE_BOUND;
  if (prepare(s,"INSERT INTO records(kind,id,sealed) VALUES(?,?,?) ON CONFLICT(kind,id) DO UPDATE SET sealed=excluded.sealed",&st)) return VEIL_STORE_SQL;
  if (!bind_text(st,1,r->kind)||!bind_text(st,2,r->id)||!bind_blob(st,3,r->bytes,r->size,VEIL_STORE_CELL_MAX)) { sqlite3_finalize(st); return VEIL_STORE_BOUND; }
  status=finish(st,SQLITE_DONE);
  if(!status&&sqlite3_changes(s->db)!=1)return VEIL_STORE_MISMATCH;
  if (!status) { s->records[replace]=r;s->removed[replace]=0;if(replace==s->count)s->count++; }
  return status;
}
veil_store_status veil_store_apply_record(veil_checked_store *s,const veil_authenticated_record *r) { return apply_record(s,r,0,0); }
veil_store_status veil_store_stage_intent(veil_checked_store *s,const veil_authenticated_intent *i) {
  veil_store_status status=guard(s,0); if (status) return status;
  if (!i || s->intent) return VEIL_STORE_DUPLICATE;
  int64_t revision=-1,count=-1,total=-1;
  if (scalar(s,"SELECT revision FROM checkpoint WHERE slot=1",&revision) || scalar(s,"SELECT COUNT(*) FROM veil_checkpoint_intents_v1",&count)
      || scalar(s,"SELECT COALESCE(SUM(length(bytes)),0) FROM veil_checkpoint_chunks_v1",&total)) return VEIL_STORE_SQL;
  if (revision!=i->base_rev) return VEIL_STORE_MISMATCH;
  if (count<0 || count>=128 || total<0 || total>VEIL_STORE_TOTAL_MAX || i->size>VEIL_STORE_TOTAL_MAX-(size_t)total) return VEIL_STORE_BOUND;
  sqlite3_stmt *st=NULL;
  if (prepare(s,"INSERT INTO veil_checkpoint_intents_v1(op,owner,device,identity_fp,key_alias,base_rev,base_hash,next_rev,next_hash,cipher_hash,auth_gen,phase,candidate_bytes,chunk_count,receipt) VALUES(?,?,?,?,?,?,?,?,?,?,?,'PREPARED',?,?,NULL)",&st)) return VEIL_STORE_SQL;
  int good=bind_text(st,1,i->op)&&bind_text(st,2,i->owner)&&bind_text(st,3,i->device)&&bind_text(st,4,i->identity_fp)&&bind_text(st,5,i->key_alias)
    && sqlite3_bind_int64(st,6,i->base_rev)==SQLITE_OK&&bind_text(st,7,i->base_hash)&&sqlite3_bind_int64(st,8,i->next_rev)==SQLITE_OK
    &&bind_text(st,9,i->next_hash)&&bind_text(st,10,i->cipher_hash)&&sqlite3_bind_int64(st,11,i->auth_gen)==SQLITE_OK
    &&sqlite3_bind_int64(st,12,(sqlite3_int64)i->size)==SQLITE_OK&&sqlite3_bind_int64(st,13,(sqlite3_int64)((i->size+65535)/65536))==SQLITE_OK;
  if (!good) { sqlite3_finalize(st); return VEIL_STORE_SQL; }
  status=finish(st,SQLITE_DONE); if (status) return status;
  if(sqlite3_changes(s->db)!=1)return VEIL_STORE_MISMATCH;
  for (size_t offset=0,part=0;offset<i->size;offset+=65536,part++) {
    size_t n=i->size-offset; if (n>65536) n=65536;
    if (prepare(s,"INSERT INTO veil_checkpoint_chunks_v1(op,part,bytes) VALUES(?,?,?)",&st)) return VEIL_STORE_SQL;
    if (!bind_text(st,1,i->op)||sqlite3_bind_int64(st,2,(sqlite3_int64)part)!=SQLITE_OK||!bind_blob(st,3,i->bytes+offset,n,65536)) { sqlite3_finalize(st); return VEIL_STORE_BOUND; }
    status=finish(st,SQLITE_DONE); if (status) return status;
    if(sqlite3_changes(s->db)!=1)return VEIL_STORE_MISMATCH;
  }
  s->intent=i; return VEIL_STORE_OK;
}
#ifdef VEIL_STORE_FIXTURE
static veil_store_status delete_record(veil_checked_store *s,const veil_authenticated_record *r) {
  if(!r || strcmp(r->kind,"SESSION") || !text_ok(r->id,1024))return VEIL_STORE_BOUND;
  size_t found=s->count;
  for(size_t n=0;n<s->count;n++)if(s->records[n]&&!strcmp(s->records[n]->kind,r->kind)&&!strcmp(s->records[n]->id,r->id)){found=n;break;}
  if(found==s->count&&s->count>=VEIL_STORE_RECORDS_MAX)return VEIL_STORE_BOUND;
  sqlite3_stmt *st=NULL;if(prepare(s,"DELETE FROM records WHERE kind=? AND id=?",&st))return VEIL_STORE_SQL;
  if(!bind_text(st,1,r->kind)||!bind_text(st,2,r->id)){sqlite3_finalize(st);return VEIL_STORE_BOUND;}
  veil_store_status status=finish(st,SQLITE_DONE);if(status)return status;
  if(sqlite3_changes(s->db)>1)return VEIL_STORE_MISMATCH;
  s->records[found]=r;s->removed[found]=1;if(found==s->count)s->count++;
  return VEIL_STORE_OK;
}
#endif
static veil_store_status verify_removed(veil_checked_store *s,const veil_authenticated_record *r) {
  sqlite3_stmt *st=NULL;if(prepare(s,"SELECT COUNT(*) FROM records WHERE kind=? AND id=?",&st))return VEIL_STORE_SQL;
  int good=bind_text(st,1,r->kind)&&bind_text(st,2,r->id)&&sqlite3_step(st)==SQLITE_ROW&&same_integer(st,0,0)&&sqlite3_step(st)==SQLITE_DONE;
  int f=sqlite3_finalize(st);return good&&f==SQLITE_OK?VEIL_STORE_OK:VEIL_STORE_MISMATCH;
}
veil_store_status veil_store_apply_native_step(veil_checked_store *s,const veil_authenticated_step *step) {
  veil_store_status status=guard(s,0);if(status)return status;
  if(!step)return VEIL_STORE_REQUIRED;
  if(step->sequence!=s->next_step || s->queue_seen)return VEIL_STORE_DUPLICATE;
  if(s->next_step>32 || (s->next_step==32 && step->tag!=INBOX && step->tag!=OUTBOX))return VEIL_STORE_BOUND;
  switch(step->tag) {
    case IDENTITY:case EC_SAVE:case KYBER_SAVE:case KYBER_USED:case SESSION:
      status=apply_record(s,step->record,1,0);break;
    case EC_REMOVE:
#ifdef VEIL_STORE_FIXTURE
      status=delete_record(s,step->record);break;
#else
      /* Required authenticated tombstone + real upstream missing loader. */
      return VEIL_STORE_REQUIRED;
#endif
    case INBOX:case OUTBOX:status=veil_store_stage_intent(s,step->intent);break;
    default:return VEIL_STORE_REQUIRED;
  }
  if(!status){s->next_step++;if(step->tag==INBOX||step->tag==OUTBOX)s->queue_seen=1;}
  return status;
}
veil_store_status veil_store_freeze(veil_checked_store *s) {
  veil_store_status status=guard(s,0); if (status) return status;
  s->phase=FROZEN; return VEIL_STORE_OK;
}
veil_store_status veil_store_verify_record(veil_checked_store *s,const veil_authenticated_record *r) {
  veil_store_status status=guard(s,1); if (status) return status;
  if (s->phase!=FROZEN || !r) return VEIL_STORE_LIFETIME;
  sqlite3_stmt *st=NULL; if (prepare(s,"SELECT kind,id,sealed FROM records WHERE kind=? AND id=?",&st)) return VEIL_STORE_SQL;
  int good=bind_text(st,1,r->kind)&&bind_text(st,2,r->id)&&sqlite3_step(st)==SQLITE_ROW
    &&same_text(st,0,r->kind,32)&&same_text(st,1,r->id,1024)&&same_blob(st,2,r->bytes,r->size,VEIL_STORE_CELL_MAX)
    &&sqlite3_step(st)==SQLITE_DONE;
  int f=sqlite3_finalize(st); return good && f==SQLITE_OK ? VEIL_STORE_OK : VEIL_STORE_MISMATCH;
}
veil_store_status veil_store_verify_intent(veil_checked_store *s,const veil_authenticated_intent *i) {
  veil_store_status status=guard(s,1); if (status) return status;
  if (s->phase!=FROZEN || !i || s->intent!=i) return VEIL_STORE_MISMATCH;
  sqlite3_stmt *st=NULL;
  if (prepare(s,"SELECT owner,device,identity_fp,key_alias,base_rev,base_hash,next_rev,next_hash,cipher_hash,auth_gen,phase,candidate_bytes,chunk_count,receipt FROM veil_checkpoint_intents_v1 WHERE op=?",&st)) return VEIL_STORE_SQL;
  int good=bind_text(st,1,i->op)&&sqlite3_step(st)==SQLITE_ROW&&same_text(st,0,i->owner,512)&&same_text(st,1,i->device,512)
    &&same_text(st,2,i->identity_fp,512)&&same_text(st,3,i->key_alias,512)&&same_integer(st,4,i->base_rev)&&same_text(st,5,i->base_hash,64)
    &&same_integer(st,6,i->next_rev)&&same_text(st,7,i->next_hash,64)&&same_text(st,8,i->cipher_hash,64)&&same_integer(st,9,i->auth_gen)
    &&same_text(st,10,"PREPARED",32)&&same_integer(st,11,(int64_t)i->size)&&same_integer(st,12,(int64_t)((i->size+65535)/65536))
    &&sqlite3_column_type(st,13)==SQLITE_NULL&&sqlite3_step(st)==SQLITE_DONE;
  sqlite3_finalize(st); if (!good) return VEIL_STORE_MISMATCH;
  if (prepare(s,"SELECT part,bytes FROM veil_checkpoint_chunks_v1 WHERE op=? ORDER BY part",&st)) return VEIL_STORE_SQL;
  if (!bind_text(st,1,i->op)) { sqlite3_finalize(st); return VEIL_STORE_SQL; }
  size_t offset=0,part=0;
  while (offset<i->size) {
    size_t n=i->size-offset; if (n>65536) n=65536;
    if (sqlite3_step(st)!=SQLITE_ROW || !same_integer(st,0,(int64_t)part)||!same_blob(st,1,i->bytes+offset,n,65536)) { sqlite3_finalize(st); return VEIL_STORE_MISMATCH; }
    offset+=n; part++;
  }
  good=sqlite3_step(st)==SQLITE_DONE; int f=sqlite3_finalize(st);
  return good&&f==SQLITE_OK ? VEIL_STORE_OK : VEIL_STORE_MISMATCH;
}
veil_store_status veil_store_verify_applied(veil_checked_store *s) {
  veil_store_status status=guard(s,1);if(status)return status;
  if(s->phase!=FROZEN)return VEIL_STORE_LIFETIME;
  for(size_t n=0;n<s->count;n++)if(s->records[n]){
    status=s->removed[n]?verify_removed(s,s->records[n]):veil_store_verify_record(s,s->records[n]);if(status)return status;
  }
  if(!s->intent)return VEIL_STORE_REQUIRED;
  return veil_store_verify_intent(s,s->intent);
}
veil_store_status veil_store_rollback(veil_checked_store *s) {
  if (!s) return VEIL_STORE_REQUIRED;
  if (!pthread_equal(s->owner,pthread_self())) return VEIL_STORE_THREAD;
  if (!s->db || s->phase==CLOSED) return VEIL_STORE_LIFETIME;
  if (!sqlite3_get_autocommit(s->db) && sqlite3_exec(s->db,"ROLLBACK",NULL,NULL,NULL)!=SQLITE_OK) { s->phase=UNKNOWN; return VEIL_STORE_UNKNOWN; }
  if (s->phase!=UNKNOWN) s->phase=ENDED;
  return VEIL_STORE_OK;
}
veil_store_status veil_store_commit_required(veil_checked_store *s) {
  veil_store_status status=guard(s,1); return status ? status : VEIL_STORE_REQUIRED;
}
veil_store_status veil_store_close(veil_checked_store *s) {
  if (!s) return VEIL_STORE_REQUIRED;
  if (!pthread_equal(s->owner,pthread_self())) return VEIL_STORE_THREAD;
  if (s->phase==CLOSED) return VEIL_STORE_LIFETIME;
  if (s->snapshot_borrows || s->producer_borrows || s->source_holds || s->source_cleanup) return VEIL_STORE_LIFETIME;
  veil_store_status status=veil_store_rollback(s); if (status) return status;
  if (sqlite3_close(s->db)!=SQLITE_OK) return VEIL_STORE_SQL;
  s->db=NULL; s->phase=CLOSED; return veil_custody_watch_drop(&s->custody);
}
veil_store_status veil_store_destroy(veil_checked_store **s) {
  if (!s||!*s) return VEIL_STORE_REQUIRED;
  if (!pthread_equal((*s)->owner,pthread_self())) return VEIL_STORE_THREAD;
  if ((*s)->phase!=CLOSED) return VEIL_STORE_LIFETIME;
  veil_private_store_release(&(*s)->binding);free(*s); *s=NULL; return VEIL_STORE_OK;
}

/* Facts only inside existing private source-held transaction. No DB escape,
 * new lease, schema initialization or authority-bearing copy. */
veil_store_status veil_private_store_custody_read(veil_checked_store *s,veil_custody_facts *out) {
  if(!out)return VEIL_STORE_BOUND;
  memset(out,0,sizeof(*out));
  if(!s)return VEIL_STORE_REQUIRED;
  if(!pthread_equal(s->owner,pthread_self()))return VEIL_STORE_THREAD;
  if(!s->db||s->phase==CLOSED||!s->custody||s->source_holds!=1||sqlite3_get_autocommit(s->db))return VEIL_STORE_LIFETIME;
  return veil_custody_read(s->db,s->custody,out);
}
static veil_store_status snapshot_owner(veil_checked_store *s) {
  if(!s)return VEIL_STORE_REQUIRED;
  if(!pthread_equal(s->owner,pthread_self()))return VEIL_STORE_THREAD;
  if(!s->db||s->phase!=OPEN||!sqlite3_get_autocommit(s->db))return VEIL_STORE_LIFETIME;
  return VEIL_STORE_OK;
}
static void snapshot_free_rows(veil_ciphertext_snapshot *snap) {
  if(!snap)return;
  for(size_t n=0;n<snap->count;n++)if(snap->rows[n]){free(snap->rows[n]->bytes);free(snap->rows[n]);}
  free(snap->rows);free(snap);
}
/* Canonical ASCII bytes, not mutation order. BLOB SQL keys below avoid using
 * a caller-replaced text collation; independently reject noncanonical rows. */
static int snapshot_row_after(const struct veil_snapshot_row *previous,const struct veil_snapshot_row *row) {
  if(!previous)return 1;
  int kind=strcmp(previous->kind,row->kind);
  return kind<0||(kind==0&&strcmp(previous->id,row->id)<0);
}
static veil_store_status snapshot_end_read(veil_checked_store *s,veil_store_status primary) {
  /* The controlled READ txn never commits business mutations. */
  if(sqlite3_exec(s->db,"ROLLBACK",NULL,NULL,NULL)!=SQLITE_OK){s->phase=UNKNOWN;return primary?primary:VEIL_STORE_UNKNOWN;}
  return primary;
}
veil_store_status veil_store_read_ciphertext_snapshot(veil_checked_store *s,veil_ciphertext_snapshot **out) {
  if(!out)return VEIL_STORE_BOUND;*out=NULL;
  veil_store_status status=snapshot_owner(s);if(status)return status;
  if(s->snapshot_borrows)return VEIL_STORE_LIFETIME;
  if(sqlite3_exec(s->db,"BEGIN",NULL,NULL,NULL)!=SQLITE_OK)return VEIL_STORE_SQL;
  /* Establish ONE real SQLite snapshot and aggregate preflight before owned rows/BLOB allocation. */
  int64_t count=-1,total=-1,invalid=-1,revision=-1,version=-1;
  status=scalar(s,"SELECT revision FROM main.checkpoint WHERE slot=1",&revision);
  if(!status)status=scalar(s,"PRAGMA main.data_version",&version);
  if(!status)status=scalar(s,"SELECT COUNT(*) FROM main.records",&count);
  if(!status)status=scalar(s,"SELECT COALESCE(SUM(length(sealed)),0) FROM main.records",&total);
  if(!status)status=scalar(s,"SELECT COUNT(*) FROM main.records WHERE typeof(kind)!='text' OR typeof(id)!='text' OR typeof(sealed)!='blob' OR length(CAST(kind AS BLOB)) NOT BETWEEN 1 AND 32 OR length(CAST(id AS BLOB)) NOT BETWEEN 1 AND 1024 OR instr(kind,char(0))>0 OR instr(id,char(0))>0 OR kind GLOB '*[^!-~]*' OR id GLOB '*[^!-~]*' OR length(sealed) NOT BETWEEN 29 AND 8388636",&invalid);
  if(status)return snapshot_end_read(s,status);
  if(count<0||count>VEIL_STORE_RECORDS_MAX||total<0||total>VEIL_STORE_TOTAL_MAX||invalid||revision<0||version<0)return snapshot_end_read(s,VEIL_STORE_BOUND);
  veil_ciphertext_snapshot *snap=calloc(1,sizeof(*snap));if(!snap)return snapshot_end_read(s,VEIL_STORE_SQL);
  snap->owner=pthread_self();snap->store=s;snap->revision=revision;snap->data_version=version;
  snap->rows=calloc(count?(size_t)count:1,sizeof(*snap->rows));if(!snap->rows){snapshot_free_rows(snap);return snapshot_end_read(s,VEIL_STORE_SQL);}
  sqlite3_stmt *st=NULL;
  status=prepare(s,"SELECT kind,id,length(sealed),sealed FROM main.records ORDER BY CAST(kind AS BLOB) COLLATE BINARY,CAST(id AS BLOB) COLLATE BINARY",&st);
  if(status){snapshot_free_rows(snap);return snapshot_end_read(s,status);}
  for(int64_t n=0;n<count;n++) {
    if(sqlite3_step(st)!=SQLITE_ROW||sqlite3_column_type(st,0)!=SQLITE_TEXT||sqlite3_column_type(st,1)!=SQLITE_TEXT
        ||sqlite3_column_type(st,2)!=SQLITE_INTEGER||sqlite3_column_type(st,3)!=SQLITE_BLOB){status=VEIL_STORE_MISMATCH;break;}
    int kn=sqlite3_column_bytes(st,0),idn=sqlite3_column_bytes(st,1);
    int64_t bytes=sqlite3_column_int64(st,2);
    if(kn<1||kn>32||idn<1||idn>1024||bytes<29||bytes>VEIL_STORE_CELL_MAX||(size_t)bytes>VEIL_STORE_TOTAL_MAX-snap->blob_bytes){status=VEIL_STORE_BOUND;break;}
    /* Every ownership allocation/copy follows checked aggregate and cell preflight. */
    struct veil_snapshot_row *row=calloc(1,sizeof(*row));if(!row){status=VEIL_STORE_SQL;break;}
    row->bytes=malloc((size_t)bytes);if(!row->bytes){free(row);status=VEIL_STORE_SQL;break;}
    const unsigned char *kind=sqlite3_column_text(st,0),*id=sqlite3_column_text(st,1);
    const void *blob=sqlite3_column_blob(st,3);
    if(!kind||!id||!blob||sqlite3_column_bytes(st,3)!=bytes){free(row->bytes);free(row);status=VEIL_STORE_MISMATCH;break;}
    memcpy(row->kind,kind,(size_t)kn);memcpy(row->id,id,(size_t)idn);row->size=(size_t)bytes;
    if(!text_ok(row->kind,32)||!text_ok(row->id,1024)||strlen(row->kind)!=(size_t)kn||strlen(row->id)!=(size_t)idn){free(row->bytes);free(row);status=VEIL_STORE_BOUND;break;}
    if(!snapshot_row_after(snap->count?snap->rows[snap->count-1]:NULL,row)){free(row->bytes);free(row);status=VEIL_STORE_MISMATCH;break;}
    memcpy(row->bytes,blob,row->size);snap->rows[snap->count++]=row;snap->blob_bytes+=row->size;
  }
  if(!status && (snap->count!=(size_t)count||snap->blob_bytes!=(size_t)total||sqlite3_step(st)!=SQLITE_DONE))status=VEIL_STORE_MISMATCH;
  int final=sqlite3_finalize(st);if(!status&&final!=SQLITE_OK)status=VEIL_STORE_SQL;
  status=snapshot_end_read(s,status);
  if(status){snapshot_free_rows(snap);return status;}
  s->snapshot_borrows++;*out=snap;return VEIL_STORE_OK;
}
veil_store_status veil_store_snapshot_compare_current(veil_checked_store *s,const veil_ciphertext_snapshot *snap) {
  veil_store_status status=snapshot_owner(s);if(status)return status;
  if(!snap||snap->store!=s)return VEIL_STORE_MISMATCH;
  if(!pthread_equal(snap->owner,pthread_self()))return VEIL_STORE_THREAD;
  if(sqlite3_exec(s->db,"BEGIN",NULL,NULL,NULL)!=SQLITE_OK)return VEIL_STORE_SQL;
  int64_t revision=-1,version=-1,count=-1;
  status=scalar(s,"SELECT revision FROM main.checkpoint WHERE slot=1",&revision);
  if(!status)status=scalar(s,"PRAGMA main.data_version",&version);
  if(!status)status=scalar(s,"SELECT COUNT(*) FROM main.records",&count);
  if(!status&&(revision!=snap->revision||version!=snap->data_version||count!=(int64_t)snap->count))status=VEIL_STORE_MISMATCH;
  sqlite3_stmt *st=NULL;
  if(!status)status=prepare(s,"SELECT kind,id,sealed FROM main.records ORDER BY CAST(kind AS BLOB) COLLATE BINARY,CAST(id AS BLOB) COLLATE BINARY",&st);
  if(!status)for(size_t n=0;n<snap->count;n++){
    const struct veil_snapshot_row *row=snap->rows[n];
    if(sqlite3_step(st)!=SQLITE_ROW||!same_text(st,0,row->kind,32)||!same_text(st,1,row->id,1024)||!same_blob(st,2,row->bytes,row->size,VEIL_STORE_CELL_MAX)){status=VEIL_STORE_MISMATCH;break;}
  }
  if(st){if(!status&&sqlite3_step(st)!=SQLITE_DONE)status=VEIL_STORE_MISMATCH;int f=sqlite3_finalize(st);if(!status&&f!=SQLITE_OK)status=VEIL_STORE_SQL;}
  return snapshot_end_read(s,status);
}
veil_store_status veil_store_snapshot_release(veil_ciphertext_snapshot **snap) {
  if(!snap||!*snap)return VEIL_STORE_REQUIRED;
  if(!pthread_equal((*snap)->owner,pthread_self()))return VEIL_STORE_THREAD;
  veil_checked_store *s=(*snap)->store;
  if(!s||!s->snapshot_borrows)return VEIL_STORE_LIFETIME;
  s->snapshot_borrows--;snapshot_free_rows(*snap);*snap=NULL;return VEIL_STORE_OK;
}
veil_store_status veil_store_acquire_snapshot_required(const veil_required_native_admission *admission,const veil_ciphertext_snapshot *ciphertext,veil_native_snapshot **out) {
  (void)admission;(void)ciphertext;if(out)*out=NULL;return VEIL_STORE_REQUIRED;
}
veil_store_status veil_store_lookup_exact_required(const veil_required_native_admission *admission,veil_checked_store *s,const veil_authenticated_intent *intent,veil_native_verified_commit **out) {
  (void)admission;(void)s;(void)intent;if(out)*out=NULL;return VEIL_STORE_REQUIRED;
}

/* Actual source/device/protector/restore/CAS provider is absent. Never call
 * mechanics code from these production seams to simulate provider success. */
veil_store_status veil_native_acquire_snapshot(veil_checked_store *s,const veil_verified_native_operation_lease *lease,veil_snapshot_read_handle **out){(void)s;(void)lease;if(out)*out=NULL;return VEIL_STORE_REQUIRED;}
#define REQUIRED_READ(name) veil_store_status name(veil_snapshot_read_handle *read,const veil_native_record_key *key,veil_native_read_result **out){(void)read;(void)key;if(out)*out=NULL;return VEIL_STORE_REQUIRED;}
REQUIRED_READ(veil_native_read_identity)
REQUIRED_READ(veil_native_read_ec)
REQUIRED_READ(veil_native_read_kyber)
REQUIRED_READ(veil_native_read_session)
REQUIRED_READ(veil_native_read_signed)
#undef REQUIRED_READ
veil_store_status veil_native_finish_snapshot(veil_snapshot_read_handle **read,veil_owned_native_snapshot **out){(void)read;if(out)*out=NULL;return VEIL_STORE_REQUIRED;}
#ifndef VEIL_STORE_FIXTURE
#include "veil_authority_registry.inc"
#endif
#include "veil_producer.inc"

/* Private encrypted candidate is NOT an authenticated record constructor.
 * Same live source must validate its exact bytes/intent/journal position before
 * this existing SQL transaction is allowed to mutate. No public entry. */
veil_store_status veil_private_apply_ciphertext(veil_checked_write_handle *w,ynx_platform_storage_hold *source,size_t sequence,const ynx_storage_ciphertext *v,int queue){
 if(!w||!source||!v)return VEIL_STORE_REQUIRED;
 veil_store_status st=producer_validate(&w->owner);if(st)return st;
 if(w->attempt||w->queued||sequence!=w->step||(queue?w->step!=w->owner.journal_steps:w->step>=w->owner.journal_steps))return VEIL_STORE_DUPLICATE;
 if(!text_ok(v->kind,32)||!text_ok(v->id,1024)||!v->bytes||v->size<YNX_STORAGE_FIXED+16||v->size>(queue?YNX_STORAGE_QUEUE_MAX:YNX_STORAGE_MAX)||memcmp(v->bytes,queue?"YNXQUE1\0":"YNXREC1\0",8)||v->size>VEIL_STORE_TOTAL_MAX-w->record_bytes)return VEIL_STORE_BOUND;
 st=ynx_qualified_validate_ciphertext(source,w->owner.held,w->owner.pin,sequence,v);if(st)return st;
 st=producer_validate(&w->owner);if(st)return st;
 veil_authenticated_record *r=&w->records[w->step];strcpy(r->kind,v->kind);strcpy(r->id,v->id);r->bytes=v->bytes;r->size=v->size;
 st=apply_record(w->owner.store,r,1,1);if(!st){w->record_bytes+=r->size;if(queue)w->queued=1;else w->step++;}return st;
}

#define REQUIRED_DROP(name,type) veil_store_status name(type **handle){return handle&&!*handle?VEIL_STORE_OK:VEIL_STORE_REQUIRED;}
REQUIRED_DROP(veil_native_snapshot_read_drop,veil_snapshot_read_handle)
REQUIRED_DROP(veil_native_owned_snapshot_drop,veil_owned_native_snapshot)
REQUIRED_DROP(veil_native_read_result_drop,veil_native_read_result)
#undef REQUIRED_DROP

#ifdef VEIL_STORE_FIXTURE
static const char *schema =
 "CREATE TABLE IF NOT EXISTS records(kind TEXT NOT NULL,id TEXT NOT NULL,sealed BLOB NOT NULL,PRIMARY KEY(kind,id));"
 "CREATE TABLE IF NOT EXISTS checkpoint(slot INTEGER PRIMARY KEY CHECK(typeof(slot)='integer' AND slot=1),revision INTEGER NOT NULL CHECK(typeof(revision)='integer' AND revision>=0));"
 "INSERT OR IGNORE INTO checkpoint(slot,revision) VALUES(1,0);"
 "CREATE TABLE IF NOT EXISTS veil_checkpoint_intents_v1(op TEXT PRIMARY KEY NOT NULL,owner TEXT NOT NULL,device TEXT NOT NULL,identity_fp TEXT NOT NULL,key_alias TEXT NOT NULL,base_rev INTEGER NOT NULL,base_hash TEXT NOT NULL,next_rev INTEGER NOT NULL,next_hash TEXT NOT NULL,cipher_hash TEXT NOT NULL,auth_gen INTEGER NOT NULL,phase TEXT NOT NULL,candidate_bytes INTEGER NOT NULL,chunk_count INTEGER NOT NULL,receipt BLOB);"
 "CREATE TABLE IF NOT EXISTS veil_checkpoint_chunks_v1(op TEXT NOT NULL,part INTEGER NOT NULL,bytes BLOB NOT NULL,PRIMARY KEY(op,part));"
 "CREATE TABLE IF NOT EXISTS veil_checkpoint_committed_ops_v1(op TEXT PRIMARY KEY NOT NULL,commitment_hash TEXT NOT NULL);";
veil_store_status veil_fixture_open(const char *path,veil_checked_store **out) {
  if (!out) return VEIL_STORE_BOUND; *out=NULL;
  if (!path || path[0]!='/' || strnlen(path,4097)>4096) return VEIL_STORE_BOUND;
  veil_checked_store *s=calloc(1,sizeof(*s)); if (!s) return VEIL_STORE_SQL;
  s->owner=pthread_self(); s->phase=OPEN;
  if (sqlite3_open_v2(path,&s->db,SQLITE_OPEN_READWRITE|SQLITE_OPEN_CREATE|SQLITE_OPEN_FULLMUTEX,NULL)!=SQLITE_OK) { if(s->db)sqlite3_close(s->db);free(s);return VEIL_STORE_SQL; }
  sqlite3_limit(s->db,SQLITE_LIMIT_LENGTH,VEIL_STORE_CELL_MAX+4096);
  sqlite3_db_config(s->db,SQLITE_DBCONFIG_DEFENSIVE,1,NULL);
  int64_t unsafe=-1;
  if (scalar(s,"SELECT COUNT(*) FROM sqlite_master WHERE type IN ('trigger','view')",&unsafe)||unsafe!=0
      ||sqlite3_exec(s->db,"PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON;",NULL,NULL,NULL)!=SQLITE_OK
      ||sqlite3_exec(s->db,schema,NULL,NULL,NULL)!=SQLITE_OK) { sqlite3_close(s->db);free(s);return VEIL_STORE_SQL; }
  *out=s; return VEIL_STORE_OK;
}
veil_store_status veil_fixture_record(const char *kind,const char *id,const unsigned char *bytes,size_t size,veil_authenticated_record **out) {
  if (!out) return VEIL_STORE_BOUND; *out=NULL;
  /* ALL bounds BEFORE allocation/copy. Caller-provided large pointers are never touched. */
  if (!text_ok(kind,32)||strcmp(kind,"SESSION")||!text_ok(id,1024)||!bytes||size<29||size>VEIL_STORE_CELL_MAX) return VEIL_STORE_BOUND;
  veil_authenticated_record *r=calloc(1,sizeof(*r)); if (!r) return VEIL_STORE_SQL;
  r->bytes=malloc(size); if (!r->bytes) {free(r);return VEIL_STORE_SQL;}
  strcpy(r->kind,kind);strcpy(r->id,id);r->size=size;memcpy(r->bytes,bytes,size);*out=r;return VEIL_STORE_OK;
}
veil_store_status veil_fixture_intent_create(const veil_fixture_intent *f,veil_authenticated_intent **out) {
  if (!out) return VEIL_STORE_BOUND; *out=NULL;
  if (!f||!op_ok(f->op)||!text_ok(f->owner,512)||!text_ok(f->device,512)||!text_ok(f->identity_fp,512)||!text_ok(f->key_alias,512)
      ||!hash_ok(f->base_hash)||!hash_ok(f->next_hash)||!hash_ok(f->cipher_hash)||f->base_rev<0||f->base_rev==INT64_MAX
      ||f->next_rev!=f->base_rev+1||f->auth_gen<0||!f->ciphertext||!f->ciphertext_size||f->ciphertext_size>VEIL_STORE_TOTAL_MAX) return VEIL_STORE_BOUND;
  veil_authenticated_intent *i=calloc(1,sizeof(*i));if(!i)return VEIL_STORE_SQL;
  i->bytes=malloc(f->ciphertext_size);if(!i->bytes){free(i);return VEIL_STORE_SQL;}
  strcpy(i->op,f->op);strcpy(i->owner,f->owner);strcpy(i->device,f->device);strcpy(i->identity_fp,f->identity_fp);strcpy(i->key_alias,f->key_alias);
  strcpy(i->base_hash,f->base_hash);strcpy(i->next_hash,f->next_hash);strcpy(i->cipher_hash,f->cipher_hash);
  i->base_rev=f->base_rev;i->next_rev=f->next_rev;i->auth_gen=f->auth_gen;i->size=f->ciphertext_size;memcpy(i->bytes,f->ciphertext,i->size);*out=i;return VEIL_STORE_OK;
}
void veil_fixture_record_free(veil_authenticated_record **r) { if(r&&*r){free((*r)->bytes);free(*r);*r=NULL;} }
void veil_fixture_intent_free(veil_authenticated_intent **i) {if(i&&*i){free((*i)->bytes);free(*i);*i=NULL;}}
veil_store_status veil_fixture_commit_mechanics(veil_checked_store *s,const char *op,const char *hash) {
  veil_store_status status=guard(s,1);if(status)return status;
  if(s->phase!=FROZEN||!s->intent||!op_ok(op)||strcmp(s->intent->op,op)||!hash_ok(hash))return VEIL_STORE_MISMATCH;
  if(s->attempt)return VEIL_STORE_DUPLICATE;
  s->attempt=1;
  status=veil_store_verify_applied(s);if(status)return status;
  sqlite3_stmt *st=NULL;
  if(prepare(s,"INSERT INTO veil_checkpoint_committed_ops_v1(op,commitment_hash) VALUES(?,?)",&st))return VEIL_STORE_SQL;
  if(!bind_text(st,1,op)||!bind_text(st,2,hash)){sqlite3_finalize(st);return VEIL_STORE_SQL;}
  status=finish(st,SQLITE_DONE);if(status)return status;
  if(prepare(s,"UPDATE checkpoint SET revision=? WHERE slot=1 AND revision=?",&st))return VEIL_STORE_SQL;
  sqlite3_bind_int64(st,1,s->intent->next_rev);sqlite3_bind_int64(st,2,s->intent->base_rev);
  status=finish(st,SQLITE_DONE);if(status||sqlite3_changes(s->db)!=1)return VEIL_STORE_MISMATCH;
  int64_t actual=-1;if(scalar(s,"SELECT revision FROM checkpoint WHERE slot=1",&actual)||actual!=s->intent->next_rev)return VEIL_STORE_MISMATCH;
  if(prepare(s,"SELECT commitment_hash FROM veil_checkpoint_committed_ops_v1 WHERE op=?",&st))return VEIL_STORE_SQL;
  int good=bind_text(st,1,op)&&sqlite3_step(st)==SQLITE_ROW&&same_text(st,0,hash,64)&&sqlite3_step(st)==SQLITE_DONE;
  sqlite3_finalize(st);if(!good)return VEIL_STORE_MISMATCH;
  /* Fixture native SQLite mechanics only, NEVER a protected final receipt. */
  if(sqlite3_exec(s->db,"COMMIT",NULL,NULL,NULL)!=SQLITE_OK){s->phase=UNKNOWN;return VEIL_STORE_UNKNOWN;}
  s->phase=ENDED;return VEIL_STORE_OK;
}
veil_store_status veil_fixture_delete_session(veil_checked_store *s,const char *id) {
  veil_store_status status=guard(s,0);if(status)return status;if(!text_ok(id,1024))return VEIL_STORE_BOUND;
  sqlite3_stmt *st=NULL;if(prepare(s,"DELETE FROM records WHERE kind='SESSION' AND id=?",&st))return VEIL_STORE_SQL;
  if(!bind_text(st,1,id)){sqlite3_finalize(st);return VEIL_STORE_BOUND;}return finish(st,SQLITE_DONE);
}
veil_store_status veil_fixture_revision(veil_checked_store *s,int64_t *out) {
  if(!s||!out)return VEIL_STORE_BOUND;
  if(!pthread_equal(s->owner,pthread_self()))return VEIL_STORE_THREAD;
  if(!s->db||s->phase==CLOSED)return VEIL_STORE_LIFETIME;
  return scalar(s,"SELECT revision FROM checkpoint WHERE slot=1",out);
}
veil_store_status veil_fixture_reopen_exact_readback(veil_checked_store *s,const veil_authenticated_record *r,const veil_authenticated_intent *i,const char *hash) {
  /* Local SQLite observation only. Never authorizes UNKNOWN output release. */
  if(!i||!r||!hash_ok(hash))return VEIL_STORE_BOUND;
  veil_store_status status=veil_store_begin(s);if(status)return status;
  s->intent=i;s->phase=FROZEN;
  status=veil_store_verify_record(s,r);if(status)return status;
  status=veil_store_verify_intent(s,i);if(status)return status;
  int64_t revision=-1;if(scalar(s,"SELECT revision FROM checkpoint WHERE slot=1",&revision)||revision!=i->next_rev)return VEIL_STORE_MISMATCH;
  sqlite3_stmt *st=NULL;if(prepare(s,"SELECT commitment_hash FROM veil_checkpoint_committed_ops_v1 WHERE op=?",&st))return VEIL_STORE_SQL;
  int good=bind_text(st,1,i->op)&&sqlite3_step(st)==SQLITE_ROW&&same_text(st,0,hash,64)&&sqlite3_step(st)==SQLITE_DONE;
  sqlite3_finalize(st);return good?VEIL_STORE_OK:VEIL_STORE_MISMATCH;
}
veil_store_status veil_fixture_step_create(veil_fixture_step_tag tag,uint32_t sequence,const veil_authenticated_record *r,const veil_authenticated_intent *i,veil_authenticated_step **out) {
  if(!out)return VEIL_STORE_BOUND;*out=NULL;
  if(tag<VEIL_FIXTURE_IDENTITY||tag>VEIL_FIXTURE_OUTBOX||sequence>32)return VEIL_STORE_BOUND;
  if((tag==VEIL_FIXTURE_INBOX||tag==VEIL_FIXTURE_OUTBOX)?!i:!r)return VEIL_STORE_BOUND;
  veil_authenticated_step *s=calloc(1,sizeof(*s));if(!s)return VEIL_STORE_SQL;
  s->tag=(enum native_step_tag)tag;s->sequence=sequence;s->record=r;s->intent=i;*out=s;return VEIL_STORE_OK;
}
void veil_fixture_step_free(veil_authenticated_step **s){if(s&&*s){free(*s);*s=NULL;}}
veil_store_status veil_fixture_snapshot_expect(const veil_ciphertext_snapshot *snap,const char *kind,const char *id,const veil_authenticated_record *expected) {
  if(!snap||!text_ok(kind,32)||!text_ok(id,1024))return VEIL_STORE_BOUND;
  if(!pthread_equal(snap->owner,pthread_self()))return VEIL_STORE_THREAD;
  for(size_t n=0;n<snap->count;n++){
    const struct veil_snapshot_row *r=snap->rows[n];
    if(!strcmp(r->kind,kind)&&!strcmp(r->id,id))return expected&&expected->size==r->size&&!memcmp(expected->bytes,r->bytes,r->size)?VEIL_STORE_OK:VEIL_STORE_MISMATCH;
  }
  return expected?VEIL_STORE_MISMATCH:VEIL_STORE_OK;
}
#endif
