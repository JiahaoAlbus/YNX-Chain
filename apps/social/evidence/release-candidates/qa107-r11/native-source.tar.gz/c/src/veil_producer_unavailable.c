#include "veil_producer_private.h"
#include "../../protected-source/linux/ynx_source_platform_qualified.h"
#include "veil_source_private.h"
#include "../../protected-source/ynx_source_platform_private.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../../protected-source/linux/ynx_source_final_owner.h"
/* Default provider closure; replace by reviewed LINK integration only.
 * No dynamic/public provider installation, no fixture promotion.
 */
#ifdef VEIL_STORE_FIXTURE
veil_store_status veil_private_guard_acquire(veil_checked_store *s,const veil_verified_native_operation_lease *l,const veil_native_intent_handle *i,veil_private_effect_guard **g){(void)s;(void)l;(void)i;if(g)*g=0;return VEIL_STORE_REQUIRED;}
veil_store_status veil_private_guard_validate(veil_private_effect_guard *g){(void)g;return VEIL_STORE_REQUIRED;}
void veil_private_guard_release(veil_private_effect_guard **g){(void)g;}
veil_store_status veil_private_intent_retain(veil_private_effect_guard *g,const veil_native_intent_handle *i,veil_private_intent_pin **p,veil_private_intent_view *v){(void)g;(void)i;(void)v;if(p)*p=0;return VEIL_STORE_REQUIRED;}
void veil_private_intent_release(veil_private_intent_pin **p){(void)p;}
#endif
#ifdef VEIL_STORE_FIXTURE
/* Legacy fixture engine excludes registry TU; keep its old REQUIRED symbols
 * separate from normal registry-checked forwarding. Never link both groups. */
veil_store_status veil_private_step_borrow(veil_private_effect_guard *g,veil_private_intent_pin *p,const veil_native_ordered_step *s,veil_private_step_view *v){(void)g;(void)p;(void)s;(void)v;return VEIL_STORE_REQUIRED;}
veil_store_status veil_private_queue_borrow(veil_private_effect_guard *g,veil_private_intent_pin *p,const veil_native_inbound_intent *i,const veil_native_outbound_intent *o,veil_private_step_view *v){(void)g;(void)p;(void)i;(void)o;(void)v;return VEIL_STORE_REQUIRED;}
#endif
#ifdef VEIL_STORE_FIXTURE
veil_store_status veil_private_cas_exact(veil_private_effect_guard *g,veil_private_intent_pin *p,veil_private_cas_match **c,const unsigned char **b,size_t *n){(void)g;(void)p;if(c)*c=0;if(b)*b=0;if(n)*n=0;return VEIL_STORE_REQUIRED;}
#endif
#ifdef VEIL_STORE_FIXTURE
veil_store_status veil_private_final_checkpoint(veil_private_effect_guard *g,veil_private_intent_pin *p,const veil_ciphertext_snapshot *s){(void)g;(void)p;(void)s;return VEIL_STORE_REQUIRED;}
#endif
#ifdef VEIL_STORE_FIXTURE
veil_store_status veil_private_publish_once(veil_private_effect_guard *g,veil_private_intent_pin *p,veil_private_cas_match *c,const veil_private_recovery_admission *w,veil_native_verified_commit **out){(void)g;(void)p;(void)c;(void)w;if(out)*out=0;return VEIL_STORE_REQUIRED;}
#endif

#ifdef VEIL_STORE_FIXTURE
veil_store_status veil_private_recover_committed(veil_private_effect_guard *g,veil_private_intent_pin *p,veil_private_cas_match *m,const veil_private_recovery_admission **out){(void)g;(void)p;(void)m;if(out)*out=0;return VEIL_STORE_REQUIRED;}
#endif

veil_store_status veil_private_store_admit(const veil_required_native_admission *a,veil_private_store_binding **b,const char **p){
 if(!b||*b||!p)return VEIL_STORE_BOUND;*p=NULL;if(!a)return VEIL_STORE_REQUIRED;
 veil_store_status s=ynx_platform_store_admit(a,b,p);
 /* Failure cannot silently transfer a binding which the existing store-open
  * caller has no slot to retain. Exact platform contract keeps original owner. */
 if(s){if(*b)abort();*p=NULL;return s;}
 if(!*b||!*p){ynx_platform_store_release(b);*p=NULL;return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;
}
void veil_private_store_release(veil_private_store_binding **b){ynx_platform_store_release(b);}

#ifdef VEIL_STORE_FIXTURE
veil_store_status veil_private_guard_acquire_recovery(veil_checked_store *s,const veil_verified_native_operation_lease *l,const veil_native_intent_handle *i,veil_private_effect_guard **g){(void)s;(void)l;(void)i;if(g)*g=0;return VEIL_STORE_REQUIRED;}
veil_store_status veil_private_unknown_fence(veil_private_effect_guard *g,veil_private_intent_pin *p){(void)g;(void)p;return VEIL_STORE_REQUIRED;}
#endif
/* Normal Source SPI is now implemented by the statically linked private
 * platform client. Unbound physical provider still rejects REQUIRED. */

#include "veil_supplier_owner_private.h"
#include "../../protected-source/ynx_source_platform_private.h"
#include <pthread.h>
#include <stdlib.h>
/* Model A owner defaults: no opaque accepted-value constructor or fake free.
 * An unrecognized non-null owner cannot be destroyed/consumed by this group. */
/* Inventory/refcount protects RAM lifetime only; qualification resides in the
 * static protected provider's own hold and same-original fence. */
struct veil_private_prepared_input_owner{ynx_platform_prepared_hold *platform;pthread_t thread;size_t refs;int unknown;veil_store_status primary;veil_private_message_session_hold *message_parent;veil_source_hold *message_source;void *permission_v2;struct veil_private_prepared_input_owner *next;};
static pthread_mutex_t prepared_lock=PTHREAD_MUTEX_INITIALIZER;
static veil_private_prepared_input_owner *prepared_inventory;
static size_t prepared_count;
static veil_store_status prepared_recognized(const veil_private_prepared_input_owner *p){
 pthread_mutex_lock(&prepared_lock);const veil_private_prepared_input_owner *q=prepared_inventory;while(q&&q!=p)q=q->next;
 veil_store_status s=!q?VEIL_STORE_REQUIRED:!pthread_equal(q->thread,pthread_self())?VEIL_STORE_THREAD:VEIL_STORE_OK;pthread_mutex_unlock(&prepared_lock);return s;
}
static veil_store_status prepared_current(veil_private_prepared_input_owner *p){
 veil_store_status s=prepared_recognized(p);if(s)return s;if(p->unknown)return VEIL_STORE_UNKNOWN;
 if(p->permission_v2){s=(veil_store_status)ynx_sdk_native_core_rights_current_v2(p->permission_v2);if(s){if(!p->primary)p->primary=s;p->unknown=1;return VEIL_STORE_UNKNOWN;}}
 s=ynx_platform_prepared_current(p->platform);if(!s&&p->message_parent)s=veil_private_message_session_current(p->message_parent);if(!s&&p->message_source)s=ynx_source_client_current(p->message_source,0);if(s){if(!p->primary)p->primary=s;p->unknown=1;return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;
}
veil_store_status veil_private_prepare_accepted_inputs(const veil_product_accepted_origin_owner *a,const veil_product_accepted_device_owner *d,const veil_product_prepared_history_owner *h,const veil_selected_retained_original_owner *r,veil_private_prepared_input_owner **out){
 if(!out||*out)return VEIL_STORE_BOUND;if(!a||!d||!h||!r)return VEIL_STORE_REQUIRED;
 veil_private_prepared_input_owner *p=calloc(1,sizeof(*p));if(!p)return VEIL_STORE_SQL;
 pthread_mutex_lock(&prepared_lock);if(prepared_count>=32){pthread_mutex_unlock(&prepared_lock);free(p);return VEIL_STORE_BOUND;}prepared_count++;pthread_mutex_unlock(&prepared_lock);
 veil_store_status s=ynx_platform_prepare_original(a,d,h,r,&p->platform);
 if(s&&!p->platform){pthread_mutex_lock(&prepared_lock);prepared_count--;pthread_mutex_unlock(&prepared_lock);free(p);return s;}
 if(!p->platform){pthread_mutex_lock(&prepared_lock);prepared_count--;pthread_mutex_unlock(&prepared_lock);free(p);return VEIL_STORE_UNKNOWN;}
 p->thread=pthread_self();p->refs=1;pthread_mutex_lock(&prepared_lock);p->next=prepared_inventory;prepared_inventory=p;pthread_mutex_unlock(&prepared_lock);
 /* Transfer RAM custody even if final current becomes UNKNOWN: existing Rust
  * owning output convention cannot discard sole custody. Validation rejects. */
 /* A failed constructor may already own protected resources. Transfer that
  * exact partial for cleanup without another current/effect or capability
  * borrow. OK here is RAM custody only; prepared_current rejects UNKNOWN. */
 if(s){p->primary=s;p->unknown=1;}else{
  s=ynx_platform_prepared_current(p->platform);if(s){p->primary=s;p->unknown=1;}
 }
 *out=p;return VEIL_STORE_OK;
}
veil_store_status veil_private_prepared_input_retain(const veil_private_prepared_input_owner *original,veil_private_prepared_input_owner **out){
 if(!out||*out)return VEIL_STORE_BOUND;veil_store_status s=prepared_recognized(original);if(s)return s;
 veil_private_prepared_input_owner *p=(veil_private_prepared_input_owner *)original;if(p->refs>=32)return VEIL_STORE_BOUND;p->refs++;*out=p;return VEIL_STORE_OK;
}
veil_store_status veil_private_prepared_input_borrow(const veil_private_prepared_input_owner *original,const veil_required_native_admission **a,const veil_verified_native_operation_lease **l,const veil_native_intent_handle **i){
 if(!a||!l||!i)return VEIL_STORE_BOUND;*a=NULL;*l=NULL;*i=NULL;veil_private_prepared_input_owner *p=(veil_private_prepared_input_owner *)original;veil_store_status s=prepared_current(p);if(s)return s;
 s=ynx_platform_prepared_capabilities(p->platform,a,l,i);if(s||!*a||!*l||!*i){p->unknown=1;*a=NULL;*l=NULL;*i=NULL;return VEIL_STORE_UNKNOWN;}
 s=prepared_current(p);if(s){*a=NULL;*l=NULL;*i=NULL;}return s;
}
veil_store_status veil_private_prepared_input_validate(veil_private_effect_guard *g,veil_private_intent_pin *pin,const veil_private_prepared_input_owner *original){
 veil_private_prepared_input_owner *p=(veil_private_prepared_input_owner *)original;veil_store_status s=prepared_current(p);if(s)return s;if(!g||!pin)return VEIL_STORE_REQUIRED;
 s=ynx_platform_prepared_validate(p->platform,g,pin);if(s){p->unknown=1;return VEIL_STORE_UNKNOWN;}return prepared_current(p);
}
veil_store_status veil_private_prepared_input_drop(veil_private_prepared_input_owner **slot){
 if(!slot)return VEIL_STORE_BOUND;if(!*slot)return VEIL_STORE_OK;veil_private_prepared_input_owner *p=*slot;veil_store_status s=prepared_recognized(p);if(s)return s;
 if(p->refs>1){p->refs--;*slot=NULL;return VEIL_STORE_OK;}ynx_platform_prepared_hold *original=p->platform;
 if(p->message_source){veil_source_hold *held=p->message_source;s=ynx_source_client_close(&p->message_source);if(s||p->message_source){if(p->message_source!=held)abort();p->unknown=1;return VEIL_STORE_UNKNOWN;}}
 s=ynx_platform_prepared_close(&p->platform);if(s||p->platform){if(p->platform!=original)abort();p->unknown=1;return VEIL_STORE_UNKNOWN;}
 if(p->permission_v2){void*before=p->permission_v2;s=(veil_store_status)ynx_sdk_native_core_rights_close_v2(&p->permission_v2);if(s||p->permission_v2){if(p->permission_v2!=before)abort();if(!p->primary)p->primary=s;p->unknown=1;return VEIL_STORE_UNKNOWN;}}
 if(p->message_parent){s=veil_private_message_session_close(&p->message_parent);if(s||p->message_parent){p->unknown=1;return VEIL_STORE_UNKNOWN;}}
 pthread_mutex_lock(&prepared_lock);veil_private_prepared_input_owner **q=&prepared_inventory;while(*q&&*q!=p)q=&(*q)->next;if(!*q)abort();*q=p->next;prepared_count--;pthread_mutex_unlock(&prepared_lock);memset(p,0,sizeof(*p));free(p);*slot=NULL;return VEIL_STORE_OK;
}
/* Final RAM ownership is distinct from prepared authority. Registration below
 * follows only a typed protected final hold returned by terminal/recover. The
 * inventory is memory safety, never independent terminal verification. */
struct veil_native_verified_commit{ynx_platform_final_hold *platform;pthread_t thread;size_t refs;int unknown;veil_store_status primary;const veil_native_intent_handle *intent;struct veil_native_verified_commit *next;};
static pthread_mutex_t final_lock=PTHREAD_MUTEX_INITIALIZER;
static veil_native_verified_commit *final_inventory;
static size_t final_count;
static veil_store_status final_recognized(const veil_native_verified_commit *p){
 pthread_mutex_lock(&final_lock);const veil_native_verified_commit *q=final_inventory;while(q&&q!=p)q=q->next;
 veil_store_status s=!q?VEIL_STORE_REQUIRED:!pthread_equal(q->thread,pthread_self())?VEIL_STORE_THREAD:VEIL_STORE_OK;pthread_mutex_unlock(&final_lock);return s;
}
static veil_native_verified_commit *final_reserve(void){
 veil_native_verified_commit *c=calloc(1,sizeof(*c));if(!c)return NULL;pthread_mutex_lock(&final_lock);if(final_count>=32){pthread_mutex_unlock(&final_lock);free(c);return NULL;}final_count++;pthread_mutex_unlock(&final_lock);c->thread=pthread_self();c->refs=1;return c;
}
static void final_unreserve(veil_native_verified_commit *c){pthread_mutex_lock(&final_lock);final_count--;pthread_mutex_unlock(&final_lock);memset(c,0,sizeof(*c));free(c);}
static veil_store_status final_current(veil_native_verified_commit *c){veil_store_status s=final_recognized(c);if(s)return s;if(c->unknown)return VEIL_STORE_UNKNOWN;s=ynx_platform_final_current(c->platform);if(s){if(!c->primary)c->primary=s;c->unknown=1;return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;}
static veil_store_status final_transfer(veil_native_verified_commit *c,veil_store_status s,veil_native_verified_commit **out){
 /* The reserved RAM slot exists before the protected operation. A partial
  * original hold is custody, not a successful terminal: keep that SAME hold
  * reachable for explicit cleanup and prohibit every authority borrow. The
  * OK below reports owning transfer only, as for a late-current refusal. */
 if(s&&!c->platform){final_unreserve(c);return s;}
 if(!c->platform){final_unreserve(c);return VEIL_STORE_UNKNOWN;}
 if(s){c->primary=s;c->unknown=1;}
 pthread_mutex_lock(&final_lock);c->next=final_inventory;final_inventory=c;pthread_mutex_unlock(&final_lock);
 /* Preserve owning RAM when the final current fence fails. Borrow refuses the
  * sticky uncertain result; disposal does not settle independent history. */
 /* No new current/borrow work after the producer's original refusal. */
 if(!c->unknown){veil_store_status late=ynx_platform_final_current(c->platform);if(late){if(!c->primary)c->primary=late;c->unknown=1;}}*out=c;return VEIL_STORE_OK;
}
veil_store_status veil_private_verified_commit_publish(ynx_platform_original_hold *h,const veil_native_intent_handle *i,veil_private_cas_match *m,const veil_private_recovery_admission *r,veil_native_verified_commit **out){
 if(!out||*out)return VEIL_STORE_BOUND;if(!h||!i||!m)return VEIL_STORE_REQUIRED;
 veil_native_verified_commit *c=final_reserve();if(!c)return VEIL_STORE_BOUND;c->intent=i;
 veil_store_status s=ynx_platform_terminal(h,i,m,r,&c->platform);return final_transfer(c,s,out);
}
veil_store_status veil_private_verified_commit_adopt_partial(ynx_platform_final_hold **slot,const veil_native_intent_handle *intent,veil_store_status cause,veil_native_verified_commit **out){
 if(!slot||!*slot||!intent||!cause||!out||*out)return VEIL_STORE_BOUND;
 veil_native_verified_commit *c=final_reserve();if(!c)return VEIL_STORE_BOUND;
 c->platform=*slot;c->intent=intent;*slot=NULL;
 return final_transfer(c,cause,out);
}
veil_store_status veil_private_verified_commit_retain(const veil_native_verified_commit *original,veil_native_verified_commit **out){
 if(!out||*out)return VEIL_STORE_BOUND;veil_store_status s=final_recognized(original);if(s)return s;veil_native_verified_commit *c=(veil_native_verified_commit *)original;if(c->refs>=32)return VEIL_STORE_BOUND;c->refs++;*out=c;return VEIL_STORE_OK;
}
veil_store_status veil_private_verified_commit_borrow(const veil_native_verified_commit *original,const veil_native_intent_handle **i,const veil_private_authenticated_once_owner **a,const veil_private_protected_output_owner **o){
 if(!i||!a||!o)return VEIL_STORE_BOUND;*i=NULL;*a=NULL;*o=NULL;veil_native_verified_commit *c=(veil_native_verified_commit *)original;veil_store_status s=final_current(c);if(s)return s;
 s=ynx_platform_final_borrow(c->platform,i,a,o);if(s||!*i||!*a||!*o||(c->intent&&c->intent!=*i)){if(!c->primary)c->primary=s?s:VEIL_STORE_BOUND;c->unknown=1;*i=NULL;*a=NULL;*o=NULL;return VEIL_STORE_UNKNOWN;}
 if(!c->intent)c->intent=*i;s=final_current(c);if(s){*i=NULL;*a=NULL;*o=NULL;}return s;
}
veil_store_status veil_private_verified_commit_acknowledge(veil_private_effect_guard *g,veil_private_intent_pin *pin,const veil_private_prepared_input_owner *original,const veil_native_verified_commit *commit){
 veil_private_prepared_input_owner *p=(veil_private_prepared_input_owner *)original;veil_native_verified_commit *c=(veil_native_verified_commit *)commit;veil_store_status s=prepared_current(p);if(s)return s;s=final_current(c);if(s)return s;if(!g||!pin)return VEIL_STORE_REQUIRED;
 s=ynx_platform_final_acknowledge(c->platform,p->platform,g,pin);if(s){if(!c->primary)c->primary=s;c->unknown=1;return VEIL_STORE_UNKNOWN;}s=prepared_current(p);if(s){c->unknown=1;return VEIL_STORE_UNKNOWN;}return final_current(c);
}
veil_store_status veil_private_verified_commit_recover(veil_private_effect_guard *g,veil_private_intent_pin *pin,const veil_private_prepared_input_owner *original,veil_native_verified_commit **out){
 if(!out||*out)return VEIL_STORE_BOUND;veil_private_prepared_input_owner *p=(veil_private_prepared_input_owner *)original;veil_store_status s=prepared_current(p);if(s)return s;if(!g||!pin)return VEIL_STORE_REQUIRED;veil_native_verified_commit *c=final_reserve();if(!c)return VEIL_STORE_BOUND;
 s=ynx_platform_final_recover(p->platform,g,pin,&c->platform);return final_transfer(c,s,out);
}
veil_store_status veil_private_verified_commit_drop(veil_native_verified_commit **slot){
 if(!slot)return VEIL_STORE_BOUND;if(!*slot)return VEIL_STORE_OK;veil_native_verified_commit *c=*slot;veil_store_status s=final_recognized(c);if(s)return s;
 if(c->refs>1){c->refs--;*slot=NULL;return VEIL_STORE_OK;}ynx_platform_final_hold *original=c->platform;s=ynx_platform_final_close(&c->platform);if(s||c->platform){if(c->platform!=original)abort();if(!c->primary)c->primary=s?s:VEIL_STORE_BOUND;c->unknown=1;return VEIL_STORE_UNKNOWN;}
 pthread_mutex_lock(&final_lock);veil_native_verified_commit **q=&final_inventory;while(*q&&*q!=c)q=&(*q)->next;if(!*q)abort();*q=c->next;final_count--;pthread_mutex_unlock(&final_lock);memset(c,0,sizeof(*c));free(c);*slot=NULL;return VEIL_STORE_OK;
}

static int final_original_bytes_valid(ynx_original_bytes b,size_t *total){
 if(!b.data||!b.size||b.size>65536||*total>393216-b.size)return 0;*total+=b.size;return 1;
}
veil_store_status veil_private_verified_commit_originals(const veil_native_verified_commit *original,ynx_independent_commit_originals *out){
 if(!out)return VEIL_STORE_BOUND;memset(out,0,sizeof(*out));
 veil_native_verified_commit *c=(veil_native_verified_commit *)original;veil_store_status st=final_current(c);if(st)return st;
 ynx_independent_commit_originals v={0};st=ynx_platform_final_originals(c->platform,&v);size_t total=0;
 if(!st){
  if(v.version!=1||v.checkpoint_count>255||v.terminal_issuer_count>255||v.terminal_anchor_count!=v.terminal_issuer_count||(v.checkpoint_count&&!v.checkpoint_predecessors)||(v.terminal_issuer_count&&(!v.terminal_issuer_predecessors||!v.terminal_anchor_predecessors)))st=VEIL_STORE_BOUND;
  ynx_original_bytes singles[]={v.engine_issuer,v.engine_anchor,v.checkpoint_anchor,v.terminal_issuer,v.terminal_anchor};
  for(size_t n=0;n<5&&!st;n++)if(!final_original_bytes_valid(singles[n],&total))st=VEIL_STORE_BOUND;
  for(size_t n=0;n<v.checkpoint_count&&!st;n++)if(!final_original_bytes_valid(v.checkpoint_predecessors[n],&total))st=VEIL_STORE_BOUND;
  for(size_t n=0;n<v.terminal_issuer_count&&!st;n++)if(!final_original_bytes_valid(v.terminal_issuer_predecessors[n],&total)||!final_original_bytes_valid(v.terminal_anchor_predecessors[n],&total))st=VEIL_STORE_BOUND;
 }
 if(st){if(!c->primary)c->primary=st;c->unknown=1;return VEIL_STORE_UNKNOWN;}
 st=final_current(c);if(st)return st;*out=v;return VEIL_STORE_OK;
}

veil_store_status veil_private_verified_commit_device_current(const veil_native_verified_commit *original,const ynx_device_original_input *input){
 veil_native_verified_commit *c=(veil_native_verified_commit *)original;veil_store_status st=final_current(c);if(st)return st;
 if(!input||input->version!=1||input->predecessor_count>255||(input->predecessor_count&&!input->predecessors))return VEIL_STORE_BOUND;
 size_t total=0;ynx_original_bytes singles[]={input->final,input->current,input->terminal,input->checkpoint};
 for(size_t n=0;n<4;n++)if(!final_original_bytes_valid(singles[n],&total))return VEIL_STORE_BOUND;
 for(size_t n=0;n<input->predecessor_count;n++)if(!final_original_bytes_valid(input->predecessors[n],&total))return VEIL_STORE_BOUND;
 /* This real root, not the public originals, supplies independent latest
  * revocation head/floor and device enrollment. Never retry or renew it. */
 st=ynx_platform_final_device_current(c->platform,input);
 if(st){if(!c->primary)c->primary=st;c->unknown=1;return VEIL_STORE_UNKNOWN;}
 return final_current(c);
}

veil_store_status veil_private_verified_commit_restore_device(const ynx_device_original_input *input,const unsigned char *classic,size_t classic_size,const unsigned char *pq,size_t pq_size,veil_native_verified_commit **out){
 if(!out||*out)return VEIL_STORE_BOUND;
 if(!input||input->version!=1||input->predecessor_count>255||(input->predecessor_count&&!input->predecessors)||!classic||classic_size!=33||classic[0]!=5||!pq||pq_size!=2592)return VEIL_STORE_BOUND;
 size_t total=0;ynx_original_bytes singles[]={input->final,input->current,input->terminal,input->checkpoint};
 for(size_t n=0;n<4;n++)if(!final_original_bytes_valid(singles[n],&total))return VEIL_STORE_BOUND;
 for(size_t n=0;n<input->predecessor_count;n++)if(!final_original_bytes_valid(input->predecessors[n],&total))return VEIL_STORE_BOUND;
 /* Reserve bounded owner custody BEFORE any provider restoration. It is not
  * admitted by inventory membership or successful allocation. */
 veil_native_verified_commit *c=final_reserve();if(!c)return VEIL_STORE_BOUND;
 veil_store_status st=ynx_platform_device_restore(input,classic,classic_size,pq,pq_size,&c->platform);
 st=final_transfer(c,st,out);if(st)return st;
 /* A refused restore can transfer partial cleanup custody, but cannot perform
  * a second provider borrow or device validation after that first refusal. */
 if(c->unknown)return VEIL_STORE_OK;
 const veil_native_intent_handle *i=NULL;const veil_private_authenticated_once_owner *a=NULL;const veil_private_protected_output_owner *o=NULL;
 st=veil_private_verified_commit_borrow(c,&i,&a,&o);
 if(!st)st=veil_private_verified_commit_device_current(c,input);
 /* An already returned real root remains owned even on a late refusal. The
  * caller must retain UNKNOWN and explicitly close; never reopen automatically. */
 if(st){if(!c->primary)c->primary=st;c->unknown=1;}
 return VEIL_STORE_OK;
}

/* RAM registry only protects custody/thread safety. Only the static platform
 * session returned from a true verified final root can qualify this owner. */
struct veil_private_message_session_hold{veil_native_verified_commit *root;ynx_platform_message_session_hold *platform;pthread_t thread;size_t refs;int unknown;veil_store_status primary;void *permission_context;ynx_device_original_input device;unsigned char *device_storage;ynx_original_bytes *device_prefix;struct veil_private_message_session_hold *next;};
static pthread_mutex_t message_lock=PTHREAD_MUTEX_INITIALIZER;
static veil_private_message_session_hold *message_inventory;static size_t message_count;
static veil_store_status message_recognized(veil_private_message_session_hold *h){
 pthread_mutex_lock(&message_lock);veil_private_message_session_hold *p=message_inventory;while(p&&p!=h)p=p->next;
 veil_store_status s=!p?VEIL_STORE_REQUIRED:!pthread_equal(p->thread,pthread_self())?VEIL_STORE_THREAD:VEIL_STORE_OK;pthread_mutex_unlock(&message_lock);return s;
}
static void message_uncertain(veil_private_message_session_hold *h,veil_store_status s){if(!h->primary)h->primary=s?s:VEIL_STORE_BOUND;h->unknown=1;}
static void message_free(veil_private_message_session_hold *h){
 if(h->root||h->platform||h->permission_context)abort();free(h->device_prefix);free(h->device_storage);pthread_mutex_lock(&message_lock);veil_private_message_session_hold **p=&message_inventory;while(*p&&*p!=h)p=&(*p)->next;if(!*p)abort();*p=h->next;message_count--;pthread_mutex_unlock(&message_lock);memset(h,0,sizeof(*h));free(h);
}
veil_store_status veil_private_message_session_current(veil_private_message_session_hold *h){
 veil_store_status s=message_recognized(h);if(s)return s;if(h->unknown||!h->platform||!h->root)return VEIL_STORE_UNKNOWN;
 s=veil_private_verified_commit_device_current(h->root,&h->device);if(!s)s=(veil_store_status)ynx_sdk_native_message_context_current_v2(h->permission_context);if(!s)s=ynx_platform_message_session_current(h->platform);if(!s)s=veil_private_verified_commit_device_current(h->root,&h->device);if(!s)s=(veil_store_status)ynx_sdk_native_message_context_current_v2(h->permission_context);
 if(s){message_uncertain(h,s);return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;
}
static veil_store_status message_device_copy(veil_private_message_session_hold*h,const ynx_device_original_input*d){
 if(!d||d->version!=1||d->predecessor_count>255||(d->predecessor_count&&!d->predecessors))return VEIL_STORE_BOUND;
 size_t total=0;ynx_original_bytes singles[]={d->final,d->current,d->terminal,d->checkpoint};
 for(size_t n=0;n<4;n++)if(!final_original_bytes_valid(singles[n],&total))return VEIL_STORE_BOUND;
 for(size_t n=0;n<d->predecessor_count;n++)if(!final_original_bytes_valid(d->predecessors[n],&total))return VEIL_STORE_BOUND;
 h->device_storage=malloc(total);if(!h->device_storage)return VEIL_STORE_SQL;
 if(d->predecessor_count){h->device_prefix=calloc(d->predecessor_count,sizeof(*h->device_prefix));if(!h->device_prefix)return VEIL_STORE_SQL;}
 h->device=*d;h->device.predecessors=h->device_prefix;size_t offset=0;ynx_original_bytes*dest[]={&h->device.final,&h->device.current,&h->device.terminal,&h->device.checkpoint};
 for(size_t n=0;n<4;n++){memcpy(h->device_storage+offset,singles[n].data,singles[n].size);*dest[n]=(ynx_original_bytes){h->device_storage+offset,singles[n].size};offset+=singles[n].size;}
 for(size_t n=0;n<d->predecessor_count;n++){ynx_original_bytes original=d->predecessors[n];memcpy(h->device_storage+offset,original.data,original.size);h->device_prefix[n]=(ynx_original_bytes){h->device_storage+offset,original.size};offset+=original.size;}return VEIL_STORE_OK;
}
/* Old private caller lacks the genuine device binding borrow. Public original
 * transport version remains1; do not treat the old entry as a v2 alias. */
veil_store_status veil_private_message_session_acquire(const veil_native_verified_commit *root,const ynx_message_session_input *input,veil_private_message_session_hold **out){(void)root;(void)input;if(!out||*out)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}
veil_store_status veil_private_message_session_acquire_v2(const veil_native_verified_commit *root,const ynx_device_original_input*device,const ynx_native_core_device_binding_v2*binding,const ynx_message_session_input *input,veil_private_message_session_hold **out){
 if(!out||*out||!binding)return VEIL_STORE_BOUND;veil_store_status s=veil_private_verified_commit_device_current(root,device);if(s)return s;
 if(!input||input->version!=1||input->issuer_history_count>255||input->anchor_history_count>255||(input->issuer_history_count&&!input->issuer_history)||(input->anchor_history_count&&!input->anchor_history))return VEIL_STORE_BOUND;
 size_t total=0;ynx_original_bytes singles[]={input->issuer_credential,input->anchor_credential,input->purpose,input->association_issuer,input->association_anchor,input->issuer_enrollment,input->anchor_enrollment};
 for(size_t n=0;n<7;n++)if(!final_original_bytes_valid(singles[n],&total))return VEIL_STORE_BOUND;
 for(size_t n=0;n<input->issuer_history_count;n++)if(!final_original_bytes_valid(input->issuer_history[n],&total))return VEIL_STORE_BOUND;
 for(size_t n=0;n<input->anchor_history_count;n++)if(!final_original_bytes_valid(input->anchor_history[n],&total))return VEIL_STORE_BOUND;
 veil_private_message_session_hold *h=calloc(1,sizeof(*h));if(!h)return VEIL_STORE_BOUND;
 pthread_mutex_lock(&message_lock);if(message_count>=32){pthread_mutex_unlock(&message_lock);free(h);return VEIL_STORE_BOUND;}message_count++;h->refs=1;h->thread=pthread_self();h->next=message_inventory;message_inventory=h;pthread_mutex_unlock(&message_lock);
 s=message_device_copy(h,device);if(s){message_free(h);return s;}
 s=veil_private_verified_commit_retain(root,&h->root);
 if(s){if(h->root){message_uncertain(h,s);*out=h;return VEIL_STORE_UNKNOWN;}message_free(h);return s;}
 s=veil_private_verified_commit_device_current(h->root,&h->device);if(!s)s=(veil_store_status)ynx_sdk_native_message_context_open_v2(binding,&h->permission_context);
 if(s){if(h->permission_context){message_uncertain(h,s);*out=h;return VEIL_STORE_UNKNOWN;}veil_store_status dropped=veil_private_verified_commit_drop(&h->root);if(dropped||h->root){message_uncertain(h,dropped);*out=h;return VEIL_STORE_UNKNOWN;}message_free(h);return s;}
 s=ynx_platform_message_session_acquire(h->root->platform,input,&h->platform);
 if(!h->platform){
  void*context=h->permission_context;veil_store_status dropped=(veil_store_status)ynx_sdk_native_message_context_close_v2(&h->permission_context);if(dropped||h->permission_context){if(h->permission_context!=context)abort();message_uncertain(h,dropped);*out=h;return VEIL_STORE_UNKNOWN;}
  dropped=veil_private_verified_commit_drop(&h->root);if(dropped||h->root){message_uncertain(h,dropped);*out=h;return VEIL_STORE_UNKNOWN;}
  message_free(h);return s?s:VEIL_STORE_UNKNOWN;
 }
 *out=h;if(s){message_uncertain(h,s);return VEIL_STORE_UNKNOWN;}
 return veil_private_message_session_current(h);
}
veil_store_status veil_private_message_session_projection(veil_private_message_session_hold *h,ynx_message_session_projection *out){
 if(!out)return VEIL_STORE_BOUND;memset(out,0,sizeof(*out));veil_store_status s=veil_private_message_session_current(h);if(s)return s;
 ynx_message_session_projection p={0};s=ynx_platform_message_session_projection(h->platform,&p);
 if(!s&&(p.version!=1||!p.local_name.data||!p.remote_name.data||!p.local_name.size||p.local_name.size>128||!p.remote_name.size||p.remote_name.size>128||!p.local_device||p.local_device>127||!p.remote_device||p.remote_device>127||!p.relation_revision||p.purpose_expires_ms<=0))s=VEIL_STORE_BOUND;
 if(!s)s=veil_private_message_session_current(h);if(s){message_uncertain(h,s);return VEIL_STORE_UNKNOWN;}*out=p;return VEIL_STORE_OK;
}
veil_store_status veil_private_message_session_close(veil_private_message_session_hold **out){
 if(!out)return VEIL_STORE_BOUND;if(!*out)return VEIL_STORE_OK;veil_private_message_session_hold *h=*out;veil_store_status s=message_recognized(h);if(s)return s;
 if(h->refs>1){h->refs--;*out=NULL;return VEIL_STORE_OK;}
 if(h->platform){ynx_platform_message_session_hold *original=h->platform;s=ynx_platform_message_session_close(&h->platform);if(s||h->platform){if(h->platform!=original)abort();message_uncertain(h,s);return VEIL_STORE_UNKNOWN;}}
 if(h->permission_context){void*original=h->permission_context;s=(veil_store_status)ynx_sdk_native_message_context_close_v2(&h->permission_context);if(s||h->permission_context){if(h->permission_context!=original)abort();message_uncertain(h,s);return VEIL_STORE_UNKNOWN;}}
 s=veil_private_verified_commit_drop(&h->root);if(s||h->root){message_uncertain(h,s);return VEIL_STORE_UNKNOWN;}message_free(h);*out=NULL;return VEIL_STORE_OK;
}

veil_store_status veil_private_message_operation_prepare(veil_private_message_session_hold *h,const ynx_message_operation_input *i,veil_private_prepared_input_owner **out){
 if(!out||*out)return VEIL_STORE_BOUND;veil_store_status s=veil_private_message_session_current(h);if(s)return s;
 if(!i||i->version!=1||(i->direction!=1&&i->direction!=2)||i->issued_ms<=0||i->expires_ms<=i->issued_ms||i->expires_ms-i->issued_ms>30000)return VEIL_STORE_BOUND;
 unsigned char nz=0;for(size_t n=0;n<16;n++)nz|=i->logical[n];if(!nz)return VEIL_STORE_BOUND;nz=0;for(size_t n=0;n<32;n++)nz|=i->nonce[n];if(!nz)return VEIL_STORE_BOUND;
 if(h->refs>=32)return VEIL_STORE_BOUND;veil_private_prepared_input_owner *p=calloc(1,sizeof(*p));if(!p)return VEIL_STORE_SQL;
 pthread_mutex_lock(&prepared_lock);if(prepared_count>=32){pthread_mutex_unlock(&prepared_lock);free(p);return VEIL_STORE_BOUND;}prepared_count++;p->thread=pthread_self();p->refs=1;p->next=prepared_inventory;prepared_inventory=p;pthread_mutex_unlock(&prepared_lock);
 h->refs++;p->message_parent=h;
 uint64_t deadline=0;s=(veil_store_status)ynx_sdk_native_message_budget_v2(h->permission_context,&deadline);
 struct timespec realtime;uint64_t mono=0;if(!s&&(clock_gettime(CLOCK_REALTIME,&realtime)||ynx_source_monotonic_now_v1(&mono)))s=VEIL_STORE_UNKNOWN;
 if(!s){int64_t now=(int64_t)realtime.tv_sec*1000+realtime.tv_nsec/1000000;if(now<i->issued_ms||now>=i->expires_ms)s=VEIL_STORE_LIFETIME;else{uint64_t remain=(uint64_t)(i->expires_ms-now)*1000000u;if(UINT64_MAX-mono<remain)s=VEIL_STORE_BOUND;else if(mono+remain<deadline)deadline=mono+remain;}}
 unsigned char original[112]={ 'Y','N','X','M','O','P','2',0 };size_t pos=8;
 uint32_t words[]={i->version,i->direction};for(unsigned n=0;n<2;n++)for(int shift=24;shift>=0;shift-=8)original[pos++]=(unsigned char)(words[n]>>shift);
 memcpy(original+pos,i->logical,16);pos+=16;memcpy(original+pos,i->request_digest,32);pos+=32;memcpy(original+pos,i->nonce,32);pos+=32;
 uint64_t times[]={(uint64_t)i->issued_ms,(uint64_t)i->expires_ms};for(unsigned n=0;n<2;n++)for(int shift=56;shift>=0;shift-=8)original[pos++]=(unsigned char)(times[n]>>shift);
 /* Actual outgoing/incoming protected state change needs read, seal, write,
  * key-global nonce and CAS. Exact named set, never blanket policy promotion. */
 if(!s)s=(veil_store_status)ynx_sdk_native_message_rights_borrow_v2(h->permission_context,(ynx_original_bytes){original,sizeof(original)},3,(1u<<1)|(1u<<2)|(1u<<3)|(1u<<4)|(1u<<5),deadline,&p->permission_v2);
 if(s){if(!p->primary)p->primary=s;p->unknown=1;}else s=ynx_platform_message_prepare(h->platform,i,&p->platform);
 if(!p->platform){veil_store_status dropped=veil_private_prepared_input_drop(&p);if(dropped||p){if(p)p->unknown=1;*out=p;return VEIL_STORE_OK;}return s?s:VEIL_STORE_UNKNOWN;}
 /* Transfer partial custody using the inherited Prepared owning convention:
  * returned handle is retained, but capabilities/current reject uncertainty. */
 if(s)p->unknown=1;else if(prepared_current(p))p->unknown=1;*out=p;return VEIL_STORE_OK;
}
veil_store_status veil_private_message_operation_current(veil_private_prepared_input_owner *p){return prepared_current(p);}
static veil_store_status message_operation_source(veil_private_prepared_input_owner *p){
 veil_store_status s=prepared_current(p);if(s)return s;if(!p->message_parent)return VEIL_STORE_REQUIRED;
 if(!p->message_source){s=ynx_source_client_prepared_acquire(p,&p->message_source);if(s||!p->message_source){p->unknown=1;return VEIL_STORE_UNKNOWN;}}return prepared_current(p);
}
veil_store_status veil_private_message_operation_plan(veil_private_prepared_input_owner *p,ynx_original_native_plan *out){
 if(!out)return VEIL_STORE_BOUND;memset(out,0,sizeof(*out));veil_store_status s=message_operation_source(p);if(s)return s;s=ynx_source_client_original_native_plan(p->message_source,out);if(!s)s=prepared_current(p);if(s){memset(out,0,sizeof(*out));p->unknown=1;return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;
}
veil_store_status veil_private_message_operation_enter(veil_private_prepared_input_owner *p){veil_store_status s=message_operation_source(p);if(s)return s;s=ynx_source_client_enter(p->message_source);if(!s)s=prepared_current(p);if(s){p->unknown=1;return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;}
veil_store_status veil_private_message_operation_snapshot(veil_private_prepared_input_owner *p,ynx_source_snapshot_hold **out){if(!out||*out)return VEIL_STORE_BOUND;veil_store_status s=message_operation_source(p);if(s)return s;s=ynx_source_client_snapshot_acquire(p->message_source,p,out);if(s){p->unknown=1;return s;}return prepared_current(p);}

veil_store_status veil_private_verified_commit_snapshot_publish(ynx_platform_snapshot_hold *h,ynx_storage_attempt **held,const veil_native_intent_handle *intent,const ynx_native_computed_step *steps,size_t count,uint32_t queue,ynx_original_bytes wire,veil_native_verified_commit **out){
 if(!out||*out||!held||*held)return VEIL_STORE_BOUND;if(!h||!intent)return VEIL_STORE_REQUIRED;
 /* The codec does not issue final evidence. Existing same-owner SQL producer
  * and actual independent publish_once alone can return verified custody. */
 return ynx_qualified_snapshot_commit(h,intent,steps,count,queue,wire,held,out);
}
