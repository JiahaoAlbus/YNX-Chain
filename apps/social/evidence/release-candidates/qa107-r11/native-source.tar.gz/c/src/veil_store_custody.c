#include "veil_store_custody.h"
#include <pthread.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

struct veil_custody_watch {
  pthread_t owner;
  int parent_fd,file_fd;
  struct stat parent,file;
  char path[VEIL_CUSTODY_PATH_MAX+1];
};
static int same_inode(const struct stat *a,const struct stat *b) {
  return a->st_dev==b->st_dev&&a->st_ino==b->st_ino;
}
static int private_file(const struct stat *s) {
  return S_ISREG(s->st_mode)&&s->st_uid==geteuid()&&s->st_nlink==1&&(s->st_mode&07777)==0600;
}
static int directory_ok(const struct stat *s,int last) {
  if(!S_ISDIR(s->st_mode))return 0;
  if(last)return s->st_uid==geteuid()&&(s->st_mode&07777)==0700;
  if(s->st_uid!=0&&s->st_uid!=geteuid())return 0;
  if(s->st_mode&0002)return 0;
  if((s->st_mode&0020)&&!(s->st_uid==0&&s->st_gid==0))return 0;
  return 1;
}
/* Separate readonly OS pin, NOT SQLite's private FD. HAS_MOVED is the public
 * Unix VFS cross-check. Path traversal never follows symlinks, including parent.
 * No claim of atomic exclusion against malicious same-UID rename/ABA races. */
static veil_store_status walk_path(const char *path,int *parent,int *file,struct stat *ps,struct stat *fs) {
  *parent=-1;*file=-1;
#if !defined(__APPLE__) && !defined(__linux__)
  (void)path;(void)ps;(void)fs;return VEIL_STORE_REQUIRED;
#else
  if(getuid()!=geteuid()||!path||path[0]!='/')return VEIL_STORE_REQUIRED;
  size_t n=strnlen(path,VEIL_CUSTODY_PATH_MAX+1);
  if(n<2||n>VEIL_CUSTODY_PATH_MAX||path[n-1]=='/')return VEIL_STORE_BOUND;
  char copy[VEIL_CUSTODY_PATH_MAX+1];memcpy(copy,path,n+1);
  int d=open("/",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
  if(d<0)return VEIL_STORE_REQUIRED;
  char *part=copy+1;
  for(;;) {
    char *end=strchr(part,'/');if(end)*end=0;
    size_t len=strlen(part);
    if(!len||len>255||!strcmp(part,".")||!strcmp(part,"..")){close(d);return VEIL_STORE_BOUND;}
    if(!end) {
      if(fstat(d,ps)||!directory_ok(ps,1)){close(d);return VEIL_STORE_REQUIRED;}
      int f=openat(d,part,O_RDONLY|O_NOFOLLOW|O_CLOEXEC|O_NONBLOCK);
      if(f<0){close(d);return VEIL_STORE_REQUIRED;}
      if(fstat(f,fs)||!private_file(fs)){close(f);close(d);return VEIL_STORE_REQUIRED;}
      *parent=d;*file=f;return VEIL_STORE_OK;
    }
    int next=openat(d,part,O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
    close(d);d=next;
    struct stat st;
    if(d<0)return VEIL_STORE_REQUIRED;
    if(fstat(d,&st)||!directory_ok(&st,0)){close(d);return VEIL_STORE_REQUIRED;}
    part=end+1;
  }
#endif
}
veil_store_status veil_custody_watch_open(const char *path,veil_custody_watch **out) {
  if(!out)return VEIL_STORE_BOUND;
  *out=NULL;int parent=-1,file=-1;struct stat ps,fs;
  veil_store_status st=walk_path(path,&parent,&file,&ps,&fs);if(st)return st;
  veil_custody_watch *w=calloc(1,sizeof(*w));
  if(!w){close(file);close(parent);return VEIL_STORE_SQL;}
  w->owner=pthread_self();w->parent_fd=parent;w->file_fd=file;w->parent=ps;w->file=fs;
  strcpy(w->path,path);*out=w;return VEIL_STORE_OK;
}
static veil_store_status watch_owner(veil_custody_watch *w) {
  if(!w)return VEIL_STORE_REQUIRED;
  return pthread_equal(w->owner,pthread_self())?VEIL_STORE_OK:VEIL_STORE_THREAD;
}
veil_store_status veil_custody_watch_check(sqlite3 *db,veil_custody_watch *w) {
  veil_store_status st=watch_owner(w);if(st)return st;
  if(!db)return VEIL_STORE_LIFETIME;
  const char *name=sqlite3_db_filename(db,"main");
  if(!name||strnlen(name,VEIL_CUSTODY_PATH_MAX+1)>VEIL_CUSTODY_PATH_MAX||strcmp(name,w->path))return VEIL_STORE_MISMATCH;
  sqlite3_vfs *vfs=NULL;
  if(sqlite3_file_control(db,"main",SQLITE_FCNTL_VFS_POINTER,&vfs)!=SQLITE_OK||!vfs||!vfs->zName||strcmp(vfs->zName,"unix"))return VEIL_STORE_REQUIRED;
  int moved=-1;
  if(sqlite3_file_control(db,"main",SQLITE_FCNTL_HAS_MOVED,&moved)!=SQLITE_OK)return VEIL_STORE_REQUIRED;
  if(moved!=0)return VEIL_STORE_MISMATCH;
  int parent=-1,file=-1;struct stat ps,fs,heldp,heldf;
  st=walk_path(w->path,&parent,&file,&ps,&fs);if(st)return st;
  int bad=fstat(w->parent_fd,&heldp)||fstat(w->file_fd,&heldf)||!private_file(&heldf)||!directory_ok(&heldp,1)
    ||heldf.st_gid!=w->file.st_gid||heldp.st_gid!=w->parent.st_gid||!same_inode(&ps,&w->parent)||!same_inode(&fs,&w->file)||!same_inode(&heldp,&ps)||!same_inode(&heldf,&fs);
  close(file);close(parent);
  return bad?VEIL_STORE_MISMATCH:VEIL_STORE_OK;
}
veil_store_status veil_custody_watch_drop(veil_custody_watch **ptr) {
  if(!ptr||!*ptr)return VEIL_STORE_OK;
  veil_store_status st=watch_owner(*ptr);if(st)return st;
  /* POSIX close errors are not retried: fd number may already be reused.
   * No DB/lease ownership is disposed by this diagnostic descriptor destructor. */
  veil_custody_watch *w=*ptr;
  int a=close(w->file_fd),b=close(w->parent_fd);free(w);*ptr=NULL;
  return a||b?VEIL_STORE_SQL:VEIL_STORE_OK;
}
static veil_store_status int_query(sqlite3 *db,const char *sql,int64_t *out) {
  sqlite3_stmt *q=NULL;
  if(sqlite3_prepare_v2(db,sql,-1,&q,NULL)!=SQLITE_OK)return VEIL_STORE_SQL;
  int good=sqlite3_stmt_readonly(q)&&sqlite3_step(q)==SQLITE_ROW&&sqlite3_column_type(q,0)==SQLITE_INTEGER;
  if(good)*out=sqlite3_column_int64(q,0);
  good=good&&sqlite3_step(q)==SQLITE_DONE;
  int f=sqlite3_finalize(q);return good&&f==SQLITE_OK?VEIL_STORE_OK:VEIL_STORE_MISMATCH;
}
struct column {const char *name,*type;int nn,pk;};
static const struct column records[]={{"kind","TEXT",1,1},{"id","TEXT",1,2},{"sealed","BLOB",1,0}};
static const struct column checkpoint[]={{"slot","INTEGER",0,1},{"revision","INTEGER",1,0}};
static const struct column intents[]={{"op","TEXT",1,1},{"owner","TEXT",1,0},{"device","TEXT",1,0},{"identity_fp","TEXT",1,0},{"key_alias","TEXT",1,0},{"base_rev","INTEGER",1,0},{"base_hash","TEXT",1,0},{"next_rev","INTEGER",1,0},{"next_hash","TEXT",1,0},{"cipher_hash","TEXT",1,0},{"auth_gen","INTEGER",1,0},{"phase","TEXT",1,0},{"candidate_bytes","INTEGER",1,0},{"chunk_count","INTEGER",1,0},{"receipt","BLOB",0,0}};
static const struct column chunks[]={{"op","TEXT",1,1},{"part","INTEGER",1,2},{"bytes","BLOB",1,0}};
static const struct column markers[]={{"op","TEXT",1,1},{"commitment_hash","TEXT",1,0}};
static const struct column state[]={{"slot","INTEGER",0,1},{"issuer","TEXT",1,0},{"source_id","TEXT",1,0},{"store_id","TEXT",1,0},{"restore_inc","INTEGER",1,0},{"source_gen","INTEGER",1,0},{"owner","TEXT",1,0},{"device","TEXT",1,0},{"identity_fp","TEXT",1,0},{"key_alias","TEXT",1,0},{"highest","INTEGER",1,0},{"revoked","INTEGER",1,0}};
static const struct column operations[]={{"op","TEXT",0,1},{"issuer","TEXT",1,0},{"actor","TEXT",1,0},{"source_id","TEXT",1,0},{"store_id","TEXT",1,0},{"restore_inc","INTEGER",1,0},{"source_gen","INTEGER",1,0},{"owner","TEXT",1,0},{"device","TEXT",1,0},{"identity_fp","TEXT",1,0},{"key_alias","TEXT",1,0},{"base_rev","INTEGER",1,0},{"base_hash","TEXT",1,0},{"next_rev","INTEGER",1,0},{"next_hash","TEXT",1,0},{"cipher_hash","TEXT",1,0},{"auth_gen","INTEGER",1,0},{"candidate_bytes","INTEGER",1,0},{"journal_steps","INTEGER",1,0},{"disposition","TEXT",1,0},{"receipt","BLOB",0,0}};
static const struct column metadata[]={{"locale","TEXT",0,0}};
struct table {const char *name;const struct column *cols;size_t count;};
#define T(n,c) {n,c,sizeof(c)/sizeof(c[0])}
static const struct table tables[]={T("records",records),T("checkpoint",checkpoint),T("veil_checkpoint_intents_v1",intents),T("veil_checkpoint_chunks_v1",chunks),T("veil_checkpoint_committed_ops_v1",markers),T("veil_source_state_v1",state),T("veil_source_operations_v1",operations),T("android_metadata",metadata)};
static int text_equal(sqlite3_stmt *q,int c,const char *s) {
  int n=sqlite3_column_bytes(q,c);size_t len=strlen(s);
  return sqlite3_column_type(q,c)==SQLITE_TEXT&&n>=0&&(size_t)n==len&&sqlite3_column_text(q,c)&&!memcmp(sqlite3_column_text(q,c),s,len);
}
static veil_store_status check_columns(sqlite3 *db,size_t table) {
  const struct table *t=&tables[table];sqlite3_stmt *q=NULL;
  if(sqlite3_prepare_v2(db,"SELECT cid,name,type,\"notnull\",pk,hidden FROM pragma_table_xinfo(?,'main') ORDER BY cid",-1,&q,NULL)!=SQLITE_OK)return VEIL_STORE_SQL;
  int good=sqlite3_stmt_readonly(q)&&sqlite3_bind_text(q,1,t->name,-1,SQLITE_STATIC)==SQLITE_OK;
  for(size_t k=0;good&&k<t->count;k++) {
    good=sqlite3_step(q)==SQLITE_ROW&&sqlite3_column_type(q,0)==SQLITE_INTEGER&&sqlite3_column_int(q,0)==(int)k
      &&text_equal(q,1,t->cols[k].name)&&text_equal(q,2,t->cols[k].type)
      &&sqlite3_column_type(q,3)==SQLITE_INTEGER&&sqlite3_column_int(q,3)==t->cols[k].nn
      &&sqlite3_column_type(q,4)==SQLITE_INTEGER&&sqlite3_column_int(q,4)==t->cols[k].pk
      &&sqlite3_column_type(q,5)==SQLITE_INTEGER&&sqlite3_column_int(q,5)==0;
  }
  good=good&&sqlite3_step(q)==SQLITE_DONE;
  int f=sqlite3_finalize(q);return good&&f==SQLITE_OK?VEIL_STORE_OK:VEIL_STORE_MISMATCH;
}
/* Metadata only, bounded before sqlite3_column_text/materialization. */
static int add_text(veil_custody_facts *v,sqlite3_stmt *q,int c,size_t cap,int nullable) {
  int type=sqlite3_column_type(q,c);
  if(type==SQLITE_NULL&&nullable) {
    if(v->schema_size>VEIL_CUSTODY_SCHEMA_MAX-4)return 0;
    memset(v->schema+v->schema_size,255,4);v->schema_size+=4;return 1;
  }
  int n=sqlite3_column_bytes(q,c);
  if(type!=SQLITE_TEXT||n<1||(size_t)n>cap||v->schema_size>VEIL_CUSTODY_SCHEMA_MAX-4-(size_t)n)return 0;
  const unsigned char *s=sqlite3_column_text(q,c);if(!s||memchr(s,0,(size_t)n))return 0;
  for(unsigned k=0;k<4;k++)v->schema[v->schema_size++]=(unsigned char)((unsigned)n>>(8*k));
  memcpy(v->schema+v->schema_size,s,(size_t)n);v->schema_size+=(size_t)n;return 1;
}
static veil_store_status read_schema(sqlite3 *db,veil_custody_facts *v) {
  int64_t count=-1,total=-1;
  veil_store_status st=int_query(db,"SELECT COUNT(*) FROM (SELECT 1 FROM main.sqlite_schema LIMIT 33)",&count);
  if(st)return st;
  if(count<5||count>VEIL_CUSTODY_OBJECT_MAX)return VEIL_STORE_BOUND;
  st=int_query(db,"SELECT COALESCE(SUM(length(CAST(type AS BLOB))+length(CAST(name AS BLOB))+length(CAST(tbl_name AS BLOB))+COALESCE(length(CAST(sql AS BLOB)),0)+16),0) FROM main.sqlite_schema",&total);
  if(st)return st;
  if(total<0||total>VEIL_CUSTODY_SCHEMA_MAX)return VEIL_STORE_BOUND;
  st=int_query(db,"SELECT COUNT(*) FROM main.sqlite_schema WHERE typeof(type)!='text' OR typeof(name)!='text' OR typeof(tbl_name)!='text' OR length(CAST(type AS BLOB)) NOT BETWEEN 1 AND 16 OR length(CAST(name AS BLOB)) NOT BETWEEN 1 AND 128 OR length(CAST(tbl_name AS BLOB)) NOT BETWEEN 1 AND 128 OR (sql IS NOT NULL AND (typeof(sql)!='text' OR length(CAST(sql AS BLOB)) NOT BETWEEN 1 AND 8192))",&count);
  if(st)return st;
  if(count)return VEIL_STORE_BOUND;
  st=int_query(db,"SELECT COUNT(*) FROM main.sqlite_schema",&count);if(st)return st;
  sqlite3_stmt *q=NULL;unsigned seen=0;
  if(sqlite3_prepare_v2(db,"SELECT type,name,tbl_name,sql FROM main.sqlite_schema ORDER BY type,name",-1,&q,NULL)!=SQLITE_OK)return VEIL_STORE_SQL;
  for(int64_t k=0;k<count;k++) {
    if(sqlite3_step(q)!=SQLITE_ROW){st=VEIL_STORE_MISMATCH;break;}
    int ti=-1;for(size_t j=0;j<sizeof(tables)/sizeof(tables[0]);j++)if(text_equal(q,2,tables[j].name)){ti=(int)j;break;}
    if(ti<0){st=VEIL_STORE_MISMATCH;break;}
    if(text_equal(q,0,"table")) {
      if(!text_equal(q,1,tables[ti].name)||(seen&(1u<<ti))){st=VEIL_STORE_MISMATCH;break;}
      seen|=1u<<ti;
    }else if(text_equal(q,0,"index")&&sqlite3_column_type(q,3)==SQLITE_NULL) {
      int n=sqlite3_column_bytes(q,1);
      if(n<18||n>128){st=VEIL_STORE_BOUND;break;}
      const unsigned char *name=sqlite3_column_text(q,1);
      if(!name||memcmp(name,"sqlite_autoindex_",17)){st=VEIL_STORE_MISMATCH;break;}
    }else{st=VEIL_STORE_MISMATCH;break;}
    if(!add_text(v,q,0,16,0)||!add_text(v,q,1,128,0)||!add_text(v,q,2,128,0)||!add_text(v,q,3,8192,1)){st=VEIL_STORE_BOUND;break;}
    v->schema_objects++;
  }
  if(!st&&sqlite3_step(q)!=SQLITE_DONE)st=VEIL_STORE_MISMATCH;
  int f=sqlite3_finalize(q);if(!st&&f!=SQLITE_OK)st=VEIL_STORE_SQL;
  if(!st&&((seen&31u)!=31u||!!(seen&32u)!=!!(seen&64u)))st=VEIL_STORE_MISMATCH;
  for(size_t j=0;!st&&j<sizeof(tables)/sizeof(tables[0]);j++)if(seen&(1u<<j))st=check_columns(db,j);
  return st;
}
veil_store_status veil_custody_read(sqlite3 *db,veil_custody_watch *w,veil_custody_facts *out) {
  if(!out)return VEIL_STORE_BOUND;
  memset(out,0,sizeof(*out));veil_store_status st=veil_custody_watch_check(db,w);if(st)return st;
  int transaction=sqlite3_txn_state(db,"main");
  if(sqlite3_get_autocommit(db)||(transaction!=SQLITE_TXN_READ&&transaction!=SQLITE_TXN_WRITE))return VEIL_STORE_LIFETIME;
  if(sqlite3_limit(db,SQLITE_LIMIT_LENGTH,-1)>(int)VEIL_STORE_CELL_MAX+4096)return VEIL_STORE_REQUIRED;
  veil_custody_facts v;memset(&v,0,sizeof(v));
  st=read_schema(db,&v);
  int64_t sv=-1,uv=-1,rows=-1,bad=-1;
  if(!st)st=int_query(db,"PRAGMA main.schema_version",&sv);
  if(!st)st=int_query(db,"PRAGMA main.user_version",&uv);
  if(!st)st=int_query(db,"SELECT COUNT(*) FROM (SELECT 1 FROM main.checkpoint LIMIT 2)",&rows);
  if(!st&&rows!=1)st=VEIL_STORE_MISMATCH;
  if(!st)st=int_query(db,"SELECT revision FROM main.checkpoint WHERE slot=1 AND typeof(slot)='integer' AND typeof(revision)='integer' AND revision>=0",&v.checkpoint_revision);
  if(!st)st=int_query(db,"SELECT COUNT(*) FROM (SELECT 1 FROM main.records LIMIT 4097)",&v.record_count);
  if(!st&&(v.record_count<0||v.record_count>VEIL_STORE_RECORDS_MAX))st=VEIL_STORE_BOUND;
  if(!st)st=int_query(db,"SELECT COALESCE(SUM(length(sealed)),0) FROM main.records",&v.record_bytes);
  if(!st&&(v.record_bytes<0||v.record_bytes>VEIL_STORE_TOTAL_MAX))st=VEIL_STORE_BOUND;
  if(!st)st=int_query(db,"SELECT COUNT(*) FROM main.records WHERE typeof(kind)!='text' OR typeof(id)!='text' OR typeof(sealed)!='blob' OR length(CAST(kind AS BLOB)) NOT BETWEEN 1 AND 32 OR length(CAST(id AS BLOB)) NOT BETWEEN 1 AND 1024 OR instr(kind,char(0))>0 OR instr(id,char(0))>0 OR kind GLOB '*[^!-~]*' OR id GLOB '*[^!-~]*' OR length(sealed) NOT BETWEEN 29 AND 8388636",&bad);
  if(!st&&bad)st=VEIL_STORE_BOUND;
  if(!st&&(sv<0||sv>INT_MAX||uv<0||uv>INT_MAX))st=VEIL_STORE_BOUND;
  if(!st)st=veil_custody_watch_check(db,w);
  if(st)return st;
  v.process_uid=getuid();v.process_euid=geteuid();v.file_uid=w->file.st_uid;v.file_gid=w->file.st_gid;
  v.file_device=w->file.st_dev;v.file_inode=w->file.st_ino;v.parent_device=w->parent.st_dev;v.parent_inode=w->parent.st_ino;
  v.file_mode=w->file.st_mode&07777;v.parent_mode=w->parent.st_mode&07777;
  v.sqlite_has_moved=0;v.sqlite_readonly=sqlite3_db_readonly(db,"main");v.schema_version=(int)sv;v.user_version=(int)uv;
  *out=v;return VEIL_STORE_OK;
}
