#define _GNU_SOURCE
#include "source_server_private.h"
#include "linux/ynx_tpm2_esys_owner.h"
#include <openssl/evp.h>
#include <openssl/crypto.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
enum wrapping_state { WRAPPING_INITIALIZING=0, WRAPPING_ACTIVE, WRAPPING_CLEANUP_ONLY };
struct ynx_source_wrapping_owner { unsigned char key[32];pthread_t thread;size_t mapping_size;enum wrapping_state state;int primary,locked;ynx_tpm2_owner *tpm; };
static pthread_mutex_t wrapping_inventory=PTHREAD_MUTEX_INITIALIZER;
static size_t wrapping_count;
static void release_inventory(void){pthread_mutex_lock(&wrapping_inventory);wrapping_count--;pthread_mutex_unlock(&wrapping_inventory);}
static int allocate_wrapping(ynx_source_wrapping_owner **out){
 long page=sysconf(_SC_PAGESIZE);
 if(page<=0||(size_t)page<sizeof(ynx_source_wrapping_owner)||(size_t)page>1048576)return VEIL_OWN_MEMORY;
 pthread_mutex_lock(&wrapping_inventory);
 if(wrapping_count>=32){pthread_mutex_unlock(&wrapping_inventory);return VEIL_OWN_MEMORY;}
 wrapping_count++;pthread_mutex_unlock(&wrapping_inventory);
 void *map=mmap(NULL,(size_t)page,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 if(map==MAP_FAILED){release_inventory();return VEIL_OWN_MEMORY;}
 if(mlock(map,(size_t)page)){
  if(munmap(map,(size_t)page)){abort();} /* no secret read; failed mapping disposal */
  release_inventory();return VEIL_OWN_MEMORY;
 }
 ynx_source_wrapping_owner *p=map;p->mapping_size=(size_t)page;p->locked=1;p->thread=pthread_self();*out=p;return VEIL_OWN_OK;
}
static int release_wrapping(ynx_source_wrapping_owner *p){
 size_t n=p->mapping_size;
 if(p->state!=WRAPPING_CLEANUP_ONLY){
  /* Revoke first. Keep nonsecret custody metadata alive if disposal fails. */
  p->state=WRAPPING_CLEANUP_ONLY;
  OPENSSL_cleanse(p->key,sizeof(p->key));
 }
 if(p->locked){
  if(munlock(p,n)){
   if(p->primary==VEIL_OWN_OK)p->primary=VEIL_OWN_UNKNOWN;
   if(p->tpm)return VEIL_OWN_UNKNOWN; /* sealed custody retains locked mapping + TPM ref */
  }
  p->locked=0;
 }
 if(p->tpm){if(ynx_tpm2_wrapping_custody_release(p->tpm)!=YNX_TPM2_OK)return VEIL_OWN_UNKNOWN;p->tpm=NULL;}
 /* Cleanup-only retries perform no reads, unlocks, or key restoration. */
 if(munmap(p,n)){if(p->primary==VEIL_OWN_OK)p->primary=VEIL_OWN_UNKNOWN;return VEIL_OWN_UNKNOWN;}
 release_inventory();return VEIL_OWN_OK;
}

int ynx_source_wrapping_open(int fd,ynx_source_wrapping_owner **out){
 if(!out||*out)return VEIL_OWN_INVALID;
 struct stat before,after;
 if(fstat(fd,&before)||!S_ISREG(before.st_mode)||(before.st_mode&077)!=0||before.st_uid!=geteuid()||before.st_size!=32)return VEIL_OWN_INVALID;
 int owned=fcntl(fd,F_DUPFD_CLOEXEC,3);if(owned<0)return VEIL_OWN_UNAVAILABLE;
 ynx_source_wrapping_owner *p=NULL;int allocated=allocate_wrapping(&p);if(allocated!=VEIL_OWN_OK){close(owned);return allocated;}
 int ok=pread(owned,p->key,32,0)==32&&!fstat(owned,&after)&&before.st_dev==after.st_dev&&before.st_ino==after.st_ino&&after.st_size==32&&before.st_mtime==after.st_mtime;
 if(close(owned))ok=0;
 if(!ok){p->primary=VEIL_OWN_UNAVAILABLE;int released=release_wrapping(p);if(released!=VEIL_OWN_OK){*out=p;return released;}return VEIL_OWN_UNAVAILABLE;}
 p->state=WRAPPING_ACTIVE;*out=p;return VEIL_OWN_OK;
}
int ynx_source_wrapping_from_tpm(ynx_tpm2_owner *tpm,ynx_source_wrapping_owner **out){
 if(!tpm||!out||*out)return VEIL_OWN_INVALID;
 const uint8_t *secret=NULL;size_t n=0;
 int rc=ynx_tpm2_owner_secret_borrow(tpm,&secret,&n);if(rc)return VEIL_OWN_UNAVAILABLE;
 ynx_source_wrapping_owner *p=NULL;int result=VEIL_OWN_OK;
 if(!secret||n!=32)result=VEIL_OWN_INVALID;
 else{result=allocate_wrapping(&p);if(result==VEIL_OWN_OK){
  if(ynx_tpm2_wrapping_custody_retain(tpm)!=YNX_TPM2_OK)result=VEIL_OWN_UNKNOWN;
  else{p->tpm=tpm;memcpy(p->key,secret,32);}
 }}
 int released=ynx_tpm2_owner_secret_release(tpm);
 if(released||ynx_tpm2_owner_current(tpm)!=YNX_TPM2_OK)result=VEIL_OWN_UNKNOWN;
 if(result!=VEIL_OWN_OK){
  if(p){p->primary=result;int disposed=release_wrapping(p);if(disposed!=VEIL_OWN_OK)*out=p;}
  return result;
 }
 p->state=WRAPPING_ACTIVE;*out=p;return VEIL_OWN_OK;
}
int ynx_source_wrapping_close(ynx_source_wrapping_owner **owner){
 if(!owner)return VEIL_OWN_INVALID;if(!*owner)return VEIL_OWN_OK;
 if(!pthread_equal((*owner)->thread,pthread_self()))return VEIL_OWN_WRONG_THREAD;
 int rc=release_wrapping(*owner);if(rc==VEIL_OWN_OK)*owner=NULL;return rc;
}
int ynx_source_wrapping_current(ynx_source_wrapping_owner *p){
 if(!p)return VEIL_OWN_INVALID;
 if(!pthread_equal(p->thread,pthread_self()))return VEIL_OWN_WRONG_THREAD;
 if(p->primary)return p->primary;
 if(p->state!=WRAPPING_ACTIVE)return p->state==WRAPPING_CLEANUP_ONLY?VEIL_OWN_UNKNOWN:VEIL_OWN_UNAVAILABLE;
 if(p->tpm&&ynx_tpm2_owner_current(p->tpm)!=YNX_TPM2_OK){
  /* Revoke availability before wiping. The original retained pointer and
   * physical reference remain solely for explicit cleanup, never retry. */
  p->primary=VEIL_OWN_UNKNOWN;OPENSSL_cleanse(p->key,sizeof(p->key));return p->primary;
 }
 return VEIL_OWN_OK;
}
static veil_own_result decrypt(void *ctx,const uint8_t *aad,size_t na,const uint8_t nonce[12],const uint8_t *cipher,size_t nc,uint8_t *clear,size_t cap,size_t *written){
 ynx_source_wrapping_owner *p=ctx;if(written)*written=0;
 if(!p||!aad||!nonce||!cipher||!clear||!written||na>7168||nc<16||nc>4912||cap<nc-16)return VEIL_OWN_INVALID;
 if(!pthread_equal(p->thread,pthread_self()))return VEIL_OWN_WRONG_THREAD;
 OPENSSL_cleanse(clear,cap);
 int current=ynx_source_wrapping_current(p);if(current!=VEIL_OWN_OK)return current;
 EVP_CIPHER_CTX *c=EVP_CIPHER_CTX_new();if(!c)return VEIL_OWN_MEMORY;
 int n=0,total=0,ok=EVP_DecryptInit_ex(c,EVP_aes_256_gcm(),NULL,NULL,NULL)==1;
 ok=ok&&EVP_CIPHER_CTX_ctrl(c,EVP_CTRL_GCM_SET_IVLEN,12,NULL)==1&&EVP_DecryptInit_ex(c,NULL,NULL,p->key,nonce)==1;
 ok=ok&&EVP_DecryptUpdate(c,NULL,&n,aad,(int)na)==1;
 ok=ok&&EVP_DecryptUpdate(c,clear,&n,cipher,(int)(nc-16))==1;total=n;
 ok=ok&&EVP_CIPHER_CTX_ctrl(c,EVP_CTRL_GCM_SET_TAG,16,(void *)(cipher+nc-16))==1;
 ok=ok&&EVP_DecryptFinal_ex(c,clear+total,&n)==1;total+=n;EVP_CIPHER_CTX_free(c);
 if(!ok||(size_t)total!=nc-16){OPENSSL_cleanse(clear,cap);return VEIL_OWN_AUTH_FAILED;}
 *written=(size_t)total;return VEIL_OWN_OK;
}
static veil_own_result decrypt_pq(void *p,const uint8_t *a,size_t n,const uint8_t iv[12],const uint8_t c[4912],uint8_t *out,size_t cap,size_t *written){return decrypt(p,a,n,iv,c,4912,out,cap,written);}
int ynx_source_reload_records(ynx_source_wrapping_owner *p,const veil_own_binding *b,const uint8_t pq[2592],const veil_own_record *qr,const veil_classic_record *cr,uint8_t classic[256],size_t *written,veil_pq_custodian **out){
 static const char domain[]="YNX/SOCIAL/INFRASTRUCTURE/V1";
 if(classic)OPENSSL_cleanse(classic,256);if(written)*written=0;
 if(!cr||cr->version!=1||cr->ciphertext_size<17||cr->ciphertext_size>272)return VEIL_OWN_INVALID;
 if(!p||!b||!out||*out||!classic||!written||!b->owner_binding||b->owner_binding_size<=sizeof(domain)||memcmp(b->owner_binding,domain,sizeof(domain)))return VEIL_OWN_INVALID;
 if(!pthread_equal(p->thread,pthread_self()))return VEIL_OWN_WRONG_THREAD;
 if(p->state!=WRAPPING_ACTIVE)return p->state==WRAPPING_CLEANUP_ONLY?VEIL_OWN_UNKNOWN:VEIL_OWN_UNAVAILABLE;
 *written=0;OPENSSL_cleanse(classic,256);
 veil_classic_protector cp={p,NULL,decrypt};
 size_t exact=(size_t)cr->ciphertext_size-16;
 int rc=veil_classic_unseal_native(b,pq,cr,&cp,classic,exact,written);if(rc!=VEIL_OWN_OK){OPENSSL_cleanse(classic,256);*written=0;return rc;}
 veil_own_protector qp={p,NULL,decrypt_pq};rc=veil_own_reload(b,pq,qr,&qp,out);
 if(rc!=VEIL_OWN_OK){OPENSSL_cleanse(classic,256);*written=0;}
 return rc;
}
