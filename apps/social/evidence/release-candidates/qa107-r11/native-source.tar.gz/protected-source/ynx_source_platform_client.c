#include "ynx_source_platform_private.h"
#include "linux/ynx_source_platform_qualified.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/sha.h>
#include <time.h>
int32_t ynx_source_monotonic_now_v1(uint64_t *out){
 if(!out)return VEIL_STORE_BOUND;*out=0;struct timespec t;
 if(clock_gettime(CLOCK_MONOTONIC,&t)||t.tv_sec<0||t.tv_nsec<0||t.tv_nsec>=1000000000)return VEIL_STORE_UNKNOWN;
 if((uint64_t)t.tv_sec>(UINT64_MAX-(uint64_t)t.tv_nsec)/1000000000u)return VEIL_STORE_BOUND;
 *out=(uint64_t)t.tv_sec*1000000000u+(uint64_t)t.tv_nsec;return VEIL_STORE_OK;
}

enum client_phase{CLIENT_ACQUIRING,CLIENT_ACQUIRED,CLIENT_ENTERED,CLIENT_UNKNOWN,CLIENT_RELEASED,CLIENT_TERMINAL};
struct veil_source_hold{unsigned char *original_storage;ynx_core_original_input original_input;ynx_original_bytes original_history[255];struct veil_source_hold *original_parent;size_t original_borrows;ynx_platform_original_hold *platform;pthread_t thread;enum client_phase phase;veil_store_status primary;veil_private_cas_match *cas;const unsigned char *receipt;size_t receipt_size;int cas_attempted,terminal_attempted,snapshot_attempted;size_t snapshot_refs;struct veil_source_hold *next;};
static pthread_mutex_t inventory_lock=PTHREAD_MUTEX_INITIALIZER;
static veil_source_hold *inventory;
static size_t inventory_count;
/* Only allocation/exclusion bookkeeping. Inventory membership is NOT grant. */
static veil_source_hold *allocate(void){
 veil_source_hold *h=calloc(1,sizeof(*h));if(!h)return NULL;
 pthread_mutex_lock(&inventory_lock);if(inventory_count>=32){pthread_mutex_unlock(&inventory_lock);free(h);return NULL;}
 h->thread=pthread_self();h->phase=CLIENT_ACQUIRING;h->next=inventory;inventory=h;inventory_count++;pthread_mutex_unlock(&inventory_lock);return h;
}
static veil_store_status recognized(veil_source_hold *h){
 if(!h)return VEIL_STORE_REQUIRED;
 pthread_mutex_lock(&inventory_lock);veil_source_hold *p=inventory;while(p&&p!=h)p=p->next;
 veil_store_status s=!p?VEIL_STORE_REQUIRED:!pthread_equal(p->thread,pthread_self())?VEIL_STORE_THREAD:VEIL_STORE_OK;
 pthread_mutex_unlock(&inventory_lock);return s;
}
static veil_store_status dispose(veil_source_hold *h){
 veil_store_status original_cause=h->platform?ynx_platform_original_first_cause(h->platform):0;if(!h->primary&&original_cause)h->primary=original_cause;
 veil_store_status s=ynx_platform_drop(&h->platform);
 if(s||h->platform){if(!s)s=VEIL_STORE_UNKNOWN;if(!h->primary)h->primary=s;h->phase=CLIENT_UNKNOWN;return s;}
 if(h->original_parent){if(!h->original_parent->original_borrows)abort();h->original_parent->original_borrows--;h->original_parent=NULL;}
 free(h->original_storage);h->original_storage=NULL;
 pthread_mutex_lock(&inventory_lock);veil_source_hold **p=&inventory;while(*p&&*p!=h)p=&(*p)->next;if(!*p)abort();*p=h->next;inventory_count--;pthread_mutex_unlock(&inventory_lock);memset(h,0,sizeof(*h));free(h);return VEIL_STORE_OK;
}
static veil_store_status acquired(veil_source_hold *h,veil_store_status s,veil_source_hold **out){
 if(!h->platform){dispose(h);return s==VEIL_STORE_OK?VEIL_STORE_UNKNOWN:s;}
 *out=h;if(s!=VEIL_STORE_OK){veil_store_status cause=ynx_platform_original_first_cause(h->platform);h->primary=cause?cause:s;h->phase=CLIENT_UNKNOWN;return VEIL_STORE_UNKNOWN;}
 /* A child may only borrow provenance from an already recognized original
  * holding the EXACT SAME platform root. Pointer equality is not permission:
  * both acquisitions must already have passed their real platform fence. */
 pthread_mutex_lock(&inventory_lock);
 for(veil_source_hold *p=inventory;p;p=p->next)if(p!=h&&p->original_storage&&p->platform==h->platform&&p->phase==CLIENT_ACQUIRED&&pthread_equal(p->thread,h->thread)){
  if(p->original_borrows>=32){pthread_mutex_unlock(&inventory_lock);h->primary=VEIL_STORE_BOUND;h->phase=CLIENT_UNKNOWN;return VEIL_STORE_UNKNOWN;}
  p->original_borrows++;h->original_parent=p;break;
 }
 pthread_mutex_unlock(&inventory_lock);
 h->phase=CLIENT_ACQUIRED;return VEIL_STORE_OK;
}
static veil_store_status observe(veil_source_hold *h,veil_store_status s){
 if(s&&h->primary==VEIL_STORE_OK)h->primary=s;
 if(s&&(s==VEIL_STORE_UNKNOWN||h->phase==CLIENT_ENTERED)){h->phase=CLIENT_UNKNOWN;return VEIL_STORE_UNKNOWN;}
 return s;
}
veil_store_status veil_source_acquire(veil_private_store_binding *b,const veil_verified_native_operation_lease *l,const veil_native_intent_handle *i,veil_source_mode m,veil_source_hold **out,veil_source_view *v){
 if(!out||*out||!v)return VEIL_STORE_BOUND;memset(v,0,sizeof(*v));if(!b||!l||!i)return VEIL_STORE_REQUIRED;
 if(m!=VEIL_SOURCE_FRESH&&m!=VEIL_SOURCE_RECOVERY&&m!=VEIL_SOURCE_TRANSITION)return VEIL_STORE_BOUND;
 veil_source_hold *h=allocate();if(!h)return VEIL_STORE_SQL;
 veil_store_status s=ynx_platform_acquire(b,l,i,m,&h->platform,v);s=acquired(h,s,out);if(s)memset(v,0,sizeof(*v));return s;
}
veil_store_status ynx_source_client_prepared_acquire(const veil_private_prepared_input_owner *p,veil_source_hold **out){
 if(!out||*out)return VEIL_STORE_BOUND;if(!p)return VEIL_STORE_REQUIRED;
 veil_source_hold *h=allocate();if(!h)return VEIL_STORE_SQL;return acquired(h,ynx_platform_acquire_prepared(p,&h->platform),out);
}
veil_store_status veil_source_validate(veil_source_hold *h,int cleanup){
 veil_store_status s=recognized(h);if(s)return s;
 if(!cleanup&&(h->phase==CLIENT_UNKNOWN||h->phase==CLIENT_RELEASED))return VEIL_STORE_UNKNOWN;
 if(h->phase==CLIENT_ACQUIRING)return VEIL_STORE_REQUIRED;
 s=ynx_platform_current(h->platform,cleanup!=0);
 return observe(h,s);
}
veil_store_status ynx_source_client_enter(veil_source_hold *h){
 veil_store_status s=veil_source_validate(h,0);if(s)return s;
 if(h->phase!=CLIENT_ACQUIRED)return VEIL_STORE_UNKNOWN;
 h->phase=CLIENT_UNKNOWN; /* before call: invocation may already persist */
 s=ynx_platform_enter(h->platform);if(s){if(!h->primary)h->primary=s;return VEIL_STORE_UNKNOWN;}h->phase=CLIENT_ENTERED;return VEIL_STORE_OK;
}
veil_store_status ynx_source_client_current(veil_source_hold *h,int cleanup){return veil_source_validate(h,cleanup);}
veil_store_status veil_source_allow_initialization(veil_source_hold *h){
 veil_store_status s=veil_source_validate(h,0);if(s)return s;
 if(h->phase!=CLIENT_ACQUIRED)return observe(h,VEIL_STORE_UNKNOWN);
 /* Initialization can persist platform custody and then local SQL. Enter the
  * SAME authentic owner before either possible effect; never call initialize
  * again from ENTERED/UNKNOWN, even after an ordinary platform rejection. */
 s=ynx_source_client_enter(h);if(s)return s;
 s=observe(h,ynx_platform_initialize(h->platform));if(s)return s;
 return veil_source_validate(h,0);
}
veil_store_status veil_source_cas_result(veil_source_hold *h,veil_private_cas_match **m,const unsigned char **b,size_t *n){
 if(!m||!b||!n)return VEIL_STORE_BOUND;*m=NULL;*b=NULL;*n=0;
 veil_store_status s=veil_source_validate(h,0);if(s)return s;
 if(h->cas_attempted){if(!h->cas||!h->receipt||!h->receipt_size)return VEIL_STORE_UNKNOWN;*m=h->cas;*b=h->receipt;*n=h->receipt_size;return VEIL_STORE_OK;}
 if(h->phase==CLIENT_ACQUIRED){s=ynx_source_client_enter(h);if(s)return s;}
 if(h->phase!=CLIENT_ENTERED)return VEIL_STORE_UNKNOWN;h->cas_attempted=1;
 s=ynx_platform_cas(h->platform,&h->cas,&h->receipt,&h->receipt_size);
 if(s||!h->cas||!h->receipt||!h->receipt_size||h->receipt_size>32768){if(!h->primary)h->primary=s?s:VEIL_STORE_BOUND;h->phase=CLIENT_UNKNOWN;return VEIL_STORE_UNKNOWN;}
 s=veil_source_validate(h,0);if(s)return s;*m=h->cas;*b=h->receipt;*n=h->receipt_size;return VEIL_STORE_OK;
}
veil_store_status veil_source_step_borrow(veil_source_hold *h,const veil_native_intent_handle *i,const veil_native_ordered_step *s,veil_private_step_view *v){if(!v)return VEIL_STORE_BOUND;memset(v,0,sizeof(*v));veil_store_status st=veil_source_validate(h,0);if(st)return st;if(!i||!s)return VEIL_STORE_BOUND;st=observe(h,ynx_platform_step(h->platform,i,s,v));if(st)memset(v,0,sizeof(*v));return st;}
veil_store_status veil_source_queue_borrow(veil_source_hold *h,const veil_native_intent_handle *i,const veil_native_inbound_intent *a,const veil_native_outbound_intent *b,veil_private_step_view *v){if(!v)return VEIL_STORE_BOUND;memset(v,0,sizeof(*v));veil_store_status st=veil_source_validate(h,0);if(st)return st;if(!i||(!a&&!b)||(a&&b))return VEIL_STORE_BOUND;st=observe(h,ynx_platform_queue(h->platform,i,a,b,v));if(st)memset(v,0,sizeof(*v));return st;}
veil_store_status veil_source_recover_committed(veil_source_hold *h,const veil_native_intent_handle *i,veil_private_cas_match *m,const veil_private_recovery_admission **out){if(!out)return VEIL_STORE_BOUND;*out=NULL;veil_store_status s=veil_source_validate(h,0);if(s)return s;if(!i||!m||m!=h->cas)return VEIL_STORE_BOUND;s=observe(h,ynx_platform_recover(h->platform,i,m,out));if(s)*out=NULL;return s;}
veil_store_status veil_source_publish_once(veil_source_hold *h,const veil_native_intent_handle *i,veil_private_cas_match *m,const veil_private_recovery_admission *r,veil_native_verified_commit **out){
 if(!out||*out)return VEIL_STORE_BOUND;veil_store_status s=veil_source_validate(h,0);if(s)return s;
 if(!i||!m||m!=h->cas)return VEIL_STORE_BOUND;if(h->phase!=CLIENT_ENTERED||h->terminal_attempted)return VEIL_STORE_UNKNOWN;
 h->terminal_attempted=1;s=veil_private_verified_commit_publish(h->platform,i,m,r,out);
 if(s&&*out)abort(); /* owning error-output violates the exact LINK contract */
 if(s||!*out){if(!h->primary)h->primary=s?s:VEIL_STORE_BOUND;h->phase=CLIENT_UNKNOWN;return VEIL_STORE_UNKNOWN;}
 h->phase=CLIENT_TERMINAL;return VEIL_STORE_OK;
}
veil_store_status ynx_source_client_type4(veil_source_hold *h,const unsigned char *b,size_t n){
 veil_store_status s=veil_source_validate(h,0);if(s)return s;if(h->phase!=CLIENT_ENTERED||!b||!n||n>65536)return VEIL_STORE_BOUND;
 return observe(h,ynx_platform_type4(h->platform,b,n));
}
void veil_source_release_lock(veil_source_hold *h){if(recognized(h)!=VEIL_STORE_OK)abort();if(h->phase==CLIENT_RELEASED)return;ynx_platform_release_lock(h->platform);h->phase=CLIENT_RELEASED;}
veil_store_status ynx_source_client_close(veil_source_hold **p){if(!p)return VEIL_STORE_BOUND;if(!*p)return VEIL_STORE_OK;veil_store_status s=recognized(*p);if(s)return s;if((*p)->snapshot_refs||(*p)->original_borrows)return VEIL_STORE_BOUND;s=dispose(*p);if(s)return s;*p=NULL;return VEIL_STORE_OK;}
void veil_source_drop(veil_source_hold **p){if(ynx_source_client_close(p)!=VEIL_STORE_OK)abort();}

static int original_bytes_present(ynx_original_bytes b){return b.data&&b.size;}
/* OriginalAdmission supplies these spans directly from its RecoveryLoan.
 * Own the complete exact bytes BEFORE the physical constructor can retain
 * partial custody. No hash/parser result or pointer grants authorization. */
static veil_store_status client_original_capture(veil_source_hold *h,const ynx_core_original_input *input){
 const ynx_original_bytes originals[6]={input->root,input->registration,input->status,input->source,input->namespace_prefix,input->request};
 const size_t limits[6]={16384,16384,16384,393216,393216,1048576};
 size_t total=32;for(size_t n=0;n<6;n++){
  if(!originals[n].data||!originals[n].size||originals[n].size>limits[n])return VEIL_STORE_BOUND;total+=originals[n].size;
 }
 for(size_t n=0;n<input->status_history_count;n++){
  if(!input->status_history[n].data||!input->status_history[n].size||input->status_history[n].size>16384)return VEIL_STORE_BOUND;
  total+=input->status_history[n].size;
 }
 unsigned char *storage=malloc(total);if(!storage)return VEIL_STORE_SQL;
 unsigned char *cursor=storage;ynx_core_original_input v={0};
 ynx_original_bytes *fields[6]={&v.root,&v.registration,&v.status,&v.source,&v.namespace_prefix,&v.request};
 for(size_t n=0;n<6;n++){memcpy(cursor,originals[n].data,originals[n].size);*fields[n]=(ynx_original_bytes){cursor,originals[n].size};cursor+=originals[n].size;}
 memcpy(cursor,input->nonce,32);v.nonce=cursor;v.nonce_size=32;cursor+=32;
 for(size_t n=0;n<input->status_history_count;n++){
  size_t size=input->status_history[n].size;memcpy(cursor,input->status_history[n].data,size);
  h->original_history[n]=(ynx_original_bytes){cursor,size};cursor+=size;
 }
 v.status_history=h->original_history;v.status_history_count=input->status_history_count;
 memcpy(v.native_classic,input->native_classic,33);memcpy(v.native_pq,input->native_pq,2592);memcpy(v.source_nonce,input->source_nonce,32);v.monotonic_deadline_ns=input->monotonic_deadline_ns;
 h->original_storage=storage;h->original_input=v;return VEIL_STORE_OK;
}
veil_store_status ynx_source_client_original_acquire(const ynx_core_original_input *input,veil_source_hold **out){
 if(!out||*out)return VEIL_STORE_BOUND;if(!input)return VEIL_STORE_REQUIRED;
 if(!original_bytes_present(input->root)||!original_bytes_present(input->registration)||!original_bytes_present(input->status)||!original_bytes_present(input->source)||!original_bytes_present(input->namespace_prefix)||!original_bytes_present(input->request)||!input->nonce||input->nonce_size!=32||input->source.size>393216||input->status_history_count>255||(input->status_history_count&&!input->status_history))return VEIL_STORE_BOUND;
 for(size_t n=0;n<input->status_history_count;n++)if(!original_bytes_present(input->status_history[n]))return VEIL_STORE_BOUND;
 /* Shape only: no local parser/fd/identity is a qualified authorization. */
 veil_source_hold *h=allocate();if(!h)return VEIL_STORE_SQL;
 veil_store_status st=client_original_capture(h,input);if(st){dispose(h);return st;}
 return acquired(h,ynx_platform_acquire_original(&h->original_input,&h->platform),out);
}
veil_store_status ynx_source_client_original_acquire_v2(const ynx_core_original_input_v2 *input,veil_source_hold **out){
 if(!out||*out)return VEIL_STORE_BOUND;if(!input)return VEIL_STORE_REQUIRED;
 const ynx_core_original_input *raw=&input->original;
 if(input->rights.version!=2||input->rights.size!=80||input->rights.monotonic_deadline_ns!=raw->monotonic_deadline_ns)return VEIL_STORE_BOUND;
 if(!original_bytes_present(raw->root)||!original_bytes_present(raw->registration)||!original_bytes_present(raw->status)||!original_bytes_present(raw->source)||!original_bytes_present(raw->namespace_prefix)||!original_bytes_present(raw->request)||!raw->nonce||raw->nonce_size!=32||raw->source.size>393216||raw->status_history_count>255||(raw->status_history_count&&!raw->status_history))return VEIL_STORE_BOUND;
 for(size_t n=0;n<raw->status_history_count;n++)if(!original_bytes_present(raw->status_history[n]))return VEIL_STORE_BOUND;
 veil_source_hold*h=allocate();if(!h)return VEIL_STORE_SQL;veil_store_status s=client_original_capture(h,raw);if(s){dispose(h);return s;}
 ynx_core_original_input_v2 held={input->rights,h->original_input};
 return acquired(h,ynx_platform_acquire_original_v2(&held,&h->platform),out);
}
veil_store_status ynx_source_client_core_origin_borrow(veil_source_hold *hold,ynx_core_origin_original *out){
 if(!out)return VEIL_STORE_BOUND;
 veil_store_status s=veil_source_validate(hold,0);if(s)return s;
 veil_source_hold *root=hold->original_storage?hold:hold->original_parent;
 if(!root||recognized(root)||!root->original_storage)return VEIL_STORE_REQUIRED;
 if(root!=hold&&(root->platform!=hold->platform||!root->original_borrows))return observe(hold,VEIL_STORE_UNKNOWN);
 s=veil_source_validate(root,0);if(s)return observe(hold,s);
 const ynx_core_original_input *original=&root->original_input;ynx_core_origin_original v={0};
 if(!SHA256(original->root.data,original->root.size,v.root_digest)||!SHA256(original->registration.data,original->registration.size,v.registration_digest))return observe(hold,VEIL_STORE_UNKNOWN);
 memcpy(v.native_classic,original->native_classic,33);memcpy(v.native_pq,original->native_pq,2592);
 memcpy(v.source_nonce,original->source_nonce,32);memcpy(v.account_nonce,original->nonce,32);
 s=veil_source_validate(root,0);if(!s)s=veil_source_validate(hold,0);if(s)return s;
 *out=v;return VEIL_STORE_OK;
}
veil_store_status ynx_source_client_original_projection(veil_source_hold *hold,const veil_product_accepted_origin_owner **a,const veil_product_accepted_device_owner **d,const veil_product_prepared_history_owner **h,const veil_selected_retained_original_owner **r){
 if(!a||!d||!h||!r)return VEIL_STORE_BOUND;*a=NULL;*d=NULL;*h=NULL;*r=NULL;
 veil_store_status s=veil_source_validate(hold,0);if(s)return s;
 s=ynx_platform_original_projection(hold->platform,a,d,h,r);
 if(s){*a=NULL;*d=NULL;*h=NULL;*r=NULL;return observe(hold,s);}
 if(!*a||!*d||!*h||!*r){*a=NULL;*d=NULL;*h=NULL;*r=NULL;return observe(hold,VEIL_STORE_UNKNOWN);}
 s=veil_source_validate(hold,0);if(s){*a=NULL;*d=NULL;*h=NULL;*r=NULL;}return s;
}

veil_store_status ynx_source_client_original_native_plan(veil_source_hold *hold,ynx_original_native_plan *plan){
 if(!plan)return VEIL_STORE_BOUND;memset(plan,0,sizeof(*plan));veil_store_status s=veil_source_validate(hold,0);if(s)return s;
 s=ynx_platform_original_native_plan(hold->platform,plan);
 if(s){memset(plan,0,sizeof(*plan));return observe(hold,s);}
 if(!plan->intent||plan->journal_count>32||(!plan->inbox==!plan->outbox)){memset(plan,0,sizeof(*plan));return observe(hold,VEIL_STORE_UNKNOWN);}
 for(size_t n=0;n<plan->journal_count;n++)if(!plan->journal[n]){memset(plan,0,sizeof(*plan));return observe(hold,VEIL_STORE_UNKNOWN);}
 s=veil_source_validate(hold,0);if(s)memset(plan,0,sizeof(*plan));return s;
}

/* This inventory enforces custody/thread/exclusion only. Platform-held owner,
 * authenticated projection and current fence are independently verified. */
struct ynx_source_snapshot_hold{ynx_storage_attempt *storage;veil_source_hold *root;ynx_platform_snapshot_hold *platform;pthread_t thread;int unknown,close_refused,commit_attempted;veil_store_status commit_primary;struct ynx_source_snapshot_hold *next;};
static ynx_source_snapshot_hold *snapshots;
static veil_store_status snapshot_recognized(ynx_source_snapshot_hold *h){
 pthread_mutex_lock(&inventory_lock);ynx_source_snapshot_hold *p=snapshots;while(p&&p!=h)p=p->next;
 veil_store_status s=!p?VEIL_STORE_REQUIRED:!pthread_equal(p->thread,pthread_self())?VEIL_STORE_THREAD:VEIL_STORE_OK;pthread_mutex_unlock(&inventory_lock);return s;
}
static void snapshot_free(ynx_source_snapshot_hold *h){
 pthread_mutex_lock(&inventory_lock);ynx_source_snapshot_hold **p=&snapshots;while(*p&&*p!=h)p=&(*p)->next;if(!*p||!h->root->snapshot_refs)abort();*p=h->next;h->root->snapshot_refs--;pthread_mutex_unlock(&inventory_lock);memset(h,0,sizeof(*h));free(h);
}
veil_store_status ynx_source_client_snapshot_message_route(ynx_source_snapshot_hold *h,const unsigned char logical[16],uint32_t direction,ynx_native_message_route *out){
 if(!out)return VEIL_STORE_BOUND;memset(out,0,sizeof(*out));if(!logical||(direction!=1&&direction!=2))return VEIL_STORE_BOUND;
 unsigned char nonzero=0;for(size_t n=0;n<16;n++)nonzero|=logical[n];if(!nonzero)return VEIL_STORE_BOUND;
 veil_store_status s=ynx_source_client_snapshot_current(h);if(s)return s;
 ynx_native_message_route route={0};s=ynx_platform_snapshot_message_route(h->platform,logical,direction,&route);
 /* A missing purpose-qualified provider produces no route, not a new lease. */
 if(s==VEIL_STORE_REQUIRED)return s;
 if(s||route.direction!=direction||memcmp(route.logical,logical,16)||!route.local_name.data||!route.remote_name.data||route.local_name.size==0||route.local_name.size>128||route.remote_name.size==0||route.remote_name.size>128||route.local_device==0||route.local_device>127||route.remote_device==0||route.remote_device>127){h->unknown=1;observe(h->root,VEIL_STORE_UNKNOWN);return VEIL_STORE_UNKNOWN;}
 ynx_native_snapshot_projection same={0};s=ynx_platform_snapshot_projection(h->platform,&same);
 if(s||memcmp(route.binding,same.binding,sizeof(route.binding))||(same.queue==1?direction!=2:same.queue==2?direction!=1:1)){h->unknown=1;observe(h->root,VEIL_STORE_UNKNOWN);return VEIL_STORE_UNKNOWN;}
 s=ynx_source_client_snapshot_current(h);if(s)return s;*out=route;return VEIL_STORE_OK;
}

veil_store_status ynx_source_client_snapshot_acquire(veil_source_hold *root,const veil_private_prepared_input_owner *prepared,ynx_source_snapshot_hold **out){
 if(!out||*out)return VEIL_STORE_BOUND;if(!prepared)return VEIL_STORE_REQUIRED;
 veil_store_status s=veil_source_validate(root,0);if(s)return s;
 if(root->snapshot_attempted)return VEIL_STORE_BOUND;
 ynx_source_snapshot_hold *h=calloc(1,sizeof(*h));if(!h)return VEIL_STORE_SQL;
 h->root=root;h->thread=pthread_self();root->snapshot_attempted=1;
 pthread_mutex_lock(&inventory_lock);h->next=snapshots;snapshots=h;root->snapshot_refs++;pthread_mutex_unlock(&inventory_lock);
 s=ynx_platform_snapshot_acquire(root->platform,prepared,&h->platform);
 if(!h->platform){snapshot_free(h);return s==VEIL_STORE_OK?observe(root,VEIL_STORE_UNKNOWN):observe(root,s);}
 /* Partial platform custody always returns the exact cleanup owner. */
 *out=h;if(s){h->unknown=1;observe(root,VEIL_STORE_UNKNOWN);return VEIL_STORE_UNKNOWN;}
 s=ynx_source_client_snapshot_current(h);if(s){h->unknown=1;return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;
}
veil_store_status ynx_source_client_snapshot_current(ynx_source_snapshot_hold *h){
 veil_store_status s=snapshot_recognized(h);if(s)return s;if(h->unknown)return VEIL_STORE_UNKNOWN;
 s=veil_source_validate(h->root,0);if(!s)s=ynx_platform_snapshot_current(h->platform);if(!s)s=veil_source_validate(h->root,0);
 if(s){h->unknown=1;observe(h->root,VEIL_STORE_UNKNOWN);return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;
}
veil_store_status ynx_source_client_snapshot_projection(ynx_source_snapshot_hold *h,ynx_native_snapshot_projection *p){
 if(!p)return VEIL_STORE_BOUND;memset(p,0,sizeof(*p));veil_store_status s=ynx_source_client_snapshot_current(h);if(s)return s;
 s=ynx_platform_snapshot_projection(h->platform,p);
 size_t total=0;if(!s){if(!p->rows||!p->row_count||p->row_count>64||!p->actor||!p->lease||!p->intent||!p->reserved_bytes||p->reserved_bytes>8*1024*1024||p->queue<1||p->queue>2||p->inbound_wire.size>1048576||(p->queue==1&&(!p->inbound_wire.data||!p->inbound_wire.size))||(p->queue==2&&p->inbound_wire.size))s=VEIL_STORE_BOUND;
 else for(size_t n=0;n<p->row_count;n++){const ynx_native_cohort_row *r=&p->rows[n];if(r->kind<1||r->kind>6||!r->version||r->body.size>65536||(r->body.size&&!r->body.data)||r->name.size>128||(r->name.size&&!r->name.data)||r->used_count>16||(r->used_count&&!r->used)||r->body.size>1048576-total){s=VEIL_STORE_BOUND;break;}total+=r->body.size;}}
 if(!s)s=ynx_source_client_snapshot_current(h);if(s){memset(p,0,sizeof(*p));h->unknown=1;observe(h->root,VEIL_STORE_UNKNOWN);return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;
}
veil_store_status ynx_source_client_snapshot_close(ynx_source_snapshot_hold **out){
 if(!out)return VEIL_STORE_BOUND;if(!*out)return VEIL_STORE_OK;ynx_source_snapshot_hold *h=*out;veil_store_status s=snapshot_recognized(h);if(s)return s;
 if(h->close_refused)return VEIL_STORE_UNKNOWN;s=ynx_qualified_storage_close(&h->storage);if(s){h->unknown=1;observe(h->root,VEIL_STORE_UNKNOWN);return s;}ynx_platform_snapshot_hold *original=h->platform;s=ynx_platform_snapshot_close(&h->platform);
 if(s||h->platform){if(h->platform!=original)abort();h->unknown=1;h->close_refused=1;observe(h->root,VEIL_STORE_UNKNOWN);return VEIL_STORE_UNKNOWN;}
 snapshot_free(h);*out=NULL;return VEIL_STORE_OK;
}

/* Distinct server first-device owner. Inventory/phase is local exclusion, never
 * qualification; actual static platform owns the independent joint fence. */
struct ynx_source_server_hold{ynx_platform_server_hold *platform;pthread_t thread;enum client_phase phase;int enter_attempted,retire_attempted;veil_store_status primary;struct ynx_source_server_hold *next;};
static ynx_source_server_hold *servers;static size_t server_count;
static veil_store_status server_recognized(ynx_source_server_hold *h){pthread_mutex_lock(&inventory_lock);ynx_source_server_hold *p=servers;while(p&&p!=h)p=p->next;veil_store_status s=!p?VEIL_STORE_REQUIRED:!pthread_equal(p->thread,pthread_self())?VEIL_STORE_THREAD:VEIL_STORE_OK;pthread_mutex_unlock(&inventory_lock);return s;}
static void server_free(ynx_source_server_hold *h){pthread_mutex_lock(&inventory_lock);ynx_source_server_hold **p=&servers;while(*p&&*p!=h)p=&(*p)->next;if(!*p)abort();*p=h->next;server_count--;pthread_mutex_unlock(&inventory_lock);memset(h,0,sizeof(*h));free(h);}
static veil_store_status server_unknown(ynx_source_server_hold *h,veil_store_status s){if(!h->primary)h->primary=s?s:VEIL_STORE_UNKNOWN;h->phase=CLIENT_UNKNOWN;return VEIL_STORE_UNKNOWN;}
static int server_add_bytes(ynx_original_bytes b,size_t *total){if(!b.data||!b.size||b.size>393216-*total)return 0;*total+=b.size;return 1;}
static int server_input_bound(const ynx_server_original_input *i){if(!i||!i->original.nonce||i->original.nonce_size!=32||i->original.status_history_count>255||(i->original.status_history_count&&!i->original.status_history))return 0;size_t n=32;ynx_original_bytes fields[]={i->original.root,i->original.registration,i->original.status,i->original.source,i->original.namespace_prefix,i->original.request,i->account_original,i->prepared_original};for(size_t k=0;k<8;k++)if(!server_add_bytes(fields[k],&n))return 0;for(size_t k=0;k<i->original.status_history_count;k++)if(!server_add_bytes(i->original.status_history[k],&n))return 0;return 1;}
veil_store_status ynx_source_client_server_acquire(const ynx_server_original_input *i,ynx_source_server_hold **out){
 if(!out||*out)return VEIL_STORE_BOUND;if(!server_input_bound(i))return VEIL_STORE_BOUND;
 ynx_source_server_hold *h=calloc(1,sizeof(*h));if(!h)return VEIL_STORE_SQL;h->thread=pthread_self();h->phase=CLIENT_ACQUIRING;
 pthread_mutex_lock(&inventory_lock);if(server_count>=16){pthread_mutex_unlock(&inventory_lock);free(h);return VEIL_STORE_BOUND;}h->next=servers;servers=h;server_count++;pthread_mutex_unlock(&inventory_lock);
 veil_store_status s=ynx_platform_server_acquire(i,&h->platform);
 if(!h->platform){server_free(h);return s==VEIL_STORE_OK?VEIL_STORE_UNKNOWN:s;}*out=h;
 if(s)return server_unknown(h,s);h->phase=CLIENT_ACQUIRED;
 s=ynx_source_client_server_current(h);return s?server_unknown(h,s):VEIL_STORE_OK;
}
veil_store_status ynx_source_client_server_current(ynx_source_server_hold *h){veil_store_status s=server_recognized(h);if(s)return s;if(h->phase==CLIENT_UNKNOWN)return VEIL_STORE_UNKNOWN;if(h->phase!=CLIENT_ACQUIRED&&h->phase!=CLIENT_ENTERED)return VEIL_STORE_REQUIRED;s=ynx_platform_server_current(h->platform);if(s&&h->phase==CLIENT_ENTERED)return server_unknown(h,s);return s;}
veil_store_status ynx_source_client_server_enter(ynx_source_server_hold *h){veil_store_status s=ynx_source_client_server_current(h);if(s)return s;if(h->phase!=CLIENT_ACQUIRED||h->enter_attempted)return VEIL_STORE_UNKNOWN;h->enter_attempted=1;h->phase=CLIENT_UNKNOWN;s=ynx_platform_server_enter(h->platform);if(s)return server_unknown(h,s);h->phase=CLIENT_ENTERED;s=ynx_source_client_server_current(h);return s?server_unknown(h,s):VEIL_STORE_OK;}
veil_store_status ynx_source_client_server_retire(ynx_source_server_hold *h,const ynx_server_terminal_input *i){veil_store_status s=ynx_source_client_server_current(h);if(s)return s;if(h->phase!=CLIENT_ENTERED||h->retire_attempted)return VEIL_STORE_UNKNOWN;size_t n=0;if(!i||!server_add_bytes(i->checkpoint,&n)||!server_add_bytes(i->namespace_prefix,&n)||!server_add_bytes(i->account_result,&n))return VEIL_STORE_BOUND;h->retire_attempted=1;h->phase=CLIENT_UNKNOWN;s=ynx_platform_server_retire(h->platform,i);if(s)return server_unknown(h,s);/* Platform atomically validates/retire under SAME fence; no post-retirement
 * current that could reject its own legitimate floor advancement. */h->phase=CLIENT_TERMINAL;return VEIL_STORE_OK;}
veil_store_status ynx_source_client_server_close(ynx_source_server_hold **out){if(!out)return VEIL_STORE_BOUND;if(!*out)return VEIL_STORE_OK;ynx_source_server_hold *h=*out;veil_store_status s=server_recognized(h);if(s)return s;ynx_platform_server_hold *original=h->platform;s=ynx_platform_server_close(&h->platform);if(s||h->platform){if(h->platform!=original)abort();return server_unknown(h,s?s:VEIL_STORE_BOUND);}server_free(h);*out=NULL;return VEIL_STORE_OK;}

veil_store_status ynx_source_client_server_unknown(ynx_source_server_hold *h){veil_store_status s=server_recognized(h);if(s)return s;return server_unknown(h,VEIL_STORE_UNKNOWN);}

/* Registry identity excludes stale/wrong-thread handles; it is not enrollment. */
struct ynx_source_role_hold{ynx_platform_role_hold *platform;pthread_t thread;int unknown,entered;struct ynx_source_role_hold *next;};
static ynx_source_role_hold *role_inventory;
static veil_store_status role_recognized(ynx_source_role_hold *h){pthread_mutex_lock(&inventory_lock);ynx_source_role_hold *p=role_inventory;while(p&&p!=h)p=p->next;veil_store_status s=!p?VEIL_STORE_REQUIRED:!pthread_equal(p->thread,pthread_self())?VEIL_STORE_THREAD:VEIL_STORE_OK;pthread_mutex_unlock(&inventory_lock);return s;}
veil_store_status ynx_source_client_role_acquire(const ynx_role_original_input *i,ynx_source_role_hold **out){
 if(!out||*out||!i)return VEIL_STORE_BOUND;
 if(i->role<1||i->role>2||i->purpose<1||i->purpose>2||!i->nonce||i->nonce_size!=32||i->status_history_count>255||(i->status_history_count&&!i->status_history))return VEIL_STORE_BOUND;
 size_t total=32;ynx_original_bytes fields[]={i->root,i->registration,i->status,i->credential,i->account_original,i->request,i->prepared_original,i->directory_checkpoint,i->namespace_prefix};for(size_t n=0;n<9;n++){if(n==6&&i->purpose==1){if(fields[n].size)return VEIL_STORE_BOUND;continue;}if(!server_add_bytes(fields[n],&total))return VEIL_STORE_BOUND;}for(size_t n=0;n<i->status_history_count;n++)if(!server_add_bytes(i->status_history[n],&total))return VEIL_STORE_BOUND;
 ynx_source_role_hold *h=calloc(1,sizeof(*h));if(!h)return VEIL_STORE_SQL;h->thread=pthread_self();
 veil_store_status s=ynx_platform_role_acquire(i,&h->platform);
 if(!h->platform){free(h);return s==VEIL_STORE_OK?VEIL_STORE_UNKNOWN:s;}
 pthread_mutex_lock(&inventory_lock);h->next=role_inventory;role_inventory=h;pthread_mutex_unlock(&inventory_lock);*out=h;
 if(s){h->unknown=1;return VEIL_STORE_UNKNOWN;}s=ynx_source_client_role_current(h);if(s){h->unknown=1;return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;
}
veil_store_status ynx_source_client_role_current(ynx_source_role_hold *h){veil_store_status s=role_recognized(h);if(s)return s;if(h->unknown)return VEIL_STORE_UNKNOWN;s=ynx_platform_role_current(h->platform);if(s){h->unknown=1;return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;}
veil_store_status ynx_source_client_role_projection(ynx_source_role_hold *h,ynx_role_binding *out){if(!out)return VEIL_STORE_BOUND;memset(out,0,sizeof(*out));veil_store_status s=ynx_source_client_role_current(h);if(s)return s;s=ynx_platform_role_projection(h->platform,out);if(!s)s=ynx_source_client_role_current(h);if(s){h->unknown=1;memset(out,0,sizeof(*out));return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;}
veil_store_status ynx_source_client_role_enter(ynx_source_role_hold *h){veil_store_status s=ynx_source_client_role_current(h);if(s)return s;if(h->entered)return VEIL_STORE_UNKNOWN;h->unknown=1;h->entered=1;s=ynx_platform_role_enter(h->platform);if(s)return VEIL_STORE_UNKNOWN;h->unknown=0;return ynx_source_client_role_current(h);}
veil_store_status ynx_source_client_role_close(ynx_source_role_hold **out){if(!out)return VEIL_STORE_BOUND;ynx_source_role_hold *h=*out;if(!h)return VEIL_STORE_OK;veil_store_status s=role_recognized(h);if(s)return s;ynx_platform_role_hold *old=h->platform;s=ynx_platform_role_close(&h->platform);if(s||h->platform){h->unknown=1;if(h->platform!=old)abort();return VEIL_STORE_UNKNOWN;}pthread_mutex_lock(&inventory_lock);ynx_source_role_hold **p=&role_inventory;while(*p&&*p!=h)p=&(*p)->next;if(!*p)abort();*p=h->next;pthread_mutex_unlock(&inventory_lock);memset(h,0,sizeof(*h));free(h);*out=NULL;return VEIL_STORE_OK;}

veil_store_status ynx_source_client_precommit_checkpoint(veil_source_hold *h,const ynx_precommit_readback *r){
 veil_store_status s=veil_source_validate(h,0);if(s)return s;
 if(!r||!r->intent||r->row_count>VEIL_STORE_RECORDS_MAX||(r->row_count&&!r->rows))return VEIL_STORE_BOUND;
 if(h->phase!=CLIENT_ENTERED||!h->cas_attempted||!h->cas||h->terminal_attempted)return VEIL_STORE_UNKNOWN;
 s=observe(h,ynx_platform_precommit_checkpoint(h->platform,r));if(s)return s;
 return veil_source_validate(h,0);
}

veil_store_status ynx_source_client_snapshot_protected_commit(ynx_source_snapshot_hold *h,const ynx_native_computed_step *steps,size_t count,uint32_t queue,ynx_original_bytes wire,veil_native_verified_commit **out){
 if(!out||*out)return VEIL_STORE_BOUND;veil_store_status s=ynx_source_client_snapshot_current(h);if(s)return s;if(h->commit_attempted)return VEIL_STORE_UNKNOWN;
 if(count>32||(count&&!steps)||(queue!=1&&queue!=2)||!wire.data||!wire.size||wire.size>1048576)return VEIL_STORE_BOUND;
 size_t total=wire.size;for(size_t n=0;n<count;n++){const ynx_native_computed_step *p=&steps[n];if(p->kind<1||p->kind>6||p->name.size>128||(p->name.size&&!p->name.data)||p->body.size>65536||(p->body.size&&!p->body.data)||p->body.size>4194304-total)return VEIL_STORE_BOUND;total+=p->body.size;}
 ynx_native_snapshot_projection projection={0};s=ynx_source_client_snapshot_projection(h,&projection);if(s)return s;if(projection.queue!=queue||!projection.intent)return VEIL_STORE_BOUND;
 /* Once before any possible protected write. Caller preserves SAME snapshot
  * and returned final custody on every late/partial failure; no re-encrypt. */
 h->commit_attempted=1;s=veil_private_verified_commit_snapshot_publish(h->platform,&h->storage,projection.intent,steps,count,queue,wire,out);
 if(s){if(!h->commit_primary)h->commit_primary=s;h->unknown=1;return VEIL_STORE_UNKNOWN;}s=ynx_source_client_snapshot_current(h);if(s){if(!h->commit_primary)h->commit_primary=s;h->unknown=1;return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;
}

veil_store_status ynx_source_client_snapshot_protected_lookup(ynx_source_snapshot_hold *h,veil_native_verified_commit **out){
 if(!out||*out)return VEIL_STORE_BOUND;veil_store_status s=snapshot_recognized(h);if(s)return s;
 if(!h->commit_attempted||!h->storage)return VEIL_STORE_REQUIRED;
 /* Cleanup/recovery validation is distinct from permission to start an effect.
  * No UNKNOWN reset: returned foreign finals remain private held custody. */
 s=veil_source_validate(h->root,1);if(!s)s=ynx_platform_snapshot_current(h->platform);
 if(!s)s=ynx_qualified_storage_lookup(h->storage,out);
 if(!s)s=veil_source_validate(h->root,1);
 if(s){if(!h->commit_primary)h->commit_primary=s;h->unknown=1;}
 return (s||h->unknown)?VEIL_STORE_UNKNOWN:VEIL_STORE_OK;
}

veil_store_status ynx_source_client_server_device_originals(ynx_source_server_hold *h,ynx_device_original_input *out){
 if(!out)return VEIL_STORE_BOUND;memset(out,0,sizeof(*out));veil_store_status s=server_recognized(h);if(s)return s;if(h->phase==CLIENT_UNKNOWN)return VEIL_STORE_UNKNOWN;if(h->phase!=CLIENT_TERMINAL)return VEIL_STORE_REQUIRED;
 s=ynx_platform_server_device_originals(h->platform,out);if(s){memset(out,0,sizeof(*out));if(s==VEIL_STORE_REQUIRED)return s;return server_unknown(h,s);}
 size_t n=0;if(out->version!=1||out->predecessor_count>255||(out->predecessor_count&&!out->predecessors)||!server_add_bytes(out->final,&n)||!server_add_bytes(out->current,&n)||!server_add_bytes(out->terminal,&n)||!server_add_bytes(out->checkpoint,&n)){memset(out,0,sizeof(*out));return server_unknown(h,VEIL_STORE_BOUND);}
 for(size_t i=0;i<out->predecessor_count;i++)if(!server_add_bytes(out->predecessors[i],&n)){memset(out,0,sizeof(*out));return server_unknown(h,VEIL_STORE_BOUND);}return VEIL_STORE_OK;
}

/* Native backend startup now owns the same authenticated source/plane/origin
 * through one normal supplier call. This inventory only preserves lifetime;
 * neither OK nor its pointer grants a storage/exclusive/floor capability. */
extern int32_t ynx_sdk_fixed_startup_initialize_core_v2(const ynx_native_core_startup_input_v2 *,void **);
extern int32_t ynx_sdk_native_core_startup_current_v2(void *);
extern int32_t ynx_sdk_native_core_startup_diagnostic_v2(void *,int32_t *,uint32_t *);
extern int32_t ynx_sdk_startup_evidence_close_v1(void **);
struct ynx_native_core_startup_hold{pthread_t thread;void *original;veil_store_status first;int unknown;struct ynx_native_core_startup_hold *next;};
static pthread_mutex_t core_startup_lock=PTHREAD_MUTEX_INITIALIZER;
static ynx_native_core_startup_hold *core_startups;
static size_t core_startup_count;
static ynx_native_core_startup_hold*core_startup_recognized(ynx_native_core_startup_hold*p){pthread_mutex_lock(&core_startup_lock);ynx_native_core_startup_hold*q=core_startups;while(q&&q!=p)q=q->next;pthread_mutex_unlock(&core_startup_lock);return q;}
static veil_store_status core_startup_fail(ynx_native_core_startup_hold*p,veil_store_status s){
 if(!p->first){int32_t first=0;uint32_t uncertain=0;veil_store_status diagnostic=p->original?(veil_store_status)ynx_sdk_native_core_startup_diagnostic_v2(p->original,&first,&uncertain):VEIL_STORE_REQUIRED;
  p->first=!diagnostic&&first?(veil_store_status)first:s;}
 p->unknown=1;return VEIL_STORE_UNKNOWN;
}
veil_store_status ynx_source_client_native_core_startup_v2(const ynx_native_core_startup_input_v2*input,ynx_native_core_startup_hold**out){
 if(!out||*out||!input||input->version!=2||input->size!=sizeof(*input))return VEIL_STORE_BOUND;
 pthread_mutex_lock(&core_startup_lock);if(core_startup_count>=32){pthread_mutex_unlock(&core_startup_lock);return VEIL_STORE_BOUND;}core_startup_count++;pthread_mutex_unlock(&core_startup_lock);
 ynx_native_core_startup_hold*p=calloc(1,sizeof(*p));if(!p){pthread_mutex_lock(&core_startup_lock);core_startup_count--;pthread_mutex_unlock(&core_startup_lock);return VEIL_STORE_SQL;}p->thread=pthread_self();
 veil_store_status s=(veil_store_status)ynx_sdk_fixed_startup_initialize_core_v2(input,&p->original);
 if(!p->original){pthread_mutex_lock(&core_startup_lock);core_startup_count--;pthread_mutex_unlock(&core_startup_lock);free(p);return s?s:VEIL_STORE_UNKNOWN;}
 pthread_mutex_lock(&core_startup_lock);p->next=core_startups;core_startups=p;*out=p;pthread_mutex_unlock(&core_startup_lock);
 if(s)return core_startup_fail(p,s);return ynx_source_client_native_core_startup_current_v2(p);
}
veil_store_status ynx_source_client_native_core_startup_current_v2(ynx_native_core_startup_hold*p){
 ynx_native_core_startup_hold*q=core_startup_recognized(p);if(!q)return VEIL_STORE_REQUIRED;if(!pthread_equal(q->thread,pthread_self()))return VEIL_STORE_THREAD;if(q->unknown)return VEIL_STORE_UNKNOWN;
 veil_store_status s=(veil_store_status)ynx_sdk_native_core_startup_current_v2(q->original);return s?core_startup_fail(q,s):VEIL_STORE_OK;
}
veil_store_status ynx_source_client_native_core_startup_close_v2(ynx_native_core_startup_hold**slot){
 if(!slot)return VEIL_STORE_BOUND;if(!*slot)return VEIL_STORE_OK;ynx_native_core_startup_hold*q=core_startup_recognized(*slot);if(!q)return VEIL_STORE_REQUIRED;if(!pthread_equal(q->thread,pthread_self()))return VEIL_STORE_THREAD;
 void*before=q->original;veil_store_status s=(veil_store_status)ynx_sdk_startup_evidence_close_v1(&q->original);
 if(q->original&&q->original!=before)abort();if(s&&!q->original&&s!=VEIL_STORE_UNKNOWN)abort();if(s)core_startup_fail(q,s);if(q->original)return core_startup_fail(q,s?s:VEIL_STORE_UNKNOWN);
 pthread_mutex_lock(&core_startup_lock);ynx_native_core_startup_hold**p=&core_startups;while(*p&&*p!=q)p=&(*p)->next;if(!*p)abort();*p=q->next;core_startup_count--;pthread_mutex_unlock(&core_startup_lock);int unresolved=q->unknown;memset(q,0,sizeof(*q));free(q);*slot=NULL;return unresolved?VEIL_STORE_UNKNOWN:VEIL_STORE_OK;
}
