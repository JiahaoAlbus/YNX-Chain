#ifndef YNX_SOURCE_ORIGINAL_RESOURCE_OWNER_H
#define YNX_SOURCE_ORIGINAL_RESOURCE_OWNER_H
#include "ynx_source_administration_owner.h"
/* Private selected Native executor. Input administration is recognized by its
 * own inventory and actual policy/resource current; no pointer grants entry. */
typedef struct ynx_original_executor ynx_original_executor;
typedef enum {YNX_EXEC_RESERVED=1,YNX_EXEC_ENTERED=2,YNX_EXEC_BURNED=3,YNX_EXEC_ALLOCATED=4,YNX_EXEC_CAS=5,YNX_EXEC_TERMINAL=6} ynx_executor_phase;
veil_store_status ynx_original_executor_acquire(ynx_administration_owner *,ynx_original_bytes,uint64_t,ynx_original_executor **);
veil_store_status ynx_original_executor_current(ynx_original_executor *);
veil_store_status ynx_original_executor_advance(ynx_original_executor *,ynx_executor_phase,ynx_original_bytes);
veil_store_status ynx_original_executor_original(ynx_original_executor *,ynx_original_bytes *,ynx_executor_phase *);
/* UNKNOWN recovery observes the same durable intent; never starts new work. */
veil_store_status ynx_original_executor_observe(ynx_original_executor *,ynx_executor_phase *);
veil_store_status ynx_original_executor_close(ynx_original_executor **);
/* Private NativeCore registered-resource PARTIAL custody. Unlike the
 * administration executor, this type never borrows an administration grant.
 * A current observation does not admit a store, allocator/floor or projection. */
typedef struct ynx_native_core_resource_loan ynx_native_core_resource_loan;
veil_store_status ynx_native_core_resource_acquire_v2(void *,ynx_native_core_resource_loan **);
veil_store_status ynx_native_core_resource_acquire(void *same_core_policy,ynx_native_core_resource_loan **);
veil_store_status ynx_native_core_resource_observe_current(ynx_native_core_resource_loan *);
veil_store_status ynx_native_core_resource_close(ynx_native_core_resource_loan **);
/* Cleanup-only original cause, no business current or Ready projection. */
veil_store_status ynx_native_core_resource_first_cause(ynx_native_core_resource_loan *);
/* Same NativeCore operation's authenticated original participant custody.
 * Not an enforcing owner: qualification needs the separately registered,
 * actual key-use/current/revoke/head/floor owning execution primitive. */
typedef struct ynx_native_core_participant ynx_native_core_participant;
typedef struct ynx_native_core_participant_originals_v2 {
 uint32_t version,purpose;uint64_t storage_generation,deadline;
 unsigned char intent_digest[32];
 ynx_original_bytes approval,issuer_current,anchor_current,association,account,operation;
 ynx_original_bytes origin[6],accepted_relation;
} ynx_native_core_participant_originals_v2;
_Static_assert(sizeof(ynx_native_core_participant_originals_v2)==264,"participant originals264");
veil_store_status ynx_native_core_participant_acquire_v2(void *,ynx_native_core_participant **);
veil_store_status ynx_native_core_participant_current(ynx_native_core_participant *);
veil_store_status ynx_native_core_participant_close(ynx_native_core_participant **);
#endif
