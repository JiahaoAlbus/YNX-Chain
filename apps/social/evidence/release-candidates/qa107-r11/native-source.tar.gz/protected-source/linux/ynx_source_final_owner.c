#include "ynx_source_final_owner.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
/* This real object owns a checked-store finish reference, not copied records.
 * A refused independent terminal never inhabits a qualified final root. */
struct ynx_platform_final_hold {
 veil_native_finish_result *finish;
 const veil_native_intent_handle *intent;
 ynx_finish_commit_original commit;
 pthread_t thread;
 veil_store_status primary;
 int refused;
 struct ynx_platform_final_hold *next;
};
static pthread_mutex_t final_hold_lock=PTHREAD_MUTEX_INITIALIZER;
static ynx_platform_final_hold *final_holds;
static size_t final_hold_count;
static veil_store_status final_hold_recognized(ynx_platform_final_hold *h){
 pthread_mutex_lock(&final_hold_lock);ynx_platform_final_hold *p=final_holds;while(p&&p!=h)p=p->next;
 veil_store_status s=!p?VEIL_STORE_REQUIRED:!pthread_equal(p->thread,pthread_self())?VEIL_STORE_THREAD:VEIL_STORE_OK;
 pthread_mutex_unlock(&final_hold_lock);return s;
}
veil_store_status ynx_final_hold_reserve(veil_native_finish_result *finish,ynx_platform_final_hold **out){
 if(!out||*out)return VEIL_STORE_BOUND;
 ynx_platform_final_hold *h=calloc(1,sizeof(*h));if(!h)return VEIL_STORE_SQL;
 pthread_mutex_lock(&final_hold_lock);if(final_hold_count>=32){pthread_mutex_unlock(&final_hold_lock);free(h);return VEIL_STORE_BOUND;}final_hold_count++;pthread_mutex_unlock(&final_hold_lock);
 veil_store_status s=ynx_finish_original_retain(finish,&h->finish,&h->intent);
 if(s){pthread_mutex_lock(&final_hold_lock);final_hold_count--;pthread_mutex_unlock(&final_hold_lock);free(h);return s;}
 s=ynx_finish_original_commit_borrow(h->finish,&h->commit);
 if(s){
  /* The real finish reference already exists: retain cleanup custody before
   * reporting a late refusal, never release/reacquire the original. */
  h->primary=s;h->refused=1;
 }
 h->thread=pthread_self();pthread_mutex_lock(&final_hold_lock);h->next=final_holds;final_holds=h;pthread_mutex_unlock(&final_hold_lock);*out=h;return s?VEIL_STORE_UNKNOWN:VEIL_STORE_OK;
}
veil_store_status ynx_final_hold_refuse(ynx_platform_final_hold *h,veil_store_status cause){
 veil_store_status s=final_hold_recognized(h);if(s)return s;if(!cause)return VEIL_STORE_BOUND;
 if(!h->primary)h->primary=cause;h->refused=1;return VEIL_STORE_UNKNOWN;
}
veil_store_status ynx_final_hold_current(ynx_platform_final_hold *h){
 veil_store_status s=final_hold_recognized(h);if(s)return s;
 if(h->refused)return VEIL_STORE_UNKNOWN;
 s=ynx_finish_original_current(h->finish);if(s){if(!h->primary)h->primary=s;h->refused=1;return VEIL_STORE_UNKNOWN;}
 ynx_finish_commit_original now={0};s=ynx_finish_original_commit_borrow(h->finish,&now);
 if(s||memcmp(now.operation,h->commit.operation,sizeof(now.operation))||memcmp(now.account,h->commit.account,sizeof(now.account))||memcmp(now.device,h->commit.device,sizeof(now.device))||memcmp(now.identity,h->commit.identity,sizeof(now.identity))||memcmp(now.storage_key,h->commit.storage_key,sizeof(now.storage_key))||memcmp(now.base_hash,h->commit.base_hash,sizeof(now.base_hash))||memcmp(now.next_hash,h->commit.next_hash,sizeof(now.next_hash))||memcmp(now.cipher_hash,h->commit.cipher_hash,sizeof(now.cipher_hash))||now.base_revision!=h->commit.base_revision||now.next_revision!=h->commit.next_revision||now.authorization_generation!=h->commit.authorization_generation||now.journal_steps!=h->commit.journal_steps||now.receipt!=h->commit.receipt||now.receipt_size!=h->commit.receipt_size||now.ciphertext!=h->commit.ciphertext||now.ciphertext_size!=h->commit.ciphertext_size||now.journal!=h->commit.journal||now.journal_size!=h->commit.journal_size||memcmp(now.journal_digest,h->commit.journal_digest,32)||memcmp(&now.origin,&h->commit.origin,sizeof(now.origin))){if(!h->primary)h->primary=s?s:VEIL_STORE_MISMATCH;h->refused=1;return VEIL_STORE_UNKNOWN;}
 /* Reserve is only held local custody. No terminal decision has been supplied
  * by the independent protected producer, so it cannot publish capabilities. */
 return VEIL_STORE_REQUIRED;
}
veil_store_status ynx_final_hold_close(ynx_platform_final_hold **slot){
 if(!slot)return VEIL_STORE_BOUND;if(!*slot)return VEIL_STORE_OK;
 ynx_platform_final_hold *h=*slot;veil_store_status s=final_hold_recognized(h);if(s)return s;
 veil_native_finish_result *original=h->finish;s=veil_native_finish_result_drop(&h->finish);
 if(s||h->finish){if(h->finish!=original)abort();if(!h->primary)h->primary=s?s:VEIL_STORE_BOUND;h->refused=1;return VEIL_STORE_UNKNOWN;}
 pthread_mutex_lock(&final_hold_lock);ynx_platform_final_hold **p=&final_holds;while(*p&&*p!=h)p=&(*p)->next;if(!*p)abort();*p=h->next;final_hold_count--;pthread_mutex_unlock(&final_hold_lock);
 memset(h,0,sizeof(*h));free(h);*slot=NULL;return VEIL_STORE_OK;
}
