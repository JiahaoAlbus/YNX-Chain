#include "ynx_source_independent_reservation.h"
#include <openssl/crypto.h>
#include <openssl/hmac.h>
#include <openssl/sha.h>
#include <string.h>
static int separate(const void*a,size_t an,const void*b,size_t bn){uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;if(!a||!b||an>UINTPTR_MAX-x||bn>UINTPTR_MAX-y)return 0;return x+an<=y||y+bn<=x;}
static uint64_t read64(const unsigned char*p){uint64_t v=0;for(size_t i=0;i<8;i++)v=(v<<8)|p[i];return v;}
static void write64(unsigned char*p,uint64_t v){for(size_t i=0;i<8;i++){p[7-i]=(unsigned char)v;v>>=8;}}
static int nonzero(const unsigned char*p,size_t n){unsigned char v=0;for(size_t i=0;i<n;i++)v|=p[i];return v!=0;}
veil_store_status ynx_independent_state_match(const ynx_independent_original_state*s,const ynx_storage_expected*e){
 static const unsigned char domain[]="YNX/PRIVATE/INDEPENDENT-RESERVATION/V1";
 if(!s||!e||e->container_class!=YNX_STORAGE_RECORD||e->name.size!=sizeof(domain)-1||!e->name.data||memcmp(e->name.data,domain,sizeof(domain)-1)||s->phase<1||s->phase>3||!s->generation||!s->sequence||s->floor>s->counter||s->generation!=e->generation||s->sequence!=e->next_version||!nonzero(s->head,32)||!nonzero(s->checkpoint,32)||!nonzero(s->registration,32)||!nonzero(s->request,32)||!nonzero(s->nonce,32)||(s->phase>1&&!nonzero(s->ciphertext_digest,32))||CRYPTO_memcmp(s->request,e->request,32)||CRYPTO_memcmp(s->nonce,e->operation_nonce,32))return VEIL_STORE_MISMATCH;
 return VEIL_STORE_OK;
}
static void encode(const ynx_independent_original_state*s,unsigned char raw[YNX_INDEPENDENT_STATE_BYTES]){
 memset(raw,0,YNX_INDEPENDENT_STATE_BYTES);memcpy(raw,"YNXIST1\0",8);raw[9]=1;raw[11]=(unsigned char)s->phase;
 write64(raw+24,s->generation);write64(raw+32,s->sequence);write64(raw+40,s->counter);write64(raw+48,s->floor);
 memcpy(raw+56,s->head,32);memcpy(raw+88,s->checkpoint,32);memcpy(raw+120,s->registration,32);memcpy(raw+152,s->request,32);memcpy(raw+184,s->nonce,32);memcpy(raw+216,s->ciphertext_digest,32);
}
veil_store_status ynx_independent_state_open(const unsigned char key[32],const ynx_storage_expected*e,ynx_original_bytes blob,unsigned char*sink,size_t cap,ynx_independent_original_state*out){
 if(!out||!key||!e||!sink||cap!=YNX_INDEPENDENT_STATE_BYTES||!blob.data||!separate(out,sizeof(*out),key,32)||!separate(out,sizeof(*out),e,sizeof(*e))||!separate(out,sizeof(*out),sink,cap)||!separate(out,sizeof(*out),blob.data,blob.size)||!separate(sink,cap,key,32)||!separate(sink,cap,e,sizeof(*e))||!separate(sink,cap,blob.data,blob.size)||!e->name.data||!separate(out,sizeof(*out),e->name.data,e->name.size)||!separate(sink,cap,e->name.data,e->name.size))return VEIL_STORE_BOUND;
 memset(out,0,sizeof(*out));
 size_t n=0;veil_store_status st=ynx_storage_open(key,e,blob,sink,cap,&n);
 if(st){OPENSSL_cleanse(sink,cap);return st;}
 if(n!=cap||memcmp(sink,"YNXIST1\0",8)||sink[8]||sink[9]!=1||sink[10]||sink[11]<1||sink[11]>3){OPENSSL_cleanse(sink,cap);return VEIL_STORE_MISMATCH;}
 for(size_t i=12;i<24;i++)if(sink[i]){OPENSSL_cleanse(sink,cap);return VEIL_STORE_MISMATCH;}
 ynx_independent_original_state s={0};s.phase=sink[11];s.generation=read64(sink+24);s.sequence=read64(sink+32);s.counter=read64(sink+40);s.floor=read64(sink+48);
 memcpy(s.head,sink+56,32);memcpy(s.checkpoint,sink+88,32);memcpy(s.registration,sink+120,32);memcpy(s.request,sink+152,32);memcpy(s.nonce,sink+184,32);memcpy(s.ciphertext_digest,sink+216,32);
 st=ynx_independent_state_match(&s,e);OPENSSL_cleanse(sink,cap);if(!st)*out=s;OPENSSL_cleanse(&s,sizeof(s));return st;
}
veil_store_status ynx_independent_state_seal(const unsigned char key[32],const ynx_storage_expected*e,const ynx_independent_original_state*s,ynx_storage_ciphertext*out){
 veil_store_status st=ynx_independent_state_match(s,e);if(st)return st;
 unsigned char raw[YNX_INDEPENDENT_STATE_BYTES];encode(s,raw);st=ynx_storage_seal(key,e,(ynx_original_bytes){raw,sizeof(raw)},out);OPENSSL_cleanse(raw,sizeof(raw));return st;
}
static int allocator_valid(const ynx_allocator_journal*s){
 return s&&s->epoch&&s->key_generation&&s->sequence&&s->deadline&&s->phase>=1&&s->phase<=4&&s->floor<=s->ordinal&&nonzero(s->allocator,32)&&nonzero(s->key_identity,32)&&nonzero(s->intent,32)&&nonzero(s->head,32)&&nonzero(s->registration,32);
}
static void allocator_encode(const ynx_allocator_journal*s,unsigned char*p){
 memset(p,0,256);memcpy(p,"YNXALC1\0",8);p[9]=1;p[11]=(unsigned char)s->phase;
 for(size_t i=0;i<4;i++)p[15-i]=(unsigned char)(s->epoch>>(i*8));
 write64(p+16,s->key_generation);write64(p+24,s->ordinal);write64(p+32,s->sequence);write64(p+40,s->floor);write64(p+48,s->deadline);
 memcpy(p+56,s->allocator,32);memcpy(p+88,s->key_identity,32);memcpy(p+120,s->intent,32);memcpy(p+152,s->head,32);memcpy(p+184,s->registration,32);memcpy(p+216,s->predecessor,32);
}
veil_store_status ynx_allocator_journal_encode(const unsigned char key[32],const ynx_allocator_journal*s,unsigned char*out){
 if(!key||!out||!allocator_valid(s)||!separate(out,YNX_ALLOCATOR_JOURNAL_BYTES,key,32)||!separate(out,YNX_ALLOCATOR_JOURNAL_BYTES,s,sizeof(*s)))return VEIL_STORE_BOUND;
 unsigned char raw[YNX_ALLOCATOR_JOURNAL_BYTES];allocator_encode(s,raw);unsigned n=0;
 if(!HMAC(EVP_sha256(),key,32,raw,256,raw+256,&n)||n!=32){OPENSSL_cleanse(raw,sizeof(raw));return VEIL_STORE_UNKNOWN;}
 memcpy(out,raw,sizeof(raw));OPENSSL_cleanse(raw,sizeof(raw));return VEIL_STORE_OK;
}
veil_store_status ynx_allocator_journal_decode(const unsigned char key[32],ynx_original_bytes original,const ynx_allocator_journal*e,ynx_allocator_journal*out){
 if(!key||!original.data||original.size!=YNX_ALLOCATOR_JOURNAL_BYTES||!out||!allocator_valid(e)||!separate(out,sizeof(*out),key,32)||!separate(out,sizeof(*out),e,sizeof(*e))||!separate(out,sizeof(*out),original.data,original.size))return VEIL_STORE_BOUND;
 const unsigned char*p=original.data;unsigned char mac[32];unsigned n=0;
 if(!HMAC(EVP_sha256(),key,32,p,256,mac,&n)||n!=32){OPENSSL_cleanse(mac,32);return VEIL_STORE_UNKNOWN;}
 int authenticated=CRYPTO_memcmp(mac,p+256,32)==0;OPENSSL_cleanse(mac,32);if(!authenticated)return VEIL_STORE_MISMATCH;
 if(memcmp(p,"YNXALC1\0",8)||p[8]||p[9]!=1||p[10]||p[11]<1||p[11]>4)return VEIL_STORE_MISMATCH;
 for(size_t i=248;i<256;i++)if(p[i])return VEIL_STORE_MISMATCH;
 ynx_allocator_journal s={0};s.phase=p[11];for(size_t i=12;i<16;i++)s.epoch=(s.epoch<<8)|p[i];s.key_generation=read64(p+16);s.ordinal=read64(p+24);s.sequence=read64(p+32);s.floor=read64(p+40);s.deadline=read64(p+48);
 memcpy(s.allocator,p+56,32);memcpy(s.key_identity,p+88,32);memcpy(s.intent,p+120,32);memcpy(s.head,p+152,32);memcpy(s.registration,p+184,32);memcpy(s.predecessor,p+216,32);
 /* The complete expected original comes from the independent retained owner,
  * never from decoded response fields. A MAC authenticates no substitutions. */
 unsigned char expected[256];allocator_encode(e,expected);int match=allocator_valid(&s)&&!CRYPTO_memcmp(expected,p,256);OPENSSL_cleanse(expected,sizeof(expected));
 if(match)*out=s;OPENSSL_cleanse(&s,sizeof(s));return match?VEIL_STORE_OK:VEIL_STORE_MISMATCH;
}
veil_store_status ynx_allocator_journal_transition(const unsigned char key[32],ynx_original_bytes raw,const ynx_allocator_journal*previous,const unsigned char intent[32],uint32_t phase,ynx_allocator_journal*out){
 if(!key||!previous||!intent||!out||!raw.data||raw.size!=YNX_ALLOCATOR_JOURNAL_BYTES||!nonzero(intent,32)||!separate(out,sizeof(*out),key,32)||!separate(out,sizeof(*out),previous,sizeof(*previous))||!separate(out,sizeof(*out),intent,32)||!separate(out,sizeof(*out),raw.data,raw.size))return VEIL_STORE_BOUND;
 /* ENTERED/UNKNOWN can never transition back to PREPARED or to ALLOCATED
  * through a codec. Allocation requires the independent owning adjudicator. */
 if(!((previous->phase==3&&phase==1)||(previous->phase==1&&phase==2)||(previous->phase==2&&phase==4)))return VEIL_STORE_FROZEN;
 if(previous->sequence==UINT64_MAX)return VEIL_STORE_BOUND;
 if(previous->phase!=3&&CRYPTO_memcmp(previous->intent,intent,32))return VEIL_STORE_MISMATCH;
 ynx_allocator_journal authenticated={0};veil_store_status s=ynx_allocator_journal_decode(key,raw,previous,&authenticated);if(s)return s;
 ynx_allocator_journal next=authenticated;next.phase=phase;next.sequence++;memcpy(next.intent,intent,32);
 if(!SHA256(raw.data,raw.size,next.predecessor)){OPENSSL_cleanse(&authenticated,sizeof(authenticated));OPENSSL_cleanse(&next,sizeof(next));return VEIL_STORE_UNKNOWN;}
 /* ordinal/head/floor/key-generation/epoch/deadline remain the ORIGINAL
  * independently held values. Neither increment nor returned counter selects
  * them; phase3 cannot be produced by this transition function. */
 *out=next;OPENSSL_cleanse(&authenticated,sizeof(authenticated));OPENSSL_cleanse(&next,sizeof(next));return VEIL_STORE_OK;
}
static void domain_encode(const ynx_domain_state*s,unsigned char b[320]){
 memset(b,0,320);memcpy(b,"YNXDOM1\0",8);write64(b+8,s->phase);write64(b+16,s->epoch);write64(b+24,s->generation);write64(b+32,s->ordinal);write64(b+40,s->sequence);write64(b+48,s->floor);write64(b+56,s->deadline);
 memcpy(b+64,s->domain,32);memcpy(b+96,s->key_identity,32);memcpy(b+128,s->intent,32);memcpy(b+160,s->head,32);memcpy(b+192,s->registration,32);memcpy(b+224,s->ciphertext,32);memcpy(b+256,s->predecessor,32);
}
veil_store_status ynx_domain_state_encode(const unsigned char key[32],const ynx_domain_state*s,unsigned char out[YNX_DOMAIN_STATE_BYTES]){
 if(!key||!s||!out||s->phase<1||s->phase>6||!s->epoch||!s->generation||!s->sequence||!s->deadline||!nonzero(s->domain,32)||!nonzero(s->key_identity,32)||!nonzero(s->registration,32))return VEIL_STORE_BOUND;
 domain_encode(s,out);unsigned n=0;if(!HMAC(EVP_sha256(),key,32,out,320,out+320,&n)||n!=32){OPENSSL_cleanse(out,YNX_DOMAIN_STATE_BYTES);return VEIL_STORE_UNKNOWN;}return VEIL_STORE_OK;
}
veil_store_status ynx_domain_state_decode(const unsigned char key[32],ynx_original_bytes raw,ynx_domain_state*out){
 if(!key||!out||!raw.data||raw.size!=YNX_DOMAIN_STATE_BYTES)return VEIL_STORE_BOUND;
 unsigned char tag[32];unsigned n=0;if(!HMAC(EVP_sha256(),key,32,raw.data,320,tag,&n)||n!=32)return VEIL_STORE_UNKNOWN;int equal=!CRYPTO_memcmp(tag,raw.data+320,32);OPENSSL_cleanse(tag,32);if(!equal)return VEIL_STORE_MISMATCH;
 const unsigned char*b=raw.data;if(memcmp(b,"YNXDOM1\0",8)||read64(b+8)>UINT32_MAX||read64(b+16)>UINT32_MAX)return VEIL_STORE_MISMATCH;for(size_t i=288;i<320;i++)if(b[i])return VEIL_STORE_MISMATCH;
 ynx_domain_state s={.phase=(uint32_t)read64(b+8),.epoch=(uint32_t)read64(b+16),.generation=read64(b+24),.ordinal=read64(b+32),.sequence=read64(b+40),.floor=read64(b+48),.deadline=read64(b+56)};
 memcpy(s.domain,b+64,32);memcpy(s.key_identity,b+96,32);memcpy(s.intent,b+128,32);memcpy(s.head,b+160,32);memcpy(s.registration,b+192,32);memcpy(s.ciphertext,b+224,32);memcpy(s.predecessor,b+256,32);
 unsigned char canonical[YNX_DOMAIN_STATE_BYTES];veil_store_status st=ynx_domain_state_encode(key,&s,canonical);if(!st&&CRYPTO_memcmp(canonical,b,raw.size))st=VEIL_STORE_MISMATCH;OPENSSL_cleanse(canonical,sizeof(canonical));if(!st)*out=s;OPENSSL_cleanse(&s,sizeof(s));return st;
}
