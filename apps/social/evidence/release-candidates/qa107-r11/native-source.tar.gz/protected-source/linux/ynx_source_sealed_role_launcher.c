#define _GNU_SOURCE
#include "ynx_source_sealed_role_launcher.h"
#include <pthread.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <tss2_mu.h>
#include <openssl/rand.h>
#include <openssl/ssl.h>
#include <limits.h>
#if defined(__linux__)
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/mman.h>
#endif
struct ynx_source_sealed_role_owner { ynx_tpm2_owner *tpm; pthread_t thread; int attempted,retired,first; };
static int dedicated_protect(void){
#if defined(__linux__)
 struct rlimit core={0,0};
 if(setrlimit(RLIMIT_CORE,&core))return YNX_TPM2_RESOURCE;
 if(prctl(PR_SET_DUMPABLE,0,0,0,0))return YNX_TPM2_RESOURCE;
 if(mlockall(MCL_CURRENT|MCL_FUTURE))return YNX_TPM2_RESOURCE;
 return YNX_TPM2_OK;
#else
 return YNX_TPM2_REQUIRED;
#endif
}
/* Private normal provisioning entry: same pre-allocation Linux governance,
 * never a platform grant or successful resource factory. */
int ynx_source_dedicated_protection_enter(void){return dedicated_protect();}
static int same_thread(ynx_source_sealed_role_owner *p){return p&&pthread_equal(p->thread,pthread_self());}
int ynx_source_sealed_role_dedicated_open(const ynx_tpm2_resource_selection *s,ynx_source_sealed_role_owner **out){
 if(!s||!out||*out)return YNX_TPM2_REFUSED;
 /* Irreversible process governance occurs before even the owner allocation. */
 int rc=dedicated_protect();if(rc)return rc;
 ynx_source_sealed_role_owner *p=calloc(1,sizeof(*p));if(!p)return YNX_TPM2_RESOURCE;
 p->thread=pthread_self();*out=p;
 rc=ynx_tpm2_owner_open(s,&p->tpm);if(rc){p->first=rc;p->retired=1;}return rc;
}
int ynx_source_sealed_role_current(ynx_source_sealed_role_owner *p){
 if(!same_thread(p))return YNX_TPM2_REFUSED;
 if(p->retired)return p->first?p->first:YNX_TPM2_UNKNOWN;
 int rc=ynx_tpm2_owner_current(p->tpm);if(rc){p->retired=1;if(!p->first)p->first=rc;}return rc;
}
int ynx_source_sealed_role_wrapping_open(ynx_source_sealed_role_owner *p,ynx_source_wrapping_owner **out){
 if(!out||*out||!same_thread(p))return YNX_TPM2_REFUSED;
 int rc=ynx_source_sealed_role_current(p);if(rc)return rc;
 if(p->attempted)return YNX_TPM2_UNKNOWN;
 p->attempted=1; /* before Unseal; no retry on partial output */
 rc=ynx_tpm2_owner_unseal(p->tpm);if(!rc)rc=ynx_source_wrapping_from_tpm(p->tpm,out);
 if(!rc)rc=ynx_source_sealed_role_current(p);
 if(rc){p->retired=1;if(!p->first)p->first=rc;}return rc;
}
int ynx_source_sealed_role_close(ynx_source_sealed_role_owner **owner){
 if(!owner)return YNX_TPM2_REFUSED;if(!*owner)return YNX_TPM2_OK;
 ynx_source_sealed_role_owner *p=*owner;if(!same_thread(p))return YNX_TPM2_REFUSED;
 p->retired=1;int rc=ynx_tpm2_owner_close(&p->tpm);
 if(p->tpm){if(!p->first)p->first=rc?rc:YNX_TPM2_UNKNOWN;return rc?rc:YNX_TPM2_UNKNOWN;}
 int unresolved=p->first||rc==YNX_TPM2_UNKNOWN;free(p);*owner=NULL;return unresolved?YNX_TPM2_UNKNOWN:rc;
 /* Never munlockall: retained siblings/ESAPI allocations share process policy. */
}
int ynx_source_sealed_role_monotonic_ns(uint64_t *out){
 struct timespec t;if(!out||clock_gettime(CLOCK_MONOTONIC,&t)||t.tv_sec<0||(uint64_t)t.tv_sec>UINT64_MAX/1000000000)return YNX_TPM2_REFUSED;
 *out=(uint64_t)t.tv_sec*1000000000+(uint64_t)t.tv_nsec;return YNX_TPM2_OK;
}
int ynx_source_sealed_role_resolve_open(const ynx_source_verified_credential_input *s,ynx_source_sealed_role_owner **out){
 if(!s||!s->raw||!s->n||s->n>65536||s->role<1||s->role>2||s->purpose<1||s->purpose>2||!s->monotonic_deadline_ns||s->not_before_ms<0||s->expires_ms<=s->not_before_ms||!out||*out)return YNX_TPM2_REFUSED;
 struct timespec wall,mono;
 if(clock_gettime(CLOCK_REALTIME,&wall)||clock_gettime(CLOCK_MONOTONIC,&mono)||wall.tv_sec<0||mono.tv_sec<0||(uint64_t)wall.tv_sec>(uint64_t)INT64_MAX/1000||(uint64_t)mono.tv_sec>UINT64_MAX/1000000000)return YNX_TPM2_REFUSED;
 int64_t now=(int64_t)wall.tv_sec*1000+wall.tv_nsec/1000000;
 uint64_t monotonic=(uint64_t)mono.tv_sec*1000000000+(uint64_t)mono.tv_nsec;
 if(now<s->not_before_ms||now>=s->expires_ms||monotonic>=s->monotonic_deadline_ns)return YNX_TPM2_REFUSED;
 /* There is no admitted credential-to-TPM/domain association carrier. A future
  * verified acquisition must keep s->monotonic_deadline_ns as its fixed upper
  * bound, intersect signed bounds, and never retain this synchronous raw borrow.
  * This precise borrowed context alone cannot populate a resource selection. */
 return YNX_TPM2_REQUIRED;
}
static int message_window(const ynx_message_sealed_custody_input *input){
 struct timespec wall;uint64_t mono=0;
 if(!input||!input->enrollment||!input->enrollment->original||input->not_before_ms<0||input->expires_ms<=input->not_before_ms||clock_gettime(CLOCK_REALTIME,&wall)||wall.tv_sec<0||(uint64_t)wall.tv_sec>(uint64_t)INT64_MAX/1000||ynx_source_sealed_role_monotonic_ns(&mono))return YNX_TPM2_REFUSED;
 int64_t now=(int64_t)wall.tv_sec*1000+wall.tv_nsec/1000000;
 const ynx_tpm2_resource_selection *selected=input->enrollment->original;
 if(!selected->monotonic_deadline_ns||mono>=selected->monotonic_deadline_ns||now<input->not_before_ms||now>=input->expires_ms)return YNX_TPM2_REFUSED;
 return YNX_TPM2_OK;
}
int ynx_source_message_sealed_open(const ynx_message_sealed_custody_input *input,ynx_source_sealed_role_owner **out){
 if(!out||*out)return YNX_TPM2_REFUSED;
 int rc=message_window(input);if(rc)return rc;
 rc=ynx_message_enrollment_validate_public(input->enrollment);if(rc)return rc;
 /* This is the actual dedicated protection -> named ESAPI owner constructor,
  * not a purpose1/2 credential conversion or a public evidence capability. */
 rc=ynx_source_sealed_role_dedicated_open(input->enrollment->original,out);
 if(!rc&&!*out)rc=YNX_TPM2_UNKNOWN;
 if(!rc)rc=ynx_source_sealed_role_current(*out);
 if(!rc)rc=message_window(input);
 if(rc&&*out){(*out)->retired=1;if(!(*out)->first)(*out)->first=rc;}
 return rc; /* any partial original remains callable for explicit cleanup */
}
static int message_raw_decode(const ynx_message_sealed_raw_input *raw,ynx_tpm2_resource_selection *selected,ynx_message_enrollment_public_input *public){
 if(!raw||!selected||!public||raw->device>1)return YNX_TPM2_REFUSED;
 ynx_tpm2_resource_selection s={0};s.device=raw->device?"/dev/tpm0":"/dev/tpmrm0";
 s.sealed_object=raw->handles[0];s.salt_key=raw->handles[1];s.attestation_key=raw->handles[2];s.counter=raw->handles[3];
 s.expected_counter=raw->counter_floor;s.monotonic_deadline_ns=raw->monotonic_deadline_ns;
 for(size_t i=0;i<13;i++){size_t max=i<3?4096:i==3?2048:i==6?256:34;if(!raw->fields[i].raw||raw->fields[i].size<2||raw->fields[i].size>max)return YNX_TPM2_REFUSED;}
 TPM2B_NAME *names[]={&s.object_name,&s.salt_name,&s.ak_name,&s.ak_qualified_name,&s.counter_name};
 for(size_t i=0;i<5;i++){ynx_message_bytes b=raw->fields[8+i];if(b.size!=34||b.raw[0]!=0||b.raw[1]!=TPM2_ALG_SHA256)return YNX_TPM2_REFUSED;names[i]->size=34;memcpy(names[i]->name,b.raw,34);}
 size_t n=0;
 if(Tss2_MU_TPM2B_DIGEST_Unmarshal(raw->fields[4].raw,raw->fields[4].size,&n,&s.object_policy)||n!=raw->fields[4].size)return YNX_TPM2_REFUSED;
 n=0;if(Tss2_MU_TPM2B_DIGEST_Unmarshal(raw->fields[5].raw,raw->fields[5].size,&n,&s.counter_policy)||n!=raw->fields[5].size)return YNX_TPM2_REFUSED;
 n=0;if(Tss2_MU_TPML_PCR_SELECTION_Unmarshal(raw->fields[6].raw,raw->fields[6].size,&n,&s.pcrs)||n!=raw->fields[6].size)return YNX_TPM2_REFUSED;
 n=0;if(Tss2_MU_TPM2B_DIGEST_Unmarshal(raw->fields[7].raw,raw->fields[7].size,&n,&s.pcr_digest)||n!=raw->fields[7].size)return YNX_TPM2_REFUSED;
 *selected=s;*public=(ynx_message_enrollment_public_input){raw->fields[0],raw->fields[1],raw->fields[2],raw->fields[3],raw->fields[4],raw->fields[5],raw->fields[6],raw->fields[7],selected};
 return ynx_message_enrollment_validate_public(public);
}
int ynx_source_message_sealed_open_raw(const ynx_message_sealed_raw_input *raw,ynx_source_sealed_role_owner **out){
 if(!out||*out)return YNX_TPM2_REFUSED;
 ynx_tpm2_resource_selection selected={0};ynx_message_enrollment_public_input public={0};
 int rc=message_raw_decode(raw,&selected,&public);if(rc)return rc;
 ynx_message_sealed_custody_input input={&public,raw->not_before_ms,raw->expires_ms};
 return ynx_source_message_sealed_open(&input,out);
}
/* Actual named resource observations, independently verified against the held
 * signed original selection. Success is neither domain admission nor terminal.
 * No mutation/Unseal/reopen occurs; partial ESAPI allocations are always freed. */
int ynx_source_message_sealed_observe_raw(ynx_source_sealed_role_owner *owner,const ynx_message_sealed_raw_input *raw){
 if(!same_thread(owner))return YNX_TPM2_REFUSED;
 int rc=ynx_source_sealed_role_current(owner);if(rc)return rc;
 ynx_tpm2_resource_selection selected={0};ynx_message_enrollment_public_input public={0};
 rc=message_raw_decode(raw,&selected,&public);
 ynx_message_sealed_custody_input input={&public,raw?raw->not_before_ms:0,raw?raw->expires_ms:0};
 if(!rc)rc=message_window(&input);
 TPM2B_DATA nonce={.size=32};TPM2B_ATTEST *quote=NULL,*certify=NULL;TPMT_SIGNATURE *qs=NULL,*ns=NULL;
 if(!rc&&RAND_bytes(nonce.buffer,32)!=1)rc=YNX_TPM2_UNKNOWN;
 if(!rc)rc=ynx_tpm2_owner_quote(owner->tpm,&nonce,&quote,&qs);
 if(!rc)rc=ynx_tpm2_owner_certify(owner->tpm,&nonce,&certify,&ns);
 unsigned char qr[8192],qsr[8192],nr[8192],nsr[8192];size_t qn=0,qsn=0,nn=0,nsn=0;
 if(!rc&&(!quote||!qs||!certify||!ns))rc=YNX_TPM2_UNKNOWN;
 if(!rc&&(Tss2_MU_TPM2B_ATTEST_Marshal(quote,qr,sizeof(qr),&qn)||Tss2_MU_TPMT_SIGNATURE_Marshal(qs,qsr,sizeof(qsr),&qsn)||Tss2_MU_TPM2B_ATTEST_Marshal(certify,nr,sizeof(nr),&nn)||Tss2_MU_TPMT_SIGNATURE_Marshal(ns,nsr,sizeof(nsr),&nsn)))rc=YNX_TPM2_REFUSED;
 if(!rc){ynx_message_attestation_input proof={&public,{qr,qn},{qsr,qsn},{nr,nn},{nsr,nsn},&nonce,raw->counter_floor};rc=ynx_message_enrollment_verify_attestations(&proof);}
 Esys_Free(quote);Esys_Free(qs);Esys_Free(certify);Esys_Free(ns);
 if(!rc)rc=ynx_source_sealed_role_current(owner);
 if(!rc)rc=message_window(&input);
 if(rc){owner->retired=1;if(!owner->first)owner->first=rc;}
 return rc;
}

int ynx_source_sealed_client_context_key(ynx_source_sealed_role_owner *p,SSL_CTX *ctx){
 if(!ctx||!same_thread(p))return YNX_TPM2_REFUSED;
 int rc=ynx_source_sealed_role_current(p);if(rc)return rc;
 if(p->attempted)return YNX_TPM2_UNKNOWN;
 p->attempted=1; /* irreversible before the sole Unseal, including failures */
 rc=ynx_tpm2_owner_unseal(p->tpm);
 const unsigned char *secret=NULL;size_t size=0;int borrowed=0;
 if(!rc){rc=ynx_tpm2_owner_secret_borrow(p->tpm,&secret,&size);borrowed=!rc;}
 EVP_PKEY *key=NULL;
 if(!rc){
  const unsigned char *cursor=secret;
  if(!secret||!size||size>LONG_MAX)rc=YNX_TPM2_REFUSED;
  else key=d2i_AutoPrivateKey(NULL,&cursor,(long)size);
  X509 *cert=SSL_CTX_get0_certificate(ctx);
  if(!rc&&(!key||cursor!=secret+size||!cert||EVP_PKEY_eq(key,X509_get0_pubkey(cert))!=1||SSL_CTX_use_PrivateKey(ctx,key)!=1||SSL_CTX_check_private_key(ctx)!=1))rc=YNX_TPM2_REFUSED;
 }
 /* SSL_CTX owns its reference; process protection was established before
  * ESAPI and EVP allocations. This is TLS possession, not store admission. */
 EVP_PKEY_free(key);
 if(borrowed){int release=ynx_tpm2_owner_secret_release(p->tpm);if(!rc)rc=release;}
 if(!rc)rc=ynx_source_sealed_role_current(p);
 if(rc){p->retired=1;if(!p->first)p->first=rc;}return rc;
}
