/* Mathematical public-area resolver. Native owning acquisition separately
 * requires actual Root registration, independent provider and fresh evidence. */
#include "../ynx_message_platform_owner.h"
#include <tss2_mu.h>
#include <openssl/sha.h>
#include <openssl/ec.h>
#include <openssl/rsa.h>
#include <openssl/evp.h>
#include <string.h>
static int bounded(ynx_message_bytes b,size_t n){return b.raw&&b.size>=2&&b.size<=n;}
static int public_area(ynx_message_bytes b,TPM2B_PUBLIC *p){
 size_t offset=0,n=0;uint8_t roundtrip[4096];
 if(!bounded(b,sizeof(roundtrip))||Tss2_MU_TPM2B_PUBLIC_Unmarshal(b.raw,b.size,&offset,p)||offset!=b.size||Tss2_MU_TPM2B_PUBLIC_Marshal(p,roundtrip,sizeof(roundtrip),&n)||n!=b.size||memcmp(roundtrip,b.raw,n))return 0;
 return p->publicArea.nameAlg==TPM2_ALG_SHA256;
}
static int object_name(const TPM2B_PUBLIC *p,const TPM2B_NAME *expected){
 uint8_t raw[4096],digest[SHA256_DIGEST_LENGTH];size_t n=0;
 if(expected->size!=34||expected->name[0]!=0||expected->name[1]!=TPM2_ALG_SHA256||Tss2_MU_TPMT_PUBLIC_Marshal(&p->publicArea,raw,sizeof(raw),&n)||!SHA256(raw,n,digest))return 0;
 return !memcmp(expected->name+2,digest,sizeof(digest));
}
static int digest_area(ynx_message_bytes raw,const TPM2B_DIGEST *expected){
 TPM2B_DIGEST p;uint8_t out[sizeof(TPM2B_DIGEST)+2];size_t n=0,end=0;
 if(!bounded(raw,sizeof(out))||Tss2_MU_TPM2B_DIGEST_Unmarshal(raw.raw,raw.size,&n,&p)||n!=raw.size||p.size!=32||expected->size!=32||memcmp(p.buffer,expected->buffer,32)||Tss2_MU_TPM2B_DIGEST_Marshal(&p,out,sizeof(out),&end)||end!=raw.size||memcmp(out,raw.raw,end))return 0;
 return 1;
}
int ynx_message_enrollment_validate_public(const ynx_message_enrollment_public_input *in){
 if(!in||!in->original)return YNX_TPM2_REFUSED;
 const ynx_tpm2_resource_selection *s=in->original;
 if(s->sealed_object<0x81000000||s->sealed_object>0x81ffffff||s->salt_key<0x81000000||s->salt_key>0x81ffffff||s->attestation_key<0x81000000||s->attestation_key>0x81ffffff||s->counter<0x01000000||s->counter>0x01ffffff||s->sealed_object==s->salt_key||s->sealed_object==s->attestation_key||s->salt_key==s->attestation_key)return YNX_TPM2_REFUSED;
 TPM2B_PUBLIC object,salt,ak;
 if(!public_area(in->object_public,&object)||!public_area(in->salt_public,&salt)||!public_area(in->ak_public,&ak)||!object_name(&object,&s->object_name)||!object_name(&salt,&s->salt_name)||!object_name(&ak,&s->ak_name))return YNX_TPM2_REFUSED;
 if(object.publicArea.type!=TPM2_ALG_KEYEDHASH||!(object.publicArea.objectAttributes&TPMA_OBJECT_ADMINWITHPOLICY)||(object.publicArea.objectAttributes&TPMA_OBJECT_USERWITHAUTH)||object.publicArea.authPolicy.size!=32||memcmp(object.publicArea.authPolicy.buffer,s->object_policy.buffer,32))return YNX_TPM2_REFUSED;
 if((salt.publicArea.objectAttributes&(TPMA_OBJECT_RESTRICTED|TPMA_OBJECT_DECRYPT))!=(TPMA_OBJECT_RESTRICTED|TPMA_OBJECT_DECRYPT)||(salt.publicArea.objectAttributes&TPMA_OBJECT_SIGN_ENCRYPT))return YNX_TPM2_REFUSED;
 if((ak.publicArea.objectAttributes&(TPMA_OBJECT_RESTRICTED|TPMA_OBJECT_SIGN_ENCRYPT))!=(TPMA_OBJECT_RESTRICTED|TPMA_OBJECT_SIGN_ENCRYPT)||(ak.publicArea.objectAttributes&TPMA_OBJECT_DECRYPT)||s->ak_qualified_name.size!=34||s->ak_qualified_name.name[0]!=0||s->ak_qualified_name.name[1]!=TPM2_ALG_SHA256)return YNX_TPM2_REFUSED;
 if(!digest_area(in->object_policy,&s->object_policy)||!digest_area(in->counter_policy,&s->counter_policy)||!digest_area(in->pcr_digest,&s->pcr_digest))return YNX_TPM2_REFUSED;
 TPM2B_NV_PUBLIC nv;uint8_t raw[2048],digest[32];size_t end=0,n=0;
 if(!bounded(in->counter_public,sizeof(raw))||Tss2_MU_TPM2B_NV_PUBLIC_Unmarshal(in->counter_public.raw,in->counter_public.size,&end,&nv)||end!=in->counter_public.size||Tss2_MU_TPM2B_NV_PUBLIC_Marshal(&nv,raw,sizeof(raw),&n)||n!=in->counter_public.size||memcmp(raw,in->counter_public.raw,n)||nv.nvPublic.nvIndex!=s->counter||nv.nvPublic.nameAlg!=TPM2_ALG_SHA256||nv.nvPublic.dataSize!=8||((nv.nvPublic.attributes&TPMA_NV_TPM2_NT_MASK)>>TPMA_NV_TPM2_NT_SHIFT)!=TPM2_NT_COUNTER||nv.nvPublic.authPolicy.size!=32||memcmp(nv.nvPublic.authPolicy.buffer,s->counter_policy.buffer,32))return YNX_TPM2_REFUSED;
 n=0;if(Tss2_MU_TPMS_NV_PUBLIC_Marshal(&nv.nvPublic,raw,sizeof(raw),&n)||!SHA256(raw,n,digest)||s->counter_name.size!=34||s->counter_name.name[0]!=0||s->counter_name.name[1]!=TPM2_ALG_SHA256||memcmp(s->counter_name.name+2,digest,32))return YNX_TPM2_REFUSED;
 TPML_PCR_SELECTION pcr;end=0;n=0;uint8_t pcr_raw[256];
 if(!bounded(in->pcr_selection,sizeof(pcr_raw))||Tss2_MU_TPML_PCR_SELECTION_Unmarshal(in->pcr_selection.raw,in->pcr_selection.size,&end,&pcr)||end!=in->pcr_selection.size||Tss2_MU_TPML_PCR_SELECTION_Marshal(&pcr,pcr_raw,sizeof(pcr_raw),&n)||n!=in->pcr_selection.size||memcmp(pcr_raw,in->pcr_selection.raw,n)||pcr.count!=1||pcr.pcrSelections[0].hash!=TPM2_ALG_SHA256||!pcr.pcrSelections[0].sizeofSelect||pcr.pcrSelections[0].sizeofSelect>sizeof(pcr.pcrSelections[0].pcrSelect))return YNX_TPM2_REFUSED;
 int any=0;for(size_t i=0;i<pcr.pcrSelections[0].sizeofSelect;i++)any|=pcr.pcrSelections[0].pcrSelect[i];
 n=0;uint8_t selected[256];if(!any||Tss2_MU_TPML_PCR_SELECTION_Marshal(&s->pcrs,selected,sizeof(selected),&n)||n!=in->pcr_selection.size||memcmp(selected,in->pcr_selection.raw,n))return YNX_TPM2_REFUSED;
 return YNX_TPM2_OK; /* UNADMITTED facts only; no qualified-owner output. */
}
static int signed_attestation(ynx_message_bytes a,ynx_message_bytes signature,const TPM2B_PUBLIC *ak,TPMS_ATTEST *parsed){
 TPM2B_ATTEST attest;TPMT_SIGNATURE sig;size_t n=0,end=0;
 uint8_t roundtrip[8192];
 if(!bounded(a,sizeof(attest)+2)||Tss2_MU_TPM2B_ATTEST_Unmarshal(a.raw,a.size,&n,&attest)||n!=a.size||Tss2_MU_TPM2B_ATTEST_Marshal(&attest,roundtrip,sizeof(roundtrip),&end)||end!=a.size||memcmp(roundtrip,a.raw,end))return 0;
 n=0;end=0;if(!bounded(signature,sizeof(sig)+2)||Tss2_MU_TPMT_SIGNATURE_Unmarshal(signature.raw,signature.size,&n,&sig)||n!=signature.size||Tss2_MU_TPMT_SIGNATURE_Marshal(&sig,roundtrip,sizeof(roundtrip),&end)||end!=signature.size||memcmp(roundtrip,signature.raw,end))return 0;
 n=0;if(Tss2_MU_TPMS_ATTEST_Unmarshal(attest.attestationData,attest.size,&n,parsed)||n!=attest.size||parsed->magic!=TPM2_GENERATED_VALUE)return 0;
 uint8_t digest[32];if(!SHA256(attest.attestationData,attest.size,digest))return 0;
 if(ak->publicArea.type==TPM2_ALG_ECC){
  const TPMS_ECC_PARMS *p=&ak->publicArea.parameters.eccDetail;
  if(sig.sigAlg!=TPM2_ALG_ECDSA||sig.signature.ecdsa.hash!=TPM2_ALG_SHA256||(p->scheme.scheme!=TPM2_ALG_NULL&&p->scheme.scheme!=TPM2_ALG_ECDSA)||(p->scheme.scheme==TPM2_ALG_ECDSA&&p->scheme.details.ecdsa.hashAlg!=TPM2_ALG_SHA256))return 0;
  size_t width;int nid;
  if(p->curveID==TPM2_ECC_NIST_P256){width=32;nid=NID_X9_62_prime256v1;}else if(p->curveID==TPM2_ECC_NIST_P384){width=48;nid=NID_secp384r1;}else return 0;
  const TPMS_ECC_POINT *point=&ak->publicArea.unique.ecc;
  if(point->x.size!=width||point->y.size!=width||!sig.signature.ecdsa.signatureR.size||!sig.signature.ecdsa.signatureS.size||sig.signature.ecdsa.signatureR.size>width||sig.signature.ecdsa.signatureS.size>width)return 0;
  EC_KEY *key=EC_KEY_new_by_curve_name(nid);EC_POINT *public_point=NULL;ECDSA_SIG *s=NULL;BIGNUM *r=NULL,*t=NULL;int valid=0;uint8_t wire[97];
  if(!key)goto ecc_done;public_point=EC_POINT_new(EC_KEY_get0_group(key));if(!public_point)goto ecc_done;
  wire[0]=4;memcpy(wire+1,point->x.buffer,width);memcpy(wire+1+width,point->y.buffer,width);
  if(!EC_POINT_oct2point(EC_KEY_get0_group(key),public_point,wire,1+2*width,NULL)||!EC_KEY_set_public_key(key,public_point)||EC_KEY_check_key(key)!=1)goto ecc_done;
  r=BN_bin2bn(sig.signature.ecdsa.signatureR.buffer,sig.signature.ecdsa.signatureR.size,NULL);t=BN_bin2bn(sig.signature.ecdsa.signatureS.buffer,sig.signature.ecdsa.signatureS.size,NULL);s=ECDSA_SIG_new();
  if(!r||!t||!s||!ECDSA_SIG_set0(s,r,t))goto ecc_done;r=NULL;t=NULL;valid=ECDSA_do_verify(digest,sizeof(digest),s,key)==1;
 ecc_done:BN_free(r);BN_free(t);ECDSA_SIG_free(s);EC_POINT_free(public_point);EC_KEY_free(key);return valid;
 }
 if(ak->publicArea.type==TPM2_ALG_RSA){
  const TPMS_RSA_PARMS *p=&ak->publicArea.parameters.rsaDetail;
  if((sig.sigAlg!=TPM2_ALG_RSASSA&&sig.sigAlg!=TPM2_ALG_RSAPSS)||(p->scheme.scheme!=TPM2_ALG_NULL&&p->scheme.scheme!=sig.sigAlg))return 0;
  const TPMS_SIGNATURE_RSA *s=sig.sigAlg==TPM2_ALG_RSASSA?&sig.signature.rsassa:&sig.signature.rsapss;
  if(s->hash!=TPM2_ALG_SHA256||(p->scheme.scheme==TPM2_ALG_RSASSA&&p->scheme.details.rsassa.hashAlg!=TPM2_ALG_SHA256)||(p->scheme.scheme==TPM2_ALG_RSAPSS&&p->scheme.details.rsapss.hashAlg!=TPM2_ALG_SHA256)||p->keyBits<2048||p->keyBits>4096||ak->publicArea.unique.rsa.size!=p->keyBits/8||s->sig.size!=p->keyBits/8)return 0;
  RSA *rsa=RSA_new();BIGNUM *n=BN_bin2bn(ak->publicArea.unique.rsa.buffer,ak->publicArea.unique.rsa.size,NULL),*e=BN_new();EVP_PKEY *key=NULL;EVP_PKEY_CTX *ctx=NULL;int valid=0;
  if(!rsa||!n||!e||!BN_set_word(e,p->exponent?p->exponent:65537)||!RSA_set0_key(rsa,n,e,NULL))goto rsa_done;n=NULL;e=NULL;
  key=EVP_PKEY_new();if(!key||!EVP_PKEY_assign_RSA(key,rsa))goto rsa_done;rsa=NULL;
  ctx=EVP_PKEY_CTX_new(key,NULL);if(!ctx||EVP_PKEY_verify_init(ctx)<=0||EVP_PKEY_CTX_set_rsa_padding(ctx,sig.sigAlg==TPM2_ALG_RSASSA?RSA_PKCS1_PADDING:RSA_PKCS1_PSS_PADDING)<=0||EVP_PKEY_CTX_set_signature_md(ctx,EVP_sha256())<=0)goto rsa_done;
  if(sig.sigAlg==TPM2_ALG_RSAPSS&&(EVP_PKEY_CTX_set_rsa_mgf1_md(ctx,EVP_sha256())<=0||EVP_PKEY_CTX_set_rsa_pss_saltlen(ctx,32)<=0))goto rsa_done;
  valid=EVP_PKEY_verify(ctx,s->sig.buffer,s->sig.size,digest,sizeof(digest))==1;
 rsa_done:BN_free(n);BN_free(e);RSA_free(rsa);EVP_PKEY_CTX_free(ctx);EVP_PKEY_free(key);return valid;
 }
 return 0;
}
int ynx_message_enrollment_verify_attestations(const ynx_message_attestation_input *in){
 if(!in||!in->enrollment||!in->original_qualifying_data||in->original_qualifying_data->size!=32||ynx_message_enrollment_validate_public(in->enrollment))return YNX_TPM2_REFUSED;
 TPM2B_PUBLIC ak;TPMS_ATTEST quote,nv;const ynx_tpm2_resource_selection *s=in->enrollment->original;
 if(!public_area(in->enrollment->ak_public,&ak)||!signed_attestation(in->quote,in->quote_signature,&ak,&quote)||!signed_attestation(in->nv_certification,in->nv_signature,&ak,&nv)||quote.type!=TPM2_ST_ATTEST_QUOTE||nv.type!=TPM2_ST_ATTEST_NV)return YNX_TPM2_REFUSED;
 for(unsigned i=0;i<2;i++){const TPMS_ATTEST *a=i?&nv:&quote;
  if(a->qualifiedSigner.size!=s->ak_qualified_name.size||memcmp(a->qualifiedSigner.name,s->ak_qualified_name.name,a->qualifiedSigner.size)||a->extraData.size!=32||memcmp(a->extraData.buffer,in->original_qualifying_data->buffer,32)||!a->clockInfo.safe)return YNX_TPM2_REFUSED;
 }
 if(quote.clockInfo.resetCount!=nv.clockInfo.resetCount||quote.clockInfo.restartCount!=nv.clockInfo.restartCount||quote.firmwareVersion!=nv.firmwareVersion)return YNX_TPM2_REFUSED;
 if(nv.attested.nv.indexName.size!=s->counter_name.size||memcmp(nv.attested.nv.indexName.name,s->counter_name.name,s->counter_name.size)||nv.attested.nv.offset||nv.attested.nv.nvContents.size!=8||quote.attested.quote.pcrDigest.size!=32||memcmp(quote.attested.quote.pcrDigest.buffer,s->pcr_digest.buffer,32))return YNX_TPM2_REFUSED;
 uint64_t counter=0;for(unsigned i=0;i<8;i++)counter=(counter<<8)|nv.attested.nv.nvContents.buffer[i];if(counter!=in->independently_expected_counter)return YNX_TPM2_REFUSED;
 uint8_t observed[256],selected[256];size_t on=0,sn=0;
 if(Tss2_MU_TPML_PCR_SELECTION_Marshal(&quote.attested.quote.pcrSelect,observed,sizeof(observed),&on)||Tss2_MU_TPML_PCR_SELECTION_Marshal(&s->pcrs,selected,sizeof(selected),&sn)||on!=sn||memcmp(observed,selected,on))return YNX_TPM2_REFUSED;
 return YNX_TPM2_OK; /* Math only: never domain/floor owner or verified_commit. */
}
