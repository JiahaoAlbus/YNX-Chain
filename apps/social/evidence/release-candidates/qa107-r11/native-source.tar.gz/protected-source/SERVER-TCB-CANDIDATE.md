# Infrastructure custody TCB candidate - NOT APPROVED / NOT DEPLOYED

## Scope and unchanged cryptography
Dedicated Linux server services, not Android device keys. The copied exact R63 primitive graph remains libsignal selected XEdDSA and ML-DSA-87 with YNX/SOCIAL/PQ-AUTH/V1 context. Device RecoveryLoan/sign_type4 and uninhabited NativeSigningAuthorization remain unchanged. No Signal, backup, KDF, message or ratchet parameter changes.
Existing protector is Android JCA/Keystore through same-worker JNI, with Android Context/UID/CE contracts. It cannot simply be called from a Linux server. Reuse is limited to its selected two-record AAD/codec, authenticated-reload discipline, selected key consistency checks and PQ locked allocation. This candidate uses OpenSSL AES-256-GCM with the SAME 32-byte key/12-byte nonce/16-byte tag storage shape; OpenSSL/server custody is a NEW TCB implementation requiring independent approval, not an already approved replacement.

## Proposed deployment, not an environment claim
Target: Linux dedicated service accounts under systemd, with TPM2-bound encrypted credentials and a narrowly inherited credential FD. Issuer and anchor MUST have independent hosts/administration/credential policy/TPM roots, different classical AND PQ keys, and separate audit/rollback state. Two FDs or processes with one UID/root administrator do not establish independence. No systemd service, TPM, credential, key or provisioning action has run.
Proposed deployment versions/package and TPM policy are NOT selected/admitted yet. Accordingly production Linux runtime cannot be declared buildable/qualified from this carrier. Host compilation uses Apple clang and installed Homebrew OpenSSL 3.6.4 headers. Rust check uses exact 1.98.1-aarch64-apple-darwin, original full Cargo.lock, offline existing dependency cache. No download. This is not Linux linkage or a TPM build.

## Wrapping key and records
One wrapping key per infrastructure custodian/deployment/provisioning generation; never shared by issuer and anchor. Current reload candidate consumes an inherited 32-byte credential, locks its native allocation, uses exact authenticated upstream record decoders, and returns PQ native custody plus native-only classical serialized bytes for selected Rust decode. It does not implement create/seal or a key supplier.
PQ and classic storage domains remain distinct in inherited veil_own_aad / veil_classic_aad; each binds alias, generation, both public keys and owner association. New association begins YNX/SOCIAL/INFRASTRUCTURE/V1 NUL + role byte + BE32 custodian length + custodian bytes. This prevents a device-record association silently passing infrastructure reload.
Filename/verified provisioning-operation binding is NOT yet implemented. An alias is not a filesystem or provisioning identity proof. The future sealed-bundle manifest must bind canonical store/file identity and original provisioning operation to this association before approval. Signing operation/frame/nonce is retained separately by the issuance journal; it must not trigger per-request key resealing.

## Nonce uniqueness and rollback
Current C implements DECRYPT/RELOAD ONLY; seal callbacks are NULL. It does not generate a GCM nonce and cannot claim crash-safe nonce allocation.
Proposed sealing design: reserve nonce from a per-wrapping-key 96-bit space (e.g. approved epoch32/counter64) in durable, rollback-protected provisioning state BEFORE invoking GCM. UNKNOWN burns the reserved value permanently; retry uses the original ciphertext/result, never re-encrypts with that nonce. Allocation must cover BOTH record domains even though AAD differs. Epoch allocation/key rotation and counter exhaustion require explicit original-operation policy. This design is NOT implemented or approved; it must not be enabled with a plain local counter.
TPM unseal or PCR policy alone does NOT establish freshest application state. Independent monotonic/rollback witness and original issuance/account history are still needed. The local Go journal is crash bookkeeping, not a trusted rollback anchor. Restoring its PREPARED snapshot would require authentic anti-rollback admission before production; the candidate does not solve this by hash or TPM terminology.

## FD and native memory boundary
Reload candidate requires an already-open regular credential FD, effective-UID ownership, no group/other permissions, exact32 bytes; duplicates with F_DUPFD_CLOEXEC; pread bounded32; checks held identity/size/mtime; closes the duplicate and leaves original with caller. It does not accept a UI path. This is metadata validation, NOT attestation of systemd/TPM origin, immutability or provisioning approval. Same-UID/root modification remains a TCB risk, including changes within timestamp resolution. Actual launch FD allowlist/mount/namespace/policy verification is not implemented.
Mandatory mlock failure rejects before use; close wipes the local wrapping allocation then unlocks/frees. Source owner is thread-bound and Rust !Send. PQ secret custody retains inherited mandatory-lock behavior. Classical temporary uses Zeroizing, but selected IdentityKeyPair/internal copies, OpenSSL round-key/temporary allocations, kernel copies and crash dumps are NOT fully wiped/locked by this candidate. Dedicated process dump/core policy and locked-memory quota remain deployment requirements, not facts established by compilation.
Native Drop uses failstop if cleanup refuses; it is NOT durable recovery, disposal proof or once completion. Explicit close/error-owner lifecycle remains subject to full review.

## Real remaining bridge closure
Go journal records exact immutable intents and durable SIGNING before returning a private dispatch. Native source-role body signs identical frames with actual selected primitive calls, and refuses second use locally, but no Go/native execution transport or authenticated provisioning association exists yet. Crypto success remains distinct from issuance permission/account attestation.
Native partial signature bytes are not yet retained into the durable Go result protocol on a PQ failure. This is a concrete incomplete ownership/result-custody path: do not invoke the bridge or claim UNKNOWN recovery completed. Pending SIGNING in the Go log refuses retry, but cannot substitute for native partial-result custody or independent rollback history.

## SII repair successor (2026-10-06)
This successor replaces small calloc/mlock owners with independently mapped,
page-sized anonymous allocations. Each owner has its own mapping size and lock
lifetime; inventory is bounded to32 across threads. Lock failure occurs before
credential pread. Wipe precedes munlock/unmap. An unmap failure during release
retains the nonnull owner and UNKNOWN; failure to dispose an allocation which
never acquired a lock is failstop, not a recovery receipt. Existing unconnected
bridge and original signing/rollback/partial-result blockers are unchanged.

Controlled actual anonymous mlock/munlock tests ran on this macOS host with
PUBLIC syscall shims for credential fstat/dup/read/close: no credential file or
wrapping secret was read. They demonstrate separate mapped pages and failure
before the read boundary, not Linux TPM/systemd qualification or all-memory
locking. OpenSSL/selected primitive copies retain prior disclosed limitations.
Classic reload now validates version and cipher17..272 and supplies exact
cipher_size-16 capacity while retaining/wiping the full256 allocation. This is
ABI correction, not padding, new encoding, encryption or an authenticated
reload positive.
