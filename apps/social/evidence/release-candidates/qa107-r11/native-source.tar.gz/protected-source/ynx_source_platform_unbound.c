#include "ynx_source_platform_private.h"
#include "linux/ynx_source_platform_qualified.h"
#include "linux/ynx_source_final_owner.h"
#include "linux/ynx_source_original_resource_owner.h"
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
/* Normal UNBOUND physical provider. Not a test platform, hardware emulation,
 * soft monotonic counter, two-FD authority or runtime callback installer.
 * A qualified provider replaces this entire TU by reviewed static linkage. */
veil_store_status ynx_platform_acquire(veil_private_store_binding *b,const veil_verified_native_operation_lease *l,const veil_native_intent_handle *i,veil_source_mode m,ynx_platform_original_hold **out,veil_source_view *v){(void)b;(void)l;(void)i;(void)m;if(!out||*out||!v)return VEIL_STORE_BOUND;memset(v,0,sizeof(*v));return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_acquire_prepared(const veil_private_prepared_input_owner *p,ynx_platform_original_hold **out){(void)p;if(!out||*out)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}
/* A retained policy/provenance loan is partial custody, never an admitted
 * platform root. Only cleanup may use this inventory without business current. */
extern int32_t ynx_sdk_native_core_original_borrow_v2(const ynx_core_original_input_v2 *,void **);
extern int32_t ynx_sdk_native_core_rights_current_v2(void *);
extern int32_t ynx_sdk_native_core_rights_close_v2(void **);
extern int32_t ynx_sdk_native_core_policy_borrow_v1(const ynx_core_original_input *,void **);
extern int32_t ynx_sdk_native_core_policy_current_v1(void *);
extern int32_t ynx_sdk_native_core_policy_close_v1(void **);
struct ynx_platform_original_hold {pthread_t thread;void *policy_loan;int policy_v2;ynx_native_core_resource_loan *resources;veil_store_status first;int unknown;struct ynx_platform_original_hold *next;};
static pthread_mutex_t original_lock=PTHREAD_MUTEX_INITIALIZER;
static ynx_platform_original_hold *originals;
static ynx_platform_original_hold *original_recognized(ynx_platform_original_hold *p){pthread_mutex_lock(&original_lock);ynx_platform_original_hold*q=originals;while(q&&q!=p)q=q->next;pthread_mutex_unlock(&original_lock);return q;}
veil_store_status ynx_platform_current(ynx_platform_original_hold *p,int cleanup){
 ynx_platform_original_hold*q=original_recognized(p);if(!q)return VEIL_STORE_REQUIRED;
 if(!pthread_equal(q->thread,pthread_self()))return VEIL_STORE_THREAD;if(cleanup)return VEIL_STORE_OK;
 if(q->unknown)return VEIL_STORE_UNKNOWN;
 veil_store_status s=(veil_store_status)(q->policy_v2?ynx_sdk_native_core_rights_current_v2(q->policy_loan):ynx_sdk_native_core_policy_current_v1(q->policy_loan));
 if(s){if(!q->first)q->first=s;q->unknown=1;return VEIL_STORE_UNKNOWN;}
 if(q->resources){s=ynx_native_core_resource_observe_current(q->resources);if(s){if(!q->first){veil_store_status cause=ynx_native_core_resource_first_cause(q->resources);q->first=cause?cause:s;}q->unknown=1;return VEIL_STORE_UNKNOWN;}}
 /* The policy loan cannot supply a core/store capability. The actual selected
  * purpose-specific enforcing resource constructor remains unimplemented. */
 return VEIL_STORE_REQUIRED;
}
veil_store_status ynx_platform_enter(ynx_platform_original_hold *p){(void)p;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_initialize(ynx_platform_original_hold *p){(void)p;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_cas(ynx_platform_original_hold *p,veil_private_cas_match **m,const unsigned char **b,size_t *n){(void)p;if(m)*m=NULL;if(b)*b=NULL;if(n)*n=0;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_step(ynx_platform_original_hold *p,const veil_native_intent_handle *i,const veil_native_ordered_step *s,veil_private_step_view *v){(void)p;(void)i;(void)s;if(v)memset(v,0,sizeof(*v));return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_queue(ynx_platform_original_hold *p,const veil_native_intent_handle *i,const veil_native_inbound_intent *a,const veil_native_outbound_intent *b,veil_private_step_view *v){(void)p;(void)i;(void)a;(void)b;if(v)memset(v,0,sizeof(*v));return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_recover(ynx_platform_original_hold *p,const veil_native_intent_handle *i,veil_private_cas_match *m,const veil_private_recovery_admission **out){(void)p;(void)i;(void)m;if(out)*out=NULL;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_terminal(ynx_platform_original_hold *p,const veil_native_intent_handle *i,veil_private_cas_match *m,const veil_private_recovery_admission *r,ynx_platform_final_hold **out){(void)p;(void)i;(void)m;(void)r;if(out)*out=NULL;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_type4(ynx_platform_original_hold *p,const unsigned char *b,size_t n){(void)p;(void)b;(void)n;return VEIL_STORE_REQUIRED;}
void ynx_platform_release_lock(ynx_platform_original_hold *p){if(p)abort();}
veil_store_status ynx_platform_drop(ynx_platform_original_hold **p){
 if(!p)return VEIL_STORE_BOUND;if(!*p)return VEIL_STORE_OK;
 ynx_platform_original_hold*q=original_recognized(*p);if(!q)return VEIL_STORE_REQUIRED;
 if(!pthread_equal(q->thread,pthread_self()))return VEIL_STORE_THREAD;
 if(q->resources){
  ynx_native_core_resource_loan*before=q->resources;veil_store_status original_cause=ynx_native_core_resource_first_cause(before);if(!q->first&&original_cause)q->first=original_cause;veil_store_status s=ynx_native_core_resource_close(&q->resources);
  if(q->resources&&q->resources!=before)abort();
  if(s||q->resources){if(!s)s=VEIL_STORE_UNKNOWN;if(!q->first)q->first=s;q->unknown=1;return s;}
 }
 if(q->policy_loan){
  void*before=q->policy_loan;veil_store_status s=(veil_store_status)(q->policy_v2?ynx_sdk_native_core_rights_close_v2(&q->policy_loan):ynx_sdk_native_core_policy_close_v1(&q->policy_loan));
  if(q->policy_loan&&q->policy_loan!=before)abort();
  if(s||q->policy_loan){if(!s)s=VEIL_STORE_UNKNOWN;if(!q->first)q->first=s;q->unknown=1;return s;}
 }
 /* A failed child close retains this exact parent even if that child released
  * its own handle. A later explicit cleanup drains only remaining RAM custody;
  * it cannot repeat an operation or settle the caller's business UNKNOWN. */
 pthread_mutex_lock(&original_lock);ynx_platform_original_hold**link=&originals;while(*link&&*link!=q)link=&(*link)->next;if(*link!=q){pthread_mutex_unlock(&original_lock);abort();}*link=q->next;pthread_mutex_unlock(&original_lock);free(q);*p=NULL;return VEIL_STORE_OK;
}

veil_store_status ynx_platform_acquire_original(const ynx_core_original_input *input,ynx_platform_original_hold **out){
 if(!input||!out||*out)return VEIL_STORE_BOUND;
 ynx_platform_original_hold*q=calloc(1,sizeof(*q));if(!q)return VEIL_STORE_SQL;q->thread=pthread_self();
 veil_store_status s=(veil_store_status)ynx_sdk_native_core_policy_borrow_v1(input,&q->policy_loan);
 if(!q->policy_loan){free(q);return s?s:VEIL_STORE_UNKNOWN;}
 /* Adopt any real returned partial BEFORE observing a late refusal. */
 pthread_mutex_lock(&original_lock);q->next=originals;originals=q;*out=q;pthread_mutex_unlock(&original_lock);
 if(s){q->first=s;q->unknown=s!=VEIL_STORE_REQUIRED;return s;}
 s=ynx_native_core_resource_acquire(q->policy_loan,&q->resources);
 if(s){if(!q->first){veil_store_status cause=q->resources?ynx_native_core_resource_first_cause(q->resources):0;q->first=cause?cause:s;}if(s!=VEIL_STORE_REQUIRED)q->unknown=1;return s;}
 /* Even a malformed OK resource return cannot publish an unadmitted root. */
 q->first=VEIL_STORE_UNKNOWN;q->unknown=1;return VEIL_STORE_UNKNOWN;
}
veil_store_status ynx_platform_acquire_original_v2(const ynx_core_original_input_v2*input,ynx_platform_original_hold**out){
 if(!input||!out||*out)return VEIL_STORE_BOUND;
 ynx_platform_original_hold*q=calloc(1,sizeof(*q));if(!q)return VEIL_STORE_SQL;q->thread=pthread_self();q->policy_v2=1;
 veil_store_status s=(veil_store_status)ynx_sdk_native_core_original_borrow_v2(input,&q->policy_loan);
 if(!q->policy_loan){free(q);return s?s:VEIL_STORE_UNKNOWN;}
 pthread_mutex_lock(&original_lock);q->next=originals;originals=q;*out=q;pthread_mutex_unlock(&original_lock);
 if(s){q->first=s;q->unknown=s!=VEIL_STORE_REQUIRED;return s;}
 s=ynx_native_core_resource_acquire_v2(q->policy_loan,&q->resources);
 if(s){if(!q->first){veil_store_status cause=q->resources?ynx_native_core_resource_first_cause(q->resources):0;q->first=cause?cause:s;}q->unknown=s!=VEIL_STORE_REQUIRED;return s;}
 /* Permission is not resource admission. Resource driver must deliver the
  * actual purpose-enforcing core/store before projection can publish. */
 q->first=VEIL_STORE_UNKNOWN;q->unknown=1;return VEIL_STORE_UNKNOWN;
}
veil_store_status ynx_platform_original_projection(ynx_platform_original_hold *hold,const veil_product_accepted_origin_owner **a,const veil_product_accepted_device_owner **d,const veil_product_prepared_history_owner **h,const veil_selected_retained_original_owner **r){(void)hold;if(!a||!d||!h||!r)return VEIL_STORE_BOUND;*a=NULL;*d=NULL;*h=NULL;*r=NULL;return VEIL_STORE_REQUIRED;}

veil_store_status ynx_platform_prepare_original(const veil_product_accepted_origin_owner *a,const veil_product_accepted_device_owner *d,const veil_product_prepared_history_owner *h,const veil_selected_retained_original_owner *r,ynx_platform_prepared_hold **out){(void)a;(void)d;(void)h;(void)r;if(!out||*out)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_prepared_current(ynx_platform_prepared_hold *h){(void)h;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_prepared_capabilities(ynx_platform_prepared_hold *h,const veil_required_native_admission **a,const veil_verified_native_operation_lease **l,const veil_native_intent_handle **i){(void)h;if(!a||!l||!i)return VEIL_STORE_BOUND;*a=NULL;*l=NULL;*i=NULL;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_prepared_validate(ynx_platform_prepared_hold *h,veil_private_effect_guard *g,veil_private_intent_pin *p){(void)h;(void)g;(void)p;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_prepared_close(ynx_platform_prepared_hold **h){if(!h)return VEIL_STORE_BOUND;return *h?VEIL_STORE_REQUIRED:VEIL_STORE_OK;}

veil_store_status ynx_platform_original_native_plan(ynx_platform_original_hold *h,ynx_original_native_plan *p){(void)h;if(!p)return VEIL_STORE_BOUND;memset(p,0,sizeof(*p));return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_store_admit(const veil_required_native_admission *a,veil_private_store_binding **b,const char **p){(void)a;if(!b||*b||!p)return VEIL_STORE_BOUND;*p=NULL;return VEIL_STORE_REQUIRED;}
void ynx_platform_store_release(veil_private_store_binding **b){if(b&&*b)abort();}

veil_store_status ynx_platform_snapshot_acquire(ynx_platform_original_hold *r,const veil_private_prepared_input_owner *p,ynx_platform_snapshot_hold **out){(void)r;(void)p;if(!out||*out)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_snapshot_current(ynx_platform_snapshot_hold *h){(void)h;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_snapshot_projection(ynx_platform_snapshot_hold *h,ynx_native_snapshot_projection *p){(void)h;if(!p)return VEIL_STORE_BOUND;memset(p,0,sizeof(*p));return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_snapshot_message_route(ynx_platform_snapshot_hold *h,const unsigned char logical[16],uint32_t direction,ynx_native_message_route *out){(void)h;(void)logical;(void)direction;if(!out)return VEIL_STORE_BOUND;memset(out,0,sizeof(*out));return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_snapshot_close(ynx_platform_snapshot_hold **h){if(!h)return VEIL_STORE_BOUND;return *h?VEIL_STORE_REQUIRED:VEIL_STORE_OK;}

veil_store_status ynx_platform_server_acquire(const ynx_server_original_input *i,ynx_platform_server_hold **o){(void)i;if(!o||*o)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_server_current(ynx_platform_server_hold *h){(void)h;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_server_enter(ynx_platform_server_hold *h){(void)h;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_server_retire(ynx_platform_server_hold *h,const ynx_server_terminal_input *i){(void)h;(void)i;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_server_close(ynx_platform_server_hold **h){if(!h)return VEIL_STORE_BOUND;return *h?VEIL_STORE_REQUIRED:VEIL_STORE_OK;}

veil_store_status ynx_platform_role_acquire(const ynx_role_original_input *i,ynx_platform_role_hold **o){(void)i;if(!o||*o)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_role_current(ynx_platform_role_hold *h){(void)h;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_role_projection(ynx_platform_role_hold *h,ynx_role_binding *o){(void)h;if(!o)return VEIL_STORE_BOUND;memset(o,0,sizeof(*o));return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_role_enter(ynx_platform_role_hold *h){(void)h;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_role_close(ynx_platform_role_hold **h){if(!h)return VEIL_STORE_BOUND;if(!*h)return VEIL_STORE_OK;return VEIL_STORE_REQUIRED;}

/* No final owner can be created by the unbound platform. These normal entry
 * refusals preserve non-null custody; they do not implement physical proof. */
veil_store_status ynx_platform_final_current(ynx_platform_final_hold *h){return ynx_final_hold_current(h);}
veil_store_status ynx_platform_final_borrow(ynx_platform_final_hold *h,const veil_native_intent_handle **i,const veil_private_authenticated_once_owner **a,const veil_private_protected_output_owner **o){(void)h;if(i)*i=NULL;if(a)*a=NULL;if(o)*o=NULL;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_final_acknowledge(ynx_platform_final_hold *h,ynx_platform_prepared_hold *p,veil_private_effect_guard *g,veil_private_intent_pin *i){(void)h;(void)p;(void)g;(void)i;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_final_recover(ynx_platform_prepared_hold *p,veil_private_effect_guard *g,veil_private_intent_pin *i,ynx_platform_final_hold **out){(void)p;(void)g;(void)i;if(!out||*out)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_final_close(ynx_platform_final_hold **p){return ynx_final_hold_close(p);}

veil_store_status ynx_platform_precommit_checkpoint(ynx_platform_original_hold *h,const ynx_precommit_readback *r){(void)h;(void)r;return VEIL_STORE_REQUIRED;}

veil_store_status ynx_platform_final_originals(ynx_platform_final_hold *h,ynx_independent_commit_originals *out){(void)h;if(!out)return VEIL_STORE_BOUND;memset(out,0,sizeof(*out));return VEIL_STORE_REQUIRED;}

veil_store_status ynx_platform_final_device_current(ynx_platform_final_hold *h,const ynx_device_original_input *i){(void)h;(void)i;return VEIL_STORE_REQUIRED;}

veil_store_status ynx_platform_device_restore(const ynx_device_original_input *i,const unsigned char *c,size_t cn,const unsigned char *p,size_t pn,ynx_platform_final_hold **out){(void)i;(void)c;(void)cn;(void)p;(void)pn;if(!out||*out)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}

veil_store_status ynx_platform_message_session_acquire(ynx_platform_final_hold *root,const ynx_message_session_input *input,ynx_platform_message_session_hold **out){(void)root;(void)input;if(!out||*out)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_message_session_current(ynx_platform_message_session_hold *h){(void)h;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_message_session_projection(ynx_platform_message_session_hold *h,ynx_message_session_projection *out){(void)h;if(!out)return VEIL_STORE_BOUND;memset(out,0,sizeof(*out));return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_message_session_close(ynx_platform_message_session_hold **h){if(!h)return VEIL_STORE_BOUND;if(!*h)return VEIL_STORE_OK;return VEIL_STORE_REQUIRED;}

veil_store_status ynx_platform_message_prepare(ynx_platform_message_session_hold *h,const ynx_message_operation_input *i,ynx_platform_prepared_hold **out){(void)h;(void)i;if(!out||*out)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}

veil_store_status ynx_platform_snapshot_protected_commit(ynx_platform_snapshot_hold *h,const ynx_native_computed_step *s,size_t n,uint32_t q,ynx_original_bytes w,ynx_platform_final_hold **out){(void)h;(void)s;(void)n;(void)q;(void)w;if(!out||*out)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}

veil_store_status ynx_platform_server_device_originals(ynx_platform_server_hold *h,ynx_device_original_input *out){(void)h;if(out)memset(out,0,sizeof(*out));return VEIL_STORE_REQUIRED;}

/* No resource factory supplied: never expose key/nonce/write capabilities. */
veil_store_status ynx_platform_snapshot_storage_acquire(ynx_platform_snapshot_hold*h,const ynx_native_computed_step*s,size_t n,uint32_t q,ynx_original_bytes w,ynx_platform_storage_hold**out){(void)h;(void)s;(void)n;(void)q;(void)w;if(!out||*out)return VEIL_STORE_BOUND;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_storage_current(ynx_platform_storage_hold*h){(void)h;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_storage_material(ynx_platform_storage_hold*h,ynx_storage_material*out){(void)h;if(!out)return VEIL_STORE_BOUND;memset(out,0,sizeof(*out));return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_storage_bind_ciphertext(ynx_platform_storage_hold*h,const ynx_storage_ciphertext*r,size_t n,veil_checked_store**s,const veil_verified_native_operation_lease**l,const veil_native_intent_handle**i){(void)h;(void)r;(void)n;if(!s||!l||!i)return VEIL_STORE_BOUND;*s=NULL;*l=NULL;*i=NULL;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_storage_validate_ciphertext(ynx_platform_storage_hold*h,veil_private_effect_guard*g,veil_private_intent_pin*p,size_t n,const ynx_storage_ciphertext*r){(void)h;(void)g;(void)p;(void)n;(void)r;return VEIL_STORE_REQUIRED;}
veil_store_status ynx_platform_storage_close(ynx_platform_storage_hold**h){if(!h)return VEIL_STORE_BOUND;return *h?VEIL_STORE_REQUIRED:VEIL_STORE_OK;}

/* Cleanup diagnostic0 is no stored cause, not a capability. */
veil_store_status ynx_platform_original_first_cause(ynx_platform_original_hold*p){
 ynx_platform_original_hold*q=original_recognized(p);if(!q||!pthread_equal(q->thread,pthread_self()))return VEIL_STORE_OK;
 if(q->first)return q->first;return q->resources?ynx_native_core_resource_first_cause(q->resources):VEIL_STORE_OK;
}
