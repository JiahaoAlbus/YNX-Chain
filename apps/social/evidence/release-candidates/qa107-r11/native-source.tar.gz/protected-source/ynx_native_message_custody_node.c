#include "ynx_native_message_custody_node.h"
#include <node_api.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
/* No numeric handles and no linkedBinding registration. A wrapper is recognized
 * only by the live native inventory plus original env/thread. */
typedef struct custody_wrapper {
 napi_env env;pthread_t thread;ynx_sdk_custody_owner *owner;
 veil_store_status first;int unknown,busy,closed;
 struct custody_wrapper *next;
} custody_wrapper;
static pthread_mutex_t inventory_lock=PTHREAD_MUTEX_INITIALIZER;
static custody_wrapper *inventory;
static void fact_free(ynx_custody_fact *f){
 if(!f)return;for(size_t i=0;i<f->count;i++)fact_free(f->children+i);
 if(f->bytes){volatile unsigned char *p=f->bytes;for(size_t i=0;i<f->size;i++)p[i]=0;free(f->bytes);}
 free(f->name);free(f->children);memset(f,0,sizeof(*f));
}
static int copy_buffer(napi_env e,napi_value v,ynx_custody_fact *f,size_t *budget){
 bool b=false;void *p=NULL;size_t n=0;
 if(napi_is_buffer(e,v,&b)!=napi_ok||!b||napi_get_buffer_info(e,v,&p,&n)!=napi_ok||n>*budget)return 0;
 f->kind=YNX_FACT_BUFFER;f->bytes=malloc(n?n:1);if(!f->bytes)return 0;
 if(n)memcpy(f->bytes,p,n);f->size=n;*budget-=n;return 1;
}
static int text(napi_env e,napi_value v,unsigned char **out,size_t *n,size_t limit){
 napi_valuetype t;if(napi_typeof(e,v,&t)!=napi_ok||t!=napi_string||napi_get_value_string_utf8(e,v,NULL,0,n)!=napi_ok||*n>limit)return 0;
 *out=malloc(*n+1);if(!*out)return 0;size_t actual=0;
 if(napi_get_value_string_utf8(e,v,(char*)*out,*n+1,&actual)!=napi_ok||actual!=*n||memchr(*out,0,*n)){free(*out);*out=NULL;return 0;}return 1;
}
/* Converted before any Native effect. Getters can reenter JS, but busy is set
 * before traversal and reentry permanently marks UNKNOWN. No returned object
 * is used as authority; the SDK validates the complete copied facts. */
static int fact_copy(napi_env e,napi_value v,ynx_custody_fact *f,size_t *budget,size_t *nodes,unsigned depth){
 if(depth>6||!*nodes)return 0;--*nodes;
 napi_valuetype t;bool b=false; if(napi_typeof(e,v,&t)!=napi_ok)return 0;
 if(t==napi_null){f->kind=YNX_FACT_NULL;return 1;}
 if(napi_is_buffer(e,v,&b)!=napi_ok)return 0;if(b)return copy_buffer(e,v,f,budget);
 if(t==napi_string){f->kind=YNX_FACT_TEXT;if(!text(e,v,&f->bytes,&f->size,*budget))return 0;*budget-=f->size;return 1;}
 if(t!=napi_object)return 0;
 bool array=false;if(napi_is_array(e,v,&array)!=napi_ok)return 0;
 napi_value keys=NULL;uint32_t count=0;
 if(array){if(napi_get_array_length(e,v,&count)!=napi_ok||count>255)return 0;f->kind=YNX_FACT_ARRAY;}
 else {if(napi_get_all_property_names(e,v,napi_key_own_only,napi_key_all_properties,napi_key_numbers_to_strings,&keys)!=napi_ok||napi_get_array_length(e,keys,&count)!=napi_ok||count>64)return 0;f->kind=YNX_FACT_OBJECT;}
 if(count>*nodes)return 0;f->children=calloc(count?count:1,sizeof(*f->children));if(!f->children)return 0;f->count=count;
 for(uint32_t i=0;i<count;i++){
  napi_value value=NULL,key=NULL;ynx_custody_fact *child=f->children+i;
  if(array){if(napi_get_element(e,v,i,&value)!=napi_ok)return 0;}
  else {
   if(napi_get_element(e,keys,i,&key)!=napi_ok)return 0;
   unsigned char *name=NULL;size_t len=0;if(!text(e,key,&name,&len,128)||!len){free(name);return 0;}
   child->name=(char*)name;child->name_size=len;
   for(uint32_t j=0;j<i;j++)if(child->name_size==f->children[j].name_size&&!memcmp(child->name,f->children[j].name,len))return 0;
   if(napi_get_property(e,v,key,&value)!=napi_ok)return 0;
  }
  if(!fact_copy(e,value,child,budget,nodes,depth+1))return 0;
 }
 return 1;
}
/* Structural preflight is denial-only. The same static SDK must still check
 * approved originals, selected role/preimage, true current and durable once. */
static int is_buffer(const ynx_custody_fact *f,size_t min,size_t max){return f->kind==YNX_FACT_BUFFER&&f->size>=min&&f->size<=max;}
static int is_text(const ynx_custody_fact *f,size_t min,size_t max){if(f->kind!=YNX_FACT_TEXT||f->size<min||f->size>max)return 0;for(size_t i=0;i<f->size;i++)if(f->bytes[i]<33||f->bytes[i]>126)return 0;return 1;}
static int exact_id(const ynx_custody_fact *f){if(!is_text(f,64,64))return 0;for(size_t i=0;i<64;i++)if(!((f->bytes[i]>='0'&&f->bytes[i]<='9')||(f->bytes[i]>='a'&&f->bytes[i]<='f')))return 0;return 1;}
static int call_preflight(size_t action,const ynx_custody_fact *a){
 switch(action){
 case YNX_CUSTODY_ROOT:return is_buffer(a,1,1048576);
 case YNX_CUSTODY_DOMAINS:case YNX_CUSTODY_CURRENT:return 1;
 case YNX_CUSTODY_ORIGINALS:return is_text(a,1,64)&&is_buffer(a+1,1,32768)&&(a[2].kind==YNX_FACT_OBJECT);
 case YNX_CUSTODY_ENTER:return exact_id(a)&&is_text(a+1,1,64)&&is_buffer(a+2,1,32768);
 case YNX_CUSTODY_CLASSIC_SIGN:case YNX_CUSTODY_PQ_SIGN:return exact_id(a)&&is_text(a+1,1,128)&&is_buffer(a+2,1,33280);
 case YNX_CUSTODY_CLASSIC_VERIFY:return is_text(a,44,44)&&is_buffer(a+1,1,33280)&&is_buffer(a+2,64,64);
 case YNX_CUSTODY_PQ_VERIFY:return is_text(a,3456,3456)&&is_buffer(a+1,1,33280)&&is_buffer(a+2,4627,4627);
 case YNX_CUSTODY_RETIRE:return exact_id(a)&&is_buffer(a+1,1,393216);
 default:return 0;
 }
}
static napi_value refusal(napi_env e,custody_wrapper *w,veil_store_status s){
 if(w){if(!w->first)w->first=s;w->unknown=1;}
 napi_value message,error,code,first;
 if(napi_create_string_utf8(e,"NATIVE_CUSTODY_REFUSED",NAPI_AUTO_LENGTH,&message)!=napi_ok||napi_create_error(e,NULL,message,&error)!=napi_ok)abort();
 napi_create_int32(e,(int)s,&code);napi_set_named_property(e,error,"status",code);
 napi_create_int32(e,w?(int)w->first:(int)s,&first);napi_set_named_property(e,error,"firstCause",first);
 napi_throw(e,error);return NULL;
}
static custody_wrapper *recognized(napi_env e,napi_value self){
 void *p=NULL;if(napi_unwrap(e,self,&p)!=napi_ok)return NULL;
 pthread_mutex_lock(&inventory_lock);custody_wrapper *w=inventory;while(w&&w!=p)w=w->next;
 if(w&&w->env!=e)w=NULL;pthread_mutex_unlock(&inventory_lock);return w;
}
static void finalize(napi_env e,void *p,void *hint){
 (void)e;(void)hint;custody_wrapper *w=p;
 /* GC cannot resolve a durable effect or drop sole partial custody. */
 if(w->owner||w->busy||!w->closed)abort();
 pthread_mutex_lock(&inventory_lock);custody_wrapper **q=&inventory;while(*q&&*q!=w)q=&(*q)->next;if(!*q)abort();*q=w->next;pthread_mutex_unlock(&inventory_lock);memset(w,0,sizeof(*w));free(w);
}
static const size_t arity[]={1,0,3,0,3,3,3,3,3,2};
static napi_value method(napi_env e,napi_callback_info info){
 napi_value args[4],self;size_t n=4;void *data=NULL;
 if(napi_get_cb_info(e,info,&n,args,&self,&data)!=napi_ok)return refusal(e,NULL,VEIL_STORE_BOUND);
 size_t action=(size_t)data;custody_wrapper *w=recognized(e,self);
 if(!w)return refusal(e,NULL,VEIL_STORE_REQUIRED);
 if(!pthread_equal(w->thread,pthread_self()))return refusal(e,NULL,VEIL_STORE_THREAD);
 if(w->closed)return refusal(e,NULL,VEIL_STORE_REQUIRED);
 if(w->busy)return refusal(e,w,VEIL_STORE_UNKNOWN);
 if(action==10){
  if(n)return refusal(e,w,VEIL_STORE_BOUND);w->busy=1;ynx_sdk_custody_owner *original=w->owner;
  veil_store_status s=ynx_sdk_custody_close(&w->owner);w->busy=0;
  if((s||w->owner)&&w->owner!=original)abort();
  if(s||w->owner)return refusal(e,w,s?s:VEIL_STORE_UNKNOWN);
  w->closed=1;napi_value v;napi_get_undefined(e,&v);return v;
 }
 if(action>=10||n!=arity[action])return refusal(e,w,VEIL_STORE_BOUND);
 if(w->unknown)return refusal(e,w,VEIL_STORE_UNKNOWN);
 w->busy=1;ynx_custody_fact facts[3]={{0}};size_t budget=1048576,nodes=1024;int copied=1;
 for(size_t i=0;i<n;i++)if(!fact_copy(e,args[i],facts+i,&budget,&nodes,0)){copied=0;break;}
 ynx_custody_result result={0};ynx_custody_call call={facts,n};
 veil_store_status s=(!copied||!call_preflight(action,facts))?VEIL_STORE_BOUND:w->unknown?VEIL_STORE_UNKNOWN:ynx_sdk_custody_call(w->owner,(enum ynx_custody_action)action,&call,&result);
 for(size_t i=0;i<n;i++)fact_free(facts+i);w->busy=0;
 if(s||w->unknown)return refusal(e,w,s?s:VEIL_STORE_UNKNOWN);
 napi_value v;
 if(action==YNX_CUSTODY_CLASSIC_SIGN||action==YNX_CUSTODY_PQ_SIGN){
  size_t expected=action==YNX_CUSTODY_CLASSIC_SIGN?64:4627;
  if(result.public_size!=expected)return refusal(e,w,VEIL_STORE_UNKNOWN);
  if(napi_create_buffer_copy(e,expected,result.public_bytes,NULL,&v)!=napi_ok)return refusal(e,w,VEIL_STORE_UNKNOWN);
 }else if(action==YNX_CUSTODY_CLASSIC_VERIFY||action==YNX_CUSTODY_PQ_VERIFY){
  if(result.verified!=0&&result.verified!=1)return refusal(e,w,VEIL_STORE_UNKNOWN);napi_get_boolean(e,result.verified,&v);
 }else napi_get_undefined(e,&v);
 memset(&result,0,sizeof(result));return v;
}
static napi_value acquire(napi_env e,napi_callback_info info){
 napi_value args[2],self,result,status,owner;size_t n=2;
 if(napi_get_cb_info(e,info,&n,args,&self,NULL)!=napi_ok||n!=1)return refusal(e,NULL,VEIL_STORE_BOUND);
 ynx_custody_fact raw={0};size_t budget=1048576;if(!copy_buffer(e,args[0],&raw,&budget)||!raw.size){fact_free(&raw);return refusal(e,NULL,VEIL_STORE_BOUND);}
 veil_store_status syntax=(veil_store_status)ynx_sdk_manifest_validate_native_v1(raw.bytes,raw.size);
 if(syntax){fact_free(&raw);return refusal(e,NULL,syntax);}
 /* The public manifest matches a retained private startup selection; it never
  * selects a Source Root, credentials or protection domain for this acquire. */
 syntax=(veil_store_status)ynx_sdk_startup_selected_match_v1(raw.bytes,raw.size);
 if(syntax){fact_free(&raw);return refusal(e,NULL,syntax);}
 custody_wrapper *w=calloc(1,sizeof(*w));if(!w){fact_free(&raw);return refusal(e,NULL,VEIL_STORE_SQL);}w->env=e;w->thread=pthread_self();
 veil_store_status s=ynx_sdk_custody_acquire((ynx_original_bytes){raw.bytes,raw.size},&w->owner);
 if(!s||w->owner){veil_store_status late=(veil_store_status)ynx_sdk_startup_selected_match_v1(raw.bytes,raw.size);if(!s&&late)s=late;}
 fact_free(&raw);
 if(!s&&!w->owner)s=VEIL_STORE_UNKNOWN;
 /* Auth's acquisition namespace is 0/1/8/4. Preserve the real first cause
  * on the retained wrapper, while every other partial failure is UNKNOWN
  * externally so the consumer can adopt the original for explicit cleanup. */
 veil_store_status first=s;if(w->owner&&s&&s!=VEIL_STORE_REQUIRED&&s!=VEIL_STORE_THREAD)s=VEIL_STORE_UNKNOWN;
 if(w->owner){
  w->unknown=s!=VEIL_STORE_OK;w->first=first;
  pthread_mutex_lock(&inventory_lock);w->next=inventory;inventory=w;pthread_mutex_unlock(&inventory_lock);
  if(napi_create_object(e,&owner)!=napi_ok||napi_wrap(e,owner,w,finalize,NULL,NULL)!=napi_ok)abort();
  const char *names[]={"assertApprovedRoot","assertIndependentDomains","assertOriginalInputs","assertCurrent","enterOnce","signClassic","signPq","verifyClassic","verifyPq","retire","close"};
  napi_property_descriptor descriptors[11]={{0}};
  for(size_t i=0;i<11;i++){descriptors[i].utf8name=names[i];descriptors[i].method=method;descriptors[i].attributes=napi_default;descriptors[i].data=(void*)i;}
  if(napi_define_properties(e,owner,11,descriptors)!=napi_ok)abort();
 }else{free(w);napi_get_null(e,&owner);}
 if(napi_create_object(e,&result)!=napi_ok||napi_create_int32(e,(int)s,&status)!=napi_ok||napi_set_named_property(e,result,"status",status)!=napi_ok||napi_set_named_property(e,result,"owner",owner)!=napi_ok)abort();return result;
}
static napi_value initialize(napi_env e,napi_value exports){
 napi_value fn,version;if(napi_create_function(e,"acquireOriginalMessageCustody",NAPI_AUTO_LENGTH,acquire,NULL,&fn)!=napi_ok)abort();napi_set_named_property(e,exports,"acquireOriginalMessageCustody",fn);napi_create_uint32(e,1,&version);napi_set_named_property(e,exports,"abiVersion",version);return exports;
}
NAPI_MODULE(ynx_social_message_custody_v1,initialize)
