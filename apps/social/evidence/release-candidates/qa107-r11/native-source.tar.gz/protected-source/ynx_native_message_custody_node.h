#ifndef YNX_NATIVE_MESSAGE_CUSTODY_NODE_H
#define YNX_NATIVE_MESSAGE_CUSTODY_NODE_H
/* Private static Native entry; no provider callback installation. The tree
 * carries copied original facts, not an accepted/admitted capability. */
#include "ynx_source_platform_private.h"
typedef struct ynx_sdk_custody_owner ynx_sdk_custody_owner;
enum ynx_custody_action { YNX_CUSTODY_ROOT,YNX_CUSTODY_DOMAINS,
 YNX_CUSTODY_ORIGINALS,YNX_CUSTODY_CURRENT,YNX_CUSTODY_ENTER,
 YNX_CUSTODY_CLASSIC_SIGN,YNX_CUSTODY_PQ_SIGN,
 YNX_CUSTODY_CLASSIC_VERIFY,YNX_CUSTODY_PQ_VERIFY,YNX_CUSTODY_RETIRE };
enum ynx_custody_fact_kind { YNX_FACT_NULL,YNX_FACT_BUFFER,YNX_FACT_TEXT,
 YNX_FACT_ARRAY,YNX_FACT_OBJECT };
typedef struct ynx_custody_fact {
 enum ynx_custody_fact_kind kind;
 unsigned char *bytes;size_t size;
 struct ynx_custody_fact *children;size_t count;
 char *name;size_t name_size;
} ynx_custody_fact;
typedef struct {const ynx_custody_fact *arguments;size_t count;} ynx_custody_call;
typedef struct {
 unsigned char public_bytes[4627];size_t public_size;int verified;
} ynx_custody_result;
/* Implemented in the same reviewed static SDK TU; not a JS-selected vtable.
 * acquire retains any partial owner; OK requires independent genuine custody.
 * A complete SDK link must resolve these symbols, never a weak fallback. */
veil_store_status ynx_sdk_custody_acquire(ynx_original_bytes,ynx_sdk_custody_owner **);
veil_store_status ynx_sdk_custody_call(ynx_sdk_custody_owner *,enum ynx_custody_action,
 const ynx_custody_call *,ynx_custody_result *);
veil_store_status ynx_sdk_custody_close(ynx_sdk_custody_owner **);
/* Native-private selected-suite primitives; C status namespace, never an
 * admission/owner factory. Key and expected-public spans are retained Native
 * borrows, never Java/JS arguments; upper SDK must gate current/once/role. */
int32_t ynx_sdk_classic_sign_native_v1(const unsigned char *,size_t,
 const unsigned char *,const unsigned char *,size_t,unsigned char *,size_t *);
int32_t ynx_sdk_classic_verify_native_v1(const unsigned char *,size_t,
 const unsigned char *,size_t,const unsigned char *,size_t,int32_t *);
int32_t ynx_sdk_manifest_validate_native_v1(const unsigned char *,size_t);
/* Public-original evidence only, never a custody/qualification return.
 * selected bootstrap is borrowed from private fixed Native startup context,
 * not copied from public manifest/JS arguments. */
int32_t ynx_sdk_startup_evidence_open_v1(const unsigned char *,size_t,const unsigned char *,size_t,const unsigned char *,size_t,const unsigned char *,size_t,void **);
int32_t ynx_sdk_startup_evidence_recheck_v1(void *,const unsigned char *,size_t,const unsigned char *,size_t,const unsigned char *,size_t);
int32_t ynx_sdk_startup_evidence_close_v1(void **);
/* Private fixed Native loader, not N-API arguments. Both original enrollment
 * chains must validate before the unadmitted evidence is published. Any failed
 * cleanup retains the same partial pointer. OK is never resource admission. */
int32_t ynx_sdk_startup_evidence_open_complete_v1(const unsigned char *,size_t,
 const unsigned char *,size_t,const unsigned char *,size_t,const unsigned char *,size_t,
 const unsigned char *,size_t,void **);
int32_t ynx_sdk_startup_enrollment_bind_v1(void *,const unsigned char *,size_t);
int32_t ynx_sdk_startup_account_bind_v1(void *,const unsigned char *,size_t,
 const unsigned char *,size_t,const unsigned char *,size_t,const ynx_original_bytes *,size_t);
/* The approved twelve fixed PUBLIC original fields, borrowed from the Native
 * backend startup supplier, not passed by acquire(manifest) or installed by JS.
 * All spans <=65536, account originals <=16384, each prefix <=255, aggregate
 * <=1MiB. Manifest/selected Source bootstrap are independent private selection
 * inputs. Digest only matches that selection; it is not a resource capability. */
typedef struct ynx_sdk_fixed_startup_originals {
 uint32_t version;unsigned char approval_input_digest[32];
 ynx_original_bytes root,registration,status_current;
 const ynx_original_bytes *status_predecessors;size_t status_predecessors_count;
 ynx_original_bytes issuer_credential,anchor_credential,issuer_enrollment_current;
 const ynx_original_bytes *issuer_enrollment_predecessors;size_t issuer_enrollment_predecessors_count;
 ynx_original_bytes anchor_enrollment_current;
 const ynx_original_bytes *anchor_enrollment_predecessors;size_t anchor_enrollment_predecessors_count;
} ynx_sdk_fixed_startup_originals;
/* OK publishes only matched account + authenticated Source/enrollment facts.
 * It never returns signing custody, floor reservation or a message owner. */
int32_t ynx_sdk_fixed_startup_open_v1(const ynx_sdk_fixed_startup_originals *,
 const unsigned char *,size_t,const unsigned char *,size_t,void **);
/* Private normal backend initialization retains this original evidence until
 * evidence_close. N-API may only match it; neither call establishes custody. */
int32_t ynx_sdk_fixed_startup_initialize_v1(const ynx_sdk_fixed_startup_originals *,
 const unsigned char *,size_t,const unsigned char *,size_t,void **);
int32_t ynx_sdk_startup_selected_match_v1(const unsigned char *,size_t);
/* Actual private encrypted-record loader; no public JS key/records installer.
 * Retains partial custody on the same selected startup owner for close. */
int32_t ynx_sdk_startup_message_records_bind_v1(void *,uint32_t,const unsigned char *,size_t,uint64_t,
 const unsigned char *,size_t,const unsigned char *,size_t);
#endif
