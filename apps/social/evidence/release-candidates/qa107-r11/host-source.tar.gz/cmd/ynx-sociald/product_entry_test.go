package main

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestSocialdNewProductCompositionRoutesNoBypass(t *testing.T) {
	privateCalls := 0
	guard := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		privateCalls++
		w.WriteHeader(http.StatusServiceUnavailable)
	})
	handler := newSocialHTTPHandler(guard)
	defer handler.CloseIdleConnections()
	// Invalid input must be handled by the actual product composition before
	// any Central request. No user grant, key or session is supplied here.
	request := httptest.NewRequest(http.MethodPost, "/v4/account-binding", strings.NewReader(`{}`))
	request.Header.Set("Content-Type", "application/json")
	response := httptest.NewRecorder()
	handler.ServeHTTP(response, request)
	if response.Code != http.StatusBadRequest || privateCalls != 0 || response.Header().Get("Cache-Control") != "no-store" {
		t.Fatal("normal entry must mount bounded account binding separately from private admission")
	}
	for _, path := range []string{"/v4/messages", "/social/v3/matrix/audience/authorize"} {
		response := httptest.NewRecorder()
		handler.ServeHTTP(response, httptest.NewRequest(http.MethodPost, path, nil))
		if response.Code != http.StatusServiceUnavailable {
			t.Fatal("new product composition must not replace or bypass source private guards")
		}
	}
	if privateCalls != 2 {
		t.Fatal("non-account routes must use the original source guard, not a legacy handler")
	}
}

func TestSocialdNewProductEnvironmentDefault(t *testing.T) {
	const name = "YNX_SOCIAL_PUBLIC_TEST_DEFAULT"
	t.Setenv(name, " ")
	if envOrDefault(name, "127.0.0.1:6491") != "127.0.0.1:6491" {
		t.Fatal("empty environment must retain the normal loopback default")
	}
	t.Setenv(name, " 127.0.0.1:6492 ")
	if envOrDefault(name, "127.0.0.1:6491") != "127.0.0.1:6492" {
		t.Fatal("explicit configured address must be retained")
	}
}
