package main

import (
	"errors"
	"net/http"
	"testing"
)

func TestAcquisitionQAOnlyRequiresTLSAndRetainsFailedCleanup(t *testing.T) {
	primary := errors.New("PUBLIC QA close uncertainty")
	qaRelease := &mfdFailedRelease{err: primary}
	prodRelease := &mfdFailedRelease{}
	qa, prod := &socialLoginRuntime{}, &socialLoginRuntime{}
	qa.releases.authority = qaRelease
	prod.releases.authority = prodRelease
	e := runSocialHTTPServer(&http.Server{}, nil, socialServerTLSConfig{}, nil, qa)
	if !errors.Is(e, errSocialTLSConfiguration) || !errors.Is(e, primary) || qaRelease.calls != 1 {
		t.Fatal("QA TLS/cleanup custody")
	}
	e = runSocialHTTPServer(&http.Server{}, prod, socialServerTLSConfig{}, nil, qa)
	if !errors.Is(e, primary) || qaRelease.calls != 1 || prodRelease.calls != 0 {
		t.Fatal("cleanup continued or retried after unknown")
	}
}
