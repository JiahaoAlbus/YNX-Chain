package main

import (
	"context"
	"errors"
	"net/http"
	"strings"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

// This selects a storage consumer, never a source profile or authorization.
type firstEnrollmentStartup struct{ mode, realm, path string }

func loadFirstEnrollmentStartup(lookup func(string) (string, bool), login socialLoginRuntimeConfig, enabled bool) (firstEnrollmentStartup, error) {
	mode, m := lookup("YNX_SOCIAL_FIRST_DEVICE_MODE")
	realm, r := lookup("YNX_SOCIAL_FIRST_DEVICE_REALM")
	path, p := lookup("YNX_SOCIAL_FIRST_DEVICE_AUTHORITY_FILE")
	if !m && !r && !p {
		return firstEnrollmentStartup{}, nil
	}
	if mode == "challenge-only" && m && !r && !p && enabled && login.EnrollmentDirectory == "" {
		return firstEnrollmentStartup{}, nil
	}
	if !m || !r || !p || mode != "authority-v3" || !enabled || login.ChallengeDirectory == "" || login.EnrollmentDirectory != "" || !socialLoginCleanFilePath(path) || realm == "" || len(realm) > 256 || strings.TrimSpace(realm) != realm || strings.ContainsAny(realm, "\x00\r\n") {
		return firstEnrollmentStartup{}, errSocialLoginRuntimeConfig
	}
	if path == login.ChallengeDirectory || path == login.Store.Directory || path == login.Store.SealKeyFile || path == login.PrivateKeyFile {
		return firstEnrollmentStartup{}, errSocialLoginRuntimeConfig
	}
	return firstEnrollmentStartup{mode: mode, realm: realm, path: path}, nil
}

// The normal main entry passes the actual loaded source owner, not its public
// Handler projection. A selected authority failure never invokes the old path.
func openNormalSocialProductBase(ctx context.Context, source *kernel.SourceAuthorityRuntime, lookup func(string) (string, bool)) (*kernel.SocialProductHandler, error) {
	config, enabled, err := loadSocialLoginRuntimeConfig(lookup)
	if err != nil {
		return nil, err
	}
	selection, err := loadFirstEnrollmentStartup(lookup, config, enabled)
	if err != nil {
		return nil, err
	}
	producerPreparation, err := loadSourceProducerStartup(lookup, selection)
	if err != nil { return nil, err }
	sealedInputs,err:=loadDedicatedSealedSourceStartup(lookup,selection,producerPreparation,dedicatedSealedSourceProcess)
 if err!=nil{return nil,err}
 accountConfig,err:=loadAccountOperationStartup(lookup,config,selection)
	if err!=nil{return nil,err}
	if normalSocialLoginRuntime != nil {
		return nil, errors.New("Social runtime already owned; replacement refused")
	}
	var fallback http.Handler
	if source != nil {
		fallback = source.Handler()
	}
	if !enabled {
		return kernel.NewSocialProductHandler(fallback), nil
	}
	runtime, err := openSocialLoginRuntime(config)
	err = retainNormalSocialRuntime(runtime, err)
	if err != nil {
		return nil, err
	}
	// Retain even failed construction until its exact cleanup outcome is known.
	normalSocialLoginRuntime = runtime
	if err=runtime.openAccountOperation(accountConfig);err!=nil{return nil,errors.Join(err,waitSocialLoginRuntimeClose(runtime))}
	handler, err := runtime.composeProduct(ctx, fallback, source, selection)
	if err==nil&&sealedInputs!=nil {
  if source==nil{err=errSocialLoginRuntimeConfig}else{err=source.LoadDedicatedSealedRoleInputs(ctx,sealedInputs.path)}
 }
 if err == nil { err = runtime.prepareSourceProducer(ctx,producerPreparation,source) }
	if err != nil {
		return nil, errors.Join(err, waitSocialLoginRuntimeClose(runtime))
	}
	return handler, nil
}

func (r *socialLoginRuntime) composeProduct(ctx context.Context, fallback http.Handler, source *kernel.SourceAuthorityRuntime, selection firstEnrollmentStartup) (*kernel.SocialProductHandler, error) {
	if selection.mode == "authority-v3" {
		if r.enrollment != nil || r.challenges == nil {
			return nil, errSocialLoginRuntimeConfig
		}
		handler, owner, err := r.service.FirstDeviceEnrollmentProductHandler(ctx, fallback, r.challenges, source, selection.realm, selection.path,r.accountOperation)
		r.authority = owner // retain any returned owner, including an error outcome
		if owner != nil {
			r.releases.authority = owner
		}
		return handler, err
	}
	if selection.mode != "" {
		return nil, errSocialLoginRuntimeConfig
	}
	return r.service.FirstDeviceProductHandler(fallback, r.challenges, r.enrollment)
}
