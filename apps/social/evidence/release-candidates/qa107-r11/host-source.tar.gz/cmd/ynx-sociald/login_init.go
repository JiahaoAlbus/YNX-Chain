package main

import (
	"errors"
	"flag"
	"path/filepath"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

const loginInitDirectoryFlag = "init-social-login-dir"
const loginInitKeyFlag = "init-social-login-seal-key-file"
const loginInitM1QADirectoryFlag = "init-social-m1qa-login-dir"

func registerSocialLoginInitializationFlags(fs *flag.FlagSet) {
	fs.String(loginInitDirectoryFlag, "", "Explicitly provision a fresh Social-only login transaction directory and exit")
	fs.String(loginInitM1QADirectoryFlag, "", "Explicitly provision a fresh isolated M1QA login transaction directory and exit; no account authorization")
	fs.String(loginInitKeyFlag, "", "Existing protected Social-only 32-byte seal key; never generated implicitly")
}

func handleSocialLoginInitialization(fs *flag.FlagSet) (bool, error) {
	var directorySet, qaDirectorySet, keySet, otherSet bool
	fs.Visit(func(f *flag.Flag) {
		switch f.Name {
		case loginInitDirectoryFlag:
			directorySet = true
		case loginInitM1QADirectoryFlag:
			qaDirectorySet = true
		case loginInitKeyFlag:
			keySet = true
		default:
			otherSet = true
		}
	})
	if !directorySet && !qaDirectorySet && !keySet {
		return false, nil
	}
	if directorySet == qaDirectorySet || !keySet || otherSet || fs.NArg() != 0 {
		return true, errors.New("Social login initialization requires exactly one ordinary or M1QA directory, its seal-key flag, and no other arguments")
	}
	directoryFlag := loginInitDirectoryFlag
	if qaDirectorySet {
		directoryFlag = loginInitM1QADirectoryFlag
	}
	directory := fs.Lookup(directoryFlag).Value.String()
	key := fs.Lookup(loginInitKeyFlag).Value.String()
	for _, path := range []string{directory, key} {
		if !filepath.IsAbs(path) || filepath.Clean(path) != path || filepath.Dir(path) == path {
			return true, errors.New("Social login initialization requires clean absolute non-root paths")
		}
	}
	if qaDirectorySet {
		return true, kernel.ProvisionSocialM1QALoginTransactions(directory, key)
	}
	return true, kernel.ProvisionSocialLoginTransactions(directory, key)
}
