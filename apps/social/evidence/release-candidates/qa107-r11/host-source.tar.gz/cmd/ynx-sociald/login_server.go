package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
	"net/http"
	"os"
	"syscall"
	"time"
)

const socialTLSCertificateEnvironment = "YNX_SOCIAL_TLS_CERT_FILE"
const socialTLSKeyEnvironment = "YNX_SOCIAL_TLS_KEY_FILE"

var errSocialTLSConfiguration = errors.New("Social HTTPS configuration invalid or unavailable")

type socialServerTLSConfig struct {
	certificate, key string
	enabled          bool
}

func loadSocialServerTLSConfig(lookup func(string) (string, bool)) (socialServerTLSConfig, error) {
	if lookup == nil {
		return socialServerTLSConfig{}, errSocialTLSConfiguration
	}
	cert, hasCert := lookup(socialTLSCertificateEnvironment)
	key, hasKey := lookup(socialTLSKeyEnvironment)
	if !hasCert && !hasKey {
		return socialServerTLSConfig{}, nil
	}
	if !hasCert || !hasKey || !socialLoginCleanFilePath(cert) || !socialLoginCleanFilePath(key) {
		return socialServerTLSConfig{}, errSocialTLSConfiguration
	}
	return socialServerTLSConfig{certificate: cert, key: key, enabled: true}, nil
}

func socialTerminationSignal() os.Signal { return syscall.SIGTERM }

// This is the NORMAL daemon's serving call, not a separate QA server. All
// post-acquisition returns complete owned cleanup before main chooses an exit.
func serveSocialHTTPServer(server *http.Server) error {
	config, err := loadSocialServerTLSConfig(os.LookupEnv)
	return runSocialHTTPServer(server, normalSocialLoginRuntime, config, err, normalM1QALoginRuntime)
}

func runSocialHTTPServer(server *http.Server, runtime *socialLoginRuntime, config socialServerTLSConfig, configErr error, qa ...*socialLoginRuntime) (result error) {
	defer func() {
		// ListenAndServe can return before an independently initiated Shutdown
		// finishes draining. Do not release stores while handlers still own them.
		if server != nil {
			if err := server.Shutdown(context.Background()); err != nil {
				result = errors.Join(result, err)
				return // retain runtime; drainage was not established
			}
		}
		for _, owner := range qa {
			if owner == nil || owner == runtime {
				continue
			}
			if err := waitSocialLoginRuntimeClose(owner); err != nil {
				result = errors.Join(result, err)
				return
			}
		}
		result = errors.Join(result, waitSocialLoginRuntimeClose(runtime))
	}()
	if configErr != nil {
		return configErr
	}
	if server == nil {
		return errors.New("Social HTTP server unavailable")
	}
	needsTLS := runtime != nil
	for _, owner := range qa {
		needsTLS = needsTLS || owner != nil
	}
	if needsTLS && !config.enabled {
		return errSocialTLSConfiguration
	}
	if server.ReadHeaderTimeout == 0 {
		server.ReadHeaderTimeout = 5 * time.Second
	}
	if server.ReadTimeout == 0 {
		server.ReadTimeout = 30 * time.Second
	}
	if server.IdleTimeout == 0 {
		server.IdleTimeout = 60 * time.Second
	}
	if server.MaxHeaderBytes == 0 {
		server.MaxHeaderBytes = 16 * 1024
	}
	var err error
	if config.enabled {
		pair, loadErr := tls.LoadX509KeyPair(config.certificate, config.key)
		if loadErr != nil || len(pair.Certificate) == 0 {
			return errSocialTLSConfiguration
		}
		leaf, parseErr := x509.ParseCertificate(pair.Certificate[0])
		now := time.Now()
		if parseErr != nil || leaf.VerifyHostname("social.ynxweb4.com") != nil || now.Before(leaf.NotBefore) || !now.Before(leaf.NotAfter) {
			return errSocialTLSConfiguration
		}
		pair.Leaf = leaf
		owned := &tls.Config{MinVersion: tls.VersionTLS12}
		if server.TLSConfig != nil {
			owned = server.TLSConfig.Clone()
			if owned.MinVersion < tls.VersionTLS12 {
				owned.MinVersion = tls.VersionTLS12
			}
		}
		owned.Certificates = []tls.Certificate{pair}
		for _, owner := range qa {
			if owner != nil && owner.nativePublisher != nil {
				owned.MinVersion = tls.VersionTLS13
				owned.NextProtos = []string{"http/1.1"}
				if err := owner.nativePublisher.AssertOriginalTLSConfig(context.Background(), owned); err != nil {
					return err
				}
			}
		}
		server.TLSConfig = owned
		if bindErr := kernel.BindSocialNativeTLSReceiver(server); bindErr != nil {
			return bindErr
		}
		err = server.ListenAndServeTLS("", "")
	} else {
		err = server.ListenAndServe()
	}
	if errors.Is(err, http.ErrServerClosed) {
		return nil
	}
	return err
}
