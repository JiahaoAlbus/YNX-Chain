//go:build linux || darwin

package main

import (
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"
)

func socialPublicFixture(t *testing.T, files map[string]string) (string, string) {
	t.Helper()
	dir := t.TempDir()
	names := make([]string, 0, len(files))
	for name := range files { names = append(names, name) }
	sort.Strings(names)
	m := socialPublicManifest{Version: 1}
	for _, name := range names {
		b := []byte(files[name])
		file := filepath.Join(dir, filepath.FromSlash(name))
		if err := os.MkdirAll(filepath.Dir(file), 0700); err != nil { t.Fatal(err) }
		if err := os.WriteFile(file, b, 0600); err != nil { t.Fatal(err) }
		m.Files = append(m.Files, socialPublicFileRecord{Path: name, Bytes: int64(len(b)), SHA256: socialPublicDigest(b)})
	}
	b, err := json.Marshal(m)
	if err != nil { t.Fatal(err) }
	return socialPublicWriteManifest(t, dir, b)
}

func socialPublicWriteManifest(t *testing.T, dir string, b []byte) (string, string) {
	t.Helper()
	file := filepath.Join(dir, "public-assets-v1.json")
	if err := os.WriteFile(file, b, 0600); err != nil { t.Fatal(err) }
	return file, socialPublicDigest(b)
}
func socialPublicLookup(filename string) func(string) (string, bool) {
	return func(name string) (string, bool) { return filename, name == socialPublicAssetManifestEnvironment }
}
func socialPublicLoadFixture(t *testing.T, file, digest string) *socialPublicStaticAssets {
	t.Helper()
	a, err := loadSocialPublicStaticAssets(socialPublicLookup(file), digest)
	if err != nil { t.Fatal(err) }
	return a
}

func TestSocialPublicStaticOptionalSelection(t *testing.T) {
	absent := func(string) (string, bool) { return "", false }
	a, err := loadSocialPublicStaticAssets(absent, "")
	next := http.NewServeMux()
	if err != nil || a != nil || a.handler(next) != next { t.Fatal("absent optional selection changed original handler") }
	file, digest := socialPublicFixture(t, map[string]string{"index.html":"PUBLIC HTML"})
	for _, tc := range []struct{name string; lookup func(string)(string,bool); pin string}{
		{"pin_only",absent,digest}, {"env_only",socialPublicLookup(file),""},
		{"wrong_pin",socialPublicLookup(file),strings.Repeat("0",64)},
		{"uppercase_pin",socialPublicLookup(file),strings.ToUpper(digest)},
		{"relative",socialPublicLookup("relative.json"),digest},
		{"nil_lookup",nil,digest},
	} {
		t.Run(tc.name,func(t *testing.T){ if a,err:=loadSocialPublicStaticAssets(tc.lookup,tc.pin);err==nil||a!=nil{t.Fatal("invalid selection accepted")} })
	}
}

func TestSocialPublicStaticImmutableGETHEAD(t *testing.T) {
	file,digest:=socialPublicFixture(t,map[string]string{"index.html":"<p>PUBLIC</p>","app.js":"PUBLIC_SCRIPT","assets/brand.svg":"<svg/>"})
	a:=socialPublicLoadFixture(t,file,digest)
	h:=a.handler(http.HandlerFunc(func(http.ResponseWriter,*http.Request){t.Fatal("known public asset delegated")}))
	if err:=os.WriteFile(filepath.Join(filepath.Dir(file),"index.html"),[]byte("CHANGED_ON_DISK"),0600);err!=nil{t.Fatal(err)}
	for _, method:=range []string{"GET","HEAD"} {
		for _, p:=range []string{"/","/index.html","/app.js","/assets/brand.svg"} {
			t.Run(method+p,func(t *testing.T){
				r:=httptest.NewRequest(method,"https://social.ynxweb4.com"+p+"?v=public",nil)
				w:=httptest.NewRecorder();h.ServeHTTP(w,r)
				if w.Code!=200||w.Header().Get("X-Content-Type-Options")!="nosniff"||w.Header().Get("ETag")=="" {t.Fatalf("bad public response %d",w.Code)}
				if method=="HEAD"&&w.Body.Len()!=0 {t.Fatal("HEAD leaked body")}
				if method=="GET"&&(p=="/"||p=="/index.html")&&w.Body.String()!="<p>PUBLIC</p>" {t.Fatal("response did not retain validated bytes")}
				if p=="/app.js"&&w.Header().Get("Content-Type")!="text/javascript; charset=utf-8" {t.Fatal("wrong JS type")}
			})
		}
	}
}

func TestSocialPublicStaticOriginalRequestDelegation(t *testing.T) {
	file,digest:=socialPublicFixture(t,map[string]string{"index.html":"PUBLIC HTML","app.js":"PUBLIC JS"})
	a:=socialPublicLoadFixture(t,file,digest)
	for _, tc:=range []struct{method,path string}{
		{"POST","/"},{"PUT","/app.js"},{"GET","/missing.js"},{"GET","/%61pp.js"},
		{"GET","/assets/../app.js"},{"GET","/m1qa/v4/login/status"},
		{"POST","/m1qa/v4/login/start"},{"POST","/m1qa/v4/first-device/prepare"},
		{"GET","/sso/m1qa/callback?code=PUBLIC_FIXTURE"},{"GET","/v4/source-authority/status"},
		{"GET","/auth/start"},{"GET","/api/state"},{"GET","/v1/state"},{"GET","/v2/state"},
	} {
		t.Run(tc.method+tc.path,func(t *testing.T){
			r:=httptest.NewRequest(tc.method,"https://social.ynxweb4.com"+tc.path,strings.NewReader("PUBLIC_UNCHANGED_BODY"))
			r.TLS=&tls.ConnectionState{Version:tls.VersionTLS13}
			tlsState,uri,host,path,query:=r.TLS,r.RequestURI,r.Host,r.URL.Path,r.URL.RawQuery
			r.Header.Set("X-Public-Fixture","unchanged")
			called:=0
			next:=http.HandlerFunc(func(w http.ResponseWriter,got *http.Request){
				called++
				if got!=r||got.TLS!=tlsState||got.RequestURI!=uri||got.Host!=host||got.URL.Path!=path||got.URL.RawQuery!=query||got.Header.Get("X-Public-Fixture")!="unchanged" {t.Fatal("original request changed")}
				b,err:=io.ReadAll(got.Body);if err!=nil||string(b)!="PUBLIC_UNCHANGED_BODY"{t.Fatal("body changed")}
				w.WriteHeader(http.StatusTeapot)
			})
			w:=httptest.NewRecorder();a.handler(next).ServeHTTP(w,r)
			if called!=1||w.Code!=http.StatusTeapot {t.Fatal("original handler did not receive exact request")}
		})
	}
}

func TestSocialPublicStaticRejectInvalidManifests(t *testing.T) {
	for _, kind:=range []string{"duplicate_version","duplicate_field","unknown_field","duplicate_path","bad_version","missing_index","empty_files","trailing_json","null","oversized_manifest","too_many_entries","zero_bytes","oversized_file","overflow_bytes","bad_hash","wrong_bytes","traversal","absolute","escaped","hidden","private_api","private_sso","private_qa","private_source","unknown_suffix","aggregate"} {
		t.Run(kind,func(t *testing.T){
			file,digest:=socialPublicFixture(t,map[string]string{"index.html":"X"})
			b,err:=os.ReadFile(file);if err!=nil{t.Fatal(err)}
			var m socialPublicManifest;if err:=json.Unmarshal(b,&m);err!=nil{t.Fatal(err)}
			switch kind {
			case "duplicate_version": b=[]byte(strings.Replace(string(b),"\"version\":1","\"version\":1,\"version\":1",1))
			case "duplicate_field": b=[]byte(strings.Replace(string(b),"\"path\":\"index.html\"","\"path\":\"index.html\",\"path\":\"index.html\"",1))
			case "unknown_field": b=[]byte(strings.Replace(string(b),"\"version\":1","\"unknown\":1,\"version\":1",1))
			case "trailing_json": b=append(b,[]byte("{}")...)
			case "null": b=[]byte("null")
			case "oversized_manifest": b=[]byte(strings.Repeat(" ",int(socialPublicManifestLimit)+1))
			default:
				switch kind {
				case "duplicate_path": m.Files=append(m.Files,m.Files[0])
				case "bad_version": m.Version=2
				case "missing_index": m.Files[0].Path="app.js"
				case "empty_files": m.Files=nil
				case "too_many_entries": for len(m.Files)<=socialPublicEntryLimit {m.Files=append(m.Files,m.Files[0])}
				case "zero_bytes": m.Files[0].Bytes=0
				case "oversized_file": m.Files[0].Bytes=socialPublicFileLimit+1
				case "overflow_bytes": m.Files[0].Bytes=9223372036854775807
				case "bad_hash": m.Files[0].SHA256=strings.Repeat("g",64)
				case "wrong_bytes": m.Files[0].Bytes=2
				case "traversal": m.Files[0].Path="../index.html"
				case "absolute": m.Files[0].Path="/index.html"
				case "escaped": m.Files[0].Path="%69ndex.html"
				case "hidden": m.Files[0].Path=".env"
				case "private_api": m.Files[0].Path="api/data.json"
				case "private_sso": m.Files[0].Path="sso/callback.html"
				case "private_qa": m.Files[0].Path="m1qa/v4/data.json"
				case "private_source": m.Files[0].Path="v4/source-authority/status.json"
				case "unknown_suffix": m.Files[0].Path="private.pk8"
				case "aggregate":
					block:=[]byte(strings.Repeat("x",int(socialPublicFileLimit)))
					for i:=0;i<5;i++ {name:=fmt.Sprintf("chunk%d.js",i);if err:=os.WriteFile(filepath.Join(filepath.Dir(file),name),block,0600);err!=nil{t.Fatal(err)};m.Files=append(m.Files,socialPublicFileRecord{Path:name,Bytes:int64(len(block)),SHA256:socialPublicDigest(block)})}
				}
				b,err=json.Marshal(m);if err!=nil{t.Fatal(err)}
			}
			file,digest=socialPublicWriteManifest(t,filepath.Dir(file),b)
			if a,err:=loadSocialPublicStaticAssets(socialPublicLookup(file),digest);err==nil||a!=nil{t.Fatal("invalid public manifest accepted")}
		})
	}
}

func TestSocialPublicStaticRejectFileReplacementAndSymlinks(t *testing.T) {
	for _, kind:=range []string{"missing","changed","symlink_leaf","symlink_ancestor","symlink_manifest","symlink_root","oversized_actual"} {
		t.Run(kind,func(t *testing.T){
			file,digest:=socialPublicFixture(t,map[string]string{"index.html":"X","assets/a.js":"PUBLIC_JS"})
			dir:=filepath.Dir(file)
			switch kind {
			case "missing": if err:=os.Remove(filepath.Join(dir,"index.html"));err!=nil{t.Fatal(err)}
			case "changed": if err:=os.WriteFile(filepath.Join(dir,"index.html"),[]byte("Y"),0600);err!=nil{t.Fatal(err)}
			case "symlink_leaf":
				if err:=os.Remove(filepath.Join(dir,"index.html"));err!=nil{t.Fatal(err)}
				if err:=os.Symlink("assets/a.js",filepath.Join(dir,"index.html"));err!=nil{t.Fatal(err)}
			case "symlink_ancestor":
				if err:=os.Rename(filepath.Join(dir,"assets"),filepath.Join(dir,"real-assets"));err!=nil{t.Fatal(err)}
				if err:=os.Symlink("real-assets",filepath.Join(dir,"assets"));err!=nil{t.Fatal(err)}
			case "symlink_manifest":
				if err:=os.Rename(file,file+".real");err!=nil{t.Fatal(err)}
				if err:=os.Symlink(file+".real",file);err!=nil{t.Fatal(err)}
			case "symlink_root":
				link:=filepath.Join(t.TempDir(),"public-link");if err:=os.Symlink(dir,link);err!=nil{t.Fatal(err)};file=filepath.Join(link,filepath.Base(file))
			case "oversized_actual":
				if err:=os.WriteFile(filepath.Join(dir,"index.html"),[]byte("XX"),0600);err!=nil{t.Fatal(err)}
			}
			if a,err:=loadSocialPublicStaticAssets(socialPublicLookup(file),digest);err==nil||a!=nil{t.Fatal("unadmitted filesystem input accepted")}
		})
	}
}

func TestSocialPublicStaticAssetlinksExactApprovedBody(t *testing.T) {
	// Actual Root-approved PUBLIC QA106 association bytes, not a device grant.
	const approved=`[
  {
    "relation": [
      "delegate_permission/common.handle_all_urls"
    ],
    "target": {
      "namespace": "android_app",
      "package_name": "com.ynx.social.m1qa",
      "sha256_cert_fingerprints": [
        "D4:E5:62:61:0E:CB:4E:30:4F:A0:0E:E0:7E:7A:DA:E7:DA:86:2C:E1:08:BD:A7:BD:FE:93:3C:28:83:1F:15:4E"
      ]
    }
  }
]
`
	if len(approved)!=339||socialPublicDigest([]byte(approved))!=socialPublicAssetLinksDigest{t.Fatal("public golden bytes drifted")}
	for _, correct:=range []bool{true,false} {
		t.Run(fmt.Sprint(correct),func(t *testing.T){
			body:=approved;if !correct{body=strings.Replace(body,"com.ynx.social.m1qa","com.ynx.social.other",1)}
			file,digest:=socialPublicFixture(t,map[string]string{"index.html":"PUBLIC",".well-known/assetlinks.json":body})
			a,err:=loadSocialPublicStaticAssets(socialPublicLookup(file),digest)
			if !correct {if err==nil||a!=nil{t.Fatal("unapproved association accepted")};return}
			if err!=nil{t.Fatal(err)}
			w:=httptest.NewRecorder();a.handler(http.NotFoundHandler()).ServeHTTP(w,httptest.NewRequest("GET","https://social.ynxweb4.com"+socialPublicAssetLinksPath,nil))
			if w.Code!=200||w.Body.String()!=approved||w.Header().Get("Cache-Control")!="no-store"{t.Fatal("approved public association changed")}
		})
	}
}
