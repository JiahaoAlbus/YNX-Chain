package main

import (
 "github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/url"
	"strings"
)

// Explicit public operator PREPARATION only. It does not select a source
// profile, provision secrets, claim SIGNING or authorize a native effect.
type sourceProducerStartup struct {
	Version         int    `json:"version"`
	RequestURI      string `json:"requestURI"`
	ExistingJournal string `json:"existingJournal"`
}

func loadSourceProducerStartup(lookup func(string) (string, bool), selection firstEnrollmentStartup) (*sourceProducerStartup, error) {
	path, enabled := lookup("YNX_SOCIAL_SOURCE_ISSUANCE_PREPARE_FILE")
	if !enabled {
		return nil, nil
	}
	if selection.mode != "authority-v3" || !socialLoginCleanFilePath(path) {
		return nil, errSocialLoginRuntimeConfig
	}
	// Use the existing owner/inode-bound metadata reader, not a second weaker
	// path. Metadata does not create a source grant or open the journal.
	data, err := readSocialLoginPublicConfig(path)
	if err != nil || len(data) == 0 || len(data) > 4096 {
		return nil, errSocialLoginRuntimeConfig
	}
	// Reject ambiguous duplicate fields before typed decoding. DisallowUnknownFields
	// alone accepts duplicates with last-value-wins semantics.
	shape := json.NewDecoder(bytes.NewReader(data))
	first, err := shape.Token()
	if err != nil || first != json.Delim('{') {
		return nil, errSocialLoginRuntimeConfig
	}
	seen := make(map[string]bool, 3)
	for shape.More() {
		token, err := shape.Token()
		name, ok := token.(string)
		if err != nil || !ok || seen[name] {
			return nil, errSocialLoginRuntimeConfig
		}
		switch name {
		case "version", "requestURI", "existingJournal":
		default:
			return nil, errSocialLoginRuntimeConfig
		}
		seen[name] = true
		var value json.RawMessage
		if shape.Decode(&value) != nil {
			return nil, errSocialLoginRuntimeConfig
		}
	}
	last, err := shape.Token()
	if err != nil || last != json.Delim('}') || len(seen) != 3 {
		return nil, errSocialLoginRuntimeConfig
	}
	if _, err := shape.Token(); err != io.EOF {
		return nil, errSocialLoginRuntimeConfig
	}
	d := json.NewDecoder(bytes.NewReader(data))
	d.DisallowUnknownFields()
	var c sourceProducerStartup
	if d.Decode(&c) != nil || d.Decode(new(any)) != io.EOF || c.Version != 1 || !socialLoginCleanFilePath(c.ExistingJournal) || c.ExistingJournal == selection.path || c.ExistingJournal == path {
		return nil, errSocialLoginRuntimeConfig
	}
	u, err := url.ParseRequestURI(c.RequestURI)
	if err != nil || u.IsAbs() || u.Host != "" || u.Fragment != "" || u.Path != "/v4/source-authority/current-history" || u.EscapedPath() != u.Path || len(c.RequestURI) > 1024 || strings.ContainsAny(c.RequestURI, "\r\n") {
		return nil, errSocialLoginRuntimeConfig
	}
	// Exact query and original nonce are validated by PrepareSourceCheckpoint.
	// Operator metadata is not a permit and is never normalized into another URI.
	return &c, nil
}

func (r *socialLoginRuntime) prepareSourceProducer(ctx context.Context, c *sourceProducerStartup, source ...*kernel.SourceAuthorityRuntime) error {
	if c == nil {
		return nil
	}
	if r == nil || r.authority == nil || r.sourceProducer != nil {
		return errSocialLoginRuntimeConfig
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://social.ynxweb4.com"+c.RequestURI, nil)
	if err != nil {
		return errSocialLoginRuntimeConfig
	}
	p, err := r.authority.OpenSourceIssuanceProducer(ctx, request, c.ExistingJournal)
	// Partial journal custody survives construction errors and is closed before
	// the directory it borrows. No replacement runtime or implicit init.
	if p != nil {
		r.sourceProducer = p
		r.releases.producer = p
	}
	if err != nil {
		return err
	}
	if len(source)!=1 || source[0]==nil { return errSocialLoginRuntimeConfig }
 if err:=p.BindSourceAuthority(ctx,source[0]);err!=nil{return err}
 return r.authority.BindSourceIssuanceProducer(ctx,p)
}

// Set by main's explicit flag before constructing any handlers or role work.
// It is process composition only, never a Source profile/admission decision.
var dedicatedSealedSourceProcess bool

type dedicatedSealedSourceStartup struct{ path string }
func loadDedicatedSealedSourceStartup(lookup func(string)(string,bool),selection firstEnrollmentStartup,producer *sourceProducerStartup,dedicated bool)(*dedicatedSealedSourceStartup,error){
 path,present:=lookup("YNX_SOCIAL_SEALED_SOURCE_ROLES_FILE")
 if !dedicated&&!present{return nil,nil}
 if !dedicated||!present||selection.mode!="authority-v3"||producer==nil||!socialLoginCleanFilePath(path)||path==selection.path||path==producer.ExistingJournal{return nil,errSocialLoginRuntimeConfig}
 if prepare,ok:=lookup("YNX_SOCIAL_SOURCE_ISSUANCE_PREPARE_FILE");ok&&prepare==path{return nil,errSocialLoginRuntimeConfig}
 return &dedicatedSealedSourceStartup{path:path},nil
}
