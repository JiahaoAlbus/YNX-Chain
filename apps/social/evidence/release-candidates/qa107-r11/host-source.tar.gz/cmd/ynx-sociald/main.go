package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"time"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

func main() {
	httpAddr := flag.String("http", envOrDefault("YNX_SOCIAL_HTTP_ADDR", "127.0.0.1:6491"), "Social HTTP listen address")
	checkConfig := flag.Bool("check-config", false, "check public source-authority inputs without starting the service")
	authorityFile := flag.String("source-authority-file", os.Getenv("YNX_SOCIAL_SOURCE_AUTHORITY_FILE"), "public source registration carrier; never a private key or an implicit enrollment")
	initEnrollmentDirectory := flag.String("init-first-device-enrollment-dir", "", "initialize a new Social-only enrollment directory at an absolute path and exit; refuses existing paths")
	registerSocialLoginInitializationFlags(flag.CommandLine)
	registerFirstDeviceChallengeInitializationFlag(flag.CommandLine)
	registerSourceIssuanceInitializationFlag(flag.CommandLine)
	dedicatedSource := flag.Bool("dedicated-sealed-source",false,"select this dedicated Linux sealed-source process; never grants custody or signing permission")
 flag.Parse()
 dedicatedSealedSourceProcess=*dedicatedSource
	var sourceRuntime *kernel.SourceAuthorityRuntime
 defer func(){
  // Existing close refuses uncertain producer disposal. Do not release its
  // original input custody before that exact close completes successfully.
  closeNormalSocialLoginRuntime()
  if sourceRuntime!=nil{if err:=sourceRuntime.CloseDedicatedSealedRoleInputs();err!=nil{log.Print("Social sealed source input cleanup uncertain; original retained: ",err)}}
 }()
	if handled, err := handleSourceIssuanceInitialization(flag.CommandLine); handled {
		if err != nil {
			log.Fatal(err)
		}
		return
	}
	if handled, err := handleFirstDeviceChallengeInitialization(flag.CommandLine); handled {
		if err != nil {
			log.Fatal(err)
		}
		fmt.Println("Social challenge storage initialized; no identity or device was authorized")
		return
	}
	if handled, err := handleSocialLoginInitialization(flag.CommandLine); handled {
		if err != nil {
			log.Fatal(err)
		}
		log.Print("Social login storage initialized; no identity or device authorized")
		return
	}
	initRequested := false
	flag.Visit(func(f *flag.Flag) {
		if f.Name == "init-first-device-enrollment-dir" {
			initRequested = true
		}
	})
	if initRequested {
		if *checkConfig {
			log.Fatal("enrollment storage initialization cannot be combined with check-config")
		}
		if err := initializeFirstDeviceEnrollmentDirectory(*initEnrollmentDirectory); err != nil {
			log.Fatal("enrollment storage initialization failed: ", err)
		}
		fmt.Println("Social enrollment storage initialized; no identity or device was authorized")
		return
	}
	// Validate the immutable public selection before acquiring private owners.
	// Operator initialization and source-only checks do not serve public assets.
	var publicAssets *socialPublicStaticAssets
	if !*checkConfig {
		var publicErr error
		publicAssets, publicErr = loadSocialPublicStaticAssets(os.LookupEnv, socialPublicAssetsAdmittedManifestDigest)
		if publicErr != nil {
			log.Fatal(publicErr)
		}
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, socialTerminationSignal())
	defer stop()
	loadCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
	var sourceErr error
 sourceRuntime, sourceErr = kernel.LoadSourceAuthority(loadCtx, *authorityFile)
	cancel()
	if *checkConfig {
		if sourceErr != nil {
			fmt.Println("ynx-sociald new-core source authority REQUIRED; no signer, enrollment, or runtime activation performed")
			return
		}
		fmt.Println("ynx-sociald public source inputs validated; native composition and private communication still REQUIRED")
		return
	}
	if sourceErr != nil {
		log.Print("new-core source authority REQUIRED; private operations fail closed")
	}
	// New builds do not construct Chat/Square/legacy Social or touch their
	// state. This dormant new-core entry cannot silently route to old crypto.
	productHandler, startupErr := openNormalSocialProduct(ctx, sourceRuntime, os.LookupEnv)
	if startupErr != nil {
		log.Fatal("Social startup refused without fallback: ", startupErr)
	}
	defer productHandler.CloseIdleConnections()
	server := &http.Server{Addr: *httpAddr, Handler: publicAssets.handler(productHandler), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 45 * time.Second, WriteTimeout: 45 * time.Second, IdleTimeout: 60 * time.Second, MaxHeaderBytes: 32 * 1024}
	go func() {
		<-ctx.Done()
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
		defer cancel()
		_ = server.Shutdown(shutdownCtx)
	}()
	log.Printf("YNX Social new-core candidate at http://%s; private communication unavailable pending genuine supplier composition", *httpAddr)
	if err := serveSocialHTTPServer(server); err != nil {
		log.Fatal(err)
	}
}

// This explicit operator action only provisions a new Social storage format.
// Startup, login and Open failures must never call it as recovery or first trust.
func initializeFirstDeviceEnrollmentDirectory(directory string) error {
	if !filepath.IsAbs(directory) || filepath.Clean(directory) != directory || directory == string(filepath.Separator) {
		return errors.New("enrollment initialization requires a clean absolute non-root directory path")
	}
	return kernel.ProvisionFirstDeviceEnrollmentDirectory(directory)
}

func newSocialHTTPHandler(source http.Handler) *kernel.SocialProductHandler {
	return newSocialProductHandler(source)
}

func envOrDefault(key, fallback string) string {
	if value := strings.TrimSpace(os.Getenv(key)); value != "" {
		return value
	}
	return fallback
}
