package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestFESI1ConstructionRetainsOriginal(t *testing.T) {
	c := publicSocialLoginRuntimeConfig(t)
	c.ChallengeDirectory = filepath.Join(filepath.Dir(c.PrivateKeyFile), "missing-challenge")
	r, err := openSocialLoginRuntime(c)
	if r != nil {
		defer r.Close(context.Background())
	}
	if err == nil || r == nil {
		t.Fatal("construction discarded acquired owner", err)
	}
	if err := r.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
}

// Release-only test doubles: cannot produce a handler, signer, source or grant.
type testContextRelease struct{ run func(context.Context) error }

func (r testContextRelease) Close(ctx context.Context) error { return r.run(ctx) }

type testPlainRelease struct{ run func() error }

func (r testPlainRelease) Close() error { return r.run() }

func TestFESI1ServiceCleanupFailureRetains(t *testing.T) {
	c := publicSocialLoginRuntimeConfig(t)
	r, err := openSocialLoginRuntime(c)
	if err != nil {
		t.Fatal(err)
	}
	defer r.service.Close(context.Background())
	defer r.provider.Close()
	secondary := errors.New("PUBLIC TEST ONLY uncertain close")
	calls, providerCalls := 0, 0
	r.releases.service = testContextRelease{func(context.Context) error { calls++; return secondary }}
	r.releases.provider = testPlainRelease{func() error { providerCalls++; return nil }}
	c.ChallengeDirectory = filepath.Join(filepath.Dir(c.PrivateKeyFile), "missing")
	retained, first := r.openDependentStores(c)
	if retained != r || first == nil || !errors.Is(first, secondary) || !strings.Contains(first.Error(), "challenge") {
		t.Fatal("construction/cleanup causes or owner lost", first)
	}
	previous := normalSocialLoginRuntime
	defer func() { normalSocialLoginRuntime = previous }()
	if retainNormalSocialRuntime(retained, first) != first || normalSocialLoginRuntime != r {
		t.Fatal("failed owner not published")
	}
	for i := 0; i < 2; i++ {
		if err := r.Close(context.Background()); err != secondary {
			t.Fatal("cleanup primary changed", err)
		}
	}
	if calls != 1 || providerCalls != 0 {
		t.Fatal("cleanup retried or released dependency", calls, providerCalls)
	}
	if _, err := openNormalSocialProduct(context.Background(), nil, func(string) (string, bool) { return "", false }); err == nil || normalSocialLoginRuntime != r {
		t.Fatal("replacement admitted")
	}
}

func TestFESI1ProviderOnlyAndOldStoreFailure(t *testing.T) {
	c := publicSocialLoginRuntimeConfig(t)
	provider, err := kernel.OpenSocialLoginSoftwareSigningProvider(c.PrivateKeyFile, c.PublicKey)
	if err != nil {
		t.Fatal(err)
	}
	defer provider.Close()
	r := &socialLoginRuntime{provider: provider}
	primary, secondary := errors.New("construction failed"), errors.New("provider cleanup uncertain")
	calls := 0
	r.releases.provider = testPlainRelease{func() error { calls++; return secondary }}
	retained, err := r.constructionFailed(primary)
	if retained != r || !errors.Is(err, primary) || !errors.Is(err, secondary) {
		t.Fatal("provider-only custody lost", err)
	}
	if r.Close(context.Background()) != secondary || calls != 1 {
		t.Fatal("provider cleanup repeated")
	}
	c.ChallengeDirectory = filepath.Join(filepath.Dir(c.PrivateKeyFile), "challenges")
	if err := os.Mkdir(c.ChallengeDirectory, 0700); err != nil {
		t.Fatal(err)
	}
	if err := kernel.ProvisionFirstDeviceAuthorizationStore(c.ChallengeDirectory); err != nil {
		t.Fatal(err)
	}
	c.EnrollmentDirectory = filepath.Join(filepath.Dir(c.PrivateKeyFile), "missing-old")
	old, err := openSocialLoginRuntime(c)
	if err == nil || old == nil || old.challenges == nil {
		t.Fatal("old-store failure discarded custody", err)
	}
	if err := old.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
}

func TestFESI1NormalConstructorPublishesBeforeError(t *testing.T) {
	c := publicSocialLoginRuntimeConfig(t)
	metadata := filepath.Join(filepath.Dir(c.PrivateKeyFile), "config.json")
	raw, _ := json.Marshal(map[string]string{"schema": "ynx-social-backend-signer/v1", "profile": c.Profile, "keyId": c.KeyID, "publicKey": base64.RawURLEncoding.EncodeToString(c.PublicKey), "privateKeyFile": c.PrivateKeyFile})
	if err := os.WriteFile(metadata, raw, 0600); err != nil {
		t.Fatal(err)
	}
	values := map[string]string{kernel.SocialLoginStateDirectoryEnvironment: c.Store.Directory, kernel.SocialLoginSealKeyEnvironment: c.Store.SealKeyFile, socialLoginSignerConfigEnvironment: metadata, "YNX_SOCIAL_FIRST_DEVICE_CHALLENGE_DIR": filepath.Join(filepath.Dir(c.PrivateKeyFile), "missing")}
	lookup := func(k string) (string, bool) { v, ok := values[k]; return v, ok }
	previous := normalSocialLoginRuntime
	normalSocialLoginRuntime = nil
	defer func() { normalSocialLoginRuntime = previous }()
	h, err := openNormalSocialProduct(context.Background(), nil, lookup)
	original := normalSocialLoginRuntime
	if err == nil || h != nil || original == nil {
		t.Fatal("normal constructor lost original", err)
	}
	if h, err := openNormalSocialProduct(context.Background(), nil, lookup); err == nil || h != nil || normalSocialLoginRuntime != original {
		t.Fatal("normal constructor replaced failed owner")
	}
	if err := original.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
}

func TestFESI1ReleaseOrderStopsAtEveryFailure(t *testing.T) {
	for stop := 0; stop < 5; stop++ {
		t.Run(fmt.Sprint(stop), func(t *testing.T) {
			var order []int
			failure := errors.New("controlled cleanup failure")
			closeAt := func(i int) error {
				order = append(order, i)
				if i == stop {
					return failure
				}
				return nil
			}
			r := &socialLoginRuntime{releases: socialRuntimeReleases{
				service:    testContextRelease{func(context.Context) error { return closeAt(0) }},
				authority:  testPlainRelease{func() error { return closeAt(1) }},
				challenges: testPlainRelease{func() error { return closeAt(2) }},
				enrollment: testPlainRelease{func() error { return closeAt(3) }},
				provider:   testPlainRelease{func() error { return closeAt(4) }},
			}}
			for n := 0; n < 2; n++ {
				if r.Close(context.Background()) != failure {
					t.Fatal("failure not retained")
				}
			}
			if len(order) != stop+1 {
				t.Fatal("later or repeated cleanup", order)
			}
			for i, v := range order {
				if i != v {
					t.Fatal("out of order", order)
				}
			}
		})
	}
}
