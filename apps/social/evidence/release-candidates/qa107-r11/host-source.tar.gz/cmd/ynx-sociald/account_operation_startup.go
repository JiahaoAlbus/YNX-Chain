package main

import (
	"bytes"
	"encoding/base64"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

type accountOperationStartup struct{ keyID,path string; public []byte; enabled bool }

// Metadata only. Dedicated NEW-purpose identity; never reuse login or source
// identity. Registration remains enforced by A, not by an environment flag.
func loadAccountOperationStartup(lookup func(string)(string,bool),login socialLoginRuntimeConfig,selection firstEnrollmentStartup)(accountOperationStartup,error){
	id,i:=lookup("YNX_SOCIAL_ACCOUNT_OPERATION_KEY_ID")
	path,p:=lookup("YNX_SOCIAL_ACCOUNT_OPERATION_PRIVATE_KEY_FILE")
	encoded,k:=lookup("YNX_SOCIAL_ACCOUNT_OPERATION_PUBLIC_KEY")
	if !i&&!p&&!k{return accountOperationStartup{},nil}
	pub,err:=base64.RawURLEncoding.Strict().DecodeString(encoded)
	if !i||!p||!k||selection.mode!="authority-v3"||err!=nil||len(pub)!=32||!socialLoginCleanFilePath(path)||path==login.PrivateKeyFile||path==login.Store.SealKeyFile||path==login.Store.Directory||path==login.ChallengeDirectory||path==selection.path||bytes.Equal(pub,login.PublicKey)||id==login.KeyID||len(id)==0||len(id)>128{return accountOperationStartup{},kernel.ErrSocialAccountOperationConfiguration}
	for _,b:=range []byte(id){if b<33||b>126{return accountOperationStartup{},kernel.ErrSocialAccountOperationConfiguration}}
	return accountOperationStartup{id,path,pub,true},nil
}

func(r *socialLoginRuntime) openAccountOperation(config accountOperationStartup)error{
	if !config.enabled{return nil}
	var err error
	r.accountOperation,err=kernel.OpenSocialAccountOperationRuntime(config.keyID,config.path,config.public)
	if r.accountOperation!=nil {r.releases.accountOperation=r.accountOperation}
	return err
}
