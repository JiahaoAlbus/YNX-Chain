package main

import (
	"bytes"
	"flag"
	"io"
	"os"
	"path/filepath"
	"testing"
)

func runSourceIssuanceInitialization(t *testing.T, args ...string) (bool, error) {
	t.Helper()
	fs := flag.NewFlagSet("PUBLIC-source-init-test", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	registerSourceIssuanceInitializationFlag(fs)
	registerSocialLoginInitializationFlags(fs)
	registerFirstDeviceChallengeInitializationFlag(fs)
	fs.Bool("check-config", false, "test conflict")
	fs.String("source-authority-file", "", "test conflict")
	fs.String("init-first-device-enrollment-dir", "", "test conflict")
	if err := fs.Parse(args); err != nil {
		t.Fatal(err)
	}
	return handleSourceIssuanceInitialization(fs)
}

func TestSourceIssuanceInitializationCLIExplicitOnly(t *testing.T) {
	for _, args := range [][]string{nil, {"--check-config"}, {"--source-authority-file", "/PUBLIC-not-read"}} {
		if handled, err := runSourceIssuanceInitialization(t, args...); handled || err != nil {
			t.Fatal("ordinary mode triggered journal initialization", args, err)
		}
	}
	parent := t.TempDir()
	if err := os.Chmod(parent, 0700); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(parent, "PUBLIC-issuance.journal")
	if handled, err := runSourceIssuanceInitialization(t, "--"+sourceIssuanceInitFlag, path); !handled || err != nil {
		t.Fatal("explicit isolated journal creation failed", err)
	}
	before, err := os.ReadFile(path)
	if err != nil || !bytes.Equal(before, []byte("YNX-SOCIAL-SOURCE-ISSUANCE-V1\n")) {
		t.Fatal("existing journal format not preserved", err)
	}
	if handled, err := runSourceIssuanceInitialization(t, "--"+sourceIssuanceInitFlag, path); !handled || err == nil {
		t.Fatal("existing journal overwritten")
	}
	after, err := os.ReadFile(path)
	if err != nil || !bytes.Equal(before, after) {
		t.Fatal("failed duplicate initialization changed journal")
	}
}

func TestSourceIssuanceInitializationCLIRejectsMixedModes(t *testing.T) {
	parent := t.TempDir()
	path := filepath.Join(parent, "never-created")
	for _, extra := range [][]string{
		{"--check-config"}, {"--check-config=false"},
		{"--source-authority-file", "/PUBLIC-not-read"},
		{"--" + loginInitDirectoryFlag, "/PUBLIC-not-created"},
		{"--" + loginInitM1QADirectoryFlag, "/PUBLIC-not-created"},
		{"--" + loginInitKeyFlag, "/PUBLIC-not-read"},
		{"--" + firstDeviceChallengeInitFlag, "/PUBLIC-not-created"},
		{"--init-first-device-enrollment-dir", "/PUBLIC-not-created"}, {"unexpected"},
	} {
		args := append([]string{"--" + sourceIssuanceInitFlag, path}, extra...)
		if handled, err := runSourceIssuanceInitialization(t, args...); !handled || err == nil {
			t.Fatal("mixed initialization mode accepted", args)
		}
	}
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatal("mixed flags created a journal")
	}
	for _, invalid := range []string{"", "/", "relative", parent + "/./journal"} {
		if handled, err := runSourceIssuanceInitialization(t, "--"+sourceIssuanceInitFlag, invalid); !handled || err == nil {
			t.Fatal("invalid journal path accepted", invalid)
		}
	}
}
