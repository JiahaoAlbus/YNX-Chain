package main

import (
	"encoding/base64"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

func TestSocialLoginRuntimeConfiguration(t *testing.T) {
	parent := t.TempDir()
	if err := os.Chmod(parent, 0700); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(parent, "signer.json")
	keyPath := filepath.Join(parent, "UNOPENED-KEY-REFERENCE")
	public := base64.RawURLEncoding.EncodeToString(make([]byte, 32))
	valid := fmt.Sprintf(`{"schema":"ynx-social-backend-signer/v1","profile":"protected-backend-software-pkcs8-v1","keyId":"PUBLIC-QA-FIXTURE","publicKey":%q,"privateKeyFile":%q}`, public, keyPath)
	for _, test := range []struct {
		name, body string
		accept     bool
	}{
		{"metadata", valid, true},
		{"duplicate", strings.Replace(valid, `"keyId":`, `"keyId":"other","keyId":`, 1), false},
		{"unknown", strings.Replace(valid, `"schema":`, `"extra":"no","schema":`, 1), false},
		{"trailing", valid + `{}`, false},
		{"inline-secret", strings.Replace(valid, `"privateKeyFile":`, `"privateKey":`, 1), false},
		{"bad-public", strings.Replace(valid, public, "invalid", 1), false},
		{"oversized", strings.Repeat(" ", 8193), false},
	} {
		t.Run(test.name, func(t *testing.T) {
			if err := os.WriteFile(path, []byte(test.body), 0600); err != nil {
				t.Fatal(err)
			}
			values := map[string]string{kernel.SocialLoginStateDirectoryEnvironment: filepath.Join(parent, "state"), kernel.SocialLoginSealKeyEnvironment: filepath.Join(parent, "seal"), socialLoginSignerConfigEnvironment: path}
			config, enabled, err := loadSocialLoginRuntimeConfig(func(k string) (string, bool) { v, ok := values[k]; return v, ok })
			if !enabled || (err == nil) != test.accept {
				t.Fatalf("configuration outcome: enabled=%v err=%v", enabled, err)
			}
			if test.accept && config.PrivateKeyFile != keyPath {
				t.Fatal("reference changed")
			}
			if _, err := os.Stat(keyPath); !os.IsNotExist(err) {
				t.Fatal("metadata loader touched missing key material", err)
			}
		})
	}
}

func TestSocialLoginRuntimePartialNeverDisables(t *testing.T) {
	for _, key := range []string{kernel.SocialLoginStateDirectoryEnvironment, kernel.SocialLoginSealKeyEnvironment, socialLoginSignerConfigEnvironment, "YNX_SOCIAL_FIRST_DEVICE_CHALLENGE_DIR", "YNX_SOCIAL_FIRST_DEVICE_ENROLLMENT_DIR"} {
		_, enabled, err := loadSocialLoginRuntimeConfig(func(k string) (string, bool) {
			if k == key {
				return "/private/reference", true
			}
			return "", false
		})
		if !enabled || err == nil {
			t.Fatal("partial configuration silently disabled", key)
		}
	}
	_, enabled, err := loadSocialLoginRuntimeConfig(func(string) (string, bool) { return "", false })
	if enabled || err != nil {
		t.Fatal("absent config state changed")
	}
}

func TestSocialLoginRuntimeChallengeConfiguration(t *testing.T) {
	base := publicSocialLoginRuntimeConfig(t)
	parent := filepath.Dir(base.PrivateKeyFile)
	metadata := filepath.Join(parent, "signer-metadata.json")
	body := fmt.Sprintf(`{"schema":"ynx-social-backend-signer/v1","profile":"protected-backend-software-pkcs8-v1","keyId":%q,"publicKey":%q,"privateKeyFile":%q}`, base.KeyID, base64.RawURLEncoding.EncodeToString(base.PublicKey), base.PrivateKeyFile)
	if err := os.WriteFile(metadata, []byte(body), 0600); err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{"", "/", "relative", parent + "/../unclean", filepath.Join(parent, "not-created")} {
		values := map[string]string{
			kernel.SocialLoginStateDirectoryEnvironment: base.Store.Directory,
			kernel.SocialLoginSealKeyEnvironment:        base.Store.SealKeyFile,
			socialLoginSignerConfigEnvironment:          metadata,
			"YNX_SOCIAL_FIRST_DEVICE_CHALLENGE_DIR":     path,
		}
		config, enabled, err := loadSocialLoginRuntimeConfig(func(k string) (string, bool) { value, ok := values[k]; return value, ok })
		valid := path == filepath.Join(parent, "not-created")
		if !enabled || (err == nil) != valid || (valid && config.ChallengeDirectory != path) {
			t.Fatal("challenge config silently disabled or altered", err)
		}
	}
	if _, err := os.Stat(filepath.Join(parent, "not-created")); !os.IsNotExist(err) {
		t.Fatal("configuration parser created challenge storage", err)
	}
}

func TestSocialLoginRuntimeConfigFileBoundary(t *testing.T) {
	parent := t.TempDir()
	if err := os.Chmod(parent, 0700); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(parent, "config")
	if err := os.WriteFile(path, []byte(`{}`), 0600); err != nil {
		t.Fatal(err)
	}
	link := filepath.Join(parent, "symlink")
	if err := os.Symlink(path, link); err != nil {
		t.Fatal(err)
	}
	if _, err := readSocialLoginPublicConfig(link); err == nil {
		t.Fatal("symlink accepted")
	}
	hardlink := filepath.Join(parent, "hardlink")
	if err := os.Link(path, hardlink); err != nil {
		t.Fatal(err)
	}
	if _, err := readSocialLoginPublicConfig(path); err == nil {
		t.Fatal("hardlinked config accepted")
	}
	if err := os.Remove(hardlink); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(path, 0644); err != nil {
		t.Fatal(err)
	}
	if _, err := readSocialLoginPublicConfig(path); err == nil {
		t.Fatal("public config permissions accepted")
	}
}

func TestSocialLoginRuntimeConfigFIFORefused(t *testing.T) {
	parent := t.TempDir()
	if err := os.Chmod(parent, 0700); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(parent, "not-a-configuration-file")
	if err := syscall.Mkfifo(path, 0600); err != nil {
		t.Fatal(err)
	}
	// There is deliberately no writer. Opening without O_NONBLOCK would wait
	// indefinitely before the regular-file predicate can reject this object.
	if _, err := readSocialLoginPublicConfig(path); err == nil {
		t.Fatal("FIFO accepted as configuration")
	}
}
