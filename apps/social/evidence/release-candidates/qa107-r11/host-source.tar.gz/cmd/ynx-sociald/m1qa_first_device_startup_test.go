package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
	"os"
	"path/filepath"
	"testing"
)

func TestM1FirstDeviceStartupNamespaceAndMissingSource(t *testing.T) {
	parent := t.TempDir()
	c := socialLoginRuntimeConfig{}
	c.Store.Directory = filepath.Join(parent, "m1qa-login-v1")
	c.ChallengeDirectory = filepath.Join(parent, "m1qa-first-device-v1")
	s := firstEnrollmentStartup{mode: "authority-v3", realm: "PUBLIC TEST ONLY", path: filepath.Join(parent, "m1qa-first-enrollment-v3.log")}
	if !m1QAFirstDevicePaths(c, s) {
		t.Fatal("selected namespace refused")
	}
	for _, bad := range []string{filepath.Join(parent, "production.log"), filepath.Join(parent, "x", "m1qa-first-enrollment-v3.log")} {
		other := s
		other.path = bad
		if m1QAFirstDevicePaths(c, other) {
			t.Fatal("shared namespace accepted")
		}
	}
	r := &socialLoginRuntime{}
	selection := &socialM1QALoginStartupSelection{runtime: c, firstDevice: &s}
	if _, err := r.mountM1QAFirstDevice(context.Background(), kernel.NewSocialProductHandler(nil), nil, selection); err == nil || r.challenges != nil || r.authority != nil {
		t.Fatal("missing source accepted")
	}
	if _, err := os.Stat(c.ChallengeDirectory); !os.IsNotExist(err) {
		t.Fatal("missing source created/opened state")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := r.mountM1QAFirstDevice(ctx, nil, nil, selection); err != context.Canceled {
		t.Fatal("context lost")
	}
}
