package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/centralbrowserfamily"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
	"net/http"
	"time"
)

// Only the deployment custodian may supply the actual independently opened
// NEW-purpose owner. No request, ENV, login signer or certificate DTO creates it.
// Nil selection leaves login available but supplies no account-operation client.
type socialM1QAOperationStartupSelection struct {
	owner        *centralbrowserfamily.SocialM1QAOperationOwner
	nativeSource *centralbrowserfamily.SocialNativeInstanceSource
	client       *http.Client
	originalNow  func() time.Time
}

func (r *socialLoginRuntime) openM1QAAccountOperation(ctx context.Context, s *socialM1QAOperationStartupSelection) error {
	if r == nil || s == nil {
		return kernel.ErrSocialAccountOperationConfiguration
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.closeStarted || r.accountOperation != nil || r.releases.accountOperation != nil {
		return kernel.ErrSocialAccountOperationConfiguration
	}
	if err := r.retainM1QAOperationOwnerLocked(s.owner); err != nil {
		return err
	}
	var owner *kernel.SocialAccountOperationRuntime
	var err error
	if s.nativeSource == nil {
		owner, err = kernel.NewSocialM1QAAccountOperationRuntime(ctx, s.owner, s.client, s.originalNow)
	} else {
		owner, err = kernel.NewSocialM1QANativeAccountOperationRuntime(ctx, s.owner, s.nativeSource, s.client, s.originalNow)
	}
	// Install partial custody before inspecting error. Cleanup uses the existing
	// runtime drain chain and never substitutes another owner after uncertainty.
	if owner != nil {
		r.accountOperation = owner
		r.releases.accountOperation = owner
		// A nonnil account runtime owns this exact operation owner, including
		// constructor errors. Its drain must finish before the separate signer.
		r.operationOwnerTransferred = true
		r.releases.operationOwner = nil
	} else if err == nil {
		err = kernel.ErrSocialAccountOperationConfiguration
	}
	if err == nil && ctx != nil {
		err = ctx.Err()
	}
	return err
}
