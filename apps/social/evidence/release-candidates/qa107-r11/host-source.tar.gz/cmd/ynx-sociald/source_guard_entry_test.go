package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

func TestSocialdNewProductMissingSourcePrivateGuard(t *testing.T) {
	runtime, err := kernel.LoadSourceAuthority(context.Background(), "")
	if err == nil {
		t.Fatal("no registered source must not become accepted authority")
	}
	handler := newSocialHTTPHandler(runtime.Handler())
	defer handler.CloseIdleConnections()
	for _, path := range []string{"/v4/devices/enroll", "/v4/devices/restore", "/v4/operations/unknown", "/v4/messages"} {
		response := httptest.NewRecorder()
		handler.ServeHTTP(response, httptest.NewRequest(http.MethodPost, path, nil))
		if response.Code != http.StatusServiceUnavailable {
			t.Fatal("actual missing-source guard must remain closed through normal composition")
		}
	}
	// This is the real missing-source boundary, not a supplied device/restore
	// or UNKNOWN transaction. It does not claim those producers are implemented.
}
