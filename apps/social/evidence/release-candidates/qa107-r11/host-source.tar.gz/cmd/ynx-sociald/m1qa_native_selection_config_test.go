package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// PUBLIC configuration controls only. Missing signed files are intentional;
// no key, provider, NativeSource, original parent pipe or device is created.
func m1qaNativeSelectionFixture(t *testing.T) (string, map[string]any, string, map[string]any) {
	t.Helper()
	file, fields := m1qaOperationMetadataFixture(t)
	dir := filepath.Dir(file)
	postFile := filepath.Join(dir, "public-post-build-native-references.json")
	fields["firstDeviceChallengeDirectory"] = filepath.Join(dir, "m1qa-first-device-v1")
	fields["firstDeviceRealm"] = "PUBLIC_UNADMITTED_QA"
	fields["firstDeviceAuthorityFile"] = filepath.Join(dir, "m1qa-first-enrollment-v3.log")
	fields["nativeRootPath"] = filepath.Join(dir, "unissued-native-root.json")
	fields["nativeRootDigest"] = strings.Repeat("f", 64)
	fields["nativeRootBytes"] = 1
	fields["nativeHostKeyFile"] = filepath.Join(dir, "must-not-open-host-private-key")
	fields["nativeSelectionFile"] = postFile
	fields["nativeTLSSPKIDigest"] = strings.Repeat("e", 64)
	fields["nativeMinimumRegistrationRevision"] = 1
	fields["nativeMinimumStatusSequence"] = 1
	post := map[string]any{
		"registrationPath": filepath.Join(dir, "unissued-native26.json"), "registrationDigest": strings.Repeat("1", 64), "registrationBytes": 1,
		"statusPath": filepath.Join(dir, "unissued-status14.json"), "statusDigest": strings.Repeat("2", 64), "statusBytes": 1,
		"statusHistory": []any{},
	}
	return file, fields, postFile, post
}

func m1qaNativeWritePost(t *testing.T, file string, fields map[string]any) []byte {
	t.Helper()
	data, err := json.Marshal(fields)
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(file, data, 0600); err != nil {
		t.Fatal(err)
	}
	return data
}

func TestM1QANativeSelectionPostBuildCannotOverrideAuthority(t *testing.T) {
	m1qaStartupTestReset(t)
	for _, key := range []string{"rootPath", "rootDigest", "publicKey", "approved", "source", "minimumStatusSequence", "expectedProfileDigest", "expectedOperationRegistrationDigest", "expectedTLSSPKIDigest", "serviceBinaryDigest", "sameServiceBinaryDigest", "now", "expiresAtMs", "status", "signature", "body", "parentRead"} {
		t.Run(key, func(t *testing.T) {
			file, fields, postFile, post := m1qaNativeSelectionFixture(t)
			post[key] = "untrusted-override"
			m1qaNativeWritePost(t, postFile, post)
			m1qaOperationWriteMetadata(t, file, fields)
			if s, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); s != nil || !errors.Is(err, errSocialM1QAStartupConfiguration) {
				t.Fatal("post-build metadata changed admitted authority")
			}
		})
	}
}

func TestM1QANativeSelectionPostBuildStrictFieldsAndTypes(t *testing.T) {
	_, _, _, post := m1qaNativeSelectionFixture(t)
	for key := range post {
		t.Run("missing-"+key, func(t *testing.T) {
			copy := make(map[string]any)
			for k, v := range post {
				if k != key {
					copy[k] = v
				}
			}
			data, err := json.Marshal(copy)
			if err != nil {
				t.Fatal(err)
			}
			if _, err = decodeSocialM1QANativePostBuildReferences(data); err == nil {
				t.Fatal("incomplete external references accepted")
			}
		})
	}
	data, err := json.Marshal(post)
	if err != nil {
		t.Fatal(err)
	}
	for _, raw := range [][]byte{
		append(append([]byte{}, data[:len(data)-1]...), []byte(",\"statusDigest\":\"duplicate\"}")...),
		append(append([]byte{}, data...), []byte("{}")...),
		[]byte(strings.Replace(string(data), "\"statusHistory\":[]", "\"statusHistory\":null", 1)),
		[]byte(strings.Replace(string(data), "\"statusBytes\":1", "\"statusBytes\":1.0", 1)),
		[]byte(strings.Replace(string(data), "\"statusBytes\":1", "\"statusBytes\":0", 1)),
		[]byte(strings.Replace(string(data), "\"statusBytes\":1", "\"statusBytes\":16385", 1)),
	} {
		if _, err := decodeSocialM1QANativePostBuildReferences(raw); err == nil {
			t.Fatal("duplicate/trailing/invalid external references accepted")
		}
	}
}

func TestM1QANativeSelectionHistoryOrderBoundsAndOwnedCopy(t *testing.T) {
	m1qaStartupTestReset(t)
	file, fields, postFile, post := m1qaNativeSelectionFixture(t)
	history := make([]any, 255)
	for i := range history {
		history[i] = map[string]any{"path": filepath.Join(filepath.Dir(file), fmt.Sprintf("PUBLIC-history-%03d.json", i)), "digest": fmt.Sprintf("%064x", i+1), "bytes": 1500}
	}
	post["statusHistory"] = history
	m1qaNativeWritePost(t, postFile, post)
	fields["nativeMinimumStatusSequence"] = 256
	m1qaOperationWriteMetadata(t, file, fields)
	s, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil || s == nil || len(s.nativeHost.source.StatusHistory) != 255 || s.nativeHost.source.MinimumStatusSequence != 256 {
		t.Fatalf("full bounded reference prefix: %v", err)
	}
	for i, ref := range s.nativeHost.source.StatusHistory {
		if ref.Digest != fmt.Sprintf("%064x", i+1) {
			t.Fatal("history reordered or omitted")
		}
	}
	history[0].(map[string]any)["digest"] = strings.Repeat("f", 64)
	if s.nativeHost.source.StatusHistory[0].Digest != fmt.Sprintf("%064x", 1) {
		t.Fatal("old selector changed with external metadata")
	}
	post["statusHistory"] = append(history, map[string]any{"path": filepath.Join(filepath.Dir(file), "extra.json"), "digest": strings.Repeat("3", 64), "bytes": 1})
	m1qaNativeWritePost(t, postFile, post)
	if next, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); next != nil || err == nil {
		t.Fatal("unbounded history accepted")
	}
	// This is prefix reference preservation, not verification of signed history.
}

func TestM1QANativeSelectionReferencePathAndTotalBudget(t *testing.T) {
	m1qaStartupTestReset(t)
	for _, name := range []string{"root", "login-key", "operation-key", "host-key", "seal", "metadata", "current-status", "relative", "bad-digest", "aggregate-budget"} {
		t.Run(name, func(t *testing.T) {
			file, fields, postFile, post := m1qaNativeSelectionFixture(t)
			ref := map[string]any{"path": filepath.Join(filepath.Dir(file), "history.json"), "digest": strings.Repeat("3", 64), "bytes": 1}
			switch name {
			case "root":
				ref["path"] = fields["nativeRootPath"]
			case "login-key":
				ref["path"] = filepath.Join(filepath.Dir(file), "must-not-open-private-key")
			case "operation-key":
				ref["path"] = fields["operationPrivateKeyFile"]
			case "host-key":
				ref["path"] = fields["nativeHostKeyFile"]
			case "seal":
				ref["path"] = fields["loginSealKeyFile"]
			case "metadata":
				ref["path"] = postFile
			case "current-status":
				ref["path"] = post["statusPath"]
			case "relative":
				ref["path"] = "relative.json"
			case "bad-digest":
				ref["digest"] = "not-sha256"
			}
			post["statusHistory"] = []any{ref}
			if name == "aggregate-budget" {
				history := make([]any, 24)
				for i := range history {
					history[i] = map[string]any{"path": filepath.Join(filepath.Dir(file), fmt.Sprintf("large-%d.json", i)), "digest": strings.Repeat("3", 64), "bytes": 16384}
				}
				post["statusHistory"] = history
			}
			m1qaNativeWritePost(t, postFile, post)
			m1qaOperationWriteMetadata(t, file, fields)
			if s, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); s != nil || err == nil {
				t.Fatal("aliased/invalid/unbounded selected artifact accepted")
			}
		})
	}
}

func TestM1QANativeSelectionHistoryDuplicatesAndUnknownRejected(t *testing.T) {
	_, _, _, post := m1qaNativeSelectionFixture(t)
	data, err := json.Marshal(post)
	if err != nil {
		t.Fatal(err)
	}
	for _, item := range []string{
		`{"path":"/public/a","path":"/public/b","digest":"a","bytes":1}`,
		`{"path":"/public/a","digest":"a","bytes":1,"approved":true}`,
		`{"path":"/public/a","digest":"a"}`,
		`{"path":"/public/a","digest":"a","bytes":null}`,
		`{"path":false,"digest":"a","bytes":1}`,
	} {
		raw := strings.Replace(string(data), `"statusHistory":[]`, `"statusHistory":[`+item+`]`, 1)
		if _, err := decodeSocialM1QANativePostBuildReferences([]byte(raw)); err == nil {
			t.Fatal("non-exact predecessor reference accepted")
		}
	}
}

func TestM1QANativeSelectionProtectedPublicFileAndBudget(t *testing.T) {
	for _, mode := range []string{"missing", "symlink", "hardlink", "world-readable", "directory", "oversized", "empty"} {
		t.Run(mode, func(t *testing.T) {
			dir := t.TempDir()
			if err := os.Chmod(dir, 0700); err != nil {
				t.Fatal(err)
			}
			file := filepath.Join(dir, "public.json")
			if mode != "missing" && mode != "directory" {
				if err := os.WriteFile(file, []byte("{}"), 0600); err != nil {
					t.Fatal(err)
				}
			}
			switch mode {
			case "symlink":
				link := filepath.Join(dir, "link.json")
				if err := os.Symlink(file, link); err != nil {
					t.Fatal(err)
				}
				file = link
			case "hardlink":
				if err := os.Link(file, filepath.Join(dir, "link.json")); err != nil {
					t.Fatal(err)
				}
			case "world-readable":
				if err := os.Chmod(file, 0644); err != nil {
					t.Fatal(err)
				}
			case "directory":
				if err := os.Mkdir(file, 0700); err != nil {
					t.Fatal(err)
				}
			case "oversized":
				if err := os.WriteFile(file, []byte(strings.Repeat(" ", socialM1QANativeSelectionByteLimit+1)), 0600); err != nil {
					t.Fatal(err)
				}
			case "empty":
				if err := os.WriteFile(file, nil, 0600); err != nil {
					t.Fatal(err)
				}
			}
			if data, err := readSocialM1QANativeSelectionFile(file); data != nil || err == nil {
				t.Fatal("unsafe public metadata file accepted")
			}
		})
	}
	if _, err := decodeSocialM1QANativePostBuildReferences([]byte(strings.Repeat(" ", socialM1QANativeSelectionByteLimit+1))); err == nil {
		t.Fatal("unbounded parser accepted")
	}
}

func TestM1QANativeSelectionCanceledContextDoesNotOpenMetadata(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if host, first, err := loadSocialM1QANativeStartupSelection(ctx, socialM1QAStartupMetadata{}, socialLoginRuntimeConfig{}, nil); host != nil || first != nil || !errors.Is(err, context.Canceled) {
		t.Fatal("pre-canceled loader attempted acquisition")
	}
	if host, first, err := loadSocialM1QANativeStartupSelection(nil, socialM1QAStartupMetadata{}, socialLoginRuntimeConfig{}, nil); host != nil || first != nil || err == nil {
		t.Fatal("nil context accepted")
	}
}
