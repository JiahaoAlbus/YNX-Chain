package main

import (
	"crypto/tls"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestSocialLoginAccountHTTPRefusalBoundaries(t *testing.T) {
	config := publicSocialLoginRuntimeConfig(t)
	runtime, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if err := waitSocialLoginRuntimeClose(runtime); err != nil {
			t.Error(err)
		}
	}()
	handler := runtime.service.ProductHandler(nil)
	request := httptest.NewRequest(http.MethodPost, "https://social.ynxweb4.com/v4/login/start", strings.NewReader(`{"intent":"A"}`))
	request.Header.Set("Origin", "https://social.ynxweb4.com")
	request.Header.Set("Content-Type", "application/json")
	started := httptest.NewRecorder()
	handler.ServeHTTP(started, request)
	if started.Code != 200 {
		t.Fatalf("public fixture start status %d", started.Code)
	}
	cookies := started.Result().Cookies()
	if len(cookies) != 2 {
		t.Fatal("missing fixture custody")
	}
	for _, scenario := range []string{"not-redeemed", "missing-tls", "wrong-host", "wrong-origin", "multiple-origin", "wrong-method", "query", "nonempty-body", "missing-cookie", "duplicate-cookie", "wrong-binding"} {
		t.Run(scenario, func(t *testing.T) {
			body := ""
			url := "https://social.ynxweb4.com/v4/login/account"
			method := http.MethodPost
			if scenario == "wrong-method" {
				method = http.MethodGet
			}
			if scenario == "query" {
				url += "?unexpected=1"
			}
			if scenario == "nonempty-body" {
				body = `{"grantToken":"NOT_ACCEPTED_FROM_BROWSER"}`
			}
			req := httptest.NewRequest(method, url, strings.NewReader(body))
			req.TLS = &tls.ConnectionState{}
			req.Header.Set("Origin", "https://social.ynxweb4.com")
			for _, cookie := range cookies {
				if scenario == "missing-cookie" {
					continue
				}
				copyCookie := *cookie
				if scenario == "wrong-binding" && strings.Contains(cookie.Name, "binding") {
					copyCookie.Value = strings.Repeat("A", 43)
				}
				req.AddCookie(&copyCookie)
			}
			switch scenario {
			case "missing-tls":
				req.TLS = nil
				req.Header.Set("X-Forwarded-Proto", "https")
			case "wrong-host":
				req.Host = "untrusted.invalid"
			case "wrong-origin":
				req.Header.Set("Origin", "https://untrusted.invalid")
			case "multiple-origin":
				req.Header.Add("Origin", "https://social.ynxweb4.com")
			case "duplicate-cookie":
				req.AddCookie(cookies[0])
			}
			result := httptest.NewRecorder()
			handler.ServeHTTP(result, req)
			if result.Code < 400 {
				t.Fatalf("unsafe observation accepted: status %d", result.Code)
			}
			if scenario == "not-redeemed" && result.Code != http.StatusConflict {
				t.Fatalf("account route not mounted: %d", result.Code)
			}
			if strings.Contains(result.Body.String(), "ACCOUNT_OBSERVED") || strings.Contains(result.Body.String(), "NOT_ACCEPTED_FROM_BROWSER") {
				t.Fatal("refusal published identity or echoed input")
			}
			for _, cookie := range cookies {
				if strings.Contains(result.Body.String(), cookie.Value) {
					t.Fatal("custody leaked in response")
				}
			}
		})
	}
	cancelRequest := httptest.NewRequest(http.MethodPost, "https://social.ynxweb4.com/v4/login/cancel", nil)
	cancelRequest.Header.Set("Origin", "https://social.ynxweb4.com")
	for _, cookie := range cookies {
		cancelRequest.AddCookie(cookie)
	}
	cancelled := httptest.NewRecorder()
	handler.ServeHTTP(cancelled, cancelRequest)
	if cancelled.Code != 200 {
		t.Fatalf("cancel status %d", cancelled.Code)
	}
	after := httptest.NewRequest(http.MethodPost, "https://social.ynxweb4.com/v4/login/account", nil)
	after.Header.Set("Origin", "https://social.ynxweb4.com")
	for _, cookie := range cookies {
		after.AddCookie(cookie)
	}
	refused := httptest.NewRecorder()
	handler.ServeHTTP(refused, after)
	if refused.Code != http.StatusConflict {
		t.Fatalf("cancelled attempt account route status %d", refused.Code)
	}
}
