package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/centralbrowserfamily"
	"testing"
	"time"
)

func TestM1OperationStartupPartialCustody(t *testing.T) {
	r := &socialLoginRuntime{}
	if e := r.openM1QAAccountOperation(context.Background(), &socialM1QAOperationStartupSelection{}); e == nil || r.accountOperation != nil {
		t.Fatal("missing root accepted")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	s := &socialM1QAOperationStartupSelection{owner: new(centralbrowserfamily.SocialM1QAOperationOwner), originalNow: time.Now}
	if e := r.openM1QAAccountOperation(ctx, s); e == nil || r.accountOperation == nil || r.releases.accountOperation != r.accountOperation {
		t.Fatal("partial runtime lost")
	}
	original := r.accountOperation
	if e := r.openM1QAAccountOperation(context.Background(), s); e == nil || r.accountOperation != original {
		t.Fatal("replacement allowed")
	}
	if e := r.Close(context.Background()); e != nil {
		t.Fatal(e)
	}
	if e := r.Close(context.Background()); e != nil || r.accountOperation != original {
		t.Fatal("cleanup lost owner")
	}
}
