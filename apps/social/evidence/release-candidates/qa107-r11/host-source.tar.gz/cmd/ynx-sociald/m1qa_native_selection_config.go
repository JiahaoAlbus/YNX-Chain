package main

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"github.com/JiahaoAlbus/YNX-Chain/internal/centralbrowserfamily"
)

const socialM1QANativeSelectionByteLimit = 131072

// Public deployment references, not a NativeSource or first-device authority.
// Trust roots, profile/operation/TLS identities and minimum accepted floors
// come from the independently pinned pre-build startup selection. The final
// signed registration/status references are loaded separately after the build.
type socialM1QANativeStartupMetadata struct {
	source                                         centralbrowserfamily.SocialNativeInstanceSourceConfig
	firstDevice                                    firstEnrollmentStartup
	challengeDirectory, selectionFile, hostKeyFile string
}

func validSocialM1QANativeStartupMetadata(n *socialM1QANativeStartupMetadata) bool {
	if n == nil || n.firstDevice.mode != "authority-v3" || n.firstDevice.realm == "" || len(n.firstDevice.realm) > 256 || strings.TrimSpace(n.firstDevice.realm) != n.firstDevice.realm || strings.ContainsAny(n.firstDevice.realm, "\x00\r\n") {
		return false
	}
	for _, p := range []string{n.source.RootPath, n.firstDevice.path, n.challengeDirectory, n.selectionFile, n.hostKeyFile} {
		if !socialLoginCleanFilePath(p) || strings.ContainsRune(p, '\x00') {
			return false
		}
	}
	return socialM1QAStartupDigestValid(n.source.RootDigest) && socialM1QAStartupDigestValid(n.source.ExpectedTLSSPKIDigest) && n.source.RootBytes > 0 && n.source.RootBytes <= 16384 && n.source.MinimumRegistrationRevision > 0 && n.source.MinimumRegistrationRevision <= 9007199254740991 && n.source.MinimumStatusSequence > 0 && n.source.MinimumStatusSequence <= 9007199254740991
}

func loadSocialM1QANativeStartupSelection(ctx context.Context, m socialM1QAStartupMetadata, login socialLoginRuntimeConfig, protected []string) (*socialNativeHostStartupSelection, *firstEnrollmentStartup, error) {
	if ctx == nil {
		return nil, nil, errSocialM1QAStartupConfiguration
	}
	if err := ctx.Err(); err != nil {
		return nil, nil, err
	}
	n := m.native
	if !validSocialM1QANativeStartupMetadata(n) || m.operation == nil || !validSocialM1QAOperationProvisioning(m.operation, login) || !m1QAFirstDevicePaths(login, n.firstDevice) {
		return nil, nil, errSocialM1QAStartupConfiguration
	}
	// No private key or signed artifact is read by this metadata loader. Prevent
	// its public-file locator from being an already selected secret/store path.
	for _, p := range []string{login.PrivateKeyFile, login.Store.SealKeyFile, login.Store.Directory, login.ChallengeDirectory, n.hostKeyFile, m.operation.privateKeyFile} {
		if n.selectionFile == p || n.hostKeyFile == login.PrivateKeyFile || n.hostKeyFile == m.operation.privateKeyFile {
			return nil, nil, errSocialM1QAStartupConfiguration
		}
	}
	data, err := readSocialM1QANativeSelectionFile(n.selectionFile)
	if err != nil {
		return nil, nil, err
	}
	if err = ctx.Err(); err != nil {
		return nil, nil, err
	}
	post, err := decodeSocialM1QANativePostBuildReferences(data)
	if err != nil {
		return nil, nil, err
	}
	config := n.source
	config.RegistrationPath, config.RegistrationDigest, config.RegistrationBytes = post.RegistrationPath, post.RegistrationDigest, post.RegistrationBytes
	config.StatusPath, config.StatusDigest, config.StatusBytes = post.StatusPath, post.StatusDigest, post.StatusBytes
	config.StatusHistory = append([]centralbrowserfamily.SocialNativeStatusHistoryFile(nil), post.StatusHistory...)
	config.ExpectedProfileDigest = m.profile.ProfileDigest
	config.ExpectedCentralRegistryDigest = m.profile.ExpectedRegistryDigest
	config.ExpectedOperationRegistrationDigest = m.operation.owner.ExpectedNodeConfigDigest
	config.ExpectedCertificateDigest = m.profile.ExpectedCertificateDigest
	config.ExpectedCallbackManifestDigest = m.profile.ExpectedCallbackManifestDigest
	// The original normal constructor observes /proc/self/exe, then the actual
	// signed 26-field verifier checks the exact digest. Never compile that final
	// digest, or a post-build metadata hash containing it, back into this binary.
	config.ExpectedServiceBinaryDigest = ""
	config.Now = time.Now
	for _, digest := range []string{config.ExpectedProfileDigest, config.ExpectedCentralRegistryDigest, config.ExpectedOperationRegistrationDigest, config.ExpectedCertificateDigest, config.ExpectedCallbackManifestDigest} {
		if !socialM1QAStartupDigestValid(digest) {
			return nil, nil, errSocialM1QAStartupConfiguration
		}
	}
	seen := make(map[string]bool, len(protected)+len(config.StatusHistory)+3)
	for _, p := range protected {
		seen[p] = true
	}
	seen[config.RootPath] = true
	refs := []centralbrowserfamily.SocialNativeStatusHistoryFile{{Path: config.RegistrationPath, Digest: config.RegistrationDigest, Bytes: config.RegistrationBytes}, {Path: config.StatusPath, Digest: config.StatusDigest, Bytes: config.StatusBytes}}
	refs = append(refs, config.StatusHistory...)
	total := config.RootBytes
	for _, ref := range refs {
		if !socialLoginCleanFilePath(ref.Path) || strings.ContainsRune(ref.Path, '\x00') || seen[ref.Path] || !socialM1QAStartupDigestValid(ref.Digest) || ref.Bytes < 1 || ref.Bytes > 16384 || ref.Bytes > 393216-total {
			return nil, nil, errSocialM1QAStartupConfiguration
		}
		seen[ref.Path] = true
		total += ref.Bytes
	}
	if err := ctx.Err(); err != nil {
		return nil, nil, err
	}
	first := n.firstDevice
	// These are constructor inputs only. No owner, provider, pipe, status grant,
	// counter reset or permission is fabricated, opened, or refreshed here.
	return &socialNativeHostStartupSelection{source: config, hostKeyFile: n.hostKeyFile}, &first, nil
}

// Same protected public-file read discipline as the login metadata reader,
// with a separate bounded budget for the existing complete predecessor prefix.
// Its digest is deliberately not an independent authority or a binary input.
func readSocialM1QANativeSelectionFile(path string) ([]byte, error) {
	if !socialLoginCleanFilePath(path) || strings.ContainsRune(path, '\x00') {
		return nil, errSocialM1QAStartupConfiguration
	}
	parent, err := os.Lstat(filepath.Dir(path))
	if err != nil || !socialLoginConfigOwned(parent, true) {
		return nil, errSocialM1QAStartupConfiguration
	}
	fd, err := syscall.Open(path, syscall.O_RDONLY|syscall.O_NOFOLLOW|syscall.O_CLOEXEC|syscall.O_NONBLOCK, 0)
	if err != nil {
		return nil, errSocialM1QAStartupConfiguration
	}
	f := os.NewFile(uintptr(fd), "social-m1qa-public-native-selection")
	held, statErr := f.Stat()
	named, nameErr := os.Lstat(path)
	if statErr != nil || nameErr != nil || !socialLoginConfigOwned(held, false) || !socialLoginConfigOwned(named, false) || !os.SameFile(held, named) || held.Size() < 1 || held.Size() > socialM1QANativeSelectionByteLimit {
		_ = f.Close()
		return nil, errSocialM1QAStartupConfiguration
	}
	data, readErr := io.ReadAll(io.LimitReader(f, socialM1QANativeSelectionByteLimit+1))
	after, afterErr := f.Stat()
	current, currentErr := os.Lstat(path)
	parentAfter, parentErr := os.Lstat(filepath.Dir(path))
	closeErr := f.Close()
	if readErr != nil || closeErr != nil || afterErr != nil || currentErr != nil || parentErr != nil || len(data) > socialM1QANativeSelectionByteLimit || !socialLoginConfigOwned(current, false) || !socialLoginConfigOwned(parentAfter, true) || !os.SameFile(held, after) || !os.SameFile(held, current) || !os.SameFile(parent, parentAfter) || held.Size() != after.Size() || int64(len(data)) != held.Size() || !held.ModTime().Equal(after.ModTime()) {
		return nil, errSocialM1QAStartupConfiguration
	}
	return data, nil
}

// This parses ONLY deployment references into the existing typed selectors.
// Root keys, expected identities/floors, clock, TTL, state and the signed 26/14
// bodies cannot be overridden here. Their existing verifier runs later.
func decodeSocialM1QANativePostBuildReferences(data []byte) (centralbrowserfamily.SocialNativeInstanceSourceConfig, error) {
	var out centralbrowserfamily.SocialNativeInstanceSourceConfig
	if len(data) == 0 || len(data) > socialM1QANativeSelectionByteLimit {
		return out, errSocialM1QAStartupConfiguration
	}
	d := json.NewDecoder(bytes.NewReader(data))
	first, err := d.Token()
	if err != nil || first != json.Delim('{') {
		return out, errSocialM1QAStartupConfiguration
	}
	fields := map[string]*string{"registrationPath": &out.RegistrationPath, "registrationDigest": &out.RegistrationDigest, "statusPath": &out.StatusPath, "statusDigest": &out.StatusDigest}
	sizes := map[string]*int64{"registrationBytes": &out.RegistrationBytes, "statusBytes": &out.StatusBytes}
	seen := make(map[string]bool)
	for d.More() {
		token, err := d.Token()
		key, ok := token.(string)
		if err != nil || !ok || seen[key] {
			return out, errSocialM1QAStartupConfiguration
		}
		seen[key] = true
		if field, ok := fields[key]; ok {
			token, err := d.Token()
			value, ok := token.(string)
			if err != nil || !ok {
				return out, errSocialM1QAStartupConfiguration
			}
			*field = value
		} else if size, ok := sizes[key]; ok {
			if err := decodeSocialM1QANativeReferenceSize(d, size); err != nil {
				return out, err
			}
		} else if key == "statusHistory" {
			start, err := d.Token()
			if err != nil || start != json.Delim('[') {
				return out, errSocialM1QAStartupConfiguration
			}
			for d.More() {
				if len(out.StatusHistory) >= 255 {
					return out, errSocialM1QAStartupConfiguration
				}
				ref, err := decodeSocialM1QANativeHistoryReference(d)
				if err != nil {
					return out, err
				}
				out.StatusHistory = append(out.StatusHistory, ref)
			}
			end, err := d.Token()
			if err != nil || end != json.Delim(']') {
				return out, errSocialM1QAStartupConfiguration
			}
		} else {
			return out, errSocialM1QAStartupConfiguration
		}
	}
	last, err := d.Token()
	if err != nil || last != json.Delim('}') || len(seen) != 7 {
		return out, errSocialM1QAStartupConfiguration
	}
	if _, err := d.Token(); err != io.EOF {
		return out, errSocialM1QAStartupConfiguration
	}
	return out, nil
}

func decodeSocialM1QANativeReferenceSize(d *json.Decoder, size *int64) error {
	var raw json.RawMessage
	if err := d.Decode(&raw); err != nil || len(raw) == 0 || raw[0] < '1' || raw[0] > '9' || json.Unmarshal(raw, size) != nil || *size > 16384 {
		return errSocialM1QAStartupConfiguration
	}
	return nil
}

func decodeSocialM1QANativeHistoryReference(d *json.Decoder) (centralbrowserfamily.SocialNativeStatusHistoryFile, error) {
	var out centralbrowserfamily.SocialNativeStatusHistoryFile
	first, err := d.Token()
	if err != nil || first != json.Delim('{') {
		return out, errSocialM1QAStartupConfiguration
	}
	seen := make(map[string]bool)
	for d.More() {
		token, err := d.Token()
		key, ok := token.(string)
		if err != nil || !ok || seen[key] {
			return out, errSocialM1QAStartupConfiguration
		}
		seen[key] = true
		switch key {
		case "path", "digest":
			token, err := d.Token()
			value, ok := token.(string)
			if err != nil || !ok {
				return out, errSocialM1QAStartupConfiguration
			}
			if key == "path" {
				out.Path = value
			} else {
				out.Digest = value
			}
		case "bytes":
			if err := decodeSocialM1QANativeReferenceSize(d, &out.Bytes); err != nil {
				return out, err
			}
		default:
			return out, errSocialM1QAStartupConfiguration
		}
	}
	last, err := d.Token()
	if err != nil || last != json.Delim('}') || len(seen) != 3 {
		return out, errSocialM1QAStartupConfiguration
	}
	return out, nil
}
