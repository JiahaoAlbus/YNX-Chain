package main

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

func TestEnrollmentInitializationExplicitFreshDirectory(t *testing.T) {
	directory := filepath.Join(privateEnrollmentParent(t), "enrollment")
	if _, err := kernel.OpenFirstDeviceEnrollmentStore(directory); err == nil {
		t.Fatal("missing storage was opened as a fresh directory")
	}
	if _, err := os.Stat(directory); !os.IsNotExist(err) {
		t.Fatalf("failed open created or changed the missing path: %v", err)
	}
	if err := initializeFirstDeviceEnrollmentDirectory(directory); err != nil {
		t.Fatal(err)
	}
	if err := initializeFirstDeviceEnrollmentDirectory(directory); err == nil {
		t.Fatal("duplicate initialization accepted an existing directory")
	}
	store, err := kernel.OpenFirstDeviceEnrollmentStore(directory)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if err := store.Close(); err != nil {
			t.Error(err)
		}
	}()
	presence, snapshot, err := store.ReadPresence(context.Background(), "qa-storage-only-subject")
	if err != nil {
		t.Fatal(err)
	}
	if presence == nil || snapshot.State != kernel.FirstEnrollmentAbsent || snapshot.LastOperation != "" || len(snapshot.Registration.Identity) != 0 {
		t.Fatal("storage initialization created identity or operation facts")
	}
}

func TestEnrollmentInitializationPreservesExistingDirectory(t *testing.T) {
	directory := filepath.Join(privateEnrollmentParent(t), "enrollment")
	if err := os.Mkdir(directory, 0700); err != nil {
		t.Fatal(err)
	}
	marker := filepath.Join(directory, "preserve-public-marker")
	if err := os.WriteFile(marker, []byte("preserve"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := initializeFirstDeviceEnrollmentDirectory(directory); err == nil {
		t.Fatal("existing incomplete directory was initialized")
	}
	if data, err := os.ReadFile(marker); err != nil || string(data) != "preserve" {
		t.Fatalf("existing content changed: %v", err)
	}
	if store, err := kernel.OpenFirstDeviceEnrollmentStore(directory); err == nil {
		_ = store.Close()
		t.Fatal("incomplete existing directory became a valid empty store")
	}
}

func TestEnrollmentInitializationRejectsPublicParent(t *testing.T) {
	parent := privateEnrollmentParent(t)
	if err := os.Chmod(parent, 0755); err != nil {
		t.Fatal(err)
	}
	directory := filepath.Join(parent, "enrollment")
	if err := initializeFirstDeviceEnrollmentDirectory(directory); err == nil {
		t.Fatal("non-private parent accepted")
	}
	if _, err := os.Stat(directory); !os.IsNotExist(err) {
		t.Fatalf("rejected parent left a new directory: %v", err)
	}
}

func privateEnrollmentParent(t *testing.T) string {
	t.Helper()
	parent := filepath.Join(t.TempDir(), "private-social")
	if err := os.Mkdir(parent, 0700); err != nil {
		t.Fatal(err)
	}
	return parent
}

func TestEnrollmentInitializationRejectsAmbiguousPaths(t *testing.T) {
	for _, directory := range []string{"", "relative-enrollment", string(filepath.Separator), t.TempDir() + "/child/../enrollment"} {
		t.Run(directory, func(t *testing.T) {
			if err := initializeFirstDeviceEnrollmentDirectory(directory); err == nil {
				t.Fatal("ambiguous initialization path accepted")
			}
		})
	}
}
