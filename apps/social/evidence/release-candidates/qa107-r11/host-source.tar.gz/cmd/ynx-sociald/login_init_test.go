package main

import (
	"bytes"
	"flag"
	"io"
	"os"
	"path/filepath"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

func TestSocialLoginInitializationM1QAUsesSeparateTypedStore(t *testing.T) {
	parent := t.TempDir()
	if err := os.Chmod(parent, 0700); err != nil {
		t.Fatal(err)
	}
	key := filepath.Join(parent, "m1qa-login-seal.key")
	// PUBLIC mechanical fixture only; no actual service or device identity.
	if err := os.WriteFile(key, bytes.Repeat([]byte{0x41}, 32), 0600); err != nil {
		t.Fatal(err)
	}
	directory := filepath.Join(parent, "m1qa-login-v1")
	args := []string{"--" + loginInitM1QADirectoryFlag, directory, "--" + loginInitKeyFlag, key}
	if handled, err := runLoginInitialization(t, args...); !handled || err != nil {
		t.Fatalf("explicit typed M1QA initialization failed: handled=%v err=%v", handled, err)
	}
	// An ordinary-login reader must not accept this as its own storage profile.
	if ordinary, err := kernel.OpenSocialLoginTransactions(directory, key); err == nil || ordinary != nil {
		if ordinary != nil {
			_ = ordinary.Close()
		}
		t.Fatal("M1QA initializer created an ordinary-login store")
	}
	entries, err := os.ReadDir(directory)
	if err != nil || len(entries) == 0 {
		t.Fatal("typed initializer did not persist storage", err)
	}
	before := make(map[string][]byte)
	for _, entry := range entries {
		if entry.Type().IsRegular() {
			raw, err := os.ReadFile(filepath.Join(directory, entry.Name()))
			if err != nil {
				t.Fatal(err)
			}
			before[entry.Name()] = raw
		}
	}
	if handled, err := runLoginInitialization(t, args...); !handled || err == nil {
		t.Fatal("existing M1QA directory was reinitialized")
	}
	for name, raw := range before {
		after, err := os.ReadFile(filepath.Join(directory, name))
		if err != nil || !bytes.Equal(raw, after) {
			t.Fatal("duplicate M1QA initialization changed existing storage", name, err)
		}
	}
	if current, err := os.ReadFile(key); err != nil || !bytes.Equal(current, bytes.Repeat([]byte{0x41}, 32)) {
		t.Fatal("existing fixture seal key was changed")
	}
}

func TestSocialLoginInitializationM1QARejectsAmbiguousOrMissingInputs(t *testing.T) {
	parent := t.TempDir()
	if err := os.Chmod(parent, 0700); err != nil {
		t.Fatal(err)
	}
	key := filepath.Join(parent, "m1qa-login-seal.key")
	directory := filepath.Join(parent, "m1qa-login-v1")
	for _, args := range [][]string{
		{"--" + loginInitM1QADirectoryFlag, directory},
		{"--" + loginInitDirectoryFlag, directory, "--" + loginInitM1QADirectoryFlag, directory, "--" + loginInitKeyFlag, key},
		{"--" + loginInitM1QADirectoryFlag, directory, "--" + loginInitKeyFlag, key, "--check-config"},
		{"--" + loginInitM1QADirectoryFlag, directory, "--" + loginInitKeyFlag, key, "unexpected"},
		{"--" + loginInitM1QADirectoryFlag, "relative", "--" + loginInitKeyFlag, key},
		{"--" + loginInitM1QADirectoryFlag, "/", "--" + loginInitKeyFlag, key},
		{"--" + loginInitM1QADirectoryFlag, directory, "--" + loginInitKeyFlag, key},
	} {
		if handled, err := runLoginInitialization(t, args...); !handled || err == nil {
			t.Fatalf("ambiguous or missing M1QA inputs accepted: %v", args)
		}
	}
	if _, err := os.Stat(key); !os.IsNotExist(err) {
		t.Fatal("missing M1QA seal key was generated")
	}
	if err := os.WriteFile(key, bytes.Repeat([]byte{0x41}, 32), 0600); err != nil {
		t.Fatal(err)
	}
	wrongDirectory := filepath.Join(parent, "ordinary-login")
	if handled, err := runLoginInitialization(t, "--"+loginInitM1QADirectoryFlag, wrongDirectory, "--"+loginInitKeyFlag, key); !handled || err == nil {
		t.Fatal("M1QA typed path requirements were bypassed")
	}
	if _, err := os.Stat(wrongDirectory); !os.IsNotExist(err) {
		t.Fatal("invalid typed M1QA path created a store")
	}
}

func runLoginInitialization(t *testing.T, args ...string) (bool, error) {
	t.Helper()
	fs := flag.NewFlagSet("login-init-test", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	registerSocialLoginInitializationFlags(fs)
	fs.Bool("check-config", false, "test conflict")
	if err := fs.Parse(args); err != nil {
		t.Fatal(err)
	}
	return handleSocialLoginInitialization(fs)
}

func TestSocialLoginInitializationExplicitOnly(t *testing.T) {
	if handled, err := runLoginInitialization(t); handled || err != nil {
		t.Fatalf("ordinary startup intercepted: handled=%v err=%v", handled, err)
	}
	parent := t.TempDir()
	if err := os.Chmod(parent, 0700); err != nil {
		t.Fatal(err)
	}
	key := filepath.Join(parent, "fixture-only.key")
	// Local test fixture, not a shared issuer or production seal key.
	if err := os.WriteFile(key, make([]byte, 32), 0600); err != nil {
		t.Fatal(err)
	}
	directory := filepath.Join(parent, "transactions")
	args := []string{"--" + loginInitDirectoryFlag, directory, "--" + loginInitKeyFlag, key}
	if handled, err := runLoginInitialization(t, args...); !handled || err != nil {
		t.Fatalf("explicit initialization failed: handled=%v err=%v", handled, err)
	}
	owner, err := kernel.OpenSocialLoginTransactions(directory, key)
	if err != nil {
		t.Fatal(err)
	}
	if err := owner.Close(); err != nil {
		t.Fatal(err)
	}
	if handled, err := runLoginInitialization(t, args...); !handled || err == nil {
		t.Fatal("existing store must not be reinitialized")
	}
	owner, err = kernel.OpenSocialLoginTransactions(directory, key)
	if err != nil {
		t.Fatalf("duplicate initialization damaged original: %v", err)
	}
	if err := owner.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestSocialLoginInitializationRejectsAmbiguity(t *testing.T) {
	for _, args := range [][]string{
		{"--" + loginInitDirectoryFlag, "/unused"},
		{"--" + loginInitKeyFlag, "/unused"},
		{"--" + loginInitDirectoryFlag, "/unused", "--" + loginInitKeyFlag, "/unused-key", "--check-config"},
		{"--" + loginInitDirectoryFlag, "/", "--" + loginInitKeyFlag, "/unused-key"},
		{"--" + loginInitDirectoryFlag, "relative", "--" + loginInitKeyFlag, "/unused-key"},
		{"--" + loginInitDirectoryFlag, "/unused", "--" + loginInitKeyFlag, "/unused-key", "unexpected"},
	} {
		if handled, err := runLoginInitialization(t, args...); !handled || err == nil {
			t.Fatalf("ambiguous initialization accepted: %v", args)
		}
	}
}

func TestSocialLoginInitializationMissingKey(t *testing.T) {
	parent := t.TempDir()
	if err := os.Chmod(parent, 0700); err != nil {
		t.Fatal(err)
	}
	key := filepath.Join(parent, "absent.key")
	directory := filepath.Join(parent, "transactions")
	if handled, err := runLoginInitialization(t, "--"+loginInitDirectoryFlag, directory, "--"+loginInitKeyFlag, key); !handled || err == nil {
		t.Fatal("missing key was accepted")
	}
	if _, err := os.Stat(key); !os.IsNotExist(err) {
		t.Fatalf("missing key must never be generated: %v", err)
	}
}
