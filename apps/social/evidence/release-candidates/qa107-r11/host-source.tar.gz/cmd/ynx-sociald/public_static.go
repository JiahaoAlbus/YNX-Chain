//go:build linux || darwin

package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

const socialPublicAssetManifestEnvironment = "YNX_SOCIAL_PUBLIC_ASSET_MANIFEST_FILE"
const socialPublicManifestLimit int64 = 65536
const socialPublicFileLimit int64 = 8388608
const socialPublicTotalLimit int64 = 33554432
const socialPublicEntryLimit = 256
const socialPublicAssetLinksPath = "/.well-known/assetlinks.json"
const socialPublicAssetLinksDigest = "f8965a46e28dc2ab144cbd4f4f919742af60492988710dc5c8e754b647bcb825"

// Independently admitted PUBLIC inventory, not any identity/device authority.
// Its exact digest is supplied with -X after the actual public carrier exists.
var socialPublicAssetsAdmittedManifestDigest string

var errSocialPublicStaticSelection = errors.New("Social public asset selection invalid or unavailable")

type socialPublicManifest struct {
	Version int                     `json:"version"`
	Files   []socialPublicFileRecord `json:"files"`
}
type socialPublicFileRecord struct {
	Path   string `json:"path"`
	Bytes  int64  `json:"bytes"`
	SHA256 string `json:"sha256"`
}
type socialPublicAsset struct {
	body        []byte
	contentType string
	digest      string
}
type socialPublicStaticAssets struct {
	files map[string]socialPublicAsset
}

func socialPublicDigest(b []byte) string {
	sum := sha256.Sum256(b)
	return hex.EncodeToString(sum[:])
}

func socialPublicDigestValid(digest string) bool {
	if len(digest) != 64 || strings.ToLower(digest) != digest {
		return false
	}
	_, err := hex.DecodeString(digest)
	return err == nil
}

// Public filenames are explicit, canonical URL paths; private namespaces can
// never be admitted by an asset manifest, even if the selected bytes are valid.
func socialPublicAssetType(urlPath string) (string, bool) {
	if urlPath == "/" {
		return "text/html; charset=utf-8", true
	}
	if urlPath == socialPublicAssetLinksPath {
		return "application/json; charset=utf-8", true
	}
	if len(urlPath) > 1024 || !strings.HasPrefix(urlPath, "/") ||
		path.Clean(urlPath) != urlPath || strings.HasSuffix(urlPath, "/") {
		return "", false
	}
	for _, ch := range urlPath {
		if ch <= 32 || ch >= 127 || strings.ContainsRune("\\%?#", ch) {
			return "", false
		}
	}
	parts := strings.Split(strings.TrimPrefix(urlPath, "/"), "/")
	for _, part := range parts {
		if part == "" || strings.HasPrefix(part, ".") {
			return "", false
		}
	}
	head := strings.ToLower(parts[0])
	switch head {
	case "m1qa", "sso", "auth", "api", "source", "source-authority", "private",
		"account", "accounts", "login", "first-device", "device", "devices":
		return "", false
	}
	if len(head) > 1 && head[0] == 'v' {
		version := true
		for _, ch := range head[1:] {
			version = version && ch >= '0' && ch <= '9'
		}
		if version {
			return "", false
		}
	}
	switch strings.ToLower(path.Ext(urlPath)) {
	case ".html":
		return "text/html; charset=utf-8", true
	case ".js", ".mjs":
		return "text/javascript; charset=utf-8", true
	case ".css":
		return "text/css; charset=utf-8", true
	case ".json", ".webmanifest":
		return "application/json; charset=utf-8", true
	case ".svg":
		return "image/svg+xml", true
	case ".png":
		return "image/png", true
	case ".jpg", ".jpeg":
		return "image/jpeg", true
	case ".gif":
		return "image/gif", true
	case ".webp":
		return "image/webp", true
	case ".ico":
		return "image/x-icon", true
	case ".woff":
		return "font/woff", true
	case ".woff2":
		return "font/woff2", true
	case ".ttf":
		return "font/ttf", true
	case ".wasm":
		return "application/wasm", true
	case ".txt":
		return "text/plain; charset=utf-8", true
	}
	return "", false
}

// Token validation precedes typed decoding so duplicate JSON keys cannot be
// silently accepted with last-value-wins semantics.
func socialPublicUniqueJSON(d *json.Decoder, depth int) error {
	if depth > 8 {
		return errSocialPublicStaticSelection
	}
	token, err := d.Token()
	if err != nil {
		return errSocialPublicStaticSelection
	}
	delim, ok := token.(json.Delim)
	if !ok {
		return nil
	}
	switch delim {
	case '{':
		seen := make(map[string]bool)
		for d.More() {
			key, err := d.Token()
			name, ok := key.(string)
			if err != nil || !ok || seen[name] {
				return errSocialPublicStaticSelection
			}
			seen[name] = true
			if err := socialPublicUniqueJSON(d, depth+1); err != nil {
				return err
			}
		}
		end, err := d.Token()
		if err != nil || end != json.Delim('}') {
			return errSocialPublicStaticSelection
		}
	case '[':
		for d.More() {
			if err := socialPublicUniqueJSON(d, depth+1); err != nil {
				return err
			}
		}
		end, err := d.Token()
		if err != nil || end != json.Delim(']') {
			return errSocialPublicStaticSelection
		}
	default:
		return errSocialPublicStaticSelection
	}
	return nil
}

func socialPublicReadFile(root *os.Root, name string, limit int64) ([]byte, error) {
	parts := strings.Split(name, "/")
	for i := range parts {
		info, err := root.Lstat(strings.Join(parts[:i+1], "/"))
		if err != nil || info.Mode()&os.ModeSymlink != 0 ||
			(i < len(parts)-1 && !info.IsDir()) {
			return nil, errSocialPublicStaticSelection
		}
	}
	// Nonblocking open prevents a replaced FIFO from hanging startup; the held
	// descriptor must still be regular. OpenRoot confines ancestor resolution.
	f, err := root.OpenFile(name, os.O_RDONLY|syscall.O_NOFOLLOW|syscall.O_NONBLOCK, 0)
	if err != nil {
		return nil, errSocialPublicStaticSelection
	}
	defer f.Close()
	info, err := f.Stat()
	if err != nil || !info.Mode().IsRegular() || info.Size() < 1 || info.Size() > limit {
		return nil, errSocialPublicStaticSelection
	}
	b, err := io.ReadAll(io.LimitReader(f, limit+1))
	if err != nil || int64(len(b)) > limit {
		return nil, errSocialPublicStaticSelection
	}
	return b, nil
}

func loadSocialPublicStaticAssets(lookup func(string) (string, bool), admittedDigest string) (*socialPublicStaticAssets, error) {
	if lookup == nil {
		return nil, errSocialPublicStaticSelection
	}
	filename, present := lookup(socialPublicAssetManifestEnvironment)
	if !present && admittedDigest == "" {
		return nil, nil
	}
	if !present || !socialPublicDigestValid(admittedDigest) || !filepath.IsAbs(filename) ||
		filepath.Clean(filename) != filename || strings.ContainsAny(filename, "\x00\r\n") {
		return nil, errSocialPublicStaticSelection
	}
	directory := filepath.Dir(filename)
	info, err := os.Lstat(directory)
	if err != nil || !info.IsDir() || info.Mode()&os.ModeSymlink != 0 {
		return nil, errSocialPublicStaticSelection
	}
	root, err := os.OpenRoot(directory)
	if err != nil {
		return nil, errSocialPublicStaticSelection
	}
	defer root.Close()
	body, err := socialPublicReadFile(root, filepath.Base(filename), socialPublicManifestLimit)
	if err != nil || socialPublicDigest(body) != admittedDigest {
		return nil, errSocialPublicStaticSelection
	}
	shape := json.NewDecoder(bytes.NewReader(body))
	if socialPublicUniqueJSON(shape, 0) != nil {
		return nil, errSocialPublicStaticSelection
	}
	if _, err := shape.Token(); err != io.EOF {
		return nil, errSocialPublicStaticSelection
	}
	decoder := json.NewDecoder(bytes.NewReader(body))
	decoder.DisallowUnknownFields()
	var manifest socialPublicManifest
	if decoder.Decode(&manifest) != nil || decoder.Decode(new(any)) != io.EOF ||
		manifest.Version != 1 || len(manifest.Files) == 0 || len(manifest.Files) > socialPublicEntryLimit {
		return nil, errSocialPublicStaticSelection
	}
	assets := &socialPublicStaticAssets{files: make(map[string]socialPublicAsset)}
	var total int64
	for _, entry := range manifest.Files {
		urlPath := "/" + entry.Path
		contentType, allowed := socialPublicAssetType(urlPath)
		if !allowed || entry.Path == "" || strings.HasPrefix(entry.Path, "/") ||
			path.Clean(entry.Path) != entry.Path || entry.Bytes < 1 || entry.Bytes > socialPublicFileLimit ||
			entry.Bytes > socialPublicTotalLimit-total || !socialPublicDigestValid(entry.SHA256) {
			return nil, errSocialPublicStaticSelection
		}
		if _, duplicate := assets.files[urlPath]; duplicate {
			return nil, errSocialPublicStaticSelection
		}
		if urlPath == socialPublicAssetLinksPath &&
			(entry.Bytes != 339 || entry.SHA256 != socialPublicAssetLinksDigest) {
			return nil, errSocialPublicStaticSelection
		}
		data, err := socialPublicReadFile(root, entry.Path, entry.Bytes)
		if err != nil || int64(len(data)) != entry.Bytes || socialPublicDigest(data) != entry.SHA256 {
			return nil, errSocialPublicStaticSelection
		}
		total += entry.Bytes
		assets.files[urlPath] = socialPublicAsset{body: data, contentType: contentType, digest: entry.SHA256}
	}
	index, ok := assets.files["/index.html"]
	if !ok {
		return nil, errSocialPublicStaticSelection
	}
	assets.files["/"] = index
	return assets, nil
}

// The frozen r3 original product/source handlers do not register assetlinks.
// If that ownership changes, its path must be removed from this static carrier;
// API/SSO/source namespaces are unconditionally delegated below.
func (a *socialPublicStaticAssets) handler(next http.Handler) http.Handler {
	if a == nil {
		return next
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL == nil || (r.Method != http.MethodGet && r.Method != http.MethodHead) ||
			r.URL.RawPath != "" || r.URL.EscapedPath() != r.URL.Path {
			next.ServeHTTP(w, r)
			return
		}
		asset, ok := a.files[r.URL.Path]
		if !ok {
			next.ServeHTTP(w, r)
			return
		}
		w.Header().Set("Content-Type", asset.contentType)
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("ETag", "\"sha256-"+asset.digest+"\"")
		w.Header().Set("Cache-Control", "public, max-age=0, must-revalidate")
		if asset.contentType == "text/html; charset=utf-8" || r.URL.Path == socialPublicAssetLinksPath {
			w.Header().Set("Cache-Control", "no-store")
		}
		http.ServeContent(w, r, path.Base(r.URL.Path), time.Time{}, bytes.NewReader(asset.body))
	})
}
