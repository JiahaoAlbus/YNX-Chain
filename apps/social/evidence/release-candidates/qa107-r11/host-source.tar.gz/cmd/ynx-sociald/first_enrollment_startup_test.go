package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
	"net/http"
	"os"
	"path/filepath"
	"testing"
)

func TestEnrollmentStartupSelection(t *testing.T) {
	config := socialLoginRuntimeConfig{ChallengeDirectory: "/private/challenges"}
	for _, tc := range []struct {
		name   string
		values map[string]string
		good   bool
	}{
		{"absent", nil, true},
		{"explicit", map[string]string{"YNX_SOCIAL_FIRST_DEVICE_MODE": "authority-v3", "YNX_SOCIAL_FIRST_DEVICE_REALM": "test-only", "YNX_SOCIAL_FIRST_DEVICE_AUTHORITY_FILE": "/private/new-v3"}, true},
		{"path-only", map[string]string{"YNX_SOCIAL_FIRST_DEVICE_AUTHORITY_FILE": "/private/new-v3"}, false},
		{"unknown-mode", map[string]string{"YNX_SOCIAL_FIRST_DEVICE_MODE": "automatic"}, false},
		{"challenge-only", map[string]string{"YNX_SOCIAL_FIRST_DEVICE_MODE": "challenge-only"}, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			_, err := loadFirstEnrollmentStartup(func(k string) (string, bool) { v, ok := tc.values[k]; return v, ok }, config, true)
			if (err == nil) != tc.good {
				t.Fatal(err)
			}
		})
	}
	values := map[string]string{"YNX_SOCIAL_FIRST_DEVICE_MODE": "authority-v3", "YNX_SOCIAL_FIRST_DEVICE_REALM": "test-only", "YNX_SOCIAL_FIRST_DEVICE_AUTHORITY_FILE": "/private/new-v3"}
	lookup := func(k string) (string, bool) { v, ok := values[k]; return v, ok }
	config.EnrollmentDirectory = "/private/old"
	if _, err := loadFirstEnrollmentStartup(lookup, config, true); err == nil {
		t.Fatal("two authorities accepted")
	}
	config.EnrollmentDirectory = ""
	if _, err := loadFirstEnrollmentStartup(lookup, config, false); err == nil {
		t.Fatal("disabled login accepted")
	}
}

func TestEnrollmentStartupMissingSourceOwnsCleanup(t *testing.T) {
	config := publicSocialLoginRuntimeConfig(t) // fixed published PUBLIC TEST ONLY fixture
	config.ChallengeDirectory = filepath.Join(filepath.Dir(config.PrivateKeyFile), "challenges")
	if err := os.Mkdir(config.ChallengeDirectory, 0700); err != nil {
		t.Fatal(err)
	}
	if err := kernel.ProvisionFirstDeviceAuthorizationStore(config.ChallengeDirectory); err != nil {
		t.Fatal(err)
	}
	r, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(filepath.Dir(config.PrivateKeyFile), "NEVER-CREATE-v3")
	calls := 0
	h, err := r.composeProduct(context.Background(), http.HandlerFunc(func(http.ResponseWriter, *http.Request) { calls++ }), nil, firstEnrollmentStartup{mode: "authority-v3", realm: "PUBLIC TEST ONLY", path: path})
	if err == nil || h != nil || calls != 0 || r.authority != nil || r.enrollment != nil {
		t.Fatal("source refusal bypass")
	}
	if _, err := os.Stat(path); !os.IsNotExist(err) {
		t.Fatal("implicit directory creation", err)
	}
	if other, err := kernel.OpenFirstDeviceAuthorizationStore(config.ChallengeDirectory); err == nil {
		other.Close()
		t.Fatal("original owner lost before cleanup")
	}
	for i := 0; i < 2; i++ {
		if err := r.Close(context.Background()); err != nil {
			t.Fatal(err)
		}
	}
	reopened, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal("cleanup leaked original store", err)
	}
	defer reopened.Close(context.Background())
	h, err = reopened.composeProduct(context.Background(), nil, nil, firstEnrollmentStartup{})
	if err != nil || h == nil {
		t.Fatal("challenge-only composition unavailable", err)
	}
	h.CloseIdleConnections()
}
