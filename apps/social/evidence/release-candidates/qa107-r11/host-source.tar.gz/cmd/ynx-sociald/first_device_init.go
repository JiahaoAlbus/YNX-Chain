package main

import (
	"errors"
	"flag"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

const firstDeviceChallengeInitFlag = "init-first-device-challenges-dir"

func registerFirstDeviceChallengeInitializationFlag(fs *flag.FlagSet) {
	fs.String(firstDeviceChallengeInitFlag, "", "Explicitly provision challenge storage in an existing private Social-only directory and exit; no device authorization")
}

func handleFirstDeviceChallengeInitialization(fs *flag.FlagSet) (bool, error) {
	var requested, other bool
	fs.Visit(func(f *flag.Flag) {
		if f.Name == firstDeviceChallengeInitFlag {
			requested = true
		} else {
			other = true
		}
	})
	if !requested {
		return false, nil
	}
	if other || fs.NArg() != 0 {
		return true, errors.New("Social challenge initialization requires its single flag and no other arguments")
	}
	directory := fs.Lookup(firstDeviceChallengeInitFlag).Value.String()
	if !socialLoginCleanFilePath(directory) {
		return true, errors.New("Social challenge initialization requires a clean absolute non-root directory path")
	}
	// Never called by startup, Open failure, login, retry, or recovery. Provision
	// enforces existing private directory ownership and exclusive file creation.
	return true, kernel.ProvisionFirstDeviceAuthorizationStore(directory)
}
