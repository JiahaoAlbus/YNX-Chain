package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
	"path/filepath"
)

// Application namespaces only, not source approval. Open never provisions or
// truncates. Existing QA runtime retains every acquired store before errors.
func m1QAFirstDevicePaths(c socialLoginRuntimeConfig, s firstEnrollmentStartup) bool {
	parent := filepath.Dir(c.Store.Directory)
	if c.EnrollmentDirectory != "" || !socialLoginCleanFilePath(c.ChallengeDirectory) || filepath.Base(c.ChallengeDirectory) != "m1qa-first-device-v1" || filepath.Dir(c.ChallengeDirectory) != parent {
		return false
	}
	if s.mode == "challenge-only" {
		return s.realm == "" && s.path == ""
	}
	return s.mode == "authority-v3" && s.realm != "" && socialLoginCleanFilePath(s.path) && filepath.Base(s.path) == "m1qa-first-enrollment-v3.log" && filepath.Dir(s.path) == parent
}
func (r *socialLoginRuntime) mountM1QAFirstDevice(ctx context.Context, h *kernel.SocialProductHandler, source *kernel.SourceAuthorityRuntime, selection *socialM1QALoginStartupSelection) (*kernel.SocialProductHandler, error) {
	if ctx == nil {
		return nil, errSocialLoginRuntimeConfig
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if r == nil || selection == nil || selection.firstDevice == nil || r.challenges != nil || r.authority != nil || !m1QAFirstDevicePaths(selection.runtime, *selection.firstDevice) {
		return nil, errSocialLoginRuntimeConfig
	}
	s := *selection.firstDevice
	// Fail missing authority dependencies before opening any QA filesystem owner.
	if s.mode == "authority-v3" && (source == nil || r.accountOperation == nil) {
		return nil, kernel.ErrFirstAuthorizationUnavailable
	}
	store, err := kernel.OpenFirstDeviceAuthorizationStore(selection.runtime.ChallengeDirectory)
	if store != nil {
		r.challenges = store
		r.releases.challenges = store
	}
	if err != nil {
		return nil, err
	}
	mounted, authority, err := h.WithM1QAFirstDevice(ctx, r.service, r.m1qaProfile, store, source, s.realm, s.path, r.accountOperation, r.nativePublisher)
	if authority != nil {
		r.authority = authority
		r.releases.authority = authority
	}
	return mounted, err
}
