package main

import (
	"context"
	"errors"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

// Supplied once by trusted startup after the independently registered M1 signer
// and existing isolated store have been opened. No HTTP/environment selector or
// local approval flag populates this slot. The current main supplies none until
// A's exact trusted registration carrier is integrated.
var normalM1QALoginRuntime *socialLoginRuntime

// Existing three-argument main remains fail-closed for QA. The same normal
// constructor accepts the independently owned service when its real supplier
// exists; it does not construct registration authority from a public tuple.
func openNormalSocialProduct(ctx context.Context, source *kernel.SourceAuthorityRuntime, lookup func(string) (string, bool), qa ...*socialLoginRuntime) (*kernel.SocialProductHandler, error) {
	if ctx == nil || lookup == nil {
		return nil, errSocialM1QAStartupConfiguration
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	_, hasStartupFile := lookup(socialM1QAStartupConfigEnvironment)
	if hasStartupFile && (len(qa) != 0 || normalM1QALoginSelection != nil || normalM1QALoginRuntime != nil) {
		return nil, errSocialM1QAStartupAmbiguous
	}
	if len(qa) == 0 && normalM1QALoginSelection == nil && normalM1QALoginRuntime == nil {
		selection, enabled, err := loadSocialM1QALoginStartupSelection(ctx, lookup)
		if err != nil {
			return nil, err
		}
		if enabled {
			// Admission binds only these deployment bytes. The existing constructor
			// still verifies the signed profile before opening provider or storage.
			normalM1QALoginSelection = selection
		}
	}
	if len(qa) == 0 && normalM1QALoginSelection != nil {
		if normalM1QALoginRuntime != nil {
			return nil, errSocialLoginRuntimeConfig
		}
		owner, err := openSelectedM1QALoginRuntime(ctx, normalM1QALoginSelection)
		if err != nil {
			// Keep any partially acquired source/provider for exact cleanup.
			normalM1QALoginRuntime = owner
			return nil, errors.Join(err, closeNormalM1QALoginRuntime(context.Background()))
		}
		qa = []*socialLoginRuntime{owner}
	}
	if len(qa) > 1 || normalM1QALoginRuntime != nil || (len(qa) == 1 && qa[0] == nil) {
		return nil, errSocialLoginRuntimeConfig
	}
	if len(qa) == 1 {
		normalM1QALoginRuntime = qa[0]
		if qa[0].service == nil {
			return nil, errors.Join(errSocialLoginRuntimeConfig, closeNormalM1QALoginRuntime(context.Background()))
		}
	}
	h, err := openNormalSocialProductBase(ctx, source, lookup)
	if err == nil && normalM1QALoginRuntime != nil {
		h, err = h.WithM1QALoginService(normalM1QALoginRuntime.service, normalM1QALoginRuntime.m1qaProfile)
		if err == nil && normalM1QALoginSelection != nil && normalM1QALoginSelection.firstDevice != nil {
			h, err = normalM1QALoginRuntime.mountM1QAFirstDevice(ctx, h, source, normalM1QALoginSelection)
		}
	}
	if err != nil && normalM1QALoginRuntime != nil {
		// Never lose an uncertain partial runtime. Close QA first; failure leaves
		// the production runtime retained, rather than continuing cleanup blindly.
		cleanup := closeNormalM1QALoginRuntime(context.Background())
		if cleanup == nil {
			cleanup = waitSocialLoginRuntimeClose(normalSocialLoginRuntime)
		}
		return nil, errors.Join(err, cleanup)
	}
	return h, err
}

func closeNormalM1QALoginRuntime(ctx context.Context) error {
	if normalM1QALoginRuntime == nil {
		return nil
	}
	return normalM1QALoginRuntime.Close(ctx)
}
