package main

import (
	"context"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

// PUBLIC startup wiring controls only. These fixtures contain no signed root,
// real credential, provisioned account/store or native owner. A test-local pin
// is NOT a production admission and never enters a released candidate.
func m1qaStartupTestReset(t *testing.T) {
	t.Helper()
	digest, selection, runtime, qa := socialM1QAAdmittedStartupDigest, normalM1QALoginSelection, normalSocialLoginRuntime, normalM1QALoginRuntime
	socialM1QAAdmittedStartupDigest, normalM1QALoginSelection, normalSocialLoginRuntime, normalM1QALoginRuntime = "", nil, nil, nil
	t.Cleanup(func() {
		socialM1QAAdmittedStartupDigest, normalM1QALoginSelection, normalSocialLoginRuntime, normalM1QALoginRuntime = digest, selection, runtime, qa
	})
}

func m1qaStartupTestPin(data []byte) string {
	h := sha256.Sum256(data)
	return hex.EncodeToString(h[:])
}

func m1qaStartupTestFixture(t *testing.T) (string, []byte, map[string]any) {
	t.Helper()
	dir := t.TempDir()
	if err := os.Chmod(dir, 0700); err != nil {
		t.Fatal(err)
	}
	signerFile := filepath.Join(dir, "public-signer-config.json")
	signer, err := json.Marshal(map[string]string{
		"schema": "ynx-social-backend-signer/v1", "profile": "protected-backend-software-pkcs8-v1",
		"keyId": "PUBLIC_TEST_ONLY_UNADMITTED", "publicKey": base64.RawURLEncoding.EncodeToString(make([]byte, 32)),
		"privateKeyFile": filepath.Join(dir, "must-not-open-private-key"),
	})
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(signerFile, signer, 0600); err != nil {
		t.Fatal(err)
	}
	digest := strings.Repeat("a", 64)
	fields := map[string]any{
		"rootPath": filepath.Join(dir, "unissued-root.json"), "rootDigest": digest, "rootBytes": 1,
		"profilePath": filepath.Join(dir, "unissued-profile.json"), "profileDigest": digest, "profileBytes": 1,
		"expectedRegistryDigest": digest, "expectedTargetArtifactDigest": digest, "expectedCertificateDigest": digest,
		"expectedCallbackManifestDigest": digest, "expectedAssetLinksDigest": digest,
		"loginStateDirectory": filepath.Join(dir, "m1qa-login-v1"), "loginSealKeyFile": filepath.Join(dir, "m1qa-login-seal.key"),
		"loginSignerConfigFile": signerFile,
	}
	data, err := json.Marshal(fields)
	if err != nil {
		t.Fatal(err)
	}
	file := filepath.Join(dir, "startup.json")
	if err = os.WriteFile(file, data, 0600); err != nil {
		t.Fatal(err)
	}
	return file, data, fields
}

func m1qaStartupTestLookup(path string) func(string) (string, bool) {
	return func(name string) (string, bool) {
		if name == socialM1QAStartupConfigEnvironment {
			return path, true
		}
		return "", false
	}
}

func TestM1QAStartupConfigAbsentPreservesNormalConstructor(t *testing.T) {
	m1qaStartupTestReset(t)
	lookup := func(string) (string, bool) { return "", false }
	selection, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), lookup)
	if err != nil || enabled || selection != nil {
		t.Fatal("absent configuration acquired QA")
	}
	h, err := openNormalSocialProduct(context.Background(), nil, lookup)
	if err != nil || h == nil {
		t.Fatalf("ordinary unconfigured startup changed: %v", err)
	}
	h.CloseIdleConnections()
	if normalM1QALoginRuntime != nil || normalM1QALoginSelection != nil {
		t.Fatal("QA authority manufactured")
	}
}

func TestM1QAStartupConfigRequiresIndependentPin(t *testing.T) {
	m1qaStartupTestReset(t)
	file, data, _ := m1qaStartupTestFixture(t)
	lookup := func(name string) (string, bool) {
		if name == socialM1QAStartupConfigEnvironment {
			return file, true
		}
		if strings.Contains(name, "DIGEST") {
			return m1qaStartupTestPin(data), true
		}
		return "", false
	}
	if selection, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), lookup); !enabled || selection != nil || !errors.Is(err, errSocialM1QAStartupUnadmitted) {
		t.Fatal("ENV or file self-admitted a release pin")
	}
}

func TestM1QAStartupConfigUsesExactOriginalBytes(t *testing.T) {
	m1qaStartupTestReset(t)
	file, data, _ := m1qaStartupTestFixture(t)
	socialM1QAAdmittedStartupDigest = m1qaStartupTestPin(data)
	if err := os.WriteFile(file, append(data, '\n'), 0600); err != nil {
		t.Fatal(err)
	}
	if selection, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); selection != nil || !errors.Is(err, errSocialM1QAStartupPin) {
		t.Fatal("semantically equal but unpinned original bytes accepted")
	}
}

func TestM1QAStartupConfigLoadsMetadataWithoutGrant(t *testing.T) {
	m1qaStartupTestReset(t)
	file, data, fields := m1qaStartupTestFixture(t)
	socialM1QAAdmittedStartupDigest = m1qaStartupTestPin(data)
	selection, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil || !enabled || selection == nil {
		t.Fatalf("metadata loading failed: %v", err)
	}
	if selection.profile.RootPath != fields["rootPath"] || selection.profile.RootDigest != fields["rootDigest"] || selection.profile.Now == nil || selection.runtime.Store.Directory != fields["loginStateDirectory"] {
		t.Fatal("existing constructor inputs not preserved")
	}
	if selection.firstDevice != nil || selection.operation != nil || selection.nativeHost != nil {
		t.Fatal("metadata created a private owner")
	}
	if normalM1QALoginRuntime != nil {
		t.Fatal("metadata opened a runtime")
	}
	for _, name := range []string{"must-not-open-private-key", "m1qa-login-v1", "m1qa-login-seal.key"} {
		if _, err := os.Stat(filepath.Join(filepath.Dir(file), name)); !os.IsNotExist(err) {
			t.Fatal("metadata provisioned secret or state")
		}
	}
}

func TestM1QAStartupConfigNormalCallerReachesOriginalVerifier(t *testing.T) {
	m1qaStartupTestReset(t)
	file, data, _ := m1qaStartupTestFixture(t)
	socialM1QAAdmittedStartupDigest = m1qaStartupTestPin(data)
	h, err := openNormalSocialProduct(context.Background(), nil, m1qaStartupTestLookup(file))
	if h != nil || err == nil || normalM1QALoginSelection == nil {
		t.Fatal("normal loader was not called or unissued profile mounted")
	}
	if errors.Is(err, errSocialM1QAStartupConfiguration) || errors.Is(err, errSocialM1QAStartupPin) || errors.Is(err, errSocialM1QAStartupUnadmitted) {
		t.Fatalf("did not reach the original profile verifier: %v", err)
	}
	if normalM1QALoginRuntime != nil || normalSocialLoginRuntime != nil {
		t.Fatal("unissued source opened provider or fallback")
	}
	selected := normalM1QALoginSelection
	if _, err := openNormalSocialProduct(context.Background(), nil, m1qaStartupTestLookup(file)); !errors.Is(err, errSocialM1QAStartupAmbiguous) || normalM1QALoginSelection != selected {
		t.Fatal("repeated normal startup replaced original selection")
	}
}

func TestM1QAStartupConfigRejectsPrivateSupplierAmbiguity(t *testing.T) {
	m1qaStartupTestReset(t)
	selected := &socialM1QALoginStartupSelection{}
	normalM1QALoginSelection = selected
	if h, err := openNormalSocialProduct(context.Background(), nil, m1qaStartupTestLookup("/must-not-read")); h != nil || !errors.Is(err, errSocialM1QAStartupAmbiguous) || normalM1QALoginSelection != selected {
		t.Fatal("locator replaced an independently supplied private selection")
	}
	normalM1QALoginSelection = nil
	if h, err := openNormalSocialProduct(context.Background(), nil, m1qaStartupTestLookup("/must-not-read"), nil); h != nil || !errors.Is(err, errSocialM1QAStartupAmbiguous) {
		t.Fatal("multiple service suppliers accepted")
	}
}

func TestM1QAStartupConfigRejectsUnsafeInput(t *testing.T) {
	for _, kind := range []string{"readable-by-others", "symlink", "oversize", "missing-file", "relative-path"} {
		t.Run(kind, func(t *testing.T) {
			m1qaStartupTestReset(t)
			file, data, _ := m1qaStartupTestFixture(t)
			socialM1QAAdmittedStartupDigest = m1qaStartupTestPin(data)
			switch kind {
			case "readable-by-others":
				if err := os.Chmod(file, 0644); err != nil {
					t.Fatal(err)
				}
			case "symlink":
				target := file
				file += ".link"
				if err := os.Symlink(target, file); err != nil {
					t.Fatal(err)
				}
			case "oversize":
				if err := os.WriteFile(file, bytesOfSpacesForM1QAStartup(8193), 0600); err != nil {
					t.Fatal(err)
				}
			case "missing-file":
				file += ".absent"
			case "relative-path":
				file = "startup.json"
			}
			if selected, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); selected != nil || !errors.Is(err, errSocialM1QAStartupConfiguration) {
				t.Fatal("unsafe startup file accepted")
			}
		})
	}
}

func bytesOfSpacesForM1QAStartup(n int) []byte { return []byte(strings.Repeat(" ", n)) }

func TestM1QAStartupConfigRejectsAmbiguousMetadata(t *testing.T) {
	for _, kind := range []string{"duplicate", "unknown", "trailing", "nested", "zero-size", "oversize-profile", "wrong-namespace", "missing-field", "upper-digest", "json-owner"} {
		t.Run(kind, func(t *testing.T) {
			m1qaStartupTestReset(t)
			file, data, fields := m1qaStartupTestFixture(t)
			switch kind {
			case "duplicate":
				data = append(data[:len(data)-1], []byte(",\"rootBytes\":1}")...)
			case "unknown":
				fields["approved"] = true
			case "trailing":
				data = append(data, []byte(" {}")...)
			case "nested":
				fields["rootPath"] = map[string]string{"value": "/not-a-path"}
			case "zero-size":
				fields["rootBytes"] = 0
			case "oversize-profile":
				fields["profileBytes"] = 16385
			case "wrong-namespace":
				fields["loginStateDirectory"] = filepath.Join(filepath.Dir(file), "production-login")
			case "missing-field":
				delete(fields, "expectedRegistryDigest")
			case "upper-digest":
				fields["rootDigest"] = strings.Repeat("A", 64)
			case "json-owner":
				fields["operation"] = map[string]bool{"approved": true}
			}
			if kind != "duplicate" && kind != "trailing" {
				var err error
				data, err = json.Marshal(fields)
				if err != nil {
					t.Fatal(err)
				}
			}
			if err := os.WriteFile(file, data, 0600); err != nil {
				t.Fatal(err)
			}
			socialM1QAAdmittedStartupDigest = m1qaStartupTestPin(data)
			if selected, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); selected != nil || !errors.Is(err, errSocialM1QAStartupConfiguration) {
				t.Fatal("malformed metadata accepted")
			}
		})
	}
}

func TestM1QAStartupConfigFailureDoesNotFallBackToProduction(t *testing.T) {
	m1qaStartupTestReset(t)
	productionRead := false
	lookup := func(name string) (string, bool) {
		if name == socialM1QAStartupConfigEnvironment {
			return "/not-admitted.json", true
		}
		productionRead = true
		return "", false
	}
	if h, err := openNormalSocialProduct(context.Background(), nil, lookup); h != nil || !errors.Is(err, errSocialM1QAStartupUnadmitted) || productionRead || normalSocialLoginRuntime != nil {
		t.Fatal("explicit unadmitted QA configuration fell through to production")
	}
}

func TestM1QAStartupConfigCancelledBeforeRead(t *testing.T) {
	m1qaStartupTestReset(t)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, _, err := loadSocialM1QALoginStartupSelection(ctx, func(string) (string, bool) { t.Fatal("cancelled startup accessed configuration"); return "", false }); !errors.Is(err, context.Canceled) {
		t.Fatal("cancelled startup continued")
	}
}

func m1qaOperationMetadataFixture(t *testing.T) (string, map[string]any) {
	t.Helper()
	file, _, fields := m1qaStartupTestFixture(t)
	dir := filepath.Dir(file)
	fields["operationRootPath"] = filepath.Join(dir, "unissued-operation-root.json")
	fields["operationRootDigest"] = strings.Repeat("b", 64)
	fields["operationRootBytes"] = 1
	fields["operationCertificatePath"] = filepath.Join(dir, "unissued-operation-certificate.json")
	fields["operationCertificateDigest"] = strings.Repeat("c", 64)
	fields["operationCertificateBytes"] = 1
	fields["operationNodeConfigPath"] = filepath.Join(dir, "unissued-full-node-config.json")
	fields["operationNodeConfigDigest"] = strings.Repeat("d", 64)
	fields["operationNodeConfigBytes"] = 1
	fields["operationKeyId"] = "PUBLIC_UNADMITTED_NEW_PURPOSE"
	public := make([]byte, 32)
	public[0] = 1
	fields["operationPublicKey"] = base64.RawURLEncoding.EncodeToString(public)
	fields["operationPrivateKeyFile"] = filepath.Join(dir, "must-not-open-operation-private-key")
	return file, fields
}

func m1qaOperationWriteMetadata(t *testing.T, file string, fields map[string]any) []byte {
	t.Helper()
	data, err := json.Marshal(fields)
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(file, data, 0600); err != nil {
		t.Fatal(err)
	}
	socialM1QAAdmittedStartupDigest = m1qaStartupTestPin(data)
	return data
}

func TestM1QAOperationMetadataCompleteReferencesAreNotAuthority(t *testing.T) {
	m1qaStartupTestReset(t)
	file, fields := m1qaOperationMetadataFixture(t)
	m1qaOperationWriteMetadata(t, file, fields)
	s, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil || !enabled || s == nil || s.provisioning == nil {
		t.Fatalf("metadata selection: %v", err)
	}
	if s.operation != nil || s.nativeHost != nil || s.firstDevice != nil {
		t.Fatal("public references manufactured authority")
	}
	if s.provisioning.owner.ExpectedNodeConfigDigest != fields["operationNodeConfigDigest"] || s.provisioning.owner.Now == nil {
		t.Fatal("original independent full Node configuration pin or clock lost")
	}
	h, err := openNormalSocialProduct(context.Background(), nil, m1qaStartupTestLookup(file))
	if err == nil || h != nil {
		t.Fatal("normal caller accepted unsigned missing profile")
	}
	if normalM1QALoginRuntime != nil || normalSocialLoginRuntime != nil {
		t.Fatal("missing original profile created a runtime")
	}
}

func TestM1QAOperationMetadataRejectsPartialGroup(t *testing.T) {
	m1qaStartupTestReset(t)
	_, all := m1qaOperationMetadataFixture(t)
	for key := range all {
		if !strings.HasPrefix(key, "operation") {
			continue
		}
		t.Run(key, func(t *testing.T) {
			fields := make(map[string]any, len(all))
			for k, v := range all {
				if k != key {
					fields[k] = v
				}
			}
			data, err := json.Marshal(fields)
			if err != nil {
				t.Fatal(err)
			}
			if _, err = decodeSocialM1QAStartupMetadata(data); !errors.Is(err, errSocialM1QAStartupConfiguration) {
				t.Fatal("partial group accepted")
			}
		})
	}
}

func TestM1QAOperationMetadataRejectsAliasesAndInvalidPins(t *testing.T) {
	m1qaStartupTestReset(t)
	cases := []struct {
		name, key string
		value     any
	}{
		{"login-key-id", "operationKeyId", "PUBLIC_TEST_ONLY_UNADMITTED"},
		{"login-public", "operationPublicKey", base64.RawURLEncoding.EncodeToString(make([]byte, 32))},
		{"bad-key-id", "operationKeyId", "bad id"},
		{"padded-public", "operationPublicKey", base64.URLEncoding.EncodeToString(make([]byte, 32))},
		{"bad-digest", "operationNodeConfigDigest", strings.Repeat("D", 64)},
		{"zero-size", "operationRootBytes", 0},
		{"oversized", "operationNodeConfigBytes", 16385},
		{"wrong-type", "operationRootBytes", "1"},
		{"nil-path", "operationPrivateKeyFile", nil},
		{"relative-path", "operationPrivateKeyFile", "relative.pk8"},
		{"root-alias", "operationRootPath", "@rootPath"},
		{"seal-alias", "operationPrivateKeyFile", "@loginSealKeyFile"},
		{"store-alias", "operationPrivateKeyFile", "@loginStateDirectory"},
		{"signer-config-alias", "operationPrivateKeyFile", "@loginSignerConfigFile"},
		{"key-file-alias", "operationPrivateKeyFile", "@loginPrivate"},
		{"certificate-alias", "operationNodeConfigPath", "@operationCertificatePath"},
		{"approval-flag", "approved", true},
		{"native-owner", "nativeSource", map[string]any{"approved": true}},
		{"binary-self-pin", "sameServiceBinaryDigest", strings.Repeat("e", 64)},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			file, fields := m1qaOperationMetadataFixture(t)
			value := tc.value
			if s, ok := value.(string); ok && strings.HasPrefix(s, "@") {
				if s == "@loginPrivate" {
					value = filepath.Join(filepath.Dir(file), "must-not-open-private-key")
				} else {
					value = fields[s[1:]]
				}
			}
			fields[tc.key] = value
			m1qaOperationWriteMetadata(t, file, fields)
			s, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
			if !enabled || s != nil || !errors.Is(err, errSocialM1QAStartupConfiguration) {
				t.Fatalf("invalid operation metadata accepted: %v", err)
			}
		})
	}
}

func TestM1QAOperationMetadataOptionalGroupPreservesLoginOnly(t *testing.T) {
	m1qaStartupTestReset(t)
	file, data, _ := m1qaStartupTestFixture(t)
	socialM1QAAdmittedStartupDigest = m1qaStartupTestPin(data)
	s, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil || !enabled || s == nil || s.provisioning != nil || s.operation != nil || s.firstDevice != nil || s.nativeHost != nil {
		t.Fatalf("metadata-only login path changed: %v", err)
	}
}

func TestM1QAOperationMetadataDuplicateAndTrailingRejected(t *testing.T) {
	m1qaStartupTestReset(t)
	file, fields := m1qaOperationMetadataFixture(t)
	data := m1qaOperationWriteMetadata(t, file, fields)
	for _, raw := range [][]byte{
		append(append([]byte{}, data[:len(data)-1]...), []byte(",\"operationKeyId\":\"duplicate\"}")...),
		append(append([]byte{}, data...), []byte("{}")...),
	} {
		if _, err := decodeSocialM1QAStartupMetadata(raw); !errors.Is(err, errSocialM1QAStartupConfiguration) {
			t.Fatal("non-unique metadata accepted")
		}
	}
}

func TestM1QANativeStartupCompleteReferencesRemainConstructorInputs(t *testing.T) {
	m1qaStartupTestReset(t)
	file, fields, postFile, post := m1qaNativeSelectionFixture(t)
	m1qaNativeWritePost(t, postFile, post)
	m1qaOperationWriteMetadata(t, file, fields)
	s, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil || !enabled || s == nil || s.nativeHost == nil || s.firstDevice == nil {
		t.Fatalf("normal selection: %v", err)
	}
	n := s.nativeHost
	if s.operation != nil || s.provisioning == nil || n.parentRead != nil || n.parentWrite != nil || n.source.ExpectedServiceBinaryDigest != "" || n.source.Now == nil {
		t.Fatal("metadata manufactured an owner, pipe or self-binary digest")
	}
	if s.firstDevice.mode != "authority-v3" || !m1QAFirstDevicePaths(s.runtime, *s.firstDevice) || n.source.RootDigest != fields["nativeRootDigest"] || n.source.ExpectedTLSSPKIDigest != fields["nativeTLSSPKIDigest"] || n.source.ExpectedProfileDigest != fields["profileDigest"] || n.source.ExpectedCentralRegistryDigest != fields["expectedRegistryDigest"] || n.source.ExpectedOperationRegistrationDigest != fields["operationNodeConfigDigest"] || n.source.ExpectedCertificateDigest != fields["expectedCertificateDigest"] || n.source.ExpectedCallbackManifestDigest != fields["expectedCallbackManifestDigest"] {
		t.Fatal("original independently selected identity/storage binding lost")
	}
	h, err := openNormalSocialProduct(context.Background(), nil, m1qaStartupTestLookup(file))
	if err == nil || h != nil || normalM1QALoginRuntime != nil {
		t.Fatal("unsigned missing profile authorized a runtime or first device")
	}
}

func TestM1QANativeStartupAllOrNoneAndOperationRequired(t *testing.T) {
	m1qaStartupTestReset(t)
	_, fields, _, _ := m1qaNativeSelectionFixture(t)
	for key := range fields {
		if !strings.HasPrefix(key, "native") && !strings.HasPrefix(key, "firstDevice") {
			continue
		}
		t.Run(key, func(t *testing.T) {
			copy := make(map[string]any)
			for k, v := range fields {
				if k != key {
					copy[k] = v
				}
			}
			data, err := json.Marshal(copy)
			if err != nil {
				t.Fatal(err)
			}
			if _, err = decodeSocialM1QAStartupMetadata(data); err == nil {
				t.Fatal("partial native/storage group accepted")
			}
		})
	}
	withoutOperation := make(map[string]any)
	for k, v := range fields {
		if !strings.HasPrefix(k, "operation") {
			withoutOperation[k] = v
		}
	}
	data, err := json.Marshal(withoutOperation)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = decodeSocialM1QAStartupMetadata(data); err == nil {
		t.Fatal("native path without NEW-purpose selection accepted")
	}
}

func TestM1QANativeStartupAbsentPreservesOperationOnly(t *testing.T) {
	m1qaStartupTestReset(t)
	file, fields := m1qaOperationMetadataFixture(t)
	m1qaOperationWriteMetadata(t, file, fields)
	s, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil || !enabled || s == nil || s.provisioning == nil || s.nativeHost != nil || s.firstDevice != nil || s.runtime.ChallengeDirectory != "" {
		t.Fatalf("absent native group changed existing mode: %v", err)
	}
}

func TestM1QANativeStartupPostBuildBytesDoNotEnterBinaryPin(t *testing.T) {
	m1qaStartupTestReset(t)
	file, fields, postFile, post := m1qaNativeSelectionFixture(t)
	m1qaNativeWritePost(t, postFile, post)
	m1qaOperationWriteMetadata(t, file, fields)
	pin := socialM1QAAdmittedStartupDigest
	first, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil {
		t.Fatal(err)
	}
	post["registrationDigest"] = strings.Repeat("8", 64)
	m1qaNativeWritePost(t, postFile, post)
	second, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil {
		t.Fatal(err)
	}
	if socialM1QAAdmittedStartupDigest != pin || first.nativeHost.source.RegistrationDigest == second.nativeHost.source.RegistrationDigest || first.nativeHost.source.ExpectedServiceBinaryDigest != "" || second.nativeHost.source.ExpectedServiceBinaryDigest != "" || first.operation != nil || second.operation != nil {
		t.Fatal("post-build reference mutated original selection or created a self-pin/authority")
	}
	// Both values are still unverified public references. Neither is a valid
	// signed registration, current NativeSource or accepted device grant.
}

func TestM1QANativeStartupInvalidIndependentSelectionRejected(t *testing.T) {
	m1qaStartupTestReset(t)
	cases := []struct {
		name, field string
		value       any
	}{
		{"zero-revision", "nativeMinimumRegistrationRevision", 0},
		{"fractional-sequence", "nativeMinimumStatusSequence", 1.5},
		{"unsafe-sequence", "nativeMinimumStatusSequence", int64(9007199254740992)},
		{"wrong-floor-type", "nativeMinimumStatusSequence", "1"},
		{"bad-root-size", "nativeRootBytes", 16385},
		{"bad-root-digest", "nativeRootDigest", strings.Repeat("G", 64)},
		{"bad-tls-digest", "nativeTLSSPKIDigest", ""},
		{"blank-realm", "firstDeviceRealm", " "},
		{"newline-realm", "firstDeviceRealm", "qa\n"},
		{"wrong-challenge", "firstDeviceChallengeDirectory", "@other-path"},
		{"wrong-authority", "firstDeviceAuthorityFile", "@other-path"},
		{"shared-root", "nativeRootPath", "@operationRootPath"},
		{"host-seal", "nativeHostKeyFile", "@loginSealKeyFile"},
		{"host-login", "nativeHostKeyFile", "@loginPrivate"},
		{"host-operation", "nativeHostKeyFile", "@operationPrivateKeyFile"},
		{"metadata-host", "nativeSelectionFile", "@nativeHostKeyFile"},
		{"metadata-login", "nativeSelectionFile", "@loginPrivate"},
		{"metadata-seal", "nativeSelectionFile", "@loginSealKeyFile"},
		{"self-digest", "nativeServiceBinaryDigest", strings.Repeat("f", 64)},
		{"post-build-pin", "nativeSelectionDigest", strings.Repeat("f", 64)},
		{"native-pointer", "nativeSource", "public-value-is-not-an-owner"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			file, fields, postFile, post := m1qaNativeSelectionFixture(t)
			m1qaNativeWritePost(t, postFile, post)
			value := tc.value
			if s, ok := value.(string); ok && strings.HasPrefix(s, "@") {
				switch s {
				case "@loginPrivate":
					value = filepath.Join(filepath.Dir(file), "must-not-open-private-key")
				case "@other-path":
					value = filepath.Join(filepath.Dir(file), "other-path")
				default:
					value = fields[s[1:]]
				}
			}
			fields[tc.field] = value
			m1qaOperationWriteMetadata(t, file, fields)
			if s, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); !enabled || s != nil || !errors.Is(err, errSocialM1QAStartupConfiguration) {
				t.Fatalf("invalid selected native path accepted: %v", err)
			}
		})
	}
}

func m1qaStartupTestSelectFirstDevice(file string, fields map[string]any) {
	dir := filepath.Dir(file)
	fields["firstDeviceMode"] = "authority-v3"
	fields["firstDeviceRealm"] = "PUBLIC-QA-REALM"
	fields["firstDeviceAuthorityFile"] = filepath.Join(dir, "m1qa-first-enrollment-v3.log")
	fields["firstDeviceChallengeDirectory"] = filepath.Join(dir, "m1qa-first-device-v1")
}

func m1qaStartupTestWriteSelection(t *testing.T, file string, fields map[string]any) []byte {
	t.Helper()
	data, err := json.Marshal(fields)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(file, data, 0600); err != nil {
		t.Fatal(err)
	}
	socialM1QAAdmittedStartupDigest = m1qaStartupTestPin(data)
	return data
}

func TestM1QAStartupConfigSelectsExistingFirstDeviceStorageWithoutAuthority(t *testing.T) {
	m1qaStartupTestReset(t)
	file, _, fields := m1qaStartupTestFixture(t)
	m1qaStartupTestSelectFirstDevice(file, fields)
	m1qaStartupTestWriteSelection(t, file, fields)
	selection, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil || !enabled || selection == nil || selection.firstDevice == nil {
		t.Fatalf("complete QA storage selection not wired: %v", err)
	}
	if selection.firstDevice.mode != "authority-v3" || selection.firstDevice.realm != fields["firstDeviceRealm"] || selection.firstDevice.path != fields["firstDeviceAuthorityFile"] || selection.runtime.ChallengeDirectory != fields["firstDeviceChallengeDirectory"] || !m1QAFirstDevicePaths(selection.runtime, *selection.firstDevice) {
		t.Fatal("normal first-device storage constructor inputs changed")
	}
	if selection.operation != nil || selection.nativeHost != nil || normalM1QALoginRuntime != nil {
		t.Fatal("storage metadata created authority or opened runtime")
	}
	// Exercise the existing real mount, not a test authorization bypass. With
	// no source/account-operation owner it must refuse BEFORE opening storage.
	runtime := &socialLoginRuntime{}
	if h, err := runtime.mountM1QAFirstDevice(context.Background(), nil, nil, selection); h != nil || !errors.Is(err, kernel.ErrFirstAuthorizationUnavailable) || runtime.challenges != nil || runtime.authority != nil {
		t.Fatalf("storage configuration bypassed actual authority: %v", err)
	}
	for _, name := range []string{"must-not-open-private-key", "m1qa-login-v1", "m1qa-login-seal.key", "m1qa-first-device-v1", "m1qa-first-enrollment-v3.log"} {
		if _, err := os.Stat(filepath.Join(filepath.Dir(file), name)); !os.IsNotExist(err) {
			t.Fatal("metadata or missing-authority mount created private state")
		}
	}
}

func TestM1QAStartupConfigFirstDeviceStillUsesNormalSignedProfileVerifier(t *testing.T) {
	m1qaStartupTestReset(t)
	file, _, fields := m1qaStartupTestFixture(t)
	m1qaStartupTestSelectFirstDevice(file, fields)
	m1qaStartupTestWriteSelection(t, file, fields)
	h, err := openNormalSocialProduct(context.Background(), nil, m1qaStartupTestLookup(file))
	if h != nil || err == nil || normalM1QALoginSelection == nil || normalM1QALoginSelection.firstDevice == nil {
		t.Fatal("normal startup bypassed verification or discarded storage selection")
	}
	if errors.Is(err, errSocialM1QAStartupConfiguration) || errors.Is(err, errSocialM1QAStartupPin) || errors.Is(err, errSocialM1QAStartupUnadmitted) {
		t.Fatalf("normal request did not reach the original signed-profile verifier: %v", err)
	}
	if normalM1QALoginRuntime != nil || normalSocialLoginRuntime != nil {
		t.Fatal("unissued profile opened a runtime or production fallback")
	}
}

func TestM1QAStartupConfigRejectsPartialOrUnsafeFirstDeviceSelection(t *testing.T) {
	cases := []string{"missing-mode", "missing-realm", "missing-authority", "missing-challenge", "empty-mode", "challenge-only", "empty-realm", "spaced-realm", "newline-realm", "relative-challenge", "wrong-challenge-namespace", "wrong-authority-namespace", "outside-challenge-parent", "outside-authority-parent", "aliased-root", "aliased-seal", "json-owner", "non-string-mode"}
	for _, kind := range cases {
		t.Run(kind, func(t *testing.T) {
			m1qaStartupTestReset(t)
			file, _, fields := m1qaStartupTestFixture(t)
			m1qaStartupTestSelectFirstDevice(file, fields)
			switch kind {
			case "missing-mode":
				delete(fields, "firstDeviceMode")
			case "missing-realm":
				delete(fields, "firstDeviceRealm")
			case "missing-authority":
				delete(fields, "firstDeviceAuthorityFile")
			case "missing-challenge":
				delete(fields, "firstDeviceChallengeDirectory")
			case "empty-mode":
				fields["firstDeviceMode"] = ""
			case "challenge-only":
				fields["firstDeviceMode"] = "challenge-only"
			case "empty-realm":
				fields["firstDeviceRealm"] = ""
			case "spaced-realm":
				fields["firstDeviceRealm"] = " PUBLIC-QA-REALM"
			case "newline-realm":
				fields["firstDeviceRealm"] = "PUBLIC\nQA"
			case "relative-challenge":
				fields["firstDeviceChallengeDirectory"] = "m1qa-first-device-v1"
			case "wrong-challenge-namespace":
				fields["firstDeviceChallengeDirectory"] = filepath.Join(filepath.Dir(file), "production-first-device")
			case "wrong-authority-namespace":
				fields["firstDeviceAuthorityFile"] = filepath.Join(filepath.Dir(file), "production-first-enrollment.log")
			case "outside-challenge-parent":
				fields["firstDeviceChallengeDirectory"] = filepath.Join(filepath.Dir(file), "other", "m1qa-first-device-v1")
			case "outside-authority-parent":
				fields["firstDeviceAuthorityFile"] = filepath.Join(filepath.Dir(file), "other", "m1qa-first-enrollment-v3.log")
			case "aliased-root":
				fields["firstDeviceAuthorityFile"] = fields["rootPath"]
			case "aliased-seal":
				fields["firstDeviceChallengeDirectory"] = fields["loginSealKeyFile"]
			case "json-owner":
				fields["operation"] = map[string]bool{"approved": true}
			case "non-string-mode":
				fields["firstDeviceMode"] = true
			}
			m1qaStartupTestWriteSelection(t, file, fields)
			if selection, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); selection != nil || !errors.Is(err, errSocialM1QAStartupConfiguration) {
				t.Fatalf("unsafe or partial storage selection accepted: %v", err)
			}
			if normalM1QALoginRuntime != nil || normalSocialLoginRuntime != nil {
				t.Fatal("invalid storage selection opened a runtime")
			}
		})
	}
}

func TestM1QAStartupConfigFirstDeviceFieldsRequireSameIndependentPin(t *testing.T) {
	m1qaStartupTestReset(t)
	file, _, fields := m1qaStartupTestFixture(t)
	m1qaStartupTestSelectFirstDevice(file, fields)
	original := m1qaStartupTestWriteSelection(t, file, fields)
	fields["firstDeviceRealm"] = "PUBLIC-ALTERED-REALM"
	m1qaStartupTestWriteSelection(t, file, fields)
	socialM1QAAdmittedStartupDigest = m1qaStartupTestPin(original)
	if selection, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); selection != nil || !errors.Is(err, errSocialM1QAStartupPin) {
		t.Fatal("changed first-device selection used the original release pin")
	}
}

func TestM1QAStartupConfigFirstDeviceCannotAliasSignerPrivateKey(t *testing.T) {
	for _, field := range []string{"firstDeviceAuthorityFile", "firstDeviceChallengeDirectory"} {
		t.Run(field, func(t *testing.T) {
			m1qaStartupTestReset(t)
			file, _, fields := m1qaStartupTestFixture(t)
			m1qaStartupTestSelectFirstDevice(file, fields)
			// This is public signer metadata, not an actual private-key file.
			metadata := map[string]string{"schema": "ynx-social-backend-signer/v1", "profile": "protected-backend-software-pkcs8-v1", "keyId": "PUBLIC_TEST_ONLY_UNADMITTED", "publicKey": base64.RawURLEncoding.EncodeToString(make([]byte, 32)), "privateKeyFile": fields[field].(string)}
			data, err := json.Marshal(metadata)
			if err != nil {
				t.Fatal(err)
			}
			if err := os.WriteFile(fields["loginSignerConfigFile"].(string), data, 0600); err != nil {
				t.Fatal(err)
			}
			m1qaStartupTestWriteSelection(t, file, fields)
			if selection, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); selection != nil || !errors.Is(err, errSocialM1QAStartupConfiguration) {
				t.Fatal("first-device storage aliased the signer key")
			}
		})
	}
}

func TestM1QAMergedStartupPreservesNativeWithExplicitStorageMode(t *testing.T) {
	m1qaStartupTestReset(t)
	file, fields, postFile, post := m1qaNativeSelectionFixture(t)
	fields["firstDeviceMode"] = "authority-v3"
	m1qaNativeWritePost(t, postFile, post)
	m1qaOperationWriteMetadata(t, file, fields)
	s, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil || !enabled || s == nil || s.nativeHost == nil || s.firstDevice == nil || s.provisioning == nil {
		t.Fatalf("merged normal native selection lost: %v", err)
	}
	if s.operation != nil || s.nativeHost.parentRead != nil || s.nativeHost.parentWrite != nil ||
		s.firstDevice.mode != "authority-v3" || s.firstDevice.realm != fields["firstDeviceRealm"] ||
		s.nativeHost.source.ExpectedOperationRegistrationDigest != fields["operationNodeConfigDigest"] {
		t.Fatal("native inputs lost or metadata created authority")
	}
}
func TestM1QAMergedStartupRejectsImplicitStandaloneOrPartialNative(t *testing.T) {
	for _, kind := range []string{"missing-mode", "challenge-only", "partial-native"} {
		t.Run(kind, func(t *testing.T) {
			m1qaStartupTestReset(t)
			file, fields := m1qaOperationMetadataFixture(t)
			m1qaStartupTestSelectFirstDevice(file, fields)
			switch kind {
			case "missing-mode":
				delete(fields, "firstDeviceMode")
			case "challenge-only":
				fields["firstDeviceMode"] = "challenge-only"
			case "partial-native":
				fields["nativeRootPath"] = filepath.Join(filepath.Dir(file), "unissued-native-root.json")
			}
			m1qaOperationWriteMetadata(t, file, fields)
			if selected, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); selected != nil || !errors.Is(err, errSocialM1QAStartupConfiguration) {
				t.Fatalf("partial selection silently downgraded: %v", err)
			}
		})
	}
}
func TestM1QAMergedStartupOperationAndStorageReferencesRemainIndependent(t *testing.T) {
	m1qaStartupTestReset(t)
	file, fields := m1qaOperationMetadataFixture(t)
	m1qaStartupTestSelectFirstDevice(file, fields)
	m1qaOperationWriteMetadata(t, file, fields)
	s, enabled, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil || !enabled || s == nil || s.provisioning == nil || s.firstDevice == nil || s.nativeHost != nil || s.operation != nil {
		t.Fatalf("complete independent references lost or authority fabricated: %v", err)
	}
	fields["operationPrivateKeyFile"] = fields["firstDeviceAuthorityFile"]
	m1qaOperationWriteMetadata(t, file, fields)
	if selected, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file)); selected != nil || !errors.Is(err, errSocialM1QAStartupConfiguration) {
		t.Fatal("operation signer aliases first-device storage")
	}
}
