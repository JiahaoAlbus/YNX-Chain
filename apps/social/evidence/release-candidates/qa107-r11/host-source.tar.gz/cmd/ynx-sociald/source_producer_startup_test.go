package main

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"testing"
)

func TestSourceProducerStartupExplicitSelection(t *testing.T){
	missing:=func(string)(string,bool){return "",false}
	if c,e:=loadSourceProducerStartup(missing,firstEnrollmentStartup{});e!=nil||c!=nil{t.Fatal("implicit producer")}
	path:=filepath.Join(t.TempDir(),"public.json")
	lookup:=func(string)(string,bool){return path,true}
	if _,e:=loadSourceProducerStartup(lookup,firstEnrollmentStartup{});e==nil{t.Fatal("old path allowed")}
	if _,e:=os.Stat(path);!os.IsNotExist(e){t.Fatal("selection created file")}
	if e:=(&socialLoginRuntime{}).prepareSourceProducer(context.Background(),&sourceProducerStartup{Version:1,ExistingJournal:filepath.Join(t.TempDir(),"absent")});e==nil{t.Fatal("missing authority accepted")}
}

func TestSourceProducerStartupPublicConfig(t *testing.T){
	dir:=t.TempDir();path:=filepath.Join(dir,"config");journal:=filepath.Join(dir,"original-journal")
	if e:=os.Chmod(dir,0700);e!=nil{t.Fatal(e)}
	body:=`{"version":1,"requestURI":"/v4/source-authority/current-history?nonce=PUBLIC","existingJournal":"`+journal+`"}`
	if e:=os.WriteFile(path,[]byte(body),0600);e!=nil{t.Fatal(e)}
	lookup:=func(string)(string,bool){return path,true}
	c,e:=loadSourceProducerStartup(lookup,firstEnrollmentStartup{mode:"authority-v3",path:filepath.Join(dir,"directory")});if e!=nil||c.ExistingJournal!=journal{t.Fatal(e)}
	if _,e:=os.Stat(journal);!os.IsNotExist(e){t.Fatal("configuration opened journal")}
	if e:=os.WriteFile(path,make([]byte,4097),0600);e!=nil{t.Fatal(e)}
	if _,e:=loadSourceProducerStartup(lookup,firstEnrollmentStartup{mode:"authority-v3"});e==nil{t.Fatal("oversize accepted")}
}

func TestSourceProducerStartupRejectsAmbiguousMetadata(t *testing.T){
	dir:=t.TempDir();path:=filepath.Join(dir,"config");journal:=filepath.Join(dir,"journal")
	if err:=os.Chmod(dir,0700);err!=nil{t.Fatal(err)}
	lookup:=func(string)(string,bool){return path,true}
	selection:=firstEnrollmentStartup{mode:"authority-v3",path:filepath.Join(dir,"directory")}
	valid:=`{"version":1,"requestURI":"/v4/source-authority/current-history?nonce=PUBLIC","existingJournal":"`+journal+`"}`
	for _,body:=range []string{
		`{"version":0,"version":1,"requestURI":"/v4/source-authority/current-history","existingJournal":"`+journal+`"}`,
		`{"version":1,"requestURI":"/wrong","requestURI":"/v4/source-authority/current-history","existingJournal":"`+journal+`"}`,
		`{"version":1,"requestURI":"/v4/source-authority/current-history","existingJournal":"/wrong","existingJournal":"`+journal+`"}`,
		`{"version":1,"requestURI":"/v4/source-authority/current-history","existingJournal":null}`,
		valid+` {}`,
	}{
		if err:=os.WriteFile(path,[]byte(body),0600);err!=nil{t.Fatal(err)}
		if c,err:=loadSourceProducerStartup(lookup,selection);err==nil||c!=nil{t.Fatal("ambiguous metadata accepted")}
	}
	if err:=os.WriteFile(path,[]byte(valid),0600);err!=nil{t.Fatal(err)}
	if c,err:=loadSourceProducerStartup(lookup,selection);err!=nil||c==nil{t.Fatal("valid metadata rejected",err)}
	if _,err:=os.Stat(journal);!os.IsNotExist(err){t.Fatal("metadata created journal")}
	link:=filepath.Join(dir,"link");if err:=os.Symlink(path,link);err!=nil{t.Fatal(err)}
	if c,err:=loadSourceProducerStartup(func(string)(string,bool){return link,true},selection);err==nil||c!=nil{t.Fatal("symlink config accepted")}
	if err:=os.Chmod(dir,0755);err!=nil{t.Fatal(err)}
	if c,err:=loadSourceProducerStartup(lookup,selection);err==nil||c!=nil{t.Fatal("public parent config accepted")}
}

type sourceProducerCloseControl struct{calls int;failure error;order *[]string;name string}
func(c *sourceProducerCloseControl)Close()error{c.calls++;*c.order=append(*c.order,c.name);return c.failure}
func TestSourceProducerStartupCloseCustody(t *testing.T){
	var order []string;cause:=errors.New("PUBLIC producer uncertain")
	p:=&sourceProducerCloseControl{failure:cause,order:&order,name:"producer"};a:=&sourceProducerCloseControl{order:&order,name:"authority"}
	r:=&socialLoginRuntime{releases:socialRuntimeReleases{producer:p,authority:a}}
	if !errors.Is(r.Close(context.Background()),cause)||!errors.Is(r.Close(context.Background()),cause)||p.calls!=1||a.calls!=0{t.Fatal("uncertain producer released authority")}
	order=nil;p=&sourceProducerCloseControl{order:&order,name:"producer"};a=&sourceProducerCloseControl{order:&order,name:"authority"}
	r=&socialLoginRuntime{releases:socialRuntimeReleases{producer:p,authority:a}}
	if e:=r.Close(context.Background());e!=nil||len(order)!=2||order[0]!="producer"||order[1]!="authority"{t.Fatal("wrong lifetime order",e,order)}
}

func TestDedicatedSealedSourceNormalStartupSelection(t *testing.T){
 dir:=t.TempDir();path:=filepath.Join(dir,"roles.json")
 selection:=firstEnrollmentStartup{mode:"authority-v3",path:filepath.Join(dir,"authority")}
 producer:=&sourceProducerStartup{Version:1,ExistingJournal:filepath.Join(dir,"journal")}
 none:=func(string)(string,bool){return "",false}
 one:=func(k string)(string,bool){if k=="YNX_SOCIAL_SEALED_SOURCE_ROLES_FILE"{return path,true};return "",false}
 if c,e:=loadDedicatedSealedSourceStartup(none,selection,producer,false);e!=nil||c!=nil{t.Fatal("implicit dedicated process")}
 cases:=[]struct{name string;lookup func(string)(string,bool);s firstEnrollmentStartup;p *sourceProducerStartup;dedicated bool}{
  {"ordinary-process",one,selection,producer,false},{"missing-input",none,selection,producer,true},
  {"missing-producer",one,selection,nil,true},{"old-mode",one,firstEnrollmentStartup{},producer,true},
  {"journal-alias",func(string)(string,bool){return producer.ExistingJournal,true},selection,producer,true},
  {"authority-alias",func(string)(string,bool){return selection.path,true},selection,producer,true},
  {"relative",func(string)(string,bool){return "./roles",true},selection,producer,true},
  {"prepare-alias",func(string)(string,bool){return path,true},selection,producer,true},
 }
 for _,c:=range cases{t.Run(c.name,func(t *testing.T){if got,e:=loadDedicatedSealedSourceStartup(c.lookup,c.s,c.p,c.dedicated);e==nil||got!=nil{t.Fatal("incomplete normal composition accepted")}})}
 if c,e:=loadDedicatedSealedSourceStartup(one,selection,producer,true);e!=nil||c==nil||c.path!=path{t.Fatal("explicit path selection rejected",e)}
 if _,e:=os.Stat(path);!os.IsNotExist(e){t.Fatal("composition generated input")}
}
