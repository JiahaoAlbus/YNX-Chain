package main

import (
	"context"
	"errors"
	"io"
	"log"
	"os"
	"os/exec"
	"reflect"
	"sync/atomic"
	"testing"
	"time"

	"github.com/JiahaoAlbus/YNX-Chain/internal/centralbrowserfamily"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

// These are PUBLIC local custody controls, not accepted signed profiles or
// device authorization fixtures. No private key, real signer or network call
// is generated here, and zero-value owners are used only on rejection paths.
type m1qaOperationReleaseFunc func() error

func (f m1qaOperationReleaseFunc) Close() error { return f() }

type m1qaOperationContextReleaseFunc func(context.Context) error

func (f m1qaOperationContextReleaseFunc) Close(ctx context.Context) error { return f(ctx) }

func m1qaOperationPublicSelection(t *testing.T) *socialM1QALoginStartupSelection {
	t.Helper()
	file, fields := m1qaOperationMetadataFixture(t)
	m1qaOperationWriteMetadata(t, file, fields)
	s, _, err := loadSocialM1QALoginStartupSelection(context.Background(), m1qaStartupTestLookup(file))
	if err != nil {
		t.Fatal(err)
	}
	return s
}

func TestM1QAOperationProvisionMissingGenuineProfileCannotAcquireProvider(t *testing.T) {
	m1qaStartupTestReset(t)
	s := m1qaOperationPublicSelection(t)
	r := &socialLoginRuntime{}
	if selected, err := r.provisionM1QAOperation(context.Background(), s.provisioning, s.runtime); selected != nil || !errors.Is(err, kernel.ErrSocialAccountOperationConfiguration) {
		t.Fatal("metadata-only runtime acquired authority")
	}
	if !r.operationProvisionAttempted || r.operationProvider != nil || r.operationOwner != nil || r.accountOperation != nil {
		t.Fatal("attempt was lost or owner fabricated")
	}
	if selected, err := r.provisionM1QAOperation(context.Background(), s.provisioning, s.runtime); selected != nil || !errors.Is(err, kernel.ErrSocialAccountOperationConfiguration) {
		t.Fatal("same acquisition automatically retried")
	}
}

func TestM1QAOperationProvisionCanceledAndClosedCannotAcquire(t *testing.T) {
	m1qaStartupTestReset(t)
	s := m1qaOperationPublicSelection(t)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	r := &socialLoginRuntime{}
	if selected, err := r.provisionM1QAOperation(ctx, s.provisioning, s.runtime); selected != nil || !errors.Is(err, context.Canceled) {
		t.Fatal("canceled acquisition changed")
	}
	if r.operationProvisionAttempted || r.operationProvider != nil {
		t.Fatal("canceled request opened resources")
	}
	if err := r.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
	if selected, err := r.provisionM1QAOperation(context.Background(), s.provisioning, s.runtime); selected != nil || err == nil {
		t.Fatal("closed runtime reopened")
	}
	if selected, err := r.provisionM1QAOperation(nil, s.provisioning, s.runtime); selected != nil || err == nil {
		t.Fatal("nil context accepted")
	}
}

func TestM1QAOperationProvisionAmbiguousSelectionRefusedBeforeAcquisition(t *testing.T) {
	m1qaStartupTestReset(t)
	s := m1qaOperationPublicSelection(t)
	s.operation = &socialM1QAOperationStartupSelection{}
	if r, err := openSelectedM1QALoginRuntime(context.Background(), s); r != nil || !errors.Is(err, errSocialM1QAStartupAmbiguous) {
		t.Fatal("ambiguous constructor selected an owner")
	}
	s.operation, s.provisioning = nil, nil
	s.nativeHost = &socialNativeHostStartupSelection{}
	if r, err := openSelectedM1QALoginRuntime(context.Background(), s); r != nil || !errors.Is(err, errSocialM1QAStartupAmbiguous) {
		t.Fatal("unbound native source selected")
	}
}

func TestM1QAOperationProvisionMetadataCannotShareLoginOrSealIdentity(t *testing.T) {
	m1qaStartupTestReset(t)
	s := m1qaOperationPublicSelection(t)
	if !validSocialM1QAOperationProvisioning(s.provisioning, s.runtime) {
		t.Fatal("valid public references rejected")
	}
	copy := *s.provisioning
	copy.owner.ExpectedNodeConfigDigest = ""
	if validSocialM1QAOperationProvisioning(&copy, s.runtime) {
		t.Fatal("missing independent Node pin accepted")
	}
	copy = *s.provisioning
	copy.owner.Now = nil
	if validSocialM1QAOperationProvisioning(&copy, s.runtime) {
		t.Fatal("missing original clock accepted")
	}
	copy = *s.provisioning
	copy.privateKeyFile = s.runtime.Store.SealKeyFile
	if validSocialM1QAOperationProvisioning(&copy, s.runtime) {
		t.Fatal("seal file reused as operation credential")
	}
}

func TestM1QAOperationCustodyOriginalIdentityRetainedBeforeNativeConstruction(t *testing.T) {
	first, replacement := &centralbrowserfamily.SocialM1QAOperationOwner{}, &centralbrowserfamily.SocialM1QAOperationOwner{}
	r := &socialLoginRuntime{}
	if err := r.retainM1QAOperationOwner(first); err != nil {
		t.Fatal(err)
	}
	if err := r.retainM1QAOperationOwner(first); err != nil {
		t.Fatal("same original custody lost")
	}
	if err := r.retainM1QAOperationOwner(replacement); err == nil {
		t.Fatal("untransferred owner replaced")
	}
	if r.operationOwner != first || r.releases.operationOwner != first || r.operationOwnerTransferred {
		t.Fatal("original pre-native owner not retained")
	}
	// Empty rejection-only owner has no credential or held file resources.
	_ = r.Close(context.Background())
	if err := r.retainM1QAOperationOwner(first); err == nil {
		t.Fatal("closed ownership slot reused")
	}
}

func TestM1QAOperationCustodyPartialAccountConstructorTransfersExactlyOnce(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	original := &centralbrowserfamily.SocialM1QAOperationOwner{}
	r := &socialLoginRuntime{}
	s := &socialM1QAOperationStartupSelection{owner: original, originalNow: time.Now}
	if err := r.openM1QAAccountOperation(ctx, s); !errors.Is(err, context.Canceled) {
		t.Fatalf("constructor original error lost: %v", err)
	}
	if r.accountOperation == nil || r.operationOwner != original || !r.operationOwnerTransferred || r.releases.operationOwner != nil || r.releases.accountOperation != r.accountOperation {
		t.Fatal("partial account runtime custody was dropped or duplicated")
	}
	partial := r.accountOperation
	if err := r.openM1QAAccountOperation(context.Background(), s); err == nil || r.accountOperation != partial {
		t.Fatal("partial owner replaced on retry")
	}
	if err := r.retainM1QAOperationOwner(original); err == nil {
		t.Fatal("transferred owner reacquired")
	}
	_ = r.Close(context.Background())
}

func TestM1QAOperationCustodyCloseOrderAndUnknownStop(t *testing.T) {
	for _, transferred := range []bool{false, true} {
		ownerName := "untransferred-owner"
		if transferred {
			ownerName = "account-runtime"
		}
		order := []string{"service", ownerName, "native-publisher", "native-source", "producer", "authority", "challenges", "enrollment", "operation-provider", "login-provider"}
		for fail := -1; fail < len(order); fail++ {
			t.Run(ownerName+"/"+func() string {
				if fail < 0 {
					return "success"
				}
				return order[fail]
			}(), func(t *testing.T) {
				var actual []string
				uncertain := errors.New("PUBLIC retained original cleanup failure")
				release := func(index int) m1qaOperationReleaseFunc {
					return func() error {
						actual = append(actual, order[index])
						if index == fail {
							return uncertain
						}
						return nil
					}
				}
				r := &socialLoginRuntime{}
				r.releases.service = m1qaOperationContextReleaseFunc(func(context.Context) error { return release(0)() })
				if transferred {
					r.releases.accountOperation = release(1)
				} else {
					r.releases.operationOwner = release(1)
				}
				r.releases.nativePublisher, r.releases.nativeSource = release(2), release(3)
				r.releases.producer, r.releases.authority = release(4), release(5)
				r.releases.challenges, r.releases.enrollment = release(6), release(7)
				r.releases.operationProvider, r.releases.provider = release(8), release(9)
				for i := 0; i < 2; i++ {
					err := r.Close(context.Background())
					if fail >= 0 && !errors.Is(err, uncertain) || fail < 0 && err != nil {
						t.Fatal("original release result changed")
					}
				}
				want := order
				if fail >= 0 {
					want = order[:fail+1]
				}
				if !reflect.DeepEqual(actual, want) {
					t.Fatalf("premature close or cleanup retry: %v, want %v", actual, want)
				}
			})
		}
	}
}

func TestM1QAOperationCustodyTimedOutObserverDoesNotReleaseSigner(t *testing.T) {
	entered, finish, completed := make(chan struct{}), make(chan struct{}), make(chan error, 1)
	var providerCalls atomic.Int32
	r := &socialLoginRuntime{}
	if err, settled := r.settledCloseResult(); err != nil || settled {
		t.Fatal("unstarted cleanup reported as settled")
	}
	r.releases.accountOperation = m1qaOperationReleaseFunc(func() error { close(entered); <-finish; return nil })
	r.releases.operationProvider = m1qaOperationReleaseFunc(func() error { providerCalls.Add(1); return nil })
	go func() { completed <- waitSocialLoginRuntimeClose(r) }()
	select {
	case <-entered:
	case <-time.After(time.Second):
		t.Fatal("drain not started")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Millisecond)
	defer cancel()
	if err := r.Close(ctx); !errors.Is(err, context.DeadlineExceeded) {
		close(finish)
		t.Fatalf("observer outcome: %v", err)
	}
	if providerCalls.Load() != 0 {
		close(finish)
		t.Fatal("signer released before original account drain")
	}
	if err, settled := r.settledCloseResult(); err != nil || settled {
		close(finish)
		t.Fatal("observer timeout replaced unfinished original cleanup")
	}
	close(finish)
	select {
	case err := <-completed:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("original drain did not finish")
	}
	if providerCalls.Load() != 1 {
		t.Fatal("provider not released exactly once")
	}
	if err, settled := r.settledCloseResult(); err != nil || !settled {
		t.Fatal("original successful completion replaced by observer timeout")
	}
	if err := r.Close(context.Background()); err != nil || providerCalls.Load() != 1 {
		t.Fatal("cached drain repeated provider close")
	}
}

func TestM1QAOperationCustodyNormalWaitReturnsOriginalTerminalResult(t *testing.T) {
	const childCase = "YNX_PUBLIC_CLOSE_WAIT_CASE"
	if selected := os.Getenv(childCase); selected != "" {
		// A regression must terminate within this test subprocess, not leave an
		// infinite wait goroutine or unbounded log stream in the parent suite.
		log.SetOutput(io.Discard)
		var original error
		switch selected {
		case "deadline":
			original = context.DeadlineExceeded
		case "wrapped-deadline":
			original = errors.Join(errors.New("PUBLIC original cleanup failure"), context.DeadlineExceeded)
		case "success":
		default:
			t.Fatal("unknown PUBLIC close case")
		}
		var accountCalls, providerCalls atomic.Int32
		r := &socialLoginRuntime{}
		r.releases.accountOperation = m1qaOperationReleaseFunc(func() error {
			accountCalls.Add(1)
			return original
		})
		r.releases.operationProvider = m1qaOperationReleaseFunc(func() error {
			providerCalls.Add(1)
			return nil
		})
		for i := 0; i < 2; i++ {
			if got := waitSocialLoginRuntimeClose(r); got != original {
				t.Fatalf("original terminal result changed: got %v, want %v", got, original)
			}
		}
		if got, settled := r.settledCloseResult(); !settled || got != original {
			t.Fatal("original terminal receipt was not retained")
		}
		wantProviderCalls := int32(0)
		if original == nil {
			wantProviderCalls = 1
		}
		if accountCalls.Load() != 1 || providerCalls.Load() != wantProviderCalls {
			t.Fatal("cleanup retried or signer released after uncertain account drain")
		}
		return
	}
	for _, selected := range []string{"deadline", "wrapped-deadline", "success"} {
		t.Run(selected, func(t *testing.T) {
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			cmd := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestM1QAOperationCustodyNormalWaitReturnsOriginalTerminalResult$", "-test.timeout=4s")
			cmd.Env = append(os.Environ(), childCase+"="+selected)
			if output, err := cmd.CombinedOutput(); err != nil {
				t.Fatalf("normal close did not return its original terminal result: %v\n%s", err, output)
			}
		})
	}
}
