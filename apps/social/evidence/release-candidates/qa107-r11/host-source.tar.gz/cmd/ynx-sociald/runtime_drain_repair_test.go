package main

import (
	"context"
	"crypto/tls"
	"net"
	"net/http"
	"sync"
	"testing"
	"time"
)

func TestFESI1BlockedHandlerDrainsBeforeRelease(t *testing.T) {
	config := publicSocialLoginRuntimeConfig(t)
	r, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal(err)
	}
	tlsConfig, pool := publicSocialListenerTLS(t) // existing PUBLIC TEST ONLY certificate
	reservation, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	addr := reservation.Addr().String()
	reservation.Close()
	entered, release := make(chan struct{}), make(chan struct{})
	var once sync.Once
	released := make(chan string, 5)
	service, provider := r.releases.service, r.releases.provider
	r.releases.service = testContextRelease{func(ctx context.Context) error { released <- "service"; return service.Close(ctx) }}
	r.releases.authority = testPlainRelease{func() error { released <- "authority-mechanical"; return nil }}
	r.releases.challenges = testPlainRelease{func() error { released <- "challenge-mechanical"; return nil }}
	r.releases.provider = testPlainRelease{func() error { released <- "provider"; return provider.Close() }}
	server := &http.Server{Addr: addr, Handler: http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		once.Do(func() { close(entered) })
		<-release
		w.WriteHeader(204)
	})}
	served := make(chan error, 1)
	go func() { served <- runSocialHTTPServer(server, r, tlsConfig, nil) }()
	defer func() {
		select {
		case <-release:
		default:
			close(release)
		}
		server.Close()
		r.Close(context.Background())
	}()
	client := &http.Client{Transport: &http.Transport{TLSClientConfig: &tls.Config{RootCAs: pool, ServerName: "social.ynxweb4.com"}}, Timeout: 5 * time.Second}
	defer client.CloseIdleConnections()
	requested := make(chan error, 1)
	go func() {
		deadline := time.Now().Add(3 * time.Second)
		for {
			resp, e := client.Get("https://" + addr + "/")
			if e == nil {
				resp.Body.Close()
				requested <- nil
				return
			}
			if time.Now().After(deadline) {
				requested <- e
				return
			}
			time.Sleep(10 * time.Millisecond)
		}
	}()
	select {
	case <-entered:
	case err := <-served:
		t.Fatal("serve failed", err)
	case <-time.After(4 * time.Second):
		t.Fatal("handler not entered")
	}
	// A timed-out first Shutdown returns while the actual handler remains held.
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Millisecond)
	err = server.Shutdown(ctx)
	cancel()
	if err != context.DeadlineExceeded {
		t.Fatal("blocked handler not held", err)
	}
	select {
	case e := <-served:
		t.Fatal("serve returned before drain", e)
	case name := <-released:
		t.Fatal("released before drain", name)
	default:
	}
	close(release)
	select {
	case err := <-served:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(4 * time.Second):
		t.Fatal("serve did not finish")
	}
	if err := <-requested; err != nil {
		t.Fatal(err)
	}
	for _, expected := range []string{"service", "authority-mechanical", "challenge-mechanical", "provider"} {
		select {
		case got := <-released:
			if got != expected {
				t.Fatal(got, expected)
			}
		default:
			t.Fatal("missing cleanup", expected)
		}
	}
	if err := r.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
	select {
	case got := <-released:
		t.Fatal("repeated cleanup", got)
	default:
	}
}
