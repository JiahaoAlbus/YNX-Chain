package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"errors"
	"math/big"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// These deterministic keys are PUBLIC TEST FIXTURES, never production inputs.
func publicSocialListenerTLS(t *testing.T) (socialServerTLSConfig, *x509.CertPool) {
	t.Helper()
	key := ed25519.NewKeyFromSeed(bytes.Repeat([]byte{0x57}, ed25519.SeedSize))
	template := &x509.Certificate{SerialNumber: big.NewInt(7), Subject: pkix.Name{CommonName: "PUBLIC TEST ONLY"}, DNSNames: []string{"social.ynxweb4.com"}, IPAddresses: []net.IP{net.ParseIP("127.0.0.1")}, NotBefore: time.Now().Add(-time.Minute), NotAfter: time.Now().Add(time.Hour), KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
	der, err := x509.CreateCertificate(nil, template, template, key.Public(), key)
	if err != nil {
		t.Fatal(err)
	}
	private, err := x509.MarshalPKCS8PrivateKey(key)
	if err != nil {
		t.Fatal(err)
	}
	dir, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	certPath, keyPath := filepath.Join(dir, "public-test-cert.pem"), filepath.Join(dir, "public-test-key.pem")
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	if err := os.WriteFile(certPath, certPEM, 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(keyPath, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: private}), 0600); err != nil {
		t.Fatal(err)
	}
	pool := x509.NewCertPool()
	if !pool.AppendCertsFromPEM(certPEM) {
		t.Fatal("test certificate rejected")
	}
	return socialServerTLSConfig{certificate: certPath, key: keyPath, enabled: true}, pool
}

func TestSocialNormalServeFailureClosesRuntime(t *testing.T) {
	for _, scenario := range []string{"occupied-address", "tls-required", "configuration-error"} {
		t.Run(scenario, func(t *testing.T) {
			config := publicSocialLoginRuntimeConfig(t)
			runtime, err := openSocialLoginRuntime(config)
			if err != nil {
				t.Fatal(err)
			}
			t.Cleanup(func() { _ = waitSocialLoginRuntimeClose(runtime) })
			listener, err := net.Listen("tcp", "127.0.0.1:0")
			if err != nil {
				t.Fatal(err)
			}
			defer listener.Close()
			tlsConfig, _ := publicSocialListenerTLS(t)
			var configErr error
			if scenario == "tls-required" {
				tlsConfig = socialServerTLSConfig{}
			}
			if scenario == "configuration-error" {
				configErr = errSocialTLSConfiguration
			}
			server := &http.Server{Addr: listener.Addr().String(), Handler: runtime.service.ProductHandler(nil)}
			if err := runSocialHTTPServer(server, runtime, tlsConfig, configErr); err == nil {
				t.Fatal("startup failure returned success")
			}
			if _, err := runtime.provider.SignEd25519(context.Background(), []byte("PUBLIC TEST ONLY")); err == nil {
				t.Fatal("provider remained usable after serving returned")
			}
			reopened, err := openSocialLoginRuntime(config)
			if err != nil {
				t.Fatalf("store not released: %v", err)
			}
			if err := waitSocialLoginRuntimeClose(reopened); err != nil {
				t.Fatal(err)
			}
		})
	}
}

func TestSocialNormalServeRealTLS(t *testing.T) {
	config := publicSocialLoginRuntimeConfig(t)
	runtime, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal(err)
	}
	tlsConfig, pool := publicSocialListenerTLS(t)
	// Reserve an OS-selected address, then release it for the normal serving path.
	reservation, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	address := reservation.Addr().String()
	if err := reservation.Close(); err != nil {
		t.Fatal(err)
	}
	server := &http.Server{Addr: address, Handler: runtime.service.ProductHandler(nil)}
	finished := make(chan error, 1)
	go func() { finished <- runSocialHTTPServer(server, runtime, tlsConfig, nil) }()
	t.Cleanup(func() { _ = server.Close(); _ = waitSocialLoginRuntimeClose(runtime) })
	transport := &http.Transport{TLSClientConfig: &tls.Config{RootCAs: pool, ServerName: "social.ynxweb4.com", MinVersion: tls.VersionTLS12}}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: time.Second}
	deadline := time.Now().Add(5 * time.Second)
	for {
		request, err := http.NewRequest(http.MethodPost, "https://"+address+"/v4/login/start", bytes.NewBufferString(`{"intent":"A"}`))
		if err != nil {
			t.Fatal(err)
		}
		request.Host = "social.ynxweb4.com"
		request.Header.Set("Origin", "https://social.ynxweb4.com")
		request.Header.Set("Content-Type", "application/json")
		response, err := client.Do(request)
		if err == nil {
			_ = response.Body.Close()
			if response.StatusCode != http.StatusOK {
				t.Fatalf("normal TLS login start: HTTP %d", response.StatusCode)
			}
			if len(response.Cookies()) != 2 {
				t.Fatal("missing login custody cookies")
			}
			break
		}
		select {
		case serveErr := <-finished:
			t.Fatalf("listener terminated: %v", serveErr)
		default:
		}
		if time.Now().After(deadline) {
			t.Fatalf("normal TLS listener unavailable: %v", err)
		}
		time.Sleep(20 * time.Millisecond)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := server.Shutdown(ctx); err != nil {
		t.Fatal(err)
	}
	select {
	case err := <-finished:
		if err != nil {
			t.Fatal(err)
		}
	case <-ctx.Done():
		t.Fatal("serving cleanup did not return")
	}
	if _, err := runtime.provider.SignEd25519(context.Background(), []byte("PUBLIC TEST ONLY")); err == nil {
		t.Fatal("provider usable after shutdown")
	}
	reopened, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal(err)
	}
	if err := waitSocialLoginRuntimeClose(reopened); err != nil && !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}
