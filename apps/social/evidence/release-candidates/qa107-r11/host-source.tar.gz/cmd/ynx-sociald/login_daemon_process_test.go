package main

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestSocialLoginActualDaemonLifecycle(t *testing.T) {
	binary := os.Getenv("YNX_SOCIAL_QA_DAEMON")
	if binary == "" {
		t.Skip("requires explicit freshly built QA daemon")
	}
	if !filepath.IsAbs(binary) {
		t.Fatal("QA daemon must be an absolute path")
	}
	for _, scenario := range []string{"occupied-address", "sigterm", "sigint"} {
		t.Run(scenario, func(t *testing.T) {
			config := publicSocialLoginRuntimeConfig(t)
			tlsConfig, pool := publicSocialListenerTLS(t)
			metadata, err := json.Marshal(map[string]string{
				"schema": "ynx-social-backend-signer/v1", "profile": config.Profile,
				"keyId": config.KeyID, "publicKey": base64.RawURLEncoding.EncodeToString(config.PublicKey), "privateKeyFile": config.PrivateKeyFile,
			})
			if err != nil {
				t.Fatal(err)
			}
			metadataPath := filepath.Join(filepath.Dir(config.PrivateKeyFile), "PUBLIC-TEST-signer.json")
			if err := os.WriteFile(metadataPath, metadata, 0600); err != nil {
				t.Fatal(err)
			}
			listener, err := net.Listen("tcp", "127.0.0.1:0")
			if err != nil {
				t.Fatal(err)
			}
			defer listener.Close()
			address := listener.Addr().String()
			if scenario != "occupied-address" {
				if err := listener.Close(); err != nil {
					t.Fatal(err)
				}
			}
			ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
			defer cancel()
			command := exec.CommandContext(ctx, binary, "-http", address)
			for _, entry := range os.Environ() {
				if !strings.HasPrefix(entry, "YNX_") {
					command.Env = append(command.Env, entry)
				}
			}
			command.Env = append(command.Env,
				"YNX_SOCIAL_LOGIN_STATE_DIR="+config.Store.Directory,
				"YNX_SOCIAL_LOGIN_SEAL_KEY_FILE="+config.Store.SealKeyFile,
				"YNX_SOCIAL_LOGIN_SIGNER_CONFIG_FILE="+metadataPath,
				"YNX_SOCIAL_TLS_CERT_FILE="+tlsConfig.certificate,
				"YNX_SOCIAL_TLS_KEY_FILE="+tlsConfig.key,
			)
			var output bytes.Buffer
			command.Stdout = &output
			command.Stderr = &output
			if err := command.Start(); err != nil {
				t.Fatal(err)
			}
			finished := make(chan error, 1)
			go func() { finished <- command.Wait() }()
			if scenario == "occupied-address" {
				select {
				case err := <-finished:
					if err == nil || ctx.Err() != nil {
						t.Fatalf("expected prompt nonzero listener failure: %v", err)
					}
					if !strings.Contains(output.String(), "address already in use") {
						t.Fatalf("failed before expected listener stage: %s", output.String())
					}
				case <-ctx.Done():
					t.Fatal("daemon failed to return on occupied address")
				}
			} else {
				transport := &http.Transport{TLSClientConfig: &tls.Config{RootCAs: pool, ServerName: "social.ynxweb4.com", MinVersion: tls.VersionTLS12}}
				defer transport.CloseIdleConnections()
				client := &http.Client{Transport: transport, Timeout: time.Second}
				for {
					request, err := http.NewRequest(http.MethodPost, "https://"+address+"/v4/login/start", bytes.NewBufferString(`{"intent":"A"}`))
					if err != nil {
						t.Fatal(err)
					}
					request.Host = "social.ynxweb4.com"
					request.Header.Set("Origin", "https://social.ynxweb4.com")
					request.Header.Set("Content-Type", "application/json")
					response, requestErr := client.Do(request)
					if requestErr == nil {
						_ = response.Body.Close()
						if response.StatusCode != 200 || len(response.Cookies()) != 2 {
							t.Fatalf("daemon login start status=%d cookies=%d", response.StatusCode, len(response.Cookies()))
						}
						break
					}
					select {
					case err := <-finished:
						t.Fatalf("daemon exited before TLS login: %v; %s", err, output.String())
					case <-ctx.Done():
						t.Fatal("daemon TLS startup timed out")
					default:
					}
					time.Sleep(20 * time.Millisecond)
				}
				signal := socialTerminationSignal()
				if scenario == "sigint" {
					signal = os.Interrupt
				}
				if err := command.Process.Signal(signal); err != nil {
					t.Fatal(err)
				}
				select {
				case err := <-finished:
					if err != nil {
						t.Fatalf("SIGTERM shutdown: %v; %s", err, output.String())
					}
				case <-ctx.Done():
					t.Fatal("SIGTERM shutdown timed out")
				}
			}
			reopened, err := openSocialLoginRuntime(config)
			if err != nil {
				t.Fatalf("fixture store unavailable after daemon exit: %v", err)
			}
			if err := waitSocialLoginRuntimeClose(reopened); err != nil {
				t.Fatal(err)
			}
		})
	}
}
