package main

import (
	"bytes"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"syscall"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

const socialLoginSignerConfigEnvironment = "YNX_SOCIAL_LOGIN_SIGNER_CONFIG_FILE"

var errSocialLoginRuntimeConfig = errors.New("Social login runtime configuration invalid or unavailable")

type socialLoginRuntimeConfig struct {
	ChallengeDirectory  string
	EnrollmentDirectory string
	Profile             string
	Store               kernel.SocialLoginServiceConfig
	KeyID               string
	PublicKey           ed25519.PublicKey
	PrivateKeyFile      string
}

// This reads only operator configuration metadata, never a private key. The
// provider separately validates protected custody before opening its reference.
// Configuration is not evidence of Central registration.
func loadSocialLoginRuntimeConfig(lookup func(string) (string, bool)) (socialLoginRuntimeConfig, bool, error) {
	store, storeEnabled, err := kernel.LoadSocialLoginServiceConfig(lookup)
	if err != nil {
		return socialLoginRuntimeConfig{}, storeEnabled, errSocialLoginRuntimeConfig
	}
	challengeDirectory, challengeEnabled := lookup("YNX_SOCIAL_FIRST_DEVICE_CHALLENGE_DIR")
	if challengeEnabled && (!storeEnabled || !socialLoginCleanFilePath(challengeDirectory)) {
		return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
	}
	enrollmentDirectory, enrollmentEnabled := lookup("YNX_SOCIAL_FIRST_DEVICE_ENROLLMENT_DIR")
	if enrollmentEnabled && (!challengeEnabled || !socialLoginCleanFilePath(enrollmentDirectory)) {
		return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
	}
	path, signerEnabled := lookup(socialLoginSignerConfigEnvironment)
	if !storeEnabled && !signerEnabled {
		return socialLoginRuntimeConfig{}, false, nil
	}
	if !storeEnabled || !signerEnabled || !socialLoginCleanFilePath(path) {
		return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
	}
	data, err := readSocialLoginPublicConfig(path)
	if err != nil {
		return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
	}
	d := json.NewDecoder(bytes.NewReader(data))
	first, err := d.Token()
	if err != nil || first != json.Delim('{') {
		return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
	}
	fields := make(map[string]string)
	for d.More() {
		key, err := d.Token()
		name, ok := key.(string)
		if err != nil || !ok {
			return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
		}
		if _, exists := fields[name]; exists {
			return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
		}
		switch name {
		case "schema", "profile", "keyId", "publicKey", "privateKeyFile":
		default:
			return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
		}
		value, err := d.Token()
		text, ok := value.(string)
		if err != nil || !ok {
			return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
		}
		fields[name] = text
	}
	last, err := d.Token()
	if err != nil || last != json.Delim('}') || len(fields) != 5 {
		return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
	}
	if _, err := d.Token(); err != io.EOF {
		return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
	}
	public, err := base64.RawURLEncoding.DecodeString(fields["publicKey"])
	if fields["schema"] != "ynx-social-backend-signer/v1" || fields["profile"] != "protected-backend-software-pkcs8-v1" || err != nil || len(public) != ed25519.PublicKeySize || base64.RawURLEncoding.EncodeToString(public) != fields["publicKey"] || !socialLoginCleanFilePath(fields["privateKeyFile"]) {
		return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
	}
	id := fields["keyId"]
	if len(id) == 0 || len(id) > 128 {
		return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
	}
	for _, c := range []byte(id) {
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_' || c == '-' || c == '.' || c == '~') {
			return socialLoginRuntimeConfig{}, true, errSocialLoginRuntimeConfig
		}
	}
	return socialLoginRuntimeConfig{EnrollmentDirectory: enrollmentDirectory, ChallengeDirectory: challengeDirectory, Profile: fields["profile"], Store: store, KeyID: id, PublicKey: public, PrivateKeyFile: fields["privateKeyFile"]}, true, nil
}

func socialLoginCleanFilePath(path string) bool {
	return filepath.IsAbs(path) && filepath.Clean(path) == path && filepath.Dir(path) != path
}

func readSocialLoginPublicConfig(path string) ([]byte, error) {
	parent, err := os.Lstat(filepath.Dir(path))
	if err != nil || !socialLoginConfigOwned(parent, true) {
		return nil, errSocialLoginRuntimeConfig
	}
	fd, err := syscall.Open(path, syscall.O_RDONLY|syscall.O_NOFOLLOW|syscall.O_CLOEXEC|syscall.O_NONBLOCK, 0)
	if err != nil {
		return nil, errSocialLoginRuntimeConfig
	}
	f := os.NewFile(uintptr(fd), "social-login-public-config")
	held, statErr := f.Stat()
	named, nameErr := os.Lstat(path)
	if statErr != nil || nameErr != nil || !socialLoginConfigOwned(held, false) || !socialLoginConfigOwned(named, false) || !os.SameFile(held, named) || held.Size() > 8192 {
		_ = f.Close()
		return nil, errSocialLoginRuntimeConfig
	}
	data, readErr := io.ReadAll(io.LimitReader(f, 8193))
	after, afterErr := f.Stat()
	current, currentErr := os.Lstat(path)
	parentAfter, parentErr := os.Lstat(filepath.Dir(path))
	closeErr := f.Close()
	if readErr != nil || closeErr != nil || afterErr != nil || currentErr != nil || parentErr != nil || len(data) > 8192 || !socialLoginConfigOwned(current, false) || !socialLoginConfigOwned(parentAfter, true) || !os.SameFile(held, after) || !os.SameFile(held, current) || !os.SameFile(parent, parentAfter) || held.Size() != after.Size() || !held.ModTime().Equal(after.ModTime()) {
		return nil, errSocialLoginRuntimeConfig
	}
	return data, nil
}

func socialLoginConfigOwned(info os.FileInfo, directory bool) bool {
	if info == nil || info.Mode().Perm()&0077 != 0 {
		return false
	}
	stat, ok := info.Sys().(*syscall.Stat_t)
	if !ok || stat.Uid != uint32(os.Geteuid()) {
		return false
	}
	if directory {
		return info.IsDir() && info.Mode()&os.ModeSymlink == 0
	}
	return info.Mode().IsRegular() && stat.Nlink == 1
}
