package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"github.com/JiahaoAlbus/YNX-Chain/internal/centralbrowserfamily"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
	"io"
	"os"
	"runtime"
	"syscall"
)

// Private independently admitted deployment input. No HTTP, ENV, CLI flag,
// Desktop catalog or a successful TLS handshake can populate this selection.
type socialNativeHostStartupSelection struct {
	source                  centralbrowserfamily.SocialNativeInstanceSourceConfig
	hostKeyFile             string
	parentRead, parentWrite *os.File
}

func (r *socialLoginRuntime) openNativeHostSource(ctx context.Context, selection *socialM1QALoginStartupSelection) (*centralbrowserfamily.SocialNativeInstanceSource, error) {
	if r == nil || selection == nil || selection.nativeHost == nil || selection.operation == nil || selection.operation.owner == nil || r.m1qaProfile == nil {
		return nil, centralbrowserfamily.ErrSocialNativeInstanceNotConfigured
	}
	raw, err := r.m1qaProfile.OriginalSignedProfileRaw(ctx)
	if err != nil {
		return nil, err
	}
	digest := sha256.Sum256([]byte(raw))
	if hex.EncodeToString(digest[:]) != selection.nativeHost.source.ExpectedProfileDigest {
		return nil, centralbrowserfamily.ErrSocialNativeInstanceInvalid
	}
	// The final binary is hashed AFTER packaging from the OS's actual executable
	// descriptor. This is an observed target, not a trust anchor; the independently
	// verified Root registration must separately approve that exact digest. It
	// avoids embedding the final executable hash in its own source/binary.
	config := selection.nativeHost.source
	actual, err := originalNativeExecutableDigest()
	if err != nil {
		return nil, err
	}
	if config.ExpectedServiceBinaryDigest != "" && config.ExpectedServiceBinaryDigest != actual {
		return nil, centralbrowserfamily.ErrSocialNativeInstanceInvalid
	}
	config.ExpectedServiceBinaryDigest = actual
	source, err := centralbrowserfamily.OpenSocialNativeInstanceSource(config)
	// Retain the exact partially opened source before returning an error.
	if source != nil {
		r.nativeSource = source
		r.releases.nativeSource = source
	}
	return source, err
}

func originalNativeExecutableDigest() (string, error) {
	if runtime.GOOS != "linux" {
		return "", centralbrowserfamily.ErrSocialNativeInstanceNotConfigured
	}
	// This exact kernel path denotes THIS process; never an ENV/caller path.
	f, err := os.Open("/proc/self/exe")
	if err != nil {
		return "", err
	}
	defer f.Close()
	first, err := f.Stat()
	if err != nil || !first.Mode().IsRegular() || first.Mode().Perm()&0022 != 0 || first.Size() < 1 || first.Size() > 64*1024*1024 {
		return "", centralbrowserfamily.ErrSocialNativeInstanceInvalid
	}
	h := sha256.New()
	n, err := io.CopyBuffer(h, io.LimitReader(f, first.Size()+1), make([]byte, 65536))
	if err != nil || n != first.Size() {
		return "", errors.Join(centralbrowserfamily.ErrSocialNativeInstanceInvalid, err)
	}
	last, err := f.Stat()
	if err != nil || !os.SameFile(first, last) || last.Mode() != first.Mode() || last.Size() != first.Size() || !last.ModTime().Equal(first.ModTime()) {
		return "", centralbrowserfamily.ErrSocialNativeInstanceInvalid
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func (r *socialLoginRuntime) openNativeHostPublisher(ctx context.Context, selection *socialM1QALoginStartupSelection) error {
	if r == nil || r.nativeSource == nil || r.accountOperation == nil || selection == nil || selection.nativeHost == nil || selection.operation == nil {
		return centralbrowserfamily.ErrSocialNativeInstanceNotConfigured
	}
	_, loginPublic, err := r.m1qaProfile.BackendSignerPublic()
	if err != nil {
		return err
	}
	_, operationPublic, err := selection.operation.owner.OperationSignerPublic(ctx)
	if err != nil {
		return err
	}
	h := selection.nativeHost
	binding, err := r.nativeSource.Binding(ctx)
	if err != nil {
		return err
	}
	// Withdrawal is still usable for original read/terminal reconciliation;
	// it never opens the current-carrier signing key or a new capture handler.
	if binding.Status != "active" {
		return nil
	}
	// Only this already admitted normal launcher inherits FD3/4. Their
	// presence is transport custody, never registration or Root authority.
	// os.NewFile observes nonblocking pipes so original context deadlines can
	// interrupt partial IO. No ENV/public path can select these descriptors.
	if h.parentRead == nil && h.parentWrite == nil {
		for _, fd := range []int{3, 4} {
			var st syscall.Stat_t
			if syscall.Fstat(fd, &st) != nil || st.Mode&syscall.S_IFMT != syscall.S_IFIFO {
				return centralbrowserfamily.ErrSocialNativeInstanceNotConfigured
			}
			if err := syscall.SetNonblock(fd, true); err != nil {
				return err
			}
		}
		h.parentRead = os.NewFile(3, "original-central-parent-read")
		h.parentWrite = os.NewFile(4, "original-central-parent-write")
	}
	publisher, err := kernel.OpenSocialNativeAccountPublisher(ctx, kernel.SocialNativeAccountPublisherConfig{Source: r.nativeSource, PrivateKeyFile: h.hostKeyFile, OriginalLoginKeyFile: selection.runtime.PrivateKeyFile, OriginalSealKeyFile: selection.runtime.Store.SealKeyFile, OriginalLoginPublic: loginPublic, OriginalOperationPublic: operationPublic, OriginalParentRead: h.parentRead, OriginalParentWrite: h.parentWrite})
	if publisher != nil {
		r.nativePublisher = publisher
		r.releases.nativePublisher = publisher
	}
	return err
}
