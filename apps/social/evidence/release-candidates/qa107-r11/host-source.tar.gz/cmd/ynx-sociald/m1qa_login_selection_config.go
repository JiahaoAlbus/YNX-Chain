package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"path/filepath"
	"time"

	"github.com/JiahaoAlbus/YNX-Chain/internal/centralbrowserfamily"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

const socialM1QAStartupConfigEnvironment = "YNX_SOCIAL_M1QA_STARTUP_CONFIG_FILE"

// This independent release input is supplied by the deployment custodian using
// -X main.socialM1QAAdmittedStartupDigest=<approved complete configuration SHA256>.
// It is deliberately unset here. Neither ENV nor the configuration supplies it.
// A matching digest admits configuration bytes, not an identity or device.
var socialM1QAAdmittedStartupDigest string

var (
	errSocialM1QAStartupUnadmitted    = errors.New("Social M1 QA startup configuration has no independent release pin")
	errSocialM1QAStartupPin           = errors.New("Social M1 QA startup configuration does not match admitted bytes")
	errSocialM1QAStartupConfiguration = errors.New("Social M1 QA startup configuration invalid or unavailable")
	errSocialM1QAStartupAmbiguous     = errors.New("Social M1 QA startup has multiple selected configurations")
)

// Ordinary public deployment metadata only. Owner objects, approval booleans,
// private material, clocks and protocol overrides cannot be decoded from it.
type socialM1QAStartupMetadata struct {
	profile            centralbrowserfamily.SocialM1QATrustedProfileConfig
	directory          string
	sealKeyFile        string
	signerConfigFile   string
	operation          *socialM1QAOperationProvisioning
	native             *socialM1QANativeStartupMetadata
	firstDevice        *firstEnrollmentStartup
	challengeDirectory string
}

func loadSocialM1QALoginStartupSelection(ctx context.Context, lookup func(string) (string, bool)) (*socialM1QALoginStartupSelection, bool, error) {
	if ctx == nil || lookup == nil {
		return nil, false, errSocialM1QAStartupConfiguration
	}
	if err := ctx.Err(); err != nil {
		return nil, false, err
	}
	path, enabled := lookup(socialM1QAStartupConfigEnvironment)
	if !enabled {
		return nil, false, nil
	}
	if !socialM1QAStartupDigestValid(socialM1QAAdmittedStartupDigest) {
		return nil, true, errSocialM1QAStartupUnadmitted
	}
	if !socialLoginCleanFilePath(path) {
		return nil, true, errSocialM1QAStartupConfiguration
	}
	// The existing reader holds one bounded regular, owned, non-symlink file.
	// Hash and decode this SAME buffer, never a remarshal or a second path read.
	data, err := readSocialLoginPublicConfig(path)
	if err != nil {
		return nil, true, errSocialM1QAStartupConfiguration
	}
	if err = ctx.Err(); err != nil {
		return nil, true, err
	}
	digest := sha256.Sum256(data)
	if hex.EncodeToString(digest[:]) != socialM1QAAdmittedStartupDigest {
		return nil, true, errSocialM1QAStartupPin
	}
	m, err := decodeSocialM1QAStartupMetadata(data)
	if err != nil {
		return nil, true, err
	}
	// These are a separate QA namespace. Do not feed QA paths into the normal
	// production ENV lookup, or silently auto-provision a missing store.
	paths := []string{path, m.profile.RootPath, m.profile.ProfilePath, m.directory, m.sealKeyFile, m.signerConfigFile}
	if m.firstDevice != nil {
		paths = append(paths, m.firstDevice.path, m.challengeDirectory)
	}
	if m.operation != nil {
		paths = append(paths, m.operation.owner.RootPath, m.operation.owner.CertificatePath, m.operation.owner.NodeConfigPath, m.operation.privateKeyFile)
	}
	if m.native != nil {
		paths = append(paths, m.native.source.RootPath, m.native.hostKeyFile, m.native.selectionFile)
	}
	seen := make(map[string]bool, len(paths))
	for _, p := range paths {
		if !socialLoginCleanFilePath(p) || seen[p] {
			return nil, true, errSocialM1QAStartupConfiguration
		}
		seen[p] = true
	}
	if filepath.Base(m.directory) != "m1qa-login-v1" || filepath.Base(m.sealKeyFile) != "m1qa-login-seal.key" || filepath.Dir(m.directory) != filepath.Dir(m.sealKeyFile) {
		return nil, true, errSocialM1QAStartupConfiguration
	}
	refs := map[string]string{
		kernel.SocialLoginStateDirectoryEnvironment: m.directory,
		kernel.SocialLoginSealKeyEnvironment:        m.sealKeyFile,
		socialLoginSignerConfigEnvironment:          m.signerConfigFile,
	}
	if m.firstDevice != nil {
		refs["YNX_SOCIAL_FIRST_DEVICE_MODE"] = m.firstDevice.mode
		refs["YNX_SOCIAL_FIRST_DEVICE_REALM"] = m.firstDevice.realm
		refs["YNX_SOCIAL_FIRST_DEVICE_AUTHORITY_FILE"] = m.firstDevice.path
		refs["YNX_SOCIAL_FIRST_DEVICE_CHALLENGE_DIR"] = m.challengeDirectory
	}
	lookupSelected := func(name string) (string, bool) {
		value, ok := refs[name]
		return value, ok
	}
	runtime, runtimeEnabled, err := loadSocialLoginRuntimeConfig(lookupSelected)
	if err != nil || !runtimeEnabled {
		return nil, true, errSocialM1QAStartupConfiguration
	}
	var firstDevice *firstEnrollmentStartup
	if m.firstDevice != nil {
		selected, err := loadFirstEnrollmentStartup(lookupSelected, runtime, runtimeEnabled)
		if err != nil || !m1QAFirstDevicePaths(runtime, selected) || runtime.ChallengeDirectory == runtime.PrivateKeyFile {
			return nil, true, errSocialM1QAStartupConfiguration
		}
		firstDevice = &selected
	}
	if err := ctx.Err(); err != nil {
		return nil, true, err
	}
	m.profile.Now = time.Now
	if m.operation != nil {
		m.operation.owner.Now = time.Now
		if !validSocialM1QAOperationProvisioning(m.operation, runtime) {
			return nil, true, errSocialM1QAStartupConfiguration
		}
	}
	selection := &socialM1QALoginStartupSelection{profile: m.profile, runtime: runtime, provisioning: m.operation, firstDevice: firstDevice}
	if m.native != nil {
		selection.nativeHost, selection.firstDevice, err = loadSocialM1QANativeStartupSelection(ctx, m, selection.runtime, append(paths, runtime.PrivateKeyFile))
		if err != nil {
			return nil, true, err
		}
	}
	// Storage and public native references select existing constructors, not
	// accepted source objects or device grants. Post-build artifacts remain
	// external to the executable's own startup pin.
	return selection, true, nil
}

func socialM1QAStartupDigestValid(s string) bool {
	if len(s) != sha256.Size*2 {
		return false
	}
	for _, c := range []byte(s) {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

func decodeSocialM1QAStartupMetadata(data []byte) (socialM1QAStartupMetadata, error) {
	var out socialM1QAStartupMetadata
	d := json.NewDecoder(bytes.NewReader(data))
	first, err := d.Token()
	if err != nil || first != json.Delim('{') {
		return out, errSocialM1QAStartupConfiguration
	}
	fields := map[string]*string{
		"rootPath":                       &out.profile.RootPath,
		"rootDigest":                     &out.profile.RootDigest,
		"profilePath":                    &out.profile.ProfilePath,
		"profileDigest":                  &out.profile.ProfileDigest,
		"expectedRegistryDigest":         &out.profile.ExpectedRegistryDigest,
		"expectedTargetArtifactDigest":   &out.profile.ExpectedTargetArtifactDigest,
		"expectedCertificateDigest":      &out.profile.ExpectedCertificateDigest,
		"expectedCallbackManifestDigest": &out.profile.ExpectedCallbackManifestDigest,
		"expectedAssetLinksDigest":       &out.profile.ExpectedAssetLinksDigest,
		"loginStateDirectory":            &out.directory,
		"loginSealKeyFile":               &out.sealKeyFile,
		"loginSignerConfigFile":          &out.signerConfigFile,
	}
	sizes := map[string]*int64{"rootBytes": &out.profile.RootBytes, "profileBytes": &out.profile.ProfileBytes}
	var operation socialM1QAOperationProvisioning
	var operationPublic string
	operationFields := map[string]*string{
		"operationRootPath":          &operation.owner.RootPath,
		"operationRootDigest":        &operation.owner.RootDigest,
		"operationCertificatePath":   &operation.owner.CertificatePath,
		"operationCertificateDigest": &operation.owner.CertificateDigest,
		"operationNodeConfigPath":    &operation.owner.NodeConfigPath,
		"operationNodeConfigDigest":  &operation.owner.NodeConfigDigest,
		"operationKeyId":             &operation.keyID,
		"operationPublicKey":         &operationPublic,
		"operationPrivateKeyFile":    &operation.privateKeyFile,
	}
	operationSizes := map[string]*int64{
		"operationRootBytes":        &operation.owner.RootBytes,
		"operationCertificateBytes": &operation.owner.CertificateBytes,
		"operationNodeConfigBytes":  &operation.owner.NodeConfigBytes,
	}
	var native socialM1QANativeStartupMetadata
	var firstDeviceMode string
	firstDeviceFields := map[string]*string{
		"firstDeviceChallengeDirectory": &native.challengeDirectory,
		"firstDeviceRealm":              &native.firstDevice.realm,
		"firstDeviceAuthorityFile":      &native.firstDevice.path,
	}
	nativeFields := map[string]*string{
		"nativeRootPath":      &native.source.RootPath,
		"nativeRootDigest":    &native.source.RootDigest,
		"nativeHostKeyFile":   &native.hostKeyFile,
		"nativeSelectionFile": &native.selectionFile,
		"nativeTLSSPKIDigest": &native.source.ExpectedTLSSPKIDigest,
	}
	nativeSizes := map[string]*int64{"nativeRootBytes": &native.source.RootBytes}
	nativeFloors := map[string]*int64{
		"nativeMinimumRegistrationRevision": &native.source.MinimumRegistrationRevision,
		"nativeMinimumStatusSequence":       &native.source.MinimumStatusSequence,
	}
	required := len(fields) + len(sizes)
	for key, target := range firstDeviceFields {
		fields[key] = target
	}
	fields["firstDeviceMode"] = &firstDeviceMode
	for key, target := range nativeFields {
		fields[key] = target
	}
	for key, target := range nativeSizes {
		sizes[key] = target
	}
	for key, target := range operationFields {
		fields[key] = target
	}
	for key, target := range operationSizes {
		sizes[key] = target
	}
	seen := make(map[string]bool, len(fields)+len(sizes))
	for d.More() {
		token, err := d.Token()
		key, ok := token.(string)
		if err != nil || !ok || seen[key] {
			return out, errSocialM1QAStartupConfiguration
		}
		seen[key] = true
		if field, ok := fields[key]; ok {
			value, err := d.Token()
			text, ok := value.(string)
			if err != nil || !ok {
				return out, errSocialM1QAStartupConfiguration
			}
			*field = text
		} else if size, ok := sizes[key]; ok {
			var raw json.RawMessage
			if err := d.Decode(&raw); err != nil || len(raw) == 0 || raw[0] < '1' || raw[0] > '9' || json.Unmarshal(raw, size) != nil || *size > 16384 {
				return out, errSocialM1QAStartupConfiguration
			}
		} else if floor, ok := nativeFloors[key]; ok {
			var raw json.RawMessage
			if err := d.Decode(&raw); err != nil || len(raw) == 0 || raw[0] < '1' || raw[0] > '9' || json.Unmarshal(raw, floor) != nil || *floor > 9007199254740991 {
				return out, errSocialM1QAStartupConfiguration
			}
		} else {
			return out, errSocialM1QAStartupConfiguration
		}
	}
	last, err := d.Token()
	if err != nil || last != json.Delim('}') {
		return out, errSocialM1QAStartupConfiguration
	}
	if _, err := d.Token(); err != io.EOF {
		return out, errSocialM1QAStartupConfiguration
	}
	operationCount := 0
	for key := range operationFields {
		if seen[key] {
			operationCount++
		}
	}
	for key := range operationSizes {
		if seen[key] {
			operationCount++
		}
	}
	firstDeviceCount := 0
	for key := range firstDeviceFields {
		if seen[key] {
			firstDeviceCount++
		}
	}
	modeCount := 0
	if seen["firstDeviceMode"] {
		modeCount = 1
	}
	nativeCount := 0
	for key := range nativeFields {
		if seen[key] {
			nativeCount++
		}
	}
	for key := range nativeSizes {
		if seen[key] {
			nativeCount++
		}
	}
	for key := range nativeFloors {
		if seen[key] {
			nativeCount++
		}
	}
	// Preserve the complete native group. Standalone storage instead requires
	// its explicit authority-v3 mode; neither can silently downgrade.
	if len(seen)-operationCount-nativeCount-firstDeviceCount-modeCount != required ||
		operationCount != 0 && operationCount != len(operationFields)+len(operationSizes) ||
		firstDeviceCount != 0 && firstDeviceCount != len(firstDeviceFields) ||
		modeCount != 0 && (firstDeviceMode != "authority-v3" || firstDeviceCount != len(firstDeviceFields)) ||
		nativeCount == 0 && firstDeviceCount != 0 && modeCount == 0 ||
		nativeCount != 0 && (nativeCount != len(nativeFields)+len(nativeSizes)+len(nativeFloors) || operationCount == 0 || firstDeviceCount != len(firstDeviceFields)) {
		return out, errSocialM1QAStartupConfiguration
	}
	if operationCount != 0 {
		public, err := base64.RawURLEncoding.DecodeString(operationPublic)
		if err != nil || len(public) != ed25519.PublicKeySize || base64.RawURLEncoding.EncodeToString(public) != operationPublic {
			return out, errSocialM1QAStartupConfiguration
		}
		operation.public = public
		operation.owner.ExpectedNodeConfigDigest = operation.owner.NodeConfigDigest
		if !validSocialM1QAOperationMetadata(&operation) {
			return out, errSocialM1QAStartupConfiguration
		}
		out.operation = &operation
	}
	if firstDeviceCount != 0 {
		native.firstDevice.mode = "authority-v3"
		first := native.firstDevice
		out.firstDevice, out.challengeDirectory = &first, native.challengeDirectory
	}
	if nativeCount != 0 {
		if !validSocialM1QANativeStartupMetadata(&native) {
			return out, errSocialM1QAStartupConfiguration
		}
		out.native = &native
	}
	for _, digest := range []string{out.profile.RootDigest, out.profile.ProfileDigest, out.profile.ExpectedRegistryDigest, out.profile.ExpectedTargetArtifactDigest, out.profile.ExpectedCertificateDigest, out.profile.ExpectedCallbackManifestDigest, out.profile.ExpectedAssetLinksDigest} {
		if !socialM1QAStartupDigestValid(digest) {
			return out, errSocialM1QAStartupConfiguration
		}
	}
	return out, nil
}
