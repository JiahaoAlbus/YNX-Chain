package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"strings"

	"github.com/JiahaoAlbus/YNX-Chain/internal/centralbrowserfamily"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

// Public construction references only. This uses the existing signed root,
// certificate and full Node registration formats; no new permission format or
// signer factory can supply an accepted owner. The referenced NEW-purpose key
// is independent of the login signer and the transaction-store seal key.
type socialM1QAOperationProvisioning struct {
	owner          centralbrowserfamily.SocialM1QAOperationOwnerConfig
	keyID          string
	public         ed25519.PublicKey
	privateKeyFile string
}

func validSocialM1QAOperationMetadata(c *socialM1QAOperationProvisioning) bool {
	if c == nil || len(c.public) != ed25519.PublicKeySize || len(c.keyID) == 0 || len(c.keyID) > 128 {
		return false
	}
	for _, b := range []byte(c.keyID) {
		if !(b >= 'a' && b <= 'z' || b >= 'A' && b <= 'Z' || b >= '0' && b <= '9' || b == '_' || b == '-' || b == '.' || b == '~') {
			return false
		}
	}
	seen := make(map[string]bool)
	for _, path := range []string{c.owner.RootPath, c.owner.CertificatePath, c.owner.NodeConfigPath, c.privateKeyFile} {
		if !socialLoginCleanFilePath(path) || strings.ContainsRune(path, '\x00') || seen[path] {
			return false
		}
		seen[path] = true
	}
	for _, digest := range []string{c.owner.RootDigest, c.owner.CertificateDigest, c.owner.NodeConfigDigest, c.owner.ExpectedNodeConfigDigest} {
		if !socialM1QAStartupDigestValid(digest) {
			return false
		}
	}
	if c.owner.NodeConfigDigest != c.owner.ExpectedNodeConfigDigest {
		return false
	}
	for _, size := range []int64{c.owner.RootBytes, c.owner.CertificateBytes, c.owner.NodeConfigBytes} {
		if size < 1 || size > 16384 {
			return false
		}
	}
	return true
}

func validSocialM1QAOperationProvisioning(c *socialM1QAOperationProvisioning, login socialLoginRuntimeConfig) bool {
	if !validSocialM1QAOperationMetadata(c) || c.owner.Now == nil || login.Profile != "protected-backend-software-pkcs8-v1" || len(login.PublicKey) != ed25519.PublicKeySize || c.keyID == login.KeyID || bytes.Equal(c.public, login.PublicKey) {
		return false
	}
	for _, path := range []string{c.owner.RootPath, c.owner.CertificatePath, c.owner.NodeConfigPath, c.privateKeyFile} {
		for _, other := range []string{login.PrivateKeyFile, login.Store.Directory, login.Store.SealKeyFile, login.ChallengeDirectory, login.EnrollmentDirectory} {
			if path == other {
				return false
			}
		}
	}
	return true
}

func (r *socialLoginRuntime) retainM1QAOperationOwner(owner *centralbrowserfamily.SocialM1QAOperationOwner) error {
	if r == nil {
		return kernel.ErrSocialAccountOperationConfiguration
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.retainM1QAOperationOwnerLocked(owner)
}

// The startup goroutine retains the owner even before native source creation.
// Identity may be observed again, but custody cannot be replaced or transferred
// a second time, including after an uncertain constructor or cleanup result.
func (r *socialLoginRuntime) retainM1QAOperationOwnerLocked(owner *centralbrowserfamily.SocialM1QAOperationOwner) error {
	if owner == nil || r.closeStarted || r.operationOwnerTransferred || r.accountOperation != nil || r.releases.accountOperation != nil {
		return kernel.ErrSocialAccountOperationConfiguration
	}
	if r.operationOwner != nil {
		if r.operationOwner != owner || r.releases.operationOwner != owner {
			return kernel.ErrSocialAccountOperationConfiguration
		}
		return nil
	}
	if r.releases.operationOwner != nil {
		return kernel.ErrSocialAccountOperationConfiguration
	}
	r.operationOwner, r.releases.operationOwner = owner, owner
	return nil
}

func (r *socialLoginRuntime) provisionM1QAOperation(ctx context.Context, c *socialM1QAOperationProvisioning, login socialLoginRuntimeConfig) (*socialM1QAOperationStartupSelection, error) {
	if r == nil || ctx == nil {
		return nil, kernel.ErrSocialAccountOperationConfiguration
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.closeStarted || r.operationProvisionAttempted || r.operationOwner != nil || r.operationProvider != nil || r.releases.operationOwner != nil || r.releases.operationProvider != nil || r.accountOperation != nil || r.releases.accountOperation != nil {
		return nil, kernel.ErrSocialAccountOperationConfiguration
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	r.operationProvisionAttempted = true
	if !validSocialM1QAOperationProvisioning(c, login) || r.m1qaProfile == nil || r.provider == nil || r.service == nil {
		return nil, kernel.ErrSocialAccountOperationConfiguration
	}
	if err := r.m1qaProfile.Current(ctx); err != nil {
		return nil, err
	}
	loginID, loginPublic, err := r.m1qaProfile.BackendSignerPublic()
	if err != nil {
		return nil, err
	}
	if loginID != login.KeyID || !bytes.Equal(loginPublic, login.PublicKey) {
		return nil, kernel.ErrSocialAccountOperationConfiguration
	}
	provider, err := kernel.OpenSocialLoginSoftwareSigningProvider(c.privateKeyFile, c.public)
	if provider != nil {
		r.operationProvider, r.releases.operationProvider = provider, provider
	}
	if err != nil {
		return nil, err
	}
	if provider == nil {
		return nil, kernel.ErrSocialAccountOperationConfiguration
	}
	if err = ctx.Err(); err != nil {
		return nil, err
	}
	owner, err := centralbrowserfamily.OpenSocialM1QAOperationOwner(c.owner, c.keyID, c.public, provider)
	if owner != nil {
		r.operationOwner, r.releases.operationOwner = owner, owner
	}
	if err != nil {
		return nil, err
	}
	if owner == nil {
		return nil, kernel.ErrSocialAccountOperationConfiguration
	}
	if err = ctx.Err(); err != nil {
		return nil, err
	}
	if err = r.m1qaProfile.Current(ctx); err != nil {
		return nil, err
	}
	return &socialM1QAOperationStartupSelection{owner: owner, originalNow: c.owner.Now}, nil
}
