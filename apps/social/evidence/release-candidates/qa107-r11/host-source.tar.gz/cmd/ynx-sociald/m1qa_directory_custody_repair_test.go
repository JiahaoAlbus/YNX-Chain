package main

import (
	"context"
	"errors"
	"testing"
)

type mfdFailedRelease struct {
	calls int
	err   error
}

func (f *mfdFailedRelease) Close() error { f.calls++; return f.err }
func TestMFDRuntimeReleaseRetainsBothCauses(t *testing.T) {
	primary := errors.New("PUBLIC construction rejection")
	secondary := errors.New("PUBLIC close uncertainty")
	resource := &mfdFailedRelease{err: errors.Join(primary, secondary)}
	r := &socialLoginRuntime{}
	r.releases.authority = resource
	for i := 0; i < 3; i++ {
		e := r.Close(context.Background())
		if !errors.Is(e, primary) || !errors.Is(e, secondary) || resource.calls != 1 || r.releases.authority != resource {
			t.Fatal("runtime discarded owner/cause or retried")
		}
	}
}
