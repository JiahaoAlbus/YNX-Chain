package main

import (
	"context"
	"encoding/hex"
	"errors"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"time"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

func main() {
	httpAddr := flag.String("http", envOrDefault("YNX_SOCIAL_HTTP_ADDR", "127.0.0.1:6491"), "Social HTTP listen address")
	checkConfig := flag.Bool("check-config", false, "check public source-authority inputs without starting the service")
	authorityFile := flag.String("source-authority-file", os.Getenv("YNX_SOCIAL_SOURCE_AUTHORITY_FILE"), "public source registration carrier; never a private key or an implicit enrollment")
	flag.Parse()
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	loadCtx, cancel := context.WithTimeout(ctx,30*time.Second)
	sourceRuntime, sourceErr := kernel.LoadSourceAuthority(loadCtx,*authorityFile)
	cancel()
	if *checkConfig {
		if sourceErr!=nil {
			fmt.Println("ynx-sociald new-core source authority REQUIRED; no signer, enrollment, or runtime activation performed")
			return
		}
		fmt.Println("ynx-sociald public source inputs validated; native composition and private communication still REQUIRED")
		return
	}
	if sourceErr!=nil { log.Print("new-core source authority REQUIRED; private operations fail closed") }
	// New builds do not construct Chat/Square/legacy Social or touch their
	// state. This dormant new-core entry cannot silently route to old crypto.
	server := &http.Server{Addr: *httpAddr, Handler: sourceRuntime.Handler(), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 45 * time.Second, WriteTimeout: 45 * time.Second, IdleTimeout: 60 * time.Second, MaxHeaderBytes: 32 * 1024}
	go func() {
		<-ctx.Done()
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
		defer cancel()
		_ = server.Shutdown(shutdownCtx)
	}()
	log.Printf("YNX Social new-core candidate at http://%s; private communication unavailable pending genuine supplier composition", *httpAddr)
	if err := server.ListenAndServe(); !errors.Is(err, http.ErrServerClosed) {
		log.Fatal(err)
	}
}

func decodeKey(name string) ([]byte, error) {
	value := strings.TrimSpace(os.Getenv(name))
	decoded, err := hex.DecodeString(value)
	if err != nil || len(decoded) < 32 {
		return nil, fmt.Errorf("%s must be hex encoding of at least 32 bytes", name)
	}
	return decoded, nil
}

// The deployment owner supplies a public, existing-user mapping, not secrets.
// Absence keeps legacy service operational but Matrix metadata fails closed.
func loadMatrixDirectory(path string) (*social.MatrixDirectory, error) {
	if path == "" {
		return nil, nil
	}
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	return social.ParseMatrixDirectory(file)
}

func envOrDefault(key, fallback string) string {
	if value := strings.TrimSpace(os.Getenv(key)); value != "" {
		return value
	}
	return fallback
}

func envInt(key string, fallback int) (int, error) {
	value := strings.TrimSpace(os.Getenv(key))
	if value == "" {
		return fallback, nil
	}
	parsed, err := strconv.Atoi(value)
	if err != nil {
		return 0, fmt.Errorf("%s must be an integer", key)
	}
	return parsed, nil
}
