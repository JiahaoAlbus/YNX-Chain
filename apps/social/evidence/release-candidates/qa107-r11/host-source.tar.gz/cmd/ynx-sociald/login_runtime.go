package main

import (
	"context"
	"errors"
	"github.com/JiahaoAlbus/YNX-Chain/internal/centralbrowserfamily"
	"log"
	"net/http"
	"os"
	"sync"
	"time"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

// Private release custody only; these interfaces cannot authorize requests.
type socialContextRelease interface{ Close(context.Context) error }
type socialRelease interface{ Close() error }
type socialRuntimeReleases struct {
	service                                     socialContextRelease
	authority, challenges, enrollment, provider socialRelease
	producer                                    socialRelease
	accountOperation                            socialRelease
	operationOwner                              socialRelease
	operationProvider                           socialRelease
	nativePublisher                             socialRelease
	nativeSource                                socialRelease
}

type socialLoginRuntime struct {
	m1qaProfile                 *centralbrowserfamily.SocialM1QATrustedProfile
	accountOperation            *kernel.SocialAccountOperationRuntime
	operationOwner              *centralbrowserfamily.SocialM1QAOperationOwner
	operationProvider           *kernel.SocialLoginSoftwareSigningProvider
	operationProvisionAttempted bool
	operationOwnerTransferred   bool
	nativePublisher             *kernel.SocialNativeAccountPublisher
	nativeSource                *centralbrowserfamily.SocialNativeInstanceSource
	releases                    socialRuntimeReleases
	authority                   *kernel.FirstDeviceEnrollmentService
	sourceProducer              *kernel.SourceIssuanceProducer
	challenges                  *kernel.FirstDeviceAuthorizationStore
	enrollment                  *kernel.FirstDeviceEnrollmentStore
	service                     *kernel.SocialLoginService
	provider                    *kernel.SocialLoginSoftwareSigningProvider
	mu                          sync.Mutex
	closeStarted                bool
	closeDone                   chan struct{}
	closeErr                    error
}

// Owned by the normal main goroutine; never a request-scoped runtime factory.
var normalSocialLoginRuntime *socialLoginRuntime

func openSocialLoginRuntime(config socialLoginRuntimeConfig) (*socialLoginRuntime, error) {
	if config.Profile != "protected-backend-software-pkcs8-v1" {
		return nil, errSocialLoginRuntimeConfig
	}
	provider, err := kernel.OpenSocialLoginSoftwareSigningProvider(config.PrivateKeyFile, config.PublicKey)
	if err != nil {
		return nil, err
	}
	r := &socialLoginRuntime{provider: provider}
	r.releases.provider = provider
	signer, err := kernel.NewSocialLoginBackendSigner(config.KeyID, config.PublicKey, provider)
	if err != nil {
		return r.constructionFailed(err)
	}
	r.service, err = kernel.OpenSocialLoginService(config.Store, signer)
	if r.service != nil {
		r.releases.service = r.service
	}
	if err != nil {
		return r.constructionFailed(err)
	}
	return r.openDependentStores(config)
}

// Continues the same acquired service/provider owner; no new runtime or signer.
func (r *socialLoginRuntime) openDependentStores(config socialLoginRuntimeConfig) (*socialLoginRuntime, error) {
	var err error
	if config.ChallengeDirectory != "" {
		r.challenges, err = kernel.OpenFirstDeviceAuthorizationStore(config.ChallengeDirectory)
		if r.challenges != nil {
			r.releases.challenges = r.challenges
		}
		if err != nil {
			return r.constructionFailed(err)
		}
	}
	if config.EnrollmentDirectory != "" {
		if r.challenges == nil {
			return r.constructionFailed(errSocialLoginRuntimeConfig)
		}
		r.enrollment, err = kernel.OpenFirstDeviceEnrollmentStore(config.EnrollmentDirectory)
		if r.enrollment != nil {
			r.releases.enrollment = r.enrollment
		}
		if err != nil {
			return r.constructionFailed(err)
		}
	}
	return r, nil
}

func (r *socialLoginRuntime) constructionFailed(primary error) (*socialLoginRuntime, error) {
	// Always return original custody, including uncertain cleanup. Close caches
	// its result and never retries a resource or replaces the original owner.
	return r, errors.Join(primary, r.Close(context.Background()))
}

func retainNormalSocialRuntime(r *socialLoginRuntime, err error) error {
	if r != nil {
		normalSocialLoginRuntime = r
	}
	return err
}

func newSocialProductHandler(fallback http.Handler) *kernel.SocialProductHandler {
	config, enabled, err := loadSocialLoginRuntimeConfig(os.LookupEnv)
	if err != nil {
		log.Fatal("Social login configuration refused; no fallback enabled")
	}
	if !enabled {
		return kernel.NewSocialProductHandler(fallback)
	}
	if normalSocialLoginRuntime != nil {
		log.Fatal("Social login runtime already owned")
	}
	runtime, err := openSocialLoginRuntime(config)
	err = retainNormalSocialRuntime(runtime, err)
	if err != nil {
		log.Fatal("Social login protected runtime unavailable; no fallback enabled")
	}
	normalSocialLoginRuntime = runtime
	handler, err := runtime.service.FirstDeviceProductHandler(fallback, runtime.challenges, runtime.enrollment)
	if err != nil {
		_ = waitSocialLoginRuntimeClose(runtime)
		log.Fatal("Social first-device consumer unavailable; no fallback enabled")
	}
	return handler
}

// Retain one cleanup worker spanning service drain and provider close. The
// provider cannot be cleared while admitted service signing still owns it.
func (r *socialLoginRuntime) Close(ctx context.Context) error {
	if r == nil {
		return nil
	}
	if ctx == nil {
		return errSocialLoginRuntimeConfig
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	r.mu.Lock()
	if !r.closeStarted {
		r.closeStarted = true
		r.closeDone = make(chan struct{})
		go func() {
			var err error
			if r.releases.service != nil {
				err = r.releases.service.Close(context.Background())
			}
			if err == nil && r.releases.accountOperation != nil {
				err = r.releases.accountOperation.Close()
			}
			if err == nil && r.releases.operationOwner != nil {
				err = r.releases.operationOwner.Close()
			}
			if err == nil && r.releases.nativePublisher != nil {
				err = r.releases.nativePublisher.Close()
			}
			if err == nil && r.releases.nativeSource != nil {
				err = r.releases.nativeSource.Close()
			}
			if err == nil && r.releases.producer != nil {
				err = r.releases.producer.Close()
			}
			if err == nil && r.releases.authority != nil {
				err = r.releases.authority.Close()
			}
			if err == nil && r.releases.challenges != nil {
				err = r.releases.challenges.Close()
			}
			if err == nil && r.releases.enrollment != nil {
				err = r.releases.enrollment.Close()
			}
			if err == nil && r.releases.operationProvider != nil {
				err = r.releases.operationProvider.Close()
			}
			if err == nil && r.releases.provider != nil {
				err = r.releases.provider.Close()
			}

			if err == nil && r.m1qaProfile != nil {
				err = r.m1qaProfile.Close()
			}
			r.mu.Lock()
			r.closeErr = err
			close(r.closeDone)
			r.mu.Unlock()
		}()
	}
	done := r.closeDone
	r.mu.Unlock()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-done:
		r.mu.Lock()
		err := r.closeErr
		r.mu.Unlock()
		return err
	}
}

func closeNormalSocialLoginRuntime() {
	if err := closeNormalM1QALoginRuntime(context.Background()); err != nil {
		log.Fatal("M1 QA login shutdown outcome uncertain; original owners retained")
	}
	if err := waitSocialLoginRuntimeClose(normalSocialLoginRuntime); err != nil {
		log.Fatal("Social login shutdown outcome uncertain; operator inspection required")
	}
}

// A caller deadline only bounds observation. Once the original cleanup has
// settled, its cached result (including a deadline error) is the terminal result.
func (runtime *socialLoginRuntime) settledCloseResult() (error, bool) {
	runtime.mu.Lock()
	defer runtime.mu.Unlock()
	select {
	case <-runtime.closeDone:
		return runtime.closeErr, true
	default:
		return nil, false
	}
}

func waitSocialLoginRuntimeClose(runtime *socialLoginRuntime) error {
	if runtime == nil {
		return nil
	}
	for {
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		err := runtime.Close(ctx)
		cancel()
		if errors.Is(err, context.DeadlineExceeded) {
			if original, settled := runtime.settledCloseResult(); settled {
				return original
			}
			log.Print("Social login shutdown still owns unfinished work; waiting without replacement")
			continue
		}
		return err
	}
}
