package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/x509"
	"encoding/pem"
	"math/big"
	"net/http"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestSocialTLSConfigurationBoundary(t *testing.T) {
	cases := []struct {
		name, cert, key string
		absent, invalid bool
	}{
		{name: "disabled", absent: true},
		{name: "certificate-only", cert: "/public-test/cert.pem", invalid: true},
		{name: "key-only", key: "/public-test/key.pem", invalid: true},
		{name: "relative-certificate", cert: "cert.pem", key: "/public-test/key.pem", invalid: true},
		{name: "relative-key", cert: "/public-test/cert.pem", key: "key.pem", invalid: true},
		{name: "unclean-path", cert: "/public-test/../cert.pem", key: "/public-test/key.pem", invalid: true},
		{name: "explicit-pair", cert: "/public-test/cert.pem", key: "/public-test/key.pem"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			values := map[string]string{}
			if tc.cert != "" {
				values["YNX_SOCIAL_TLS_CERT_FILE"] = tc.cert
			}
			if tc.key != "" {
				values["YNX_SOCIAL_TLS_KEY_FILE"] = tc.key
			}
			config, err := loadSocialServerTLSConfig(func(name string) (string, bool) { value, ok := values[name]; return value, ok })
			if (err != nil) != tc.invalid {
				t.Fatalf("invalid=%t error=%v", tc.invalid, err)
			}
			if !tc.invalid && config.enabled == tc.absent {
				t.Fatal("incorrect explicit TLS activation state")
			}
		})
	}
}

func TestSocialTLSInvalidCertificateClosesRuntime(t *testing.T) {
	for _, scenario := range []string{"wrong-hostname", "expired", "not-yet-valid", "mismatched-key", "malformed-certificate"} {
		t.Run(scenario, func(t *testing.T) {
			config := publicSocialLoginRuntimeConfig(t)
			runtime, err := openSocialLoginRuntime(config)
			if err != nil {
				t.Fatal(err)
			}
			t.Cleanup(func() { _ = waitSocialLoginRuntimeClose(runtime) })
			// Public deterministic test material only, including the mismatched key.
			key := ed25519.NewKeyFromSeed(bytes.Repeat([]byte{0x61}, ed25519.SeedSize))
			now := time.Now()
			cert := &x509.Certificate{SerialNumber: big.NewInt(11), DNSNames: []string{"social.ynxweb4.com"}, NotBefore: now.Add(-time.Hour), NotAfter: now.Add(time.Hour), KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
			if scenario == "wrong-hostname" {
				cert.DNSNames = []string{"not-social.invalid"}
			}
			if scenario == "expired" {
				cert.NotAfter = now.Add(-time.Minute)
			}
			if scenario == "not-yet-valid" {
				cert.NotBefore = now.Add(time.Minute)
			}
			der, err := x509.CreateCertificate(nil, cert, cert, key.Public(), key)
			if err != nil {
				t.Fatal(err)
			}
			certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
			if scenario == "malformed-certificate" {
				certPEM = []byte("PUBLIC TEST INVALID CERTIFICATE")
			}
			if scenario == "mismatched-key" {
				key = ed25519.NewKeyFromSeed(bytes.Repeat([]byte{0x62}, ed25519.SeedSize))
			}
			keyDER, err := x509.MarshalPKCS8PrivateKey(key)
			if err != nil {
				t.Fatal(err)
			}
			dir, err := filepath.EvalSymlinks(t.TempDir())
			if err != nil {
				t.Fatal(err)
			}
			certPath, keyPath := filepath.Join(dir, "test-cert.pem"), filepath.Join(dir, "test-key.pem")
			if err := os.WriteFile(certPath, certPEM, 0600); err != nil {
				t.Fatal(err)
			}
			if err := os.WriteFile(keyPath, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: keyDER}), 0600); err != nil {
				t.Fatal(err)
			}
			server := &http.Server{Addr: "127.0.0.1:0", Handler: runtime.service.ProductHandler(nil)}
			if err := runSocialHTTPServer(server, runtime, socialServerTLSConfig{certificate: certPath, key: keyPath, enabled: true}, nil); err == nil {
				t.Fatal("invalid TLS material accepted")
			}
			if _, err := runtime.provider.SignEd25519(context.Background(), []byte("PUBLIC TEST ONLY")); err == nil {
				t.Fatal("provider remained active after TLS rejection")
			}
			reopened, err := openSocialLoginRuntime(config)
			if err != nil {
				t.Fatal(err)
			}
			if err := waitSocialLoginRuntimeClose(reopened); err != nil {
				t.Fatal(err)
			}
		})
	}
}
