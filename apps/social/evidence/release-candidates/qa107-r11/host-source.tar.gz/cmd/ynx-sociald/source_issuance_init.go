package main

import (
	"errors"
	"flag"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

const sourceIssuanceInitFlag = "init-source-issuance-journal"

func registerSourceIssuanceInitializationFlag(fs *flag.FlagSet) {
	fs.String(sourceIssuanceInitFlag, "", "Explicitly create a new Social-only issuance journal in an existing private directory and exit; no source registration or signing")
}

func handleSourceIssuanceInitialization(fs *flag.FlagSet) (bool, error) {
	var requested, other bool
	fs.Visit(func(f *flag.Flag) {
		if f.Name == sourceIssuanceInitFlag {
			requested = true
		} else {
			other = true
		}
	})
	if !requested {
		return false, nil
	}
	if other || fs.NArg() != 0 {
		return true, errors.New("Social issuance initialization requires its single flag and no other arguments")
	}
	path := fs.Lookup(sourceIssuanceInitFlag).Value.String()
	if !socialLoginCleanFilePath(path) {
		return true, errors.New("Social issuance initialization requires a clean absolute non-root journal path")
	}
	// Initialization is never reached from ordinary startup, Open failure,
	// check-config, retry, reconciliation or a request handler.
	return true, kernel.ProvisionSourceIssuanceJournal(path)
}
