package main

import (
	"bytes"
	"flag"
	"io"
	"os"
	"path/filepath"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

func firstDeviceInitFlags(t *testing.T, args ...string) *flag.FlagSet {
	t.Helper()
	fs := flag.NewFlagSet("social-challenge-init", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	registerFirstDeviceChallengeInitializationFlag(fs)
	registerSocialLoginInitializationFlags(fs)
	fs.Bool("check-config", false, "test existing mode")
	fs.String("init-first-device-enrollment-dir", "", "test existing mode")
	if err := fs.Parse(args); err != nil {
		t.Fatal(err)
	}
	return fs
}

func TestFirstDeviceChallengeInitializationExplicitAndPreserved(t *testing.T) {
	dir := t.TempDir()
	if err := os.Chmod(dir, 0700); err != nil {
		t.Fatal(err)
	}
	if handled, err := handleFirstDeviceChallengeInitialization(firstDeviceInitFlags(t)); handled || err != nil {
		t.Fatal("initialization became implicit", err)
	}
	fs := firstDeviceInitFlags(t, "-"+firstDeviceChallengeInitFlag, dir)
	if handled, err := handleFirstDeviceChallengeInitialization(fs); !handled || err != nil {
		t.Fatal("explicit provisioning failed", err)
	}
	journal := filepath.Join(dir, "first-device-challenges.journal")
	before, err := os.ReadFile(journal)
	if err != nil {
		t.Fatal(err)
	}
	store, err := kernel.OpenFirstDeviceAuthorizationStore(dir)
	if err != nil {
		t.Fatal("normal runtime cannot open initialized journal", err)
	}
	if err := store.Close(); err != nil {
		t.Fatal(err)
	}
	if handled, err := handleFirstDeviceChallengeInitialization(fs); !handled || err == nil {
		t.Fatal("repeated initialization overwrote the journal")
	}
	after, err := os.ReadFile(journal)
	if err != nil || !bytes.Equal(before, after) {
		t.Fatal("refused initialization changed original bytes", err)
	}
}

func TestFirstDeviceChallengeInitializationRejectsMixedModes(t *testing.T) {
	for _, extra := range [][]string{
		{"-check-config"}, {"-init-first-device-enrollment-dir", "/unused"},
		{"-" + loginInitDirectoryFlag, "/unused"}, {"unexpected-positional"},
	} {
		dir := t.TempDir()
		args := append([]string{"-" + firstDeviceChallengeInitFlag, dir}, extra...)
		if handled, err := handleFirstDeviceChallengeInitialization(firstDeviceInitFlags(t, args...)); !handled || err == nil {
			t.Fatal("mixed initialization accepted")
		}
		if _, err := os.Stat(filepath.Join(dir, "first-device-challenges.journal")); !os.IsNotExist(err) {
			t.Fatal("mixed command created storage", err)
		}
	}
	for _, path := range []string{"", "/", "relative", "/tmp/../unused"} {
		if handled, err := handleFirstDeviceChallengeInitialization(firstDeviceInitFlags(t, "-"+firstDeviceChallengeInitFlag, path)); !handled || err == nil {
			t.Fatal("invalid provisioning path accepted")
		}
	}
}
