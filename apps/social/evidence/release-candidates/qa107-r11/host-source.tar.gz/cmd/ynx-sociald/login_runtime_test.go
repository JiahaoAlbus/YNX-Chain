package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/x509"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

func publicSocialLoginRuntimeConfig(t *testing.T) socialLoginRuntimeConfig {
	t.Helper()
	parent, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(parent, 0700); err != nil {
		t.Fatal(err)
	}
	// Published TEST ONLY material, never operator or user identity keys.
	private := ed25519.NewKeyFromSeed(bytes.Repeat([]byte{0x42}, ed25519.SeedSize))
	encoded, err := x509.MarshalPKCS8PrivateKey(private)
	if err != nil {
		t.Fatal(err)
	}
	keyPath := filepath.Join(parent, "PUBLIC-TEST-ONLY.pk8")
	if err := os.WriteFile(keyPath, encoded, 0600); err != nil {
		t.Fatal(err)
	}
	seal := filepath.Join(parent, "PUBLIC-TEST-ONLY.seal")
	if err := os.WriteFile(seal, make([]byte, 32), 0600); err != nil {
		t.Fatal(err)
	}
	store := kernel.SocialLoginServiceConfig{Directory: filepath.Join(parent, "transactions"), SealKeyFile: seal}
	if err := kernel.ProvisionSocialLoginTransactions(store.Directory, store.SealKeyFile); err != nil {
		t.Fatal(err)
	}
	return socialLoginRuntimeConfig{Profile: "protected-backend-software-pkcs8-v1", Store: store, KeyID: "PUBLIC_TEST_ONLY", PublicKey: private.Public().(ed25519.PublicKey), PrivateKeyFile: keyPath}
}

func TestSocialLoginRuntimeHostLoopbackTLS(t *testing.T) {
	config := publicSocialLoginRuntimeConfig(t)
	runtime, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal(err)
	}
	defer runtime.Close(context.Background())
	handler := runtime.service.ProductHandler(nil)
	defer handler.CloseIdleConnections()
	// A real loopback TLS listener and verified test-client trust, not public
	// deployment or Central consent. Only local start is exercised; no redirect
	// is navigated and no token-family request or account operation occurs.
	server := httptest.NewTLSServer(handler)
	defer server.Close()
	request, err := http.NewRequest(http.MethodPost, server.URL+"/v4/login/start", strings.NewReader(`{"intent":"A"}`))
	if err != nil {
		t.Fatal(err)
	}
	request.Host = "social.ynxweb4.com"
	request.Header.Set("Origin", kernel.SocialLoginOrigin)
	request.Header.Set("Content-Type", "application/json")
	response, err := server.Client().Do(request)
	if err != nil {
		t.Fatal(err)
	}
	body, readErr := io.ReadAll(io.LimitReader(response.Body, 8193))
	closeErr := response.Body.Close()
	if readErr != nil || closeErr != nil || response.StatusCode != 200 || !strings.Contains(string(body), "authorizeUrl") || len(response.Cookies()) != 2 {
		t.Fatalf("loopback startup route failed: status=%d read=%v close=%v", response.StatusCode, readErr, closeErr)
	}
	if err := runtime.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
	if err := runtime.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
	if _, err := runtime.provider.SignEd25519(context.Background(), []byte("PUBLIC_FIXTURE")); err == nil {
		t.Fatal("provider usable after runtime close")
	}
	// Existing state can be opened again only after the original owner drained.
	reopened, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal(err)
	}
	if err := reopened.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
}

func TestSocialLoginRuntimeHostRefusesInvalidInputs(t *testing.T) {
	base := publicSocialLoginRuntimeConfig(t)
	for _, name := range []string{"profile-required", "missing-key", "wrong-public", "missing-store"} {
		t.Run(name, func(t *testing.T) {
			config := base
			switch name {
			case "profile-required":
				config.Profile = ""
			case "missing-key":
				config.PrivateKeyFile = filepath.Join(filepath.Dir(base.PrivateKeyFile), "absent-key")
			case "wrong-public":
				config.PublicKey = make([]byte, 32)
			case "missing-store":
				config.Store.Directory = filepath.Join(filepath.Dir(base.Store.Directory), "absent-store")
			}
			if runtime, err := openSocialLoginRuntime(config); err == nil {
				_ = runtime.Close(context.Background())
				t.Fatal("invalid runtime admitted")
			}
		})
	}
}

func TestSocialLoginRuntimeChallengeStoreLifecycleAndTLS(t *testing.T) {
	config := publicSocialLoginRuntimeConfig(t)
	config.ChallengeDirectory = filepath.Join(filepath.Dir(config.PrivateKeyFile), "challenge-store")
	if runtime, err := openSocialLoginRuntime(config); err == nil {
		_ = runtime.Close(context.Background())
		t.Fatal("missing challenge directory admitted")
	}
	if _, err := os.Stat(config.ChallengeDirectory); !os.IsNotExist(err) {
		t.Fatal("startup created missing challenge directory", err)
	}
	if err := os.Mkdir(config.ChallengeDirectory, 0700); err != nil {
		t.Fatal(err)
	}
	if runtime, err := openSocialLoginRuntime(config); err == nil {
		_ = runtime.Close(context.Background())
		t.Fatal("empty challenge directory provisioned implicitly")
	}
	if _, err := os.Stat(filepath.Join(config.ChallengeDirectory, "first-device-challenges.journal")); !os.IsNotExist(err) {
		t.Fatal("Open created missing journal", err)
	}
	if err := kernel.ProvisionFirstDeviceAuthorizationStore(config.ChallengeDirectory); err != nil {
		t.Fatal(err)
	}
	runtime, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal("failed open retained a replacement-blocking resource", err)
	}
	defer runtime.Close(context.Background())
	if other, err := kernel.OpenFirstDeviceAuthorizationStore(config.ChallengeDirectory); err == nil {
		_ = other.Close()
		t.Fatal("challenge store admitted a second owner")
	}
	handler, err := runtime.service.FirstDeviceProductHandler(nil, runtime.challenges)
	if err != nil {
		t.Fatal(err)
	}
	defer handler.CloseIdleConnections()
	server := httptest.NewTLSServer(handler)
	defer server.Close()
	post := func(path, body string, cookies []*http.Cookie) (int, string, []*http.Cookie) {
		t.Helper()
		request, err := http.NewRequest(http.MethodPost, server.URL+path, strings.NewReader(body))
		if err != nil {
			t.Fatal(err)
		}
		request.Host = "social.ynxweb4.com"
		request.Header.Set("Origin", kernel.SocialLoginOrigin)
		request.Header.Set("Content-Type", "application/json")
		for _, cookie := range cookies {
			request.AddCookie(cookie)
		}
		response, err := server.Client().Do(request)
		if err != nil {
			t.Fatal(err)
		}
		data, readErr := io.ReadAll(io.LimitReader(response.Body, 8193))
		closeErr := response.Body.Close()
		if readErr != nil || closeErr != nil {
			t.Fatal("response incomplete", readErr, closeErr)
		}
		return response.StatusCode, string(data), response.Cookies()
	}
	status, _, cookies := post("/v4/login/start", `{"intent":"A"}`, nil)
	if status != 200 || len(cookies) != 2 {
		t.Fatal("normal local login start failed", status)
	}
	// A real local pending login is NOT a Central-authenticated account. Do not
	// navigate consent, inject a family or contact the fixed remote introspector.
	status, body, _ := post("/v4/first-device/challenge", `{"operation":"pending-login","proposal":"cHVibGlj"}`, cookies)
	if status != http.StatusConflict || !strings.Contains(body, "ORIGINAL_OPERATION_UNAVAILABLE") || !strings.Contains(body, `"deviceAuthorization":"REQUIRED"`) {
		t.Fatal("unverified login crossed the challenge boundary", status)
	}
	if err := runtime.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
	if _, err := runtime.provider.SignEd25519(context.Background(), []byte("PUBLIC_FIXTURE")); err == nil {
		t.Fatal("provider remained usable after completed close")
	}
	reopened, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal("normal close did not release original stores", err)
	}
	if err := reopened.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
}

func TestSocialLoginRuntimeEnrollmentDirectoryOwnership(t *testing.T) {
	config := publicSocialLoginRuntimeConfig(t)
	parent := filepath.Dir(config.PrivateKeyFile)
	config.ChallengeDirectory = filepath.Join(parent, "challenges")
	config.EnrollmentDirectory = filepath.Join(parent, "enrollment")
	if err := os.Mkdir(config.ChallengeDirectory, 0700); err != nil {
		t.Fatal(err)
	}
	if err := kernel.ProvisionFirstDeviceAuthorizationStore(config.ChallengeDirectory); err != nil {
		t.Fatal(err)
	}
	if runtime, err := openSocialLoginRuntime(config); err == nil {
		_ = runtime.Close(context.Background())
		t.Fatal("missing enrollment directory admitted")
	}
	if _, err := os.Stat(config.EnrollmentDirectory); !os.IsNotExist(err) {
		t.Fatal("missing enrollment directory recreated", err)
	}
	if err := kernel.ProvisionFirstDeviceEnrollmentDirectory(config.EnrollmentDirectory); err != nil {
		t.Fatal(err)
	}
	runtime, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal("failed initial open leaked earlier resources", err)
	}
	defer runtime.Close(context.Background())
	if other, err := kernel.OpenFirstDeviceEnrollmentStore(config.EnrollmentDirectory); err == nil {
		_ = other.Close()
		t.Fatal("directory admitted a second owner")
	}
	handler, err := runtime.service.FirstDeviceProductHandler(nil, runtime.challenges, runtime.enrollment)
	if err != nil {
		t.Fatal(err)
	}
	handler.CloseIdleConnections()
	if err := runtime.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
	reopened, err := openSocialLoginRuntime(config)
	if err != nil {
		t.Fatal("completed shutdown retained an enrollment lock", err)
	}
	if err := reopened.Close(context.Background()); err != nil {
		t.Fatal(err)
	}
}
