package main

import (
	"encoding/base64"
	"testing"
)

func TestAccountNormalConfigurationSeparatesSigner(t *testing.T){
	login:=socialLoginRuntimeConfig{PrivateKeyFile:"/private/login.der",KeyID:"login",PublicKey:make([]byte,32)}
	pub:=make([]byte,32);pub[0]=1 // PUBLIC bytes, no keypair.
	m:=map[string]string{"YNX_SOCIAL_ACCOUNT_OPERATION_KEY_ID":"new-purpose","YNX_SOCIAL_ACCOUNT_OPERATION_PRIVATE_KEY_FILE":"/private/operation.der","YNX_SOCIAL_ACCOUNT_OPERATION_PUBLIC_KEY":base64.RawURLEncoding.EncodeToString(pub)}
	lookup:=func(k string)(string,bool){v,ok:=m[k];return v,ok}
	if c,err:=loadAccountOperationStartup(lookup,login,firstEnrollmentStartup{mode:"authority-v3"});err!=nil||!c.enabled{t.Fatal(err)}
	m["YNX_SOCIAL_ACCOUNT_OPERATION_PRIVATE_KEY_FILE"]=login.PrivateKeyFile
	if _,err:=loadAccountOperationStartup(lookup,login,firstEnrollmentStartup{mode:"authority-v3"});err==nil{t.Fatal("login key reused")}
	m["YNX_SOCIAL_ACCOUNT_OPERATION_PRIVATE_KEY_FILE"]="/private/operation.der"
	m["YNX_SOCIAL_ACCOUNT_OPERATION_PUBLIC_KEY"]=base64.RawURLEncoding.EncodeToString(login.PublicKey)
	if _,err:=loadAccountOperationStartup(lookup,login,firstEnrollmentStartup{mode:"authority-v3"});err==nil{t.Fatal("login public identity reused")}
	delete(m,"YNX_SOCIAL_ACCOUNT_OPERATION_KEY_ID")
	if _,err:=loadAccountOperationStartup(lookup,login,firstEnrollmentStartup{mode:"authority-v3"});err==nil{t.Fatal("partial config accepted")}
	if c,err:=loadAccountOperationStartup(func(string)(string,bool){return "",false},login,firstEnrollmentStartup{});err!=nil||c.enabled{t.Fatal("missing must stay unconfigured")}
}
