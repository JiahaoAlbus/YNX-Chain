package main

import (
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/centralbrowserfamily"
	"os"
	"path/filepath"
	"testing"
)

// No fixture registration is issued. These exercise the actual startup body
// and retention on its missing/zero-source boundary, before provider file IO.
func TestM1QANormalStartupOwnedConsumer(t *testing.T) {
	original, originalQA := normalSocialLoginRuntime, normalM1QALoginRuntime
	normalSocialLoginRuntime, normalM1QALoginRuntime = nil, nil
	defer func() { normalSocialLoginRuntime, normalM1QALoginRuntime = original, originalQA }()
	cfg := socialLoginRuntimeConfig{}
	cfg.PrivateKeyFile = filepath.Join(t.TempDir(), "must-not-open")
	if r, err := openSocialM1QALoginRuntime(context.Background(), cfg, nil); err == nil || r != nil {
		t.Fatal("nil source acquired runtime")
	}
	source := new(centralbrowserfamily.SocialM1QATrustedProfile)
	r, err := openSocialM1QALoginRuntime(context.Background(), cfg, source)
	if err == nil || r == nil || r.m1qaProfile != source || r.provider != nil || r.service != nil {
		t.Fatal("partial original source ownership lost")
	}
	if _, err = os.Stat(cfg.PrivateKeyFile); !os.IsNotExist(err) {
		t.Fatal("refusal created credential")
	}
	// The original startup composition retains this partial owner before failure.
	lookup := func(string) (string, bool) { return "", false }
	if h, err := openNormalSocialProduct(context.Background(), nil, lookup, r); err == nil || h != nil {
		t.Fatal("unissued runtime mounted")
	}
	if normalM1QALoginRuntime != r {
		t.Fatal("lost exact failed runtime")
	}
	if h, err := openNormalSocialProduct(context.Background(), nil, lookup, r); err == nil || h != nil {
		t.Fatal("duplicate startup")
	}
	if err = closeNormalM1QALoginRuntime(context.Background()); err != nil {
		t.Fatal(err)
	}
	if err = closeNormalM1QALoginRuntime(context.Background()); err != nil {
		t.Fatal(err)
	}
	if normalM1QALoginRuntime != r {
		t.Fatal("close discarded owner")
	}
}
func TestM1QANormalStartupRejectsAmbiguousSupplier(t *testing.T) {
	original, originalQA := normalSocialLoginRuntime, normalM1QALoginRuntime
	normalSocialLoginRuntime, normalM1QALoginRuntime = nil, nil
	defer func() { normalSocialLoginRuntime, normalM1QALoginRuntime = original, originalQA }()
	lookup := func(string) (string, bool) { return "", false }
	for _, owners := range [][]*socialLoginRuntime{{nil}, {nil, nil}} {
		if h, err := openNormalSocialProduct(context.Background(), nil, lookup, owners...); err == nil || h != nil {
			t.Fatal("ambiguous supplier accepted")
		}
	}
	if normalSocialLoginRuntime != nil || normalM1QALoginRuntime != nil {
		t.Fatal("rejection acquired runtime")
	}
}

func TestM1QANormalSelectedLoaderRefusesUnconfiguredRoot(t *testing.T) {
	oldSelection, oldRuntime, oldQA := normalM1QALoginSelection, normalSocialLoginRuntime, normalM1QALoginRuntime
	defer func() {
		normalM1QALoginSelection, normalSocialLoginRuntime, normalM1QALoginRuntime = oldSelection, oldRuntime, oldQA
	}()
	normalSocialLoginRuntime, normalM1QALoginRuntime = nil, nil
	// Deliberately invalid inputs, not a synthetic signed approval.
	normalM1QALoginSelection = &socialM1QALoginStartupSelection{}
	normalM1QALoginSelection.runtime.PrivateKeyFile = filepath.Join(t.TempDir(), "must-not-open")
	if h, err := openNormalSocialProduct(context.Background(), nil, func(string) (string, bool) { return "", false }); err == nil || h != nil {
		t.Fatal("unconfigured selected root mounted")
	}
	if _, err := os.Stat(normalM1QALoginSelection.runtime.PrivateKeyFile); !os.IsNotExist(err) {
		t.Fatal("source rejection created provider file")
	}
	if normalSocialLoginRuntime != nil {
		t.Fatal("source rejection started production fallback")
	}
}
