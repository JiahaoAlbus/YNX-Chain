package main

import (
	"bytes"
	"context"
	"github.com/JiahaoAlbus/YNX-Chain/internal/centralbrowserfamily"
	"github.com/JiahaoAlbus/YNX-Chain/internal/social/kernel"
)

// Only an independently approved deployment/source selection may populate
// this private startup slot. No ENV, request, flag or public setter selects it.
// Nil is deliberate until that actual approved selection is supplied.
type socialM1QALoginStartupSelection struct {
	firstDevice  *firstEnrollmentStartup
	profile      centralbrowserfamily.SocialM1QATrustedProfileConfig
	runtime      socialLoginRuntimeConfig
	operation    *socialM1QAOperationStartupSelection
	provisioning *socialM1QAOperationProvisioning
	nativeHost   *socialNativeHostStartupSelection
}

var normalM1QALoginSelection *socialM1QALoginStartupSelection

func openSelectedM1QALoginRuntime(ctx context.Context, selection *socialM1QALoginStartupSelection) (*socialLoginRuntime, error) {
	if ctx == nil || selection == nil {
		return nil, centralbrowserfamily.ErrSocialM1QAProfileNotConfigured
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if selection.operation != nil && selection.provisioning != nil || selection.nativeHost != nil && selection.operation == nil && selection.provisioning == nil {
		return nil, errSocialM1QAStartupAmbiguous
	}
	source, err := centralbrowserfamily.OpenSocialM1QATrustedProfile(selection.profile)
	if err != nil {
		if source != nil {
			return &socialLoginRuntime{m1qaProfile: source}, err
		}
		return nil, err
	}
	r, err := openSocialM1QALoginRuntime(ctx, selection.runtime, source)
	if err != nil {
		return r, err
	}
	// Work with the same genuine owners, without mutating the startup selection.
	// Metadata selects construction, never a pre-authorized operation instance.
	effective := *selection
	if selection.provisioning != nil {
		effective.operation, err = r.provisionM1QAOperation(ctx, selection.provisioning, selection.runtime)
		if err != nil {
			return r, err
		}
	}
	if effective.operation != nil {
		operation := *effective.operation
		if err = r.retainM1QAOperationOwner(operation.owner); err != nil {
			return r, err
		}
		effective.operation = &operation
		if effective.nativeHost != nil {
			operation.nativeSource, err = r.openNativeHostSource(ctx, &effective)
			if err != nil {
				return r, err
			}
		}
		err = r.openM1QAAccountOperation(ctx, &operation)
	}
	if err == nil && effective.nativeHost != nil {
		err = r.openNativeHostPublisher(ctx, &effective)
	}
	return r, err
}

// Concrete trusted-startup composition. No path/flag in HTTP or operator login
// config can manufacture this already verified, originally selected source.
// The supplier remains a snapshot, not Central registration or a remote lease.
// A nonnil return always owns partial resources, even when error is nonnil.
func openSocialM1QALoginRuntime(ctx context.Context, config socialLoginRuntimeConfig, source *centralbrowserfamily.SocialM1QATrustedProfile) (*socialLoginRuntime, error) {
	if source == nil {
		return nil, centralbrowserfamily.ErrSocialM1QAProfileNotConfigured
	}
	r := &socialLoginRuntime{m1qaProfile: source}
	if err := source.Current(ctx); err != nil {
		return r, err
	}
	keyID, public, err := source.BackendSignerPublic()
	if err != nil {
		return r, err
	}
	if config.Profile != "protected-backend-software-pkcs8-v1" || config.KeyID != keyID || !bytes.Equal(config.PublicKey, public) || config.PrivateKeyFile == config.Store.SealKeyFile {
		return r, errSocialLoginRuntimeConfig
	}
	if err = source.AssertBackendProofRule(ctx, "POST", kernel.SocialLoginFamilyPath, keyID, public); err != nil {
		return r, err
	}
	provider, err := kernel.OpenSocialLoginSoftwareSigningProvider(config.PrivateKeyFile, public)
	if provider != nil {
		r.provider = provider
		r.releases.provider = provider
	}
	if err != nil {
		return r, err
	}
	if err = source.Current(ctx); err != nil {
		return r, err
	}
	adapter, err := centralbrowserfamily.NewSocialM1QATrustedSignerAdapter(source, keyID, public, provider)
	if err != nil {
		return r, err
	}
	signer, err := kernel.NewSocialM1QALoginBackendSigner(source, adapter)
	if err != nil {
		return r, err
	}
	service, err := kernel.OpenSocialM1QALoginService(config.Store, signer, source)
	if service != nil {
		r.service = service
		r.releases.service = service
	}
	if err != nil {
		return r, err
	}
	if err = source.Current(ctx); err != nil {
		return r, err
	}
	return r, nil
}
