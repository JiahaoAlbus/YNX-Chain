//go:build linux || darwin

package centralbrowserfamily

// PREPARED, NOT_RUN. Package-private owner state below is an explicit unit
// coordination model, not a root-admitted source, OS holder or production proof.
import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"errors"
	"io"
	"net/http"
	"strings"
	"testing"
	"time"
)

type preparedM1SignPort func(context.Context, []byte) ([]byte, error)

func (f preparedM1SignPort) SignEd25519(ctx context.Context, raw []byte) ([]byte, error) {
	return f(ctx, raw)
}

type preparedM1ContextKey struct{}

func preparedM1Owner(now func() time.Time, sign preparedM1SignPort) *SocialM1QAOperationOwner {
	private := ed25519.NewKeyFromSeed(make([]byte, 32))
	if sign == nil {
		sign = func(_ context.Context, b []byte) ([]byte, error) { return ed25519.Sign(private, b), nil }
	}
	return &SocialM1QAOperationOwner{ready: true, last: -1, config: SocialM1QAOperationOwnerConfig{Now: now}, public: private.Public().(ed25519.PublicKey), provider: sign, binding: SocialM1QAOperationOwnerBinding{KeyID: "prepared-owner", ClientID: m1OperationClient, IssuedAtMs: 0, ExpiresAtMs: 86400000}}
}
func preparedM1Body() string {
	return strings.ReplaceAll(firstBody, "ynx-social-v1-sso-v1", m1OperationClient)
}

const preparedM1Response = `{"version":"ynx-social-account-operation-result/v1","intentId":"fd1-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","commitment":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","status":"unknown","terminal":null,"blocked":false,"pending":true,"readOnly":false,"dispatchAllowed":true}`

func preparedM1Reply() *http.Response {
	h := http.Header{}
	h.Set("X-YNX-Social-Account-Eligibility-V2", base64.RawURLEncoding.EncodeToString([]byte(`{"fixture":"unverified-v2-carrier"}`)))
	return &http.Response{StatusCode: 200, Header: h, Body: io.NopCloser(strings.NewReader(preparedM1Response))}
}

func TestPreparedM1TypedOwnerRequired(t *testing.T) {
	now := func() time.Time { return time.UnixMilli(1) }
	if _, e := NewSocialM1QAOperationTransport("old-raw-key", wireSigner{}, nil, now); !errors.Is(e, ErrSocialM1QAOperationOwnerNotConfigured) {
		t.Fatal("bare M1 crypto signer supplied owner")
	}
	for _, owner := range []*SocialM1QAOperationOwner{nil, {}} {
		if _, e := NewSocialM1QAProtectedOperationTransport(context.Background(), owner, nil, now); e == nil {
			t.Fatal("missing source opened")
		}
	}
}
func TestPreparedM1OriginalContextDirectSign(t *testing.T) {
	now := func() time.Time { return time.UnixMilli(1) }
	ctx := context.WithValue(context.Background(), preparedM1ContextKey{}, "original")
	calls, requests := 0, 0
	private := ed25519.NewKeyFromSeed(make([]byte, 32))
	owner := preparedM1Owner(now, func(got context.Context, raw []byte) ([]byte, error) {
		calls++
		if got != ctx || got.Value(preparedM1ContextKey{}) != "original" {
			t.Fatal("caller context replaced")
		}
		return ed25519.Sign(private, raw), nil
	})
	httpClient := &http.Client{Transport: wireRT(func(r *http.Request) (*http.Response, error) {
		requests++
		if r.URL.String() != m1OperationIssuer+m1OperationPrefix+"reserve" {
			t.Fatal("wrong target")
		}
		return preparedM1Reply(), nil
	})}
	c, e := NewSocialM1QAProtectedOperationTransport(ctx, owner, httpClient, now)
	if e != nil {
		t.Fatal(e)
	}
	out, e := c.CallBound(ctx, "reserve", preparedM1Body(), strings.Repeat("a", 64))
	if e != nil || !out.DispatchAllowed || calls != 1 || requests != 1 {
		t.Fatal("typed prepared boundary", e, calls, requests)
	}
}
func TestPreparedM1LateAndCancellationKeepUnknown(t *testing.T) {
	for _, mode := range []string{"sign-cancel", "response-cancel", "body-expiry"} {
		t.Run(mode, func(t *testing.T) {
			at := int64(1)
			now := func() time.Time { return time.UnixMilli(at) }
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			requests := 0
			private := ed25519.NewKeyFromSeed(make([]byte, 32))
			owner := preparedM1Owner(now, func(got context.Context, raw []byte) ([]byte, error) {
				if mode == "sign-cancel" {
					cancel()
				}
				return ed25519.Sign(private, raw), nil
			})
			h := &http.Client{Transport: wireRT(func(_ *http.Request) (*http.Response, error) {
				requests++
				if mode == "response-cancel" {
					cancel()
				}
				r := preparedM1Reply()
				if mode == "body-expiry" {
					r.Body = &preparedM1BodyReader{Reader: strings.NewReader(preparedM1Response), after: func() { at = 30001 }}
				}
				return r, nil
			})}
			c, e := NewSocialM1QAProtectedOperationTransport(ctx, owner, h, now)
			if e != nil {
				t.Fatal(e)
			}
			out, e := c.Call(ctx, "reserve", preparedM1Body())
			if !errors.Is(e, ErrSocialOperationUnknown) || out.DispatchAllowed {
				t.Fatal("uncertain call released", e)
			}
			if requests > 1 || mode == "sign-cancel" && requests != 0 {
				t.Fatal("retry or late dispatch")
			}
		})
	}
}

type preparedM1BodyReader struct {
	io.Reader
	after func()
}

func (r *preparedM1BodyReader) Read(b []byte) (int, error) {
	n, e := r.Reader.Read(b)
	r.after()
	return n, e
}
func (r *preparedM1BodyReader) Close() error { return nil }
func TestPreparedM1SwallowedMalformedTransportReentry(t *testing.T) {
	now := func() time.Time { return time.UnixMilli(1) }
	private := ed25519.NewKeyFromSeed(make([]byte, 32))
	ctx := context.Background()
	var c *SocialOperationTransport
	requests := 0
	owner := preparedM1Owner(now, func(got context.Context, raw []byte) ([]byte, error) {
		_, _ = c.CallBound(got, "read", preparedM1Body(), "malformed")
		return ed25519.Sign(private, raw), nil
	})
	h := &http.Client{Transport: wireRT(func(_ *http.Request) (*http.Response, error) { requests++; return preparedM1Reply(), nil })}
	var e error
	c, e = NewSocialM1QAProtectedOperationTransport(ctx, owner, h, now)
	if e != nil {
		t.Fatal(e)
	}
	if _, e = c.Call(ctx, "reserve", preparedM1Body()); !errors.Is(e, ErrSocialOperationUnknown) || requests != 0 || !c.invalid.Load() {
		t.Fatal("swallowed reentry released")
	}
	if _, e = c.Call(ctx, "reserve", preparedM1Body()); e == nil || requests != 0 {
		t.Fatal("sticky failure cleared")
	}
}
