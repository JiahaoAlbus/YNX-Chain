package centralbrowserfamily

import (
	"context"
	"crypto"
	"crypto/ed25519"
	"encoding/base64"
	"io"
	"net/http"
	"strings"
	"testing"
	"time"
)

type wireSigner struct{}

func (wireSigner) Public() crypto.PublicKey { return ed25519.PublicKey(make([]byte, 32)) }
func (wireSigner) Sign(io.Reader, []byte, crypto.SignerOpts) ([]byte, error) {
	return make([]byte, 64), nil
}

type wireRT func(*http.Request) (*http.Response, error)

func (f wireRT) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

const firstBody = `{"challenge":{"expiresAtMs":30001,"issuedAtMs":1,"nonce":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","operation":"fd1-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","requestDigest":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"},"clientId":"ynx-social-v1-sso-v1","grantToken":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","intentId":"fd1-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","preparedPublicCommitment":{"device":"d","identity":"i","issuerMessage":"QQ","operation":"fd1-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","revision":"1","targetMessage":"Qg","version":"ynx-social-first-enrollment-prepared/v1"}}`

func wireClient(t *testing.T, response string) *SocialOperationTransport {
	return wireClientCarrier(t, response, true)
}
func wireClientCarrier(t *testing.T, response string, includeCarrier bool) *SocialOperationTransport {
	t.Helper()
	h := &http.Client{Transport: wireRT(func(r *http.Request) (*http.Response, error) {
		if r.URL.Host != "wallet-auth.ynxweb4.com" || r.Header.Get("X-YNX-Social-Operation-Proof") == "" {
			t.Fatal("wrong fixed wire")
		}
		headers := http.Header{}
		if includeCarrier && strings.Contains(response, `"pending":true`) && !strings.Contains(response, `"blocked":true`) {
			headers.Set("X-YNX-Social-Account-Eligibility-V1", base64.RawURLEncoding.EncodeToString([]byte(`{"fixture":"unverified-carrier-only"}`)))
		}
		return &http.Response{StatusCode: 200, Body: io.NopCloser(strings.NewReader(response)), Header: headers}, nil
	})}
	c, e := NewSocialOperationTransport("NEW-role-fixture", wireSigner{}, h, func() time.Time { return time.UnixMilli(1) })
	if e != nil {
		t.Fatal(e)
	}
	return c
}
func TestOriginalNodeFirstACKWire(t *testing.T) {
	const root = `{"version":"ynx-social-account-operation-result/v1","intentId":"fd1-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","commitment":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","status":"unknown","terminal":null,"blocked":false,"pending":true,"readOnly":false,"dispatchAllowed":true}`
	c := wireClient(t, root)
	got, e := c.Call(context.Background(), "reserve", firstBody)
	if e != nil || !got.DispatchAllowed || got.Blocked {
		t.Fatalf("actual Node first ACK rejected %v %+v", e, got)
	}
	t.Run("first-carrier-missing-unknown", func(t *testing.T) {
		c := wireClientCarrier(t, root, false)
		if _, e := c.Call(context.Background(), "reserve", firstBody); e == nil {
			t.Fatal("headerless first ACK released")
		}
	})
	t.Run("blocked-first-reject", func(t *testing.T) {
		c := wireClient(t, strings.Replace(root, `"blocked":false`, `"blocked":true`, 1))
		if _, e := c.Call(context.Background(), "reserve", firstBody); e == nil {
			t.Fatal("blocked dispatch allowed")
		}
	})
	t.Run("replay-readonly", func(t *testing.T) {
		s := strings.Replace(strings.Replace(root, `"readOnly":false`, `"readOnly":true`, 1), `"dispatchAllowed":true`, `"dispatchAllowed":false`, 1)
		c := wireClient(t, s)
		got, e := c.Call(context.Background(), "read", firstBody)
		if e != nil || got.DispatchAllowed || !got.ReadOnly {
			t.Fatal("replay decision lost")
		}
	})
	t.Run("expected-association-mismatch", func(t *testing.T) {
		c := wireClient(t, root)
		if _, e := c.CallBound(context.Background(), "reserve", firstBody, strings.Repeat("b", 64)); e == nil {
			t.Fatal("wrong association accepted")
		}
	})
	t.Run("terminal-readonly", func(t *testing.T) {
		s := strings.Replace(strings.Replace(strings.Replace(root, `"status":"unknown"`, `"status":"committed"`, 1), `"pending":true`, `"pending":false`, 1), `"dispatchAllowed":true`, `"dispatchAllowed":false`, 1)
		s = strings.Replace(s, `"readOnly":false`, `"readOnly":true`, 1)
		s = strings.Replace(s, `"terminal":null`, `"terminal":{"action":"terminal","outcome":"committed","receiptDigest":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","observedAtMs":1}`, 1)
		c := wireClient(t, s)
		got, e := c.CallBound(context.Background(), "read", firstBody, strings.Repeat("a", 64))
		if e != nil || got.DispatchAllowed || got.Status != "committed" {
			t.Fatal("terminal read rejected")
		}
	})
}

func TestOriginalNodeFirstTerminalCancelAndReadReplay(t *testing.T) {
	for _, tc := range []struct{ action, status, outcome string }{
		{"terminal", "committed", "committed"}, {"terminal", "not-executed", "not-executed"}, {"cancel", "cancelled", "not-executed"},
	} {
		t.Run(tc.action+"-"+tc.outcome, func(t *testing.T) {
			response := `{"version":"ynx-social-account-operation-result/v1","intentId":"fd1-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","commitment":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","status":"` + tc.status + `","terminal":{"action":"` + tc.action + `","outcome":"` + tc.outcome + `","receiptDigest":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","observedAtMs":1},"blocked":false,"pending":false,"readOnly":false,"dispatchAllowed":false}`
			body := strings.TrimSuffix(firstBody, "}") + `,"publicReceipt":{}}`
			c := wireClient(t, response)
			got, e := c.CallBound(context.Background(), tc.action, body, strings.Repeat("a", 64))
			if e != nil || got.ReadOnly || got.DispatchAllowed {
				t.Fatalf("original first settle refused %v", e)
			}
			replay := strings.Replace(response, `"readOnly":false`, `"readOnly":true`, 1)
			c = wireClient(t, replay)
			if got, e = c.CallBound(context.Background(), tc.action, body, strings.Repeat("a", 64)); e != nil || !got.ReadOnly {
				t.Fatal("settled replay refused")
			}
			c = wireClient(t, replay)
			if got, e = c.CallBound(context.Background(), "read", firstBody, strings.Repeat("a", 64)); e != nil || !got.ReadOnly {
				t.Fatal("read settled refused")
			}
			c = wireClient(t, response)
			if _, e = c.CallBound(context.Background(), "read", firstBody, strings.Repeat("a", 64)); e == nil {
				t.Fatal("mutating READ accepted")
			}
		})
	}
}
