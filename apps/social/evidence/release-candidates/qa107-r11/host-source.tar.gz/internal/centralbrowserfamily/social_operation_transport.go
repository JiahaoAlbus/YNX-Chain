package centralbrowserfamily

import (
	"bytes"
	"context"
	"crypto"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"reflect"
	"strings"
	"sync/atomic"
	"time"
)

// This client signs only the NEW Social purpose. Server-side real purpose
// registration remains mandatory; possession of an old key grants no rights.
type SocialOperationTransport struct {
	active       atomic.Bool
	invalid      atomic.Bool
	key          crypto.Signer
	owner        *SocialM1QAOperationOwner
	nativeSource *SocialNativeInstanceSource
	keyID        string
	clientID     string
	http         http.Client
	now          func() time.Time
}

var ErrSocialOperationUnknown = errors.New("SOCIAL_OPERATION_UNKNOWN")

const socialOperationPrefix = "/v2/browser-sessions/social-account-operations/v1/"

func NewSocialOperationTransport(keyID string, key crypto.Signer, client *http.Client, now func() time.Time) (*SocialOperationTransport, error) {
	return newSocialOperationTransport(keyID, key, client, now, "ynx-social-v1-sso-v1")
}

// Deprecated metadata-only M1 construction is closed. A bare crypto.Signer
// cannot supply the independently approved owner or preserve caller context.
// The signature remains for source compatibility, never an automatic upgrade.
func NewSocialM1QAOperationTransport(keyID string, key crypto.Signer, client *http.Client, now func() time.Time) (*SocialOperationTransport, error) {
	return nil, ErrSocialM1QAOperationOwnerNotConfigured
}

// Actual typed normal M1 source composition. Owner is the original protected
// factory object; no DTO/current callback, login signer or key fallback.
func NewSocialM1QAProtectedOperationTransport(ctx context.Context, owner *SocialM1QAOperationOwner, client *http.Client, now func() time.Time) (*SocialOperationTransport, error) {
	if ctx == nil || ctx.Err() != nil || owner == nil || now == nil {
		return nil, ErrSocialM1QAOperationOwnerNotConfigured
	}
	keyID, public, e := owner.OperationSignerPublic(ctx)
	if e != nil || len(public) != ed25519.PublicKeySize {
		return nil, errors.Join(ErrSocialM1QAOperationOwnerNotConfigured, e)
	}
	c := &SocialOperationTransport{owner: owner, keyID: keyID, clientID: "ynx-social-v1-m1qa-sso-v1", http: socialOperationHTTPClient(client), now: now}
	if e = owner.Current(ctx); e != nil {
		return nil, e
	}
	return c, nil
}

func newSocialOperationTransport(keyID string, key crypto.Signer, client *http.Client, now func() time.Time, clientID string) (*SocialOperationTransport, error) {
	if len(keyID) < 1 || len(keyID) > 128 || key == nil || socialNil(key) || now == nil {
		return nil, ErrSocialOperationUnknown
	}
	for _, c := range keyID {
		if c < 33 || c > 126 {
			return nil, ErrSocialOperationUnknown
		}
	}
	pub, ok := key.Public().(ed25519.PublicKey)
	if !ok || len(pub) != ed25519.PublicKeySize {
		return nil, ErrSocialOperationUnknown
	}
	return &SocialOperationTransport{key: key, keyID: keyID, clientID: clientID, http: socialOperationHTTPClient(client), now: now}, nil
}

func socialOperationHTTPClient(client *http.Client) http.Client {
	h := http.Client{Timeout: 5 * time.Second}
	if client != nil {
		h = *client
		if h.Timeout <= 0 || h.Timeout > 5*time.Second {
			h.Timeout = 5 * time.Second
		}
	}
	h.CheckRedirect = func(*http.Request, []*http.Request) error { return ErrSocialOperationUnknown }
	return h
}

func (c *SocialOperationTransport) ownerCurrent(ctx context.Context) error {
	if c.invalid.Load() || ctx == nil || ctx.Err() != nil {
		return ErrSocialOperationUnknown
	}
	if c.owner != nil {
		if e := c.owner.Current(ctx); e != nil {
			return e
		}
		if c.invalid.Load() || ctx.Err() != nil {
			return ErrSocialOperationUnknown
		}
		return nil
	}
	if c.clientID == "ynx-social-v1-m1qa-sso-v1" {
		return ErrSocialM1QAOperationOwnerNotConfigured
	}
	return nil
}

// Uses the owner's already-fenced final clock, without introducing another
// external callback after Current. A still-current certificate alone cannot
// extend the original thirty-second operation proof.
func (c *SocialOperationTransport) ownerCurrentWithin(ctx context.Context, start, end time.Time) error {
	if e := c.ownerCurrent(ctx); e != nil {
		return e
	}
	if c.owner != nil {
		c.owner.mu.Lock()
		at, invalid := c.owner.last, c.owner.invalid || c.owner.closed
		c.owner.mu.Unlock()
		if invalid || at < start.UnixMilli() || at >= end.UnixMilli() {
			return ErrSocialM1QAOperationOwnerInvalid
		}
	}
	if c.nativeSource != nil {
		if e := c.nativeSource.Current(ctx); e != nil {
			return e
		}
		c.nativeSource.mu.Lock()
		at, bad := c.nativeSource.last, c.nativeSource.invalid || c.nativeSource.closed
		c.nativeSource.mu.Unlock()
		if bad || at < start.UnixMilli() || at >= end.UnixMilli() || c.invalid.Load() {
			return ErrSocialNativeInstanceInvalid
		}
		// The instance clock is another external boundary: revalidate the actual
		// operation source without replacing its retained proof/window.
		if e := c.ownerCurrent(ctx); e != nil {
			return e
		}
		c.owner.mu.Lock()
		last, bad := c.owner.last, c.owner.invalid || c.owner.closed
		c.owner.mu.Unlock()
		if bad || last < start.UnixMilli() || last >= end.UnixMilli() {
			return ErrSocialOperationUnknown
		}
		if e := c.nativeSource.heldAfterClock(ctx, last); e != nil {
			return e
		}
	}
	return nil
}

type SocialOperationDecision struct {
	// Raw original signed public carrier only; NOT verified grant/current.
	OriginalEligibilityRaw     string `json:"-"`
	originalAccountRaw         string
	originalNativeSequence     int64
	originalNativeRegistration string
	originalReadProof          string
	Version                    string `json:"version"`
	IntentID                   string `json:"intentId"`
	Commitment                 string `json:"commitment"`
	Status                     string `json:"status"`
	Terminal                   *struct {
		Action        string `json:"action"`
		Outcome       string `json:"outcome"`
		ReceiptDigest string `json:"receiptDigest"`
		ObservedAtMS  int64  `json:"observedAtMs"`
	} `json:"terminal"`
	Blocked         bool `json:"blocked"`
	Pending         bool `json:"pending"`
	ReadOnly        bool `json:"readOnly"`
	DispatchAllowed bool `json:"dispatchAllowed"`
}

// Call never retries. rawBody is the ORIGINAL producer's canonical PUBLIC
// wire string, including transient grant token; it is never journaled here.
// On any uncertain response, original product durable mapping must READ with
// the same intent, not re-run native finalize or generate a second operation.
func (c *SocialOperationTransport) Call(ctx context.Context, action, rawBody string) (SocialOperationDecision, error) {
	return c.call(ctx, action, rawBody, "", false, "")
}

func (c *SocialOperationTransport) CallBound(ctx context.Context, action, rawBody, originalCommitment string) (SocialOperationDecision, error) {
	if c != nil && c.active.Load() {
		c.invalid.Store(true)
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if !socialHex(originalCommitment) {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	return c.call(ctx, action, rawBody, originalCommitment, false, "")
}

func (c *SocialOperationTransport) call(ctx context.Context, action, rawBody, originalCommitment string, accountMode bool, retainedProof string) (SocialOperationDecision, error) {
	var out SocialOperationDecision
	if c == nil {
		return out, ErrSocialOperationUnknown
	}
	if !c.active.CompareAndSwap(false, true) {
		c.invalid.Store(true)
		return out, ErrSocialOperationUnknown
	}
	defer c.active.Store(false)
	if c.invalid.Load() {
		return out, ErrSocialOperationUnknown
	}
	if c == nil || ctx == nil || ctx.Err() != nil || len(rawBody) > 65536 || len(rawBody) == 0 {
		return out, ErrSocialOperationUnknown
	}
	if accountMode && (action != "read" || c.owner == nil || c.clientID != "ynx-social-v1-m1qa-sso-v1") {
		return out, ErrSocialOperationUnknown
	}
	if action != "reserve" && action != "read" && action != "terminal" && action != "cancel" {
		return out, ErrSocialOperationUnknown
	}
	if e := c.ownerCurrent(ctx); e != nil {
		return out, errors.Join(ErrSocialOperationUnknown, e)
	}
	var captured struct {
		ClientID   string `json:"clientId"`
		GrantToken string `json:"grantToken"`
		IntentID   string `json:"intentId"`
		Challenge  struct {
			Operation     string `json:"operation"`
			Nonce         string `json:"nonce"`
			RequestDigest string `json:"requestDigest"`
			IssuedAtMS    int64  `json:"issuedAtMs"`
			ExpiresAtMS   int64  `json:"expiresAtMs"`
		} `json:"challenge"`
		Prepared json.RawMessage `json:"preparedPublicCommitment"`
		Receipt  json.RawMessage `json:"publicReceipt"`
	}
	dec := json.NewDecoder(strings.NewReader(rawBody))
	dec.DisallowUnknownFields()
	if dec.Decode(&captured) != nil || dec.Decode(new(any)) != io.EOF || captured.ClientID != c.clientID || captured.IntentID == "" || len(captured.IntentID) > 128 || captured.IntentID != captured.Challenge.Operation || len(captured.GrantToken) != 43 || len(captured.Prepared) == 0 || (action == "terminal" || action == "cancel") != (len(captured.Receipt) > 0) {
		return out, ErrSocialOperationUnknown
	}
	// Node performs authoritative canonical/exact-field/challenge checks. The
	// transport never rewrites raw input, normalizes commitments or infers grant.
	raw := []byte(rawBody)
	at := c.now().UTC().Truncate(time.Millisecond)
	end := at.Add(30 * time.Second)
	if c.invalid.Load() || at.UnixMilli() < 0 || ctx.Err() != nil {
		return out, ErrSocialOperationUnknown
	}
	var envelope []byte
	var e error
	if retainedProof != "" {
		// Only a private captured handle supplies these SAME original bytes/nonce.
		// No new Sign/random on original join or uncertainty readback.
		var saved map[string]any
		if json.Unmarshal([]byte(retainedProof), &saved) != nil {
			return out, ErrSocialOperationUnknown
		}
		start, ok1 := saved["issuedAt"].(string)
		finish, ok2 := saved["expiresAt"].(string)
		var err error
		at, err = time.Parse("2006-01-02T15:04:05.000Z", start)
		if err != nil || !ok1 {
			return out, ErrSocialOperationUnknown
		}
		end, err = time.Parse("2006-01-02T15:04:05.000Z", finish)
		if err != nil || !ok2 {
			return out, ErrSocialOperationUnknown
		}
		sum := sha256.Sum256(raw)
		if action != "read" || len(saved) != 14 || saved["clientId"] != c.clientID || saved["keyId"] != c.keyID || saved["action"] != "read" || saved["path"] != socialOperationPrefix+"read" || saved["bodySha256"] != hex.EncodeToString(sum[:]) || saved["version"] != float64(1) || saved["purpose"] != "social-original-operation/v1" || saved["issuer"] != "https://wallet-auth.ynxweb4.com" || saved["audience"] != "https://wallet-auth.ynxweb4.com"+socialOperationPrefix || saved["method"] != "POST" || !end.After(at) || end.Sub(at) > 30*time.Second {
			return out, ErrSocialOperationUnknown
		}
		envelope = []byte(retainedProof)
		if e := c.ownerCurrentWithin(ctx, at, end); e != nil {
			return out, errors.Join(ErrSocialOperationUnknown, e)
		}
	} else {
		nonce := make([]byte, 32)
		if _, e := rand.Read(nonce); e != nil {
			return out, ErrSocialOperationUnknown
		}
		sum := sha256.Sum256(raw)
		proof := map[string]any{"version": 1, "purpose": "social-original-operation/v1", "issuer": "https://wallet-auth.ynxweb4.com", "audience": "https://wallet-auth.ynxweb4.com" + socialOperationPrefix, "clientId": captured.ClientID, "keyId": c.keyID, "action": action, "method": "POST", "path": socialOperationPrefix + action, "bodySha256": hex.EncodeToString(sum[:]), "issuedAt": at.Format("2006-01-02T15:04:05.000Z"), "expiresAt": end.Format("2006-01-02T15:04:05.000Z"), "nonce": base64.RawURLEncoding.EncodeToString(nonce)}
		signed, e := socialProofJSON(proof)
		if e != nil {
			return out, ErrSocialOperationUnknown
		}
		if e = c.ownerCurrentWithin(ctx, at, end); e != nil {
			return out, errors.Join(ErrSocialOperationUnknown, e)
		}
		var signature []byte
		if c.owner != nil {
			signature, e = c.owner.SignSocialOriginalOperation(ctx, signed)
		} else {
			signature, e = c.key.Sign(rand.Reader, signed, crypto.Hash(0))
		}
		if e != nil || len(signature) != ed25519.SignatureSize {
			return out, ErrSocialOperationUnknown
		}
		if e = c.ownerCurrentWithin(ctx, at, end); e != nil {
			return out, errors.Join(ErrSocialOperationUnknown, e)
		}
		proof["signature"] = base64.RawURLEncoding.EncodeToString(signature)
		envelope, e = socialProofJSON(proof)
		if e != nil || len(envelope) > 4096 {
			return out, ErrSocialOperationUnknown
		}

	}
	afterSign := c.now().UTC()
	if c.invalid.Load() || afterSign.Before(at) || !afterSign.Before(end) || ctx.Err() != nil {
		return out, ErrSocialOperationUnknown
	}
	if e = c.ownerCurrentWithin(ctx, at, end); e != nil {
		return out, errors.Join(ErrSocialOperationUnknown, e)
	}
	callCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	req, e := http.NewRequestWithContext(callCtx, "POST", "https://wallet-auth.ynxweb4.com"+socialOperationPrefix+action, bytes.NewReader(raw))
	if e != nil {
		return out, ErrSocialOperationUnknown
	}
	req.Header.Set("Content-Type", "application/json")
	if accountMode {
		req.Header.Set("Accept", "application/vnd.ynx.social-original-account+json")
		if c.nativeSource != nil {
			req.Header.Set("Accept", "application/vnd.ynx.social-native-phase-custody+json")
		}
	}
	req.Header.Set("Cache-Control", "no-store")
	req.Header.Set("X-YNX-Social-Operation-Proof", base64.RawURLEncoding.EncodeToString(envelope))
	resp, e := c.http.Do(req)
	if e != nil {
		return out, ErrSocialOperationUnknown
	}
	responseClosed := false
	defer func() {
		if !responseClosed {
			_ = resp.Body.Close()
		}
	}()
	if e = c.ownerCurrentWithin(ctx, at, end); e != nil {
		return out, errors.Join(ErrSocialOperationUnknown, e)
	}
	response, e := io.ReadAll(io.LimitReader(resp.Body, 65537))
	// Close may invoke the original client's lifecycle: do it before the last
	// Current fence, never defer a successful-result callback past that fence.
	responseClosed = true
	closeErr := resp.Body.Close()
	if currentErr := c.ownerCurrentWithin(ctx, at, end); currentErr != nil {
		return out, errors.Join(ErrSocialOperationUnknown, currentErr)
	}
	if e != nil || closeErr != nil || len(response) > 65536 || resp.StatusCode != 200 {
		return out, ErrSocialOperationUnknown
	}
	if accountMode {
		if resp.Header.Get("Content-Type") != "application/json; charset=utf-8" {
			return out, ErrSocialOperationUnknown
		}
		if c.nativeSource != nil {
			var fields map[string]json.RawMessage
			var custody struct {
				Version      string `json:"version"`
				Sequence     int64  `json:"sequence"`
				Registration string `json:"registrationDigest"`
				Frame        string `json:"accountFrame"`
			}
			if decodeOriginalAccountJSON(response, &fields) != nil || len(fields) != 4 || fields["version"] == nil || fields["sequence"] == nil || fields["registrationDigest"] == nil || fields["accountFrame"] == nil || bytes.Equal(fields["sequence"], []byte("null")) || decodeOriginalAccountJSON(response, &custody) != nil || custody.Version != "ynx-social-native-phase-custody/v1" || custody.Sequence < 1 || custody.Sequence > 9007199254740991 {
				return out, ErrSocialOperationUnknown
			}
			binding, err := c.nativeSource.Binding(ctx)
			if err != nil || binding.Status != "active" || custody.Registration != binding.RegistrationDigest {
				return out, ErrSocialOperationUnknown
			}
			response = []byte(custody.Frame)
			out.originalNativeSequence = custody.Sequence
			out.originalNativeRegistration = custody.Registration
		}
		frame, err := parseOriginalSocialAccountFrame(response, rawBody, at, end)
		if err != nil {
			return out, err
		}
		if err = c.ownerCurrentWithin(ctx, at, end); err != nil || c.invalid.Load() || ctx.Err() != nil {
			return out, errors.Join(ErrSocialOperationUnknown, err)
		}
		// Last clock/source gate precedes release. This is private TLS data, not grant.
		if err = c.ownerCurrentWithin(ctx, at, time.UnixMilli(frame.ExpiresAtMS)); err != nil {
			return out, err
		}
		out.originalAccountRaw = string(response)
		out.originalReadProof = string(envelope)
		return out, nil
	}
	// Private original-holder terminal READ must retain the existing exact
	// JSON representation boundary. Other original action behavior is unchanged.
	if retainedProof != "" && !accountMode && resp.Header.Get("Content-Type") != "application/json; charset=utf-8" {
		return out, ErrSocialOperationUnknown
	}
	d := json.NewDecoder(bytes.NewReader(response))
	d.DisallowUnknownFields()
	if d.Decode(&out) != nil || d.Decode(new(any)) != io.EOF || out.Version != "ynx-social-account-operation-result/v1" || out.IntentID != captured.IntentID || !socialHex(out.Commitment) || originalCommitment != "" && out.Commitment != originalCommitment || ctx.Err() != nil {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if out.Status != "unknown" && out.Status != "committed" && out.Status != "not-executed" && out.Status != "cancelled" {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if out.DispatchAllowed && (action != "reserve" || out.ReadOnly || !out.Pending || out.Blocked || out.Status != "unknown" || out.Terminal != nil) {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if action == "read" && !out.ReadOnly {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if action == "reserve" && !out.DispatchAllowed && !out.ReadOnly {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if (action == "terminal" || action == "cancel") && (out.Status == "unknown" || out.Terminal == nil || out.Terminal.Action != action) {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if out.Status == "cancelled" && (out.Terminal == nil || out.Terminal.Action != "cancel" || out.Terminal.Outcome != "not-executed") {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if (out.Status == "committed" || out.Status == "not-executed") && (out.Terminal == nil || out.Terminal.Action != "terminal") {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if out.Status == "unknown" && (out.Terminal != nil || !out.Pending) {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if out.Status != "unknown" && (out.Terminal == nil || out.Pending || out.DispatchAllowed) {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if out.Terminal != nil && (out.Status == "committed" && out.Terminal.Outcome != "committed" || out.Status != "committed" && out.Terminal.Outcome != "not-executed") {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	if out.Terminal != nil {
		t := out.Terminal
		if (t.Action != "terminal" && t.Action != "cancel") || (t.Outcome != "committed" && t.Outcome != "not-executed") || !socialHex(t.ReceiptDigest) || t.ObservedAtMS < 0 {
			return SocialOperationDecision{}, ErrSocialOperationUnknown
		}
	}
	carrier, carrierErr := captureOriginalSocialEligibilityHeaderForClient(resp.Header, c.clientID)
	if carrierErr != nil || out.DispatchAllowed && carrier == "" || carrier != "" && (!out.Pending || out.Blocked || (action != "reserve" && action != "read")) {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	out.OriginalEligibilityRaw = carrier
	final := c.now().UTC()
	if c.invalid.Load() || final.Before(afterSign) || !final.Before(end) || ctx.Err() != nil {
		return SocialOperationDecision{}, ErrSocialOperationUnknown
	}
	// Last external transport clock must precede original held-source fencing.
	if e = c.ownerCurrentWithin(ctx, at, end); e != nil || c.invalid.Load() || ctx.Err() != nil {
		return SocialOperationDecision{}, errors.Join(ErrSocialOperationUnknown, e)
	}
	return out, nil
}
func socialHex(s string) bool {
	if len(s) != 64 {
		return false
	}
	for _, c := range s {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}
func socialProofJSON(v any) ([]byte, error) {
	var b bytes.Buffer
	e := json.NewEncoder(&b)
	e.SetEscapeHTML(false)
	if err := e.Encode(v); err != nil {
		return nil, err
	}
	return bytes.TrimSuffix(b.Bytes(), []byte("\n")), nil
}

func socialNil(v any) bool {
	r := reflect.ValueOf(v)
	switch r.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice:
		return r.IsNil()
	}
	return false
}

// This bounded transport carries exact issuer bytes without treating the
// header, ACK or DispatchAllowed as authenticated account eligibility. Native
// must verify its independently approved pending-writer pin and its original
// expected request/messages. Missing first carrier preserves UNKNOWN.
func captureOriginalSocialEligibilityHeader(headers http.Header) (string, error) {
	return captureOriginalSocialEligibilityHeaderForClient(headers, "ynx-social-v1-sso-v1")
}

func captureOriginalSocialEligibilityHeaderForClient(headers http.Header, clientID string) (string, error) {
	name, foreign := "X-YNX-Social-Account-Eligibility-V1", "X-YNX-Social-Account-Eligibility-V2"
	if clientID == "ynx-social-v1-m1qa-sso-v1" {
		name, foreign = foreign, name
	} else if clientID != "ynx-social-v1-sso-v1" {
		return "", ErrSocialOperationUnknown
	}
	if len(headers.Values(foreign)) != 0 {
		return "", ErrSocialOperationUnknown
	}
	values := headers.Values(name)
	if len(values) == 0 {
		return "", nil
	}
	if len(values) != 1 || len(values[0]) < 1 || len(values[0]) > 10923 || base64.RawURLEncoding.DecodedLen(len(values[0])) > 8192 {
		return "", ErrSocialOperationUnknown
	}
	raw, err := base64.RawURLEncoding.Strict().DecodeString(values[0])
	if err != nil || len(raw) > 8192 || base64.RawURLEncoding.EncodeToString(raw) != values[0] || !json.Valid(raw) {
		return "", ErrSocialOperationUnknown
	}
	return string(raw), nil
}
