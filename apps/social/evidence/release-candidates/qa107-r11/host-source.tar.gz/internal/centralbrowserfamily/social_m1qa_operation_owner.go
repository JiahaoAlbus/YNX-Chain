//go:build linux || darwin

package centralbrowserfamily

// This NEW source verifier does not approve a root, generate a holder, or use
// the login two-POST purpose. Its protected files are public, not key files.
import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/x509"
	"encoding/pem"
	"errors"
	"os"
	"reflect"
	"sync"
	"time"
)

const SocialM1QAOperationOwnerPurpose = "social-m1qa-original-operation-owner/v1"
const SocialM1QAOperationOwnerDomain = "YNX_SOCIAL_M1QA_ORIGINAL_OPERATION_OWNER_V1\n"
const m1OperationIssuer = "https://wallet-auth.ynxweb4.com"
const m1OperationPrefix = "/v2/browser-sessions/social-account-operations/v1/"
const m1OperationClient = "ynx-social-v1-m1qa-sso-v1"

var ErrSocialM1QAOperationOwnerNotConfigured = errors.New("SOCIAL_M1QA_OPERATION_OWNER_NOT_CONFIGURED")
var ErrSocialM1QAOperationOwnerInvalid = errors.New("SOCIAL_M1QA_OPERATION_OWNER_INVALID")

// Existing original provider port. An implementation alone is NOT registration
// or OS protection. The normal owner must open the original protected holder.
type SocialM1QAOperationProtectedSigner interface {
	SignEd25519(context.Context, []byte) ([]byte, error)
}
type SocialM1QAOperationOwnerConfig struct {
	RootPath, RootDigest, CertificatePath, CertificateDigest, NodeConfigPath, NodeConfigDigest string
	RootBytes, CertificateBytes, NodeConfigBytes                                               int64
	// Independently selected expected full canonical Node config, not header/ENV.
	ExpectedNodeConfigDigest string
	// Fixed pure synchronous bounded original clock. Not an approval callback.
	Now func() time.Time
}
type SocialM1QAOperationOwnerBinding struct {
	RegistrationID, ClientID, Origin, RedirectURI, KeyID, NodeConfigDigest string
	Revision, IssuedAtMs, ExpiresAtMs                                      int64
	Actions                                                                []string
}
type SocialM1QAOperationOwner struct {
	mu                             sync.Mutex
	active, invalid, closed, ready bool
	files                          []*socialM1QAHeldFile
	config                         SocialM1QAOperationOwnerConfig
	binding                        SocialM1QAOperationOwnerBinding
	public                         ed25519.PublicKey
	provider                       SocialM1QAOperationProtectedSigner
	last                           int64
	closeErr                       error
	constructionErr                error
}

func m1OperationNil(v any) bool {
	if v == nil {
		return true
	}
	r := reflect.ValueOf(v)
	switch r.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice:
		return r.IsNil()
	}
	return false
}
func m1OperationPublic(s string) (ed25519.PublicKey, error) {
	b, rest := pem.Decode([]byte(s))
	if b == nil || b.Type != "PUBLIC KEY" || len(rest) != 0 || len(b.Headers) != 0 {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	key, e := x509.ParsePKIXPublicKey(b.Bytes)
	p, ok := key.(ed25519.PublicKey)
	if e != nil || !ok || len(p) != 32 {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	return bytes.Clone(p), nil
}
func m1OperationActions(v any) bool {
	a, ok := v.([]any)
	if !ok || len(a) != 4 {
		return false
	}
	for i, s := range []string{"reserve", "read", "terminal", "cancel"} {
		if a[i] != s {
			return false
		}
	}
	return true
}
func m1OperationAction(s string) bool {
	return s == "reserve" || s == "read" || s == "terminal" || s == "cancel"
}

// This leaf inherits only fixed stdlib helper definitions from the immutable
// profile cleanup source. It never opens a login profile or delegates its rights.
// After any descriptor is opened, a nonnil result owns that partial custody
// even when error is nonnil. Capture it before inspecting error, then Close
// after its users drain. The supplied protected signer remains caller-owned.
func OpenSocialM1QAOperationOwner(c SocialM1QAOperationOwnerConfig, keyID string, public ed25519.PublicKey, provider SocialM1QAOperationProtectedSigner) (resultOwner *SocialM1QAOperationOwner, resultErr error) {
	if c.Now == nil || m1OperationNil(provider) || !m1token(keyID) || len(public) != 32 || !m1hash(c.ExpectedNodeConfigDigest) {
		return nil, ErrSocialM1QAOperationOwnerNotConfigured
	}
	if c.NodeConfigDigest != c.ExpectedNodeConfigDigest || c.RootPath == c.CertificatePath || c.RootPath == c.NodeConfigPath || c.CertificatePath == c.NodeConfigPath {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	o := &SocialM1QAOperationOwner{config: c, public: bytes.Clone(public), provider: provider, last: -1}
	good := false
	defer func() {
		if !good {
			o.invalid, o.ready = true, false
			o.constructionErr = resultErr
			// Main captures a nonnil owner before examining the original error.
			// No hidden cleanup or lost partial FD, and no transfer of signer custody.
			if len(o.files) > 0 {
				resultOwner = o
			}
		}
	}()
	var raw [][]byte
	for _, s := range []struct {
		path, digest string
		size         int64
	}{{c.RootPath, c.RootDigest, c.RootBytes}, {c.CertificatePath, c.CertificateDigest, c.CertificateBytes}, {c.NodeConfigPath, c.NodeConfigDigest, c.NodeConfigBytes}} {
		h, b, e := m1holdOwned(s.path, s.digest, s.size)
		o.files = append(o.files, h...)
		if e != nil {
			return nil, e
		}
		raw = append(raw, b)
	}
	root, e := m1parse(raw[0])
	if e != nil || !m1exact(root, "version", "purpose", "rootId", "rootKeyId", "publicKey") || m1int(root, "version") != 1 || m1str(root, "purpose") != SocialM1QAOperationOwnerPurpose || !m1token(m1str(root, "rootId")) || !m1token(m1str(root, "rootKeyId")) {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	rootPublic, e := m1OperationPublic(m1str(root, "publicKey"))
	if e != nil {
		return nil, e
	}
	env, e := m1parse(raw[1])
	if e != nil || !m1exact(env, "body", "signature") {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	body, ok := env["body"].(map[string]any)
	if !ok || !m1exact(body, "version", "purpose", "rootId", "rootKeyId", "registrationId", "revision", "environment", "clientId", "origin", "redirectUri", "keyId", "publicKey", "actions", "nodeConfigDigest", "issuedAtMs", "expiresAtMs") {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	for k, want := range map[string]string{"purpose": SocialM1QAOperationOwnerPurpose, "rootId": m1str(root, "rootId"), "rootKeyId": m1str(root, "rootKeyId"), "environment": "testnet-qa", "clientId": m1OperationClient, "origin": "https://social.ynxweb4.com", "redirectUri": "https://social.ynxweb4.com/sso/m1qa/callback", "keyId": keyID, "nodeConfigDigest": c.ExpectedNodeConfigDigest} {
		if m1str(body, k) != want {
			return nil, ErrSocialM1QAOperationOwnerInvalid
		}
	}
	issued, expires := m1int(body, "issuedAtMs"), m1int(body, "expiresAtMs")
	if m1int(body, "version") != 1 || m1int(body, "revision") < 1 || !m1token(m1str(body, "registrationId")) || !m1OperationActions(body["actions"]) || issued < 0 || expires <= issued || expires-issued > 86400000 {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	delegated, e := m1b64(m1str(body, "publicKey"), 32)
	if e != nil || !bytes.Equal(delegated, public) {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	signature, e := m1b64(m1str(env, "signature"), 64)
	if e != nil {
		return nil, e
	}
	canonical, e := m1canonical(body)
	if e != nil || !ed25519.Verify(rootPublic, append([]byte(SocialM1QAOperationOwnerDomain), canonical...), signature) {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	// Parse and validate every original Node v1 row, never select a DTO row only.
	node, e := m1parse(raw[2])
	if e != nil || !m1exact(node, "version", "purpose", "registrations") || m1str(node, "version") != "ynx-social-account-operation-registrations/v1" || m1str(node, "purpose") != "social-original-operation/v1" {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	rows, ok := node["registrations"].([]any)
	if !ok || len(rows) < 1 || len(rows) > 16 {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	seen := map[string]bool{}
	found := false
	for _, v := range rows {
		row, ok := v.(map[string]any)
		if !ok || !m1exact(row, "clientId", "origin", "redirectUri", "keyId", "publicKey", "actions") {
			return nil, ErrSocialM1QAOperationOwnerInvalid
		}
		id, client := m1str(row, "keyId"), m1str(row, "clientId")
		redirect := "https://social.ynxweb4.com/sso/callback"
		if client == m1OperationClient {
			redirect = "https://social.ynxweb4.com/sso/m1qa/callback"
		} else if client != "ynx-social-v1-sso-v1" {
			return nil, ErrSocialM1QAOperationOwnerInvalid
		}
		if !m1token(id) || seen[id] || m1str(row, "origin") != "https://social.ynxweb4.com" || m1str(row, "redirectUri") != redirect {
			return nil, ErrSocialM1QAOperationOwnerInvalid
		}
		seen[id] = true
		rowPublic, e := m1OperationPublic(m1str(row, "publicKey"))
		if e != nil {
			return nil, e
		}
		a, ok := row["actions"].([]any)
		if !ok || len(a) < 1 || len(a) > 4 {
			return nil, ErrSocialM1QAOperationOwnerInvalid
		}
		used := map[string]bool{}
		for _, v := range a {
			s, ok := v.(string)
			if !ok || !m1OperationAction(s) || used[s] {
				return nil, ErrSocialM1QAOperationOwnerInvalid
			}
			used[s] = true
		}
		if id == keyID {
			if client != m1OperationClient || !bytes.Equal(rowPublic, public) || !m1OperationActions(row["actions"]) {
				return nil, ErrSocialM1QAOperationOwnerInvalid
			}
			found = true
		}
	}
	if !found {
		return nil, ErrSocialM1QAOperationOwnerNotConfigured
	}
	o.binding = SocialM1QAOperationOwnerBinding{RegistrationID: m1str(body, "registrationId"), ClientID: m1OperationClient, Origin: "https://social.ynxweb4.com", RedirectURI: "https://social.ynxweb4.com/sso/m1qa/callback", KeyID: keyID, NodeConfigDigest: c.ExpectedNodeConfigDigest, Revision: m1int(body, "revision"), IssuedAtMs: issued, ExpiresAtMs: expires, Actions: []string{"reserve", "read", "terminal", "cancel"}}
	o.ready = true
	if e = o.Current(context.Background()); e != nil {
		return nil, e
	}
	good = true
	return o, nil
}
func (o *SocialM1QAOperationOwner) enter() error {
	if o == nil {
		return ErrSocialM1QAOperationOwnerNotConfigured
	}
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.active {
		o.invalid = true
		return ErrSocialM1QAOperationOwnerInvalid
	}
	if !o.ready {
		if o.constructionErr != nil {
			return o.constructionErr
		}
		return ErrSocialM1QAOperationOwnerNotConfigured
	}
	if o.invalid || o.closed {
		return ErrSocialM1QAOperationOwnerInvalid
	}
	o.active = true
	return nil
}
func (o *SocialM1QAOperationOwner) leave() { o.mu.Lock(); o.active = false; o.mu.Unlock() }
func (o *SocialM1QAOperationOwner) fail() error {
	o.mu.Lock()
	o.invalid = true
	o.mu.Unlock()
	return ErrSocialM1QAOperationOwnerInvalid
}
func (o *SocialM1QAOperationOwner) filesCurrent() error {
	for _, h := range o.files {
		if e := m1check(h); e != nil {
			return o.fail()
		}
		held, e := h.file.Stat()
		if e != nil {
			return o.fail()
		}
		named, e := os.Lstat(h.path)
		if e != nil || !os.SameFile(held, h.info) || !os.SameFile(named, h.info) || !m1safeInfo(held, h.size < 0) || !m1safeInfo(named, h.size < 0) {
			return o.fail()
		}
		if h.size >= 0 && (held.Size() != h.size || named.Size() != h.size || !held.ModTime().Equal(h.info.ModTime()) || !named.ModTime().Equal(h.info.ModTime())) {
			return o.fail()
		}
	}
	return nil
}

// Caller already owns active slot. All last-clock callbacks are followed by
// ctx/source/invalid fences before any signature or public result is released.
func (o *SocialM1QAOperationOwner) current(ctx context.Context) (int64, error) {
	if ctx == nil {
		return 0, ErrSocialM1QAOperationOwnerInvalid
	}
	if e := ctx.Err(); e != nil {
		return 0, e
	}
	if e := o.filesCurrent(); e != nil {
		return 0, e
	}
	at := o.config.Now().UnixMilli()
	o.mu.Lock()
	bad := o.invalid || at < o.last || at < 0 || at > 9007199254740991 || at < o.binding.IssuedAtMs || at >= o.binding.ExpiresAtMs
	if bad {
		o.invalid = true
	} else {
		o.last = at
	}
	o.mu.Unlock()
	if bad {
		return 0, ErrSocialM1QAOperationOwnerInvalid
	}
	if e := ctx.Err(); e != nil {
		return 0, e
	}
	if e := o.filesCurrent(); e != nil {
		return 0, e
	}
	if e := ctx.Err(); e != nil {
		return 0, e
	}
	o.mu.Lock()
	bad = o.invalid
	o.mu.Unlock()
	if bad {
		return 0, ErrSocialM1QAOperationOwnerInvalid
	}
	return at, nil
}
func (o *SocialM1QAOperationOwner) Current(ctx context.Context) error {
	if e := o.enter(); e != nil {
		return e
	}
	defer o.leave()
	_, e := o.current(ctx)
	return e
}
func (o *SocialM1QAOperationOwner) Binding(ctx context.Context) (SocialM1QAOperationOwnerBinding, error) {
	if e := o.enter(); e != nil {
		return SocialM1QAOperationOwnerBinding{}, e
	}
	defer o.leave()
	if _, e := o.current(ctx); e != nil {
		return SocialM1QAOperationOwnerBinding{}, e
	}
	b := o.binding
	b.Actions = append([]string(nil), b.Actions...)
	return b, nil
}
func (o *SocialM1QAOperationOwner) OperationSignerPublic(ctx context.Context) (string, ed25519.PublicKey, error) {
	if e := o.enter(); e != nil {
		return "", nil, e
	}
	defer o.leave()
	if _, e := o.current(ctx); e != nil {
		return "", nil, e
	}
	return o.binding.KeyID, bytes.Clone(o.public), nil
}
func (o *SocialM1QAOperationOwner) SignSocialOriginalOperation(ctx context.Context, preimage []byte) ([]byte, error) {
	if e := o.enter(); e != nil {
		return nil, e
	}
	defer o.leave()
	if ctx == nil || len(preimage) < 1 || len(preimage) > 4096 {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	raw := bytes.Clone(preimage)
	proof, e := m1parse(raw)
	if e != nil || !m1exact(proof, "version", "purpose", "issuer", "audience", "clientId", "keyId", "action", "method", "path", "bodySha256", "issuedAt", "expiresAt", "nonce") {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	action := m1str(proof, "action")
	if m1int(proof, "version") != 1 || m1str(proof, "purpose") != "social-original-operation/v1" || m1str(proof, "issuer") != m1OperationIssuer || m1str(proof, "audience") != m1OperationIssuer+m1OperationPrefix || m1str(proof, "clientId") != m1OperationClient || m1str(proof, "keyId") != o.binding.KeyID || !m1OperationAction(action) || m1str(proof, "method") != "POST" || m1str(proof, "path") != m1OperationPrefix+action || !m1hash(m1str(proof, "bodySha256")) {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	if _, e = m1b64(m1str(proof, "nonce"), 32); e != nil {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	layout := "2006-01-02T15:04:05.000Z"
	start, e := time.Parse(layout, m1str(proof, "issuedAt"))
	if e != nil || start.Format(layout) != m1str(proof, "issuedAt") {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	end, e := time.Parse(layout, m1str(proof, "expiresAt"))
	if e != nil || end.Format(layout) != m1str(proof, "expiresAt") || start.UnixMilli() < 0 || !end.After(start) || end.Sub(start) > 30*time.Second {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	if start.UnixMilli() < o.binding.IssuedAtMs || end.UnixMilli() > o.binding.ExpiresAtMs {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	at, e := o.current(ctx)
	if e != nil {
		return nil, e
	}
	if at < start.UnixMilli() || at >= end.UnixMilli() {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	// Original exact preimage; no reserialize, extra domain, second nonce or retry.
	supplied := bytes.Clone(raw)
	signature, e := o.provider.SignEd25519(ctx, supplied)
	captured := bytes.Clone(signature)
	if e != nil {
		return nil, e
	}
	if !bytes.Equal(supplied, raw) || len(captured) != 64 || !ed25519.Verify(o.public, raw, captured) {
		return nil, o.fail()
	}
	at, e = o.current(ctx)
	if e != nil {
		return nil, e
	}
	if at < start.UnixMilli() || at >= end.UnixMilli() {
		return nil, ErrSocialM1QAOperationOwnerInvalid
	}
	return captured, nil
}

// Cleanup never requires a still-current certificate. During a callback it
// latches invalid and preserves FDs until the outer call leaves.
func (o *SocialM1QAOperationOwner) Close() error {
	if o == nil {
		return nil
	}
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.active {
		o.invalid = true
		return ErrSocialM1QAOperationOwnerInvalid
	}
	if o.closed {
		return o.closeErr
	}
	o.closed = true
	o.invalid = true
	var result error
	for _, h := range o.files {
		result = errors.Join(result, h.closeOriginalOnce())
	}
	o.closeErr = result
	return result
}
