//go:build linux || darwin

package centralbrowserfamily

// SOURCE ONLY: independently admitted root/profile files must be installed by
// the original owner. A digest, QA key, Session or ENV is not that admission.
import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"syscall"
	"time"
)

const SocialM1QAProfilePurpose = "social-m1qa-private-service-profile/v1"
const SocialM1QAProfileSignatureDomain = "YNX_SOCIAL_M1QA_PRIVATE_SERVICE_PROFILE_V1\n"

// Exact 1.0.6-INCOMPLETE-QA public APK. Updating this selection does not update an old
// signed profile: its targetArtifactDigest must still independently match.
const socialM1QAAPK = "29537ed86adfcb2e97459e8cd42bc11d15fccc088d8bc00863c44da8c90b5739"
const socialM1QACallback = "ac7f06a7e7bd2aa2c1a42f85d89e2963f101383cb8cce8fa8a2b01037b90129f"

func socialM1QASelectedArtifact(artifact, callback string) bool {
	return artifact == socialM1QAAPK && callback == socialM1QACallback
}

var ErrSocialM1QAProfileNotConfigured = errors.New("SOCIAL_M1QA_PROFILE_NOT_CONFIGURED")
var ErrSocialM1QAProfileInvalid = errors.New("SOCIAL_M1QA_PROFILE_INVALID")

type SocialM1QATrustedProfileConfig struct {
	RootPath, RootDigest, ProfilePath, ProfileDigest                                    string
	RootBytes, ProfileBytes                                                             int64
	ExpectedRegistryDigest, ExpectedTargetArtifactDigest                                string
	ExpectedCertificateDigest, ExpectedCallbackManifestDigest, ExpectedAssetLinksDigest string
	// Pure synchronous bounded original clock; never reenter this profile.
	Now func() time.Time
}
type SocialM1QAProfileBinding struct {
	PackageID, Activity, ClientID, Origin, RedirectURI, APIMount, Audience                            string
	RegistryDigest, TargetArtifactDigest, CertificateDigest, CallbackManifestDigest, AssetLinksDigest string
	RegistrationID, BackendKeyID                                                                      string
	Revision, IssuedAtMs, ExpiresAtMs                                                                 int64
	Scopes                                                                                            []string
}
type socialM1QAHeldFile struct {
	path      string
	file      *os.File
	info      os.FileInfo
	size      int64
	digest    string
	closeOnce sync.Once
	closeErr  error
}

// Retain the first close result, including uncertain failure; never close an
// already selected descriptor number again after the OS may have recycled it.
func (h *socialM1QAHeldFile) closeOriginalOnce() error {
	h.closeOnce.Do(func() {
		if h.file == nil {
			h.closeErr = ErrSocialM1QAProfileInvalid
			return
		}
		h.closeErr = h.file.Close()
	})
	return h.closeErr
}

// No public constructor other than Open; fields are inaccessible to callers.
type SocialM1QATrustedProfile struct {
	mu                             sync.Mutex
	active, invalid, closed, ready bool
	files                          []*socialM1QAHeldFile
	config                         SocialM1QATrustedProfileConfig
	binding                        SocialM1QAProfileBinding
	backend                        ed25519.PublicKey
	last                           int64
	originalSignedRaw              string
}

func m1sha(b []byte) string { sum := sha256.Sum256(b); return hex.EncodeToString(sum[:]) }
func m1hash(s string) bool {
	b, e := hex.DecodeString(s)
	return e == nil && len(b) == 32 && hex.EncodeToString(b) == s
}
func m1token(s string) bool {
	if len(s) < 1 || len(s) > 128 {
		return false
	}
	for _, c := range s {
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || strings.ContainsRune("._:-", c)) {
			return false
		}
	}
	return true
}
func m1exact(v map[string]any, keys ...string) bool {
	if len(v) != len(keys) {
		return false
	}
	for _, k := range keys {
		if _, ok := v[k]; !ok {
			return false
		}
	}
	return true
}
func m1str(v map[string]any, k string) string { s, _ := v[k].(string); return s }
func m1int(v map[string]any, k string) int64 {
	n, ok := v[k].(json.Number)
	if !ok {
		return -1
	}
	i, e := n.Int64()
	if e != nil || i < 0 || i > 9007199254740991 {
		return -1
	}
	return i
}
func m1canonical(v any) ([]byte, error) {
	var b bytes.Buffer
	e := json.NewEncoder(&b)
	e.SetEscapeHTML(false)
	if err := e.Encode(v); err != nil {
		return nil, err
	}
	return bytes.TrimSuffix(b.Bytes(), []byte{'\n'}), nil
}
func m1parse(raw []byte) (map[string]any, error) {
	if len(raw) < 1 || len(raw) > 16384 {
		return nil, ErrSocialM1QAProfileInvalid
	}
	// ASCII protocol keys/values remove cross-language Unicode escape ambiguity.
	for _, b := range raw {
		if b >= 128 {
			return nil, ErrSocialM1QAProfileInvalid
		}
	}
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber()
	var v map[string]any
	if err := d.Decode(&v); err != nil {
		return nil, err
	}
	var extra any
	if d.Decode(&extra) != io.EOF {
		return nil, ErrSocialM1QAProfileInvalid
	}
	c, e := m1canonical(v)
	if e != nil || !bytes.Equal(c, raw) {
		return nil, ErrSocialM1QAProfileInvalid
	}
	return v, nil
}
func m1b64(s string, n int) ([]byte, error) {
	b, e := base64.RawURLEncoding.DecodeString(s)
	if e != nil || len(b) != n || base64.RawURLEncoding.EncodeToString(b) != s {
		return nil, ErrSocialM1QAProfileInvalid
	}
	return b, nil
}
func m1safeInfo(i os.FileInfo, directory bool) bool {
	st, ok := i.Sys().(*syscall.Stat_t)
	if !ok || i.Mode()&os.ModeSymlink != 0 || i.Mode().Perm()&0022 != 0 {
		return false
	}
	if directory {
		return i.IsDir() && (st.Uid == 0 || st.Uid == uint32(os.Geteuid()))
	}
	return i.Mode().IsRegular() && i.Mode().Perm()&0077 == 0 && st.Uid == uint32(os.Geteuid()) && st.Nlink == 1
}
func m1hold(path, digest string, size int64) ([]*socialM1QAHeldFile, []byte, error) {
	held, raw, err := m1holdOwned(path, digest, size)
	if err != nil {
		for _, h := range held {
			if closeErr := h.closeOriginalOnce(); closeErr != nil {
				err = errors.Join(err, closeErr)
			}
		}
		return nil, nil, err
	}
	return held, raw, nil
}

// Partial custody contract for the original operation owner. All successfully
// opened descriptors transfer even on error; this callee never closes them.
// Legacy m1hold callers retain their no-partial-return wrapper above.
func m1holdOwned(path, digest string, size int64) ([]*socialM1QAHeldFile, []byte, error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path || !m1hash(digest) || size < 1 || size > 16384 {
		return nil, nil, ErrSocialM1QAProfileNotConfigured
	}
	parts := []string{}
	for p := filepath.Dir(path); ; p = filepath.Dir(p) {
		parts = append(parts, p)
		if p == string(filepath.Separator) {
			break
		}
	}
	for i, j := 0, len(parts)-1; i < j; i, j = i+1, j-1 {
		parts[i], parts[j] = parts[j], parts[i]
	}
	parts = append(parts, path)
	held := []*socialM1QAHeldFile{}
	for index, p := range parts {
		i, e := os.Lstat(p)
		directory := index < len(parts)-1
		if e != nil || !m1safeInfo(i, directory) {
			return held, nil, ErrSocialM1QAProfileInvalid
		}
		fd, e := syscall.Open(p, syscall.O_RDONLY|syscall.O_NOFOLLOW|syscall.O_CLOEXEC, 0)
		if e != nil {
			return held, nil, e
		}
		f := os.NewFile(uintptr(fd), p)
		h := &socialM1QAHeldFile{path: p, file: f, size: -1}
		held = append(held, h) // Before Stat/validation can fail.
		fi, e := f.Stat()
		if e != nil || !os.SameFile(i, fi) || !m1safeInfo(fi, directory) {
			return held, nil, ErrSocialM1QAProfileInvalid
		}
		h.info = fi
	}
	final := held[len(held)-1]
	final.size = size
	final.digest = digest
	raw, e := m1read(final)
	if e != nil {
		return held, nil, e
	}
	for _, h := range held {
		if e = m1check(h); e != nil {
			return held, nil, e
		}
	}
	return held, raw, nil
}
func m1read(h *socialM1QAHeldFile) ([]byte, error) {
	if h.size < 0 {
		return nil, nil
	}
	if _, e := h.file.Seek(0, 0); e != nil {
		return nil, e
	}
	b, e := io.ReadAll(io.LimitReader(h.file, 65537))
	if e != nil || int64(len(b)) != h.size || m1sha(b) != h.digest {
		return nil, ErrSocialM1QAProfileInvalid
	}
	return b, nil
}
func m1check(h *socialM1QAHeldFile) error {
	i, e := os.Lstat(h.path)
	if e != nil || !os.SameFile(i, h.info) || !m1safeInfo(i, h.size < 0) {
		return ErrSocialM1QAProfileInvalid
	}
	fi, e := h.file.Stat()
	if e != nil || !os.SameFile(fi, h.info) || !m1safeInfo(fi, h.size < 0) {
		return ErrSocialM1QAProfileInvalid
	}
	if h.size >= 0 {
		if fi.Size() != h.size {
			return ErrSocialM1QAProfileInvalid
		}
		_, e = m1read(h)
	}
	return e
}

func OpenSocialM1QATrustedProfile(c SocialM1QATrustedProfileConfig) (*SocialM1QATrustedProfile, error) {
	if c.Now == nil {
		return nil, ErrSocialM1QAProfileNotConfigured
	}
	for _, s := range []string{c.ExpectedRegistryDigest, c.ExpectedTargetArtifactDigest, c.ExpectedCertificateDigest, c.ExpectedCallbackManifestDigest, c.ExpectedAssetLinksDigest} {
		if !m1hash(s) {
			return nil, ErrSocialM1QAProfileNotConfigured
		}
	}
	if !socialM1QASelectedArtifact(c.ExpectedTargetArtifactDigest, c.ExpectedCallbackManifestDigest) || c.RootPath == c.ProfilePath {
		return nil, ErrSocialM1QAProfileInvalid
	}
	p := &SocialM1QATrustedProfile{config: c, last: -1}
	good := false
	defer func() {
		if !good {
			for _, h := range p.files {
				h.file.Close()
			}
		}
	}()
	rh, rraw, e := m1hold(c.RootPath, c.RootDigest, c.RootBytes)
	if e != nil {
		return nil, e
	}
	p.files = append(p.files, rh...)
	ph, praw, e := m1hold(c.ProfilePath, c.ProfileDigest, c.ProfileBytes)
	if e != nil {
		return nil, e
	}
	p.files = append(p.files, ph...)
	r, e := m1parse(rraw)
	if e != nil || !m1exact(r, "version", "purpose", "rootId", "keyId", "publicKey") || m1int(r, "version") != 1 || m1str(r, "purpose") != SocialM1QAProfilePurpose || !m1token(m1str(r, "rootId")) || !m1token(m1str(r, "keyId")) {
		return nil, ErrSocialM1QAProfileInvalid
	}
	block, rest := pem.Decode([]byte(m1str(r, "publicKey")))
	if block == nil || block.Type != "PUBLIC KEY" || len(rest) != 0 || len(block.Headers) != 0 {
		return nil, ErrSocialM1QAProfileInvalid
	}
	parsed, e := x509.ParsePKIXPublicKey(block.Bytes)
	pub, ok := parsed.(ed25519.PublicKey)
	if e != nil || !ok {
		return nil, ErrSocialM1QAProfileInvalid
	}
	env, e := m1parse(praw)
	if e != nil || !m1exact(env, "body", "signature") {
		return nil, ErrSocialM1QAProfileInvalid
	}
	b, ok := env["body"].(map[string]any)
	if !ok || !m1exact(b, "version", "purpose", "rootId", "rootKeyId", "registrationId", "revision", "environment", "registryDigest", "targetArtifactDigest", "certificateDigest", "callbackManifestDigest", "assetLinksDigest", "packageId", "activity", "clientId", "origin", "redirectUri", "apiMount", "audience", "scopes", "backendKeyId", "backendPublicKey", "allowedProofPaths", "issuedAtMs", "expiresAtMs") {
		return nil, ErrSocialM1QAProfileInvalid
	}
	fixed := map[string]string{"purpose": SocialM1QAProfilePurpose, "rootId": m1str(r, "rootId"), "rootKeyId": m1str(r, "keyId"), "environment": "testnet-qa", "registryDigest": c.ExpectedRegistryDigest, "targetArtifactDigest": c.ExpectedTargetArtifactDigest, "certificateDigest": c.ExpectedCertificateDigest, "callbackManifestDigest": c.ExpectedCallbackManifestDigest, "assetLinksDigest": c.ExpectedAssetLinksDigest, "packageId": "com.ynx.social.m1qa", "activity": "com.ynx.social.matrix.VeilSocialQaLoginCallbackActivity", "clientId": "ynx-social-v1-m1qa-sso-v1", "origin": "https://social.ynxweb4.com", "redirectUri": "https://social.ynxweb4.com/sso/m1qa/callback", "apiMount": "/m1qa", "audience": "ynx:social:identity"}
	for k, v := range fixed {
		if m1str(b, k) != v {
			return nil, ErrSocialM1QAProfileInvalid
		}
	}
	arrayEquals := func(k string, wanted []string) bool {
		a, ok := b[k].([]any)
		if !ok || len(a) != len(wanted) {
			return false
		}
		for i, w := range wanted {
			if a[i] != w {
				return false
			}
		}
		return true
	}
	if m1int(b, "version") != 1 || m1int(b, "revision") < 1 || !m1token(m1str(b, "registrationId")) || !m1token(m1str(b, "backendKeyId")) || !arrayEquals("scopes", []string{"identity:read"}) || !arrayEquals("allowedProofPaths", []string{"/v2/browser-sessions/token-family", "/v2/browser-sessions/introspect"}) {
		return nil, ErrSocialM1QAProfileInvalid
	}
	issued, expires := m1int(b, "issuedAtMs"), m1int(b, "expiresAtMs")
	if issued < 0 || expires <= issued || expires-issued > 86400000 {
		return nil, ErrSocialM1QAProfileInvalid
	}
	backend, e := m1b64(m1str(b, "backendPublicKey"), 32)
	if e != nil {
		return nil, e
	}
	sig, e := m1b64(m1str(env, "signature"), 64)
	if e != nil {
		return nil, e
	}
	canonical, e := m1canonical(b)
	if e != nil || !ed25519.Verify(pub, append([]byte(SocialM1QAProfileSignatureDomain), canonical...), sig) {
		return nil, ErrSocialM1QAProfileInvalid
	}
	p.originalSignedRaw = string(praw)
	p.backend = append(ed25519.PublicKey(nil), backend...)
	p.binding = SocialM1QAProfileBinding{PackageID: fixed["packageId"], Activity: fixed["activity"], ClientID: fixed["clientId"], Origin: fixed["origin"], RedirectURI: fixed["redirectUri"], APIMount: fixed["apiMount"], Audience: fixed["audience"], RegistryDigest: c.ExpectedRegistryDigest, TargetArtifactDigest: c.ExpectedTargetArtifactDigest, CertificateDigest: c.ExpectedCertificateDigest, CallbackManifestDigest: c.ExpectedCallbackManifestDigest, AssetLinksDigest: c.ExpectedAssetLinksDigest, RegistrationID: m1str(b, "registrationId"), BackendKeyID: m1str(b, "backendKeyId"), Revision: m1int(b, "revision"), IssuedAtMs: issued, ExpiresAtMs: expires, Scopes: []string{"identity:read"}}
	p.ready = true
	if e = p.Current(context.Background()); e != nil {
		return nil, e
	}
	good = true
	return p, nil
}
func (p *SocialM1QATrustedProfile) enter() error {
	if p == nil {
		return ErrSocialM1QAProfileNotConfigured
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.active {
		p.invalid = true
		return ErrSocialM1QAProfileInvalid
	}
	if !p.ready {
		return ErrSocialM1QAProfileNotConfigured
	}
	if p.invalid || p.closed {
		return ErrSocialM1QAProfileInvalid
	}
	p.active = true
	return nil
}
func (p *SocialM1QATrustedProfile) leave() { p.mu.Lock(); p.active = false; p.mu.Unlock() }
func (p *SocialM1QATrustedProfile) Current(ctx context.Context) error {
	if e := p.enter(); e != nil {
		return e
	}
	defer p.leave()
	if ctx == nil {
		return ErrSocialM1QAProfileInvalid
	}
	if e := ctx.Err(); e != nil {
		return e
	}
	for _, h := range p.files {
		if e := m1check(h); e != nil {
			p.mu.Lock()
			p.invalid = true
			p.mu.Unlock()
			return e
		}
	}
	at := p.config.Now().UnixMilli()
	p.mu.Lock()
	bad := p.invalid || at < p.last || at < 0 || at > 9007199254740991
	p.last = at
	if bad || at < p.binding.IssuedAtMs || at >= p.binding.ExpiresAtMs {
		p.invalid = true
		bad = true
	}
	p.mu.Unlock()
	if bad {
		return ErrSocialM1QAProfileInvalid
	}
	if e := ctx.Err(); e != nil {
		return e
	}
	// After the LAST external clock: recheck every held ancestor/file identity/hash.
	for _, h := range p.files {
		if e := m1check(h); e != nil {
			p.mu.Lock()
			p.invalid = true
			p.mu.Unlock()
			return e
		}
	}
	p.mu.Lock()
	bad = p.invalid
	p.mu.Unlock()
	if bad {
		return ErrSocialM1QAProfileInvalid
	}
	return nil
}
func (p *SocialM1QATrustedProfile) Binding() (SocialM1QAProfileBinding, error) {
	if e := p.Current(context.Background()); e != nil {
		return SocialM1QAProfileBinding{}, e
	}
	if e := p.enter(); e != nil {
		return SocialM1QAProfileBinding{}, e
	}
	defer p.leave()
	b := p.binding
	b.Scopes = append([]string(nil), b.Scopes...)
	return b, nil
}
func (p *SocialM1QATrustedProfile) BackendSignerPublic() (string, ed25519.PublicKey, error) {
	if e := p.Current(context.Background()); e != nil {
		return "", nil, e
	}
	if e := p.enter(); e != nil {
		return "", nil, e
	}
	defer p.leave()
	return p.binding.BackendKeyID, append(ed25519.PublicKey(nil), p.backend...), nil
}
func (p *SocialM1QATrustedProfile) AuthorizeRequest(ctx context.Context, method, path string) error {
	if e := p.Current(ctx); e != nil {
		return e
	}
	if method != "POST" || (path != "/v2/browser-sessions/token-family" && path != "/v2/browser-sessions/introspect") {
		return ErrSocialM1QAProfileInvalid
	}
	return nil
}
func (p *SocialM1QATrustedProfile) AssertBackendProofRule(ctx context.Context, method, path, keyID string, public []byte) error {
	if e := p.AuthorizeRequest(ctx, method, path); e != nil {
		return e
	}
	if keyID != p.binding.BackendKeyID || !bytes.Equal(public, p.backend) {
		return ErrSocialM1QAProfileInvalid
	}
	return p.Current(ctx)
}
func (p *SocialM1QATrustedProfile) Close() error {
	if p == nil {
		return nil
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.active {
		p.invalid = true
		return ErrSocialM1QAProfileInvalid
	}
	if p.closed {
		return nil
	}
	p.closed = true
	var failures []string
	for _, h := range p.files {
		if e := h.file.Close(); e != nil {
			failures = append(failures, e.Error())
		}
	}
	sort.Strings(failures)
	if len(failures) > 0 {
		return fmt.Errorf("profile close: %s", strings.Join(failures, ";"))
	}
	return nil
}

// Immutable exact signed source, from the SAME held private owner. It is public
// registration evidence, not Native account/instance admission or a sign key.
func (p *SocialM1QATrustedProfile) OriginalSignedProfileRaw(ctx context.Context) (string, error) {
	if e := p.Current(ctx); e != nil {
		return "", e
	}
	if e := p.enter(); e != nil {
		return "", e
	}
	raw := p.originalSignedRaw
	expected := p.config.ProfileDigest
	p.leave()
	if len(raw) == 0 || len(raw) > 16384 || m1sha([]byte(raw)) != expected {
		return "", ErrSocialM1QAProfileInvalid
	}
	if e := p.Current(ctx); e != nil {
		return "", e
	}
	return raw, nil
}
