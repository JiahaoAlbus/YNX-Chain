package centralbrowserfamily

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"io"
	"reflect"
	"strings"
	"time"
	"unicode/utf8"
)

// OriginalSocialAccountCapture is an in-process private transport reference.
// It is NOT Native Original, a signed credential, absence evidence, or a grant.
// The product's sealed login owner must deliver it only through its actual
// native-internal fixed-origin authenticated HTTPS channel. There is no DTO
// constructor or restoration from returned response fields.
type OriginalSocialAccountCapture struct {
	owner              *SocialOperationTransport
	lifetime           *originalAccountLifetime
	wire, proof, raw   string
	frame              originalSocialAccountFrame
	nativeSequence     int64
	nativeRegistration string
}

type originalSocialAccountFrame struct {
	Version         string          `json:"version"`
	Phase           string          `json:"phase"`
	Issuer          string          `json:"issuer"`
	Account         string          `json:"account"`
	ClientID        string          `json:"clientId"`
	Origin          string          `json:"origin"`
	SessionID       string          `json:"sessionId"`
	FamilyID        string          `json:"familyId"`
	Generation      int64           `json:"generation"`
	Operation       string          `json:"operation"`
	Challenge       json.RawMessage `json:"challenge"`
	Prepared        json.RawMessage `json:"preparedPublicCommitment"`
	Association     *string         `json:"associationCommitment"`
	ReservedAt      *int64          `json:"reservedAtMs"`
	ObservedAtMS    int64           `json:"observedAtMs"`
	ExpiresAtMS     int64           `json:"expiresAtMs"`
	State           string          `json:"state"`
	DispatchAllowed bool            `json:"dispatchAllowed"`
}

func decodeOriginalAccountJSON(raw []byte, out any) error {
	if len(raw) == 0 || len(raw) > 65536 || !utf8.Valid(raw) {
		return ErrSocialOperationUnknown
	}
	// Reject duplicate members at every depth before decoding a typed frame.
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber()
	depth := 0
	var value func() error
	value = func() error {
		depth++
		defer func() { depth-- }()
		if depth > 32 {
			return ErrSocialOperationUnknown
		}
		t, e := d.Token()
		if e != nil {
			return ErrSocialOperationUnknown
		}
		delim, ok := t.(json.Delim)
		if !ok {
			return nil
		}
		switch delim {
		case '{':
			seen := map[string]bool{}
			for d.More() {
				k, e := d.Token()
				key, ok := k.(string)
				if e != nil || !ok || seen[key] {
					return ErrSocialOperationUnknown
				}
				seen[key] = true
				if e = value(); e != nil {
					return e
				}
			}
			t, e = d.Token()
			if e != nil || t != json.Delim('}') {
				return ErrSocialOperationUnknown
			}
		case '[':
			for d.More() {
				if e = value(); e != nil {
					return e
				}
			}
			t, e = d.Token()
			if e != nil || t != json.Delim(']') {
				return ErrSocialOperationUnknown
			}
		default:
			return ErrSocialOperationUnknown
		}
		return nil
	}
	if value() != nil {
		return ErrSocialOperationUnknown
	}
	if _, e := d.Token(); e != io.EOF {
		return ErrSocialOperationUnknown
	}
	d = json.NewDecoder(bytes.NewReader(raw))
	d.DisallowUnknownFields()
	d.UseNumber()
	if d.Decode(out) != nil || d.Decode(new(any)) != io.EOF {
		return ErrSocialOperationUnknown
	}
	return nil
}

func sameOriginalAccountJSON(a, b []byte) bool {
	var x, y any
	return decodeOriginalAccountJSON(a, &x) == nil && decodeOriginalAccountJSON(b, &y) == nil && reflect.DeepEqual(x, y)
}
func originalAccountToken(s string) bool {
	raw, e := base64.RawURLEncoding.Strict().DecodeString(s)
	return e == nil && len(raw) == 32 && base64.RawURLEncoding.EncodeToString(raw) == s
}

// Exact application storage/transport schema, not evidence admission. Validate
// before encoding/json's case-insensitive struct matching and null defaults.
func exactAccountObject(raw []byte, schema map[string]byte) (map[string]json.RawMessage, error) {
	var fields map[string]json.RawMessage
	if decodeOriginalAccountJSON(raw, &fields) != nil || fields == nil || len(fields) != len(schema) {
		return nil, ErrSocialOperationUnknown
	}
	for key, kind := range schema {
		v, ok := fields[key]
		if !ok {
			return nil, ErrSocialOperationUnknown
		}
		v = bytes.TrimSpace(v)
		if bytes.Equal(v, []byte("null")) {
			if kind == '?' || kind == '#' {
				continue
			}
			return nil, ErrSocialOperationUnknown
		}
		switch kind {
		case 's', '?':
			var s string
			if len(v) == 0 || v[0] != '"' || json.Unmarshal(v, &s) != nil {
				return nil, ErrSocialOperationUnknown
			}
		case 'n', '#':
			var n int64
			if json.Unmarshal(v, &n) != nil || n < 0 || n > 9007199254740991 {
				return nil, ErrSocialOperationUnknown
			}
		case 'b':
			if !bytes.Equal(v, []byte("false")) && !bytes.Equal(v, []byte("true")) {
				return nil, ErrSocialOperationUnknown
			}
		case 'o':
			if len(v) == 0 || v[0] != '{' {
				return nil, ErrSocialOperationUnknown
			}
		default:
			return nil, ErrSocialOperationUnknown
		}
	}
	return fields, nil
}

func exactAccountNested(fields map[string]json.RawMessage) error {
	if _, e := exactAccountObject(fields["challenge"], map[string]byte{"operation": 's', "nonce": 's', "requestDigest": 's', "issuedAtMs": 'n', "expiresAtMs": 'n'}); e != nil {
		return e
	}
	_, e := exactAccountObject(fields["preparedPublicCommitment"], map[string]byte{"version": 's', "operation": 's', "revision": 's', "identity": 's', "device": 's', "issuerMessage": 's', "targetMessage": 's'})
	return e
}
func parseOriginalSocialAccountFrame(raw []byte, wire string, start, end time.Time) (originalSocialAccountFrame, error) {
	var f originalSocialAccountFrame
	fields, e := exactAccountObject(raw, map[string]byte{"version": 's', "phase": 's', "issuer": 's', "account": 's', "clientId": 's', "origin": 's', "sessionId": 's', "familyId": 's', "generation": 'n', "operation": 's', "challenge": 'o', "preparedPublicCommitment": 'o', "associationCommitment": '?', "reservedAtMs": '#', "observedAtMs": 'n', "expiresAtMs": 'n', "state": 's', "dispatchAllowed": 'b'})
	if e != nil || exactAccountNested(fields) != nil {
		return f, ErrSocialOperationUnknown
	}
	inputFields, e := exactAccountObject([]byte(wire), map[string]byte{"clientId": 's', "grantToken": 's', "intentId": 's', "challenge": 'o', "preparedPublicCommitment": 'o'})
	if e != nil || exactAccountNested(inputFields) != nil {
		return f, ErrSocialOperationUnknown
	}
	var input struct {
		ClientID  string          `json:"clientId"`
		Grant     string          `json:"grantToken"`
		Intent    string          `json:"intentId"`
		Challenge json.RawMessage `json:"challenge"`
		Prepared  json.RawMessage `json:"preparedPublicCommitment"`
	}
	if decodeOriginalAccountJSON(raw, &f) != nil || decodeOriginalAccountJSON([]byte(wire), &input) != nil {
		return f, ErrSocialOperationUnknown
	}
	var keys map[string]json.RawMessage
	if json.Unmarshal(raw, &keys) != nil || len(keys) != 18 {
		return f, ErrSocialOperationUnknown
	}
	if f.Version != "ynx-social-original-account-acquisition/v1" || f.Issuer != "https://wallet-auth.ynxweb4.com" || f.ClientID != "ynx-social-v1-m1qa-sso-v1" || f.ClientID != input.ClientID || f.Origin != "https://social.ynxweb4.com" || f.Operation != input.Intent || !originalAccountToken(f.SessionID) || !originalAccountToken(f.FamilyID) || f.Generation < 1 || f.Generation > 9007199254740991 || f.DispatchAllowed {
		return f, ErrSocialOperationUnknown
	}
	if len(f.Account) != 42 || !strings.HasPrefix(f.Account, "ynx1") {
		return f, ErrSocialOperationUnknown
	}
	for _, r := range f.Account[4:] {
		if !strings.ContainsRune("023456789acdefghjklmnpqrstuvwxyz", r) {
			return f, ErrSocialOperationUnknown
		}
	}
	if !sameOriginalAccountJSON(f.Challenge, input.Challenge) || !sameOriginalAccountJSON(f.Prepared, input.Prepared) {
		return f, ErrSocialOperationUnknown
	}
	var challenge struct {
		Operation string `json:"operation"`
		Nonce     string `json:"nonce"`
		Digest    string `json:"requestDigest"`
		Issued    int64  `json:"issuedAtMs"`
		Expires   int64  `json:"expiresAtMs"`
	}
	if decodeOriginalAccountJSON(f.Challenge, &challenge) != nil || challenge.Operation != f.Operation || !originalAccountToken(challenge.Nonce) || !socialHex(challenge.Digest) || challenge.Issued < 0 || challenge.Expires <= challenge.Issued {
		return f, ErrSocialOperationUnknown
	}
	if f.ObservedAtMS < start.UnixMilli() || f.ObservedAtMS < challenge.Issued || f.ExpiresAtMS <= f.ObservedAtMS || f.ExpiresAtMS > end.UnixMilli() || f.ExpiresAtMS > challenge.Expires || f.ExpiresAtMS > 9007199254740991 {
		return f, ErrSocialOperationUnknown
	}
	switch f.Phase {
	case "captured":
		if f.Association != nil || f.ReservedAt != nil || f.State != "not-reserved" {
			return f, ErrSocialOperationUnknown
		}
	case "joined":
		if f.Association == nil || !socialHex(*f.Association) || f.ReservedAt == nil || *f.ReservedAt < challenge.Issued || *f.ReservedAt > f.ObservedAtMS || f.State != "unknown-pending" {
			return f, ErrSocialOperationUnknown
		}
	default:
		return f, ErrSocialOperationUnknown
	}
	return f, nil
}

// AcquireOriginalAccount authenticates READ and captures actual same-Store
// account/session/family facts before reserve. It never proves first absence.
func (c *SocialOperationTransport) AcquireOriginalAccount(ctx context.Context, rawBody string) (*OriginalSocialAccountCapture, error) {
	started := time.Now() // monotonic anchor BEFORE the original physical READ
	out, e := c.call(ctx, "read", rawBody, "", true, "")
	if e != nil {
		return nil, e
	}
	f, at, end, e := originalAccountResponse(out, rawBody)
	if e != nil || f.Phase != "captured" {
		return nil, ErrSocialOperationUnknown
	}
	if e = c.ownerCurrentWithin(ctx, at, time.UnixMilli(f.ExpiresAtMS)); e != nil {
		return nil, e
	}
	_ = end
	life, e := newOriginalAccountLifetime(ctx, started, at, time.UnixMilli(f.ExpiresAtMS))
	if e != nil {
		return nil, e
	}
	return &OriginalSocialAccountCapture{owner: c, lifetime: life, wire: rawBody, proof: out.originalReadProof, raw: out.originalAccountRaw, frame: f, nativeSequence: out.originalNativeSequence, nativeRegistration: out.originalNativeRegistration}, nil
}
func originalAccountResponse(out SocialOperationDecision, wire string) (originalSocialAccountFrame, time.Time, time.Time, error) {
	var proof struct {
		Issued  string `json:"issuedAt"`
		Expires string `json:"expiresAt"`
	}
	if json.Unmarshal([]byte(out.originalReadProof), &proof) != nil {
		return originalSocialAccountFrame{}, time.Time{}, time.Time{}, ErrSocialOperationUnknown
	}
	at, e := time.Parse("2006-01-02T15:04:05.000Z", proof.Issued)
	if e != nil {
		return originalSocialAccountFrame{}, at, time.Time{}, e
	}
	end, e := time.Parse("2006-01-02T15:04:05.000Z", proof.Expires)
	if e != nil {
		return originalSocialAccountFrame{}, at, end, e
	}
	f, e := parseOriginalSocialAccountFrame([]byte(out.originalAccountRaw), wire, at, end)
	return f, at, end, e
}

// JoinOriginalAccount only reads the exact original reservation with the SAME
// retained READ proof/body/nonce. No new signing, reserve, or effect on UNKNOWN.
func (c *SocialOperationTransport) JoinOriginalAccount(ctx context.Context, original *OriginalSocialAccountCapture) (*OriginalSocialAccountCapture, error) {
	if c == nil || original == nil || original.owner != c || original.frame.Phase != "captured" || original.lifetime == nil {
		return nil, ErrSocialOperationUnknown
	}
	callCtx, done, e := original.lifetime.borrow(ctx, false)
	if e != nil {
		return nil, e
	}
	defer done()
	out, e := c.call(callCtx, "read", original.wire, "", true, original.proof)
	if e != nil {
		return nil, e
	}
	f, at, _, e := originalAccountResponse(out, original.wire)
	old := original.frame
	if e != nil || f.Phase != "joined" || f.Issuer != old.Issuer || f.Account != old.Account || f.ClientID != old.ClientID || f.SessionID != old.SessionID || f.FamilyID != old.FamilyID || f.Generation != old.Generation || f.ObservedAtMS < old.ObservedAtMS || f.ExpiresAtMS > old.ExpiresAtMS {
		return nil, ErrSocialOperationUnknown
	}
	if e = c.ownerCurrentWithin(ctx, at, time.UnixMilli(f.ExpiresAtMS)); e != nil {
		return nil, e
	}
	if e = original.lifetime.restrictExpiry(at, time.UnixMilli(f.ExpiresAtMS)); e != nil {
		return nil, e
	}
	if e = original.lifetime.check(ctx, false); e != nil {
		return nil, e
	}
	return &OriginalSocialAccountCapture{owner: c, lifetime: original.lifetime, wire: original.wire, proof: original.proof, raw: out.originalAccountRaw, frame: f, nativeSequence: out.originalNativeSequence, nativeRegistration: out.originalNativeRegistration}, nil
}

// PrivateAuthenticatedDeliveryBytes is transport data only. The native
// receiver MUST establish peer/service profile and original login/request
// ownership independently; arbitrary bytes passed by Go cannot create Native
// Original. Do not expose these private fields through UI, logs, or journals.
func (original *OriginalSocialAccountCapture) PrivateAuthenticatedDeliveryBytes(ctx context.Context) ([]byte, error) {
	if original == nil || original.owner == nil || original.lifetime == nil {
		return nil, ErrSocialOperationUnknown
	}
	if e := original.lifetime.check(ctx, false); e != nil {
		return nil, e
	}
	var p struct {
		Issued string `json:"issuedAt"`
	}
	if json.Unmarshal([]byte(original.proof), &p) != nil {
		return nil, ErrSocialOperationUnknown
	}
	at, e := time.Parse("2006-01-02T15:04:05.000Z", p.Issued)
	if e != nil {
		return nil, e
	}
	if e = original.owner.ownerCurrentWithin(ctx, at, time.UnixMilli(original.frame.ExpiresAtMS)); e != nil {
		return nil, e
	}
	if e = original.lifetime.check(ctx, false); e != nil {
		return nil, e
	}
	return []byte(original.raw), nil
}
