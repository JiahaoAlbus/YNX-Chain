//go:build linux || darwin

package centralbrowserfamily

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// All signing here uses a fixed PUBLIC fixture seed, never an enrolled issuer,
// user identity, Native runtime, network, or production authorization.
type nativeHistoryPublicFixture struct {
	config  SocialNativeInstanceSourceConfig
	rootKey ed25519.PrivateKey
	records [][]byte
	now     int64
	dir     string
}

func nativeHistoryCanonical(t *testing.T, value any) []byte {
	t.Helper()
	raw, err := m1canonical(value)
	if err != nil {
		t.Fatal(err)
	}
	return raw
}
func nativeHistorySigned(t *testing.T, body map[string]any, domain string, key ed25519.PrivateKey) []byte {
	t.Helper()
	canonical := nativeHistoryCanonical(t, body)
	signature := ed25519.Sign(key, append([]byte(domain), canonical...))
	return nativeHistoryCanonical(t, map[string]any{"body": body, "signature": base64.RawURLEncoding.EncodeToString(signature)})
}
func nativeHistoryWrite(t *testing.T, path string, raw []byte) {
	t.Helper()
	if err := os.WriteFile(path, raw, 0600); err != nil {
		t.Fatal(err)
	}
}
func newNativeHistoryPublicFixture(t *testing.T, states ...string) *nativeHistoryPublicFixture {
	t.Helper()
	if len(states) == 0 {
		t.Fatal("PUBLIC fixture needs a current status")
	}
	dir, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	f := &nativeHistoryPublicFixture{rootKey: ed25519.NewKeyFromSeed(bytes.Repeat([]byte{7}, ed25519.SeedSize)), now: 1700000200000, dir: dir}
	publicDER, err := x509.MarshalPKIXPublicKey(f.rootKey.Public())
	if err != nil {
		t.Fatal(err)
	}
	root := nativeHistoryCanonical(t, map[string]any{"version": 1, "rootId": "PUBLIC_ROOT", "keyId": "PUBLIC_ROOT_KEY", "publicKey": string(pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: publicDER})), "purposes": []string{SocialNativeRegistrationPurpose, SocialNativeStatusPurpose}})
	f.config = SocialNativeInstanceSourceConfig{
		RootPath: filepath.Join(dir, "root.json"), RootDigest: nativeSourceDigest(root), RootBytes: int64(len(root)),
		RegistrationPath: filepath.Join(dir, "registration.json"), StatusPath: filepath.Join(dir, "status-current.json"),
		ExpectedProfileDigest: nativeSourceDigest([]byte("PUBLIC_PROFILE")), ExpectedCentralRegistryDigest: nativeSourceDigest([]byte("PUBLIC_REGISTRY")),
		ExpectedOperationRegistrationDigest: nativeSourceDigest([]byte("PUBLIC_OPERATION")), ExpectedServiceBinaryDigest: nativeSourceDigest([]byte("PUBLIC_BINARY")),
		ExpectedTLSSPKIDigest: nativeSourceDigest([]byte("PUBLIC_TLS")), ExpectedCertificateDigest: nativeSourceDigest([]byte("PUBLIC_CERTIFICATE")),
		ExpectedCallbackManifestDigest: nativeSourceDigest([]byte("PUBLIC_CALLBACK")), MinimumRegistrationRevision: 1, MinimumStatusSequence: 1,
		Now: func() time.Time { return time.UnixMilli(f.now) },
	}
	registration := map[string]any{
		"version": 1, "purpose": SocialNativeRegistrationPurpose, "environment": "testnet-qa", "registrationId": "PUBLIC_REGISTRATION", "registrationRevision": 1,
		"rootId": "PUBLIC_ROOT", "rootKeyId": "PUBLIC_ROOT_KEY", "instanceId": "PUBLIC_INSTANCE", "instanceKeyId": "PUBLIC_INSTANCE_KEY",
		"instancePublicKey": base64.RawURLEncoding.EncodeToString(ed25519.NewKeyFromSeed(bytes.Repeat([]byte{9}, ed25519.SeedSize)).Public().(ed25519.PublicKey)),
		"serviceOrigin":     "https://social.ynxweb4.com", "apiMount": "/m1qa", "packageId": "com.ynx.social.m1qa", "certificateDigest": f.config.ExpectedCertificateDigest,
		"callbackManifestDigest": f.config.ExpectedCallbackManifestDigest, "clientId": m1OperationClient, "profileRegistrationId": "PUBLIC_PROFILE_REGISTRATION", "profileRevision": 1,
		"profileDigest": f.config.ExpectedProfileDigest, "centralRegistryDigest": f.config.ExpectedCentralRegistryDigest, "operationRegistrationDigest": f.config.ExpectedOperationRegistrationDigest,
		"serviceBinaryDigest": f.config.ExpectedServiceBinaryDigest, "tlsSpkiDigest": f.config.ExpectedTLSSPKIDigest, "actions": []string{"capture", "join", "observe", "retire"},
		"issuedAtMs": f.now - 8640000, "expiresAtMs": f.now + 3600000,
	}
	regRaw := nativeHistorySigned(t, registration, socialNativeRegistrationDomain, f.rootKey)
	f.config.RegistrationDigest = nativeSourceDigest(regRaw)
	f.config.RegistrationBytes = int64(len(regRaw))
	nativeHistoryWrite(t, f.config.RootPath, root)
	nativeHistoryWrite(t, f.config.RegistrationPath, regRaw)
	for i, state := range states {
		issued := f.now - 60000 - int64(len(states)-i)*30000
		if i == len(states)-1 {
			issued = f.now - 1000
		}
		var previous any
		if i > 0 {
			previous = nativeSourceDigest(f.records[i-1])
		}
		body := map[string]any{"version": 1, "purpose": SocialNativeStatusPurpose, "rootId": "PUBLIC_ROOT", "rootKeyId": "PUBLIC_ROOT_KEY", "instanceId": "PUBLIC_INSTANCE", "registrationId": "PUBLIC_REGISTRATION", "registrationRevision": 1, "registrationDigest": f.config.RegistrationDigest, "statusSequence": i + 1, "status": state, "previousStatusDigest": previous, "effectiveAtMs": issued, "issuedAtMs": issued, "expiresAtMs": issued + 30000}
		f.records = append(f.records, nativeHistorySigned(t, body, socialNativeStatusDomain, f.rootKey))
	}
	f.publish(t)
	return f
}
func (f *nativeHistoryPublicFixture) publish(t *testing.T) {
	t.Helper()
	f.config.StatusHistory = nil
	for i, raw := range f.records[:len(f.records)-1] {
		path := filepath.Join(f.dir, fmt.Sprintf("status-history-%03d.json", i+1))
		nativeHistoryWrite(t, path, raw)
		f.config.StatusHistory = append(f.config.StatusHistory, SocialNativeStatusHistoryFile{Path: path, Digest: nativeSourceDigest(raw), Bytes: int64(len(raw))})
	}
	current := f.records[len(f.records)-1]
	nativeHistoryWrite(t, f.config.StatusPath, current)
	f.config.StatusDigest = nativeSourceDigest(current)
	f.config.StatusBytes = int64(len(current))
}
func (f *nativeHistoryPublicFixture) rewrite(t *testing.T, index int, change func(map[string]any)) {
	t.Helper()
	for i := index; i < len(f.records); i++ {
		record, err := m1parse(f.records[i])
		if err != nil {
			t.Fatal(err)
		}
		body := record["body"].(map[string]any)
		if i == index {
			change(body)
		} else {
			body["previousStatusDigest"] = nativeSourceDigest(f.records[i-1])
		}
		f.records[i] = nativeHistorySigned(t, body, socialNativeStatusDomain, f.rootKey)
	}
	f.publish(t)
}
func nativeHistoryOpen(t *testing.T, f *nativeHistoryPublicFixture) *SocialNativeInstanceSource {
	t.Helper()
	source, err := OpenSocialNativeInstanceSource(f.config)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if err := source.Close(); err != nil {
			t.Error(err)
		}
	})
	return source
}

func TestOriginalStatusHistoryCompletePrefix(t *testing.T) {
	for _, states := range [][]string{{"active"}, {"active", "active", "active"}, {"active", "withdrawing", "revoked", "revoked"}} {
		t.Run(fmt.Sprint(states), func(t *testing.T) {
			f := newNativeHistoryPublicFixture(t, states...)
			source := nativeHistoryOpen(t, f)
			delegation, history, err := source.OriginalDelegationRaw(context.Background())
			if err != nil || len(delegation) != 3 || len(history) != len(states)-1 {
				t.Fatalf("prefix/current separation: %d %d %v", len(delegation), len(history), err)
			}
			if !bytes.Equal(delegation[2], f.records[len(states)-1]) {
				t.Fatal("current bytes changed")
			}
			for i, raw := range history {
				if !bytes.Equal(raw, f.records[i]) {
					t.Fatal("original predecessor changed")
				}
			}
			// Both returned levels are disposable copies, not retained source storage.
			delegation[2][0] ^= 1
			if len(history) > 0 {
				history[0][0] ^= 1
				history[0] = nil
			}
			again, prefix, err := source.OriginalDelegationRaw(context.Background())
			if err != nil || !bytes.Equal(again[2], f.records[len(states)-1]) {
				t.Fatal("current alias", err)
			}
			if len(prefix) > 0 && !bytes.Equal(prefix[0], f.records[0]) {
				t.Fatal("history alias")
			}
			binding, err := source.Binding(context.Background())
			if err != nil || binding.SequenceFloor != int64(len(states)) || binding.Status != states[len(states)-1] {
				t.Fatal("binding", err)
			}
		})
	}
}

func TestOriginalStatusHistoryRejectsMalformedChain(t *testing.T) {
	cases := []struct {
		name string
		edit func(*testing.T, *nativeHistoryPublicFixture)
	}{
		{"missing", func(t *testing.T, f *nativeHistoryPublicFixture) { f.config.StatusHistory = nil }},
		{"truncated", func(t *testing.T, f *nativeHistoryPublicFixture) { f.config.StatusHistory = f.config.StatusHistory[1:] }},
		{"gap", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 1, func(b map[string]any) { b["statusSequence"] = 4 })
		}},
		{"duplicate-sequence", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 1, func(b map[string]any) { b["statusSequence"] = 1; b["previousStatusDigest"] = nil })
		}},
		{"genesis-not-active", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["status"] = "revoked" })
		}},
		{"genesis-has-parent", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["previousStatusDigest"] = f.config.RootDigest })
		}},
		{"missing-parent", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 1, func(b map[string]any) { b["previousStatusDigest"] = nil })
		}},
		{"wrong-parent", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 1, func(b map[string]any) { b["previousStatusDigest"] = f.config.RootDigest })
		}},
		{"malformed-parent", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 1, func(b map[string]any) { b["previousStatusDigest"] = 42 })
		}},
		{"registration-id", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["registrationId"] = "OTHER" })
		}},
		{"registration-revision", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["registrationRevision"] = 2 })
		}},
		{"registration-digest", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["registrationDigest"] = f.config.RootDigest })
		}},
		{"root-id", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["rootId"] = "OTHER" })
		}},
		{"instance-id", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["instanceId"] = "OTHER" })
		}},
		{"unsafe-integer", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["expiresAtMs"] = int64(9007199254740992) })
		}},
		{"exponent", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["version"] = json.Number("1e0") })
		}},
		{"bad-window", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["expiresAtMs"] = b["issuedAtMs"] })
		}},
		{"unknown-field", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["extra"] = true })
		}},
		{"unknown-state", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 0, func(b map[string]any) { b["status"] = "approved" })
		}},
		{"withdrawing-reversal", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 1, func(b map[string]any) { b["status"] = "withdrawing" })
		}},
		{"revoked-reversal", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.rewrite(t, 1, func(b map[string]any) { b["status"] = "revoked" })
		}},
		{"noncanonical", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.records[0] = append(f.records[0], '\n')
			f.publish(t)
		}},
		{"invalid-signature", func(t *testing.T, f *nativeHistoryPublicFixture) {
			r, e := m1parse(f.records[0])
			if e != nil {
				t.Fatal(e)
			}
			r["signature"] = base64.RawURLEncoding.EncodeToString(make([]byte, 64))
			f.records[0] = nativeHistoryCanonical(t, r)
			f.publish(t)
		}},
		{"duplicate-record", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.records[1] = bytes.Clone(f.records[0])
			f.publish(t)
		}},
		{"current-in-prefix", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.records[0] = bytes.Clone(f.records[2])
			f.publish(t)
		}},
		{"current-byte-mismatch", func(t *testing.T, f *nativeHistoryPublicFixture) { f.config.StatusDigest = f.config.RootDigest }},
		{"same-selected-path", func(t *testing.T, f *nativeHistoryPublicFixture) {
			f.config.StatusHistory[0].Path = f.config.StatusPath
		}},
		{"minimum-sequence", func(t *testing.T, f *nativeHistoryPublicFixture) { f.config.MinimumStatusSequence = 4 }},
		{"minimum-revision", func(t *testing.T, f *nativeHistoryPublicFixture) { f.config.MinimumRegistrationRevision = 2 }},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			f := newNativeHistoryPublicFixture(t, "active", "active", "active")
			tc.edit(t, f)
			s, err := OpenSocialNativeInstanceSource(f.config)
			if err == nil {
				s.Close()
				t.Fatal("accepted malformed original chain")
			}
		})
	}
}

func TestOriginalStatusHistoryHeldFilesAndClock(t *testing.T) {
	for _, action := range []string{"same-inode-history", "replaced-history", "same-inode-current", "cancel", "expiry", "clock-rollback", "config-copy"} {
		t.Run(action, func(t *testing.T) {
			f := newNativeHistoryPublicFixture(t, "active", "active")
			s := nativeHistoryOpen(t, f)
			ctx := context.Background()
			path := f.config.StatusHistory[0].Path
			switch action {
			case "same-inode-history":
				raw := bytes.Clone(f.records[0])
				raw[len(raw)-2] ^= 1
				nativeHistoryWrite(t, path, raw)
			case "replaced-history":
				replacement := filepath.Join(f.dir, "replacement.json")
				nativeHistoryWrite(t, replacement, f.records[0])
				if e := os.Rename(replacement, path); e != nil {
					t.Fatal(e)
				}
			case "same-inode-current":
				raw := bytes.Clone(f.records[1])
				raw[len(raw)-2] ^= 1
				nativeHistoryWrite(t, f.config.StatusPath, raw)
			case "cancel":
				var cancel context.CancelFunc
				ctx, cancel = context.WithCancel(ctx)
				cancel()
			case "expiry":
				f.now += 30000
			case "clock-rollback":
				f.now--
			case "config-copy":
				f.config.StatusHistory[0] = SocialNativeStatusHistoryFile{Path: "/PUBLIC/not-a-source", Digest: "invalid", Bytes: 1}
				if e := s.Current(ctx); e != nil {
					t.Fatal("caller selector alias", e)
				}
				nativeHistoryWrite(t, path, append(bytes.Clone(f.records[0]), ' '))
			}
			delegation, history, err := s.OriginalDelegationRaw(ctx)
			if err == nil || delegation != nil || history != nil {
				t.Fatal("invalid source released originals")
			}
			if action == "cancel" {
				if err := s.Current(context.Background()); err != nil {
					t.Fatal("cancel poisoned unrelated owner", err)
				}
			}
		})
	}
}

func TestOriginalStatusHistorySelectorBounds(t *testing.T) {
	f := newNativeHistoryPublicFixture(t, "active")
	for _, count := range []int{255, 256} {
		c := f.config
		c.StatusHistory = make([]SocialNativeStatusHistoryFile, count)
		for i := range c.StatusHistory {
			c.StatusHistory[i] = SocialNativeStatusHistoryFile{Path: fmt.Sprintf("/PUBLIC/%d", i), Digest: c.RootDigest, Bytes: 1}
		}
		err := nativeStatusHistorySelectors(c)
		if (count == 255) != (err == nil) {
			t.Fatalf("count %d: %v", count, err)
		}
	}
	c := f.config
	c.StatusHistory = make([]SocialNativeStatusHistoryFile, 24)
	for i := range c.StatusHistory {
		c.StatusHistory[i] = SocialNativeStatusHistoryFile{Path: fmt.Sprintf("/PUBLIC/%d", i), Digest: c.RootDigest, Bytes: 16384}
	}
	if nativeStatusHistorySelectors(c) == nil {
		t.Fatal("aggregate original byte bound lost")
	}
	for _, size := range []int64{0, -1, 16385, 9223372036854775807} {
		c := f.config
		c.RootBytes = size
		if nativeStatusHistorySelectors(c) == nil {
			t.Fatal("invalid selector byte count", size)
		}
	}
}
