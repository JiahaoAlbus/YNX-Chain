package centralbrowserfamily

import (
	"context"
	"crypto"
	"crypto/ed25519"
	"errors"
	"io"
	"strings"
	"testing"
	"time"
)

type unavailableSocialSigner struct{}

func (*unavailableSocialSigner) Public() crypto.PublicKey { return ed25519.PublicKey(make([]byte, 32)) }
func (*unavailableSocialSigner) Sign(io.Reader, []byte, crypto.SignerOpts) ([]byte, error) {
	return nil, errors.New("fixture signer unavailable")
}
func TestSocialTransportTypedNilAndEarlyBound(t *testing.T) {
	var key *unavailableSocialSigner
	if _, e := NewSocialOperationTransport("new-purpose", key, nil, time.Now); e == nil {
		t.Fatal("typed nil accepted")
	}
	c, e := NewSocialOperationTransport("new-purpose", &unavailableSocialSigner{}, nil, time.Now)
	if e != nil {
		t.Fatal(e)
	}
	if _, e = c.Call(context.Background(), "reserve", strings.Repeat("x", 65537)); e == nil {
		t.Fatal("oversize accepted")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, e = c.Call(ctx, "read", "{}"); e == nil {
		t.Fatal("cancel accepted")
	}
}
func TestSocialTransportSwallowedClockReentryCloses(t *testing.T) {
	var c *SocialOperationTransport
	now := func() time.Time {
		if c != nil {
			c.Call(context.Background(), "read", "{}")
		}
		return time.UnixMilli(1)
	}
	var e error
	c, e = NewSocialOperationTransport("new-purpose", &unavailableSocialSigner{}, nil, now)
	if e != nil {
		t.Fatal(e)
	}
	body := `{"challenge":{"expiresAtMs":30001,"issuedAtMs":1,"nonce":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","operation":"fd1-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","requestDigest":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"},"clientId":"ynx-social-v1-sso-v1","grantToken":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","intentId":"fd1-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","preparedPublicCommitment":{}}`
	if _, e = c.Call(context.Background(), "reserve", body); e == nil || !c.invalid.Load() {
		t.Fatal("swallowed nested clock failure reopened")
	}
}
func TestSocialProofASCIIEncoding(t *testing.T) {
	b, e := socialProofJSON(map[string]any{"z": "<", "a": 1})
	if e != nil || string(b) != `{"a":1,"z":"<"}` {
		t.Fatalf("proof encoding %s %v", b, e)
	}
}
