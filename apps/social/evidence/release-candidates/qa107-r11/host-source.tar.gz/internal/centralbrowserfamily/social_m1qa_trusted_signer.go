//go:build linux || darwin

package centralbrowserfamily

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"errors"
	"reflect"
	"sync"
	"time"
)

var ErrSocialM1QATrustedSignerUnavailable = errors.New("SOCIAL_M1QA_TRUSTED_SIGNER_NOT_CONFIGURED")
var ErrSocialM1QATrustedSigningInvalid = errors.New("SOCIAL_M1QA_TRUSTED_SIGNING_INVALID")

// Only the original owner can qualify the underlying protected holder/provider.
// This interface alone does not prove custody, enrollment or registration.
type SocialM1QAProtectedEd25519 interface {
	SignEd25519(context.Context, []byte) ([]byte, error)
}

// All authority inputs are captured privately; no raw-key loading or fallback.
type SocialM1QATrustedSignerAdapter struct {
	mu                     sync.Mutex
	active, invalid, ready bool
	profile                *SocialM1QATrustedProfile
	keyID                  string
	public                 ed25519.PublicKey
	protected              SocialM1QAProtectedEd25519
}

func socialM1QANilProtected(v SocialM1QAProtectedEd25519) bool {
	if v == nil {
		return true
	}
	r := reflect.ValueOf(v)
	switch r.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Pointer, reflect.Slice, reflect.UnsafePointer:
		return r.IsNil()
	}
	return false
}

func NewSocialM1QATrustedSignerAdapter(profile *SocialM1QATrustedProfile, keyID string, public []byte, protected SocialM1QAProtectedEd25519) (*SocialM1QATrustedSignerAdapter, error) {
	if profile == nil || socialM1QANilProtected(protected) || len(public) != ed25519.PublicKeySize {
		return nil, ErrSocialM1QATrustedSignerUnavailable
	}
	// Hyp's original key ID grammar, stricter than generic profile tokens.
	if len(keyID) < 1 || len(keyID) > 128 {
		return nil, ErrSocialM1QATrustedSigningInvalid
	}
	for _, c := range []byte(keyID) {
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_' || c == '-' || c == '.' || c == '~') {
			return nil, ErrSocialM1QATrustedSigningInvalid
		}
	}
	captured := append(ed25519.PublicKey(nil), public...)
	actualID, actualPublic, err := profile.BackendSignerPublic()
	if err != nil {
		return nil, err
	}
	if keyID != actualID || !bytes.Equal(captured, actualPublic) {
		return nil, ErrSocialM1QATrustedSigningInvalid
	}
	if err = profile.Current(context.Background()); err != nil {
		return nil, err
	}
	return &SocialM1QATrustedSignerAdapter{profile: profile, keyID: keyID, public: captured, protected: protected, ready: true}, nil
}

func (s *SocialM1QATrustedSignerAdapter) enter() error {
	if s == nil {
		return ErrSocialM1QATrustedSignerUnavailable
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.active {
		s.invalid = true
		return ErrSocialM1QATrustedSigningInvalid
	}
	if !s.ready {
		return ErrSocialM1QATrustedSignerUnavailable
	}
	if s.invalid {
		return ErrSocialM1QATrustedSigningInvalid
	}
	s.active = true
	return nil
}
func (s *SocialM1QATrustedSignerAdapter) leave() { s.mu.Lock(); s.active = false; s.mu.Unlock() }
func (s *SocialM1QATrustedSignerAdapter) valid() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return !s.invalid
}

func (s *SocialM1QATrustedSignerAdapter) proof(raw []byte) (string, int64, error) {
	if len(raw) < 1 || len(raw) > 4096 {
		return "", 0, ErrSocialM1QATrustedSigningInvalid
	}
	v, err := m1parse(raw)
	if err != nil || !m1exact(v, "version", "issuer", "audience", "clientId", "keyId", "method", "path", "bodySha256", "issuedAt", "nonce") {
		return "", 0, ErrSocialM1QATrustedSigningInvalid
	}
	issuer := "https://wallet-auth.ynxweb4.com"
	path := m1str(v, "path")
	if m1int(v, "version") != 1 || m1str(v, "issuer") != issuer || m1str(v, "audience") != issuer+"/v2/browser-sessions" || m1str(v, "clientId") != "ynx-social-v1-m1qa-sso-v1" || m1str(v, "keyId") != s.keyID || m1str(v, "method") != "POST" || (path != "/v2/browser-sessions/token-family" && path != "/v2/browser-sessions/introspect") || !m1hash(m1str(v, "bodySha256")) {
		return "", 0, ErrSocialM1QATrustedSigningInvalid
	}
	if _, err = m1b64(m1str(v, "nonce"), 32); err != nil {
		return "", 0, ErrSocialM1QATrustedSigningInvalid
	}
	at := m1str(v, "issuedAt")
	parsed, err := time.Parse("2006-01-02T15:04:05.000Z", at)
	if err != nil || parsed.Year() < 1 || parsed.Year() > 9999 || parsed.UTC().Format("2006-01-02T15:04:05.000Z") != at {
		return "", 0, ErrSocialM1QATrustedSigningInvalid
	}
	return path, parsed.UnixMilli(), nil
}

// Checks the already-captured profile clock value, without another external Now
// callback after Current's final held-source fence. This is a snapshot, not a
// remote revocation lease or independent action/nonce authority.
func (s *SocialM1QATrustedSignerAdapter) fresh(issued int64) error {
	s.profile.mu.Lock()
	at := s.profile.last
	bad := s.profile.invalid || s.profile.closed || !s.profile.ready
	s.profile.mu.Unlock()
	if bad || at < issued || at-issued > 30000 || !s.valid() {
		return ErrSocialM1QATrustedSigningInvalid
	}
	return nil
}

func (s *SocialM1QATrustedSignerAdapter) SignEd25519(ctx context.Context, message []byte) ([]byte, error) {
	// Reentry latches before malformed input/context handling; normal invalid
	// input outside an active callback does not permanently invalidate the signer.
	if err := s.enter(); err != nil {
		return nil, err
	}
	defer s.leave()
	if ctx == nil {
		return nil, ErrSocialM1QATrustedSigningInvalid
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if len(message) < 1 || len(message) > 4096 {
		return nil, ErrSocialM1QATrustedSigningInvalid
	}
	original := append([]byte(nil), message...)
	path, issued, err := s.proof(original)
	if err != nil {
		return nil, err
	}
	if err = s.profile.AssertBackendProofRule(ctx, "POST", path, s.keyID, s.public); err != nil {
		return nil, err
	}
	if err = s.fresh(issued); err != nil {
		return nil, err
	}
	// Provider gets its own mutable copy; mutation must never alter preimage.
	providerMessage := append([]byte(nil), original...)
	signature, signErr := s.protected.SignEd25519(ctx, providerMessage)
	if !s.valid() {
		return nil, ErrSocialM1QATrustedSigningInvalid
	}
	if signErr != nil {
		return nil, signErr
	}
	if len(signature) != ed25519.SignatureSize || !bytes.Equal(providerMessage, original) {
		return nil, ErrSocialM1QATrustedSigningInvalid
	}
	capturedSignature := append([]byte(nil), signature...)
	if !ed25519.Verify(s.public, original, capturedSignature) {
		return nil, ErrSocialM1QATrustedSigningInvalid
	}
	// This is the final external-callback boundary. Current checks original ctx,
	// finite original Now and source AFTER that clock/ctx callback. No additional
	// external Now/provider/context callback runs after it before release.
	if err = s.profile.AssertBackendProofRule(ctx, "POST", path, s.keyID, s.public); err != nil {
		return nil, err
	}
	if err = s.fresh(issued); err != nil {
		return nil, err
	}
	return capturedSignature, nil
}
