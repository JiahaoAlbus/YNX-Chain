package centralbrowserfamily

import (
	"encoding/base64"
	"net/http"
	"testing"
)

// Prepared protocol-boundary checks only. NOT_RUN under the retained runtime
// restriction; these do not authenticate the raw credential or native grant.
func TestInheritedM1EligibilityVersionedCarrier(t *testing.T) {
	raw := `{"version":2}`
	encoded := base64.RawURLEncoding.EncodeToString([]byte(raw))
	h := http.Header{}
	h.Set("X-YNX-Social-Account-Eligibility-V2", encoded)
	got, err := captureOriginalSocialEligibilityHeaderForClient(h, "ynx-social-v1-m1qa-sso-v1")
	if err != nil || got != raw {
		t.Fatal("exact M1 v2 carrier refused")
	}
	if _, err = captureOriginalSocialEligibilityHeaderForClient(h, "ynx-social-v1-sso-v1"); err == nil {
		t.Fatal("prod accepted M1 carrier")
	}
	h = http.Header{}
	h.Set("X-YNX-Social-Account-Eligibility-V1", encoded)
	if _, err = captureOriginalSocialEligibilityHeaderForClient(h, "ynx-social-v1-m1qa-sso-v1"); err == nil {
		t.Fatal("M1 accepted old v1 carrier")
	}
	h = http.Header{}
	h.Add("X-YNX-Social-Account-Eligibility-V2", encoded)
	h.Add("X-YNX-Social-Account-Eligibility-V2", encoded)
	if _, err = captureOriginalSocialEligibilityHeaderForClient(h, "ynx-social-v1-m1qa-sso-v1"); err == nil {
		t.Fatal("duplicate carrier accepted")
	}
}
