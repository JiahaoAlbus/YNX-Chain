package centralbrowserfamily

import (
	"encoding/json"
	"strings"
	"testing"
	"time"
)

func TestOriginalAccountFrameExactRequestedBinding(t *testing.T) {
	token := strings.Repeat("A", 43)
	challenge := map[string]any{"operation": "original-1", "nonce": token, "requestDigest": strings.Repeat("a", 64), "issuedAtMs": 500, "expiresAtMs": 30000}
	prepared := map[string]any{"version": "ynx-social-first-enrollment-prepared/v1", "operation": "original-1", "revision": "1", "identity": "identity", "device": "device", "issuerMessage": "original issuer Type4", "targetMessage": "original target Type4"}
	wire, _ := json.Marshal(map[string]any{"clientId": "ynx-social-v1-m1qa-sso-v1", "grantToken": token, "intentId": "original-1", "challenge": challenge, "preparedPublicCommitment": prepared})
	f := map[string]any{"version": "ynx-social-original-account-acquisition/v1", "phase": "captured", "issuer": "https://wallet-auth.ynxweb4.com", "account": "ynx1" + strings.Repeat("0", 38), "clientId": "ynx-social-v1-m1qa-sso-v1", "origin": "https://social.ynxweb4.com", "sessionId": token, "familyId": token, "generation": 1, "operation": "original-1", "challenge": challenge, "preparedPublicCommitment": prepared, "associationCommitment": nil, "reservedAtMs": nil, "observedAtMs": 1001, "expiresAtMs": 25000, "state": "not-reserved", "dispatchAllowed": false}
	check := func(want bool) {
		t.Helper()
		raw, _ := json.Marshal(f)
		_, e := parseOriginalSocialAccountFrame(raw, string(wire), time.UnixMilli(1000), time.UnixMilli(31000))
		if (e == nil) != want {
			t.Fatalf("accepted=%v want=%v", e == nil, want)
		}
	}
	check(true)
	f["dispatchAllowed"] = true
	check(false)
	f["dispatchAllowed"] = false
	f["associationCommitment"] = strings.Repeat("b", 64)
	check(false)
	f["phase"] = "joined"
	f["state"] = "unknown-pending"
	f["reservedAtMs"] = 1000
	check(true)
	f["reservedAtMs"] = 1002
	check(false)
	f["reservedAtMs"] = 1000
	f["expiresAtMs"] = 31001
	check(false)
	f["expiresAtMs"] = 25000
	f["foreign"] = true
	check(false)
	delete(f, "foreign")
	changed := map[string]any{}
	for k, v := range prepared {
		changed[k] = v
	}
	changed["revision"] = "2"
	f["preparedPublicCommitment"] = changed
	check(false)
}
func TestOriginalAccountJSONRejectsDuplicateAndDeepObjects(t *testing.T) {
	for _, raw := range []string{`{"x":1,"x":2}`, `{"x":{"a":1,"a":2}}`, strings.Repeat("[", 40) + "0" + strings.Repeat("]", 40), `{} {}`, string([]byte{0xff})} {
		var v any
		if decodeOriginalAccountJSON([]byte(raw), &v) == nil {
			t.Fatal("accepted invalid bounded JSON")
		}
	}
}
