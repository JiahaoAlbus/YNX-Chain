package centralbrowserfamily

import (
	"encoding/base64"
	"net/http"
	"strings"
	"testing"
)

func TestPreparedOriginalEligibilityCarrierBoundaries(t *testing.T) {
	raw := `{"version":1}`
	h := http.Header{}
	h.Set("X-YNX-Social-Account-Eligibility-V1", base64.RawURLEncoding.EncodeToString([]byte(raw)))
	got, err := captureOriginalSocialEligibilityHeader(h)
	if err != nil || got != raw {
		t.Fatal("exact carrier")
	}
	h.Add("X-YNX-Social-Account-Eligibility-V1", h.Get("X-YNX-Social-Account-Eligibility-V1"))
	if _, e := captureOriginalSocialEligibilityHeader(h); e == nil {
		t.Fatal("duplicate")
	}
	h.Set("X-YNX-Social-Account-Eligibility-V1", strings.Repeat("A", 10924))
	if _, e := captureOriginalSocialEligibilityHeader(h); e == nil {
		t.Fatal("capacity")
	}
	h.Set("X-YNX-Social-Account-Eligibility-V1", "e30=")
	if _, e := captureOriginalSocialEligibilityHeader(h); e == nil {
		t.Fatal("padding")
	}
}
