package centralbrowserfamily

import (
	"encoding/json"
	"strings"
	"testing"
	"time"
)

func oacPublicFrame() (map[string]any, map[string]any) {
	token := strings.Repeat("A", 43)
	ch := map[string]any{"operation": "public-1", "nonce": token, "requestDigest": strings.Repeat("a", 64), "issuedAtMs": 0, "expiresAtMs": 30000}
	prep := map[string]any{"version": "ynx-social-first-enrollment-prepared/v1", "operation": "public-1", "revision": "1", "identity": "public-i", "device": "public-d", "issuerMessage": "PUBLIC dummy", "targetMessage": "PUBLIC dummy"}
	w := map[string]any{"clientId": "ynx-social-v1-m1qa-sso-v1", "grantToken": token, "intentId": "public-1", "challenge": ch, "preparedPublicCommitment": prep}
	f := map[string]any{"version": "ynx-social-original-account-acquisition/v1", "phase": "captured", "issuer": "https://wallet-auth.ynxweb4.com", "account": "ynx1" + strings.Repeat("0", 38), "clientId": "ynx-social-v1-m1qa-sso-v1", "origin": "https://social.ynxweb4.com", "sessionId": token, "familyId": token, "generation": 1, "operation": "public-1", "challenge": ch, "preparedPublicCommitment": prep, "associationCommitment": nil, "reservedAtMs": nil, "observedAtMs": 0, "expiresAtMs": 25000, "state": "not-reserved", "dispatchAllowed": false}
	return f, w
}
func oacCheck(t *testing.T, f, w map[string]any, valid bool) {
	t.Helper()
	raw, _ := json.Marshal(f)
	wire, _ := json.Marshal(w)
	_, err := parseOriginalSocialAccountFrame(raw, string(wire), time.UnixMilli(0), time.UnixMilli(30000))
	if (err == nil) != valid {
		t.Fatalf("acceptance=%v expected=%v", err == nil, valid)
	}
}
func TestOACExactFrameSchema(t *testing.T) {
	f, w := oacPublicFrame()
	oacCheck(t, f, w, true)
	for k := range f {
		t.Run("case/"+k, func(t *testing.T) {
			f, w := oacPublicFrame()
			v := f[k]
			delete(f, k)
			f[strings.ToUpper(k[:1])+k[1:]] = v
			oacCheck(t, f, w, false)
		})
		if k != "associationCommitment" && k != "reservedAtMs" {
			t.Run("null/"+k, func(t *testing.T) { f, w := oacPublicFrame(); f[k] = nil; oacCheck(t, f, w, false) })
		}
	}
	for _, key := range []string{"associationCommitment", "reservedAtMs"} {
		t.Run("joined-null/"+key, func(t *testing.T) {
			f, w := oacPublicFrame()
			f["phase"] = "joined"
			f["state"] = "unknown-pending"
			f["associationCommitment"] = strings.Repeat("b", 64)
			f["reservedAtMs"] = 0
			oacCheck(t, f, w, true)
			f[key] = nil
			oacCheck(t, f, w, false)
		})
	}
}
func TestOACExactNestedAndInputSchema(t *testing.T) {
	for _, part := range []string{"challenge", "preparedPublicCommitment"} {
		f, _ := oacPublicFrame()
		for key := range f[part].(map[string]any) {
			for _, mode := range []string{"case", "null"} {
				t.Run(part+"/"+key+"/"+mode, func(t *testing.T) {
					f, w := oacPublicFrame()
					m := f[part].(map[string]any)
					if mode == "null" {
						m[key] = nil
					} else {
						v := m[key]
						delete(m, key)
						m[strings.ToUpper(key[:1])+key[1:]] = v
					}
					oacCheck(t, f, w, false)
				})
			}
		}
	}
	_, w := oacPublicFrame()
	for k := range w {
		t.Run("wire/"+k, func(t *testing.T) {
			f, w := oacPublicFrame()
			v := w[k]
			delete(w, k)
			w[strings.ToUpper(k[:1])+k[1:]] = v
			oacCheck(t, f, w, false)
		})
	}
	f, w := oacPublicFrame()
	w["grantToken"] = nil
	oacCheck(t, f, w, false)
}
