//go:build linux || darwin

package centralbrowserfamily

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
)

// The actual Native physical-request owner supplies only these request facts.
// Account/session/family/generation and Central phase never come from this DTO.
type SocialNativePhysicalRequestBinding struct {
	LoginInstanceDigest, NativeRequestDigest, TLSExporterDigest         string
	Operation, ChallengeNonce, ChallengeRequestDigest, PreparedRevision string
	IssuerMessageDigest, TargetMessageDigest, Identity, Device          string
	// Sequence belongs to the original Central persisted phase, not a local
	// clock/counter. The private acquisition representation supplies it.
	Sequence int64
}

// There is no exported constructor, bytes setter, or restoration from an ACK.
type SocialNativeCurrentPreimage struct {
	source                             *SocialNativeInstanceSource
	account                            *OriginalSocialAccountCapture
	body                               map[string]any
	frameRaw, statusRaw, canonicalBody string
	issued, expires                    int64
}

func (s *SocialNativeInstanceSource) PrepareOriginalCurrent(ctx context.Context, a *OriginalSocialAccountCapture, f SocialNativePhysicalRequestBinding) (*SocialNativeCurrentPreimage, error) {
	if s == nil || a == nil || a.owner == nil || f.Sequence < 1 || f.Sequence > 9007199254740991 {
		return nil, ErrSocialNativeInstanceNotConfigured
	}
	for _, d := range []string{f.LoginInstanceDigest, f.NativeRequestDigest, f.TLSExporterDigest, f.ChallengeRequestDigest, f.IssuerMessageDigest, f.TargetMessageDigest} {
		if !m1hash(d) {
			return nil, ErrSocialNativeInstanceInvalid
		}
	}
	raw, e := a.PrivateAuthenticatedDeliveryBytes(ctx)
	if e != nil {
		return nil, e
	}
	defer clear(raw)
	frame, e := m1parse(raw)
	if e != nil {
		return nil, e
	}
	original := a.frame
	var ch map[string]any
	var prep map[string]any
	if decodeOriginalAccountJSON(original.Challenge, &ch) != nil || decodeOriginalAccountJSON(original.Prepared, &prep) != nil {
		return nil, ErrSocialNativeInstanceInvalid
	}
	if f.Operation != original.Operation || f.ChallengeNonce != m1str(ch, "nonce") || f.ChallengeRequestDigest != m1str(ch, "requestDigest") || f.PreparedRevision != m1str(prep, "revision") || f.Identity != m1str(prep, "identity") || f.Device != m1str(prep, "device") {
		return nil, ErrSocialNativeInstanceInvalid
	}
	for _, m := range []struct{ field, domain, want string }{{"issuerMessage", "YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_ISSUER_V1\n", f.IssuerMessageDigest}, {"targetMessage", "YNX_SOCIAL_ACCOUNT_ELIGIBILITY_TYPE4_TARGET_V1\n", f.TargetMessageDigest}} {
		message, err := base64.RawURLEncoding.DecodeString(m1str(prep, m.field))
		if err != nil || base64.RawURLEncoding.EncodeToString(message) != m1str(prep, m.field) || nativeSourceDigest(append([]byte(m.domain), message...)) != m.want {
			return nil, ErrSocialNativeInstanceInvalid
		}
	}
	b, e := s.Binding(ctx)
	if e != nil {
		return nil, e
	}
	if b.Status != "active" {
		return nil, ErrSocialNativeInstanceInvalid
	}
	if a.owner.nativeSource != s || a.nativeRegistration != b.RegistrationDigest || a.nativeSequence != f.Sequence {
		return nil, ErrSocialNativeInstanceInvalid
	}
	if e = s.enter(); e != nil {
		return nil, e
	}
	now, e := s.current(ctx)
	s.leave()
	if e != nil {
		return nil, e
	}
	end := now + 30000
	for _, v := range []int64{b.ExpiresAtMS, original.ExpiresAtMS, m1int(ch, "expiresAtMs")} {
		if v < end {
			end = v
		}
	}
	if now >= end {
		return nil, ErrSocialNativeInstanceInvalid
	}
	phase, action, state := original.Phase, "capture", "not-reserved"
	if phase == "joined" {
		action = "join"
		state = "unknown-pending"
	} else if phase != "captured" {
		return nil, ErrSocialNativeInstanceInvalid
	}
	canonicalFrame, e := m1canonical(frame)
	if e != nil || !bytes.Equal(canonicalFrame, raw) {
		return nil, ErrSocialNativeInstanceInvalid
	}
	body := map[string]any{"version": 1, "purpose": SocialNativeCurrentPurpose, "instanceId": b.InstanceID, "instanceKeyId": b.KeyID, "registrationDigest": b.RegistrationDigest, "sequence": f.Sequence, "action": action, "phase": phase, "requestId": f.Operation, "loginInstanceDigest": f.LoginInstanceDigest, "nativeRequestDigest": f.NativeRequestDigest, "operation": f.Operation, "challengeNonce": f.ChallengeNonce, "challengeRequestDigest": f.ChallengeRequestDigest, "preparedRevision": f.PreparedRevision, "issuerMessageDigest": f.IssuerMessageDigest, "targetMessageDigest": f.TargetMessageDigest, "identity": f.Identity, "device": f.Device, "accountIssuer": original.Issuer, "account": original.Account, "clientId": original.ClientID, "origin": original.Origin, "sessionId": original.SessionID, "familyId": original.FamilyID, "generation": original.Generation, "associationCommitment": original.Association, "reservedAtMs": original.ReservedAt, "centralFrameDigest": nativeSourceDigest(raw), "delegationStatusDigest": nativeSourceDigest([]byte(b.StatusRaw)), "historicalCarrierDigest": nil, "tlsExporterDigest": f.TLSExporterDigest, "state": state, "issuedAtMs": now, "expiresAtMs": end}
	c, e := m1canonical(body)
	if e != nil {
		return nil, e
	}
	return &SocialNativeCurrentPreimage{source: s, account: a, body: body, frameRaw: string(raw), statusRaw: b.StatusRaw, canonicalBody: string(c), issued: now, expires: end}, nil
}

func (p *SocialNativeCurrentPreimage) Current(ctx context.Context) error {
	if p == nil || p.source == nil || p.account == nil {
		return ErrSocialNativeInstanceNotConfigured
	}
	raw, e := p.account.PrivateAuthenticatedDeliveryBytes(ctx)
	if e != nil {
		return e
	}
	defer clear(raw)
	if string(raw) != p.frameRaw {
		return ErrSocialNativeInstanceInvalid
	}
	if e = p.source.enter(); e != nil {
		return e
	}
	defer p.source.leave()
	at, e := p.source.current(ctx)
	if e != nil {
		return e
	}
	if at < p.issued || at >= p.expires || p.source.statusRaw != p.statusRaw || m1str(p.source.status, "status") != "active" {
		return ErrSocialNativeInstanceInvalid
	}
	if p.account.owner.invalid.Load() || p.account.owner.owner == nil {
		return ErrSocialNativeInstanceInvalid
	}
	if e = p.account.owner.owner.filesCurrent(); e != nil {
		return e
	}
	p.account.owner.owner.mu.Lock()
	invalid := p.account.owner.owner.invalid || p.account.owner.owner.closed
	p.account.owner.owner.mu.Unlock()
	if invalid {
		return ErrSocialNativeInstanceInvalid
	}
	for _, h := range p.source.files {
		if m1check(h) != nil {
			return p.source.fail()
		}
	}
	p.source.mu.Lock()
	invalid = p.source.invalid || p.source.closed
	p.source.mu.Unlock()
	if invalid || ctx.Err() != nil {
		return ErrSocialNativeInstanceInvalid
	}
	return nil
}

// Only a typed original preimage can reach the dedicated protected provider.
// This is public signing input, not secret/key export or an admission result.
func (p *SocialNativeCurrentPreimage) SigningInput(ctx context.Context) ([]byte, error) {
	if e := p.Current(ctx); e != nil {
		return nil, e
	}
	return []byte(socialNativeCurrentDomain + p.canonicalBody), nil
}
func (p *SocialNativeCurrentPreimage) RetainedCarrier(ctx context.Context, signature []byte) ([]byte, error) {
	if e := p.Current(ctx); e != nil {
		return nil, e
	}
	if len(signature) != 64 || !verifyNativeCurrentSignature(p.source.public, []byte(socialNativeCurrentDomain+p.canonicalBody), signature) {
		return nil, ErrSocialNativeInstanceInvalid
	}
	// Outer total encoded bound includes all escaped full historical/private raw.
	out, e := m1canonical(map[string]any{"body": p.body, "signature": base64.RawURLEncoding.EncodeToString(signature), "accountFrame": p.frameRaw, "delegationStatus": p.statusRaw, "historicalCarrier": nil})
	if e != nil || len(out) > 65536 {
		clear(out)
		return nil, ErrSocialNativeInstanceInvalid
	}
	if e = p.Current(ctx); e != nil {
		clear(out)
		return nil, e
	}
	return out, nil
}
func (*SocialNativeCurrentPreimage) MarshalJSON() ([]byte, error) {
	return nil, ErrSocialNativeInstanceInvalid
}
func (*SocialNativeCurrentPreimage) String() string { return "social-native-current-preimage[private]" }

// Captured original deadline, never a renewed authority window.
func (p *SocialNativeCurrentPreimage) ExpiresAtMS() int64 {
	if p == nil {
		return 0
	}
	return p.expires
}

// No callback or clock after the last external current check. This only
// rechecks the held original files, captured deadline and sticky owners.
func (p *SocialNativeCurrentPreimage) CheckHeld(ctx context.Context) error {
	if p == nil || p.source == nil || p.account == nil || p.account.owner == nil || p.account.owner.owner == nil {
		return ErrSocialNativeInstanceInvalid
	}
	p.source.mu.Lock()
	at := p.source.last
	bad := p.source.active || p.source.invalid || p.source.closed
	p.source.mu.Unlock()
	if bad || at < p.issued || at >= p.expires || p.account.owner.invalid.Load() {
		return ErrSocialNativeInstanceInvalid
	}
	if err := p.account.owner.owner.filesCurrent(); err != nil {
		return err
	}
	return p.source.heldAfterClock(ctx, at)
}

// Keep the public carrier opaque to callers; no decoded response fills an
// Original, expected account, or a source selection.
var _ json.Marshaler = (*SocialNativeCurrentPreimage)(nil)

func verifyNativeCurrentSignature(pub ed25519.PublicKey, msg, signature []byte) bool {
	return ed25519.Verify(pub, msg, signature)
}
