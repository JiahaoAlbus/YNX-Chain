//go:build linux || darwin

package centralbrowserfamily

import (
	"strings"
	"testing"
)

// Public artifact identities only. No profile signing, credential, file access,
// network, registration, or native authorization occurs in this test.
func TestSocialM1QASelectedArtifact106(t *testing.T) {
	const current = "29537ed86adfcb2e97459e8cd42bc11d15fccc088d8bc00863c44da8c90b5739"
	const retired105 = "c5b7694ed13129fa34825b5776a02cbc330d84b2ce67bcd3d195d0f219d1cf63"
	const retiredX70 = "23703d1b0a9138317c6bf7335f5e0217fbdef95660c6ab9ff781fd6923205a5d"
	const callback = "ac7f06a7e7bd2aa2c1a42f85d89e2963f101383cb8cce8fa8a2b01037b90129f"
	const retired105Callback = "566458adb6f95113cb5e039e171ffbb06ef0f2b4e512e328799a766c06ed7dd5"
	const unresolvedPreviousCallback = "19fe72c1047bb24098d49b204af174ab1182b04abbcf791e4145a6c755e4a319"
	const previous = "d2709ce6902165c2498c6c5f6d55d64d6deb357b66426e414e9099b57bc2eada"
	for _, tc := range []struct {
		name, artifact, callback string
		want                     bool
	}{
		{"exact-current", current, callback, true},
		{"retired-105-callback", current, retired105Callback, false},
		{"retired-105-artifact-and-callback", retired105, retired105Callback, false},
		{"previous-unresolved-callback", current, unresolvedPreviousCallback, false},
		{"retired-105", retired105, callback, false},
		{"retired-x70", retiredX70, callback, false},
		{"previous-release", previous, callback, false},
		{"uppercase", strings.ToUpper(current), callback, false},
		{"missing-artifact", "", callback, false},
		{"trailing-space", current + " ", callback, false},
		{"missing-callback", current, "", false},
		{"different-callback", current, strings.Repeat("0", 64), false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			if got := socialM1QASelectedArtifact(tc.artifact, tc.callback); got != tc.want {
				t.Fatalf("artifact selection = %v, want %v", got, tc.want)
			}
		})
	}
}
