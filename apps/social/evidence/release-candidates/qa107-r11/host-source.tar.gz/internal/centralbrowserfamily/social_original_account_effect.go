package centralbrowserfamily

import (
	"context"
	"encoding/json"
	"errors"
	"sync"
	"time"
)

var ErrOriginalAccountLifetime = errors.New("ORIGINAL_ACCOUNT_LIFETIME_CLOSED_OR_EXPIRED")
var ErrOriginalAccountEffectUnknown = errors.New("ORIGINAL_ACCOUNT_EFFECT_UNKNOWN")

// A local participant in the ORIGINAL reservation, not a remote revocation
// lease or Native signing authority. No public constructor, authority callback,
// new attempt, nonce, deadline or persisted parallel transaction is introduced.
type originalAccountLifetime struct {
	mu                sync.Mutex
	original          context.Context
	local             context.Context
	stop              context.CancelFunc
	anchor, issued    time.Time
	deadline          time.Time // time.Now-derived monotonic, never replaced by Join/borrow
	cancelled, closed bool
	effect            *OriginalSocialAccountEffect
}

func newOriginalAccountLifetime(ctx context.Context, started, issued, expires time.Time) (*originalAccountLifetime, error) {
	if ctx == nil || ctx.Err() != nil || !expires.After(issued) || expires.Sub(issued) > 30*time.Second {
		return nil, ErrOriginalAccountLifetime
	}
	deadline := started.Add(expires.Sub(issued))
	if d, ok := ctx.Deadline(); ok && d.Before(deadline) {
		deadline = d
	}
	if !time.Now().Before(deadline) {
		return nil, ErrOriginalAccountLifetime
	}
	local, stop := context.WithDeadline(ctx, deadline)
	return &originalAccountLifetime{original: ctx, local: local, stop: stop, anchor: started, issued: issued, deadline: deadline}, nil
}
func (l *originalAccountLifetime) check(ctx context.Context, allowCancelled bool) error {
	if l == nil || ctx == nil || ctx.Err() != nil {
		return ErrOriginalAccountLifetime
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.original == nil || l.original.Err() != nil || l.closed || (!allowCancelled && l.cancelled) || !time.Now().Before(l.deadline) {
		return ErrOriginalAccountLifetime
	}
	return nil
}
func (l *originalAccountLifetime) borrow(ctx context.Context, allowCancelled bool) (context.Context, func(), error) {
	if e := l.check(ctx, allowCancelled); e != nil {
		return nil, nil, e
	}
	// Parent is the ORIGINAL acquisition context. The request adds cancellation;
	// it cannot replace that parent or extend its monotonic budget.
	l.mu.Lock()
	base, deadline := l.original, l.deadline
	if !allowCancelled {
		base = l.local
	}
	l.mu.Unlock()
	c, cancel := context.WithDeadline(base, deadline)
	stop := context.AfterFunc(ctx, cancel)
	done := func() { stop(); cancel() }
	if e := l.check(ctx, allowCancelled); e != nil {
		done()
		return nil, nil, e
	}
	return c, done, nil
}

// OriginalSocialAccountEffect is a singleton local participant shared by the
// capture/join lineage. Methods never create NativeSigningAuthorization.
type OriginalSocialAccountEffect struct {
	mu                                        sync.Mutex
	original                                  *OriginalSocialAccountCapture
	busy, invalid, entered, terminalAttempted bool
	terminal                                  *SocialOperationDecision
	localPrepared                             bool
}

// OpenOriginalEffect requires the actual joined retained holder. Reopening the
// same lineage returns the SAME participant, including UNKNOWN/once state.
func (o *OriginalSocialAccountCapture) OpenOriginalEffect(ctx context.Context) (*OriginalSocialAccountEffect, error) {
	if o == nil || o.owner == nil || o.lifetime == nil || o.frame.Phase != "joined" || o.frame.Association == nil {
		return nil, ErrSocialOperationUnknown
	}
	if e := o.currentEffect(ctx, false); e != nil {
		return nil, e
	}
	l := o.lifetime
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.closed || l.cancelled || l.original.Err() != nil || !time.Now().Before(l.deadline) {
		return nil, ErrOriginalAccountLifetime
	}
	if l.effect == nil {
		l.effect = &OriginalSocialAccountEffect{original: o}
	}
	if l.effect.original.owner != o.owner || l.effect.original.wire != o.wire || l.effect.original.proof != o.proof || *l.effect.original.frame.Association != *o.frame.Association {
		return nil, ErrSocialOperationUnknown
	}
	return l.effect, nil
}
func (o *OriginalSocialAccountCapture) currentEffect(ctx context.Context, allowCancelled bool) error {
	if o == nil || o.owner == nil || o.lifetime == nil {
		return ErrOriginalAccountLifetime
	}
	if e := o.lifetime.check(ctx, allowCancelled); e != nil {
		return e
	}
	var p struct {
		Issued string `json:"issuedAt"`
	}
	if json.Unmarshal([]byte(o.proof), &p) != nil {
		return ErrSocialOperationUnknown
	}
	at, e := time.Parse("2006-01-02T15:04:05.000Z", p.Issued)
	if e != nil {
		return ErrSocialOperationUnknown
	}
	c, done, e := o.lifetime.borrow(ctx, allowCancelled)
	if e != nil {
		return e
	}
	defer done()
	if e = o.owner.ownerCurrentWithin(c, at, time.UnixMilli(o.frame.ExpiresAtMS)); e != nil {
		return e
	}
	return o.lifetime.check(ctx, allowCancelled)
}
func (e *OriginalSocialAccountEffect) enter() error {
	if e == nil {
		return ErrSocialOperationUnknown
	}
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.busy {
		e.invalid = true
		return ErrOriginalAccountEffectUnknown
	}
	if e.invalid {
		return ErrOriginalAccountEffectUnknown
	}
	e.busy = true
	return nil
}
func (e *OriginalSocialAccountEffect) leave() { e.mu.Lock(); e.busy = false; e.mu.Unlock() }
func (e *OriginalSocialAccountEffect) valid() error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.invalid {
		return ErrOriginalAccountEffectUnknown
	}
	return nil
}

// CheckCurrent must surround the product's independent native source/sign/effect
// checks. It checks the actual protected operation/instance source and original
// ctx/window. It does not lock remote account revocation across an external effect.
func (e *OriginalSocialAccountEffect) CheckCurrent(ctx context.Context) error {
	if err := e.enter(); err != nil {
		return err
	}
	defer e.leave()
	if err := e.original.refreshOriginalJoined(ctx); err != nil {
		return err
	}
	if err := e.valid(); err != nil { return err }
	e.mu.Lock()
	if !e.entered && !e.terminalAttempted && e.terminal == nil { e.localPrepared = true }
	e.mu.Unlock()
	return nil
}

// EnterEffect consumes the local once slot BEFORE any possible native effect.
// An exception, cancellation, Close or late current failure never rearms it.
func (e *OriginalSocialAccountEffect) EnterEffect(ctx context.Context) error {
	if err := e.enter(); err != nil {
		return err
	}
	defer e.leave()
	if err := e.original.refreshOriginalJoined(ctx); err != nil {
		return err
	}
	return e.claimEffect(ctx)
}
func (e *OriginalSocialAccountEffect) claimEffect(ctx context.Context) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.invalid || e.entered || e.terminalAttempted || e.terminal != nil {
		return ErrOriginalAccountEffectUnknown
	}
	if err := e.original.lifetime.check(ctx, false); err != nil {
		return err
	}
	e.entered = true
	return nil
}

// Cancel is a local stop request, never a no-effect receipt. The original
// reservation and any entered/partial/uncertain effect remain UNKNOWN.
func (e *OriginalSocialAccountEffect) Cancel() error {
	if e == nil {
		return ErrSocialOperationUnknown
	}
	l := e.original.lifetime
	l.mu.Lock()
	defer l.mu.Unlock()
	l.cancelled = true
	l.stop()
	return nil
}

// Close only closes this lineage once; it never closes a shared provider,
// withdraws a reservation or erases evidence. It is allowed after expiry/cancel.
func (e *OriginalSocialAccountEffect) Close() error {
	if e == nil {
		return ErrSocialOperationUnknown
	}
	l := e.original.lifetime
	l.mu.Lock()
	defer l.mu.Unlock()
	l.closed = true
	l.stop()
	return nil
}

// Status is local lifecycle observation only. UNKNOWN is not no-effect.
func (e *OriginalSocialAccountEffect) Status() (entered, closed, cancelled, terminal bool) {
	if e == nil {
		return
	}
	e.mu.Lock()
	entered = e.entered
	terminal = e.terminal != nil
	e.mu.Unlock()
	l := e.original.lifetime
	l.mu.Lock()
	closed = l.closed
	cancelled = l.cancelled
	l.mu.Unlock()
	return
}

// Terminal body is the exact original request plus its existing protocol's
// publicReceipt. No account/challenge/prepared field may be replaced. Central
// authenticates the original terminal writer; a caller string cannot settle it.
func originalEffectTerminalBody(original, terminal string) error {
	var a, b map[string]json.RawMessage
	if decodeOriginalAccountJSON([]byte(original), &a) != nil || decodeOriginalAccountJSON([]byte(terminal), &b) != nil || len(b) != len(a)+1 {
		return ErrSocialOperationUnknown
	}
	r, ok := b["publicReceipt"]
	if !ok || len(r) == 0 || string(r) == "null" {
		return ErrSocialOperationUnknown
	}
	delete(b, "publicReceipt")
	x, err := json.Marshal(b)
	if err != nil || !sameOriginalAccountJSON([]byte(original), x) {
		return ErrSocialOperationUnknown
	}
	return nil
}

// SubmitOriginalTerminal invokes only the existing terminal/cancel protocol,
// never reserve. A failed/partial call is consumed and remains UNKNOWN. This
// uses that protocol's proof nonce; it never replaces the original reservation
// or READ nonce, body, ctx, capture or deadline. No background recovery is made.
func (e *OriginalSocialAccountEffect) SubmitOriginalTerminal(ctx context.Context, action, raw string) (SocialOperationDecision, error) {
	var out SocialOperationDecision
	if err := e.enter(); err != nil {
		return out, err
	}
	defer e.leave()
	if action != "terminal" && action != "cancel" {
		return out, ErrSocialOperationUnknown
	}
	if err := originalEffectTerminalBody(e.original.wire, raw); err != nil {
		return out, err
	}
	if err := e.original.currentEffect(ctx, true); err != nil {
		return out, err
	}
	c, done, err := e.original.lifetime.borrow(ctx, true)
	if err != nil {
		return out, err
	}
	defer done()
	e.mu.Lock()
	if e.invalid || e.terminalAttempted || e.terminal != nil {
		e.mu.Unlock()
		return out, ErrOriginalAccountEffectUnknown
	}
	e.terminalAttempted = true
	e.mu.Unlock()
	out, err = e.original.owner.CallBound(c, action, raw, *e.original.frame.Association)
	if err != nil {
		return SocialOperationDecision{}, err
	}
	if err = e.original.currentEffect(ctx, true); err != nil {
		return SocialOperationDecision{}, err
	}
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.invalid {
		return SocialOperationDecision{}, ErrOriginalAccountEffectUnknown
	}
	e.terminal = &out
	return out, nil
}

// refreshOriginalJoined reads the same reservation under its SAME retained READ
// proof. Central revalidates the real grant/family/session/account generation
// and original reservation; this is bounded observation, not a remote lock.
func (o *OriginalSocialAccountCapture) refreshOriginalJoined(ctx context.Context) error {
	if err := o.currentEffect(ctx, false); err != nil {
		return err
	}
	c, done, err := o.lifetime.borrow(ctx, false)
	if err != nil {
		return err
	}
	defer done()
	out, err := o.owner.call(c, "read", o.wire, "", true, o.proof)
	if err != nil {
		return err
	}
	f, _, _, err := originalAccountResponse(out, o.wire)
	if err != nil || !sameOriginalJoined(o.frame, f) || out.originalNativeSequence != o.nativeSequence || out.originalNativeRegistration != o.nativeRegistration {
		return ErrSocialOperationUnknown
	}
	return o.currentEffect(ctx, false)
}
func sameOriginalJoined(a, b originalSocialAccountFrame) bool {
	return a.Phase == "joined" && b.Phase == "joined" && a.Issuer == b.Issuer && a.Account == b.Account && a.ClientID == b.ClientID && a.Origin == b.Origin && a.SessionID == b.SessionID && a.FamilyID == b.FamilyID && a.Generation == b.Generation && a.Operation == b.Operation && a.Association != nil && b.Association != nil && *a.Association == *b.Association && a.ReservedAt != nil && b.ReservedAt != nil && *a.ReservedAt == *b.ReservedAt && sameOriginalAccountJSON(a.Challenge, b.Challenge) && sameOriginalAccountJSON(a.Prepared, b.Prepared) && b.ObservedAtMS >= a.ObservedAtMS && b.ExpiresAtMS <= a.ExpiresAtMS
}

// Capture-side cleanup is available even when no joined effect was opened.
// Neither operation erases reservation state or closes the shared key owner.
func (o *OriginalSocialAccountCapture) CancelOriginalAccount() error {
	if o == nil || o.lifetime == nil {
		return ErrOriginalAccountLifetime
	}
	l := o.lifetime
	l.mu.Lock()
	defer l.mu.Unlock()
	l.cancelled = true
	l.stop()
	return nil
}
func (o *OriginalSocialAccountCapture) CloseOriginalAccount() error {
	if o == nil || o.lifetime == nil {
		return ErrOriginalAccountLifetime
	}
	l := o.lifetime
	l.mu.Lock()
	defer l.mu.Unlock()
	l.closed = true
	l.stop()
	return nil
}

func (l *originalAccountLifetime) restrictExpiry(issued, expires time.Time) error {
	if l == nil {
		return ErrOriginalAccountLifetime
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	if !issued.Equal(l.issued) || !expires.After(issued) || expires.Sub(issued) > 30*time.Second {
		return ErrOriginalAccountLifetime
	}
	d := l.anchor.Add(expires.Sub(issued))
	if d.Before(l.deadline) {
		l.deadline = d
	}
	if l.closed || l.cancelled || l.original.Err() != nil || !time.Now().Before(l.deadline) {
		return ErrOriginalAccountLifetime
	}
	return nil
}

// ObserveOriginalTerminal performs a bounded READ with the ORIGINAL READ proof
// bytes/nonce. No signing, entropy, new reserve or alternative context is used.
// Cancelled-local participants may observe while the ORIGINAL ctx/deadline is
// still alive. Closed/expired lifetimes cannot be revived for recovery.
func (e *OriginalSocialAccountEffect) ObserveOriginalTerminal(ctx context.Context) (SocialOperationDecision, error) {
	var out SocialOperationDecision
	if err := e.enter(); err != nil {
		return out, err
	}
	defer e.leave()
	if err := e.original.currentEffect(ctx, true); err != nil {
		return out, err
	}
	c, done, err := e.original.lifetime.borrow(ctx, true)
	if err != nil {
		return out, err
	}
	defer done()
	out, err = e.original.owner.call(c, "read", e.original.wire, *e.original.frame.Association, false, e.original.proof)
	if err != nil {
		return SocialOperationDecision{}, err
	}
	if err = e.original.currentEffect(ctx, true); err != nil {
		return SocialOperationDecision{}, err
	}
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.invalid {
		return SocialOperationDecision{}, ErrOriginalAccountEffectUnknown
	}
	if out.Status != "unknown" {
		e.terminal = &out
	}
	return out, nil
}


// CheckHeldLocal makes no remote READ, signing call, clock callback or new
// reservation. The independently qualified Native owner remains mandatory.
func (e *OriginalSocialAccountEffect) CheckHeldLocal(ctx context.Context) error {
 if err := e.enter(); err != nil { return err }; defer e.leave()
 return e.checkHeldLocal(ctx)
}
func (e *OriginalSocialAccountEffect) checkHeldLocal(ctx context.Context) error {
 e.mu.Lock()
 ready := e.localPrepared && !e.invalid && !e.terminalAttempted && e.terminal == nil
 original := e.original
 e.mu.Unlock()
 if !ready || original == nil || original.owner == nil || original.owner.invalid.Load() || original.lifetime == nil { return ErrOriginalAccountEffectUnknown }
 l := original.lifetime
 if err := l.check(ctx, false); err != nil { return err }
 l.mu.Lock(); same := l.effect == e; l.mu.Unlock()
 if !same { return ErrOriginalAccountEffectUnknown }
 return e.valid()
}
// Consumes only the original local once slot after a genuine pre-fence READ.
// It cannot authorize Native entry or replace the platform's account fence.
func (e *OriginalSocialAccountEffect) EnterEffectHeldLocal(ctx context.Context) error {
 if err := e.enter(); err != nil { return err }; defer e.leave()
 if err := e.checkHeldLocal(ctx); err != nil { return err }
 return e.claimEffect(ctx)
}
