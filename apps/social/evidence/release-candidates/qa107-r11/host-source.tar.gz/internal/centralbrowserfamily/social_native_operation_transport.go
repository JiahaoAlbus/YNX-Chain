//go:build linux || darwin

package centralbrowserfamily

import (
	"context"
	"net/http"
	"time"
)

// Identity comparison by private startup; this does not admit a source.
func (t *SocialOperationTransport) NativeInstanceSource() *SocialNativeInstanceSource {
	if t == nil {
		return nil
	}
	return t.nativeSource
}

// Normal dedicated construction, not an upgrade of an already-running login
// transport. The exact typed operation and independently admitted instance
// sources remain held throughout sign/IO/body close/final release.
func NewSocialM1QANativeOperationTransport(ctx context.Context, owner *SocialM1QAOperationOwner, source *SocialNativeInstanceSource, client *http.Client, now func() time.Time) (*SocialOperationTransport, error) {
	if source == nil || owner == nil {
		return nil, ErrSocialNativeInstanceNotConfigured
	}
	b, e := source.Binding(ctx)
	if e != nil || (b.Status != "active" && b.Status != "withdrawing" && b.Status != "revoked") {
		return nil, ErrSocialNativeInstanceInvalid
	}
	owner.mu.Lock()
	digest := owner.config.ExpectedNodeConfigDigest
	owner.mu.Unlock()
	if b.OperationRegistrationDigest != digest {
		return nil, ErrSocialNativeInstanceInvalid
	}
	t, e := NewSocialM1QAProtectedOperationTransport(ctx, owner, client, now)
	if e != nil {
		return nil, e
	}
	t.nativeSource = source
	if e = t.ownerCurrent(ctx); e != nil {
		return nil, e
	}
	if e = source.Current(ctx); e != nil {
		return nil, e
	}
	return t, nil
}

// Sequence/registration are only original persisted phase custody. This does
// not turn the account reference or a returned Go value into Native authority.
func (a *OriginalSocialAccountCapture) OriginalNativePhase(ctx context.Context) (int64, string, error) {
	if a == nil || a.owner == nil || a.owner.nativeSource == nil || a.nativeSequence < 1 {
		return 0, "", ErrSocialNativeInstanceNotConfigured
	}
	raw, e := a.PrivateAuthenticatedDeliveryBytes(ctx)
	clear(raw)
	if e != nil {
		return 0, "", e
	}
	b, e := a.owner.nativeSource.Binding(ctx)
	if e != nil || b.RegistrationDigest != a.nativeRegistration {
		return 0, "", ErrSocialNativeInstanceInvalid
	}
	return a.nativeSequence, a.nativeRegistration, nil
}
