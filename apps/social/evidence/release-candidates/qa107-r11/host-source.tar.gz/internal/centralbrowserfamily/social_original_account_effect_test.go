package centralbrowserfamily

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"testing"
	"time"
)

// These are in-process PUBLIC lifecycle controls. Synthetic internal captures
// are NOT a production constructor, admitted holder, signature or Native grant.
func effectFixture(t *testing.T) (*OriginalSocialAccountCapture, context.CancelFunc) {
	t.Helper()
	ctx, cancel := context.WithCancel(context.Background())
	now := time.Now()
	l, err := newOriginalAccountLifetime(ctx, now, now, now.Add(2*time.Second))
	if err != nil {
		t.Fatal(err)
	}
	assoc := strings.Repeat("b", 64)
	proof, _ := json.Marshal(map[string]string{"issuedAt": now.UTC().Format("2006-01-02T15:04:05.000Z")})
	return &OriginalSocialAccountCapture{owner: &SocialOperationTransport{clientID: "ynx-social-v1-sso-v1"}, lifetime: l, wire: `{"intentId":"original","clientId":"fixed"}`, proof: string(proof), frame: originalSocialAccountFrame{Phase: "joined", Association: &assoc, ExpiresAtMS: now.Add(2 * time.Second).UnixMilli()}}, cancel
}
func TestOriginalEffectSingletonOnceUnknown(t *testing.T) {
	o, cancel := effectFixture(t)
	defer cancel()
	e, err := o.OpenOriginalEffect(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	again, err := o.OpenOriginalEffect(context.Background())
	if err != nil || again != e {
		t.Fatal("new participant")
	}
	if err = e.claimEffect(context.Background()); err != nil {
		t.Fatal(err)
	}
	if e.claimEffect(context.Background()) == nil {
		t.Fatal("reentered effect")
	}
	entered, _, _, terminal := e.Status()
	if !entered || terminal {
		t.Fatal("UNKNOWN lost")
	}
}
func TestOriginalEffectOriginalCancellationCannotDetach(t *testing.T) {
	o, cancel := effectFixture(t)
	e, err := o.OpenOriginalEffect(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	cancel()
	if e.CheckCurrent(context.Background()) == nil || e.claimEffect(context.Background()) == nil {
		t.Fatal("detached original ctx")
	}
	if _, err = o.PrivateAuthenticatedDeliveryBytes(context.Background()); err == nil {
		t.Fatal("getter detached")
	}
}
func TestOriginalEffectCancelCloseDoNotClaimNoEffect(t *testing.T) {
	o, cancel := effectFixture(t)
	defer cancel()
	e, _ := o.OpenOriginalEffect(context.Background())
	if err := e.claimEffect(context.Background()); err != nil {
		t.Fatal(err)
	}
	if e.Cancel() != nil || e.Close() != nil || e.Close() != nil {
		t.Fatal("cleanup")
	}
	entered, closed, cancelled, terminal := e.Status()
	if !entered || !closed || !cancelled || terminal {
		t.Fatal("invented terminal")
	}
	if _, err := o.OpenOriginalEffect(context.Background()); err == nil {
		t.Fatal("reopened closed lineage")
	}
}
func TestOriginalEffectDeadlineNeverReset(t *testing.T) {
	o, cancel := effectFixture(t)
	defer cancel()
	l := o.lifetime
	original := l.deadline
	c, done, err := l.borrow(context.Background(), false)
	if err != nil {
		t.Fatal(err)
	}
	d, _ := c.Deadline()
	done()
	if !d.Equal(original) || !l.deadline.Equal(original) {
		t.Fatal("renewed")
	}
	l.mu.Lock()
	l.deadline = time.Now().Add(-time.Nanosecond)
	l.mu.Unlock()
	if _, err = o.PrivateAuthenticatedDeliveryBytes(context.Background()); err == nil {
		t.Fatal("expired getter")
	}
	if _, err = o.OpenOriginalEffect(context.Background()); err == nil {
		t.Fatal("expired participant")
	}
}
func TestOriginalEffectReentrySticky(t *testing.T) {
	o, cancel := effectFixture(t)
	defer cancel()
	e, _ := o.OpenOriginalEffect(context.Background())
	if e.enter() != nil {
		t.Fatal("entry")
	}
	if e.enter() == nil {
		t.Fatal("nested")
	}
	e.leave()
	if e.CheckCurrent(context.Background()) == nil {
		t.Fatal("swallowed nested")
	}
	if e.Close() != nil {
		t.Fatal("invalid cleanup")
	}
}
func TestOriginalEffectTerminalExactOriginalBinding(t *testing.T) {
	original := `{"intentId":"same","clientId":"fixed","challenge":{"nonce":"old"}}`
	for _, raw := range []string{`{"intentId":"same","clientId":"fixed","challenge":{"nonce":"old"},"publicReceipt":{"opaque":"original"}}`} {
		if originalEffectTerminalBody(original, raw) != nil {
			t.Fatal("original receipt shape")
		}
	}
	for _, raw := range []string{`{"intentId":"new","clientId":"fixed","challenge":{"nonce":"old"},"publicReceipt":{}}`, `{"intentId":"same","clientId":"fixed","challenge":{"nonce":"new"},"publicReceipt":{}}`, `{"intentId":"same","clientId":"fixed","challenge":{"nonce":"old"},"publicReceipt":null}`, `{"intentId":"same","intentId":"same","clientId":"fixed","challenge":{"nonce":"old"},"publicReceipt":{}}`} {
		if originalEffectTerminalBody(original, raw) == nil {
			t.Fatal("accepted replacement/duplicate/null")
		}
	}
}
func TestOriginalEffectNoCapturedParticipant(t *testing.T) {
	o, cancel := effectFixture(t)
	defer cancel()
	o.frame.Phase = "captured"
	if _, err := o.OpenOriginalEffect(context.Background()); err == nil {
		t.Fatal("no reserve")
	}
}
func TestOriginalEffectLifetimeRejectsExtendedRead(t *testing.T) {
	now := time.Now()
	if _, err := newOriginalAccountLifetime(context.Background(), now, now, now.Add(120*time.Second)); err == nil {
		t.Fatal("challenge extended READ")
	}
	if _, err := newOriginalAccountLifetime(context.Background(), now.Add(-time.Minute), now, now.Add(time.Second)); err == nil {
		t.Fatal("reset elapsed budget")
	}
}

func TestOriginalEffectCancelledBorrowSignalAndCleanup(t *testing.T) {
	o, cancel := effectFixture(t)
	defer cancel()
	c, done, err := o.lifetime.borrow(context.Background(), false)
	if err != nil {
		t.Fatal(err)
	}
	defer done()
	if o.CancelOriginalAccount() != nil {
		t.Fatal("cancel")
	}
	select {
	case <-c.Done():
	default:
		t.Fatal("borrow not cancelled")
	}
	if o.CloseOriginalAccount() != nil || o.CloseOriginalAccount() != nil {
		t.Fatal("cleanup")
	}
}
func TestOriginalEffectJoinedCurrentRejectsAccountRefresh(t *testing.T) {
	a := originalSocialAccountFrame{Phase: "joined", Issuer: "issuer", Account: "original", ClientID: "fixed", Origin: "origin", SessionID: "session", FamilyID: "family", Generation: 1, Operation: "op", Challenge: json.RawMessage(`{"x":1}`), Prepared: json.RawMessage(`{"y":1}`), ObservedAtMS: 1, ExpiresAtMS: 30}
	assoc := strings.Repeat("a", 64)
	reserved := int64(1)
	a.Association = &assoc
	a.ReservedAt = &reserved
	b := a
	b.ObservedAtMS = 2
	b.ExpiresAtMS = 29
	if !sameOriginalJoined(a, b) {
		t.Fatal("matching observation")
	}
	for _, change := range []func(*originalSocialAccountFrame){func(f *originalSocialAccountFrame) { f.Generation++ }, func(f *originalSocialAccountFrame) { f.Account = "other" }, func(f *originalSocialAccountFrame) { f.FamilyID = "other" }, func(f *originalSocialAccountFrame) { f.SessionID = "other" }, func(f *originalSocialAccountFrame) { f.ExpiresAtMS = 31 }, func(f *originalSocialAccountFrame) { f.Challenge = json.RawMessage(`{"x":2}`) }, func(f *originalSocialAccountFrame) { f.Prepared = json.RawMessage(`{"y":2}`) }} {
		c := b
		change(&c)
		if sameOriginalJoined(a, c) {
			t.Fatal("accepted changed current")
		}
	}
}

func TestOriginalEffectJoinOnlyShortensMonotonicWindow(t *testing.T) {
	o, cancel := effectFixture(t)
	defer cancel()
	l := o.lifetime
	old := l.deadline
	if err := l.restrictExpiry(l.issued, l.issued.Add(time.Second)); err != nil {
		t.Fatal(err)
	}
	short := l.deadline
	if !short.Before(old) {
		t.Fatal("join did not shorten")
	}
	if err := l.restrictExpiry(l.issued, l.issued.Add(2*time.Second)); err != nil || !l.deadline.Equal(short) {
		t.Fatal("renewed shorter joined window")
	}
}

type originalEffectWireControl func(*http.Request) (*http.Response, error)

func (f originalEffectWireControl) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
func originalEffectObserverControl(t *testing.T, mime, status string) (*OriginalSocialAccountEffect, context.CancelFunc, *int) {
	o, cancel := effectFixture(t)
	now := time.Now().UTC().Truncate(time.Millisecond)
	end := now.Add(time.Second)
	wire, _ := json.Marshal(map[string]any{"clientId": "ynx-social-v1-sso-v1", "grantToken": strings.Repeat("A", 43), "intentId": "original", "challenge": map[string]any{"operation": "original"}, "preparedPublicCommitment": map[string]any{"original": true}})
	sum := sha256.Sum256(wire)
	proof, _ := json.Marshal(map[string]any{"version": 1, "purpose": "social-original-operation/v1", "issuer": "https://wallet-auth.ynxweb4.com", "audience": "https://wallet-auth.ynxweb4.com" + socialOperationPrefix, "clientId": "ynx-social-v1-sso-v1", "keyId": "original-key", "action": "read", "method": "POST", "path": socialOperationPrefix + "read", "bodySha256": hex.EncodeToString(sum[:]), "issuedAt": now.Format("2006-01-02T15:04:05.000Z"), "expiresAt": end.Format("2006-01-02T15:04:05.000Z"), "nonce": strings.Repeat("A", 43), "signature": "synthetic-not-admission"})
	o.wire = string(wire)
	o.proof = string(proof)
	o.frame.ExpiresAtMS = end.UnixMilli()
	o.owner.keyID = "original-key"
	o.owner.now = func() time.Time { return now }
	calls := 0
	o.owner.http = socialOperationHTTPClient(&http.Client{Transport: originalEffectWireControl(func(r *http.Request) (*http.Response, error) {
		calls++
		body, _ := io.ReadAll(r.Body)
		if !bytes.Equal(body, wire) || r.Header.Get("X-YNX-Social-Operation-Proof") != base64.RawURLEncoding.EncodeToString(proof) || r.URL.Path != socialOperationPrefix+"read" {
			t.Fatal("replaced original READ")
		}
		responseValue := map[string]any{"version": "ynx-social-account-operation-result/v1", "intentId": "original", "commitment": *o.frame.Association, "status": status, "pending": status == "unknown", "readOnly": true, "dispatchAllowed": false, "blocked": false, "terminal": nil}
		if status == "committed" {
			responseValue["terminal"] = map[string]any{"action": "terminal", "outcome": "committed", "receiptDigest": strings.Repeat("c", 64), "observedAtMs": now.UnixMilli()}
		}
		response, _ := json.Marshal(responseValue)
		header := make(http.Header)
		if mime != "" {
			header.Set("Content-Type", mime)
		}
		return &http.Response{StatusCode: 200, Header: header, Body: io.NopCloser(bytes.NewReader(response))}, nil
	})})
	return &OriginalSocialAccountEffect{original: o}, cancel, &calls
}
func TestOriginalEffectReadUsesSameProofWithoutSigner(t *testing.T) {
	e, cancel, calls := originalEffectObserverControl(t, "application/json; charset=utf-8", "unknown")
	defer cancel()
	if err := e.Cancel(); err != nil {
		t.Fatal(err)
	}
	out, err := e.ObserveOriginalTerminal(context.Background())
	if err != nil || out.Status != "unknown" || *calls != 1 {
		t.Fatalf("read %v calls%d", err, *calls)
	}
	_, _, _, terminal := e.Status()
	if terminal {
		t.Fatal("UNKNOWN settled")
	}
	// key is nil: any attempt to create/sign another proof would fail this control.
}

func TestOriginalEffectSettledObservationRequiresExactMIME(t *testing.T) {
	for _, tc := range []struct {
		name, mime string
		want       bool
	}{{"correct", "application/json; charset=utf-8", true}, {"missing", "", false}, {"wrong", "text/plain", false}, {"inexact", "application/json", false}} {
		t.Run(tc.name, func(t *testing.T) {
			e, cancel, calls := originalEffectObserverControl(t, tc.mime, "committed")
			defer cancel()
			out, err := e.ObserveOriginalTerminal(context.Background())
			if (err == nil) != tc.want || *calls != 1 {
				t.Fatalf("accepted%v want%v calls%d", err == nil, tc.want, *calls)
			}
			_, _, _, terminal := e.Status()
			if terminal != tc.want {
				t.Fatal("invalid MIME changed retained terminal")
			}
			if tc.want && (out.Status != "committed" || out.Terminal == nil || out.Terminal.Action != "terminal" || out.Terminal.Outcome != "committed" || !out.ReadOnly) {
				t.Fatal("settled terminal lost")
			}
		})
	}
}

// Full transport rejection, using an explicitly synthetic in-process signer
// and HTTP control, not a real M1 holder, authority approval or device grant.
func TestOriginalEffectUnknownSubmissionNeverSettlesOrRearms(t *testing.T) {
	for _, action := range []string{"terminal", "cancel"} {
		t.Run(action, func(t *testing.T) {
			e, cancel, calls := originalEffectObserverControl(t, "application/json; charset=utf-8", "unknown")
			defer cancel()
			defer e.Close()
			_, key, err := ed25519.GenerateKey(rand.Reader)
			if err != nil {
				t.Fatal(err)
			}
			e.original.owner.key = key
			if err = e.claimEffect(context.Background()); err != nil {
				t.Fatal(err)
			}
			var request map[string]json.RawMessage
			if err = json.Unmarshal([]byte(e.original.wire), &request); err != nil {
				t.Fatal(err)
			}
			request["publicReceipt"] = json.RawMessage(`{"testOnly":"not-authority"}`)
			raw, err := json.Marshal(request)
			if err != nil {
				t.Fatal(err)
			}
			originalRead := e.original.owner.http.Transport
			e.original.owner.http.Transport = originalEffectWireControl(func(r *http.Request) (*http.Response, error) {
				*calls++
				body, readErr := io.ReadAll(r.Body)
				if readErr != nil || !bytes.Equal(body, raw) || r.URL.Path != socialOperationPrefix+action {
					t.Fatal("replaced terminal submission")
				}
				response, marshalErr := json.Marshal(map[string]any{
					"version": "ynx-social-account-operation-result/v1", "intentId": "original",
					"commitment": *e.original.frame.Association, "status": "unknown", "terminal": nil,
					"pending": true, "readOnly": true, "dispatchAllowed": false, "blocked": false,
				})
				if marshalErr != nil {
					t.Fatal(marshalErr)
				}
				return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"application/json; charset=utf-8"}}, Body: io.NopCloser(bytes.NewReader(response))}, nil
			})
			if _, err = e.SubmitOriginalTerminal(context.Background(), action, string(raw)); err == nil {
				t.Fatal("UNKNOWN submission accepted as terminal")
			}
			entered, _, _, terminal := e.Status()
			if !entered || terminal || !e.terminalAttempted || *calls != 1 {
				t.Fatal("UNKNOWN or consumed attempt lost")
			}
			if _, err = e.SubmitOriginalTerminal(context.Background(), action, string(raw)); err == nil || *calls != 1 {
				t.Fatal("uncertain submission retried")
			}
			e.original.owner.http.Transport = originalRead
			out, err := e.ObserveOriginalTerminal(context.Background())
			if err != nil || out.Status != "unknown" || *calls != 2 {
				t.Fatal("same-proof observation failed", err)
			}
			_, _, _, terminal = e.Status()
			if terminal || !e.terminalAttempted {
				t.Fatal("observation settled or rearmed UNKNOWN")
			}
		})
	}
}


// PUBLIC mechanical local singleton controls, NOT real account/Native proof.
func TestOriginalEffectNativeLocalRequiresPreflight(t *testing.T){
 o,cancel:=effectFixture(t);defer cancel();e,err:=o.OpenOriginalEffect(context.Background());if err!=nil{t.Fatal(err)}
 if e.CheckHeldLocal(context.Background())==nil||e.EnterEffectHeldLocal(context.Background())==nil{t.Fatal("missing preflight accepted")}
 entered,_,_,_:=e.Status();if entered{t.Fatal("refusal consumed original")}
}
func TestOriginalEffectNativeLocalOnceAndCancellation(t *testing.T){
 o,cancel:=effectFixture(t);defer cancel();e,err:=o.OpenOriginalEffect(context.Background());if err!=nil{t.Fatal(err)}
 e.localPrepared=true // explicitly synthetic local preflight, never Native authority
 if err=e.CheckHeldLocal(context.Background());err!=nil{t.Fatal(err)}
 if err=e.EnterEffectHeldLocal(context.Background());err!=nil{t.Fatal(err)}
 if e.EnterEffectHeldLocal(context.Background())==nil{t.Fatal("once rearmed")}
 cancel();if e.CheckHeldLocal(context.Background())==nil{t.Fatal("detached original")}
 entered,_,_,terminal:=e.Status();if !entered||terminal{t.Fatal("UNKNOWN lost")}
}
func TestOriginalEffectNativeLocalNoTransportAndExpiry(t *testing.T){
 o,cancel:=effectFixture(t);defer cancel();e,err:=o.OpenOriginalEffect(context.Background());if err!=nil{t.Fatal(err)}
 e.localPrepared=true;o.owner.http=http.Client{Transport:originalEffectWireControl(func(*http.Request)(*http.Response,error){t.Fatal("local method attempted network");return nil,context.Canceled})}
 if err=e.CheckHeldLocal(context.Background());err!=nil{t.Fatal(err)}
 deadline:=o.lifetime.deadline;o.lifetime.deadline=time.Now().Add(-time.Second)
 if e.EnterEffectHeldLocal(context.Background())==nil{t.Fatal("expired local original accepted")}
 if o.lifetime.deadline.Equal(deadline){t.Fatal("fixture not applied")}
 if err=e.Close();err!=nil{t.Fatal(err)}
 if e.CheckHeldLocal(context.Background())==nil{t.Fatal("closed local original accepted")}
}
