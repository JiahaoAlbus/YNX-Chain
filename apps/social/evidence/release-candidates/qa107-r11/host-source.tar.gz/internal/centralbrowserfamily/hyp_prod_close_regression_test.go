package centralbrowserfamily
import("context";"encoding/base64";"errors";"io";"net/http";"strings";"testing";"time")
type hypCloseBody struct{io.Reader;calls int; failure error}
func(b *hypCloseBody)Close()error{b.calls++;return b.failure}
func TestHypProdCloseRegression(t *testing.T){
 for _,failed:=range []bool{false,true}{t.Run(map[bool]string{false:"success",true:"failure"}[failed],func(t *testing.T){
  b:=&hypCloseBody{Reader:strings.NewReader(preparedM1Response)};if failed{b.failure=errors.New("PUBLIC close failure")}
  requests:=0
  h:=&http.Client{Transport:wireRT(func(*http.Request)(*http.Response,error){requests++;hdr:=http.Header{};hdr.Set("X-YNX-Social-Account-Eligibility-V1",base64.RawURLEncoding.EncodeToString([]byte(`{"fixture":"public"}`)));return &http.Response{StatusCode:200,Header:hdr,Body:b},nil})}
  c,e:=NewSocialOperationTransport("PUBLIC-prod",wireSigner{},h,func()time.Time{return time.UnixMilli(1)});if e!=nil{t.Fatal(e)}
  out,e:=c.Call(context.Background(),"reserve",firstBody)
  if requests!=1||b.calls!=1{t.Fatal("physical request/close repeated")}
  if failed{if !errors.Is(e,ErrSocialOperationUnknown)||out.DispatchAllowed{t.Fatal("close failure released decision")}}else if e!=nil||!out.DispatchAllowed{t.Fatal("prod success semantics changed",e)}
 })}
}
