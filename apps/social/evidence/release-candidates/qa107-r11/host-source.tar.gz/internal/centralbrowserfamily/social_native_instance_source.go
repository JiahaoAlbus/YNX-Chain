//go:build linux || darwin

package centralbrowserfamily

// Normal host source selection, not an HTTP/ENV profile or root bootstrap.
// No key is opened here. The independently admitted startup owns the selection.
import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"sync"
	"time"
)

const SocialNativeRegistrationPurpose = "social-native-account-instance-registration/v1"
const SocialNativeStatusPurpose = "social-native-account-delegation-status/v1"
const SocialNativeCurrentPurpose = "social-native-account-current/v1"
const socialNativeRegistrationDomain = "YNX_SOCIAL_NATIVE_ACCOUNT_INSTANCE_REGISTRATION_V1\n"
const socialNativeStatusDomain = "YNX_SOCIAL_NATIVE_ACCOUNT_DELEGATION_STATUS_V1\n"
const socialNativeCurrentDomain = "YNX_SOCIAL_NATIVE_ACCOUNT_CURRENT_V1\n"

var ErrSocialNativeInstanceNotConfigured = errors.New("SOCIAL_NATIVE_INSTANCE_NOT_CONFIGURED")
var ErrSocialNativeInstanceInvalid = errors.New("SOCIAL_NATIVE_INSTANCE_INVALID")

// SocialNativeStatusHistoryFile selects an independently admitted original
// predecessor record. Its path/hash/size do not themselves grant authority.
type SocialNativeStatusHistoryFile struct {
	Path, Digest string
	Bytes        int64
}

type SocialNativeInstanceSourceConfig struct {
	// StatusHistory excludes the separately supplied current StatusPath. Genesis
	// has an empty prefix; later records require the complete sequence from one.
	StatusHistory                                                                             []SocialNativeStatusHistoryFile
	RootPath, RootDigest, RegistrationPath, RegistrationDigest, StatusPath, StatusDigest      string
	RootBytes, RegistrationBytes, StatusBytes                                                 int64
	ExpectedProfileDigest, ExpectedCentralRegistryDigest, ExpectedOperationRegistrationDigest string
	ExpectedServiceBinaryDigest, ExpectedTLSSPKIDigest                                        string
	ExpectedCertificateDigest, ExpectedCallbackManifestDigest                                 string
	MinimumRegistrationRevision, MinimumStatusSequence                                        int64
	Now                                                                                       func() time.Time
}

type SocialNativeInstanceBinding struct {
	InstanceID, KeyID, RegistrationDigest, RegistrationRaw, StatusRaw, Status string
	ProfileDigest, OperationRegistrationDigest, TLSSPKIDigest                 string
	SequenceFloor, IssuedAtMS, ExpiresAtMS                                    int64
	Public                                                                    ed25519.PublicKey
}
type SocialNativeInstanceSource struct {
	statusHistoryRaw           []string
	mu                         sync.Mutex
	active, invalid, closed    bool
	config                     SocialNativeInstanceSourceConfig
	files                      []*socialM1QAHeldFile
	registration, status       map[string]any
	registrationRaw, statusRaw string
	rootRaw                    string
	public                     ed25519.PublicKey
	last                       int64
}

func nativeSourceDigest(raw []byte) string { h := sha256.Sum256(raw); return hex.EncodeToString(h[:]) }
func nativeSignedBody(raw []byte, fields []string, domain string, root ed25519.PublicKey) (map[string]any, error) {
	e, err := m1parse(raw)
	if err != nil || !m1exact(e, "body", "signature") {
		return nil, ErrSocialNativeInstanceInvalid
	}
	b, ok := e["body"].(map[string]any)
	if !ok || !m1exact(b, fields...) {
		return nil, ErrSocialNativeInstanceInvalid
	}
	sig, err := m1b64(m1str(e, "signature"), 64)
	if err != nil {
		return nil, ErrSocialNativeInstanceInvalid
	}
	c, err := m1canonical(b)
	if err != nil || !ed25519.Verify(root, append([]byte(domain), c...), sig) {
		return nil, ErrSocialNativeInstanceInvalid
	}
	return b, nil
}

// This verifies the SAME 26/14 wire domains as the original Node supplier. A
// public root file is only usable when its digest/provenance was independently
// selected by the real startup owner; this constructor does not select one.
func OpenSocialNativeInstanceSource(c SocialNativeInstanceSourceConfig) (*SocialNativeInstanceSource, error) {
	// Freeze selectors before opening any held file; a caller cannot retarget
	// the retained source by changing its configuration slice later.
	c.StatusHistory = append([]SocialNativeStatusHistoryFile(nil), c.StatusHistory...)
	if err := nativeStatusHistorySelectors(c); err != nil {
		return nil, err
	}
	if c.Now == nil || c.MinimumRegistrationRevision < 1 || c.MinimumStatusSequence < 1 {
		return nil, ErrSocialNativeInstanceNotConfigured
	}
	for _, d := range []string{c.RootDigest, c.RegistrationDigest, c.StatusDigest, c.ExpectedProfileDigest, c.ExpectedCentralRegistryDigest, c.ExpectedOperationRegistrationDigest, c.ExpectedServiceBinaryDigest, c.ExpectedTLSSPKIDigest, c.ExpectedCertificateDigest, c.ExpectedCallbackManifestDigest} {
		if !m1hash(d) {
			return nil, ErrSocialNativeInstanceInvalid
		}
	}
	if c.RootPath == c.RegistrationPath || c.RootPath == c.StatusPath || c.RegistrationPath == c.StatusPath {
		return nil, ErrSocialNativeInstanceInvalid
	}
	o := &SocialNativeInstanceSource{config: c, last: -1}
	good := false
	defer func() {
		if !good {
			_ = o.Close()
		}
	}()
	raws := make([][]byte, 0, 3)
	for _, s := range []struct {
		path, digest string
		size         int64
	}{{c.RootPath, c.RootDigest, c.RootBytes}, {c.RegistrationPath, c.RegistrationDigest, c.RegistrationBytes}, {c.StatusPath, c.StatusDigest, c.StatusBytes}} {
		h, raw, e := m1hold(s.path, s.digest, s.size)
		if e != nil {
			return nil, e
		}
		o.files = append(o.files, h...)
		raws = append(raws, raw)
	}
	r, err := m1parse(raws[0])
	if err != nil || !m1exact(r, "version", "rootId", "keyId", "publicKey", "purposes") || m1int(r, "version") != 1 || !m1token(m1str(r, "rootId")) || !m1token(m1str(r, "keyId")) {
		return nil, ErrSocialNativeInstanceInvalid
	}
	purposes, ok := r["purposes"].([]any)
	if !ok || len(purposes) != 2 || purposes[0] != SocialNativeRegistrationPurpose || purposes[1] != SocialNativeStatusPurpose {
		return nil, ErrSocialNativeInstanceInvalid
	}
	root, err := m1OperationPublic(m1str(r, "publicKey"))
	if err != nil {
		return nil, err
	}
	rf := []string{"version", "purpose", "environment", "registrationId", "registrationRevision", "rootId", "rootKeyId", "instanceId", "instanceKeyId", "instancePublicKey", "serviceOrigin", "apiMount", "packageId", "certificateDigest", "callbackManifestDigest", "clientId", "profileRegistrationId", "profileRevision", "profileDigest", "centralRegistryDigest", "operationRegistrationDigest", "serviceBinaryDigest", "tlsSpkiDigest", "actions", "issuedAtMs", "expiresAtMs"}
	b, err := nativeSignedBody(raws[1], rf, socialNativeRegistrationDomain, root)
	if err != nil {
		return nil, err
	}
	for k, want := range map[string]string{"purpose": SocialNativeRegistrationPurpose, "environment": "testnet-qa", "rootId": m1str(r, "rootId"), "rootKeyId": m1str(r, "keyId"), "serviceOrigin": "https://social.ynxweb4.com", "apiMount": "/m1qa", "packageId": "com.ynx.social.m1qa", "clientId": m1OperationClient, "profileDigest": c.ExpectedProfileDigest, "centralRegistryDigest": c.ExpectedCentralRegistryDigest, "operationRegistrationDigest": c.ExpectedOperationRegistrationDigest, "serviceBinaryDigest": c.ExpectedServiceBinaryDigest, "tlsSpkiDigest": c.ExpectedTLSSPKIDigest, "certificateDigest": c.ExpectedCertificateDigest, "callbackManifestDigest": c.ExpectedCallbackManifestDigest} {
		if m1str(b, k) != want {
			return nil, ErrSocialNativeInstanceInvalid
		}
	}
	for _, k := range []string{"registrationId", "instanceId", "instanceKeyId", "profileRegistrationId"} {
		if !m1token(m1str(b, k)) {
			return nil, ErrSocialNativeInstanceInvalid
		}
	}
	a, ok := b["actions"].([]any)
	if !ok || len(a) != 4 || a[0] != "capture" || a[1] != "join" || a[2] != "observe" || a[3] != "retire" {
		return nil, ErrSocialNativeInstanceInvalid
	}
	issued, end := m1int(b, "issuedAtMs"), m1int(b, "expiresAtMs")
	if m1int(b, "version") != 1 || m1int(b, "profileRevision") < 1 || m1int(b, "registrationRevision") < c.MinimumRegistrationRevision || issued < 0 || end <= issued || end-issued > 86400000 {
		return nil, ErrSocialNativeInstanceInvalid
	}
	public, err := m1b64(m1str(b, "instancePublicKey"), 32)
	if err != nil {
		return nil, err
	}
	sf := []string{"version", "purpose", "rootId", "rootKeyId", "instanceId", "registrationId", "registrationRevision", "registrationDigest", "statusSequence", "status", "previousStatusDigest", "effectiveAtMs", "issuedAtMs", "expiresAtMs"}
	s, err := nativeSignedBody(raws[2], sf, socialNativeStatusDomain, root)
	if err != nil {
		return nil, err
	}
	for _, k := range []string{"rootId", "rootKeyId", "instanceId", "registrationId"} {
		if m1str(s, k) != m1str(b, k) {
			return nil, ErrSocialNativeInstanceInvalid
		}
	}
	ss, se, eff := m1int(s, "issuedAtMs"), m1int(s, "expiresAtMs"), m1int(s, "effectiveAtMs")
	status := m1str(s, "status")
	prev := s["previousStatusDigest"]
	if m1int(s, "version") != 1 || m1str(s, "purpose") != SocialNativeStatusPurpose || m1str(s, "registrationDigest") != c.RegistrationDigest || m1int(s, "registrationRevision") != m1int(b, "registrationRevision") || m1int(s, "statusSequence") < c.MinimumStatusSequence || ss < 0 || se <= ss || se-ss > 30000 || eff < ss || eff >= se || (status != "active" && status != "withdrawing" && status != "revoked") || (prev != nil && !m1hash(m1str(s, "previousStatusDigest"))) || (m1int(s, "statusSequence") == 1 && prev != nil) {
		return nil, ErrSocialNativeInstanceInvalid
	}
	o.rootRaw = string(raws[0])
	o.registration = b
	o.status = s
	o.registrationRaw = string(raws[1])
	o.statusRaw = string(raws[2])
	o.public = bytes.Clone(public)
	if err := o.loadOriginalStatusHistory(); err != nil {
		return nil, err
	}
	if _, err = o.Binding(context.Background()); err != nil {
		return nil, err
	}
	good = true
	return o, nil
}

func (o *SocialNativeInstanceSource) enter() error {
	if o == nil {
		return ErrSocialNativeInstanceNotConfigured
	}
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.active {
		o.invalid = true
		return ErrSocialNativeInstanceInvalid
	}
	if o.invalid || o.closed {
		return ErrSocialNativeInstanceInvalid
	}
	o.active = true
	return nil
}
func (o *SocialNativeInstanceSource) leave() { o.mu.Lock(); o.active = false; o.mu.Unlock() }
func (o *SocialNativeInstanceSource) fail() error {
	o.mu.Lock()
	o.invalid = true
	o.mu.Unlock()
	return ErrSocialNativeInstanceInvalid
}
func (o *SocialNativeInstanceSource) current(ctx context.Context) (int64, error) {
	if ctx == nil {
		return 0, o.fail()
	}
	if e := ctx.Err(); e != nil {
		return 0, e
	}
	for _, h := range o.files {
		if m1check(h) != nil {
			return 0, o.fail()
		}
	}
	at := o.config.Now().UnixMilli()
	o.mu.Lock()
	bad := o.invalid || o.closed || at < 0 || at > 9007199254740991 || at < o.last || at < m1int(o.registration, "issuedAtMs") || at >= m1int(o.registration, "expiresAtMs") || at < m1int(o.status, "effectiveAtMs") || at >= m1int(o.status, "expiresAtMs")
	if bad {
		o.invalid = true
	} else {
		o.last = at
	}
	o.mu.Unlock()
	if bad {
		return 0, ErrSocialNativeInstanceInvalid
	}
	for _, h := range o.files {
		if m1check(h) != nil {
			return 0, o.fail()
		}
	}
	if e := ctx.Err(); e != nil {
		return 0, e
	}
	o.mu.Lock()
	bad = o.invalid || o.closed
	o.mu.Unlock()
	if bad {
		return 0, ErrSocialNativeInstanceInvalid
	}
	return at, nil
}

// The companion operation clock must be followed by this no-callback file and
// captured-time fence. Do not add another Now which could reopen a last-check gap.
func (o *SocialNativeInstanceSource) heldAfterClock(ctx context.Context, at int64) error {
	if e := o.enter(); e != nil {
		return e
	}
	defer o.leave()
	if ctx == nil || ctx.Err() != nil {
		return o.fail()
	}
	for _, h := range o.files {
		if m1check(h) != nil {
			return o.fail()
		}
	}
	o.mu.Lock()
	bad := o.invalid || o.closed || at < o.last || at < m1int(o.registration, "issuedAtMs") || at >= m1int(o.registration, "expiresAtMs") || at < m1int(o.status, "effectiveAtMs") || at >= m1int(o.status, "expiresAtMs")
	o.mu.Unlock()
	if bad {
		return o.fail()
	}
	return nil
}
func (o *SocialNativeInstanceSource) Current(ctx context.Context) error {
	if e := o.enter(); e != nil {
		return e
	}
	defer o.leave()
	_, e := o.current(ctx)
	return e
}
func (o *SocialNativeInstanceSource) Binding(ctx context.Context) (SocialNativeInstanceBinding, error) {
	if e := o.enter(); e != nil {
		return SocialNativeInstanceBinding{}, e
	}
	defer o.leave()
	if _, e := o.current(ctx); e != nil {
		return SocialNativeInstanceBinding{}, e
	}
	r, s := o.registration, o.status
	end := m1int(r, "expiresAtMs")
	if v := m1int(s, "expiresAtMs"); v < end {
		end = v
	}
	return SocialNativeInstanceBinding{InstanceID: m1str(r, "instanceId"), KeyID: m1str(r, "instanceKeyId"), RegistrationDigest: o.config.RegistrationDigest, RegistrationRaw: o.registrationRaw, StatusRaw: o.statusRaw, Status: m1str(s, "status"), ProfileDigest: m1str(r, "profileDigest"), OperationRegistrationDigest: m1str(r, "operationRegistrationDigest"), TLSSPKIDigest: m1str(r, "tlsSpkiDigest"), SequenceFloor: m1int(s, "statusSequence"), IssuedAtMS: m1int(s, "effectiveAtMs"), ExpiresAtMS: end, Public: bytes.Clone(o.public)}, nil
}

// Cleanup is independent of expiry/invalid, and never restores authority.
func (o *SocialNativeInstanceSource) Close() error {
	if o == nil {
		return nil
	}
	o.mu.Lock()
	if o.active {
		o.invalid = true
		o.mu.Unlock()
		return ErrSocialNativeInstanceInvalid
	}
	if o.closed {
		o.mu.Unlock()
		return nil
	}
	o.closed = true
	o.invalid = true
	fs := o.files
	o.files = nil
	o.mu.Unlock()
	var err error
	for _, h := range fs {
		err = errors.Join(err, h.file.Close())
	}
	return err
}

// Copies exact already-held public enrollment bytes, never re-marshals a
// signed body. The current loader supplies no older status chain: refuse a
// later sequence rather than silently treating it as genesis or full history.
func (o *SocialNativeInstanceSource) OriginalDelegationRaw(ctx context.Context) (delegation, history [][]byte, err error) {
	if err := o.enter(); err != nil {
		return nil, nil, err
	}
	defer o.leave()
	if _, err := o.current(ctx); err != nil {
		return nil, nil, err
	}
	if o.rootRaw == "" || o.registrationRaw == "" || o.statusRaw == "" {
		return nil, nil, ErrSocialNativeInstanceNotConfigured
	}
	history = make([][]byte, len(o.statusHistoryRaw))
	for i, raw := range o.statusHistoryRaw {
		history[i] = []byte(raw)
	}
	return [][]byte{[]byte(o.rootRaw), []byte(o.registrationRaw), []byte(o.statusRaw)}, history, nil
}

const nativeStatusHistoryByteLimit = 393216

func nativeStatusHistorySelectors(c SocialNativeInstanceSourceConfig) error {
	if len(c.StatusHistory) > 255 {
		return ErrSocialNativeInstanceInvalid
	}
	selections := []SocialNativeStatusHistoryFile{
		{c.RootPath, c.RootDigest, c.RootBytes},
		{c.RegistrationPath, c.RegistrationDigest, c.RegistrationBytes},
		{c.StatusPath, c.StatusDigest, c.StatusBytes},
	}
	selections = append(selections, c.StatusHistory...)
	paths := make(map[string]bool, len(selections))
	var total int64
	for _, selection := range selections {
		if selection.Path == "" || paths[selection.Path] || !m1hash(selection.Digest) || selection.Bytes < 1 || selection.Bytes > 16384 || selection.Bytes > nativeStatusHistoryByteLimit-total {
			return ErrSocialNativeInstanceInvalid
		}
		paths[selection.Path] = true
		total += selection.Bytes
	}
	return nil
}

func nativeOriginalStatusBody(raw []byte, registration map[string]any, digest string, root ed25519.PublicKey) (map[string]any, error) {
	fields := []string{"version", "purpose", "rootId", "rootKeyId", "instanceId", "registrationId", "registrationRevision", "registrationDigest", "statusSequence", "status", "previousStatusDigest", "effectiveAtMs", "issuedAtMs", "expiresAtMs"}
	body, err := nativeSignedBody(raw, fields, socialNativeStatusDomain, root)
	if err != nil {
		return nil, err
	}
	for _, field := range []string{"rootId", "rootKeyId", "instanceId", "registrationId"} {
		if m1str(body, field) != m1str(registration, field) {
			return nil, ErrSocialNativeInstanceInvalid
		}
	}
	issued, expires, effective := m1int(body, "issuedAtMs"), m1int(body, "expiresAtMs"), m1int(body, "effectiveAtMs")
	sequence, state := m1int(body, "statusSequence"), m1str(body, "status")
	previous := body["previousStatusDigest"]
	if m1int(body, "version") != 1 || m1str(body, "purpose") != SocialNativeStatusPurpose || m1str(body, "registrationDigest") != digest || m1int(body, "registrationRevision") != m1int(registration, "registrationRevision") || sequence < 1 || issued < 0 || expires <= issued || expires-issued > 30000 || effective < issued || effective >= expires || (state != "active" && state != "withdrawing" && state != "revoked") || (previous != nil && !m1hash(m1str(body, "previousStatusDigest"))) || (sequence == 1 && previous != nil) || (sequence > 1 && previous == nil) {
		return nil, ErrSocialNativeInstanceInvalid
	}
	return body, nil
}

func (o *SocialNativeInstanceSource) loadOriginalStatusHistory() error {
	rootRecord, err := m1parse([]byte(o.rootRaw))
	if err != nil {
		return err
	}
	root, err := m1OperationPublic(m1str(rootRecord, "publicKey"))
	if err != nil {
		return err
	}
	if int64(len(o.config.StatusHistory))+1 != m1int(o.status, "statusSequence") {
		return errors.New("SOCIAL_NATIVE_FULL_ORIGINAL_STATUS_HISTORY_REQUIRED")
	}
	for _, selection := range o.config.StatusHistory {
		held, raw, err := m1hold(selection.Path, selection.Digest, selection.Bytes)
		if err != nil {
			return err
		}
		o.files = append(o.files, held...)
		o.statusHistoryRaw = append(o.statusHistoryRaw, string(raw))
	}
	// History is signed evidence, not a freshness oracle. Its old validity
	// windows may have elapsed. Only current() enforces the current clock,
	// configured floor and registration/status deadlines, without renewing the
	// original login request. A durable latest-head oracle remains separate.
	var prior map[string]any
	var priorRaw string
	for i := 0; i <= len(o.statusHistoryRaw); i++ {
		raw := o.statusRaw
		if i < len(o.statusHistoryRaw) {
			raw = o.statusHistoryRaw[i]
		}
		body, err := nativeOriginalStatusBody([]byte(raw), o.registration, o.config.RegistrationDigest, root)
		if err != nil {
			return err
		}
		if m1int(body, "statusSequence") != int64(i)+1 {
			return ErrSocialNativeInstanceInvalid
		}
		state := m1str(body, "status")
		if i == 0 {
			if body["previousStatusDigest"] != nil || state != "active" {
				return ErrSocialNativeInstanceInvalid
			}
		} else if m1str(body, "previousStatusDigest") != nativeSourceDigest([]byte(priorRaw)) || (m1str(prior, "status") == "withdrawing" && state == "active") || (m1str(prior, "status") == "revoked" && state != "revoked") {
			return ErrSocialNativeInstanceInvalid
		}
		prior, priorRaw = body, raw
	}
	return nil
}
