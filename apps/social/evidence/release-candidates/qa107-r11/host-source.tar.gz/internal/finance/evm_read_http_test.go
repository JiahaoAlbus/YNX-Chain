package finance

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func evmReadFixture(t *testing.T, node, script string, input any) json.RawMessage {
	t.Helper()
	encoded, err := json.Marshal(input)
	if err != nil {
		t.Fatal(err)
	}
	command := exec.Command(node, script)
	command.Stdin = bytes.NewReader(encoded)
	output, err := command.Output()
	if err != nil || !json.Valid(output) {
		t.Fatalf("Wallet/Auth test signer failed: %v", err)
	}
	return json.RawMessage(output)
}

func evmReadGET(t *testing.T, url string, proof json.RawMessage, origin string) (*http.Response, map[string]any) {
	t.Helper()
	request, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		t.Fatal(err)
	}
	request.Header.Set("Origin", origin)
	request.Header.Set(evmReadProofHeader, base64.RawURLEncoding.EncodeToString(proof))
	response, err := http.DefaultClient.Do(request)
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	var body map[string]any
	if err := json.NewDecoder(io.LimitReader(response.Body, 128<<10)).Decode(&body); err != nil {
		t.Fatal(err)
	}
	return response, body
}

func TestEVMReadHTTPRealWalletProofDurableOwnershipAndRevoke(t *testing.T) {
	node, err := exec.LookPath("node")
	if err != nil {
		t.Skip("Node runtime is unavailable")
	}
	script, err := filepath.Abs(filepath.Join("..", "..", "apps", "finance", "scripts", "evm-read-session-authority.bundle.mjs"))
	if err != nil {
		t.Fatal(err)
	}
	fixture, err := filepath.Abs(filepath.Join("..", "..", "apps", "finance", "tests", "fixtures", "evm-read-sign.mjs"))
	if err != nil {
		t.Fatal(err)
	}
	dependencies := filepath.Join("..", "..", "packages", "wallet-auth", "node_modules", "@noble", "curves")
	if _, err := os.Stat(dependencies); err != nil {
		t.Skip("install Wallet/Auth npm dependencies to run the real HTTP proof fixture")
	}
	authority, err := NewNodeEVMReadAuthority(node, script, 5*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	clock := time.Now().UTC().Truncate(time.Millisecond)
	storePath := filepath.Join(t.TempDir(), "finance.json")
	store, err := OpenStore(storePath)
	if err != nil {
		t.Fatal(err)
	}
	var expectedAccount string
	explorer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.URL.Path == "/health":
			_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "nativeSymbol": "YNXT", "truthfulStatus": "indexed-with-reported-lag", "lastCheckedAt": clock})
		case r.URL.Path == "/api/accounts/"+expectedAccount:
			_ = json.NewEncoder(w).Encode(map[string]any{"account": map[string]any{"address": expectedAccount, "balance": 123, "staked": 4}})
		case r.URL.Path == "/api/txs":
			_ = json.NewEncoder(w).Encode(map[string]any{"transactions": []any{}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer explorer.Close()
	upstreams, err := NewUpstreams(explorer.URL, "", "", "https://support.example/dispute")
	if err != nil {
		t.Fatal(err)
	}
	service := &Service{Store: store, Upstreams: upstreams, AI: fakeAI{}, Support: SupportLinks{HelpURL: "https://support.example/help", PrivacyURL: "https://support.example/privacy", DisputeURL: "https://support.example/dispute"}}
	auth, _ := testAuthenticator(t, "evm-read-native-isolation")
	server, err := NewServer(service, auth, ServerConfig{AllowedOrigins: []string{BrowserFinanceOrigin}, CursorSigningKey: testCursorKey, OperationsKey: testOperationsKey, EVMReadAuthority: authority, Now: func() time.Time { return clock }})
	if err != nil {
		t.Fatal(err)
	}
	ts := httptest.NewServer(server.Handler())
	defer ts.Close()
	var identity struct {
		Account   string `json:"account"`
		DeviceID  string `json:"deviceId"`
		DeviceKey string `json:"deviceKey"`
	}
	if err := json.Unmarshal(evmReadFixture(t, node, fixture, map[string]any{"action": "identity"}), &identity); err != nil {
		t.Fatal(err)
	}
	expectedAccount = identity.Account
	challengeURL := ts.URL + "/api/evm-read/challenges"
	if response, _ := postEVMLogin(t, challengeURL, map[string]any{"account": identity.Account, "providerKind": "metamask", "deviceId": identity.DeviceID, "deviceKey": identity.DeviceKey}, ""); response.StatusCode != http.StatusForbidden {
		t.Fatal("originless EVM read challenge was accepted")
	}
	response, issued := postEVMLogin(t, challengeURL, map[string]any{"account": identity.Account, "providerKind": "metamask", "deviceId": identity.DeviceID, "deviceKey": identity.DeviceKey}, BrowserFinanceOrigin)
	if response.StatusCode != http.StatusCreated || issued["privateFinanceAuthorized"] != false {
		t.Fatalf("EVM read challenge failed: status=%d body=%#v", response.StatusCode, issued)
	}
	challenge := issued["challenge"]
	challengeFields := challenge.(map[string]any)
	challengeIssuedAt, issuedErr := time.Parse(time.RFC3339Nano, challengeFields["issuedAt"].(string))
	challengeExpiresAt, expiresErr := time.Parse(time.RFC3339Nano, challengeFields["expiresAt"].(string))
	if issuedErr != nil || expiresErr != nil || challengeExpiresAt.Sub(challengeIssuedAt) > 5*time.Minute || !challengeExpiresAt.After(challengeIssuedAt) {
		t.Fatal("Finance challenge exceeded its five-minute authority boundary")
	}
	proof := evmReadFixture(t, node, fixture, map[string]any{"action": "login", "challenge": challenge})
	response, sessionResult := postEVMLogin(t, ts.URL+"/api/evm-read/sessions", map[string]any{"proof": proof}, BrowserFinanceOrigin)
	if response.StatusCode != http.StatusCreated || sessionResult["privateFinanceAuthorized"] != false || sessionResult["evmAccountReadAuthorized"] != true || sessionResult["extensionLiveStateAttested"] != false {
		t.Fatalf("EVM session issue failed: status=%d body=%#v", response.StatusCode, sessionResult)
	}
	session := sessionResult["session"]
	sessionFields := session.(map[string]any)
	sessionIssuedAt, issuedErr := time.Parse(time.RFC3339Nano, sessionFields["issuedAt"].(string))
	sessionExpiresAt, expiresErr := time.Parse(time.RFC3339Nano, sessionFields["expiresAt"].(string))
	if issuedErr != nil || expiresErr != nil || sessionExpiresAt.Sub(sessionIssuedAt) > 5*time.Minute || !sessionExpiresAt.After(sessionIssuedAt) {
		t.Fatal("Finance session exceeded its five-minute last-verification boundary")
	}
	reopened, err := OpenStore(storePath)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := reopened.EVMReadSession(session.(map[string]any)["sessionId"].(string)); err != nil {
		t.Fatalf("EVM session not durable across stores: %v", err)
	}
	if response, _ := postEVMLogin(t, ts.URL+"/api/evm-read/sessions", map[string]any{"proof": proof}, BrowserFinanceOrigin); response.StatusCode == http.StatusCreated {
		t.Fatal("login proof replay issued a second session")
	}
	clock = clock.Add(2 * time.Second)
	target := evmReadPortfolioPath + "?view=balances"
	readInput := map[string]any{"method": "GET", "target": target, "bodyDigest": evmReadEmptyBodyDigest, "nonce": "finance_read_nonce_0123456789abcdef", "issuedAt": evmReadTime(clock), "expiresAt": evmReadTime(clock.Add(30 * time.Second))}
	readProof := evmReadFixture(t, node, fixture, map[string]any{"action": "read", "session": session, "request": readInput})
	// The exact EVM device proof authorizes only the read endpoint. It must not
	// be accepted as a native Product Session or order-approval authority.
	for _, privateTarget := range []struct {
		method string
		path   string
		body   string
	}{
		{method: http.MethodGet, path: "/api/broker/orders"},
		{method: http.MethodPost, path: "/api/broker/challenges", body: `{}`},
	} {
		privateRequest, err := http.NewRequest(privateTarget.method, ts.URL+privateTarget.path, strings.NewReader(privateTarget.body))
		if err != nil {
			t.Fatal(err)
		}
		privateRequest.Header.Set("Origin", BrowserFinanceOrigin)
		privateRequest.Header.Set(evmReadProofHeader, base64.RawURLEncoding.EncodeToString(readProof))
		privateResponse, err := http.DefaultClient.Do(privateRequest)
		if err != nil {
			t.Fatal(err)
		}
		_ = privateResponse.Body.Close()
		if privateResponse.StatusCode != http.StatusUnauthorized {
			t.Fatalf("EVM read proof crossed private order boundary: %s %s returned %d", privateTarget.method, privateTarget.path, privateResponse.StatusCode)
		}
	}
	response, portfolio := evmReadGET(t, ts.URL+target, readProof, BrowserFinanceOrigin)
	if response.StatusCode != http.StatusOK || portfolio["account"] != identity.Account || portfolio["privateFinanceAuthorized"] != false || portfolio["evmAccountReadAuthorized"] != true {
		t.Fatalf("EVM account-bound read failed: status=%d body=%#v", response.StatusCode, portfolio)
	}
	owned := portfolio["portfolio"].(map[string]any)
	if owned["balanceYnxt"] != float64(123) || owned["account"] != identity.Account {
		t.Fatalf("Explorer-backed account ownership was lost: %#v", owned)
	}
	// A second real QA key has an independent server-issued account session.
	// Neither its Wallet signature nor its device key can read the first owner.
	var otherIdentity struct {
		Account   string `json:"account"`
		DeviceID  string `json:"deviceId"`
		DeviceKey string `json:"deviceKey"`
	}
	if err := json.Unmarshal(evmReadFixture(t, node, fixture, map[string]any{"action": "identity", "testUser": 1}), &otherIdentity); err != nil || otherIdentity.Account == identity.Account {
		t.Fatal("QA identities must be distinct")
	}
	secondResponse, secondChallenge := postEVMLogin(t, challengeURL, map[string]any{"account": otherIdentity.Account, "providerKind": "metamask", "deviceId": otherIdentity.DeviceID, "deviceKey": otherIdentity.DeviceKey}, BrowserFinanceOrigin)
	if secondResponse.StatusCode != http.StatusCreated {
		t.Fatal("second owner challenge failed")
	}
	secondProof := evmReadFixture(t, node, fixture, map[string]any{"action": "login", "testUser": 1, "challenge": secondChallenge["challenge"]})
	secondResponse, secondResult := postEVMLogin(t, ts.URL+"/api/evm-read/sessions", map[string]any{"proof": secondProof}, BrowserFinanceOrigin)
	if secondResponse.StatusCode != http.StatusCreated {
		t.Fatal("second owner session failed")
	}
	secondSession := secondResult["session"]
	secondRequest := map[string]any{"method": "GET", "target": target, "bodyDigest": evmReadEmptyBodyDigest, "nonce": "second_owner_read_nonce_0123456789abcdef", "issuedAt": evmReadTime(clock), "expiresAt": evmReadTime(clock.Add(30 * time.Second))}
	secondRead := evmReadFixture(t, node, fixture, map[string]any{"action": "read", "testUser": 1, "session": secondSession, "request": secondRequest})
	secondResponse, secondPortfolio := evmReadGET(t, ts.URL+target, secondRead, BrowserFinanceOrigin)
	if secondResponse.StatusCode != http.StatusOK || secondPortfolio["account"] != otherIdentity.Account || secondPortfolio["portfolio"].(map[string]any)["account"] != otherIdentity.Account {
		t.Fatal("second owner read lost its account isolation")
	}
	var wrongOwner map[string]any
	if err := json.Unmarshal(secondRead, &wrongOwner); err != nil {
		t.Fatal(err)
	}
	wrongOwner["account"] = identity.Account
	wrongOwner["sessionId"] = sessionFields["sessionId"]
	wrongOwner["challengeDigest"] = sessionFields["challengeDigest"]
	wrongDeviceProof, _ := json.Marshal(wrongOwner)
	if response, _ := evmReadGET(t, ts.URL+target, wrongDeviceProof, BrowserFinanceOrigin); response.StatusCode != http.StatusUnauthorized {
		t.Fatal("second owner's device was allowed to read the first owner")
	}
	browserGETInput := map[string]any{"method": "GET", "target": target, "bodyDigest": evmReadEmptyBodyDigest, "nonce": "finance_browser_get_nonce_0123456789abcdef", "issuedAt": evmReadTime(clock), "expiresAt": evmReadTime(clock.Add(30 * time.Second))}
	browserGETProof := evmReadFixture(t, node, fixture, map[string]any{"action": "read", "session": session, "request": browserGETInput})
	browserGET, err := http.NewRequest(http.MethodGet, ts.URL+target, nil)
	if err != nil {
		t.Fatal(err)
	}
	browserGET.Host = "finance.ynxweb4.com"
	browserGET.Header.Set("Sec-Fetch-Site", "same-origin")
	browserGET.Header.Set("Sec-Fetch-Mode", "cors")
	browserGET.Header.Set("Sec-Fetch-Dest", "empty")
	browserGET.Header.Set(evmReadProofHeader, base64.RawURLEncoding.EncodeToString(browserGETProof))
	browserResponse, err := http.DefaultClient.Do(browserGET)
	if err != nil {
		t.Fatal(err)
	}
	_ = browserResponse.Body.Close()
	if browserResponse.StatusCode != http.StatusOK {
		t.Fatalf("same-origin Chromium GET without Origin was rejected: %d", browserResponse.StatusCode)
	}
	missingMetadata, _ := http.NewRequest(http.MethodGet, ts.URL+target, nil)
	missingMetadata.Host = "finance.ynxweb4.com"
	missingMetadata.Header.Set(evmReadProofHeader, base64.RawURLEncoding.EncodeToString(browserGETProof))
	missingResponse, err := http.DefaultClient.Do(missingMetadata)
	if err != nil {
		t.Fatal(err)
	}
	_ = missingResponse.Body.Close()
	if missingResponse.StatusCode != http.StatusForbidden {
		t.Fatalf("originless GET without browser metadata was accepted: %d", missingResponse.StatusCode)
	}
	for _, mismatch := range []struct {
		host string
		site string
	}{{"attacker.example", "same-origin"}, {"finance.ynxweb4.com", "cross-site"}} {
		request, _ := http.NewRequest(http.MethodGet, ts.URL+target, nil)
		request.Host = mismatch.host
		request.Header.Set("Sec-Fetch-Site", mismatch.site)
		request.Header.Set("Sec-Fetch-Mode", "cors")
		request.Header.Set("Sec-Fetch-Dest", "empty")
		request.Header.Set(evmReadProofHeader, base64.RawURLEncoding.EncodeToString(browserGETProof))
		denied, err := http.DefaultClient.Do(request)
		if err != nil {
			t.Fatal(err)
		}
		_ = denied.Body.Close()
		if denied.StatusCode != http.StatusForbidden {
			t.Fatalf("originless GET with host/site mismatch was accepted: host=%s site=%s status=%d", mismatch.host, mismatch.site, denied.StatusCode)
		}
	}
	if response, _ := evmReadGET(t, ts.URL+target, readProof, BrowserFinanceOrigin); response.StatusCode == http.StatusOK {
		t.Fatal("HTTP proof replay read private EVM account data")
	}
	changed := map[string]any{"method": "GET", "target": target, "bodyDigest": evmReadEmptyBodyDigest, "nonce": "finance_changed_nonce_0123456789abcdef", "issuedAt": evmReadTime(clock), "expiresAt": evmReadTime(clock.Add(30 * time.Second))}
	changedProof := evmReadFixture(t, node, fixture, map[string]any{"action": "read", "session": session, "request": changed})
	if response, _ := evmReadGET(t, ts.URL+evmReadPortfolioPath+"?view=orders", changedProof, BrowserFinanceOrigin); response.StatusCode == http.StatusOK {
		t.Fatal("changed raw query was accepted")
	}
	if response, _ := evmReadGET(t, ts.URL+target, changedProof, "https://other.ynxweb4.com"); response.StatusCode == http.StatusOK {
		t.Fatal("cross-origin read was accepted")
	}
	native, err := http.Get(ts.URL + "/api/overview")
	if err != nil {
		t.Fatal(err)
	}
	_ = native.Body.Close()
	if native.StatusCode == http.StatusOK {
		t.Fatal("EVM read session widened native v2 overview authority")
	}
	clock = clock.Add(time.Second)
	revokeInput := map[string]any{"bodyDigest": evmReadEmptyBodyDigest, "nonce": "finance_revoke_nonce_0123456789abcdef", "issuedAt": evmReadTime(clock), "expiresAt": evmReadTime(clock.Add(30 * time.Second))}
	revokeProof := evmReadFixture(t, node, fixture, map[string]any{"action": "revoke", "session": session, "request": revokeInput})
	revokeRequest, _ := http.NewRequest(http.MethodPost, ts.URL+evmReadRevokePath, nil)
	revokeRequest.Header.Set("Origin", BrowserFinanceOrigin)
	revokeRequest.Header.Set(evmReadProofHeader, base64.RawURLEncoding.EncodeToString(revokeProof))
	revoked, err := http.DefaultClient.Do(revokeRequest)
	if err != nil {
		t.Fatal(err)
	}
	_ = revoked.Body.Close()
	if revoked.StatusCode != http.StatusOK {
		t.Fatalf("authenticated EVM revoke failed: %d", revoked.StatusCode)
	}
	if response, _ := evmReadGET(t, ts.URL+target, changedProof, BrowserFinanceOrigin); response.StatusCode == http.StatusOK {
		t.Fatal("revoked session read account data")
	}
	if revokedAgain, err := http.DefaultClient.Do(revokeRequest); err == nil {
		_ = revokedAgain.Body.Close()
		if revokedAgain.StatusCode == http.StatusOK {
			t.Fatal("replayed revoke was accepted")
		}
	}
	if !strings.HasPrefix(session.(map[string]any)["account"].(string), "0x") {
		t.Fatal("session account is not a canonical EVM account")
	}
}
