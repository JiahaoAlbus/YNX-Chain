package faucet

import (
	"bytes"
	"context"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/JiahaoAlbus/YNX-Chain/internal/accountaddress"
	"github.com/JiahaoAlbus/YNX-Chain/internal/buildinfo"
	"github.com/JiahaoAlbus/YNX-Chain/internal/chain"
	"github.com/JiahaoAlbus/YNX-Chain/internal/consensus"
	"github.com/decred/dcrd/dcrec/secp256k1/v4"
)

const (
	UpstreamAuthoritative = "authoritative"
	UpstreamBFT           = "bft"
	MaxResponseBytes      = 1 << 20
)

var (
	ynxAddressPattern = regexp.MustCompile(`^ynx_[a-zA-Z0-9_]{3,80}$`)
	evmAddressPattern = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)
)

type Config struct {
	CoreAuthTokenPath string
	RPCURL            string
	HTTPAddr          string
	UpstreamMode      string
	FaucetKey         string
	FaucetKeyPath     string
	FaucetAddress     string
	ChainID           int64
	DefaultAmount     int64
	MaxAmount         int64
	Window            time.Duration
	MaxRequests       int
	IPMaxRequests     int
	IPWindow          time.Duration
	RequestLog        string
	AdmissionPath     string
	MaxAdmissions     int
	HealthTimeout     time.Duration
}

func (c Config) normalized() (Config, error) {
	if strings.TrimSpace(c.RPCURL) == "" {
		return Config{}, fmt.Errorf("faucet RPC URL is required")
	}
	c.UpstreamMode = strings.ToLower(strings.TrimSpace(c.UpstreamMode))
	if c.UpstreamMode == "" {
		c.UpstreamMode = UpstreamAuthoritative
	}
	if c.UpstreamMode != UpstreamAuthoritative && c.UpstreamMode != UpstreamBFT {
		return Config{}, fmt.Errorf("faucet upstream mode must be %q or %q", UpstreamAuthoritative, UpstreamBFT)
	}
	if strings.TrimSpace(c.FaucetKey) == "" && strings.TrimSpace(c.FaucetKeyPath) == "" && !(c.UpstreamMode == UpstreamAuthoritative && c.CoreAuthTokenPath != "") {
		return Config{}, fmt.Errorf("FAUCET_PRIVATE_KEY or YNX_FAUCET_PRIVATE_KEY_FILE is required for ynx-faucetd")
	}
	if c.UpstreamMode == UpstreamBFT {
		if strings.TrimSpace(c.FaucetKey) != "" && strings.TrimSpace(c.FaucetKeyPath) != "" {
			return Config{}, fmt.Errorf("BFT faucet requires exactly one private key source")
		}
		if !consensus.IsNativeAddress(strings.TrimSpace(c.FaucetAddress)) {
			return Config{}, fmt.Errorf("BFT faucet requires canonical YNX_FAUCET_ADDRESS")
		}
		if c.ChainID == 0 {
			c.ChainID = 6423
		}
		if c.ChainID != 6423 {
			return Config{}, fmt.Errorf("BFT faucet chain ID must equal 6423")
		}
	}
	if c.DefaultAmount <= 0 {
		c.DefaultAmount = 100
	}
	if c.MaxAmount <= 0 {
		c.MaxAmount = c.DefaultAmount
	}
	if c.DefaultAmount > c.MaxAmount {
		return Config{}, fmt.Errorf("default faucet amount cannot exceed max amount")
	}
	if c.Window <= 0 {
		c.Window = time.Hour
	}
	if c.MaxRequests <= 0 {
		c.MaxRequests = 1
	}
	if c.IPMaxRequests <= 0 {
		c.IPMaxRequests = 100
	}
	if c.IPWindow <= 0 {
		c.IPWindow = time.Minute
	}
	if c.RequestLog == "" {
		c.RequestLog = "tmp/faucet/requests.jsonl"
	}
	if c.ChainID == 0 {
		c.ChainID = 6423
	}
	if c.ChainID < 0 {
		return Config{}, fmt.Errorf("faucet chain ID must be positive")
	}
	if c.AdmissionPath == "" {
		c.AdmissionPath = c.RequestLog + ".admissions.db"
	}
	if c.MaxAdmissions <= 0 {
		c.MaxAdmissions = 100000
	}
	if c.HealthTimeout == 0 {
		c.HealthTimeout = 2 * time.Second
	}
	if c.HealthTimeout < 0 || c.HealthTimeout > 5*time.Second {
		return Config{}, fmt.Errorf("faucet health timeout must be positive and at most 5s")
	}
	return c, nil
}

type Service struct {
	coreAuthToken        string
	admissions           *admissionStore
	cfg                  Config
	httpClient           *http.Client
	healthClient         *http.Client
	signer               *secp256k1.PrivateKey
	signerAddr           string
	mu                   sync.Mutex
	fundMu               sync.Mutex
	logMu                sync.Mutex
	seen                 map[string][]time.Time
	requests             int64
	successes            int64
	denied               int64
	requestOutcomes      map[string]uint64
	admissionErrors      map[string]uint64
	lastHash             string
	lastError            string
	healthMu             sync.Mutex
	healthFlight         *healthFlight
	healthStats          healthProbeStats
	flightMu             sync.Mutex
	fundingFlights       map[string]*fundingFlight
	statusFlights        map[string]*statusFlight
	capabilityFlight     *capabilityFlight
	capabilityValidUntil time.Time
	flightStats          flightStats
}

func New(cfg Config) (*Service, error) {
	normalized, err := cfg.normalized()
	if err != nil {
		return nil, err
	}
	service := &Service{
		cfg:          normalized,
		httpClient:   newUpstreamHTTPClient(10*time.Second, 10*time.Second),
		healthClient: newUpstreamHTTPClient(0, normalized.HealthTimeout),
		seen:         map[string][]time.Time{}, requestOutcomes: map[string]uint64{}, admissionErrors: map[string]uint64{},
		fundingFlights: map[string]*fundingFlight{}, statusFlights: map[string]*statusFlight{},
	}
	if normalized.UpstreamMode == UpstreamBFT {
		signer, address, err := loadBFTSigner(normalized)
		if err != nil {
			return nil, err
		}
		service.signer = signer
		service.signerAddr = address
		service.cfg.FaucetKey = ""
	}
	if normalized.UpstreamMode == UpstreamAuthoritative {
		service.coreAuthToken, err = loadCoreAuthToken(normalized.CoreAuthTokenPath)
		if err != nil {
			return nil, err
		}
		store, err := openAdmissionStore(normalized)
		if err != nil {
			return nil, fmt.Errorf("open durable faucet admission: %w", err)
		}
		service.admissions = store
	}
	return service, nil
}

func loadBFTSigner(cfg Config) (*secp256k1.PrivateKey, string, error) {
	var keyBytes []byte
	if path := strings.TrimSpace(cfg.FaucetKeyPath); path != "" {
		info, err := os.Stat(path)
		if err != nil {
			return nil, "", fmt.Errorf("stat BFT faucet private key: %w", err)
		}
		if !info.Mode().IsRegular() || info.Mode().Perm()&0o077 != 0 {
			return nil, "", fmt.Errorf("BFT faucet private key file must be regular and mode-restricted")
		}
		keyBytes, err = os.ReadFile(path)
		if err != nil {
			return nil, "", fmt.Errorf("read BFT faucet private key: %w", err)
		}
	} else {
		raw := strings.TrimPrefix(strings.TrimSpace(cfg.FaucetKey), "0x")
		var err error
		keyBytes, err = hex.DecodeString(raw)
		if err != nil {
			return nil, "", fmt.Errorf("BFT faucet private key must be canonical hex")
		}
	}
	defer clear(keyBytes)
	if len(keyBytes) != 32 || bytes.Equal(keyBytes, make([]byte, 32)) {
		return nil, "", fmt.Errorf("BFT faucet private key must be one non-zero 32-byte scalar")
	}
	privateKey := secp256k1.PrivKeyFromBytes(keyBytes)
	if !bytes.Equal(privateKey.Serialize(), keyBytes) {
		return nil, "", fmt.Errorf("BFT faucet private key scalar is outside the canonical range")
	}
	address, err := consensus.NativeAddress(privateKey.PubKey().SerializeCompressed())
	if err != nil {
		return nil, "", err
	}
	if address != strings.TrimSpace(cfg.FaucetAddress) {
		return nil, "", fmt.Errorf("BFT faucet configured address does not match private key")
	}
	return privateKey, address, nil
}

type Request struct {
	RequestID string `json:"requestId,omitempty"`
	Address   string `json:"address"`
	Amount    int64  `json:"amount,omitempty"`
}

type Response struct {
	Transaction      chain.Transaction `json:"transaction"`
	Address          string            `json:"address"`
	Amount           int64             `json:"amount"`
	NativeSymbol     string            `json:"nativeSymbol"`
	RequestID        string            `json:"requestId"`
	TruthfulStatus   string            `json:"truthfulStatus"`
	TransactionHash  string            `json:"transactionHash,omitempty"`
	Status           string            `json:"status,omitempty"`
	RetrySameRequest bool              `json:"retrySameRequest,omitempty"`
	Replayed         bool              `json:"replayed,omitempty"`
}

type LogEntry struct {
	RequestID string    `json:"requestId"`
	At        time.Time `json:"at"`
	IP        string    `json:"ip"`
	Address   string    `json:"address"`
	Amount    int64     `json:"amount"`
	Status    string    `json:"status"`
	TxHash    string    `json:"txHash,omitempty"`
	Error     string    `json:"error,omitempty"`
}

func (s *Service) Request(ctx context.Context, req Request, remoteAddr string) (response Response, status int, err error) {
	defer func() { s.recordRequestOutcome(response, status, err) }()
	if s.cfg.UpstreamMode == UpstreamAuthoritative {
		return s.requestAuthoritative(ctx, req, remoteAddr)
	}
	if req.RequestID != "" {
		return Response{}, http.StatusBadRequest, fmt.Errorf("request IDs are not supported by this BFT faucet adapter")
	}
	requestID := requestID()
	ip := clientIP(remoteAddr)
	recipient, recipientErr := s.normalizeRecipient(req.Address)
	amount := req.Amount
	if amount == 0 {
		amount = s.cfg.DefaultAmount
	}
	entry := LogEntry{RequestID: requestID, At: time.Now().UTC(), IP: ip, Address: recipient, Amount: amount}
	s.mu.Lock()
	s.requests++
	s.mu.Unlock()
	if recipientErr != nil {
		entry.Status = "rejected"
		entry.Error = "invalid address"
		_ = s.appendLog(entry)
		s.recordDenied(entry.Error)
		return Response{}, http.StatusBadRequest, fmt.Errorf("invalid address")
	}
	if amount <= 0 || amount > s.cfg.MaxAmount {
		entry.Status = "rejected"
		entry.Error = "amount exceeds faucet limits"
		_ = s.appendLog(entry)
		s.recordDenied(entry.Error)
		return Response{}, http.StatusBadRequest, fmt.Errorf("amount exceeds faucet limits")
	}
	if !s.allow(ip, recipient, entry.At) {
		entry.Status = "rate_limited"
		entry.Error = "faucet rate limit exceeded"
		_ = s.appendLog(entry)
		s.recordDenied(entry.Error)
		return Response{}, http.StatusTooManyRequests, fmt.Errorf("faucet rate limit exceeded")
	}
	tx, err := s.callRPC(ctx, recipient, amount)
	if err != nil {
		entry.Status = "error"
		entry.Error = err.Error()
		_ = s.appendLog(entry)
		s.mu.Lock()
		s.lastError = err.Error()
		s.mu.Unlock()
		return Response{}, http.StatusBadGateway, err
	}
	entry.Status = "sent"
	entry.TxHash = tx.Hash
	_ = s.appendLog(entry)
	s.mu.Lock()
	s.successes++
	s.lastHash = tx.Hash
	s.lastError = ""
	s.mu.Unlock()
	return Response{Transaction: tx, Address: recipient, Amount: amount, NativeSymbol: "YNXT", RequestID: requestID, TruthfulStatus: s.truthfulStatus()}, http.StatusCreated, nil
}

func (s *Service) normalizeRecipient(address string) (string, error) {
	address = strings.TrimSpace(address)
	if strings.HasPrefix(strings.ToLower(address), accountaddress.HRP+"1") || strings.HasPrefix(strings.ToLower(address), "0x") {
		canonical, err := accountaddress.Normalize(address)
		if err != nil {
			return "", err
		}
		if s.cfg.UpstreamMode == UpstreamBFT && canonical == s.signerAddr {
			return "", fmt.Errorf("faucet recipient must differ from signer")
		}
		return canonical, nil
	}
	if s.cfg.UpstreamMode == UpstreamBFT {
		return "", fmt.Errorf("BFT faucet requires a canonical YNX recipient")
	}
	if ynxAddressPattern.MatchString(address) {
		return address, nil
	}
	return "", fmt.Errorf("invalid faucet recipient")
}

func (s *Service) truthfulStatus() string {
	if s.cfg.UpstreamMode == UpstreamBFT {
		return "bft-gateway-signed-faucet"
	}
	return "rpc-backed-faucet"
}

func ValidAddress(address string) bool {
	address = strings.TrimSpace(address)
	return ynxAddressPattern.MatchString(address) || evmAddressPattern.MatchString(address)
}

func (s *Service) allow(ip, address string, now time.Time) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	key := ip + "|" + strings.ToLower(address)
	cutoff := now.Add(-s.cfg.Window)
	kept := s.seen[key][:0]
	for _, at := range s.seen[key] {
		if at.After(cutoff) {
			kept = append(kept, at)
		}
	}
	if len(kept) >= s.cfg.MaxRequests {
		s.seen[key] = kept
		return false
	}
	kept = append(kept, now)
	s.seen[key] = kept
	return true
}

func (s *Service) callRPC(ctx context.Context, address string, amount int64) (chain.Transaction, error) {
	return s.callBFTGateway(ctx, address, amount)
}

type bftBroadcastResponse struct {
	Transaction    chain.Transaction `json:"transaction"`
	Committed      bool              `json:"committed"`
	Height         uint64            `json:"height"`
	CometHash      string            `json:"cometHash"`
	TruthfulStatus string            `json:"truthfulStatus"`
}

func (s *Service) callBFTGateway(ctx context.Context, address string, amount int64) (chain.Transaction, error) {
	s.fundMu.Lock()
	defer s.fundMu.Unlock()

	account, err := s.bftAccount(ctx)
	if err != nil {
		return chain.Transaction{}, err
	}
	if account.Nonce == math.MaxUint64 {
		return chain.Transaction{}, fmt.Errorf("BFT faucet account nonce is exhausted")
	}
	if account.Balance < consensus.SignedTransactionFeeYNXT || amount > account.Balance-consensus.SignedTransactionFeeYNXT {
		return chain.Transaction{}, fmt.Errorf("BFT faucet has insufficient YNXT")
	}
	nonce := account.Nonce + 1
	signed, err := consensus.NewSignedTransfer(s.signer, s.cfg.ChainID, address, amount, nonce)
	if err != nil {
		return chain.Transaction{}, err
	}
	payload, err := consensus.EncodeSignedTransaction(signed)
	if err != nil {
		return chain.Transaction{}, err
	}
	expectedHash := consensus.SignedTransactionHash(payload)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, strings.TrimRight(s.cfg.RPCURL, "/")+"/transactions/broadcast", bytes.NewReader(payload))
	if err != nil {
		return chain.Transaction{}, err
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := s.httpClient.Do(req)
	if err != nil {
		return chain.Transaction{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		var errorBody map[string]any
		_ = decodeBoundedJSON(resp.Body, &errorBody)
		return chain.Transaction{}, fmt.Errorf("BFT Gateway broadcast returned %d: %v", resp.StatusCode, errorBody)
	}
	var result bftBroadcastResponse
	if err := decodeBoundedJSON(resp.Body, &result); err != nil {
		return chain.Transaction{}, fmt.Errorf("decode BFT Gateway broadcast: %w", err)
	}
	if !result.Committed || result.Height == 0 || result.TruthfulStatus != "cometbft-broadcast-commit" {
		return chain.Transaction{}, fmt.Errorf("BFT Gateway did not prove committed broadcast")
	}
	tx := result.Transaction
	if tx.Hash != expectedHash || tx.Type != consensus.SignedTransactionType || tx.From != s.signerAddr || tx.To != address || tx.Amount != amount || tx.Fee != consensus.SignedTransactionFeeYNXT || tx.Nonce != nonce || tx.BlockNum != result.Height {
		return chain.Transaction{}, fmt.Errorf("BFT Gateway broadcast response does not match signed faucet transaction")
	}
	if !strings.EqualFold(result.CometHash, strings.TrimPrefix(expectedHash, "0x")) {
		return chain.Transaction{}, fmt.Errorf("BFT Gateway Comet hash does not match signed faucet transaction")
	}
	return tx, nil
}

func (s *Service) bftAccount(ctx context.Context) (chain.ConsensusAccount, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, strings.TrimRight(s.cfg.RPCURL, "/")+"/accounts/"+s.signerAddr, nil)
	if err != nil {
		return chain.ConsensusAccount{}, err
	}
	resp, err := s.httpClient.Do(req)
	if err != nil {
		return chain.ConsensusAccount{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return chain.ConsensusAccount{}, fmt.Errorf("BFT Gateway account returned %d", resp.StatusCode)
	}
	var account chain.ConsensusAccount
	if err := decodeBoundedJSON(resp.Body, &account); err != nil {
		return chain.ConsensusAccount{}, fmt.Errorf("decode BFT faucet account: %w", err)
	}
	if account.Address != s.signerAddr || account.Balance < 0 {
		return chain.ConsensusAccount{}, fmt.Errorf("BFT Gateway returned inconsistent faucet account")
	}
	return account, nil
}

func decodeBoundedJSON(reader io.Reader, target any) error {
	limited := io.LimitReader(reader, MaxResponseBytes+1)
	payload, err := io.ReadAll(limited)
	if err != nil {
		return err
	}
	if len(payload) > MaxResponseBytes {
		return fmt.Errorf("upstream response exceeds %d bytes", MaxResponseBytes)
	}
	decoder := json.NewDecoder(bytes.NewReader(payload))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		return err
	}
	if err := decoder.Decode(&struct{}{}); err != io.EOF {
		return fmt.Errorf("upstream response must contain one JSON value")
	}
	return nil
}

func (s *Service) appendLog(entry LogEntry) error {
	if s.cfg.RequestLog == "" {
		return nil
	}
	s.logMu.Lock()
	defer s.logMu.Unlock()
	if err := os.MkdirAll(filepath.Dir(s.cfg.RequestLog), 0o700); err != nil {
		return err
	}
	f, err := os.OpenFile(s.cfg.RequestLog, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		return err
	}
	defer f.Close()
	payload, err := json.Marshal(entry)
	if err != nil {
		return err
	}
	_, err = f.Write(append(payload, '\n'))
	return err
}

func (s *Service) recordDenied(reason string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.denied++
}

type Health struct {
	CheckedAt                time.Time      `json:"checkedAt"`
	SnapshotAgeMS            int64          `json:"snapshotAgeMs,omitempty"`
	ProbeCached              bool           `json:"probeCached,omitempty"`
	ProbeDurationMS          int64          `json:"probeDurationMs"`
	StatusDurationMS         int64          `json:"statusDurationMs"`
	CapabilityDurationMS     int64          `json:"capabilityDurationMs"`
	AdmissionDurationMS      int64          `json:"admissionDurationMs"`
	FundingDurationMS        int64          `json:"fundingDurationMs"`
	ProbeFailureStage        string         `json:"probeFailureStage,omitempty"`
	IdempotentRequests       bool           `json:"idempotentRequests"`
	FundingReady             bool           `json:"fundingReady"`
	AdmissionReady           bool           `json:"admissionReady"`
	AdmissionCapacityReady   bool           `json:"admissionCapacityReady"`
	AdmissionCount           int            `json:"admissionCount"`
	AdmissionCapacity        int            `json:"admissionCapacity"`
	AdmissionRemaining       int            `json:"admissionRemaining"`
	AdmissionScope           string         `json:"admissionScope"`
	MultiActiveSupported     bool           `json:"multiActiveSupported"`
	DeploymentStrategy       string         `json:"deploymentStrategy"`
	FundingModel             string         `json:"fundingModel"`
	FundingBalanceApplicable bool           `json:"fundingBalanceApplicable"`
	FundingBalanceYNXT       int64          `json:"fundingBalanceYnxt,omitempty"`
	RequestStatusPath        string         `json:"requestStatusPath"`
	IPRateLimitMax           int            `json:"ipRateLimitMax"`
	IPRateLimitWindowSeconds int64          `json:"ipRateLimitWindowSeconds"`
	RequestPath              string         `json:"requestPath"`
	RateLimitMax             int            `json:"rateLimitMax"`
	RateLimitWindowSeconds   int64          `json:"rateLimitWindowSeconds"`
	OK                       bool           `json:"ok"`
	Service                  string         `json:"service"`
	RPCURL                   string         `json:"rpcUrl"`
	UpstreamMode             string         `json:"upstreamMode"`
	FaucetAddress            string         `json:"faucetAddress,omitempty"`
	UpstreamOK               bool           `json:"upstreamOk"`
	ChainID                  int64          `json:"chainId,omitempty"`
	Height                   uint64         `json:"height,omitempty"`
	NativeSymbol             string         `json:"nativeSymbol"`
	DefaultAmount            int64          `json:"defaultAmount"`
	MaxAmount                int64          `json:"maxAmount"`
	RateLimit                string         `json:"rateLimit"`
	RequestLog               string         `json:"requestLog"`
	Requests                 int64          `json:"requests"`
	Successes                int64          `json:"successes"`
	Denied                   int64          `json:"denied"`
	LastTxHash               string         `json:"lastTxHash,omitempty"`
	LastError                string         `json:"lastError,omitempty"`
	Build                    buildinfo.Info `json:"build"`
	TruthfulStatus           string         `json:"truthfulStatus"`
}

func (s *Service) Health() Health {
	s.mu.Lock()
	defer s.mu.Unlock()
	fundingModel := "protocol-authority"
	admissionScope := "single-instance-local-bbolt"
	admissionCapacity := s.cfg.MaxAdmissions
	admissionRemaining := s.cfg.MaxAdmissions
	if s.cfg.UpstreamMode == UpstreamBFT {
		fundingModel = "bft-account"
		admissionScope = "process-local-memory"
		admissionCapacity = 0
		admissionRemaining = 0
	}
	return Health{
		OK:                s.lastError == "",
		Service:           "ynx-faucetd",
		RequestPath:       "/request",
		RequestStatusPath: "/request-status", IPRateLimitMax: s.cfg.IPMaxRequests, IPRateLimitWindowSeconds: int64(s.cfg.IPWindow.Seconds()),
		IdempotentRequests:       s.cfg.UpstreamMode == UpstreamAuthoritative,
		AdmissionReady:           s.cfg.UpstreamMode != UpstreamAuthoritative || s.admissions != nil,
		AdmissionCapacityReady:   s.cfg.UpstreamMode != UpstreamAuthoritative || s.admissions != nil,
		AdmissionCapacity:        admissionCapacity,
		AdmissionRemaining:       admissionRemaining,
		AdmissionScope:           admissionScope,
		MultiActiveSupported:     false,
		DeploymentStrategy:       "stop-drain-start",
		FundingModel:             fundingModel,
		FundingBalanceApplicable: s.cfg.UpstreamMode == UpstreamBFT,
		RateLimitMax:             s.cfg.MaxRequests,
		RateLimitWindowSeconds:   int64(s.cfg.Window.Seconds()),
		RPCURL:                   s.cfg.RPCURL,
		UpstreamMode:             s.cfg.UpstreamMode,
		FaucetAddress:            s.signerAddr,
		NativeSymbol:             "YNXT",
		DefaultAmount:            s.cfg.DefaultAmount,
		MaxAmount:                s.cfg.MaxAmount,
		RateLimit:                fmt.Sprintf("%d per %s per address", s.cfg.MaxRequests, s.cfg.Window),
		RequestLog:               s.cfg.RequestLog,
		Requests:                 s.requests,
		Successes:                s.successes,
		Denied:                   s.denied,
		LastTxHash:               s.lastHash,
		LastError:                s.lastError,
		TruthfulStatus:           s.truthfulStatus(),
	}
}

type rpcStatus struct {
	ChainID              int64  `json:"chainId"`
	Height               uint64 `json:"height"`
	NativeCurrencySymbol string `json:"nativeCurrencySymbol"`
}

func (s *Service) probeHealth(ctx context.Context) (health Health) {
	started := time.Now()
	statusDone := false
	defer func() {
		health.CheckedAt = time.Now().UTC()
		health.ProbeDurationMS = time.Since(started).Milliseconds()
		if !statusDone {
			health.StatusDurationMS = health.ProbeDurationMS
		}
	}()
	health = s.Health()
	health.ProbeFailureStage = "status"
	var status rpcStatus
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, strings.TrimRight(s.cfg.RPCURL, "/")+"/status", nil)
	if err != nil {
		health.OK = false
		health.LastError = err.Error()
		return health
	}
	resp, err := s.healthClient.Do(req)
	if err != nil {
		health.OK = false
		health.LastError = err.Error()
		return health
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		health.OK = false
		health.LastError = fmt.Sprintf("RPC status returned %d", resp.StatusCode)
		return health
	}
	// Core status is extensible; bound its body and reject trailing JSON without
	// rejecting unrelated status fields added by another compatible Core build.
	raw, err := io.ReadAll(io.LimitReader(resp.Body, MaxResponseBytes+1))
	if err == nil && len(raw) > MaxResponseBytes {
		err = fmt.Errorf("RPC status exceeds response limit")
	}
	if err == nil {
		err = json.Unmarshal(raw, &status)
	}
	if err != nil {
		health.OK = false
		health.LastError = err.Error()
		return health
	}
	health.StatusDurationMS = time.Since(started).Milliseconds()
	statusDone = true
	health.UpstreamOK = status.NativeCurrencySymbol == "YNXT" && status.ChainID == s.cfg.ChainID
	health.ChainID = status.ChainID
	health.Height = status.Height
	if !health.UpstreamOK {
		health.OK = false
		health.LastError = "RPC network identity does not match the Faucet"
	}
	if health.UpstreamOK {
		health.OK = true
		health.LastError = ""
		if s.cfg.UpstreamMode == UpstreamAuthoritative {
			capabilityStart := time.Now()
			if err := s.probeFaucetCapability(ctx, s.healthClient); err != nil {
				health.OK = false
				health.LastError = err.Error()
				health.ProbeFailureStage = "capability"
			}
			health.CapabilityDurationMS = time.Since(capabilityStart).Milliseconds()
			if health.OK {
				s.noteCapabilitySuccess()
			}
			if health.OK {
				admissionStart := time.Now()
				if err := s.admissions.health(); err != nil {
					health.OK = false
					health.AdmissionReady = false
					health.AdmissionCapacityReady = false
					health.LastError = "durable faucet admission is unavailable"
					health.ProbeFailureStage = "admission"
					s.recordAdmissionStoreError("health")
				} else if used, limit, err := s.admissions.capacity(); err != nil {
					health.OK = false
					health.AdmissionReady = false
					health.AdmissionCapacityReady = false
					health.LastError = "durable faucet admission capacity is unavailable"
					health.ProbeFailureStage = "admission"
					s.recordAdmissionStoreError("health")
				} else {
					health.AdmissionCount = used
					health.AdmissionCapacity = limit
					health.AdmissionRemaining = limit - used
					health.AdmissionCapacityReady = used < limit
					if !health.AdmissionCapacityReady {
						health.OK = false
						health.LastError = "durable faucet admission capacity is exhausted"
						health.ProbeFailureStage = "capacity"
					}
				}
				health.AdmissionDurationMS = time.Since(admissionStart).Milliseconds()
			}
		} else if health.OK {
			fundingStart := time.Now()
			account, err := s.bftAccount(ctx)
			health.FundingDurationMS = time.Since(fundingStart).Milliseconds()
			if err != nil {
				health.OK = false
				health.LastError = "BFT faucet funding account is unavailable"
				health.ProbeFailureStage = "funding"
			} else {
				health.FundingBalanceYNXT = account.Balance
				if account.Balance < s.cfg.DefaultAmount+consensus.SignedTransactionFeeYNXT {
					health.OK = false
					health.LastError = "BFT faucet has insufficient YNXT"
					health.ProbeFailureStage = "funding"
				}
			}
		}
	}
	health.FundingReady = health.OK && health.UpstreamOK
	if health.FundingReady {
		health.ProbeFailureStage = ""
	}
	return health
}

func (s *Service) Metrics() string {
	h := s.Health()
	labels := `native_symbol="YNXT"`
	return fmt.Sprintf(`# HELP ynx_faucet_requests_total Requests received by ynx-faucetd.
# TYPE ynx_faucet_requests_total counter
ynx_faucet_requests_total{%s} %d
# HELP ynx_faucet_success_total Successful faucet transactions.
# TYPE ynx_faucet_success_total counter
ynx_faucet_success_total{%s} %d
# HELP ynx_faucet_denied_total Rejected or rate-limited faucet requests.
# TYPE ynx_faucet_denied_total counter
ynx_faucet_denied_total{%s} %d
`, labels, h.Requests, labels, h.Successes, labels, h.Denied) + s.requestMetrics() + s.healthMetrics() + s.flightMetrics()
}

func (s *Service) recordRequestOutcome(response Response, status int, err error) {
	outcome := response.Status
	switch outcome {
	case "accepted", "admission_unavailable", "ip_rate_limited", "rate_limited", "receipt_persistence_uncertain", "request_id_conflict", "stored_receipt_invalid", "transaction_result_uncertain", "upstream_capability_unavailable":
	default:
		switch {
		case err == nil && status >= 200 && status < 300:
			outcome = "accepted"
		case status == http.StatusBadRequest:
			outcome = "invalid_request"
		case status == http.StatusTooManyRequests:
			outcome = "rate_limited"
		case status >= 500:
			outcome = "upstream_error"
		default:
			outcome = "other_error"
		}
	}
	s.mu.Lock()
	s.requestOutcomes[outcome]++
	s.mu.Unlock()
}

func (s *Service) recordAdmissionStoreError(operation string) {
	switch operation {
	case "admit", "complete", "health", "lookup":
	default:
		operation = "other"
	}
	s.mu.Lock()
	s.admissionErrors[operation]++
	s.mu.Unlock()
}

func (s *Service) requestMetrics() string {
	s.mu.Lock()
	outcomes := make(map[string]uint64, len(s.requestOutcomes))
	for key, value := range s.requestOutcomes {
		outcomes[key] = value
	}
	admission := make(map[string]uint64, len(s.admissionErrors))
	for key, value := range s.admissionErrors {
		admission[key] = value
	}
	s.mu.Unlock()
	var b strings.Builder
	fmt.Fprintf(&b, "# HELP ynx_faucet_default_amount_ynxt Configured default grant amount.\n# TYPE ynx_faucet_default_amount_ynxt gauge\nynx_faucet_default_amount_ynxt %d\n", s.cfg.DefaultAmount)
	b.WriteString("# HELP ynx_faucet_request_results_total Faucet request results by bounded outcome.\n# TYPE ynx_faucet_request_results_total counter\n")
	for _, outcome := range []string{"accepted", "admission_unavailable", "invalid_request", "ip_rate_limited", "other_error", "rate_limited", "receipt_persistence_uncertain", "request_id_conflict", "stored_receipt_invalid", "transaction_result_uncertain", "upstream_capability_unavailable", "upstream_error"} {
		fmt.Fprintf(&b, "ynx_faucet_request_results_total{outcome=%q} %d\n", outcome, outcomes[outcome])
	}
	b.WriteString("# HELP ynx_faucet_admission_store_errors_total Durable admission store errors by bounded operation.\n# TYPE ynx_faucet_admission_store_errors_total counter\n")
	for _, operation := range []string{"admit", "complete", "health", "lookup", "other"} {
		fmt.Fprintf(&b, "ynx_faucet_admission_store_errors_total{operation=%q} %d\n", operation, admission[operation])
	}
	return b.String()
}

func requestID() string {
	return fmt.Sprintf("faucet_%d", time.Now().UnixNano())
}

func clientIP(remoteAddr string) string {
	host, _, err := net.SplitHostPort(remoteAddr)
	if err == nil {
		return host
	}
	if remoteAddr == "" {
		return "unknown"
	}
	return remoteAddr
}
