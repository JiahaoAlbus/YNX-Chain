'use strict';
// Successor of the retained normal Android recipe. Build inputs are public pins,
// never authority, enrollment state or runtime configuration.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const SOURCE_SHA = '86a7fc7f417cad43c5f03d8c62c4e064e33326f53fbdf6868fd8a796672ccbfa';
const TREE_SHA = '98e73af5c9f6d30322197fbe1844f9c345342a5817e34ff798fd25d0c2cfdf8d';
const CLOSURE_SHA = '2366c9dd8d6651308f3e1d0c68e9af9c98fd5f75c1a2d1fedf2fbebcef7cf949';
const LOCK_SHA = '8701f492195b503bac8c6413cc537b6aad3a7a6a0ae8732447bbb5e5aeafe7c2';
const C_UNITS = [
  [
    "c/src/veil_checked_store.c",
    true
  ],
  [
    "c/src/veil_producer_unavailable.c",
    true
  ],
  [
    "c/src/veil_store_custody.c",
    true
  ],
  [
    "protected-source/ynx_source_platform_client.c",
    false
  ],
  [
    "protected-source/ynx_source_platform_unbound.c",
    false
  ],
  [
    "protected-source/source_server_private.c",
    false
  ],
  [
    "protected-source/linux/ynx_source_sealed_role_launcher.c",
    false
  ],
  [
    "protected-source/linux/ynx_tpm2_esys_owner.c",
    false
  ],
  [
    "protected-source/linux/ynx_source_original_resource_owner.c",
    false
  ],
  [
    "protected-source/linux/ynx_source_administration_owner.c",
    true
  ],
  [
    "protected-source/linux/ynx_source_independent_reservation.c",
    false
  ],
  [
    "protected-source/linux/ynx_source_platform_qualified.c",
    false
  ],
  [
    "protected-source/linux/ynx_source_final_owner.c",
    false
  ],
  [
    "protected-source/linux/ynx_message_enrollment_resolver.c",
    false
  ],
  [
    "protected-source/linux/ynx_source_server_resource_owner.c",
    false
  ]
];
const BASE_LIBRARIES = [
  'libveil_ownkey_custodian_v4.a', 'libveil_ownkey_bootstrap_final.a',
  'libveil_predevice_pair.a', 'libveil_predevice_sqlite3500400.a',
  'liboqs.a', 'libsodium.a', 'libtss2-esys.a', 'libtss2-sys.a',
  'libtss2-mu.a', 'libtss2-tcti-device.a', 'libtss2-tctildr.a',
  'libssl.a', 'libcrypto.a',
];
const HOST_FEATURES = ['abi5-final-native-link', 'predevice-reconciliation-v3',
  'predevice-cold-v1', 'source-collector-bridge'];
function need(ok, message) { if (!ok) throw new Error(message); }
function sha(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex'); }
function absolute(p) {
  need(typeof p === 'string' && path.isAbsolute(p) && !/[\0\r\n]/.test(p), 'Absolute path required');
  return path.resolve(p);
}
function pin(p, io = fs) {
  const bytes = io.readFileSync(p);
  return { path: p, bytes: bytes.length, sha256: sha(bytes) };
}
function exactFile(expected, io = fs) {
  need(expected && Number.isSafeInteger(expected.bytes) && expected.bytes >= 0 &&
    /^[a-f0-9]{64}$/.test(expected.sha256), 'Complete file pin required');
  const p = absolute(expected.path), stat = io.lstatSync(p);
  need(stat.isFile() && !stat.isSymbolicLink(), 'Pinned leaf must be a regular file: ' + p);
  const bytes = io.readFileSync(p);
  need(bytes.length === expected.bytes && sha(bytes) === expected.sha256, 'Changed input: ' + p);
  return bytes;
}
function inside(root, relative) {
  need(typeof relative === 'string' && relative.length > 0 && !path.isAbsolute(relative) &&
    !relative.split('/').some(x => x === '..' || x === '.' || x === ''), 'Unsafe relative input');
  const result = path.resolve(root, relative);
  need(result.startsWith(root + path.sep), 'Input escaped root');
  return result;
}
function verifyTree(root, entries, io = fs) {
  root = absolute(root);
  need(Array.isArray(entries) && entries.length > 0, 'Source entries required');
  const seen = new Set(), verifiedLinks = new Map();
  for (const e of entries) {
    need(!seen.has(e.path), 'Duplicate source entry'); seen.add(e.path);
    const p = inside(root, e.path), st = io.lstatSync(p);
    need((st.mode & 0o777) === Number(e.mode), 'Source mode changed');
    let bytes;
    if (e.type === 'symlink') {
      need(st.isSymbolicLink() && (e.literal === undefined || typeof e.literal === 'string'), 'Source symlink type changed');
      const literal = io.readlinkSync(p);
      if (e.literal !== undefined) need(literal === e.literal, 'Source symlink changed');
      bytes = Buffer.from(literal);
      verifiedLinks.set(e.path, literal);
    } else {
      need(e.type === 'file' && st.isFile() && !st.isSymbolicLink(), 'Source leaf type changed');
      bytes = io.readFileSync(p);
    }
    need(bytes.length === e.bytes && sha(bytes) === e.sha256, 'Source bytes changed: ' + e.path);
    const blob = crypto.createHash('sha1').update(Buffer.from('blob ' + bytes.length + '\0')).update(bytes).digest('hex');
    need(blob === e.gitBlob, 'Source blob changed: ' + e.path);
  }
  function walk(dir, prefix = '') {
    for (const name of io.readdirSync(dir)) {
      const relative = prefix ? prefix + '/' + name : name;
      const p = inside(root, relative), st = io.lstatSync(p);
      if (st.isDirectory() && !st.isSymbolicLink()) walk(p, relative);
      else need(seen.has(relative), 'Unlisted source leaf: ' + relative);
    }
  }
  walk(root);
  return verifiedLinks;
}
function profile(kind, config) {
  if (kind === 'android') {
    need(config.target === 'aarch64-linux-android' && config.androidApi === 24, 'Android arm64/API24 required');
    return { rust: config.target, machine: 'AArch64', features: ['abi5-final-native-link', 'predevice-cold-v1'], goarch: null };
  }
  need(kind === 'linux', 'Unsupported build kind');
  need(config.target === 'aarch64-unknown-linux-gnu' || config.target === 'x86_64-unknown-linux-gnu',
    'Actual Linux target required; Darwin is not a deployment artifact');
  const arm = config.target.startsWith('aarch64-');
  need(config.service && config.service.goos === 'linux' &&
    config.service.goarch === (arm ? 'arm64' : 'amd64'), 'Go/native target mismatch');
  return { rust: config.target, machine: arm ? 'AArch64' : 'Advanced Micro Devices X86-64',
    features: HOST_FEATURES.slice(), goarch: config.service.goarch };
}
function validateConfig(kind, config) {
  need(config && config.schemaVersion === 1, 'Build-input version required');
  const selected = profile(kind, config);
  const sourceRoot = absolute(config.sourceRoot), outputRoot = absolute(config.outputRoot);
  absolute(config.cargoHome);
  need(!outputRoot.startsWith(sourceRoot + path.sep) && outputRoot !== sourceRoot, 'Output must not modify source');
  need(Object.keys(config.libraries || {}).length === BASE_LIBRARIES.length &&
    Object.keys(config.libraries).every(n => BASE_LIBRARIES.includes(n)), 'Unexpected dependency library');
  const support = ['sqlite3.h', 'official-sqlite-symbols.h', ...(kind === 'android' ? ['allocation_diagnostic.o'] : [])];
  need(Object.keys(config.support || {}).length === support.length &&
    Object.keys(config.support).every(n => support.includes(n)), 'Unexpected support input');
  need(config.nativeManifest?.sha256 === SOURCE_SHA && config.closureManifest?.sha256 === CLOSURE_SHA,
    'Exact R11 source/closure pins required');
  need(config.cargoLock?.sha256 === LOCK_SHA && config.cargoLock.path === path.join(config.sourceRoot, 'native/Cargo.lock'),
    'Actual native/Cargo.lock required');
  for (const name of ['cc', 'ar', 'cargo', 'rustc', 'rustdoc', 'readelf', 'nm', 'protoc']) {
    need(config.tools?.[name]?.path, 'Missing pinned tool: ' + name);
  }
  need(Array.isArray(config.headerPins) && config.headerPins.length > 0, 'Target headers must be pinned');
  need(Array.isArray(config.includeDirectories) && config.includeDirectories.length > 0, 'Target include paths required');
  config.includeDirectories.forEach(absolute);
  for (const name of BASE_LIBRARIES) {
    const item = config.libraries?.[name];
    need(item && item.target === selected.rust, 'Missing/foreign target library: ' + name);
    need(path.basename(item.path) === name, 'Wrong library leaf: ' + name);
  }
  for (const name of ['sqlite3.h', 'official-sqlite-symbols.h']) {
    need(config.support?.[name]?.path && path.basename(config.support[name].path) === name,
      'Actual SQLite header required: ' + name);
  }
  if (kind === 'android') need(config.support?.['allocation_diagnostic.o']?.target === selected.rust,
    'Matching Android diagnostic object required');
  if (kind === 'linux') {
    absolute(config.service.root);
    need(config.tools.go?.path && config.service.manifest, 'Pinned full Go service and toolchain required');
  }
  need(!config.resume && !config.reuseObjects, 'Old object or completed-log reuse is forbidden');
  return selected;
}
function verifySourceManifest(manifest) {
  need(manifest && manifest.treeSHA256 === TREE_SHA &&
    (manifest.whole === undefined || manifest.whole === 152) &&
    Array.isArray(manifest.entries) && manifest.entries.length === 152,
    'Wrong whole source manifest');
  // R11 records the exact ordered entry vector, without redundant whole/literal
  // fields. Keep its original bytes and bind every path/mode/digest to that vector.
  need(sha(Buffer.from(JSON.stringify(manifest.entries))) === TREE_SHA,
    'Source manifest entry vector changed');
}
function verifyInputs(kind, config, io = fs, postBuild = false) {
  const selected = validateConfig(kind, config);
  if (!postBuild) need(!io.existsSync(config.outputRoot), 'Output exists; do not overwrite or resume');
  const manifest = JSON.parse(exactFile(config.nativeManifest, io));
  verifySourceManifest(manifest);
  const sourceLinks = verifyTree(config.sourceRoot, manifest.entries, io);
  exactFile(config.cargoLock, io);
  const closure = JSON.parse(exactFile(config.closureManifest, io));
  need(closure.treeSHA256 === TREE_SHA && closure.selectedCount === C_UNITS.length &&
    JSON.stringify(closure.translationUnits.map(e => [e.path, e.sqliteForcedPrefixInclude])) === JSON.stringify(C_UNITS),
    'Incomplete or changed selected C closure');
  for (const p of [...Object.values(config.tools), ...Object.values(config.libraries),
    ...Object.values(config.support), ...config.headerPins]) exactFile(p, io);
  for (const directory of config.includeDirectories) {
    need(config.headerPins.some(p => p.path.startsWith(directory + path.sep)), 'Unpinned include directory');
  }
  if (kind === 'linux') {
    const service = JSON.parse(exactFile(config.service.manifest, io));
    verifyTree(config.service.root, service.entries, io);
  }
  // Literal native source symlinks retain their pinned spelling. The build owner
  // must also supply full pins of their upstream source targets, not just links.
  need(Array.isArray(config.upstreamTrees) && config.upstreamTrees.length > 0, 'Pinned upstream source trees required');
  const roots = new Set();
  for (const upstream of config.upstreamTrees) {
    roots.add(absolute(upstream.root));
    verifyTree(upstream.root, JSON.parse(exactFile(upstream.manifest, io)).entries, io);
  }
  for (const e of manifest.entries.filter(x => x.type === 'symlink')) {
    need(roots.has(path.resolve(path.dirname(inside(config.sourceRoot, e.path)), sourceLinks.get(e.path))),
      'Unpinned upstream symlink target: ' + e.path);
  }
  return selected;
}
function makePlan(kind, config) {
  const p = validateConfig(kind, config), out = config.outputRoot;
  const objects = path.join(out, 'objects'), deps = path.join(out, 'dependencies');
  const source = config.sourceRoot, lib = path.join(out, 'libveil_abi5_store.a');
  const commands = [];
  const add = (name, command, args, cwd = out, env = {}) => commands.push({ name, command, args, cwd, env });
  for (const [relative, prefix] of C_UNITS) {
    const name = path.basename(relative, '.c');
    const includes = [path.join(source, 'c/include'), path.join(source, 'c/src'),
      path.join(source, 'protected-source'), path.join(source, 'protected-source/include'),
      path.join(source, 'protected-source/linux'), deps, ...config.includeDirectories];
    const args = ['-std=c11', '-D_GNU_SOURCE', '-fPIC', '-O2', '-pthread',
      ...includes.flatMap(x => ['-I', x]), '-MD', '-MF', path.join(objects, name + '.d')];
    if (prefix) args.push('-include', path.join(deps, 'official-sqlite-symbols.h'));
    args.push('-c', path.join(source, relative), '-o', path.join(objects, name + '.o'));
    add('c-' + name, config.tools.cc.path, args);
  }
  add('archive-store', config.tools.ar.path, ['rcs', lib,
    ...C_UNITS.map(([relative]) => path.join(objects, path.basename(relative, '.c') + '.o'))]);
  const extra = ['-L', 'native=' + out, '-L', 'native=' + deps, '-C', 'debuginfo=0'];
  const targetDir = path.join(out, 'target');
  if (kind === 'android') {
    extra.push('-C', 'link-arg=' + path.join(deps, 'allocation_diagnostic.o'));
    extra.push('-C', 'link-arg=-Wl,--start-group', '-C', 'link-arg=' + lib);
    for (const name of BASE_LIBRARIES) extra.push('-C', 'link-arg=' + path.join(deps, name));
    extra.push('-C', 'link-arg=-Wl,--end-group', '-C', 'link-arg=-ldl',
      '-C', 'link-arg=-llog', '-C', 'link-arg=-lm', '-C', 'link-arg=-Wl,--no-undefined');
  } else extra.push('--print', 'native-static-libs');
  add(kind === 'android' ? 'rust-link' : 'rust-static', config.tools.cargo.path,
    ['rustc', '--offline', '--locked', '--manifest-path', path.join(source, 'native/Cargo.toml'),
      '-p', 'ynx-native-operation', '--target', p.rust, '--lib', '--crate-type',
      kind === 'android' ? 'cdylib' : 'staticlib', '--no-default-features',
      '--features', p.features.join(','), '--', ...extra], path.join(source, 'native'));
  return { kind, target: p, outputRoot: out, objects, dependencies: deps, archive: lib, targetDir, commands };
}
function buildEnvironment(config, plan, inherited = process.env) {
  const key = plan.target.rust.replaceAll('-', '_');
  const env = {};
  for (const name of ['HOME', 'USER', 'TMPDIR', 'LANG', 'LC_ALL', 'SYSTEMROOT']) {
    if (inherited[name] !== undefined) env[name] = inherited[name];
  }
  Object.assign(env, {
    PATH: [...new Set(Object.values(config.tools).map(t => path.dirname(t.path))), '/usr/bin', '/bin'].join(path.delimiter),
    CARGO_HOME: config.cargoHome, CARGO_TARGET_DIR: plan.targetDir,
    RUSTC: config.tools.rustc.path, RUSTDOC: config.tools.rustdoc.path,
    PROTOC: config.tools.protoc.path, CARGO_PROFILE_DEV_DEBUG: '0',
    CARGO_PROFILE_DEV_STRIP: 'none', CARGO_BUILD_JOBS: '1',
    ['CARGO_TARGET_' + key.toUpperCase() + '_LINKER']: config.tools.cc.path,
    ['CC_' + key]: config.tools.cc.path, ['AR_' + key]: config.tools.ar.path,
  });
  return env;
}
function runCommands(plan, run) {
  let staticFlags;
  for (const step of plan.commands) {
    const output = run(step);
    if (step.name === 'rust-static') {
      staticFlags = [...output.matchAll(/note: native-static-libs: (.+)/g)].at(-1)?.[1];
      need(staticFlags && /^(-l[a-zA-Z0-9_+-]+ ?)+$/.test(staticFlags), 'Unexpected native-static-libs output');
    }
  }
  return staticFlags;
}
function goLinkStep(config, plan, library, staticFlags) {
  need(plan.kind === 'linux' && typeof staticFlags === 'string' &&
    /^(-l[a-zA-Z0-9_+-]+ ?)+$/.test(staticFlags), 'Linux native link flags required');
  const grouped = [library, plan.archive, ...BASE_LIBRARIES.map(n => path.join(plan.dependencies, n))];
  const ld = ['-L' + plan.outputRoot, '-L' + plan.dependencies,
    '-Wl,--start-group', ...grouped, '-Wl,--end-group', ...staticFlags.trim().split(/\s+/),
    '-Wl,--no-undefined', '-ldl', '-lpthread', '-lm'];
  const quote = s => '"' + s.replaceAll('\\', '\\\\').replaceAll('"', '\\"') + '"';
  return { name: 'go-link', command: config.tools.go.path,
    args: ['build', '-tags', 'ynx_source_native_collector', '-o', path.join(plan.outputRoot, 'ynx-sociald'), './cmd/ynx-sociald'],
    cwd: config.service.root, env: { CGO_ENABLED: '1', GOTOOLCHAIN: 'local', GOPROXY: 'off',
      GOSUMDB: 'off', GOWORK: 'off', GOFLAGS: '-mod=readonly', GOOS: 'linux', GOARCH: plan.target.goarch,
      CC: config.tools.cc.path, CXX: config.tools.cc.path,
      CGO_CFLAGS: ['-I' + path.join(config.sourceRoot, 'c/include'),
        '-I' + path.join(config.sourceRoot, 'protected-source/include'),
        '-I' + path.join(config.sourceRoot, 'protected-source')].map(quote).join(' '),
      CGO_LDFLAGS: ld.map(quote).join(' ') } };
}
function verifyElfHeader(bytes, kind, target) {
  const machine = { 'aarch64-linux-android': 183, 'aarch64-unknown-linux-gnu': 183,
    'x86_64-unknown-linux-gnu': 62 }[target];
  need(machine && Buffer.isBuffer(bytes) && bytes.length >= 64 &&
    bytes.subarray(0, 4).equals(Buffer.from([0x7f, 0x45, 0x4c, 0x46])) &&
    bytes[4] === 2 && bytes[5] === 1 && bytes[6] === 1,
    'Final artifact architecture mismatch');
  const type = bytes.readUInt16LE(16);
  need(bytes.readUInt16LE(18) === machine &&
    (kind === 'android' ? type === 3 : kind === 'linux' && (type === 2 || type === 3)),
    'Final artifact architecture mismatch');
}
function executePlan(config, plan) {
  const out = plan.outputRoot;
  fs.mkdirSync(out, { mode: 0o700 }); // Nonrecursive, exclusive fresh output.
  for (const dir of [plan.objects, plan.dependencies, path.join(out, 'logs')]) fs.mkdirSync(dir, { mode: 0o700 });
  const env = buildEnvironment(config, plan), steps = [];
  let status = 'FAILED';
  const write = (name, value) => fs.writeFileSync(path.join(out, name),
    JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  function run(step) {
    const log = path.join(out, 'logs', step.name + '.log'), fd = fs.openSync(log, 'wx', 0o600);
    let r;
    try { r = spawnSync(step.command, step.args, { cwd: step.cwd || out, env: { ...env, ...step.env }, stdio: ['ignore', fd, fd] }); }
    finally { fs.closeSync(fd); }
    steps.push({ ...step, log, exit: r.status, signal: r.signal, error: r.error?.message });
    need(!r.error && r.status === 0 && r.signal === null, step.name + ' failed; see ' + log);
    return fs.readFileSync(log, 'utf8');
  }
  try {
    write('BUILD_INPUTS.json', config); write('COMMAND_PLAN.json', plan);
    for (const [name, source] of Object.entries({ ...config.libraries, ...config.support })) {
      need(/^[a-zA-Z0-9_.-]+$/.test(name), 'Unsafe dependency leaf');
      const bytes = exactFile(source);
      fs.writeFileSync(path.join(plan.dependencies, name), bytes, { flag: 'wx', mode: 0o600 });
    }
    const staticFlags = runCommands(plan, run);
    const target = path.join(plan.targetDir, plan.target.rust, 'debug');
    const library = path.join(out, plan.kind === 'android' ? 'libynx_native_operation.so' : 'libynx_native_operation.a');
    fs.copyFileSync(path.join(target, path.basename(library)), library, fs.constants.COPYFILE_EXCL);
    let artifact = library;
    if (plan.kind === 'linux') {
      // Rust's staticlib may already bundle checked-store archive members; link
      // the selected archive separately once, rather than appending duplicates.
      artifact = path.join(out, 'ynx-sociald');
      run(goLinkStep(config, plan, library, staticFlags));
    }
    const elf = run({ name: 'elf', command: config.tools.readelf.path, args: ['--file-header', '--dynamic', artifact] });
    verifyElfHeader(fs.readFileSync(artifact), plan.kind, plan.target.rust);
    if (plan.kind === 'android') {
      const symbols = run({ name: 'symbols', command: config.tools.nm.path, args: ['--dynamic', '--defined-only', artifact] });
      for (const suffix of ['Prepare', 'ObserveSignatures', 'CloseSignatures']) {
        const name = 'Java_com_ynx_social_matrix_VeilNativeAccountChannel_native' + suffix;
        need(symbols.split('\n').filter(line => line.trim().endsWith(' ' + name)).length === 1, 'Missing/duplicate normal JNI symbol: ' + name);
      }
    }
    verifyInputs(plan.kind, config, fs, true);
    status = 'LINKED_NOT_EXECUTED';
    write('ARTIFACT.json', { state: status, artifact: pin(artifact), library: pin(library),
      target: plan.target.rust, sourceTree: TREE_SHA, runtime: 'NOT_EXECUTED',
      grant: false, twoClientM1: false, installed: false, deployed: false });
  } finally {
    write('TERMINAL.json', { state: status, steps, sourceWrites: 0, runtime: false, serviceStarted: false });
  }
}
function main(kind, argv = process.argv.slice(2)) {
  need(argv.length === 3 && argv[0] === '--inputs' && /^[a-f0-9]{64}$/.test(argv[2]),
    'Usage: node recipe.cjs --inputs /absolute/pinned-build-inputs.json SHA256');
  const bytes = fs.readFileSync(absolute(argv[1]));
  need(sha(bytes) === argv[2], 'Build-input manifest changed');
  const config = JSON.parse(bytes);
  need(absolute(config.outputRoot).startsWith(path.resolve(__dirname, '..') + path.sep),
    'Output must remain in this owned recipe carrier');
  verifyInputs(kind, config);
  executePlan(config, makePlan(kind, config));
}
module.exports = { C_UNITS, BASE_LIBRARIES, SOURCE_SHA, TREE_SHA, CLOSURE_SHA, LOCK_SHA,
  exactFile, verifyTree, verifySourceManifest, verifyElfHeader, profile, validateConfig, verifyInputs, makePlan, buildEnvironment, runCommands, goLinkStep, executePlan, main };
if (require.main === module) {
  try { main('android'); } catch (error) { console.error(error.message); process.exitCode = 1; }
}
