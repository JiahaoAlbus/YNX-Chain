'use strict';
// PUBLIC planning/guard controls. No compiler, native library, service or network
// is launched. Success means recipe behavior only, never product acceptance.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const recipe = require('./build-matching-android-native.cjs');
const host = require('./build-matching-host-service.cjs');
const fakePin = p => ({ path: p, bytes: 1, sha256: '0'.repeat(64) });
test('ELF architecture validation uses binary header and refuses wrong class, endian, machine or type', () => {
  const header = Buffer.alloc(64);
  Buffer.from([0x7f, 0x45, 0x4c, 0x46, 2, 1, 1]).copy(header);
  header.writeUInt16LE(3, 16); header.writeUInt16LE(183, 18);
  recipe.verifyElfHeader(header, 'android', 'aarch64-linux-android');
  for (const [offset, value] of [[0, 0], [4, 1], [5, 2], [6, 0], [16, 2], [18, 62]]) {
    const bad = Buffer.from(header); bad[offset] = value;
    assert.throws(() => recipe.verifyElfHeader(bad, 'android', 'aarch64-linux-android'), /architecture mismatch/);
  }
  assert.throws(() => recipe.verifyElfHeader(header.subarray(0, 24), 'android', 'aarch64-linux-android'), /architecture mismatch/);
  assert.throws(() => recipe.verifyElfHeader(header, 'linux', 'x86_64-unknown-linux-gnu'), /architecture mismatch/);
  const x64 = Buffer.from(header); x64.writeUInt16LE(62, 18);
  recipe.verifyElfHeader(x64, 'linux', 'x86_64-unknown-linux-gnu');
});
function config(kind = 'android') {
  const target = kind === 'android' ? 'aarch64-linux-android' : 'aarch64-unknown-linux-gnu';
  const c = {
    schemaVersion: 1, target, androidApi: kind === 'android' ? 24 : undefined,
    sourceRoot: '/qa/source', outputRoot: '/qa/new-output', cargoHome: '/qa/cargo',
    nativeManifest: { ...fakePin('/qa/FULL_SOURCE_MANIFEST.json'), sha256: recipe.SOURCE_SHA },
    closureManifest: { ...fakePin('/qa/CLOSURE.json'), sha256: recipe.CLOSURE_SHA },
    cargoLock: { ...fakePin('/qa/source/native/Cargo.lock'), sha256: recipe.LOCK_SHA },
    tools: Object.fromEntries(['cc','ar','cargo','rustc','rustdoc','readelf','nm','protoc',
      ...(kind === 'linux' ? ['go'] : [])].map(n => [n, fakePin('/qa/bin/' + n)])),
    headerPins: [fakePin('/qa/include/openssl/ssl.h')], includeDirectories: ['/qa/include'],
    libraries: Object.fromEntries(recipe.BASE_LIBRARIES.map(n => [n, { ...fakePin('/qa/lib/' + n), target }])),
    support: { 'sqlite3.h': fakePin('/qa/headers/sqlite3.h'),
      'official-sqlite-symbols.h': fakePin('/qa/headers/official-sqlite-symbols.h') },
    upstreamTrees: [],
  };
  if (kind === 'android') c.support['allocation_diagnostic.o'] = { ...fakePin('/qa/lib/allocation_diagnostic.o'), target };
  else c.service = { root: '/qa/service', goos: 'linux', goarch: 'arm64', manifest: fakePin('/qa/SERVICE.json') };
  return c;
}
test('actual Android plan records exactly 15 selected C units and one archive', () => {
  const c = config(), p = recipe.makePlan('android', c), recorded = [];
  recipe.runCommands(p, step => { recorded.push(step); return ''; });
  const compile = recorded.filter(s => s.name.startsWith('c-'));
  assert.equal(compile.length, 15);
  assert(!compile.some(s => s.args.some(a => a.endsWith('ynx_native_message_custody_node.c'))));
  const archive = recorded.filter(s => s.name === 'archive-store');
  assert.equal(archive.length, 1);
  const objects = archive[0].args.filter(a => a.endsWith('.o'));
  assert.equal(objects.length, 15); assert.equal(new Set(objects).size, 15);
  assert(recorded.at(-1).args.includes('--offline'));
  assert(recorded.at(-1).args.includes('--locked'));
  assert(recorded.at(-1).args.includes('--no-default-features'));
  assert.equal(recorded.at(-1).args[recorded.at(-1).args.indexOf('--features') + 1],
    'abi5-final-native-link,predevice-cold-v1');
  assert(recorded.at(-1).args.includes('link-arg=-Wl,--no-undefined'));
});
test('administration SQL receives same exact forced SQLite prefix as checked store', () => {
  const p = recipe.makePlan('android', config());
  const prefixed = p.commands.filter(s => s.args.includes('-include')).map(s => s.name);
  assert.deepEqual(prefixed, ['c-veil_checked_store', 'c-veil_producer_unavailable',
    'c-veil_store_custody', 'c-ynx_source_administration_owner']);
  for (const s of p.commands.filter(s => s.args.includes('-include'))) {
    assert.equal(s.args[s.args.indexOf('-include') + 1], '/qa/new-output/dependencies/official-sqlite-symbols.h');
  }
});
test('Android full closure includes TLS ssl and crypto once, no second SQLite engine', () => {
  const args = recipe.makePlan('android', config()).commands.at(-1).args;
  assert.equal(args.filter(s => s.endsWith('/libssl.a')).length, 1);
  assert.equal(args.filter(s => s.endsWith('/libcrypto.a')).length, 1);
  assert.equal(args.filter(s => s.endsWith('/libveil_predevice_sqlite3500400.a')).length, 1);
  assert(!args.includes('-lsqlite3'));
});
test('Linux entry produces actual Linux Rust and CGO command plan without running either', () => {
  const c = config('linux'), p = host.makePlan(c), recorded = [];
  const flags = recipe.runCommands(p, s => {
    recorded.push(s); return s.name === 'rust-static' ? 'note: native-static-libs: -lgcc_s -lutil -lrt -lpthread -lm -ldl -lc\n' : '';
  });
  assert.equal(recorded.length, 17);
  assert.equal(p.target.rust, 'aarch64-unknown-linux-gnu');
  assert(recorded.at(-1).args.includes('staticlib'));
  const step = recipe.goLinkStep(c, p, '/qa/new-output/libynx_native_operation.a', flags);
  assert.equal(step.env.GOOS, 'linux'); assert.equal(step.env.GOARCH, 'arm64');
  assert(step.env.CGO_LDFLAGS.includes('-L/qa/new-output'));
  assert(step.env.CGO_LDFLAGS.includes('libssl.a'));
  assert(step.env.CGO_LDFLAGS.includes('--no-undefined'));
  assert.equal(step.env.GOPROXY, 'off'); assert.equal(step.env.GOFLAGS, '-mod=readonly');
});
test('Linux x64 selection must match Go amd64; Darwin cannot be relabeled', () => {
  const c = config('linux'); c.target = 'x86_64-unknown-linux-gnu'; c.service.goarch = 'amd64';
  for (const pin of Object.values(c.libraries)) pin.target = c.target;
  assert.equal(host.makePlan(c).target.goarch, 'amd64');
  c.service.goarch = 'arm64'; assert.throws(() => host.makePlan(c), /Go\/native target mismatch/);
  c.target = 'aarch64-apple-darwin'; assert.throws(() => host.makePlan(c), /Actual Linux target/);
});
test('R11 changed pin guards reject wrong manifests and the misplaced Cargo.lock', () => {
  let c = config(); c.nativeManifest.sha256 = '1'.repeat(64);
  assert.throws(() => recipe.makePlan('android', c), /Exact R11/);
  c = config(); c.cargoLock.path = '/qa/source/Cargo.lock';
  assert.throws(() => recipe.makePlan('android', c), /native\/Cargo.lock/);
  c = config(); c.closureManifest.sha256 = '2'.repeat(64);
  assert.throws(() => recipe.makePlan('android', c), /Exact R11/);
});
test('missing ssl, foreign architecture, support overrides and object reuse are rejected', () => {
  let c = config(); delete c.libraries['libssl.a'];
  assert.throws(() => recipe.makePlan('android', c), /Unexpected dependency/);
  c = config(); c.libraries['libssl.a'].target = 'aarch64-apple-darwin';
  assert.throws(() => recipe.makePlan('android', c), /foreign target/);
  c = config(); c.support['libssl.a'] = fakePin('/qa/evil/libssl.a');
  assert.throws(() => recipe.makePlan('android', c), /Unexpected support/);
  c = config(); c.reuseObjects = true;
  assert.throws(() => recipe.makePlan('android', c), /reuse is forbidden/);
});
test('output cannot be inside source or overwrite an existing carrier', () => {
  let c = config(); c.outputRoot = '/qa/source/build';
  assert.throws(() => recipe.makePlan('android', c), /must not modify source/);
  c = config();
  const io = { existsSync: () => true, readFileSync: () => { throw Error('Unexpected read'); } };
  assert.throws(() => recipe.verifyInputs('android', c, io), /Output exists/);
});
test('file verification rejects tampering and symlinked pinned binaries', () => {
  const bytes = Buffer.from('public fixture');
  const p = { path: '/qa/input', bytes: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex') };
  const io = { lstatSync: () => ({ isFile: () => true, isSymbolicLink: () => false }),
    readFileSync: () => bytes };
  assert.deepEqual(recipe.exactFile(p, io), bytes);
  assert.throws(() => recipe.exactFile({ ...p, sha256: '0'.repeat(64) }, io), /Changed input/);
  assert.throws(() => recipe.exactFile(p, { ...io, lstatSync: () => ({ isFile: () => false, isSymbolicLink: () => true }) }), /regular file/);
});
test('source verifier rejects a new unlisted build.rs as well as changed tracked bytes', () => {
  const bytes = Buffer.from('public source fixture'), entry = { path: 'a.rs', type: 'file', mode: '0o644',
    bytes: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
    gitBlob: crypto.createHash('sha1').update(Buffer.from('blob ' + bytes.length + '\0')).update(bytes).digest('hex') };
  const io = { lstatSync: () => ({ isFile: () => true, isSymbolicLink: () => false, isDirectory: () => false, mode: 0o644 }),
    readFileSync: () => bytes, readdirSync: () => ['a.rs'] };
  recipe.verifyTree('/qa/tree', [entry], io);
  assert.throws(() => recipe.verifyTree('/qa/tree', [entry], { ...io, readdirSync: () => ['a.rs','build.rs'] }), /Unlisted source leaf/);
  assert.throws(() => recipe.verifyTree('/qa/tree', [entry], { ...io, readFileSync: () => Buffer.from('changed') }), /Source bytes changed/);
});
test('source path traversal and duplicates are rejected', () => {
  assert.throws(() => recipe.verifyTree('/qa/tree', [{ path: '../escape' }], {}), /Unsafe relative/);
});
test('environment cannot inherit old Cargo wrappers, flags or target directory', () => {
  const c = config(), p = recipe.makePlan('android', c);
  const env = recipe.buildEnvironment(c, p, { HOME: '/qa/home', RUSTFLAGS: '-lunsafe',
    RUSTC_WRAPPER: '/qa/old-wrapper', CARGO_TARGET_DIR: '/qa/old', TOKEN: 'not-for-build' });
  assert.equal(env.HOME, '/qa/home'); assert.equal(env.RUSTFLAGS, undefined);
  assert.equal(env.RUSTC_WRAPPER, undefined); assert.equal(env.TOKEN, undefined);
  assert.equal(env.CARGO_TARGET_DIR, '/qa/new-output/target');
  assert.equal(env.CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER, '/qa/bin/cc');
  assert.equal(env.CARGO_BUILD_JOBS, '1');
});
test('unexpected Rust link flags are rejected instead of executing embedded commands', () => {
  const p = host.makePlan(config('linux'));
  assert.throws(() => recipe.runCommands(p, s => s.name === 'rust-static' ?
    'note: native-static-libs: -lc; touch /bad' : ''), /Unexpected native-static-libs/);
});

test('R11 accepts the exact current source, tree and closure for Android and Linux plans', () => {
  assert.equal(recipe.SOURCE_SHA, '86a7fc7f417cad43c5f03d8c62c4e064e33326f53fbdf6868fd8a796672ccbfa');
  assert.equal(recipe.TREE_SHA, '98e73af5c9f6d30322197fbe1844f9c345342a5817e34ff798fd25d0c2cfdf8d');
  assert.equal(recipe.CLOSURE_SHA, '2366c9dd8d6651308f3e1d0c68e9af9c98fd5f75c1a2d1fedf2fbebcef7cf949');
  assert.equal(recipe.LOCK_SHA, '8701f492195b503bac8c6413cc537b6aad3a7a6a0ae8732447bbb5e5aeafe7c2');
  for (const kind of ['android', 'linux']) {
    const c = config(kind);
    const plan = kind === 'android' ? recipe.makePlan(kind, c) : host.makePlan(c);
    const recorded = [];
    recipe.runCommands(plan, step => {
      recorded.push(step);
      return step.name === 'rust-static' ? 'note: native-static-libs: -lc\n' : '';
    });
    assert.equal(recorded.filter(step => step.name.startsWith('c-')).length, 15);
    assert.equal(recorded.length, 17);
    assert.equal(plan.target.rust, c.target);
  }
});
test('R11 rejects the exact previous M1, R8 and R9 source and closure on both targets', () => {
  for (const kind of ['android', 'linux']) {
    for (const [field, previous] of [
      ['nativeManifest', '153836e3041d3a94dd7620173f294c082c27493614f09677010c1f18637ddb70'],
      ['closureManifest', '4aba3e2790bfc2daf05f9c6087081c45351f4413c89822a924c86bb50c993985'],
      ['nativeManifest', 'aa8ba6eccfc0a266efc3c5f1ff89f0772300a8a13f6212eb38902aa0582249c0'],
      ['closureManifest', 'cb5efdd91f385a1004f782fef903aa60ee5b9b7a7ce5a113d271cf217c954725'],
      ['nativeManifest', '970b43ca3f5d86cbfc28321685540741b297a3e10a06562703736b1df3a8f7c8'],
      ['closureManifest', '46aadbea83e111d83c8dfcef5b7b1cedf5672a5d8d86f41257c8b3d6da6318b6'],
    ]) {
      const c = config(kind);
      c[field].sha256 = previous;
      assert.throws(() => kind === 'android' ? recipe.makePlan(kind, c) : host.makePlan(c),
        /Exact R11 source\/closure pins required/);
    }
  }
});

test('R11 exact entry vector accepts absent whole but rejects missing leaves, paths and digests', () => {
  const bytes = fs.readFileSync(path.join(__dirname, '../inputs/NATIVE_SOURCE_MANIFEST.json'));
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), recipe.SOURCE_SHA);
  const manifest = JSON.parse(bytes);
  recipe.verifySourceManifest(manifest);
  recipe.verifySourceManifest({ ...manifest, whole: 152 });
  for (const whole of [null, 151, 153]) {
    assert.throws(() => recipe.verifySourceManifest({ ...manifest, whole }), /Wrong whole/);
  }
  assert.throws(() => recipe.verifySourceManifest({ ...manifest, entries: manifest.entries.slice(1) }), /Wrong whole/);
  for (const mutation of [
    { path: 'wrong-path.rs' },
    { sha256: '0'.repeat(64) },
    { mode: '0o600' },
  ]) {
    const entries = structuredClone(manifest.entries);
    Object.assign(entries[0], mutation);
    assert.throws(() => recipe.verifySourceManifest({ ...manifest, entries }), /entry vector changed/);
  }
});
test('R11 hashed symlinks preserve target, mode and pathset checks without a literal field', () => {
  const literal = '/qa/pinned-upstream', bytes = Buffer.from(literal);
  const entry = { path: 'link', type: 'symlink', mode: '0o755', bytes: bytes.length,
    sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
    gitBlob: crypto.createHash('sha1').update(Buffer.from('blob ' + bytes.length + '\0')).update(bytes).digest('hex') };
  const io = {
    lstatSync: () => ({ isFile: () => false, isSymbolicLink: () => true, isDirectory: () => false, mode: 0o755 }),
    readlinkSync: () => literal, readdirSync: () => ['link'],
  };
  assert.equal(recipe.verifyTree('/qa/tree', [entry], io).get('link'), literal);
  assert.throws(() => recipe.verifyTree('/qa/tree', [entry], { ...io, readlinkSync: () => '/qa/changed' }), /Source bytes changed/);
  assert.throws(() => recipe.verifyTree('/qa/tree', [{ ...entry, literal: '/qa/changed' }], io), /Source symlink changed/);
  assert.throws(() => recipe.verifyTree('/qa/tree', [{ ...entry, mode: '0o777' }], io), /Source mode changed/);
  assert.throws(() => recipe.verifyTree('/qa/tree', [entry, entry], io), /Duplicate source entry/);
  assert.throws(() => recipe.verifyTree('/qa/tree', [entry], { ...io, readdirSync: () => ['link', 'extra'] }), /Unlisted source leaf/);
});
