'use strict';
// The inherited host recipe produced Darwin only. This entry now requires an
// explicit Linux Rust/Go target and matching pinned native dependencies.
// It never treats a macOS archive or an old source carrier as Linux output.
const recipe = require('./build-matching-android-native.cjs');
if (require.main === module) {
  try { recipe.main('linux'); } catch (error) { console.error(error.message); process.exitCode = 1; }
}
module.exports = { makePlan: config => recipe.makePlan('linux', config),
  verifyInputs: config => recipe.verifyInputs('linux', config) };
