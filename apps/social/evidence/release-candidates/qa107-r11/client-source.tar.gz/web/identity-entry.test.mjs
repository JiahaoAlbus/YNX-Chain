import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createIdentityEntry,readSharedIdentity,identityEntryText} from './identity-entry.mjs';

const origin='https://social.ynxweb4.com';
const href='/sso/start?target=conversations';
const reply=(status,type='basic')=>({status,type,ok:status>=200&&status<300});
const deferred=()=>{let resolve;const promise=new Promise(done=>{resolve=done});return {promise,resolve}};
function harness(fetcher,options={}){
  const states=[],navigations=[];
  const entry=createIdentityEntry({origin,href,fetcher,navigate:url=>navigations.push(url),onState:state=>states.push(state),...options});
  return {entry,states,navigations};
}
test('HTTP 404 is visible and a retry performs a fresh probe before original navigation',async()=>{
  const requests=[];
  const {entry,navigations}=harness(async(url,options)=>{requests.push({url,options});return reply(requests.length===1?404:200)});
  await entry.start();assert.equal(entry.state.phase,'failed');assert.match(entry.state.message,/HTTP 404.*routing has not been checked/);assert.deepEqual(navigations,[]);
  await entry.start();assert.deepEqual(navigations,[origin+href]);assert.equal(entry.state.phase,'navigating');assert.equal(requests.length,2);
  for(const {url,options} of requests){assert.equal(url,'/social/health');assert.equal(options.method,'GET');assert.equal(options.redirect,'error');assert.equal(options.credentials,'omit');assert.equal(options.cache,'no-store')}
});
test('HTTP denial and server failure retain exact status and never navigate',async()=>{
  for(const status of [401,403,429,500,503]){const {entry,navigations}=harness(async()=>reply(status));await entry.start();assert.match(entry.state.message,new RegExp('HTTP '+status));assert.deepEqual(navigations,[])}
});
test('network failure is actionable and does not grant identity',async()=>{
  const {entry,navigations}=harness(async()=>{throw Error('sensitive transport diagnostic')});await entry.start();assert.match(entry.state.message,/could not be completed.*Retry/);assert.doesNotMatch(entry.state.message,/sensitive/);assert.deepEqual(navigations,[]);
});
test('diagnostics never fetch Start; one browser navigation initiates SSO and repeated pending clicks cannot double-start',async()=>{
  const requests=[];const {entry,navigations}=harness(async(url,options)=>{requests.push({url,method:options.method});assert.equal(url,'/social/health');return reply(200)});
  await entry.start();await entry.start();assert.deepEqual(requests,[{url:'/social/health',method:'GET'}]);assert.deepEqual(navigations,[origin+href]);assert.equal(entry.state.phase,'navigating');assert.match(entry.state.message,/routing was not verified/);
  for(const response of [reply(302),reply(405),reply(501)]){const blocked=harness(async()=>response);await blocked.entry.start();assert.equal(blocked.entry.state.phase,'failed');assert.deepEqual(blocked.navigations,[])}
});
test('cancel aborts pending work and ignores late replies; retry remains available',async()=>{
  const first=deferred();let signal,calls=0;
  const {entry,navigations}=harness(async(_url,options)=>{signal=options.signal;return ++calls===1?first.promise:reply(200)});
  const work=entry.start();entry.cancel();assert.equal(signal.aborted,true);first.resolve(reply(200));await work;assert.equal(entry.state.phase,'cancelled');assert.deepEqual(navigations,[]);await entry.start();assert.deepEqual(navigations,[origin+href]);
});
test('a new attempt supersedes an older reply without duplicate navigation',async()=>{
  const first=deferred();let calls=0;
  const {entry,navigations}=harness(async()=>++calls===1?first.promise:reply(404));const old=entry.start();await entry.start();first.resolve(reply(200));await old;assert.match(entry.state.message,/404/);assert.deepEqual(navigations,[]);
});
test('timeout aborts even an uncooperative fetch and late replies cannot navigate',async()=>{
  const pending=deferred();let signal;const {entry,navigations}=harness(async(_url,options)=>{signal=options.signal;return pending.promise},{timeoutMs:5});const work=entry.start();await new Promise(done=>setTimeout(done,20));assert.match(entry.state.message,/timed out/);assert.equal(signal.aborted,true);pending.resolve(reply(200));await work;assert.deepEqual(navigations,[]);
});
test('entry URL cannot escape the original origin, target or callback path',()=>{
  for(const route of ['https://attacker.invalid/sso/start?target=conversations','/sso/callback?target=conversations','/sso/start?target=https://attacker.invalid','/sso/start?target=conversations&callback=https://attacker.invalid','/sso/start?target=conversations#other','https://user:pass@social.ynxweb4.com/sso/start?target=conversations'])assert.throws(()=>harness(async()=>reply(200),{href:route}),{code:'SSO_ROUTE'});
});
test('account checks expose actual HTTP failure and preserve redirect refusal',async()=>{
  for(const status of [404,401,403,503]){
    await assert.rejects(readSharedIdentity(async(url,options)=>{assert.equal(url,'/sso/account');assert.equal(options.redirect,'error');assert.equal(options.credentials,'same-origin');return reply(status)}),error=>error.code==='SSO_HTTP'&&error.status===status&&error.message.includes('HTTP '+status));
  }
  await assert.rejects(readSharedIdentity(async()=>{throw Error('network')}),{code:'SSO_NETWORK'});
});
test('invalid, unsigned and malformed account responses remain locked',async()=>{
  for(const body of [null,{}, {signedIn:false}, {signedIn:'true',account:'untrusted',csrfToken:'untrusted'}, {signedIn:true,account:'',csrfToken:''}])await assert.rejects(readSharedIdentity(async()=>({...reply(200),json:async()=>body})),{code:'SSO_UNVERIFIED'});
  await assert.rejects(readSharedIdentity(async()=>({...reply(200),json:async()=>{throw Error('bad JSON')}})),{code:'SSO_RESPONSE'});
});
test('returning from sign-in uses account verification; 404 or cancellation cannot become identity',async()=>{
  const requests=[];const {entry,navigations}=harness(async(url)=>{requests.push(url);return reply(404)});
  await entry.recover();assert.deepEqual(requests,['/sso/account']);assert.match(entry.state.message,/account route.*404/);assert.equal(entry.state.phase,'failed');assert.deepEqual(navigations,[]);
  const pending=deferred();const cancelled=harness(async()=>pending.promise);const work=cancelled.entry.recover();cancelled.entry.cancel();pending.resolve({...reply(200),json:async()=>({signedIn:false})});await work;assert.equal(cancelled.entry.state.phase,'cancelled');
});

test('owned bilingual errors preserve HTTP status, error codes and arbitrary content',async()=>{
  for(const status of [401,403,404,429,500,503]){
    await assert.rejects(readSharedIdentity(async()=>reply(status),{lang:'zh-CN'}),error=>error.status===status&&error.code==='SSO_HTTP'&&error.message.includes('HTTP '+status)&&/[\u4e00-\u9fff]/.test(error.message));
    const {entry}=harness(async()=>reply(status));await entry.start();const chinese=identityEntryText(entry.state.message,'zh-CN');assert.match(chinese,/[\u4e00-\u9fff]/);assert.equal(identityEntryText(chinese,'en'),entry.state.message);
  }
  for(const raw of ['Private account: 原始内容','server response: Retry sign-in','opaque-csrf-token','unrecognized server error'])assert.equal(identityEntryText(raw,'zh-CN'),raw);
  let lang='en';const pending=deferred();const work=readSharedIdentity(()=>pending.promise,{lang:()=>lang});lang='zh-CN';pending.resolve(reply(404));await assert.rejects(work,error=>error.message.startsWith('身份账户接口不可用'));
  const {entry}=harness(async()=>{throw Error('server body')});await entry.start();assert.match(identityEntryText(entry.state.message,'zh-CN'),/无法完成 Social 服务检查/);entry.cancel();assert.match(identityEntryText(entry.state.message,'zh-CN'),/已取消/);
  assert.equal(identityEntryText('Identity service returned an invalid response. Retry sign-in.','zh-CN'),'身份服务返回了无效响应。请重试登录。');
  assert.equal(identityEntryText('No verified shared identity. Sign in with YNX identity and retry.','zh-CN'),'尚未验证共享身份。请使用 YNX 身份登录后重试。');
});

test('actual bundled private-session UI: bilingual live error/cancel/recovery, cleanup and native navigation',async()=>{
  const root=fileURLToPath(new URL('.',import.meta.url));
  const evidence=fileURLToPath(new URL('../evidence/identity-entry-integration-20261004/',import.meta.url));
  await mkdir(evidence,{recursive:true});
  const require=createRequire(new URL('../package.json',import.meta.url));
  const {build}=require('esbuild'),{chromium}=require('playwright');
  await build({absWorkingDir:root,entryPoints:['private-session-ui.js'],outfile:path.join(evidence,'private-session-ui.js'),bundle:true,platform:'browser',format:'esm',target:'es2022',define:{'process.env.NODE_ENV':'"production"'}});
  const browser=await chromium.launch({headless:true});
  const requests=[],errors=[],checks=[];let mode='404',accountGate=null;
  try{
    const context=await browser.newContext();
    await context.route('**/*',async route=>{
      const request=route.request(),url=new URL(request.url());requests.push({method:request.method(),path:url.pathname});
      if(url.origin!==origin)return route.abort();
      if(url.pathname==='/sso/start'){
        assert.equal(request.method(),'GET','no HEAD preflight of stateful Start');assert.equal(request.resourceType(),'document','Start is only reached by document navigation');
        return route.fulfill({status:404,body:'SSO route unavailable'});
      }
      if(url.pathname==='/social/health'){
        if(mode==='network')return route.abort('failed');
        if(mode==='pending'){await new Promise(done=>setTimeout(done,150));return route.fulfill({status:404,body:''}).catch(()=>{})}
        return route.fulfill({status:mode==='navigate'?200:404,body:'Social service check'});
      }
      if(url.pathname==='/sso/account'){if(accountGate)await accountGate.promise;return route.fulfill({status:404,contentType:'application/json',body:'{}'})}
      if(url.pathname.startsWith('/v2/')||url.pathname.startsWith('/matrix/'))return route.fulfill({status:401,contentType:'application/json',body:'{}'});
      const name=url.pathname==='/'?'index.html':url.pathname.slice(1);if(name.includes('..'))return route.abort();
      try{const body=await readFile(path.join(name==='private-session-ui.js'?evidence:root,name));return route.fulfill({contentType:({'.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.html':'text/html'})[path.extname(name)]??'application/octet-stream',body})}catch{return route.abort()}
    });
    const page=await context.newPage();page.setDefaultTimeout(5000);page.on('pageerror',error=>errors.push(error.message));
    await page.goto(origin+'/#people-panel');
    const entry=page.locator('[data-identity-entry]'),link=page.getByRole('link',{name:'Sign in with YNX identity',exact:true});
    await entry.waitFor({state:'attached'}).catch(error=>{throw new Error(error.message+'; page errors: '+JSON.stringify(errors))});
    assert.equal(await entry.isVisible(),false);assert.equal(requests.some(item=>item.path.startsWith('/sso/')||item.path==='/social/health'),false,'guest entry performs no diagnostic');
    await link.click();await page.waitForFunction(()=>document.querySelector('[data-identity-entry]').textContent.includes('HTTP 404'));
    assert.equal(new URL(page.url()).pathname,'/');assert.equal(await page.locator('#workspace-content').isVisible(),false);assert.equal(requests.filter(item=>item.path==='/sso/start').length,0);checks.push('service-health HTTP 404 is explicit and does not claim to have tested SSO routing or initiate SSO');
    await page.screenshot({path:path.join(evidence,'http-404.png'),fullPage:true});
    await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(evidence,'http-404-mobile.png'),fullPage:true});
    const switchLanguage=async(locale,phrase)=>{await page.selectOption('#social-locale',locale);await page.waitForFunction(({locale,phrase})=>document.documentElement.lang===locale&&document.querySelector('[data-identity-entry]').textContent.includes(phrase),{locale,phrase})};
    const beforeSwitch=requests.filter(item=>item.path.startsWith('/sso/')||item.path==='/social/health').length;
    await switchLanguage('zh-CN','Social 服务检查不可用（HTTP 404）');assert.equal(await entry.getByRole('button',{name:'重试登录',exact:true}).count(),1);assert.equal(await entry.getByRole('link',{name:'在浏览器中打开登录',exact:true}).count(),1);assert.match(await page.locator('#workspace-status').textContent(),/Social 服务检查不可用/);await page.screenshot({path:path.join(evidence,'http-404-mobile-zh.png'),fullPage:true});
    assert.equal(requests.filter(item=>item.path.startsWith('/sso/')||item.path==='/social/health').length,beforeSwitch,'language changes do not request identity or health');checks.push('live HTTP error and buttons follow existing language selector without network requests');
    mode='network';await entry.getByRole('button',{name:'重试登录',exact:true}).click();await page.waitForFunction(()=>document.querySelector('[data-identity-entry]').textContent.includes('无法完成 Social 服务检查'));await switchLanguage('en','could not be completed');checks.push('network failure live-switches Chinese to English');
    mode='pending';await entry.getByRole('button',{name:'Retry sign-in',exact:true}).click();await switchLanguage('zh-CN','正在检查 Social 服务是否可达');await entry.getByRole('button',{name:'取消登录检查',exact:true}).click();await page.waitForFunction(()=>document.querySelector('[data-identity-entry]').textContent.includes('登录检查已取消'));await switchLanguage('en','cancelled');await page.waitForTimeout(200);assert.match(await entry.textContent(),/cancelled/);assert.equal(requests.filter(item=>item.path==='/sso/start').length,0);checks.push('cancelled diagnostics never fetch Start and ignore delayed health failure');
    mode='404';await entry.getByRole('button',{name:'Retry sign-in',exact:true}).click();await page.waitForFunction(()=>document.querySelector('[data-identity-entry]').textContent.includes('HTTP 404'));
    await page.locator('#social-workspace .permission-details summary').click();await page.locator('#chat-authorize').click();await page.waitForFunction(()=>document.querySelector('#workspace-status').textContent.includes('Identity account route is unavailable (HTTP 404)'));await switchLanguage('zh-CN','Social 服务检查不可用');assert.match(await page.locator('#workspace-status').textContent(),/身份账户接口不可用（HTTP 404）/);await switchLanguage('en','Social service check unavailable');assert.match(await page.locator('#workspace-status').textContent(),/Identity account route is unavailable/);assert.equal(await page.locator('#workspace-content').isVisible(),false);checks.push('actual authorize account error live-switches separately from retained entry error');
    // A plain fallback anchor still makes an ordinary document GET.
    await entry.getByRole('link',{name:'Open sign-in in browser'}).click();await page.waitForURL(origin+href);assert.equal(requests.filter(item=>item.path==='/sso/start').length,1);checks.push('fallback initiates exactly one normal document GET of Start');
    mode='navigate';await page.goto(origin+'/#people-panel');await entry.waitFor({state:'attached'});const startsBefore=requests.filter(item=>item.path==='/sso/start').length;await link.click();await page.waitForURL(origin+href);assert.equal(requests.filter(item=>item.path==='/sso/start').length,startsBefore+1);checks.push('successful read-only health check initiates exactly one document GET of Start; no SSO fetch or HEAD');
    accountGate=deferred();await page.goBack();await entry.waitFor({state:'attached'});await page.waitForFunction(()=>document.querySelector('[data-identity-entry]').textContent.includes('Checking shared identity after returning'));
    await switchLanguage('zh-CN','正在检查登录返回后的共享身份');await switchLanguage('en','Checking shared identity after returning');accountGate.resolve();accountGate=null;
    await page.waitForFunction(()=>document.querySelector('[data-identity-entry]').textContent.includes('Identity account route is unavailable (HTTP 404)'));await switchLanguage('zh-CN','身份账户接口不可用（HTTP 404）');await switchLanguage('en','Identity account route is unavailable');assert.equal(await page.locator('#workspace-content').isVisible(),false);checks.push('pending recovery and resulting account error live-switch both directions while workspace stays locked');
    const cleanup=await page.evaluate(async()=>{
      const {mountIdentityEntry}=await import('/identity-entry.mjs');
      const root=document.createElement('section'),status=document.createElement('p');root.innerHTML='<a href="/sso/start?target=conversations">Fixture sign-in</a>';root.append(status);document.body.append(root);
      const listeners=new Map();let disconnected=0,signal,release,calls=0;
      const environment={location:window.location,sessionStorage:window.sessionStorage,MutationObserver:class extends MutationObserver{disconnect(){disconnected++;super.disconnect()}},addEventListener:(name,handler)=>{listeners.set(name,handler);window.addEventListener(name,handler)},removeEventListener:(name,handler)=>{if(listeners.get(name)===handler)listeners.delete(name);window.removeEventListener(name,handler)}};
      const language=value=>{const select=document.querySelector('#social-locale');select.value=value;select.dispatchEvent(new Event('change',{bubbles:true}))};language('zh-CN');
      const fixture=mountIdentityEntry({root,status,environment,fetcher:async(_url,options)=>{calls++;signal=options.signal;return new Promise(done=>{release=done})},navigate:()=>{throw Error('unexpected navigation')}});
      const initiallyChinese=root.querySelector('button').textContent==='重试登录';
      const work=fixture.start();await new Promise(done=>setTimeout(done,0));const note=root.querySelector('[role=status]'),controls=[...root.querySelectorAll('button')];
      const followsLang=note.textContent.includes('正在检查 Social 服务是否可达')&&controls[1].textContent==='取消登录检查';
      status.textContent='Private account: 原始内容 / server response';language('en');await new Promise(done=>setTimeout(done,0));const preservesContent=status.textContent==='Private account: 原始内容 / server response';
      const retainedText=controls[1].textContent;fixture.destroy();fixture.destroy();language('zh-CN');await new Promise(done=>setTimeout(done,0));release({ok:true,status:200,type:'basic'});await work;await fixture.start();root.querySelector('a').addEventListener('click',event=>event.preventDefault(),{once:true});root.querySelector('a').dispatchEvent(new MouseEvent('click',{button:0,cancelable:true}));
      const result={initiallyChinese,followsLang,preservesContent,aborted:signal.aborted,disconnectedOnce:disconnected===1,listenersRemoved:listeners.size===0,boxRemoved:!root.querySelector('[data-identity-entry]'),noLateRender:controls[1].textContent===retainedText,noRestart:calls===1};root.remove();language('en');return result;
    });
    for(const [name,passed] of Object.entries(cleanup))assert.equal(passed,true,name);checks.push('explicit teardown disconnects locale observer, removes listeners, aborts pending work and preserves private/server content');
    assert.deepEqual(errors,[]);assert.equal(requests.some(item=>item.method!=='GET'),false,'no HEAD, account/sign/transaction or business mutation');
    assert.equal(requests.some(item=>item.path.startsWith('/v2/')),false,'no private-session authorization');
    await writeFile(path.join(evidence,'browser-results.json'),JSON.stringify({controlledRoutes:true,actualHTMLAndBundledPrivateSessionUI:true,syntheticSuccessfulIdentity:false,publicAcceptance:false,checks,cleanup,errors,requests},null,2));
  }finally{await browser.close()}
});
