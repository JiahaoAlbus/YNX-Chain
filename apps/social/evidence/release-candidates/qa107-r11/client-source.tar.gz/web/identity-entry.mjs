const copy=new Map([
  ['Retry sign-in','重试登录'],
  ['Cancel sign-in entry','取消登录检查'],
  ['Open sign-in in browser','在浏览器中打开登录'],
  ['Identity service could not be reached. Check your connection and retry.','无法连接身份服务。请检查网络后重试。'],
  ['Identity account route is unavailable (HTTP 404). The server route must be restored before sign-in can be confirmed.','身份账户接口不可用（HTTP 404）。服务端恢复接口后才能确认登录。'],
  ['Identity service returned an invalid response. Retry sign-in.','身份服务返回了无效响应。请重试登录。'],
  ['No verified shared identity. Sign in with YNX identity and retry.','尚未验证共享身份。请使用 YNX 身份登录后重试。'],
  ['Unexpected identity entry route.','身份登录入口地址不符合要求。'],
  ['Local sign-in check cancelled. This does not cancel a sign-in already opened in your browser. Retry when you are ready.','本地登录检查已取消。这不会取消浏览器中已打开的登录流程。准备好后可重试。'],
  ['Checking shared identity after returning from sign-in...','正在检查登录返回后的共享身份……'],
  ['Checking Social service reachability. This does not verify sign-in routing...','正在检查 Social 服务是否可达。这不会验证登录路由……'],
  ['Identity service timed out. Retry or open the original sign-in link in your browser.','身份服务响应超时。请重试，或在浏览器中打开原登录链接。'],
  ['Social service check timed out. Sign-in routing has not been checked. Retry or open sign-in in your browser.','Social 服务检查超时。登录路由尚未检查。请重试，或在浏览器中打开登录。'],
  ['Shared identity was confirmed by the server. Review Social permissions separately.','服务器已确认共享身份。请另行检查 Social 权限。'],
  ['Social service responded. Opening YNX identity sign-in; sign-in routing was not verified by this check.','Social 服务已响应。正在打开 YNX 身份登录；本次检查未验证登录路由。'],
  ['Social service check could not be completed. Sign-in routing has not been checked. Retry or open sign-in in your browser.','无法完成 Social 服务检查。登录路由尚未检查。请重试，或在浏览器中打开登录。'],
  ['Identity service could not be reached. Check your connection and retry, or open the original sign-in link in your browser.','无法连接身份服务。请检查网络后重试，或在浏览器中打开原登录链接。'],
]);
const reverseCopy=new Map([...copy].map(([en,zh])=>[zh,en]));
// Only owned UI copy is translated. Response bodies, accounts and tokens are
// never passed to this renderer; HTTP status is the only dynamic substitution.
export function identityEntryText(value,lang='en'){
  const chinese=/^zh(?:-|$)/i.test(lang),canonical=reverseCopy.get(value)??value;
  if(copy.has(canonical))return chinese?copy.get(canonical):canonical;
  let match=/^Identity could not be confirmed \(HTTP (\d{3})\)\. Sign in or retry when the service is available\.$/.exec(value)??/^无法确认身份（HTTP (\d{3})）。请登录，或在服务恢复后重试。$/.exec(value);
  if(match)return chinese?`无法确认身份（HTTP ${match[1]}）。请登录，或在服务恢复后重试。`:`Identity could not be confirmed (HTTP ${match[1]}). Sign in or retry when the service is available.`;
  match=/^Social service check unavailable \(HTTP (\d{3})\)\. Sign-in routing has not been checked\. Retry or open sign-in in your browser\.$/.exec(value)??/^Social 服务检查不可用（HTTP (\d{3})）。登录路由尚未检查。请重试，或在浏览器中打开登录。$/.exec(value);
  if(match)return chinese?`Social 服务检查不可用（HTTP ${match[1]}）。登录路由尚未检查。请重试，或在浏览器中打开登录。`:`Social service check unavailable (HTTP ${match[1]}). Sign-in routing has not been checked. Retry or open sign-in in your browser.`;
  return value;
}

export class IdentityEntryError extends Error {
  constructor(message,code,status){super(message);this.name='IdentityEntryError';this.code=code;if(status)this.status=status}
}

export async function readSharedIdentity(fetcher=globalThis.fetch,{signal,lang='en'}={}){
  const failure=(message,code,status)=>new IdentityEntryError(identityEntryText(message,typeof lang==='function'?lang():lang),code,status);
  let response;
  try{response=await fetcher('/sso/account',{credentials:'same-origin',cache:'no-store',redirect:'error',signal})}
  catch(error){if(signal?.aborted)throw error;throw failure('Identity service could not be reached. Check your connection and retry.','SSO_NETWORK')}
  if(!response.ok)throw failure(response.status===404?'Identity account route is unavailable (HTTP 404). The server route must be restored before sign-in can be confirmed.':`Identity could not be confirmed (HTTP ${response.status}). Sign in or retry when the service is available.`,'SSO_HTTP',response.status);
  let result;try{result=await response.json()}catch{throw failure('Identity service returned an invalid response. Retry sign-in.','SSO_RESPONSE')}
  if(result?.signedIn!==true||typeof result.account!=='string'||!result.account.trim()||typeof result.csrfToken!=='string'||!result.csrfToken.trim())throw failure('No verified shared identity. Sign in with YNX identity and retry.','SSO_UNVERIFIED');
  return result;
}

// Start handles HEAD like GET and can set pending state. Never fetch Start for
// diagnostics. Existing GET /social/health only reports service reachability;
// the original document navigation owns the actual SSO state and callbacks.
export function createIdentityEntry({href,origin,fetcher=globalThis.fetch,navigate,onState=()=>{},timeoutMs=10000}){
  const url=new URL(href,origin);
  if(url.origin!==new URL(origin).origin||url.pathname!=='/sso/start'||url.search!=='?target=conversations'||url.hash||url.username||url.password)throw new IdentityEntryError('Unexpected identity entry route.','SSO_ROUTE');
  let attempt=0,controller=null,timer=null,disposed=false,state={phase:'idle',message:''};
  const publish=(phase,message)=>{state={phase,message};onState(state)};
  const stop=()=>{clearTimeout(timer);timer=null;controller?.abort();controller=null};
  const cancel=()=>{if(disposed)return;attempt++;stop();publish('cancelled','Local sign-in check cancelled. This does not cancel a sign-in already opened in your browser. Retry when you are ready.')};
  async function run(recovery=false){
    if(disposed||(!recovery&&state.phase==='navigating'))return;
    const id=++attempt;stop();const active=controller=new AbortController();
    publish('checking',recovery?'Checking shared identity after returning from sign-in...':'Checking Social service reachability. This does not verify sign-in routing...');
    timer=setTimeout(()=>{if(id!==attempt)return;attempt++;stop();publish('failed',recovery?'Identity service timed out. Retry or open the original sign-in link in your browser.':'Social service check timed out. Sign-in routing has not been checked. Retry or open sign-in in your browser.')},timeoutMs);
    try{
      if(recovery){await readSharedIdentity(fetcher,{signal:active.signal});if(id===attempt)publish('verified','Shared identity was confirmed by the server. Review Social permissions separately.');return}
      const response=await fetcher('/social/health',{method:'GET',credentials:'omit',cache:'no-store',redirect:'error',signal:active.signal});
      if(id!==attempt)return;
      if(!response.ok)throw new IdentityEntryError(`Social service check unavailable (HTTP ${response.status}). Sign-in routing has not been checked. Retry or open sign-in in your browser.`,'SOCIAL_HEALTH_HTTP',response.status);
      stop();publish('navigating','Social service responded. Opening YNX identity sign-in; sign-in routing was not verified by this check.');navigate(url.href);
    }catch(error){if(id===attempt)publish('failed',error instanceof IdentityEntryError?error.message:recovery?'Identity service could not be reached. Check your connection and retry, or open the original sign-in link in your browser.':'Social service check could not be completed. Sign-in routing has not been checked. Retry or open sign-in in your browser.')}
    finally{if(id===attempt)stop()}
  }
  return {start:()=>run(),recover:()=>run(true),cancel,destroy:()=>{disposed=true;attempt++;stop()},get state(){return state}};
}

export function mountIdentityEntry({root,status,environment=globalThis,fetcher=environment.fetch.bind(environment),navigate=url=>environment.location.assign(url),timeoutMs}){
  const link=root.querySelector('a[href="/sso/start?target=conversations"]');
  if(!link)return null;
  const pendingKey='ynx.social.web.identity-entry.pending.v1';
  const pending=value=>{try{if(value)environment.sessionStorage.setItem(pendingKey,'yes');else environment.sessionStorage.removeItem(pendingKey)}catch{ /* Navigation works even when storage is blocked. */ }};
  let returned=false;try{returned=environment.sessionStorage.getItem(pendingKey)==='yes'}catch{}
  const doc=root.ownerDocument,box=doc.createElement('section'),note=doc.createElement('p'),retry=doc.createElement('button'),cancel=doc.createElement('button'),native=doc.createElement('a');
  box.hidden=true;box.dataset.identityEntry='';note.setAttribute('role','status');note.setAttribute('aria-live','polite');retry.type=cancel.type='button';native.href=link.getAttribute('href');box.append(note,retry,cancel,native);link.after(box);
  let view={phase:'idle',message:''};
  const setText=(element,text)=>{if(element.textContent!==text)element.textContent=text};
  const localize=()=>{
    const lang=doc.documentElement.lang;
    setText(retry,identityEntryText('Retry sign-in',lang));setText(cancel,identityEntryText('Cancel sign-in entry',lang));setText(native,identityEntryText('Open sign-in in browser',lang));
    setText(note,identityEntryText(view.message,lang));
    // Another workspace action may own this status now. Translate only known
    // identity copy, without replacing that action's text with stale entry state.
    const next=identityEntryText(status.textContent,lang);if(next!==status.textContent)status.textContent=next;
  };
  const entry=createIdentityEntry({href:link.getAttribute('href'),origin:environment.location.origin,fetcher,navigate,timeoutMs,onState:view=>{
    pending(view.phase==='navigating');
    render(view);
  }});
  function render(next){view=next;box.hidden=false;status.textContent=view.message;cancel.hidden=view.phase!=='checking';retry.hidden=view.phase==='checking'||view.phase==='navigating';native.hidden=view.phase==='checking'||view.phase==='verified';link.setAttribute('aria-busy',String(view.phase==='checking'));localize()}
  const click=event=>{if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||link.hasAttribute('download')||(link.target&&link.target!=='_self'))return;event.preventDefault();void entry.start()};
  const retryClick=()=>void entry.start(),cancelClick=()=>entry.cancel();
  link.addEventListener('click',click);retry.addEventListener('click',retryClick);cancel.addEventListener('click',cancelClick);
  // The fallback is a normal anchor, retaining native navigation and gestures.
  const nativeClick=event=>{entry.cancel();if(event.button===0&&!event.metaKey&&!event.ctrlKey&&!event.shiftKey&&!event.altKey)pending(true)};
  const pageshow=event=>{if(event.persisted&&entry.state.phase==='navigating')void entry.recover()},focus=()=>{if(entry.state.phase==='navigating')void entry.recover()};
  native.addEventListener('click',nativeClick);environment.addEventListener('pageshow',pageshow);environment.addEventListener('focus',focus);
  const observer=new environment.MutationObserver(localize);observer.observe(doc.documentElement,{attributes:true,attributeFilter:['lang']});localize();
  const dispose=entry.destroy;let destroyed=false;
  entry.destroy=()=>{if(destroyed)return;destroyed=true;dispose();observer.disconnect();link.removeEventListener('click',click);retry.removeEventListener('click',retryClick);cancel.removeEventListener('click',cancelClick);native.removeEventListener('click',nativeClick);environment.removeEventListener('pageshow',pageshow);environment.removeEventListener('focus',focus);environment.removeEventListener('pagehide',pagehide);link.removeAttribute('aria-busy');box.remove()};
  const pagehide=event=>{if(!event.persisted)entry.destroy()};environment.addEventListener('pagehide',pagehide);
  if(returned)void entry.recover();
  return entry;
}
