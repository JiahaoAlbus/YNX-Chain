import {createSocialPrivateSession,SOCIAL_CHAT_SCOPES} from './private-session.js';
import {SocialWorkspace,browserChatDevices} from './chat-workspace.ts';
import {SocialAPI} from '../src/api.ts';
import {DurableOutbox} from '../src/durableOutbox.ts';
import {reviewContact} from './contact-review.mjs';
import {scanContactQR} from './contact-camera.mjs';
import {discoveryEntry} from './discovery-entry.mjs';
import {ContactRetry} from './contact-retry.mjs';
import {reviewContactAction} from './contact-action.mjs';
import {createProfileShare} from './profile-share.mjs';
import {indexedDBInvitationIntents} from '../src/invitationIntent.ts';
import {mountIdentityEntry,readSharedIdentity} from './identity-entry.mjs';

const privateSession=createSocialPrivateSession();
const chatSession=createSocialPrivateSession({scopes:SOCIAL_CHAT_SCOPES});
const byId=id=>document.getElementById(id);
const status=byId('private-auth-status'),account=byId('private-auth-account'),openWallet=byId('private-auth-open');
const buttons=['private-auth-begin','private-auth-restore','private-auth-disconnect'].map(byId);
const chatOpen=byId('chat-open-wallet'),workspaceStatus=byId('workspace-status');
const intentKey='ynx.social.request.intent.v2';
let contactRetry,workspaceWorkCount=0;
const outbox=new DurableOutbox({read:slot=>localStorage.getItem(`ynx.social.web.outbox.v2.${slot}`),write:(slot,value)=>localStorage.setItem(`ynx.social.web.outbox.v2.${slot}`,value),remove:slot=>localStorage.removeItem(`ynx.social.web.outbox.v2.${slot}`)});
const identity=()=>readSharedIdentity(globalThis.fetch,{lang:()=>document.documentElement.lang});
mountIdentityEntry({root:byId('social-workspace'),status:workspaceStatus});
const profileShare=createProfileShare(byId('profile-share-panel'));
const workspace=new SocialWorkspace(chatSession,new SocialAPI(location.origin),browserChatDevices(),outbox,identity,view=>{
  workspaceStatus.textContent=view.status;
  if(!view.account)document.dispatchEvent(new CustomEvent('ynx-social-private-locked'));
  synchronizeContactRetry();
  if(view.account)localStorage.setItem('ynx.social.web.workspace.approved.v2','yes');
  byId('workspace-content').hidden=!view.account;
  byId('workspace-account').textContent=view.account?`Private account: ${view.account}`:'';
  const profile=byId('profile-form');
  for(const key of ['handle','displayName','bio'])profile.elements.namedItem(key).value=view.profile?.[key]??'';
  void profileShare.show(view.profile,()=>workspace.current.account===view.account&&workspace.current.profile?.id===view.profile?.id);
  const privacy=byId('privacy-form');privacy.querySelector('fieldset').disabled=!view.settings;
  for(const key of ['discoverableByHandle','contactsMatching','allowRecommendations'])privacy.elements.namedItem(key).checked=view.settings?.[key]??false;privacy.elements.namedItem('allowRequestsFrom').value=view.settings?.allowRequestsFrom??'everyone';
  byId('create-invite').textContent=view.invitationPending?'Retry my original invitation':'Create or retry my invitation';
  const invitations=byId('invitation-list');invitations.replaceChildren();
  for(const record of view.invitations??[]){const item=document.createElement('li'),text=document.createElement('p'),link=document.createElement('input');text.textContent=`${record.status} · Expires ${record.expiresAt}`;link.readOnly=true;link.value=record.link;link.setAttribute('aria-label','Your original invitation link');item.append(text,link);if(record.status==='active'){const revoke=document.createElement('button');revoke.type='button';revoke.textContent='Revoke invitation';revoke.onclick=()=>void work(async()=>{const guard=workspace.contactContextGuard();if(!await reviewInvitation(record,guard))return;await workspace.revokeInvitation(record.id)});item.append(revoke)}invitations.append(item)}
  byId('contact-request-form').querySelector('button').disabled=!view.profile;
  const contacts=byId('contact-list');contacts.replaceChildren();
  for(const person of view.contacts??[]){const li=document.createElement('li'),button=document.createElement('button');li.append(document.createTextNode(`${person.displayName} @${person.handle} `));button.type='button';button.textContent='Message';button.addEventListener('click',()=>{const chat=byId('matrix-social-workspace');chat.scrollIntoView({behavior:'smooth',block:'start'});document.dispatchEvent(new CustomEvent('ynx-social-open-contact',{detail:{account:view.account,personId:person.id}}));chat.querySelector('[data-connect]').focus()});li.append(button);
   const options=document.createElement('details'),summary=document.createElement('summary');summary.textContent='Contact controls';options.append(summary);
   for(const [action,label] of [['remove','Remove contact'],['block','Block person'],['mute','Mute notifications'],['unmute','Unmute notifications']]){const control=document.createElement('button');control.type='button';control.textContent=label;control.addEventListener('click',()=>void work(async()=>{const current=workspace.contactContextGuard();if(!await reviewContactAction(document,person,action,()=>current()&&workspace.current.contacts?.some(item=>item.id===person.id)))return;await workspace.changeContact(person.id,action);if(action==='remove'||action==='block')document.dispatchEvent(new CustomEvent('ynx-social-contact-removed',{detail:{account:view.account,personId:person.id}}))}));options.append(control)}
   li.append(options);contacts.append(li)}
  const requests=byId('contact-request-list');requests.replaceChildren();
  for(const request of view.requests??[]){const li=document.createElement('li');li.append(document.createTextNode(`${request.direction==='incoming'?'From':'To'} @${request.person.handle}: ${request.status} `));if(request.message){const note=document.createElement('p');note.textContent=request.message;li.append(note)}if(request.status==='pending'){for(const action of request.direction==='incoming'?['accept','reject']:['withdraw']){const button=document.createElement('button');button.type='button';button.textContent=action[0].toUpperCase()+action.slice(1);button.addEventListener('click',()=>void work(()=>workspace.transitionContact(request.id,action)));li.append(button)}}requests.append(li)}
  const conversations=byId('conversation-list');conversations.replaceChildren();
  for(const item of view.conversations??[]){const li=document.createElement('li'),button=document.createElement('button');button.type='button';button.textContent=item.title||item.handle||'Conversation';button.addEventListener('click',()=>void work(()=>workspace.select(item.id)));li.append(button);conversations.append(li)}
  const messages=byId('message-list');messages.replaceChildren();
  for(const item of view.messages??[]){const li=document.createElement('li');li.textContent=`${item.record.sender===view.account?'You':'Participant'}: ${item.plaintext}`;messages.append(li)}
  byId('conversation-title').textContent=view.conversationId?'Encrypted conversation':'Choose a conversation';
},undefined,indexedDBInvitationIntents());
const retryBox=document.createElement('section'),retryNote=document.createElement('p'),retryButton=document.createElement('button'),reviewAgain=document.createElement('button');retryBox.hidden=true;retryBox.setAttribute('aria-live','polite');retryButton.type='button';retryButton.textContent='Retry exact request';reviewAgain.type='button';reviewAgain.textContent='Review another request';retryBox.append(retryNote,retryButton,reviewAgain);byId('contact-request-form').append(retryBox);
contactRetry=new ContactRetry(workspace,synchronizeContactRetry);
function synchronizeContactRetry(){if(!contactRetry)return;const intent=contactRetry.current;retryBox.hidden=!intent;byId('contact-request-form').querySelector('button[type="submit"]').textContent=intent?'Retry reviewed request':'Preview person';if(!intent)return;retryNote.textContent=`Request outcome not confirmed: ${intent.preview.person.displayName} @${intent.preview.person.handle}. Original message: ${intent.message||'(no message)'}. Retry keeps the same target and request identity; editing does not undo an already sent request.`;retryButton.disabled=workspaceWorkCount>0||contactRetry.running===intent;reviewAgain.disabled=workspaceWorkCount>0}
async function sendReviewedContact(preview,message){contactRetry.retain(preview,message);await contactRetry.attempt()}
retryButton.addEventListener('click',()=>void work(()=>contactRetry.attempt()));reviewAgain.addEventListener('click',()=>{contactRetry.reviewAgain();workspaceStatus.textContent='Review a new request. The original request may already have reached the person.'});
byId('contact-request-form').addEventListener('input',event=>{if(event.target.name==='handle'||event.target.name==='source')contactRetry.reviewAgain()});byId('contact-request-form').addEventListener('change',event=>{if(event.target.name==='source')contactRetry.reviewAgain()});
function showRoute(anchor,result){anchor.hidden=true;anchor.removeAttribute('href');if(result.route?.status==='ready'){const url=new URL(result.route.url);if(url.protocol!=='ynxwallet:'||url.hostname!=='authorize')throw new Error('Unexpected Wallet launch route');anchor.href=url.href;anchor.hidden=false}}
function render(result){showRoute(openWallet,result);account.textContent=result.status==='connected'?`Signed in: ${result.session.account}`:'Sign in to keep your private workspace together.';status.textContent=result.status==='connected'?'You are signed in. Allow Social contacts and chat separately when you are ready.':result.message||`Private session: ${result.status}`}
async function perform(action){for(const button of buttons)button.disabled=true;try{render(await action())}catch(error){account.textContent='Private identity could not be confirmed.';showRoute(openWallet,{});status.textContent=error.message||'Private identity needs Retry. Standard wallet connection is unchanged.'}finally{for(const button of buttons)button.disabled=false}}
async function work(action){const originalContext=workspace.current.account?workspace.contactContextGuard():null;workspaceWorkCount++;const controls=[...byId('social-workspace').querySelectorAll('button')];for(const button of controls)button.disabled=true;try{return await action()}catch(error){if(originalContext&&!originalContext())return;if(error.status===401||error.status===403)workspace.lock('Private permission is no longer verified; existing keys and ciphertext retained.');if(error.code==='CHAT_DEVICE_PROTECTION_REQUIRED')byId('protect-chat-device').hidden=false;workspaceStatus.textContent=error.message||'Private operation unavailable; existing ciphertext retained.'}finally{workspaceWorkCount--;for(const button of controls)button.disabled=workspaceWorkCount>0;byId('contact-request-form').querySelector('button').disabled=workspaceWorkCount>0||!workspace.current.profile;synchronizeContactRetry()}}
buttons[0].addEventListener('click',()=>void perform(async()=>{const result=await privateSession.begin();localStorage.setItem(intentKey,'identity');return result}));
buttons[1].addEventListener('click',()=>void perform(()=>privateSession.restore()));
buttons[2].addEventListener('click',()=>void perform(()=>privateSession.disconnect()));
byId('chat-authorize').addEventListener('click',()=>void work(async()=>{await identity();const result=await workspace.authorize();if(result.status==='connected'){await workspace.restore();return;}localStorage.setItem(intentKey,'chat');showRoute(chatOpen,result);workspaceStatus.textContent=result.message||'Approve the exact profile, contacts and chat scopes in Wallet when ready. Nothing opens automatically.'}));
byId('chat-restore').addEventListener('click',()=>void work(()=>workspace.restore()));
byId('chat-logout').addEventListener('click',()=>void work(async()=>{workspace.lock('Signed out locally. Revocation is pending.');showRoute(chatOpen,{});const shared=await identity().catch(()=>null);const revoked=await Promise.allSettled([workspace.logout(),privateSession.disconnect()]);if(revoked[1].status==='fulfilled')render(revoked[1].value);if(shared){const response=await fetch('/sso/logout',{method:'POST',credentials:'same-origin',redirect:'error',cache:'no-store',headers:{'X-YNX-SSO-CSRF':shared.csrfToken}});if(!response.ok)throw new Error('Shared identity revocation is pending. Private access remains locked.')}if(revoked.some(result=>result.status==='rejected')||revoked[1].value?.status!=='disconnected')throw new Error('Wallet revocation is pending. Keys and ciphertext were retained.');workspace.lock(shared?'Private workspace and shared identity signed out. Keys and pending ciphertext retained.':'Social permission revoked; shared identity sign-out could not be confirmed. Private access remains locked.')}));
byId('workspace-refresh').addEventListener('click',()=>void work(()=>workspace.refresh()));
byId('protect-chat-device').addEventListener('click',()=>{const confirmed=confirm('Protect this browser\'s existing Social chat device? The exact old keys are encrypted and read back before its old cleartext carrier is removed. Messages and pending ciphertext are preserved. No key import or administrator credential is required.');if(confirmed)void work(async()=>{await workspace.protectExistingDevice(true);byId('protect-chat-device').hidden=true})});
byId('contact-request-form').addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget,data=new FormData(form),source=String(data.get('source')||'handle'),value=String(data.get('handle'));void work(async()=>{if(contactRetry.current){await contactRetry.attempt();form.reset();return}const preview=await workspace.previewContact(source,value);let message='';const approved=await reviewContact(document,preview,()=>workspace.isContactPreviewCurrent(preview),value=>{message=value});if(!approved){workspace.cancelContactPreview(preview);return}await sendReviewedContact(preview,message);form.reset()})});
byId('contact-scan-qr').addEventListener('click',()=>void work(async()=>{contactRetry.reviewAgain();const isCurrent=workspace.contactContextGuard(),value=await scanContactQR(document,globalThis,isCurrent);if(!value||!isCurrent())return;const entry=discoveryEntry(value),preview=await workspace.previewContact(entry.source,entry.value);let message='';const approved=await reviewContact(document,preview,()=>workspace.isContactPreviewCurrent(preview),value=>{message=value});if(approved)await sendReviewedContact(preview,message);else workspace.cancelContactPreview(preview)}));
byId('profile-form').addEventListener('submit',event=>{event.preventDefault();const data=new FormData(event.currentTarget);void work(()=>workspace.updateProfile({handle:String(data.get('handle')),displayName:String(data.get('displayName')),bio:String(data.get('bio'))}))});
byId('load-privacy').addEventListener('click',()=>void work(()=>workspace.loadPrivacy()));
byId('privacy-form').addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;void work(()=>workspace.savePrivacy({discoverableByHandle:form.elements.namedItem('discoverableByHandle').checked,contactsMatching:form.elements.namedItem('contactsMatching').checked,allowRecommendations:form.elements.namedItem('allowRecommendations').checked,allowRequestsFrom:form.elements.namedItem('allowRequestsFrom').value}))});
byId('load-invites').addEventListener('click',()=>void work(()=>workspace.loadInvitations()));
byId('create-invite').addEventListener('click',()=>void work(()=>workspace.createInvitation()));
function reviewInvitation(record,guard){
 if(!guard())return Promise.resolve(false);
 return new Promise(resolve=>{const dialog=document.createElement('dialog');dialog.className='contact-review';const heading=document.createElement('h2'),note=document.createElement('p'),cancel=document.createElement('button'),approve=document.createElement('button');heading.textContent='Revoke this invitation?';note.textContent='New profile discovery through this link will stop after the server confirms revocation. Existing contacts, following relationships and encrypted history are retained.';cancel.type=approve.type='button';cancel.textContent='Cancel';approve.textContent='Revoke this invitation';let done=false;const finish=result=>{if(done)return;done=true;document.removeEventListener('ynx-social-private-locked',locked);dialog.close();dialog.remove();resolve(result&&guard()&&workspace.current.invitations?.some(item=>item.id===record.id&&item.status==='active'))};const locked=()=>finish(false);document.addEventListener('ynx-social-private-locked',locked);cancel.onclick=()=>finish(false);approve.onclick=()=>finish(true);dialog.addEventListener('cancel',event=>{event.preventDefault();finish(false)});dialog.addEventListener('close',()=>finish(false));dialog.append(heading,note,cancel,approve);document.body.append(dialog);dialog.showModal();cancel.focus()});
}
byId('conversation-form').addEventListener('submit',event=>{event.preventDefault();const data=new FormData(event.currentTarget);void work(()=>workspace.createConversation(String(data.get('handle'))))});
byId('message-form').addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget,text=String(new FormData(form).get('message'));void work(async()=>{await workspace.send(text);form.reset()})});
byId('message-retry').addEventListener('click',()=>void work(()=>workspace.retry()));
// Only existing approved storage can restore; no guest key/request/approval creation.
if(location.pathname==='/wallet-auth/callback'){
  if(localStorage.getItem(intentKey)==='chat')void work(async()=>{await workspace.accept(location.href);history.replaceState(null,'','/#conversations');localStorage.removeItem(intentKey)});
  else void perform(async()=>{const result=await privateSession.handleReturn(location.href);history.replaceState(null,'','/wallet-auth/callback');localStorage.removeItem(intentKey);return result});
}else if(localStorage.getItem('ynx.social.web.workspace.approved.v2')==='yes')void work(()=>workspace.restore());
byId('workspace-content').addEventListener('focusin',()=>{if(workspace.current.account)localStorage.setItem('ynx.social.web.workspace.approved.v2','yes')});
addEventListener('storage',event=>{if(event.key==='ynx.social.web.workspace.signedout.v2')workspace.lock('Another tab signed out; reconnect explicitly')});
byId('chat-logout').addEventListener('click',()=>{localStorage.removeItem('ynx.social.web.workspace.approved.v2');localStorage.setItem('ynx.social.web.workspace.signedout.v2',String(Date.now()))});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')workspace.lock('Private workspace hidden; restore retained permission when you return');else if(localStorage.getItem('ynx.social.web.workspace.approved.v2')==='yes')void work(()=>workspace.restore())});
