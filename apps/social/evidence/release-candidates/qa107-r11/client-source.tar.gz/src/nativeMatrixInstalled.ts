import type { NativeMatrixConsumer, MatrixBinding, MatrixPeer } from './nativeMatrix';

/** Retired entry; no old protocol, native restoration or alternate fallback. */
export function installedMatrixConsumer(_current: () => Promise<MatrixBinding>,
  _acceptedPeer: (personId: string) => Promise<MatrixPeer>): NativeMatrixConsumer {
  throw new Error('YNX_SOCIAL_LEGACY_CORE_RETIRED');
}
