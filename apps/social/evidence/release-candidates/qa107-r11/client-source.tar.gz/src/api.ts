import type { ProductSessionChallenge, WalletApproval, WalletAuthorizationRequest, WalletLogin } from "./walletAuth";
import type { ChatDevice, ChatMessage, DeviceRotationRequest, SendMessageRequest } from "./chatCrypto";
import type { SessionProof } from "./scopedSessionBridge";
export type Person = Readonly<{ id:string; handle:string; displayName:string; avatarUrl?:string }>;
export type ContactRequest = Readonly<{ id:string; person:Person; direction:"incoming"|"outgoing"; status:string; source:string; expiresAt?:string; message?:string }>;
export type ContactMatch = Readonly<{token:string;person:Person}>;
export type Conversation = Readonly<{ id:string; title:string; handle?:string; unread:number; lastMessage:string; e2ee:"verified"|"rotating"|"recovery-required"; updatedAt:string }>;
export type ConversationDetail = Conversation & Readonly<{members:readonly Person[]}>;
export type MediaObject = Readonly<{id:string;mimeType:string;sizeBytes:number;sha256:string;purpose:"moment"|"message";encrypted:boolean;createdAt:string}>;
export type FeedPost = Readonly<{ id:string; author:Person; text:string; media:readonly MediaObject[]; visibility:"public"|"contacts"|"private"; reactions:number; comments:number;viewerReaction?:"like"|"love"|"insight"|"support";status:string; createdAt:string }>;
export type MomentComment = Readonly<{id:string;author:Person;text:string;createdAt:string}>;
export type SocialReport = Readonly<{id:string;status:string;outcome:string;explanation:string;evidenceHashes:readonly string[];appeal?:string;updatedAt:string}>;
export type AlertItem = Readonly<{ id:string; kind:string; actor:Person; summary:string; readAt?:string; createdAt:string }>;
export type AIJob = Readonly<{id:string;status:"awaiting_permission"|"streaming"|"cancelled"|"provider_failed"|"review"|"applied"|"rejected"|"appealed";output?:string;provider:string;model:string;outputLanguage:string;estimatedCostUsd:number;actualCostUsd?:number;actualTokens?:number}>;
export type Session = Readonly<{ token:string; authMode?:"product-session-v2"; session:Readonly<{id:string;account:string;deviceId:string;scopes:readonly string[];createdAt:string;expiresAt:string}>; profile?:Person }>;
export type SocialProfile = Person & Readonly<{bio:string;followerCount:number;followingCount:number;postCount:number;privacy:Readonly<{discoverableByHandle:boolean;contactsMatching:boolean;allowRecommendations:boolean;allowRequestsFrom:string;avatarUrl?:string;profileQrPayload?:string}>}>;
export type PrivacySettings = SocialProfile["privacy"] & Readonly<{account?:string;updatedAt?:string}>;
export type Invitation = Readonly<{id:string;link:string;status:"active"|"expired"|"revoked";expiresAt:string;createdAt:string;revokedAt?:string}>;
export type InvitationSnapshot = Readonly<{invitations:Invitation[];operation?:Readonly<{confirmed:boolean;id?:string}>}>;
export type GroupDiscoveryInput = Readonly<{ idempotencyKey: string; source: "handle" | "contacts" | "qr" | "invite" | "recommendation"; value: string }>;
export type GroupMembershipUpdateInput = Readonly<{ idempotencyKey: string; add: readonly GroupDiscoveryInput[]; remove: readonly string[] }>;
export type DeviceRotationResponse = Readonly<{record:{id:string};replayed:boolean;session:Session["session"];token:string}>;
export function adoptRotatedSession(previous:Session,result:DeviceRotationResponse):Session{return {...previous,token:result.token,session:result.session}}
export class SocialAPIError extends Error{constructor(message:string,readonly status:number){super(message)}}

export class SocialAPI {
  readonly base:string; private token:string|null;
  private productProof:((scopes:readonly string[])=>Promise<SessionProof>)|null=null;
  private productAccount:string|null=null;
  private csrf:string|undefined;
  private epoch=0;
  onPrivateInvalidated?:()=>void;
  constructor(base=process.env.EXPO_PUBLIC_YNX_SOCIAL_API_BASE ?? "https://api.ynxweb4.com",token:string|null=null){if(!/^https:\/\//.test(base)&&!/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(base))throw new Error("Set a secure YNX Social API endpoint");this.base=base.replace(/\/$/,"");this.token=token}
  get authorizationGeneration(){return this.epoch}
  get currentProductAccount(){return this.productAccount}
  authorizationGuard(){const epoch=this.epoch;return()=>epoch===this.epoch}
  setToken(value:string|null){const hadPrivateProof=this.productProof!==null;this.epoch++;this.productProof=null;this.productAccount=null;this.token=value;if(hadPrivateProof)this.onPrivateInvalidated?.()}
  useSession(value:Session){if(value.authMode!=="product-session-v2")this.setToken(value.token)}
  useProductSession(proof:(scopes:readonly string[])=>Promise<SessionProof>,account:string,csrf?:string){this.epoch++;this.token=null;this.productProof=proof;this.productAccount=account;this.csrf=csrf}
  bindDevice(body:unknown,proof:SessionProof){return this.request<{session:Session["session"];authMode:"product-session-v2"}>("/social/v2/session/bind",{method:"POST",body,proof})}
  walletChallenge(request:WalletAuthorizationRequest,approval:WalletApproval){return this.request<{challenge:ProductSessionChallenge}>("/social/v1/wallet/challenge",{method:"POST",body:{request,approval},auth:false})}
  login(input:WalletLogin){return this.request<Session>("/social/v1/wallet/login",{method:"POST",body:input,auth:false})}
  profile(){return this.request<{record:SocialProfile}>("/social/v1/profile")}
  async profileOrSetup(){try{const record=(await this.profile()).record;if(!record)throw new Error("Invalid Social profile response");return !record.handle&&!record.displayName?null:record}catch(error){if(error instanceof SocialAPIError&&error.status===404)return null;throw error}}
  updateProfile(body:{idempotencyKey:string;handle:string;displayName:string;bio:string;avatarUrl?:string}){return this.request<{record:SocialProfile;replayed:boolean}>("/social/v1/profile",{method:"PUT",body})}
  settings(signal?:AbortSignal){return this.request<{record:PrivacySettings}>("/social/v1/settings",{signal})}
  updateSettings(body:{idempotencyKey:string;discoverableByHandle:boolean;contactsMatching:boolean;allowRecommendations:boolean;allowRequestsFrom:"everyone"|"contacts"|"nobody";avatarUrl?:string},signal?:AbortSignal){return this.request<{record:PrivacySettings;replayed:boolean}>("/social/v1/settings",{method:"PUT",body,signal})}
  invitations(intent?:string,signal?:AbortSignal){return this.request<InvitationSnapshot>("/social/v1/invites"+(intent?'?intent='+encodeURIComponent(intent):''),{signal})}
  createInvite(ttlSeconds=86400,idempotencyKey?:string,signal?:AbortSignal){return this.request<{record:{id:string;link:string;expiresAt:string};token:string}>("/social/v1/invites",{method:"POST",body:{ttlSeconds,idempotencyKey},signal})}
  revokeInvite(id:string,signal?:AbortSignal){return this.request<{record:{id:string;link:string;expiresAt:string;revokedAt:string}}>(`/social/v1/invites/${encodeURIComponent(id)}/revoke`,{method:"POST",body:{},signal})}
  contacts(){return this.request<{contacts:Person[];requests:ContactRequest[]}>("/social/v1/contacts")}
  contactMatches(hashes:readonly string[]){return this.request<{matches:ContactMatch[]}>("/social/v1/contact-matches",{method:"POST",body:{hashes}})}
  previewContact(source:GroupDiscoveryInput["source"],value:string,signal?:AbortSignal){return this.request<{person:Person}>("/social/v1/contacts/preview",{method:"POST",body:{source,value},signal})}
  requestContact(source:"handle"|"contacts"|"qr"|"invite"|"recommendation",value:string,idempotencyKey:string,expectedAccount?:string,message="",signal?:AbortSignal){return this.request("/social/v1/contact-requests",{method:"POST",body:{source,value,idempotencyKey,expectedAccount,message:message||undefined},signal})}
  transitionRequest(id:string,action:"accept"|"reject"|"withdraw"){return this.request(`/social/v1/contact-requests/${encodeURIComponent(id)}`,{method:"POST",body:{action}})}
  deleteContact(target:string){return this.request("/social/v1/contacts/delete",{method:"POST",body:{target}})}
  block(target:string){return this.request("/social/v1/privacy/block",{method:"POST",body:{target}})}
  mute(target:string,active:boolean){return this.request("/social/v1/privacy/mute",{method:"POST",body:{target,active}})}
  conversations(query=""){return this.request<{conversations:Conversation[]}>(`/social/v1/conversations?q=${encodeURIComponent(query)}`)}
  createConversation(source:"handle"|"contacts"|"qr"|"invite"|"recommendation",value:string,idempotencyKey:string){return this.request<{record:{id:string};replayed:boolean}>("/social/v1/conversations",{method:"POST",body:{source,value,idempotencyKey}})}
  createGroup(title:string,handles:readonly string[],idempotencyKey:string){return this.request<{record:{id:string};replayed:boolean}>("/social/v1/conversations/groups",{method:"POST",body:{title,idempotencyKey,members:handles.map((value,index)=>({source:"handle",value,idempotencyKey:`member-${index}`}))}})}
  updateGroupMembers(id:string,body:GroupMembershipUpdateInput){return this.request<{record:ConversationDetail;replayed:boolean}>(`/social/v1/conversations/${encodeURIComponent(id)}/members`,{method:"POST",body})}
  conversation(id:string){return this.request<{record:ConversationDetail}>(`/social/v1/conversations/${encodeURIComponent(id)}`)}
  conversationDevices(id:string){return this.request<{devices:ChatDevice[]}>(`/social/v1/conversations/${encodeURIComponent(id)}/devices`)}
  messagePage(id:string,after="",limit=100){return this.request<{messages:ChatMessage[];nextCursor?:string;hasMore?:boolean}>(`/social/v1/conversations/${encodeURIComponent(id)}/messages?limit=${limit}&after=${encodeURIComponent(after)}`)}
  async messages(id:string){
    const messages:ChatMessage[]=[];let cursor="";
    const seen=new Set<string>();
    for(let page=0;page<100;page++){
      const result=await this.messagePage(id,cursor);
      for(const item of result.messages){if(!seen.has(item.id)){seen.add(item.id);messages.push(item)}}
      if(!result.hasMore)return {messages};
      if(!result.nextCursor||result.nextCursor===cursor)throw new Error("Message synchronization cursor did not advance");
      cursor=result.nextCursor;
    }
    throw new Error("Message history exceeds this synchronization window");
  }
  sendMessage(id:string,body:SendMessageRequest){return this.request<{record:ChatMessage;replayed:boolean}>(`/social/v1/conversations/${encodeURIComponent(id)}/messages`,{method:"POST",body})}
  acknowledge(id:string,messageId:string,state:"delivered"|"read"){return this.request<{record:ChatMessage}>(`/social/v1/conversations/${encodeURIComponent(id)}/messages/${encodeURIComponent(messageId)}/${state}`,{method:"POST",body:{}})}
  rotateDevice(replacedDeviceId:string,body:DeviceRotationRequest){return this.request<DeviceRotationResponse>(`/social/v1/devices/${encodeURIComponent(replacedDeviceId)}/rotate`,{method:"POST",body})}
  feed(){return this.request<{posts:FeedPost[]}>("/social/v1/feed")}
  publishMoment(body:{idempotencyKey:string;text:string;visibility:"public"|"contacts"|"private";media:readonly string[]}){return this.request("/social/v1/feed",{method:"POST",body})}
  comments(id:string){return this.request<{comments:MomentComment[]}>(`/social/v1/feed/${encodeURIComponent(id)}/comments`)}
  comment(id:string,text:string,idempotencyKey:string){return this.request(`/social/v1/feed/${encodeURIComponent(id)}/comments`,{method:"POST",body:{text,idempotencyKey}})}
  react(id:string,kind:"like"|"love"|"insight"|"support",active:boolean,idempotencyKey:string){return this.request(`/social/v1/feed/${encodeURIComponent(id)}/reaction`,{method:"POST",body:{kind,active,idempotencyKey}})}
  deleteMoment(id:string){return this.request(`/social/v1/feed/${encodeURIComponent(id)}`,{method:"DELETE",headers:{"X-YNX-Confirm-Delete":"DELETE MOMENT"}})}
  follow(handle:string,active:boolean,idempotencyKey:string){return this.request("/social/v1/follows",{method:"POST",body:{source:"handle",value:handle,idempotencyKey,active}})}
  uploadMedia(body:{idempotencyKey:string;purpose:"moment"|"message";conversationId?:string;mimeType:string;sha256:string;data:string}){return this.request<{record:MediaObject;replayed:boolean}>("/social/v1/media",{method:"POST",body})}
  mediaSource(id:string){if(!this.token)throw new Error("Social session is locked");return {uri:`${this.base}/social/v1/media/${encodeURIComponent(id)}`,headers:{Authorization:`Bearer ${this.token}`}}}
  async downloadMedia(id:string){if(!this.token)throw new Error("Social session is locked");const response=await fetch(`${this.base}/social/v1/media/${encodeURIComponent(id)}`,{headers:{Authorization:`Bearer ${this.token}`}});if(!response.ok)throw new Error(`Attachment download failed (${response.status})`);return new Uint8Array(await response.arrayBuffer())}
  report(body:{idempotencyKey:string;targetType:string;targetId:string;category:string;detail:string;evidenceHashes:readonly string[]}){return this.request<{record:SocialReport;replayed:boolean}>("/social/v1/reports",{method:"POST",body})}
  reportDetail(id:string){return this.request<{record:SocialReport}>(`/social/v1/reports/${encodeURIComponent(id)}`)}
  appealReport(id:string,correction:string){return this.request<{record:SocialReport}>(`/social/v1/reports/${encodeURIComponent(id)}/appeal`,{method:"POST",body:{correction}})}
  alerts(){return this.request<{notifications:AlertItem[];unread:number}>("/social/v1/notifications")}
  markRead(id:string){return this.request(`/social/v1/notifications/${encodeURIComponent(id)}/read`,{method:"POST",body:{}})}
  exportData(){return this.request<Record<string,unknown>>("/social/v1/privacy/export")}
  async deleteAccount(onConfirmed?:(current:()=>boolean)=>Promise<void>){
    const current=this.authorizationGuard();
    const result=await this.request("/social/v1/privacy/delete",{method:"DELETE",headers:{"X-YNX-Confirm-Delete":"DELETE MY SOCIAL DATA"}});
    if(!current())throw new Error("Social authorization changed; deletion response discarded");
    if(!result||typeof result!=="object"||Array.isArray(result)||Object.keys(result).length!==1||!("deleted" in result)||result.deleted!==true)throw new Error("Deletion response was not confirmed; original authorization and local data retained");
    try{if(onConfirmed)await onConfirmed(current)}catch(error){if(current())this.setToken(null);throw error}
    if(!current())throw new Error("Social authorization changed; deletion confirmation retained only for original account");
    this.setToken(null);
    return result;
  }
  async deleteAccountReceipt(account:string,onConfirmed?:(current:()=>boolean)=>Promise<void>){
    if(!/^ynx1[0-9a-z]{38}$/.test(account)||this.productProof===null||this.productAccount!==account)throw new Error("Verified current Social account binding is required; legacy local erasure is not confirmed");
    const generation=this.epoch;
    const result=await this.deleteAccount(onConfirmed);
    if(this.epoch!==generation+1)throw new Error("Social authorization changed; deletion cleanup discarded");
    return Object.freeze({account,result,current:this.authorizationGuard()});
  }
  aiBegin(body:Record<string,unknown>){return this.request<{record:AIJob;replayed:boolean}>("/social/v1/ai/jobs",{method:"POST",body})}
  aiTransition(id:string,action:string,output=""){return this.request<AIJob>(`/social/v1/ai/jobs/${encodeURIComponent(id)}`,{method:"POST",body:{action,output}})}
  async streamAI(id:string,contextText:string,onToken:(value:string)=>void,signal?:AbortSignal):Promise<AIJob>{if(!this.token)throw new Error("Social session is locked");const response=await fetch(`${this.base}/social/v1/ai/jobs/${encodeURIComponent(id)}/stream`,{method:"POST",headers:{Accept:"text/event-stream","Content-Type":"application/json",Authorization:`Bearer ${this.token}`},body:JSON.stringify({contextText}),signal});if(!response.ok)throw new Error(`Social AI stream failed (${response.status})`);if(!response.body)throw new Error("Streaming is unavailable on this device");const reader=response.body.getReader(),decoder=new TextDecoder(),lines:{event:string;data:string}[]=[];let buffer="",event="",doneJob:AIJob|undefined;while(true){const chunk=await reader.read();if(chunk.done)break;buffer+=decoder.decode(chunk.value,{stream:true});const parts=buffer.split("\n");buffer=parts.pop()??"";for(const raw of parts){const line=raw.trimEnd();if(line.startsWith("event:")){event=line.slice(6).trim()}else if(line.startsWith("data:")){const data=line.slice(5).trim();lines.push({event,data});if(event==="token"){const value=JSON.parse(data) as {text?:string};if(value.text)onToken(value.text)}else if(event==="error"){const value=JSON.parse(data) as {error?:string};throw new Error(value.error??"AI provider unavailable")}else if(event==="done"){const value=JSON.parse(data) as {record?:AIJob};doneJob=value.record}}}}if(!doneJob)throw new Error("AI stream ended before review state");return doneJob}
  async request<T=unknown>(path:string,options:{method?:string;body?:unknown;auth?:boolean;headers?:Record<string,string>;proof?:SessionProof;signal?:AbortSignal}={}):Promise<T>{
    if(options.signal?.aborted)throw new Error("Original Social operation cancelled; intent retained");
    const epoch=this.epoch,headers:Record<string,string>={Accept:"application/json",...options.headers};
    if(options.body!==undefined)headers["Content-Type"]="application/json";
    if(options.auth!==false){
      if(this.productProof){
        const proofOwner=this.productProof;
        const relative=path.split("?")[0]!.replace("/social/v1/","");
        const scope=relative.startsWith("conversations")||relative.startsWith("devices/")?"social.messaging":/^(contacts?|privacy\/|invites?|notifications?)/.test(relative)?"social.contacts":"social.profile";
        if(/^(feed|media|reports?|follows?|ai\/)/.test(relative))throw new Error("This action requires a separately supported permission");
        const proof=options.proof??await proofOwner([scope]).catch(()=>{if(options.signal?.aborted)throw new Error("Original Social operation cancelled; intent retained");if(epoch===this.epoch&&proofOwner===this.productProof)this.setToken(null);throw new SocialAPIError("Wallet permission could not be verified; restore explicitly",401)});
        if(options.signal?.aborted)throw new Error("Original Social operation cancelled; intent retained");
        if(epoch!==this.epoch||proofOwner!==this.productProof)throw new SocialAPIError("Social authorization changed; old permission discarded",401);
        if(proof.proof.account!==this.productAccount){this.setToken(null);throw new SocialAPIError("Social account changed; reconnect explicitly",401)}
        headers["X-YNX-Product-Session-Proof-V2"]=proof.proofHeader;
        if(this.csrf)headers["X-YNX-SSO-CSRF"]=this.csrf;
      }else{if(!this.token)throw new Error("Social session is locked");headers.Authorization=`Bearer ${this.token}`}
    }
    const response=await fetch(`${this.base}${path}`,{method:options.method??"GET",headers,credentials:this.csrf?"same-origin":"omit",redirect:"error",cache:"no-store",signal:options.signal,body:options.body===undefined?undefined:JSON.stringify(options.body)});
    const data=await response.json().catch(()=>({error:"Invalid server response"}));
    if(options.signal?.aborted)throw new Error("Original Social operation cancelled; intent retained");
    if(epoch!==this.epoch)throw new Error("Social authorization changed; response discarded");
    if(!response.ok){if(this.productProof&&(response.status===401||response.status===403))this.setToken(null);throw new SocialAPIError(typeof data?.error==="string"?data.error:`Social request failed (${response.status})`,response.status)}
    return data as T;
  }
}
