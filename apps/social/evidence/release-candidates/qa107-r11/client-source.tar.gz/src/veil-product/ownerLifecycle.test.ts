import assert from 'node:assert/strict';
import test from 'node:test';
import {decodeOwnerLifecycle,OwnerLifecycleGate} from './ownerLifecycle';
const projection=(state='DRAIN_REQUIRED')=>({ownerState:state,queued:0,pendingTickets:0,reopenedPendingRows:0,pendingStoreState:'READY',failureRetained:true,nativeBoundary:'REQUIRED',localGenesisAttempted:false,localGenesisStatus:null});
const reply=(closeStatus='PENDING_RECONCILIATION_REQUIRED',owner:unknown=projection())=>({closeStatus,nativeBoundary:'REQUIRED',owner});
test('strict decoder refuses synthetic release and contradictory closed owner',()=>{
 for(const raw of [true,36,reply('36'),reply('CLOSED_LOCAL_ONLY'),{...reply(),released:true},{...reply(),nativeBoundary:'AUTHORIZED'}])assert.throws(()=>decodeOwnerLifecycle(raw));
 assert.equal(decodeOwnerLifecycle(reply('CLOSED_LOCAL_ONLY',projection('CLOSED'))).closeStatus,'CLOSED_LOCAL_ONLY');
 let touched=false;assert.throws(()=>decodeOwnerLifecycle({get closeStatus(){touched=true;return 'NOT_SELECTED';},nativeBoundary:'REQUIRED',owner:null}));assert.equal(touched,false);
});
test('remount observations never open or close an owner',async()=>{
 let closes=0,reads=0;const gate=new OwnerLifecycleGate(async()=>({closeLocalOwner:async()=>{closes++;},observeLocalOwnerLifecycle:async()=>{reads++;return reply('NOT_SELECTED',null);}}));
 await gate.observe();const detach=gate.subscribe(()=>{});detach();await gate.observe();assert.equal(reads,2);assert.equal(closes,0);assert.equal(gate.getSnapshot().selected,false);
});
test('deferred close coalesces clicks/remount; drain never means closed',async()=>{
 let finish!:()=>void,closes=0,reads=0;const held=new Promise<void>(r=>{finish=r;});
 const gate=new OwnerLifecycleGate(async()=>({closeLocalOwner:async()=>{closes++;await held;},observeLocalOwnerLifecycle:async()=>{reads++;return reply();}}));
 const first=gate.closeOriginal();assert.equal(gate.closeOriginal(),first);assert.equal(gate.observe(),first);
 await new Promise(r=>setImmediate(r));assert.equal(gate.getSnapshot().pending,true);assert.equal(reads,0);
 finish();await first;assert.equal(closes,1);assert.equal(gate.getSnapshot().result?.closeStatus,'PENDING_RECONCILIATION_REQUIRED');await gate.closeOriginal();assert.equal(closes,1);assert.equal(reads,2);
});
test('close throw observes retained failed receipt with no close replay',async()=>{
 let closes=0;const primary=Error('public-control');const gate=new OwnerLifecycleGate(async()=>({closeLocalOwner:async()=>{closes++;throw primary;},observeLocalOwnerLifecycle:async()=>reply('CLOSE_RECEIPT_FAILED')}));
 await gate.closeOriginal();await gate.closeOriginal();assert.equal(closes,1);assert.equal(gate.getSnapshot().result?.closeStatus,'CLOSE_RECEIPT_FAILED');
});
test('native pending receipt later closed does not change authority boundary',async()=>{
 let status='OBSERVATION_PENDING',closes=0;const gate=new OwnerLifecycleGate(async()=>({closeLocalOwner:async()=>{closes++;throw Error('observation timeout');},observeLocalOwnerLifecycle:async()=>reply(status,projection(status==='CLOSED_LOCAL_ONLY'?'CLOSED':'CLOSING'))}));
 await gate.closeOriginal();assert.equal(gate.getSnapshot().result?.closeStatus,'OBSERVATION_PENDING');status='CLOSED_LOCAL_ONLY';await gate.observe();assert.equal(closes,1);assert.equal(gate.getSnapshot().result?.nativeBoundary,'REQUIRED');
});
test('read failure retains last receipt; fresh process cannot restore release from UI phase',async()=>{
 let fail=false;const module={closeLocalOwner:async()=>{},observeLocalOwnerLifecycle:async()=>{if(fail)throw Error('read');return reply();}};const gate=new OwnerLifecycleGate(async()=>module);
 await gate.closeOriginal();fail=true;await gate.observe();assert.equal(gate.getSnapshot().observationFailed,true);assert.equal(gate.getSnapshot().result?.closeStatus,'PENDING_RECONCILIATION_REQUIRED');const fresh=new OwnerLifecycleGate(async()=>module);assert.equal(fresh.getSnapshot().result,null);assert.equal(fresh.getSnapshot().selected,false);
});
