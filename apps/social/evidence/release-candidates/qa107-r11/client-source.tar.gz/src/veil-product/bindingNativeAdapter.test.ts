import assert from 'node:assert/strict';import test from 'node:test';import {readFileSync} from 'node:fs';
import {NativeBindingAdapter,bindingRequestId,decodeNativeBindingReply,type NativeBindingHttpModule,type NativeBindingReply} from './bindingNativeAdapter';
const token='PUBLIC_NATIVE_ADAPTER_NOT_A_GRANT';const body=JSON.stringify({status:'ACCOUNT_BOUND',subject:'public-subject',generation:0,deviceAuthorization:'REQUIRED'});
const tick=()=>new Promise<void>(r=>setImmediate(r));
function deferred<T>(){let resolve!:(v:T)=>void;const promise=new Promise<T>(r=>{resolve=r;});return {promise,resolve};}
function fixture(){let epoch='1',next=1;const cancelled:string[]=[],sent:{handle:string;epoch:string;token:string}[]=[];let advances=0;const module:NativeBindingHttpModule={readBindingHttpEpoch:async()=>epoch,reserveBindingHttp:async()=>String(next++),sendBindingHttp:async(handle,e,t)=>{sent.push({handle,epoch:e,token:t});return {epoch:e,handle,status:200,body,error:null};},cancelBindingHttp:async h=>{cancelled.push(h);return false;},advanceBindingHttpContext:async()=>{advances++;epoch=String(Number(epoch)+1);return epoch;}};return {module,cancelled,sent,setEpoch:(v:string)=>{epoch=v;},advances:()=>advances};}
test('actual five-export adapter strict tuple/readonly gen0 and non-authorizing metadata',async()=>{
 const f=fixture(),a=new NativeBindingAdapter(async()=>f.module);const result=await a.request(token,100);assert.equal(result.kind,'metadata');if(result.kind==='metadata'){assert.equal(result.metadata.generation,0);assert.equal(result.metadata.deviceAuthorization,'REQUIRED');assert.ok(Object.isFrozen(result.metadata));}assert.deepEqual(f.sent,[{handle:'1',epoch:'1',token}]);
 for(const value of [0,'0','01','-1','1e2','9223372036854775808'])assert.throws(()=>bindingRequestId(value));assert.equal(bindingRequestId('9223372036854775807'),'9223372036854775807');
 assert.throws(()=>decodeNativeBindingReply({epoch:'1',handle:'2',status:200,body,error:null},'1','1'));
 assert.throws(()=>decodeNativeBindingReply({epoch:'1',handle:'1',status:200,body,error:null,grant:true},'1','1'));
});
test('pre-import total deadline retains hung load and no late reservation/send',async()=>{
 const load=deferred<NativeBindingHttpModule|null>();const f=fixture();let loads=0;const a=new NativeBindingAdapter(()=>{loads++;return load.promise;});assert.deepEqual(await a.request(token,2),{kind:'unavailable',reason:'TIMEOUT'});assert.equal((await a.request(token,2)).kind,'unavailable');assert.equal(loads,1);load.resolve(f.module);await tick();assert.equal(f.sent.length,0);
});
test('late reservation is cancelled exact handle after deadline; cancel false is not resource release',async()=>{
 const reserve=deferred<string>(),f=fixture();f.module.reserveBindingHttp=()=>reserve.promise;const a=new NativeBindingAdapter(async()=>f.module);assert.deepEqual(await a.request(token,2),{kind:'unavailable',reason:'TIMEOUT'});assert.equal((await a.request(token,2)).kind,'unavailable');reserve.resolve('12');await tick();assert.deepEqual(f.cancelled,['12']);assert.equal(f.sent.length,0);
});
test('advance actual barrier fences delayed send response, stale tuple/epoch and late result',async()=>{
 const send=deferred<NativeBindingReply>(),f=fixture();f.module.sendBindingHttp=(h,e,t)=>{f.sent.push({handle:h,epoch:e,token:t});return send.promise;};const a=new NativeBindingAdapter(async()=>f.module);const pending=a.request(token,100);await tick();assert.equal(f.sent.length,1);await a.advanceContext();assert.equal(f.advances(),1);send.resolve({epoch:'1',handle:'1',status:200,body,error:null});assert.equal((await pending).kind,'unavailable');assert.deepEqual(f.cancelled,['1']);
});
test('external current epoch change after awaited send rejects metadata without generation mapping',async()=>{
 const f=fixture();f.module.sendBindingHttp=async(h,e)=>{f.setEpoch('2');return {epoch:e,handle:h,status:200,body,error:null};};const a=new NativeBindingAdapter(async()=>f.module);assert.equal((await a.request(token,100)).kind,'unavailable');assert.deepEqual(f.cancelled,['1']);
});
test('new request waits actual advance barrier, not a synthetic epoch value',async()=>{
 const barrier=deferred<string>(),f=fixture();f.module.advanceBindingHttpContext=()=>barrier.promise;const a=new NativeBindingAdapter(async()=>f.module);const advanced=a.advanceContext(),pending=a.request(token,100);await tick();assert.equal(f.sent.length,0);f.setEpoch('2');barrier.resolve('2');await advanced;assert.equal((await pending).kind,'metadata');const sent=f.sent[0];assert.ok(sent,'expected one actual send after barrier');assert.equal(sent.epoch,'2');
});
for(const mode of ['error','status','duplicate-json','wrong-tuple','bad-epoch','send-reject','cancel-reject'] as const)test(`native ${mode} is refusal, cancellation cannot change primary or revoke anything`,async()=>{
 const f=fixture();f.module.sendBindingHttp=async(h,e)=>{if(mode==='send-reject')throw Error('PUBLIC_GUARD_REFUSAL');return {epoch:mode==='bad-epoch'?'01':e,handle:mode==='wrong-tuple'?'22':h,status:mode==='status'?403:200,body:mode==='error'?null:mode==='duplicate-json'?body.replace('"generation":0','"generation":0,"generation":1'):mode==='cancel-reject'?'{}':body,error:mode==='error'?'HTTP_TLS_FAILED':null};};if(mode==='cancel-reject')f.module.cancelBindingHttp=async()=>{throw Error('PUBLIC_CANCEL_ERROR');};const a=new NativeBindingAdapter(async()=>f.module);assert.equal((await a.request(token,100)).kind,'unavailable');await tick();assert.equal(f.cancelled.length,mode==='cancel-reject'?0:1);
});
test('actual loader name/exports and root lifecycle call real barrier; no provisional SDK/token UI',()=>{
 const loader=readFileSync(new URL('./bindingNativeModule.ts',import.meta.url),'utf8');assert.match(loader,/requireOptionalNativeModule<NativeBindingHttpModule>\('YNXSocialAccountBindingHttp'\)/);for(const name of ['readBindingHttpEpoch','reserveBindingHttp','sendBindingHttp','cancelBindingHttp','advanceBindingHttpContext'])assert.ok(loader.includes(name));assert.match(loader,/Platform.OS!=='android'/);
 const root=readFileSync(new URL('../VeilSocialApp.tsx',import.meta.url),'utf8');assert.ok((root.match(/advanceAccountBindingContext\(\)/g)??[]).length>=3);assert.doesNotMatch(root,/requestAccountBinding\(/);
});
test('deadline during send cancels own handle once; late DTO cannot publish after observation expires',async()=>{
 const send=deferred<NativeBindingReply>(),f=fixture();f.module.sendBindingHttp=(h,e,t)=>{f.sent.push({handle:h,epoch:e,token:t});return send.promise;};const a=new NativeBindingAdapter(async()=>f.module);
 const result=await a.request(token,3);assert.deepEqual(result,{kind:'unavailable',reason:'TIMEOUT'});assert.deepEqual(f.cancelled,['1']);
 assert.equal((await a.request(token,2)).kind,'unavailable');send.resolve({epoch:'1',handle:'1',status:200,body,error:null});await tick();assert.deepEqual(f.cancelled,['1']);assert.deepEqual(result,{kind:'unavailable',reason:'TIMEOUT'});
});
test('late reservation after real context barrier is cancelled without send; pending barrier remains a barrier',async()=>{
 const reserve=deferred<string>(),f=fixture();f.module.reserveBindingHttp=()=>reserve.promise;const a=new NativeBindingAdapter(async()=>f.module);const pending=a.request(token,100);await tick();await a.advanceContext();reserve.resolve('77');assert.equal((await pending).kind,'unavailable');assert.deepEqual(f.cancelled,['77']);assert.equal(f.sent.length,0);
 const advance=deferred<string>(),g=fixture();g.module.advanceBindingHttpContext=()=>advance.promise;const b=new NativeBindingAdapter(async()=>g.module);await assert.rejects(b.advanceContext(2));assert.deepEqual(await b.request(token,2),{kind:'unavailable',reason:'TIMEOUT'});assert.equal(g.sent.length,0);g.setEpoch('2');advance.resolve('2');await tick();assert.equal(g.sent.length,0);
});
test('normal entry is NOT_ADMITTED until actual frozen native MIME contract; no fabricated response Content-Type',async()=>{
 const {accountBindingInput,requestAccountBinding}=await import('./accountBinding');assert.equal(accountBindingInput.nativeTransport,'NORMAL_NATIVE_ADAPTER_MATCHED_NOT_ADMITTED_RUNTIME_CALLBACK_NOT_VERIFIED');assert.equal(accountBindingInput.status,'UNAVAILABLE_AUTH_PRODUCER');assert.deepEqual(await requestAccountBinding(token),{kind:'unavailable',reason:'TRANSPORT_UNAVAILABLE'});
 const loader=readFileSync(new URL('./bindingNativeModule.ts',import.meta.url),'utf8');assert.doesNotMatch(loader,/contentType|Content-Type|capability/);
});
