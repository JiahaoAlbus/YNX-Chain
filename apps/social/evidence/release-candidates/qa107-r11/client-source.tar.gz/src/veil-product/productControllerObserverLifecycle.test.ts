import assert from 'node:assert/strict';
import test from 'node:test';
import { VeilProductController } from './productController';

// Public decoder/controller fixtures only, not native authorization or M1 QA.
const view = (revision = 'public-view-a') => ({
  kind: 'AUTHORIZED', accountViewRef: 'public-account-a', viewRevision: revision,
  profile: { displayName: 'Public QA', publicIdentifier: 'public-qa' },
  conversations: [], messages: [], activeConversationId: null, contacts: [], contactRequests: [],
  moments: [], devices: [], audiences: [], recoveries: [],
  actions: ['requestContact', 'reviewRecovery'], localAi: 'unsupported',
});
const command = { type: 'requestContact' as const, viewRevision: 'public-view-a', identifier: 'public-recipient' };
function ready() {
  const controller = new VeilProductController();
  controller.activate();
  const read = controller.beginRead(); assert.ok(read);
  controller.completeRead(read, { context: read.context, snapshot: view() });
  controller.release(read);
  return controller;
}

test('a throwing observer cannot strand admission, replace completion or skip release', () => {
  const c = ready(); let otherObserved = 0;
  c.subscribe(() => { throw new Error('public render failure'); });
  c.subscribe(() => { otherObserved++; });
  const op = c.beginExecute(command, 4); assert.ok(op);
  assert.equal(c.beginRead(), null);
  const result = c.completeExecute(op, { context: op.context, result: {
    kind: 'snapshot', completion: 'confirmed', originalOperationRef: 'public-original', snapshot: view('public-view-b'),
  } });
  assert.equal(result?.kind, 'snapshot');
  c.release(op);
  assert.equal(c.getSnapshot().busy, false);
  assert.equal(c.getSnapshot().error, null);
  assert.equal(c.getSnapshot().pending.length, 0);
  assert.ok(otherObserved >= 3);
  const next = c.beginRead(); assert.ok(next); c.release(next);
});

test('a throwing read observer is not a native boundary rejection', () => {
  const c = new VeilProductController(); c.activate();
  const read = c.beginRead(); assert.ok(read);
  c.subscribe(() => { throw new Error('public observer'); });
  assert.equal(c.completeRead(read, { context: read.context, snapshot: view() })?.kind, 'AUTHORIZED');
  c.release(read);
  assert.equal(c.getSnapshot().snapshot?.kind, 'AUTHORIZED');
  assert.equal(c.getSnapshot().error, null);
  assert.equal(c.getSnapshot().busy, false);
});

test('foreground activation never exposes an old view for synchronous new admission', () => {
  const c = ready(); const admitted: unknown[] = [];
  c.subscribe(() => { const op = c.beginExecute(command); if (op) admitted.push(op); });
  c.activate();
  assert.deepEqual(admitted, []);
  assert.equal(c.getSnapshot().snapshot, null);
  assert.equal(c.getSnapshot().needsRead, true);
  assert.equal(c.getSnapshot().busy, false);
});

for (const transition of ['invalidate', 'deactivate'] as const) {
  test(`${transition} publishes the cleared view and original uncertainty atomically`, () => {
    const c = ready(); const op = c.beginExecute(command, 8); assert.ok(op);
    const observed: ReturnType<typeof c.getSnapshot>[] = [];
    c.subscribe(() => { observed.push(c.getSnapshot()); });
    c[transition]();
    assert.equal(observed.length, 1);
    assert.equal(observed[0]?.snapshot, null);
    assert.equal(observed[0]?.pending[0]?.draftRevision, 8);
    assert.equal(observed[0]?.pending[0]?.disposition, 'unknown');
    assert.equal(c.beginRead(), null);
    c.release(op);
    assert.equal(c.getSnapshot().busy, false);
  });
}

test('invalidation during successful publication retains the reference without clearing the draft', () => {
  const c = ready(); const op = c.beginExecute(command, 11); assert.ok(op);
  c.subscribe(() => {
    const snapshot = c.getSnapshot().snapshot;
    if (snapshot?.kind === 'AUTHORIZED' && snapshot.viewRevision === 'public-view-b') c.invalidate();
  });
  const result = c.completeExecute(op, { context: op.context, result: {
    kind: 'snapshot', completion: 'confirmed', originalOperationRef: 'public-exact-original', snapshot: view('public-view-b'),
  } });
  assert.equal(result, null);
  const retained = c.getSnapshot().pending[0]; assert.ok(retained);
  assert.equal(retained.originalOperationRef, 'public-exact-original');
  assert.equal(retained.draftRevision, 11);
  assert.deepEqual(retained.command, command);
  assert.equal(retained.disposition, 'unknown');
  assert.equal(retained.resolution, 'unresolved');
  assert.equal(c.getSnapshot().snapshot, null);
  c.release(op);
  const read = c.beginRead(); assert.ok(read);
  c.completeRead(read, { context: read.context, snapshot: view() }); c.release(read);
  assert.equal(c.beginExecute(command, 12), null);
});

test('failure publication retains the draft and locked view in a single notification', () => {
  const c = ready(); const op = c.beginExecute(command, 6); assert.ok(op);
  const observed: ReturnType<typeof c.getSnapshot>[] = [];
  c.subscribe(() => { observed.push(c.getSnapshot()); });
  assert.equal(c.fail(op), true);
  assert.equal(observed.length, 1);
  assert.equal(observed[0]?.snapshot?.kind, 'LOCKED');
  assert.equal(observed[0]?.pending[0]?.draftRevision, 6);
  assert.equal(observed[0]?.error, 'OUTCOME_UNKNOWN');
  c.release(op);
});

test('read completion cannot publish a view invalidated by its own observer', () => {
  const c = new VeilProductController(); c.activate();
  const read = c.beginRead(); assert.ok(read);
  c.subscribe(() => { if (c.getSnapshot().snapshot?.kind === 'AUTHORIZED') c.deactivate(); });
  assert.equal(c.completeRead(read, { context: read.context, snapshot: view() }), null);
  assert.equal(c.getSnapshot().active, false);
  assert.equal(c.getSnapshot().snapshot, null);
  c.release(read);
});
