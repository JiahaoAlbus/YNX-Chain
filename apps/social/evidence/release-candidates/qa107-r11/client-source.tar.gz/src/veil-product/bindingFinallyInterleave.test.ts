import assert from 'node:assert/strict';
import {test} from 'node:test';
import {NativeBindingAdapter,type NativeBindingHttpModule,type NativeBindingReply} from './bindingNativeAdapter';

function deferred<T>(){let resolve!:(value:T)=>void;const promise=new Promise<T>(r=>{resolve=r;});return {promise,resolve};}
async function bounded<T>(promise:Promise<T>):Promise<T>{
  let timer:ReturnType<typeof setTimeout>|undefined;
  try{return await Promise.race([promise,new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(Error('CONTROL_WAIT_EXPIRED')),1000);})]);}
  finally{if(timer!==undefined)clearTimeout(timer);}
}
const token='PUBLIC_FINALLY_INTERLEAVE_NOT_A_GRANT';
const body=JSON.stringify({status:'ACCOUNT_BOUND',subject:'public-subject',generation:0,deviceAuthorization:'REQUIRED'});

test('old completion and new active request interleave without clearing or cancelling new admission',async()=>{
  const oldEpoch=deferred<string>(),atOldEpoch=deferred<void>(),newSend=deferred<NativeBindingReply>(),atNewSend=deferred<void>();
  let epoch='1',reads=0,reservations=0,oldObserved=false;
  const cancelled:string[]=[];
  const module:NativeBindingHttpModule={
    readBindingHttpEpoch:async()=>{if(++reads===3){atOldEpoch.resolve();return oldEpoch.promise;}return epoch;},
    reserveBindingHttp:async()=>String(++reservations),
    sendBindingHttp:async(handle,requestEpoch)=>{if(handle==='2'){atNewSend.resolve();return newSend.promise;}return {epoch:requestEpoch,handle,status:200,body,error:null};},
    cancelBindingHttp:async handle=>{cancelled.push(handle);return false;},
    advanceBindingHttpContext:async()=>{epoch=String(Number(epoch)+1);return epoch;},
  };
  const adapter=new NativeBindingAdapter(async()=>module);
  const old=adapter.request(token,1000).then(result=>{oldObserved=true;return result;});
  let fresh:Promise<Awaited<ReturnType<NativeBindingAdapter['request']>>>|undefined;
  try{
    await bounded(atOldEpoch.promise);
    // The native async export wraps oldEpoch. Two microtasks allow its await
    // continuation to finish actual ownership before the public race settles.
    oldEpoch.resolve('1');
    await Promise.resolve();await Promise.resolve();
    assert.equal(oldObserved,false,'new admission must precede old public completion');
    fresh=adapter.request(token,30);
    await bounded(atNewSend.promise);
    assert.equal((await bounded(old)).kind,'metadata');
    assert.deepEqual(cancelled,[],'old completion must not cancel new handle');
    assert.deepEqual(await adapter.request(token),{kind:'unavailable',reason:'TRANSPORT_UNAVAILABLE'});
    assert.equal(reservations,2,'old cleanup must not clear new admission');
    assert.deepEqual(await bounded(fresh),{kind:'unavailable',reason:'TIMEOUT'});
    assert.deepEqual(cancelled,['2']);
    await bounded(adapter.advanceContext());
    assert.deepEqual(await adapter.request(token),{kind:'unavailable',reason:'TRANSPORT_UNAVAILABLE'});
    newSend.resolve({epoch:'1',handle:'2',status:200,body,error:null});
    await new Promise<void>(resolve=>setImmediate(resolve));
    assert.deepEqual(cancelled,['2'],'late old-epoch delivery must not cancel a different request');
    assert.equal((await bounded(adapter.request(token,1000))).kind,'metadata');
    assert.equal(reservations,3);
  }finally{
    oldEpoch.resolve('1');newSend.resolve({epoch:'1',handle:'2',status:200,body,error:null});
    await bounded(old);if(fresh)await bounded(fresh);
  }
});
