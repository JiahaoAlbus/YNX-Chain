import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { en, productCopy } from './copy';
import { decodeSnapshotReply } from './productBoundary';
const source=readFileSync(new URL('../VeilSocialApp.tsx',import.meta.url),'utf8');
test('context status is inside bounded Friends/Moments scroll, not fixed over workspace (source control)',()=>{
 assert.doesNotMatch(source,/section !== 'chats' && section !== 'settings'/);
 for(const name of ['friends','moments']) {
  const at=source.indexOf(`const ${name} = <ScrollView`);assert.ok(at>0);
  const end=source.indexOf('</ScrollView>',at);assert.ok(end>at);
  const pane=source.slice(at,end);assert.match(pane,/style=\{styles.pane\}/);assert.match(pane,/\{connectionNotice\}/);assert.match(pane,/keyboardShouldPersistTaps="handled"/);
 }
 assert.match(source,/keyboardDidShow/);assert.match(source,/shown.remove\(\); hidden.remove\(\)/);
 assert.match(source,/!wide && !keyboardVisible && nav\(true\)/);
 assert.match(source,/maxHeight: 160/);
});
test('language controls precede long settings body and preserve visible top anchor (source control)',()=>{
 const at=source.indexOf('const settings = <ScrollView');const end=source.indexOf('</ScrollView>',at);const pane=source.slice(at,end);
 assert.ok(pane.indexOf("t('language')")<pane.indexOf('{accountSetup}'));
 assert.match(pane,/onContentSizeChange/);assert.match(pane,/scrollTo\(\{ y: 0, animated: false \}\)/);
 assert.notEqual(en.unavailable,'UNAVAILABLE');assert.notEqual(productCopy('zh', 'unavailable'),'UNAVAILABLE');
});
test('unavailable authorized projection remains unavailable, not empty authorized model',()=>{
 const context={callId:1,epoch:1,action:'readSnapshot' as const,accountViewRef:null,viewRevision:null};
 const result=decodeSnapshotReply({context,snapshot:{kind:'UNAVAILABLE',gaps:['AUTHORIZED_PRODUCT_PROJECTION_UNAVAILABLE']}},context);
 assert.equal(result.kind,'UNAVAILABLE');
 assert.match(source,/!audienceId \|\| !momentBody.trim\(\)/);
 assert.match(source,/blocked\('sendMessage'\)/);
});
