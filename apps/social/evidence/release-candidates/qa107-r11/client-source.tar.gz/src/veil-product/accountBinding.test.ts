import assert from 'node:assert/strict';import test from 'node:test';import {readFileSync} from 'node:fs';
import {decodeAccountBinding,decodeAccountBindingText,accountBindingInput} from './accountBinding';
import {veilProductNativeConsumer} from './nativeConsumer';import {VeilProductController} from './productController';
// Fixed public metadata parser controls only. No grants, fetch, or auth fixtures.
const metadata=()=>({status:'ACCOUNT_BOUND',subject:'public-subject',generation:0,deviceAuthorization:'REQUIRED'});
test('exact readonly binding metadata accepts generation zero without authorizing a device',()=>{const raw=metadata(),value=decodeAccountBinding(raw);raw.subject='changed';assert.equal(value.subject,'public-subject');assert.equal(value.generation,0);assert.equal(value.deviceAuthorization,'REQUIRED');assert.ok(Object.isFrozen(value));assert.deepEqual(decodeAccountBindingText(JSON.stringify(metadata())),value);});
test('binding rejects missing/extra/duplicate fields, unsafe generation, wrong authority, getters and overbounds',()=>{
  for(const delta of [{generation:-1},{generation:0.5},{generation:Number.MAX_SAFE_INTEGER+1},{status:'AUTHORIZED'},{deviceAuthorization:'APPROVED'},{subject:''},{subject:'x'.repeat(1025)},{grant:true}])assert.throws(()=>decodeAccountBinding({...metadata(),...delta}));
  assert.throws(()=>decodeAccountBindingText('{"status":"ACCOUNT_BOUND","subject":"public-subject","generation":1,"generation":0,"deviceAuthorization":"REQUIRED"}'));
  assert.throws(()=>decodeAccountBindingText(JSON.stringify(metadata())+'{}'));assert.throws(()=>decodeAccountBindingText(' '.repeat(8193)));
  let invoked=false;assert.throws(()=>decodeAccountBinding(Object.defineProperty(metadata(),'subject',{enumerable:true,get(){invoked=true;return 'public';}})));assert.equal(invoked,false);
});
test('missing approved new auth producer stays explicit and does not mutate controller or route through old auth',()=>{
  assert.equal(veilProductNativeConsumer.readAccountBindingInput(),accountBindingInput);assert.equal(accountBindingInput.status,'UNAVAILABLE_AUTH_PRODUCER');
  const c=new VeilProductController(),before=c.getSnapshot();decodeAccountBinding(metadata());assert.equal(c.getSnapshot(),before);
  const root=readFileSync(new URL('../VeilSocialApp.tsx',import.meta.url),'utf8');assert.match(root,/authProducerMissing/);assert.doesNotMatch(root,/requestAccountBinding\(/);
  const source=readFileSync(new URL('./bindingTransport.ts',import.meta.url),'utf8');assert.match(source,/JSON.stringify\(\{grantToken:token\}\)/);assert.match(source,/credentials:'omit'/);assert.match(source,/cache:'no-store'/);assert.match(source,/redirect:'error'/);assert.doesNotMatch(source,/localStorage|AsyncStorage|console\.|disconnect\(|closeLocalOwner\(/);
});
