import assert from 'node:assert/strict';
import {test} from 'node:test';
import {accountBindingInput,requestAccountBinding} from './accountBinding';

test('source-reviewed transport remains unqualified without runtime callback and approved producer',async()=>{
  assert.equal(accountBindingInput.nativeTransport,'NORMAL_NATIVE_ADAPTER_MATCHED_NOT_ADMITTED_RUNTIME_CALLBACK_NOT_VERIFIED');
  assert.equal(accountBindingInput.status,'UNAVAILABLE_AUTH_PRODUCER');
  assert.equal(accountBindingInput.deployment,'NOT_DEPLOYED');
  assert.ok(Object.isFrozen(accountBindingInput));
  assert.deepEqual(await requestAccountBinding('PUBLIC_DIAGNOSTIC_NOT_A_GRANT'),{kind:'unavailable',reason:'TRANSPORT_UNAVAILABLE'});
});
