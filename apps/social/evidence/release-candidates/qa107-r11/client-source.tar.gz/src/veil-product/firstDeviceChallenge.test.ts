import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {FirstDeviceChallengeGate, challengeCopy, type ChallengePrerequisite} from './firstDeviceChallenge';
import {bindChallengeModule, decodeChallenge, challengeStatuses, challengeResult, type ChallengeStatus} from './firstDeviceChallengeBridge';
import {productCopy, productLocale} from './copy';
const reply = challengeResult;
function fixture() {
  const calls: string[] = [];
  let status: ChallengeStatus = 'CHALLENGE_REQUIRED';
  let prerequisite: ChallengePrerequisite = null;
  const native = {
    async beginFirstDeviceChallenge(...args: unknown[]) { assert.equal(this, native); assert.deepEqual(args, []); calls.push('begin'); status = 'CHALLENGE_PENDING'; return reply(status); },
    async observeFirstDeviceChallenge(...args: unknown[]) { assert.equal(this, native); assert.deepEqual(args, []); calls.push('observe'); return reply(status); },
    async cancelFirstDeviceChallenge(...args: unknown[]) { assert.equal(this, native); assert.deepEqual(args, []); calls.push('cancel'); return reply(status === 'CHALLENGE_PENDING' ? status : 'CHALLENGE_CANCELED'); },
  };
  let loads = 0;
  const gate = new FirstDeviceChallengeGate(async () => { loads++; return bindChallengeModule(native); }, () => prerequisite);
  return {gate, calls, native, status: (s: ChallengeStatus) => { status = s; }, prerequisite: (p: ChallengePrerequisite) => { prerequisite = p; }, loads: () => loads};
}
test('explicit continuation uses exact no-arg adapter after original A+keys UI prerequisite', async () => {
  const f = fixture(); f.prerequisite('ORIGINAL_A_LOGIN_REQUIRED');
  await f.gate.continueByUser(); assert.deepEqual(f.calls, []);
  f.prerequisite('LOCAL_KEYS_REQUIRED'); await f.gate.continueByUser(); assert.deepEqual(f.calls, []);
  f.prerequisite(null); await f.gate.continueByUser();
  assert.deepEqual(f.calls, ['observe', 'begin']); assert.equal(f.gate.getSnapshot().result?.deviceAuthorization, 'REQUIRED');
  await f.gate.continueByUser(); assert.deepEqual(f.calls, ['observe', 'begin']);
});
test('mount/foreground/remount observe only; native auto-issued original never begins again', async () => {
  const f = fixture(); f.status('CHALLENGE_ISSUED_UNVERIFIED');
  const stop = f.gate.subscribe(() => {}); await f.gate.observe(); stop();
  f.gate.subscribe(() => {}); await f.gate.observe(); await f.gate.continueByUser();
  assert.deepEqual(f.calls, ['observe', 'observe']); assert.equal(f.loads(), 1);
});
test('explicit action observes native autoIssue before begin even without prior mount', async () => {
  const f = fixture(); f.status('CHALLENGE_PENDING'); await f.gate.continueByUser();
  assert.deepEqual(f.calls, ['observe']); assert.equal(f.gate.canContinue(), false);
});
test('prerequisite rechecked after delayed observe; no begin when original login changes', async () => {
  const f = fixture(); let finish!: (v: ReturnType<typeof reply>) => void;
  f.native.observeFirstDeviceChallenge = async () => new Promise(resolve => { finish = resolve; });
  const task = f.gate.continueByUser(); await new Promise(resolve => setImmediate(resolve));
  f.prerequisite('ORIGINAL_A_LOGIN_REQUIRED'); finish(reply('CHALLENGE_REQUIRED')); await task;
  assert.deepEqual(f.calls, []); assert.equal(f.gate.getSnapshot().result?.status, 'ORIGINAL_A_LOGIN_REQUIRED');
});
test('repeat clicks/unmount/timeout retain one physical bridge promise and late reply', async () => {
  const f = fixture(); let finish!: (v: ReturnType<typeof reply>) => void;
  f.native.beginFirstDeviceChallenge = async () => { f.calls.push('begin'); return new Promise(resolve => { finish = resolve; }); };
  assert.equal((await f.gate.continueByUser(1)).status, 'OBSERVATION_PENDING');
  const stop = f.gate.subscribe(() => {}); stop(); const same = f.gate.continueByUser();
  const cancel = f.gate.cancelByUser(); assert.equal(f.gate.getSnapshot().pending, true);
  finish(reply('CHALLENGE_ISSUED_UNVERIFIED')); await same; await cancel;
  assert.deepEqual(f.calls, ['observe', 'begin']); assert.equal(f.gate.getSnapshot().result?.status, 'CHALLENGE_ISSUED_UNVERIFIED');
});
test('unknown and pending are sticky begin fences even if later observation says required', async () => {
  for (const s of ['CHALLENGE_UNKNOWN_RETAINED', 'CHALLENGE_PENDING', 'CHALLENGE_CANCEL_UNKNOWN_RETAINED'] as const) {
    const f = fixture(); f.status(s); await f.gate.observe(); f.status('CHALLENGE_REQUIRED'); await f.gate.observe();
    await f.gate.continueByUser(); assert.deepEqual(f.calls, ['observe', 'observe']); assert.equal(f.gate.canContinue(), false);
  }
});
test('pending cancel is not queued/confirmed and requires observation then another explicit action', async () => {
  const f = fixture(); f.status('CHALLENGE_PENDING'); await f.gate.observe(); await f.gate.cancelByUser();
  assert.equal(f.gate.getSnapshot().cancelUnconfirmed, true); assert.equal(f.gate.canCancel(), false);
  await f.gate.cancelByUser(); assert.deepEqual(f.calls, ['observe', 'cancel']);
  f.status('CHALLENGE_ISSUED_UNVERIFIED'); await f.gate.observe(); assert.equal(f.gate.canCancel(), true);
  assert.deepEqual(f.calls, ['observe', 'cancel', 'observe']);
  await f.gate.cancelByUser(); assert.equal(f.gate.getSnapshot().result?.status, 'CHALLENGE_CANCELED');
  assert.equal(f.gate.getSnapshot().cancelUnconfirmed, false); assert.equal(f.gate.canContinue(), false);
});
test('cancel uncertainty never auto-retries or invokes login/owner actions', async () => {
  const f = fixture(); f.status('CHALLENGE_ISSUED_UNVERIFIED'); await f.gate.observe();
  f.native.cancelFirstDeviceChallenge = async () => { f.calls.push('cancel'); throw Error('public bridge failure'); };
  await f.gate.cancelByUser(); await f.gate.cancelByUser(); await f.gate.continueByUser();
  assert.deepEqual(f.calls, ['observe', 'cancel']); assert.equal(f.gate.getSnapshot().result?.status, 'CHALLENGE_CANCEL_UNKNOWN_RETAINED');
  assert.equal(f.gate.getSnapshot().canceled, true);
});
test('strict safe-map decode rejects private payload/authority/accessors without reading getters', () => {
  for (const s of challengeStatuses) assert.equal(decodeChallenge(reply(s)).status, s);
  let reads = 0;
  for (const bad of [null, [], {...reply('CHALLENGE_PENDING'), nonce: 'no'}, {...reply('CHALLENGE_PENDING'), deviceAuthorization: 'APPROVED'}, {...reply('CHALLENGE_PENDING'), status: '62'},
    {get status() { reads++; return 'CHALLENGE_PENDING'; }, nativeBoundary: 'REQUIRED', deviceAuthorization: 'REQUIRED'}]) assert.throws(() => decodeChallenge(bad));
  assert.equal(reads, 0); assert.equal(bindChallengeModule(null), null);
});
test('English default and live Chinese copy keep issued/cancel distinct from authorization', () => {
  assert.equal(productLocale(undefined), 'en');
  for (const locale of ['en', 'zh'] as const) for (const key of Object.values(challengeCopy)) assert.ok(productCopy(locale, key));
  assert.match(productCopy('en', challengeCopy.CHALLENGE_ISSUED_UNVERIFIED), /authorization is not complete/);
  assert.match(productCopy('zh', challengeCopy.CHALLENGE_ISSUED_UNVERIFIED), /设备授权仍未完成/);
  assert.match(productCopy('en', 'registrationCancelUnconfirmed'), /may not have been queued/);
  assert.match(productCopy('zh', 'registrationCancelUnconfirmed'), /可能尚未排队/);
});
test('panel/root wiring source check only: mounted real panel, actions and observe-only effects', () => {
  const panel = readFileSync(new URL('FirstDeviceChallengePanel.tsx', import.meta.url), 'utf8');
  const root = readFileSync(new URL('../VeilSocialApp.tsx', import.meta.url), 'utf8');
  const start = panel.indexOf('useEffect(() => {'), end = panel.indexOf('return <View', start);
  assert.ok(start >= 0 && end > start); assert.doesNotMatch(panel.slice(start, end), /continueByUser|cancelByUser/);
  assert.match(panel, /onPress=.*gate.continueByUser/); assert.match(panel, /onPress=.*gate.cancelByUser/);
  assert.match(root, /<FirstDeviceChallengePanel locale=\{locale\}/);
  assert.doesNotMatch(panel, /cancelAccountLogin|initializeLocalDevice|publicProjection|nonce|proposal/);
});
