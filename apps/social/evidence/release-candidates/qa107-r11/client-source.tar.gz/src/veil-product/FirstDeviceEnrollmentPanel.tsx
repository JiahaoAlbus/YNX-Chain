import React, { useEffect, useSyncExternalStore } from 'react';
import { AppState, Pressable, Text, View } from 'react-native';
import { productCopy } from './copy';
import { firstDeviceEnrollmentGate as gate } from './firstDeviceEnrollmentModule';

/** Uses the existing login/owner in native; mounting never prepares or signs. */
export function FirstDeviceEnrollmentPanel({ locale, disabled }: { locale: 'en' | 'zh'; disabled: boolean }) {
  const state = useSyncExternalStore(gate.subscribe, gate.snapshot, gate.snapshot);
  const copy = (key: Parameters<typeof productCopy>[1]) => productCopy(locale, key);
  useEffect(() => {
    void gate.observe();
    const foreground = AppState.addEventListener('change', value => { if (value === 'active') void gate.observe(); });
    const timer = setInterval(() => { if (AppState.currentState === 'active') void gate.observe(); }, 5000);
    return () => { foreground.remove(); clearInterval(timer); }; // original future stays owned
  }, []);
  const status = state.result?.status;
  if (!status || ['CHALLENGE_REQUIRED', 'ORIGINAL_A_LOGIN_REQUIRED', 'LOCAL_KEYS_REQUIRED', 'UNAVAILABLE'].includes(status)) return null;
  const message = status === 'SOURCE_CHECK_PENDING' ? copy('registrationPending') :
    status === 'SOURCE_EVIDENCE_UNADMITTED' ? copy('registrationSourceUnadmitted') :
    status === 'SOURCE_PROFILE_REQUIRED' || status === 'SOURCE_NATIVE_INTERFACE_REQUIRED' ? copy('registrationSourceUnavailable') :
    status === 'SOURCE_CHECK_CANCELED_RETAINED' ? copy('registrationSourceCanceled') :
    status === 'SOURCE_UNKNOWN_RETAINED' || status === 'SOURCE_CHECK_REJECTED' ? copy('registrationUnknown') :
    status === 'CHALLENGE_ISSUED_UNVERIFIED' ? copy('registrationReady') :
    status === 'ENROLLMENT_COMMITTED_UNVERIFIED' || status === 'NATIVE_PROOF_AUTHORIZATION_REQUIRED' ? copy('registrationIssued') :
    status === 'CHALLENGE_CANCELED' ? copy('registrationCanceled') :
    status === 'ENROLLMENT_UNKNOWN_RETAINED' || status === 'ENROLLMENT_EXPIRED_RETAINED' ? copy('registrationUnknown') : copy('registrationPending');
  return <View accessibilityLiveRegion="polite">
    <Text>{message}</Text>
    <Pressable accessibilityRole="button" disabled={disabled || !gate.canPrepare()}
      accessibilityState={{ disabled: disabled || !gate.canPrepare() }}
      onPress={() => { if (!disabled) void gate.prepareByUser(); }}>
      <Text>{copy('registrationContinue')}</Text>
    </Pressable>
    <Pressable accessibilityRole="button" disabled={state.pending} onPress={() => { void gate.observe(); }}>
      <Text>{copy('registrationObserve')}</Text>
    </Pressable>
  </View>;
}
