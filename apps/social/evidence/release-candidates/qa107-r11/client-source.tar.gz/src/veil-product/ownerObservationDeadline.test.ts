import assert from 'node:assert/strict';
import test from 'node:test';
import {readFileSync} from 'node:fs';
import {LocalOwnerObservationGate,readLoadedOwner,type LocalOwnerReadModule} from './localOwner';
import {decodeSnapshotReply} from './productBoundary';
const publicRaw=()=>({ownerState:'LOCAL_PENDING',queued:0,pendingTickets:1,reopenedPendingRows:0,pendingStoreState:'UNKNOWN',failureRetained:false,nativeBoundary:'REQUIRED',localGenesisAttempted:false,localGenesisStatus:null});
function deferred<T>(){let resolve!:(value:T)=>void;let reject!:(error:Error)=>void;const promise=new Promise<T>((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};}
test('R5-O1 total deadline covers slow import, shares repeat observations and late native settlement',async()=>{
  const gate=new LocalOwnerObservationGate();const loader=deferred<LocalOwnerReadModule|null>();const native=deferred<unknown>();let loads=0,calls=0;
  const operation=()=>readLoadedOwner(()=>{loads++;return loader.promise;});
  assert.equal((await gate.observe(operation,2)).status,'READ_TIMEOUT');assert.equal(loads,1);assert.equal(calls,0);
  assert.equal((await gate.observe(operation,2)).status,'READ_TIMEOUT');assert.equal(loads,1);assert.equal(calls,0);
  loader.resolve({readLocalOwnerState:()=>{calls++;return native.promise;}});
  assert.equal((await gate.observe(operation,2)).status,'READ_TIMEOUT');assert.equal(loads,1);assert.equal(calls,1);
  const late=gate.observe(operation,100);native.resolve(publicRaw());const value=await late;
  assert.equal(value.status,'OBSERVED');assert.equal(value.nativeBoundary,'REQUIRED');assert.equal(loads,1);assert.equal(calls,1);
  assert.ok(Object.isFrozen(value));
  const context={callId:1,epoch:1,action:'readSnapshot' as const,accountViewRef:null,viewRevision:null};
  assert.equal(decodeSnapshotReply({context,snapshot:{kind:'UNAVAILABLE',gaps:[],localOwner:value}},context).kind,'UNAVAILABLE');
  assert.throws(()=>decodeSnapshotReply({context:{...context,epoch:2},snapshot:{kind:'UNAVAILABLE',gaps:[],localOwner:value}},context));
});
test('R5-O1 fast load deferred native and timeout second read retain one actual operation',async()=>{
  const gate=new LocalOwnerObservationGate();const native=deferred<unknown>();let loads=0,calls=0;
  const operation=()=>readLoadedOwner(async()=>{loads++;return {readLocalOwnerState:()=>{calls++;return native.promise;}};});
  assert.equal((await gate.observe(operation,2)).status,'READ_TIMEOUT');
  const second=gate.observe(operation,100);native.resolve(publicRaw());assert.equal((await second).status,'OBSERVED');
  assert.equal(loads,1);assert.equal(calls,1);
});
test('R5-O1 loader failure/missing and native failure are distinct, never success',async()=>{
  const gate=new LocalOwnerObservationGate();
  assert.equal((await gate.observe(()=>readLoadedOwner(async()=>{throw Error('fixed public load failure');}),100)).status,'MODULE_UNAVAILABLE');
  assert.equal((await gate.observe(()=>readLoadedOwner(async()=>null),100)).status,'MODULE_UNAVAILABLE');
  assert.equal((await gate.observe(()=>readLoadedOwner(async()=>({readLocalOwnerState:async()=>{throw Error('fixed public native failure');}})),100)).status,'READ_FAILED');
  assert.equal((await gate.observe(()=>readLoadedOwner(async()=>({readLocalOwnerState:async()=>({...publicRaw(),nativeBoundary:'AUTHORIZED'})})),100)).status,'INVALID_REPLY');
  await assert.rejects(gate.observe(()=>readLoadedOwner(async()=>null),31001));
});
test('R5-O1 actual consumer invokes total production gate before cached import',()=>{
  const source=readFileSync(new URL('./nativeConsumer.ts',import.meta.url),'utf8');
  assert.match(source,/ownerReadGate.observe\(\(\) => readLoadedOwner\(\(\) => \{/);
  assert.match(source,/ownerModule \?\?= import\('\.\/localOwnerModule'\)/);
  assert.doesNotMatch(source,/const module = await ownerModule/);
  assert.doesNotMatch(source,/ownerModule\s*=\s*null\s*;/); // No timeout reset/re-import.
  assert.doesNotMatch(source,/\.closeLocalOwner\(/);
});
