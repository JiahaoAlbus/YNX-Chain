/** Original process-local registration only. All source/pair/challenge data stays native. */
export const enrollmentStatuses = [
  'ORIGINAL_A_LOGIN_REQUIRED', 'LOCAL_KEYS_REQUIRED', 'UNAVAILABLE', 'OBSERVATION_PENDING',
  'CHALLENGE_REQUIRED', 'CHALLENGE_PENDING', 'CHALLENGE_ISSUED_UNVERIFIED',
  'CHALLENGE_UNKNOWN_RETAINED', 'CHALLENGE_CANCEL_PENDING', 'CHALLENGE_CANCEL_UNKNOWN_RETAINED',
  'CHALLENGE_CANCELED', 'ORIGINAL_INTENT_REQUIRED', 'ENROLLMENT_PENDING',
  'ENROLLMENT_UNKNOWN_RETAINED', 'ENROLLMENT_EXPIRED_RETAINED',
  'NATIVE_PROOF_AUTHORIZATION_REQUIRED', 'ENROLLMENT_COMMITTED_UNVERIFIED',
  'SOURCE_CHECK_PENDING', 'SOURCE_EVIDENCE_UNADMITTED', 'SOURCE_PROFILE_REQUIRED',
  'SOURCE_CHECK_REJECTED', 'SOURCE_CHECK_CANCELED_RETAINED', 'SOURCE_UNKNOWN_RETAINED',
  'SOURCE_NATIVE_INTERFACE_REQUIRED',
] as const;
export type EnrollmentStatus = typeof enrollmentStatuses[number];
export type EnrollmentResult = Readonly<{ status: EnrollmentStatus; nativeBoundary: 'REQUIRED'; deviceAuthorization: 'REQUIRED' }>;
export interface EnrollmentModule {
  prepareFirstDeviceEnrollment(): Promise<unknown>;
  observeFirstDeviceEnrollment(): Promise<unknown>;
}
const result = (status: EnrollmentStatus): EnrollmentResult => Object.freeze({ status, nativeBoundary: 'REQUIRED', deviceAuthorization: 'REQUIRED' });
export function decodeEnrollment(value: unknown): EnrollmentResult {
  if (!value || typeof value !== 'object') throw new Error('INVALID_ENROLLMENT_PROJECTION');
  const prototype = Object.getPrototypeOf(value);
  const fields = Object.getOwnPropertyDescriptors(value);
  if (prototype !== Object.prototype && prototype !== null || Reflect.ownKeys(fields).length !== 3 ||
      !['status', 'nativeBoundary', 'deviceAuthorization'].every(k => fields[k]?.enumerable && 'value' in fields[k]!)) throw new Error('INVALID_ENROLLMENT_PROJECTION');
  const status = fields.status!.value;
  if (!enrollmentStatuses.includes(status) || fields.nativeBoundary!.value !== 'REQUIRED' || fields.deviceAuthorization!.value !== 'REQUIRED') throw new Error('INVALID_ENROLLMENT_PROJECTION');
  return result(status);
}
export function bindEnrollmentModule(value: unknown): EnrollmentModule | null {
  if (!value || typeof value !== 'object') return null;
  const module = value as Partial<EnrollmentModule>;
  if (typeof module.prepareFirstDeviceEnrollment !== 'function' || typeof module.observeFirstDeviceEnrollment !== 'function') return null;
  const prepare = module.prepareFirstDeviceEnrollment.bind(value);
  const observe = module.observeFirstDeviceEnrollment.bind(value);
  return Object.freeze({ prepareFirstDeviceEnrollment: () => prepare(), observeFirstDeviceEnrollment: () => observe() });
}
export class FirstDeviceEnrollmentGate {
  private module: Promise<EnrollmentModule | null> | undefined;
  private active: Promise<EnrollmentResult> | undefined;
  private attempted = false;
  private state: Readonly<{ pending: boolean; result?: EnrollmentResult }> = Object.freeze({ pending: false });
  private listeners = new Set<() => void>();
  constructor(private readonly load: () => Promise<EnrollmentModule | null>) {}
  snapshot = () => this.state;
  subscribe = (listener: () => void) => { this.listeners.add(listener); return () => { this.listeners.delete(listener); }; };
  canPrepare = () => !this.active && !this.attempted && this.state.result?.status === 'CHALLENGE_ISSUED_UNVERIFIED';
  observe = () => this.run(false);
  prepareByUser = () => this.run(true);
  private publish(pending: boolean, value?: EnrollmentResult) {
    this.state = Object.freeze({ pending, ...(value ? { result: value } : {}) });
    for (const listener of this.listeners) {
      try { listener(); } catch { /* UI observers cannot release or rewrite the original native call. */ }
    }
  }
  private run(prepare: boolean): Promise<EnrollmentResult> {
    if (this.active) return this.active;
    if (prepare && !this.canPrepare()) return Promise.resolve(this.state.result ?? result('UNAVAILABLE'));
    const work = Promise.resolve().then(async () => {
      const module = await (this.module ??= this.load());
      if (!module) return result('UNAVAILABLE');
      const current = decodeEnrollment(await module.observeFirstDeviceEnrollment());
      if (!prepare || current.status !== 'CHALLENGE_ISSUED_UNVERIFIED' || this.attempted) return current;
      this.attempted = true; // physical invocation may outlive UI; never clear on timeout/unmount
      return decodeEnrollment(await module.prepareFirstDeviceEnrollment());
    }).catch(() => result('ENROLLMENT_UNKNOWN_RETAINED')).then(value => {
      if (value.status.startsWith('SOURCE_') || ['ENROLLMENT_PENDING', 'ENROLLMENT_UNKNOWN_RETAINED', 'ENROLLMENT_EXPIRED_RETAINED',
        'NATIVE_PROOF_AUTHORIZATION_REQUIRED', 'ENROLLMENT_COMMITTED_UNVERIFIED', 'CHALLENGE_CANCELED',
        'CHALLENGE_CANCEL_PENDING', 'CHALLENGE_CANCEL_UNKNOWN_RETAINED'].includes(value.status)) this.attempted = true;
      this.active = undefined; this.publish(false, value); return value;
    });
    this.active = work;
    // Reserve the original promise before notifying observers: a synchronous
    // reentrant read/continue must join this call, never dispatch another one.
    this.publish(true, this.state.result);
    return work;
  }
}
