import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo-modules-core';
import { bindEnrollmentModule, FirstDeviceEnrollmentGate } from './firstDeviceEnrollment';
export const firstDeviceEnrollmentGate = new FirstDeviceEnrollmentGate(async () =>
  Platform.OS === 'android' ? bindEnrollmentModule(requireOptionalNativeModule('YNXSocialCryptoEngine')) : null);
