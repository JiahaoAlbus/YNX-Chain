import assert from 'node:assert/strict';
import test from 'node:test';
import {readFileSync} from 'node:fs';
import {accountEntryCapabilities,accountEntryCases,selectAccountEntry} from './accountEntry';
import {veilProductNativeConsumer} from './nativeConsumer';
import {VeilProductController} from './productController';
import {en,zh} from './copy';
test('M1 four normal entry intents distinguish first-device, add, restore, revoked without authority',()=>{
  assert.equal(accountEntryCapabilities.length,4);
  assert.deepEqual(veilProductNativeConsumer.readAccountEntryCapabilities(),accountEntryCapabilities);
  const expected=['CREATE_IDENTITY_FIRST_DEVICE_API','LOGIN_ADD_DEVICE_API','RESTORE_AUTHORITY_API','REVOKED_DEVICE_CHECK_API'];
  accountEntryCases.forEach((intent,i)=>{const entry=selectAccountEntry(intent);assert.equal(entry.requirements[0],expected[i]);assert.equal(entry.availability,'UNAVAILABLE');assert.equal(entry.grantsAccount,false);assert.equal(entry.grantsHistory,false);assert.ok(Object.isFrozen(entry));assert.ok(Object.isFrozen(entry.requirements));});
  assert.throws(()=>selectAccountEntry('fabricated' as never));
  assert.match(en.firstDeviceDetail,/do not need an older trusted device/);assert.match(zh.firstDeviceDetail,/不要求.*旧/);
});
test('normal entry choice does not touch controller/session or synthesize AUTHORIZED',()=>{
  const c=new VeilProductController();const before=c.getSnapshot();
  for(const intent of accountEntryCases)selectAccountEntry(intent);
  assert.equal(c.getSnapshot(),before);assert.equal(before.snapshot,null);assert.equal(before.pending.length,0);
  const root=readFileSync(new URL('../VeilSocialApp.tsx',import.meta.url),'utf8');
  assert.match(root,/onPress=\{\(\) => \{ setLocalSetupFeedback\(null\); setEntryIntent\(item.intent\); \}\}/);
  assert.match(root,/disabled=\{localSetupBusy \|\| accountLoginBusy\} accessibilityState=\{\{ selected: entryIntent === item.intent, disabled: localSetupBusy \|\| accountLoginBusy \}\}/);
  assert.match(root,/localDeviceSetupGate\.observe\(locale\)/);
  assert.match(root,/entryNotConnected/);assert.match(root,/loginNotGrant/);
  const entry=readFileSync(new URL('./accountEntry.ts',import.meta.url),'utf8');assert.doesNotMatch(entry,/kind:\s*['"]AUTHORIZED/);
  for(const key of Object.keys(en))assert.ok(zh[key as keyof typeof en]);
});
