import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {localEntryPresentation} from './entryPresentation';
import {decodeNativeLocalOwner} from './localOwner';
import {AccountLoginGate} from './accountLogin';
import {en, zh} from './copy';
const base={ownerState:'LOCAL_PENDING',queued:0,pendingTickets:0,reopenedPendingRows:0,pendingStoreState:'FRESH',failureRetained:false,nativeBoundary:'REQUIRED',localGenesisAttempted:false,localGenesisStatus:null};
const observed=(delta:Record<string,unknown>={})=>decodeNativeLocalOwner({...base,...delta});
test('first unstarted local lifecycle shows preparation, not existing-key recovery or a grant',()=>{
 assert.deepEqual(localEntryPresentation(observed(),'newIdentityFirstDevice'),{mode:'prepare',canPrepare:true,showOriginal:false});
 for(const intent of ['existingIdentityAddDevice','restoreIdentity','revokedDeviceAttempt'] as const)assert.equal(localEntryPresentation(observed(),intent).canPrepare,false);
});
test('retained, reopened and unknown operations cannot offer a replacement',()=>{
 for(const delta of [{localGenesisAttempted:true,localGenesisStatus:41},{localGenesisAttempted:true,localGenesisStatus:16},{localGenesisAttempted:true,localGenesisStatus:25},{reopenedPendingRows:1},{pendingTickets:1},{pendingStoreState:'UNKNOWN'},{pendingStoreState:'RECONCILIATION_REQUIRED'}]){
  const state=localEntryPresentation(observed(delta),'newIdentityFirstDevice');assert.equal(state.canPrepare,false);assert.equal(state.showOriginal,true);
 }
});
test('missing read, failure, queue, closing and closed never become fresh permission',()=>{
 for(const delta of [{failureRetained:true},{queued:1},{ownerState:'CLOSING'},{ownerState:'CLOSED'},{ownerState:'INIT_FAILED'},{pendingStoreState:null}])assert.equal(localEntryPresentation(observed(delta),'newIdentityFirstDevice').canPrepare,false);
 assert.equal(localEntryPresentation(undefined,'newIdentityFirstDevice').canPrepare,false);
 assert.equal(localEntryPresentation({status:'READ_TIMEOUT',nativeBoundary:'REQUIRED'},'newIdentityFirstDevice').showOriginal,false);
});
test('explicit new-account action uses real gate A once, preflight refusal does not change intent',async()=>{
 const calls:string[]=[];const gate=new AccountLoginGate(async()=>({beginAccountLogin:async intent=>{calls.push(intent);return {status:'VERIFIED_CALLBACK_REQUIRED',deviceAuthorization:'REQUIRED'};},observeAccountLogin:async()=>({status:'VERIFIED_CALLBACK_REQUIRED',deviceAuthorization:'REQUIRED'}),cancelAccountLogin:async()=>({status:'CANCELLED',deviceAuthorization:'REQUIRED'})}));
 assert.deepEqual(calls,[]);await gate.execute('begin','newIdentityFirstDevice');
 await gate.execute('begin','existingIdentityAddDevice');assert.deepEqual(calls,['A']);assert.equal(gate.getSnapshot().intent,'newIdentityFirstDevice');
});
test('normal root exposes real account panel before case descriptions and gates original controls',()=>{
 const root=readFileSync(new URL('../VeilSocialApp.tsx',import.meta.url),'utf8');
 const block=root.slice(root.indexOf('const accountSetup ='),root.indexOf('const originalLocalControls ='));
 assert.ok(block.indexOf('<AccountLoginPanel')<block.indexOf("t('accountEntryDetail')"));
 assert.match(root,/section === 'chats' \? \(ready \? chats : welcome\)/);
 assert.match(root,/localEntry\.showOriginal && <LocalRecoveryPanel/);
 assert.match(root,/localEntry\.showOriginal && <View/);
 assert.match(root,/section !== 'chats' && section !== 'settings' && <View style=\{styles.banner\}/);
 assert.match(root,/const welcome = <ScrollView style=\{styles.pane\}/);
 assert.match(root,/if \(!localEntryPresentation\([\s\S]*?\.canPrepare\) return;/);
});
test('normal copy remains bilingual without changing safety projections',()=>{
 assert.deepEqual(Object.keys(en).sort(),Object.keys(zh).sort());
 for(const key of ['welcomeTitle','welcomeDetail','setupStatusDetail','localEntryChecking','localEntryRetained','localEntryUnavailable'] as const){assert.ok(en[key]);assert.ok(zh[key]);}
 const consumer=readFileSync(new URL('./nativeConsumer.ts',import.meta.url),'utf8');assert.match(consumer,/kind: 'UNAVAILABLE'/);
});
