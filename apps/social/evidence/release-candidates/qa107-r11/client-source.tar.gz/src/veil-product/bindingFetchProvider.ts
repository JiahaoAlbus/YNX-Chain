import { Platform } from 'react-native';
import { fetch as expoFetch, type FetchRequestInit } from 'expo/fetch';
import type { BindingFetch } from './bindingTransport';
/** Actual installed Expo 57.0.8 public export. No custom/native SDK writes. */
export function loadBindingFetch(): BindingFetch {
  // The installed native API omits cache/no-store and inherits an HTTP cache.
  // Do not silently discard required privacy controls or patch shared native.
  if (Platform.OS === 'android') throw new Error('VEIL_NATIVE_FETCH_NO_STORE_UNSUPPORTED');
  if (Platform.OS !== 'web') throw new Error('VEIL_FETCH_PLATFORM_UNQUALIFIED');
  return (url, init) => {
    // Installed native FetchRequestInit has no cache/referrerPolicy fields.
    // Web honors those standard controls; native uses fresh POST/omit cookies
    // and backend no-store, with no metadata cache or referrer header added.
    const request: FetchRequestInit & { cache: 'no-store'; referrerPolicy: 'no-referrer' } = init;
    return expoFetch(url, request);
  };
}
