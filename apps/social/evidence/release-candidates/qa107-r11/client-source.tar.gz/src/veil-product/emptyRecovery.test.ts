import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {LocalRecoveryGate,decodeRecovery} from './localRecovery';
import {localEntryPresentation} from './entryPresentation';
import {decodeNativeLocalOwner} from './localOwner';
const reply=(status:string)=>({status,nativeBoundary:'REQUIRED',deviceAuthorization:'REQUIRED'});
test('empty original result remains same receipt across repeats and remount, never initialization',async()=>{
 let begin=0,observe=0; const gate=new LocalRecoveryGate(async()=>({beginLocalRecoveryCheck:async()=>{begin++;return reply('NO_ORIGINAL_OPERATION');},observeLocalRecoveryCheck:async()=>{observe++;throw Error('not needed');}}));
 const first=await gate.inspect();gate.subscribe(()=>{})();assert.strictEqual(await gate.inspect(),first);
 assert.deepEqual([begin,observe],[1,0]);assert.equal(first.status,'NO_ORIGINAL_OPERATION');assert.equal(first.deviceAuthorization,'REQUIRED');
});
test('empty result waits for original bridge completion; timeout does not clear or retry',async()=>{
 let finish!:(v:unknown)=>void,calls=0;const gate=new LocalRecoveryGate(async()=>({beginLocalRecoveryCheck:()=>{calls++;return new Promise(r=>finish=r);},observeLocalRecoveryCheck:async()=>{throw Error('not needed');}}));
 assert.equal((await gate.inspect(1)).status,'OBSERVATION_PENDING');assert.equal(gate.getSnapshot().pending,true);
 const pending=gate.inspect(1000);finish(reply('NO_ORIGINAL_OPERATION'));assert.equal((await pending).status,'NO_ORIGINAL_OPERATION');assert.equal(calls,1);
});
test('UNKNOWN and failures cannot be decoded or rewritten as empty',async()=>{
 for(const status of ['UNKNOWN_RETAINED','RECOVERY_REQUIRED','REFUSED_RETAINED']) assert.equal(decodeRecovery(reply(status)).status,status);
 assert.throws(()=>decodeRecovery({...reply('NO_ORIGINAL_OPERATION'),deviceAuthorization:'APPROVED'}));
 const gate=new LocalRecoveryGate(async()=>({beginLocalRecoveryCheck:async()=>{throw Error('original');},observeLocalRecoveryCheck:async()=>reply('NO_ORIGINAL_OPERATION')}));
 assert.equal((await gate.inspect()).status,'RECOVERY_REQUIRED');assert.equal((await gate.inspect()).status,'RECOVERY_REQUIRED');
});
test('closed/closing owner cannot offer duplicate original setup even with retained attempted metadata',()=>{
 for(const ownerState of ['CLOSED','CLOSING'])for(const attempted of [false,true]){
 const owner=decodeNativeLocalOwner({ownerState,queued:0,pendingTickets:0,reopenedPendingRows:0,pendingStoreState:'CLOSED',failureRetained:true,nativeBoundary:'REQUIRED',localGenesisAttempted:attempted,localGenesisStatus:null});
 assert.deepEqual(localEntryPresentation(owner,'newIdentityFirstDevice'),{mode:'closed',canPrepare:false,showOriginal:false});
 }
});
test('source wiring: same worker inspection precedes receipt/postguard publication (not runtime evidence)',()=>{
 const root=new URL('../../modules/native-matrix/android/src/main/java/com/ynx/social/matrix/',import.meta.url);
 const owner=readFileSync(new URL('VeilCryptoEngineOwner.kt',root),'utf8');
 const start=owner.indexOf('fun inspectExistingLocalRecovery()'),end=owner.indexOf('fun prepareExistingLocalRecovery()',start);assert.ok(start>0&&end>start);
 const method=owner.slice(start,end);for(const token of ['val c = checked()','synchronized(owner.gate)','owner.firstFailure == null','owner.localGenesisInput == null','owner.localGenesisCommand == null','Status.FRESH','original.record == null','NO_LOCAL_INTENT','prepareExistingLocalRecovery()','readPreparedExistingLocalRecovery(input)'])assert.ok(method.includes(token),token);
 assert.doesNotMatch(method,/beginLocalGenesis|openAppPrivate|firstFailure\s*=\s*null/);
 const module=readFileSync(new URL('VeilCryptoEngineModule.kt',root),'utf8');const a=module.indexOf('private fun localRecoveryCheck('),b=module.indexOf('private fun',a+20);const body=module.slice(a,b);
 assert.ok(body.includes('awaitOriginal(current.dispatch'));assert.ok(body.includes('scope.inspectExistingLocalRecovery()'));assert.ok(body.includes('null -> "NO_ORIGINAL_OPERATION"'));
 assert.ok(body.indexOf('retained.complete(checkNotNull(observed))')>body.indexOf('// Receipt.await'));assert.ok(body.includes('owner === current && localRecovery === retained'));
});
test('UI source: retained lifecycle fences setup, welcome scroll resets and disabled inspection has contrast',()=>{
 const app=readFileSync(new URL('../VeilSocialApp.tsx',import.meta.url),'utf8');
 assert.ok(app.includes("if (section === 'chats') welcomeScroll.current?.scrollTo({ y: 0, animated: false });"));
 assert.ok(app.includes('localLifecycle.selected'));assert.ok(app.includes("localEntry.mode !== 'closed'"));assert.ok(!app.includes('(localEntry.showOriginal || accountLoginAttempt.intent !== null)'));
 const panel=readFileSync(new URL('LocalRecoveryPanel.tsx',import.meta.url),'utf8');assert.ok(panel.includes('blocked && styles.buttonDisabledText'));assert.ok(panel.includes('NO_ORIGINAL_OPERATION'));assert.ok(panel.includes('当前没有可检查'));
});
