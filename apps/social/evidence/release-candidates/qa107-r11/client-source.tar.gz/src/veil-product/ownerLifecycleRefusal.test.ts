import test from 'node:test';
import assert from 'node:assert/strict';
import {decodeOwnerLifecycle} from './ownerLifecycle';
const owner={ownerState:'DRAIN_REQUIRED',queued:0,pendingTickets:0,reopenedPendingRows:0,pendingStoreState:'READY',failureRetained:true,nativeBoundary:'REQUIRED',localGenesisAttempted:false,localGenesisStatus:null};
test('OLC-I1 no-owner statement refuses an existing owner, pending preserves it',()=>{
 assert.throws(()=>decodeOwnerLifecycle({closeStatus:'NOT_OPENED',nativeBoundary:'REQUIRED',owner}));
 assert.equal(decodeOwnerLifecycle({closeStatus:'OBSERVATION_PENDING',nativeBoundary:'REQUIRED',owner}).owner?.status,'OBSERVED');
 assert.equal(decodeOwnerLifecycle({closeStatus:'NOT_OPENED',nativeBoundary:'REQUIRED',owner:null}).owner,null);
});
