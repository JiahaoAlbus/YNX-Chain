import assert from 'node:assert/strict';
import test from 'node:test';
import {FirstDeviceEnrollmentGate, decodeEnrollment, type EnrollmentStatus} from './firstDeviceEnrollment';
import {decodeChallenge} from './firstDeviceChallengeBridge';
import {productCopy} from './copy';
const statuses: EnrollmentStatus[] = ['SOURCE_CHECK_PENDING', 'SOURCE_EVIDENCE_UNADMITTED',
  'SOURCE_PROFILE_REQUIRED', 'SOURCE_CHECK_REJECTED', 'SOURCE_CHECK_CANCELED_RETAINED',
  'SOURCE_UNKNOWN_RETAINED', 'SOURCE_NATIVE_INTERFACE_REQUIRED'];
const value = (status: EnrollmentStatus) => ({status, nativeBoundary: 'REQUIRED', deviceAuthorization: 'REQUIRED'});
test('all source observations remain unadmitted in both actual decoders; no data projection', () => {
  for (const status of statuses) {
    assert.equal(decodeEnrollment(value(status)).deviceAuthorization, 'REQUIRED');
    assert.equal(decodeChallenge(value(status)).deviceAuthorization, 'REQUIRED');
    assert.throws(() => decodeEnrollment({...value(status), sourceNonce: 'forbidden'}));
    assert.throws(() => decodeChallenge({...value(status), deviceAuthorization: 'AUTHORIZED'}));
  }
});
test('source states survive remount observation without another prepare or arbitrary inputs', async () => {
  for (const status of statuses) {
    let prepares = 0; let current: EnrollmentStatus = 'CHALLENGE_ISSUED_UNVERIFIED';
    const gate = new FirstDeviceEnrollmentGate(async () => ({
      async observeFirstDeviceEnrollment(...args: unknown[]) { assert.equal(args.length, 0); return value(current); },
      async prepareFirstDeviceEnrollment(...args: unknown[]) { assert.equal(args.length, 0); prepares++; current = status; return value(status); },
    }));
    await gate.observe(); await gate.prepareByUser();
    const off = gate.subscribe(() => {}); off();
    await gate.observe(); await gate.prepareByUser();
    assert.equal(gate.snapshot().result?.status, status);
    assert.equal(prepares, 1); assert.equal(gate.canPrepare(), false);
    current = 'CHALLENGE_ISSUED_UNVERIFIED'; await gate.observe(); await gate.prepareByUser();
    assert.equal(prepares, 1); assert.equal(gate.canPrepare(), false);
  }
});
test('normal bilingual copy does not advertise authorization, cancellation as release, or algorithm choices', () => {
  assert.match(productCopy('en', 'registrationSourceUnadmitted'), /not approved/);
  assert.match(productCopy('zh', 'registrationSourceUnadmitted'), /尚未获批/);
  for (const locale of ['en','zh'] as const) {
    assert.ok(productCopy(locale, 'registrationSourceUnavailable').length > 0);
    assert.ok(productCopy(locale, 'registrationSourceCanceled').length > 0);
    assert.doesNotMatch(productCopy(locale, 'registrationSourceUnadmitted'), /ML-DSA|libsignal|算法/);
  }
});
