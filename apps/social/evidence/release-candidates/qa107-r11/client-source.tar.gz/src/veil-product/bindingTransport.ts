import { accountBindingEndpoint, socialOfficialOrigin, decodeAccountBindingText, type AccountBindingResult } from './accountBinding';
export type BindingRequest = Readonly<{method:'POST';headers:Readonly<{'Content-Type':'application/json'}>;body:string;credentials:'omit';cache:'no-store';redirect:'error';referrerPolicy:'no-referrer';signal:AbortSignal}>;
export type BindingResponse = Pick<Response,'body'|'headers'|'status'|'url'|'redirected'>;
export type BindingFetch = (url:string,init:BindingRequest)=>Promise<BindingResponse>;
export const bindingReadLimits=Object.freeze({maxReads:8257,maxEmptyReads:64,maxConsecutiveEmpty:16});
/** Stop our wait even when provider abort/cancel does not settle its read. */
async function readOwned(reader:ReadableStreamDefaultReader<Uint8Array>,signal:AbortSignal){
  if(signal.aborted)throw new Error('VEIL_BINDING_STOPPED');
  let listener!:()=>void;
  const stopped=new Promise<never>((_,reject)=>{listener=()=>reject(new Error('VEIL_BINDING_STOPPED'));signal.addEventListener('abort',listener,{once:true});});
  const actual=Promise.resolve().then(()=>{if(signal.aborted)throw new Error('VEIL_BINDING_STOPPED');return reader.read();});
  void actual.then(()=>{if(signal.aborted){try{reader.releaseLock();}catch{}}},()=>{});
  try{return await Promise.race([actual,stopped]);}finally{signal.removeEventListener('abort',listener);}
}
let pinnedProvider:Promise<BindingFetch>|null=null;
export function loadPinnedBindingFetch():Promise<BindingFetch>{
  return pinnedProvider ??= import('./bindingFetchProvider').then(module=>module.loadBindingFetch());
}
const failure=(reason:Extract<AccountBindingResult,{kind:'unavailable'}>['reason']):AccountBindingResult=>Object.freeze({kind:'unavailable',reason});
/** Actual production transport helper. Tests pass public streams here, never
 * replacing the normal loader/consumer with a successful auth provider. */
export async function performAccountBinding(token:string,load:()=>Promise<BindingFetch>,origin:string|undefined,timeoutMs=15000):Promise<AccountBindingResult>{
  if(!Number.isInteger(timeoutMs)||timeoutMs<1||timeoutMs>15000)return failure('INVALID_INPUT');
  if(typeof token!=='string'||!token||token.length>8192)return failure('INVALID_INPUT');
  if(origin!==undefined&&origin!==socialOfficialOrigin)return failure('ORIGIN_NOT_ALLOWED');
  let body=JSON.stringify({grantToken:token});token='';
  if(new TextEncoder().encode(body).length>8192)return failure('INVALID_INPUT');
  const abort=new AbortController();let reader:ReadableStreamDefaultReader<Uint8Array>|null=null;
  let responseBody:ReadableStream<Uint8Array>|null=null;let expired=false,bodyPhase=false;
  const now=()=>globalThis.performance?.now()??Date.now();const expires=now()+timeoutMs;
  const isExpired=()=>expired||now()>=expires;
  let cancelled:ReadableStreamDefaultReader<Uint8Array>|ReadableStream<Uint8Array>|null=null;
  const cancel=()=>{
    try{if(!abort.signal.aborted)abort.abort();}catch{}
    const owned=reader??responseBody;
    if(!owned||owned===cancelled)return;
    cancelled=owned;
    try{void owned.cancel().catch(()=>{});}catch{}
  };
  let timer:ReturnType<typeof setTimeout>|undefined;
  // Timer is installed before either the dynamic provider load or fetch starts.
  const deadline=new Promise<AccountBindingResult>(resolve=>{timer=setTimeout(()=>{expired=true;body='';cancel();resolve(failure('TIMEOUT'));},timeoutMs);});
  const actual=(async():Promise<AccountBindingResult>=>{
    try{
      const fetch=await load();if(isExpired())return failure('TIMEOUT');
      const response=await fetch(accountBindingEndpoint,{method:'POST',headers:Object.freeze({'Content-Type':'application/json'}),body,credentials:'omit',cache:'no-store',redirect:'error',referrerPolicy:'no-referrer',signal:abort.signal});body='';
      responseBody=response.body;
      if(isExpired()){cancel();return failure('TIMEOUT');}
      if(response.redirected||response.url!==accountBindingEndpoint){cancel();return failure('INVALID_RESPONSE');}
      if(response.status!==200){cancel();return failure('HTTP_NOT_VERIFIED');}
      if(!/^application\/json(?:\s*;\s*charset=utf-8)?$/i.test(response.headers.get('Content-Type')??'')){cancel();return failure('INVALID_RESPONSE');}
      const length=response.headers.get('Content-Length');if(length!==null&&(!/^\d+$/.test(length)||Number(length)>8192)){cancel();return failure('INVALID_RESPONSE');}
      if(!responseBody){cancel();return failure('TRANSPORT_UNAVAILABLE');}
      bodyPhase=true;reader=responseBody.getReader();const bytes=new Uint8Array(8192);let total=0,reads=0,empty=0,consecutiveEmpty=0;
      while(true){
        if(abort.signal.aborted||isExpired()){cancel();return failure('TIMEOUT');}
        if(++reads>bindingReadLimits.maxReads){cancel();return failure('INVALID_RESPONSE');}
        const part=await readOwned(reader,abort.signal);
        if(abort.signal.aborted||isExpired()){cancel();return failure('TIMEOUT');}if(part.done)break;
        if(!(part.value instanceof Uint8Array)||part.value.byteLength>8192-total){cancel();return failure('INVALID_RESPONSE');}
        if(part.value.byteLength===0){
          if(++empty>bindingReadLimits.maxEmptyReads||++consecutiveEmpty>bindingReadLimits.maxConsecutiveEmpty){cancel();return failure('INVALID_RESPONSE');}
          continue;
        }
        consecutiveEmpty=0;
        bytes.set(part.value,total);total+=part.value.byteLength;
      }
      const metadata=decodeAccountBindingText(new TextDecoder('utf-8',{fatal:true}).decode(bytes.subarray(0,total)));
      if(isExpired()){cancel();return failure('TIMEOUT');}
      return Object.freeze({kind:'metadata',metadata});
    }catch{cancel();return failure(isExpired()?'TIMEOUT':bodyPhase?'INVALID_RESPONSE':'TRANSPORT_UNAVAILABLE');}
    finally{body='';try{reader?.releaseLock();}catch{}}
  })();
  try{return await Promise.race([actual,deadline]);}finally{body='';if(timer!==undefined)clearTimeout(timer);}
}
