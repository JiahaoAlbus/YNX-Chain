import assert from 'node:assert/strict';
import test from 'node:test';
import {AccountLoginGate, accountLoginStatuses, decodeAccountLogin, type AccountLoginModule} from './accountLogin';

const publicResult = (status = 'AWAIT_CALLBACK') => ({status, deviceAuthorization: 'REQUIRED'});
test('strict public login projection rejects authority, secrets, accessors and extra fields', () => {
  for (const status of accountLoginStatuses) {
    const actual = decodeAccountLogin(publicResult(status));
    assert.equal(actual.status, status); assert.equal(actual.deviceAuthorization, 'REQUIRED'); assert.ok(Object.isFrozen(actual));
  }
  for (const raw of [null, [], {}, {...publicResult(), cookie: 'secret'}, {...publicResult(), code: 'code'}, {...publicResult(), subject: 'subject'}, {...publicResult(), deviceAuthorization: 'APPROVED'}, publicResult('AUTHORIZED'), Object.create(publicResult()), {...publicResult(), [Symbol('extra')]: 1}]) assert.throws(() => decodeAccountLogin(raw));
  let touched = false;
  assert.throws(() => decodeAccountLogin({get status() { touched = true; return 'AWAIT_CALLBACK'; }, deviceAuthorization: 'REQUIRED'}));
  assert.equal(touched, false);
});
test('timeout retains physical begin; same intent observes, changed intent and other operations cannot replace it', async () => {
  let resolve!: (value: unknown) => void; let calls = 0;
  const pending = new Promise<unknown>(done => { resolve = done; });
  const module: AccountLoginModule = {beginAccountLogin: async intent => { assert.equal(intent, 'A'); calls++; return pending; }, observeAccountLogin: async () => { throw Error('unexpected observe'); }, cancelAccountLogin: async () => { throw Error('unexpected cancel'); }};
  const gate = new AccountLoginGate(async () => module);
  assert.equal((await gate.execute('begin', 'newIdentityFirstDevice', 1)).status, 'OBSERVATION_PENDING');
  assert.equal(gate.isPending(), true);
  assert.equal((await gate.execute('begin', 'existingIdentityAddDevice', 1)).status, 'BUSY');
  assert.equal((await gate.execute('cancel', 'newIdentityFirstDevice', 1)).status, 'BUSY');
  const observation = gate.execute('begin', 'newIdentityFirstDevice', 1000);
  resolve(publicResult());
  assert.equal((await observation).status, 'AWAIT_CALLBACK'); assert.equal(calls, 1); assert.equal(gate.isPending(), false);
});
test('all four intentions map to native input without fabricating device grant', async () => {
  const calls: string[] = [];
  for (const intent of ['newIdentityFirstDevice', 'existingIdentityAddDevice', 'restoreIdentity', 'revokedDeviceAttempt'] as const) {
    // Separate native owners, not a stateless mock claiming same-owner switching.
    const gate = new AccountLoginGate(async () => ({beginAccountLogin: async value => { calls.push(value); return publicResult('ACCOUNT_OBSERVED'); }, observeAccountLogin: async () => publicResult(), cancelAccountLogin: async () => publicResult('CANCELLED')}));
    assert.equal((await gate.execute('begin', intent)).deviceAuthorization, 'REQUIRED');
    assert.equal((await gate.execute('cancel', intent)).status, 'CANCELLED');
  }
  assert.deepEqual(calls, ['A', 'B', 'C', 'D']);
});
test('missing module is unavailable; invalid result or thrown call preserves review-required uncertainty', async () => {
  assert.equal((await new AccountLoginGate(async () => null).execute('begin', 'newIdentityFirstDevice')).status, 'UNAVAILABLE');
  for (const observeAccountLogin of [async () => ({status: 'AUTHORIZED'}), async () => { throw Error('private detail'); }]) {
    const gate = new AccountLoginGate(async () => ({beginAccountLogin: observeAccountLogin, observeAccountLogin, cancelAccountLogin: observeAccountLogin}));
    assert.deepEqual(await gate.execute('begin', 'newIdentityFirstDevice'), publicResult('REVIEW_REQUIRED'));
    assert.equal(gate.isPending(), false);
  }
});

const cases = ['newIdentityFirstDevice', 'existingIdentityAddDevice', 'restoreIdentity', 'revokedDeviceAttempt'] as const;
function retainedNative(firstStatus = 'OBSERVATION_PENDING') {
  let selected: string | null = null;
  let status = firstStatus;
  const calls: string[] = [];
  const module: AccountLoginModule = {
    beginAccountLogin: async intent => {
      calls.push(`begin:${intent}`);
      if (selected !== null) return publicResult('REFUSED');
      selected = intent;
      return publicResult(status); // Worker/browser still owns selected after this resolves.
    },
    observeAccountLogin: async () => { calls.push(`observe:${selected}`); return publicResult(status); },
    cancelAccountLogin: async () => { calls.push(`cancel:${selected}`); status = 'CANCELLED'; return publicResult(status); },
  };
  return {module, calls, complete: (next: string) => { status = next; }, selected: () => selected};
}

test('immediate snapshot does not unlock A-to-B/C/D intent or redirect observe/cancel', async () => {
  const native = retainedNative(); const gate = new AccountLoginGate(async () => native.module);
  await gate.execute('begin', cases[0]);
  assert.equal(gate.isPending(), false); assert.equal(native.selected(), 'A');
  assert.equal(gate.getSnapshot().intent, cases[0]); assert.equal(gate.getSnapshot().status, 'OBSERVATION_PENDING');
  const retained = gate.getSnapshot();
  for (const other of cases.slice(1)) {
    assert.equal(gate.canSelectIntent(other), false);
    for (const op of ['begin', 'observe', 'cancel'] as const) assert.equal((await gate.execute(op, other)).status, 'BUSY');
  }
  assert.strictEqual(gate.getSnapshot(), retained);
  assert.deepEqual(native.calls, ['begin:A']);
  native.complete('ACCOUNT_OBSERVED');
  assert.equal((await gate.observeOriginal()).status, 'ACCOUNT_OBSERVED');
  assert.equal(gate.getSnapshot().intent, cases[0]);
  await gate.execute('cancel', cases[0]);
  assert.deepEqual(native.calls, ['begin:A', 'observe:A', 'cancel:A']);
  assert.equal(gate.getSnapshot().status, 'CANCELLED');
  assert.equal(gate.canSelectIntent(cases[1]), false);
  await gate.execute('begin', cases[0]); // Programmatic repeat observes, never restarts.
  assert.deepEqual(native.calls, ['begin:A', 'observe:A', 'cancel:A', 'observe:A']);
});

test('each first intent remains original through preflight refusal, cancellation and repeated begin', async () => {
  for (const intent of cases) for (const initial of ['VERIFIED_CALLBACK_REQUIRED', 'REFUSED', 'REVIEW_REQUIRED', 'CLOSED']) {
    const native = retainedNative(initial); const gate = new AccountLoginGate(async () => native.module);
    await gate.execute('begin', intent); await gate.execute('begin', intent);
    await gate.execute('cancel', intent); await gate.execute('begin', intent);
    assert.equal(native.calls.filter(c => c.startsWith('begin:')).length, 1);
    assert.equal(gate.getSnapshot().intent, intent);
    for (const other of cases.filter(value => value !== intent)) assert.equal((await gate.execute('begin', other)).status, 'BUSY');
  }
});

test('late physical result and foreground observation stay with original after subscriber remount', async () => {
  let finish!: (value: unknown) => void;
  const native = retainedNative('AWAIT_CALLBACK'); let loads = 0;
  const module: AccountLoginModule = {...native.module, beginAccountLogin: async intent => {
    await native.module.beginAccountLogin(intent);
    return new Promise(resolve => { finish = resolve; });
  }};
  const gate = new AccountLoginGate(async () => { loads++; return module; });
  let oldNotices = 0; const unmount = gate.subscribe(() => { oldNotices++; });
  assert.equal((await gate.execute('begin', cases[2], 1)).status, 'OBSERVATION_PENDING');
  const pending = gate.getSnapshot(); assert.equal(pending.intent, cases[2]);
  unmount(); const oldCount = oldNotices;
  let remounted = gate.getSnapshot();
  const remove = gate.subscribe(() => { remounted = gate.getSnapshot(); });
  assert.strictEqual(remounted, pending); // Same useSyncExternalStore contract as panel/root.
  assert.equal((await gate.execute('begin', cases[0])).status, 'BUSY');
  const joined = gate.execute('begin', cases[2]);
  finish(publicResult('AWAIT_CALLBACK')); await joined;
  assert.equal(oldNotices, oldCount); assert.equal(remounted.intent, cases[2]); assert.equal(remounted.pending, false);
  native.complete('ACCOUNT_OBSERVED');
  await gate.observeOriginal(); // Same method used on panel mount / AppState active.
  assert.equal(remounted.status, 'ACCOUNT_OBSERVED'); assert.equal(remounted.intent, cases[2]);
  await gate.execute('cancel', cases[2]);
  assert.equal(remounted.status, 'CANCELLED'); assert.equal(remounted.intent, cases[2]);
  remove(); assert.equal(loads, 1); assert.deepEqual(native.calls, ['begin:C', 'observe:C', 'cancel:C']);
});

test('unknown original cannot observe/cancel native and unavailable load never creates a replacement', async () => {
  let loads = 0; const gate = new AccountLoginGate(async () => { loads++; return null; });
  assert.equal((await gate.observeOriginal()).status, 'REVIEW_REQUIRED');
  for (const op of ['observe', 'cancel'] as const) assert.equal((await gate.execute(op, cases[0])).status, 'REVIEW_REQUIRED');
  assert.equal(loads, 0); assert.equal(gate.getSnapshot().intent, null);
  assert.equal((await gate.execute('begin', cases[3])).status, 'UNAVAILABLE');
  await gate.execute('begin', cases[3]); await gate.execute('cancel', cases[3]);
  assert.equal(loads, 1); assert.equal(gate.getSnapshot().intent, cases[3]);
  assert.equal((await gate.execute('begin', cases[0])).status, 'BUSY');
});

test('a late original observe cannot publish under a changed case or replace its pinned module', async () => {
  const native = retainedNative('AWAIT_CALLBACK'); let loads = 0;
  let finish!: (value: unknown) => void;
  const module: AccountLoginModule = {...native.module, observeAccountLogin: () => new Promise(resolve => { finish = resolve; })};
  const gate = new AccountLoginGate(async () => { loads++; return module; });
  await gate.execute('begin', cases[1]);
  assert.equal((await gate.observeOriginal(1)).status, 'OBSERVATION_PENDING');
  for (const other of cases.filter(value => value !== cases[1])) assert.equal((await gate.execute('cancel', other)).status, 'BUSY');
  const joined = gate.observeOriginal(); finish(publicResult('ACCOUNT_OBSERVED')); await joined;
  assert.equal(gate.getSnapshot().intent, cases[1]); assert.equal(gate.getSnapshot().status, 'ACCOUNT_OBSERVED');
  assert.equal(loads, 1); assert.deepEqual(native.calls, ['begin:B']);
});
