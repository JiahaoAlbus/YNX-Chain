import assert from 'node:assert/strict';
import test from 'node:test';
function requiredAt<T>(values: readonly T[], index: number): T {
  const value = values[index];
  assert.ok(value !== undefined, `expected retained row at index ${index}`);
  return value;
}

import { readFileSync } from 'node:fs';
import { VeilProductController } from './productController';
import { failRootOperation, clearAccountFeedback } from './rootFeedback';
import type { VeilCopyKey } from './copy';
import type { VeilProductCommand } from './productModel';
// Fixed public structural DTOs, not a native supplier/account or approval.
const view = (account='public-a') => ({kind:'AUTHORIZED',accountViewRef:account,viewRevision:'public-view',profile:{displayName:'Public QA',publicIdentifier:'public-only'},conversations:[{id:'public-chat',title:'Public QA',preview:'',unreadCount:0}],activeConversationId:'public-chat',messages:[],contacts:[],contactRequests:[],moments:[],devices:[],audiences:[],recoveries:[],actions:['sendMessage','requestContact','reviewRecovery'],localAi:'unsupported'});
function read(c:VeilProductController,account='public-a') {
  const lease=c.beginRead();assert.ok(lease);c.completeRead(lease,{context:lease.context,snapshot:view(account)});c.release(lease);
  assert.equal(c.getSnapshot().snapshot?.kind,'AUTHORIZED');
}
const send:VeilProductCommand={type:'sendMessage',viewRevision:'public-view',conversationId:'public-chat',body:'Fixed public text',replyToMessageId:null};
const contact:VeilProductCommand={type:'requestContact',viewRevision:'public-view',identifier:'public-recipient'};
for(const command of [send,contact]) for(const unrelated of [false,true]) {
  test(`PE-R4-I1 ${command.type} recovery ${unrelated?'unrelated':'empty'} retains same admission and blocks all edited retries`,()=>{
    const c=new VeilProductController();c.activate();read(c);
    const lease=c.beginExecute(command,11);assert.ok(lease);
    const items=unrelated?[{originalOperationRef:'public-unrelated-original',label:'Public unrelated',state:'review-required'}]:[];
    const result=c.completeExecute(lease,{context:lease.context,result:{kind:'recovery',state:{kind:'RECOVERY_REQUIRED',accountViewRef:'public-a',viewRevision:'public-recovery-view',items}}});
    assert.equal(result?.kind,'recovery');c.release(lease);
    if (unrelated) {
      const review=c.beginExecute({type:'reviewRecovery',originalOperationRef:'public-unrelated-original'});assert.ok(review);
      c.completeExecute(review,{context:review.context,result:{kind:'originalReview',originalOperationRef:'public-unrelated-original',resolution:'confirmed',nextStep:'none'}});c.release(review);
      assert.equal(c.getSnapshot().pending.length,1);
      assert.equal(requiredAt(c.getSnapshot().pending, 0).resolution,'unresolved');
      assert.equal(requiredAt(c.getSnapshot().pending, 0).originalOperationRef,null);
    }
    read(c);
    const pending=c.getSnapshot().pending;assert.equal(pending.length,1);
    assert.equal(requiredAt(pending, 0).originalOperationRef,null);assert.equal(requiredAt(pending, 0).localCallId,lease.context.callId);
    assert.equal(requiredAt(pending, 0).accountViewRef,'public-a');assert.equal(requiredAt(pending, 0).viewRevision,'public-view');
    assert.equal(requiredAt(pending, 0).draftRevision,11);assert.equal(requiredAt(pending, 0).action,command.type);
    assert.deepEqual(requiredAt(pending, 0).command,command);assert.equal(requiredAt(pending, 0).disposition,'unknown');assert.equal(requiredAt(pending, 0).resolution,'unresolved');
    assert.equal(c.beginExecute(command,11),null);
    const edited:VeilProductCommand=command.type==='sendMessage'?{...command,body:'Edited public draft'}:{...contact,identifier:'public-edited-recipient'};
    assert.equal(c.beginExecute(edited,12),null);assert.equal(c.beginExecute(command.type==='sendMessage'?contact:send,13),null);
    if(unrelated){
      const review=c.beginExecute({type:'reviewRecovery',originalOperationRef:'public-unrelated-original'});
      // No invented relation to the null-ref original. Fresh view has no such review action target.
      assert.equal(review,null);
    }
    assert.ok(Object.isFrozen(requiredAt(pending, 0)));assert.ok(Object.isFrozen(requiredAt(pending, 0).command));
  });
}
test('PE-R4-I2 actual root failure helper fences deferred A rejection, scope reset and stale finally against B',async()=>{
  const c=new VeilProductController();c.activate();read(c);
  const a=c.beginExecute(send,11);assert.ok(a);
  let feedback:VeilCopyKey|null='queued';const published:(VeilCopyKey|null)[]=[];
  const publish=(value:VeilCopyKey|null)=>{feedback=value;published.push(value);};
  let reject!:(error:Error)=>void;const deferred=new Promise<never>((_,r)=>{reject=r;});
  const work=deferred.catch(()=>failRootOperation(c,a,()=>true,publish)).finally(()=>c.release(a));
  c.invalidate();clearAccountFeedback('public-a',null,publish);
  assert.equal(c.beginRead(),null); // B cannot overlap A's still-owned native work.
  reject(new Error('fixed public A rejection'));assert.equal(await work,false);
  assert.equal(feedback,null);assert.deepEqual(published,[null]);
  read(c,'public-b');clearAccountFeedback(null,'public-b',publish);
  assert.equal(feedback,null);const original=requiredAt(c.getSnapshot().pending, 0);
  assert.equal(original.accountViewRef,'public-a');assert.equal(original.originalOperationRef,null);assert.equal(original.draftRevision,11);
  const b=c.beginExecute(contact,12);assert.ok(b);
  assert.equal(failRootOperation(c,a,()=>true,publish),false);c.release(a);
  assert.equal(feedback,null);assert.equal(c.getSnapshot().busy,true);
  assert.equal(c.getSnapshot().snapshot?.kind,'AUTHORIZED');
  c.release(b);
});
test('PE-R4-I2 helper emits only accepted mounted failure and actual root uses both helpers',()=>{
  const c=new VeilProductController();c.activate();read(c);const lease=c.beginExecute(send,11);assert.ok(lease);
  const output:(VeilCopyKey|null)[]=[];assert.equal(failRootOperation(c,lease,()=>true,v=>output.push(v)),true);
  assert.deepEqual(output,['unknown']);c.release(lease);
  assert.equal(failRootOperation(c,lease,()=>true,v=>output.push(v)),false);assert.deepEqual(output,['unknown']);
  clearAccountFeedback('public-a','public-a',v=>output.push(v));assert.deepEqual(output,['unknown']);
  clearAccountFeedback('public-a','public-b',v=>output.push(v));assert.deepEqual(output,['unknown',null]);
  const root=readFileSync(new URL('../VeilSocialApp.tsx',import.meta.url),'utf8');
  assert.match(root,/failRootOperation\(controller, lease, \(\) => alive.current, setFeedback\)/);
  assert.match(root,/clearAccountFeedback\(draftScope.current, nextScope, setFeedback\)/);
  assert.doesNotMatch(root,/if \(alive.current\) setFeedback\('unknown'\)/);
});
