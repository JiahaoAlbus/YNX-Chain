import test from 'node:test';
import assert from 'node:assert/strict';
import { FirstDeviceEnrollmentGate, type EnrollmentModule } from './firstDeviceEnrollment';

const observed = (status: string) => ({ status, nativeBoundary: 'REQUIRED', deviceAuthorization: 'REQUIRED' });
function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>(done => { resolve = done; });
  return { promise, resolve };
}

test('reentrant enrollment observation retains the original physical call', async () => {
  const original = deferred<unknown>();
  let reads = 0;
  const module: EnrollmentModule = {
    observeFirstDeviceEnrollment() { reads++; return original.promise; },
    async prepareFirstDeviceEnrollment() { throw Error('unexpected prepare'); },
  };
  const gate = new FirstDeviceEnrollmentGate(async () => module);
  let reentered: Promise<unknown> | undefined;
  let once = false;
  const off = gate.subscribe(() => {
    if (gate.snapshot().pending && !once) {
      once = true;
      reentered = gate.observe();
    }
  });
  const first = gate.observe();
  assert.equal(reentered, first);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(reads, 1);
  original.resolve(observed('CHALLENGE_ISSUED_UNVERIFIED'));
  assert.equal((await first).deviceAuthorization, 'REQUIRED');
  off();
});

test('reentrant continue cannot send a second preparation or replace its future', async () => {
  const original = deferred<unknown>();
  let prepares = 0;
  const gate = new FirstDeviceEnrollmentGate(async () => ({
    async observeFirstDeviceEnrollment() { return observed('CHALLENGE_ISSUED_UNVERIFIED'); },
    prepareFirstDeviceEnrollment() { prepares++; return original.promise; },
  }));
  await gate.observe();
  let reentered: Promise<unknown> | undefined;
  let once = false;
  const off = gate.subscribe(() => {
    if (gate.snapshot().pending && !once) { once = true; reentered = gate.prepareByUser(); }
  });
  const first = gate.prepareByUser();
  assert.equal(reentered, first);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(prepares, 1);
  original.resolve(observed('ENROLLMENT_UNKNOWN_RETAINED'));
  assert.equal((await first).status, 'ENROLLMENT_UNKNOWN_RETAINED');
  assert.equal(gate.canPrepare(), false);
  await gate.prepareByUser();
  assert.equal(prepares, 1);
  off();
});

test('a throwing UI subscriber cannot prevent or rewrite the native result', async () => {
  let prepares = 0;
  const gate = new FirstDeviceEnrollmentGate(async () => ({
    async observeFirstDeviceEnrollment() { return observed('CHALLENGE_ISSUED_UNVERIFIED'); },
    async prepareFirstDeviceEnrollment() { prepares++; return observed('NATIVE_PROOF_AUTHORIZATION_REQUIRED'); },
  }));
  gate.subscribe(() => { throw Error('UI observer failed'); });
  await gate.observe();
  const value = await gate.prepareByUser();
  assert.equal(prepares, 1);
  assert.equal(value.status, 'NATIVE_PROOF_AUTHORIZATION_REQUIRED');
  assert.equal(value.deviceAuthorization, 'REQUIRED');
  assert.equal(gate.snapshot().pending, false);
});

test('a rejected original preparation stays unknown and is not retried', async () => {
  let prepares = 0;
  const gate = new FirstDeviceEnrollmentGate(async () => ({
    async observeFirstDeviceEnrollment() { return observed('CHALLENGE_ISSUED_UNVERIFIED'); },
    async prepareFirstDeviceEnrollment() { prepares++; throw Error('original transport outcome unknown'); },
  }));
  await gate.observe();
  assert.equal((await gate.prepareByUser()).status, 'ENROLLMENT_UNKNOWN_RETAINED');
  await gate.observe();
  assert.equal(gate.canPrepare(), false);
  await gate.prepareByUser();
  assert.equal(prepares, 1);
});
