import assert from 'node:assert/strict';import test from 'node:test';import {readFileSync} from 'node:fs';
import {performAccountBinding,type BindingFetch,type BindingResponse,type BindingRequest} from './bindingTransport';import {accountBindingEndpoint,socialOfficialOrigin} from './accountBinding';
const token='PUBLIC_TRANSPORT_TEST_NOT_A_GRANT';
const text=JSON.stringify({status:'ACCOUNT_BOUND',subject:'public-subject',generation:0,deviceAuthorization:'REQUIRED'});
const bytes=(s:string)=>new TextEncoder().encode(s);
function deferred<T>(){let resolve!:(v:T)=>void;let reject!:(e:Error)=>void;const promise=new Promise<T>((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};}
const tick=()=>new Promise<void>(r=>setImmediate(r));
function response(stream:ReadableStream<Uint8Array>,status=200,type='application/json'):Response{const value=new Response(stream,{status,headers:{'Content-Type':type}});Object.defineProperty(value,'url',{value:accountBindingEndpoint});return value;}
const stream=(value=text)=>new ReadableStream<Uint8Array>({start(c){c.enqueue(bytes(value));c.close();}});
const request=(fetch:BindingFetch,ms=100)=>performAccountBinding(token,async()=>fetch,socialOfficialOrigin,ms);
test('r2 public streamed metadata/request privacy: exact body, fixed URL, no ambient credentials/cache/header/query',async()=>{
 let captured!:BindingRequest;let url='';const result=await request(async(u,init)=>{captured=init;url=u;return response(stream());});
 assert.equal(result.kind,'metadata');if(result.kind==='metadata'){assert.equal(result.metadata.generation,0);assert.equal(result.metadata.deviceAuthorization,'REQUIRED');assert.ok(Object.isFrozen(result.metadata));}
 assert.equal(url,accountBindingEndpoint);assert.deepEqual(JSON.parse(captured.body),{grantToken:token});assert.deepEqual(captured.headers,{'Content-Type':'application/json'});assert.equal(captured.credentials,'omit');assert.equal(captured.redirect,'error');assert.equal(captured.cache,'no-store');assert.equal(captured.referrerPolicy,'no-referrer');
 let calls=0;const bad=await performAccountBinding(token,async()=>{calls++;return async()=>response(stream());},'https://public.invalid',100);assert.deepEqual(bad,{kind:'unavailable',reason:'ORIGIN_NOT_ALLOWED'});assert.equal(calls,0);
});
test('r2 deadline precedes hanging dynamic import; late provider never fetches',async()=>{
 const load=deferred<BindingFetch>();let calls=0;const result=await performAccountBinding(token,()=>load.promise,undefined,2);assert.deepEqual(result,{kind:'unavailable',reason:'TIMEOUT'});
 load.resolve(async()=>{calls++;return response(stream());});await tick();assert.equal(calls,0);
 const failed=await performAccountBinding(token,async()=>{throw Error('PUBLIC_IMPORT_FAILURE');},undefined,100);assert.deepEqual(failed,{kind:'unavailable',reason:'TRANSPORT_UNAVAILABLE'});
});
test('r2 deadline cancels hung body, aborts request and cannot publish success after expiry',async()=>{
 let cancelCount=0,signal!:AbortSignal;const body=new ReadableStream<Uint8Array>({cancel(){cancelCount++;}});
 const value=await request(async(_,init)=>{signal=init.signal;return response(body);},2);assert.deepEqual(value,{kind:'unavailable',reason:'TIMEOUT'});assert.equal(signal.aborted,true);await tick();assert.equal(cancelCount,1);
});
test('r2 late headers/body after deadline are cancelled, not metadata',async()=>{
 const headers=deferred<BindingResponse>();let cancelled=0,signal!:AbortSignal;
 const result=await request(async(_,init)=>{signal=init.signal;return headers.promise;},2);assert.equal(result.kind,'unavailable');assert.equal(signal.aborted,true);
 headers.resolve(response(new ReadableStream<Uint8Array>({cancel(){cancelled++;}})));await tick();assert.equal(cancelled,1);assert.deepEqual(result,{kind:'unavailable',reason:'TIMEOUT'});
});
for(const mode of ['oversize-chunk','aggregate-oversize','reader-failure','duplicate-fields','invalid-utf8'] as const){
 test(`r2 ${mode} cancels/aborts and cannot publish metadata`,async()=>{
  let cancelled=0,signal!:AbortSignal;let pulls=0;
  const body=new ReadableStream<Uint8Array>({pull(c){pulls++;if(mode==='reader-failure'){c.error(Error('PUBLIC_READER_FAILURE'));return;}if(mode==='oversize-chunk')c.enqueue(new Uint8Array(8193));else if(mode==='aggregate-oversize'){c.enqueue(new Uint8Array(5000));if(pulls<2)return;}else if(mode==='duplicate-fields')c.enqueue(bytes(text.replace('"generation":0','"generation":0,"generation":1')));else c.enqueue(new Uint8Array([255]));if(mode!=='oversize-chunk'&&mode!=='aggregate-oversize')c.close();},cancel(){cancelled++;}});
  const value=await request(async(_,init)=>{signal=init.signal;return response(body);});assert.deepEqual(value,{kind:'unavailable',reason:'INVALID_RESPONSE'});assert.equal(signal.aborted,true);if(mode==='oversize-chunk'||mode==='aggregate-oversize')assert.equal(cancelled,1);
 });
}
test('r2 TLS reject, HTTP error, redirect, nonJSON and missing stream are fail-closed with cleanup',async()=>{
 assert.deepEqual(await request(async()=>{throw Error('PUBLIC_TLS_REJECTION');}),{kind:'unavailable',reason:'TRANSPORT_UNAVAILABLE'});
 for(const mode of ['http','redirect','non-json','oversized-length','no-stream']){
  let signal!:AbortSignal;const value=await request(async(_,init)=>{signal=init.signal;const r=response(stream(),mode==='http'?403:200,mode==='non-json'?'text/plain':'application/json');if(mode==='redirect')Object.defineProperty(r,'redirected',{value:true});if(mode==='oversized-length')r.headers.set('Content-Length','8193');if(mode==='no-stream')Object.defineProperty(r,'body',{value:null});return r;});assert.equal(value.kind,'unavailable');assert.equal(signal.aborted,true);
 }
});
test('r2 production provider remains actual installed expo/fetch, no global RN fetch/SDK or auth callback seam',()=>{
 const source=readFileSync(new URL('./bindingFetchProvider.ts',import.meta.url),'utf8');assert.match(source,/from 'expo\/fetch'/);assert.match(source,/Platform.OS === 'android'.*VEIL_NATIVE_FETCH_NO_STORE_UNSUPPORTED/);assert.doesNotMatch(source,/globalThis.fetch|Wallet|closeLocalOwner/);
 const client=readFileSync(new URL('./accountBinding.ts',import.meta.url),'utf8');assert.match(client,/performAccountBinding\(grantToken,loadPinnedBindingFetch/);
 const transport=readFileSync(new URL('./bindingTransport.ts',import.meta.url),'utf8');assert.doesNotMatch(transport,/response.text\(|localStorage|AsyncStorage|console\.|disconnect\(/);
});
test('r2 stuck cancellation cleanup cannot hang deadline result or allow late success',async()=>{
 let cancelled=0;const responseBody=new ReadableStream<Uint8Array>({cancel(){cancelled++;return new Promise<void>(()=>{});}});
 const result=await request(async()=>response(responseBody),2);assert.deepEqual(result,{kind:'unavailable',reason:'TIMEOUT'});assert.equal(cancelled,1);
});
