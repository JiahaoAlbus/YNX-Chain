import assert from 'node:assert/strict';
import test from 'node:test';
import { VeilProductController } from './productController';
// Public UI serialization fixtures, NOT a native provider or accepted account.
function view(account='public-a') {return {kind:'AUTHORIZED',accountViewRef:account,viewRevision:'view-a',profile:{displayName:'Public',publicIdentifier:'public'},conversations:[{id:'conv',title:'Public',preview:'',unreadCount:0}],messages:[],activeConversationId:'conv',contacts:[],contactRequests:[],moments:[],devices:[],audiences:[],recoveries:[],actions:['sendMessage','reviewRecovery'],localAi:'unsupported'};}
const command={type:'sendMessage' as const,viewRevision:'view-a',conversationId:'conv',body:'PUBLIC UNSENT FIXTURE',replyToMessageId:null};
function active(){const c=new VeilProductController();c.activate();const read=c.beginRead();assert.ok(read);c.completeRead(read,{context:read.context,snapshot:view()});c.release(read);return c;}
test('original late pending binds reference after remount without publishing or clearing draft',()=>{
 const c=active();const op=c.beginExecute(command,17);assert.ok(op);c.deactivate();c.activate();
 assert.equal(c.beginRead(),null);
 assert.equal(c.completeExecute(op,{context:op.context,result:{kind:'pending',disposition:'queued',originalOperationRef:'original-17'}}),null);
 const p=c.getSnapshot().pending[0];assert.ok(p);assert.equal(p.originalOperationRef,'original-17');assert.equal(p.disposition,'unknown');assert.equal(p.resolution,'unresolved');assert.equal(p.draftRevision,17);assert.deepEqual(p.command,command);
 assert.equal(c.getSnapshot().snapshot,null);c.release(op);
 const read=c.beginRead();assert.ok(read);c.completeRead(read,{context:read.context,snapshot:view()});c.release(read);
 assert.equal(c.beginExecute(command,18),null);assert.ok(c.beginExecute({type:'reviewRecovery',originalOperationRef:'original-17'}));
});
test('late confirmed result retains only original reference, never confirmed outcome/view',()=>{
 const c=active();const op=c.beginExecute(command,2);assert.ok(op);c.invalidate();
 assert.equal(c.completeExecute(op,{context:op.context,result:{kind:'snapshot',snapshot:view(),completion:'confirmed',originalOperationRef:'original-confirmed'}}),null);
 assert.equal(c.getSnapshot().snapshot,null);assert.equal(c.getSnapshot().pending[0]?.originalOperationRef,'original-confirmed');assert.equal(c.getSnapshot().pending[0]?.resolution,'unresolved');assert.equal(c.getSnapshot().pending[0]?.nextStep,'review-only');
});
test('foreign tuple, released flight, and conflicting reference cannot retarget original',()=>{
 const c=active();const op=c.beginExecute(command,3);assert.ok(op);c.invalidate();
 c.completeExecute(op,{context:{...op.context,accountViewRef:'public-b'},result:{kind:'pending',disposition:'unknown',originalOperationRef:'foreign'}});
 assert.equal(c.getSnapshot().pending[0]?.originalOperationRef,null);
 c.completeExecute(op,{context:op.context,result:{kind:'pending',disposition:'unknown',originalOperationRef:'same'}});
 c.completeExecute(op,{context:op.context,result:{kind:'pending',disposition:'unknown',originalOperationRef:'different'}});
 assert.equal(c.getSnapshot().pending[0]?.originalOperationRef,'same');c.release(op);
 c.completeExecute(op,{context:op.context,result:{kind:'pending',disposition:'unknown',originalOperationRef:'released'}});
 assert.equal(c.getSnapshot().pending[0]?.originalOperationRef,'same');
});
test('invalidation cannot erase a reference already received before original flight release',()=>{
 const c=active();const op=c.beginExecute(command,4);assert.ok(op);
 c.completeExecute(op,{context:op.context,result:{kind:'pending',disposition:'unknown',originalOperationRef:'captured'}});
 assert.doesNotThrow(()=>c.invalidate());assert.equal(c.getSnapshot().pending[0]?.originalOperationRef,'captured');
});
test('deferred real controller result remains original across inactive UI, no second operation',async()=>{
 const c=active();const op=c.beginExecute(command,5);assert.ok(op);
 let done!:(v:unknown)=>void;const pending=new Promise<unknown>(r=>{done=r;});let calls=0;
 const actual=pending.then(raw=>{calls++;return c.completeExecute(op,raw);}).finally(()=>c.release(op));
 c.deactivate();assert.equal(c.beginExecute(command,6),null);
 done({context:op.context,result:{kind:'pending',disposition:'unknown',originalOperationRef:'deferred'}});assert.equal(await actual,null);
 assert.equal(calls,1);assert.equal(c.getSnapshot().pending[0]?.originalOperationRef,'deferred');assert.equal(c.getSnapshot().snapshot,null);
});
