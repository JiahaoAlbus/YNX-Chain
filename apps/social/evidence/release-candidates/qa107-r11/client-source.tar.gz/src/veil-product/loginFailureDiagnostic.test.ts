import test from 'node:test';
import assert from 'node:assert/strict';
import {decodeLoginFailureDiagnostic, loginFailureReasons} from './loginFailureDiagnostic';
import {decodeReturnLinkDiagnostic} from './returnLinkDiagnostic';
import {AccountLoginGate} from './accountLogin';
const refused = {state:'CLIENT_REFUSED',operation:'START',reason:'HTTP_REFUSED',httpStatus:404,remoteOutcomeUnknown:true,exception:'NONE'};
const none = {state:'NOT_RECORDED',operation:'NONE',reason:'NONE',httpStatus:0,remoteOutcomeUnknown:false,exception:'NONE'};
const tick=()=>new Promise(resolve=>setImmediate(resolve));
test('exact failure schema allows only enums, integer HTTP status and boolean; rejects payload/getters',()=>{
  for(const reason of loginFailureReasons) assert.equal(decodeLoginFailureDiagnostic({...refused,reason}).reason,reason);
  assert.deepEqual(decodeLoginFailureDiagnostic(none),none);
  for(const raw of [{...refused,body:'FORBIDDEN'},{...refused,message:'FORBIDDEN'},{...refused,reason:'FORBIDDEN'},{...refused,httpStatus:'404'},{...refused,httpStatus:NaN},{...refused,httpStatus:600},{...refused,httpStatus:1},{...refused,remoteOutcomeUnknown:'true'},{...refused,exception:'Error: FORBIDDEN'},{...none,httpStatus:404},null,[]]) assert.throws(()=>decodeLoginFailureDiagnostic(raw));
  let touched=false;assert.throws(()=>decodeLoginFailureDiagnostic({...refused,get reason(){touched=true;return 'HTTP_REFUSED';}}));assert.equal(touched,false);
  assert.deepEqual(decodeLoginFailureDiagnostic({state:'EXCEPTION',operation:'LOGIN_WORKER',reason:'NONE',httpStatus:0,remoteOutcomeUnknown:true,exception:'OTHER_EXCEPTION'}),{state:'EXCEPTION',operation:'LOGIN_WORKER',reason:'NONE',httpStatus:0,remoteOutcomeUnknown:true,exception:'OTHER_EXCEPTION'});
});
test('return link requires explicit completed full check set; partial is not passed',()=>{
  const d={state:'PASSED',check:'ALL_CHECKS',outcome:'PASSED',completedChecks:12,totalChecks:12};assert.deepEqual(decodeReturnLinkDiagnostic(d),d);
  for(const raw of [{...d,completedChecks:11},{...d,totalChecks:11},{...d,state:'NOT_STARTED'},{...d,callback:'FORBIDDEN'}])assert.throws(()=>decodeReturnLinkDiagnostic(raw));
  assert.equal(decodeReturnLinkDiagnostic({state:'CHECKING',check:'NOT_CHECKED',outcome:'NOT_CHECKED',completedChecks:12,totalChecks:12}).state,'CHECKING');
});
test('normal Gate observes diagnostic progression, keeps original first failure over cancel and remount; no network status hook',async()=>{
  let begins=0,observes=0,cancels=0;let failure:unknown=none;
  let link:unknown={state:'CHECKING',check:'NOT_CHECKED',outcome:'NOT_CHECKED',completedChecks:4,totalChecks:12};
  const reply=(status:string)=>({status,deviceAuthorization:'REQUIRED'});
  const gate=new AccountLoginGate(async()=>({beginAccountLogin:async()=>{begins++;return reply('OBSERVATION_PENDING');},observeAccountLogin:async()=>{observes++;return reply('REVIEW_REQUIRED');},cancelAccountLogin:async()=>{cancels++;return reply('CANCELLED');},readAccountLoginDiagnostic:async()=>link,readAccountLoginFailureDiagnostic:async()=>failure}));
  await gate.execute('begin','newIdentityFirstDevice');await tick();assert.equal(gate.getSnapshot().diagnostic?.state,'CHECKING');
  failure=refused;link={state:'PASSED',check:'ALL_CHECKS',outcome:'PASSED',completedChecks:12,totalChecks:12};
  await gate.observeOriginal();await tick();assert.deepEqual(gate.getSnapshot().failureDiagnostic,refused);assert.equal(gate.getSnapshot().diagnostic?.state,'PASSED');
  const remove=gate.subscribe(()=>{});remove();const first=gate.getSnapshot().failureDiagnostic;
  failure={...refused,reason:'CANCELLED',httpStatus:0};await gate.execute('cancel','newIdentityFirstDevice');await tick();await gate.observeOriginal();await tick();assert.strictEqual(gate.getSnapshot().failureDiagnostic,first);assert.equal(begins,1);assert.equal(cancels,1);assert.equal(observes,2);assert.equal(gate.canSelectIntent('restoreIdentity'),false);
});
test('delayed diagnostic failure neither overrides original status nor leaks exception text',async()=>{
  const gate=new AccountLoginGate(async()=>({beginAccountLogin:async()=>({status:'REVIEW_REQUIRED',deviceAuthorization:'REQUIRED'}),observeAccountLogin:async()=>({status:'REVIEW_REQUIRED',deviceAuthorization:'REQUIRED'}),cancelAccountLogin:async()=>null,readAccountLoginFailureDiagnostic:async()=>{throw Error('FORBIDDEN_URL_TOKEN_BODY');}}));
  await gate.execute('begin','newIdentityFirstDevice');await tick();assert.equal(gate.getSnapshot().status,'REVIEW_REQUIRED');assert.equal(gate.getSnapshot().failureDiagnostic,undefined);assert.equal(JSON.stringify(gate.getSnapshot()).includes('FORBIDDEN'),false);
});
