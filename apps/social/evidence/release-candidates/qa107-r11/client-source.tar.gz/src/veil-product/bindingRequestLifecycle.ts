/** Client-side request lifetime only, NOT a native ABI/account/source epoch.
 * Actual final supplier must decode its own epoch/handle and terminal receipt
 * before calling these local identity checks. No module lookup or grant here.
 */
export type LocalBindingAttempt = Readonly<{localEpoch:number;sequence:number;signal:AbortSignal}>;
type SupplierTuple<E,H> = Readonly<{requestEpoch:E;requestHandle:H}>;
export class BindingRequestLifecycle<E,H> {
  private epoch=1;
  private sequence=0;
  private active:LocalBindingAttempt|null=null;
  private abort:AbortController|null=null;
  private supplier:SupplierTuple<E,H>|null=null;
  begin():LocalBindingAttempt|null {
    if(this.active||this.epoch>=Number.MAX_SAFE_INTEGER||this.sequence>=Number.MAX_SAFE_INTEGER)return null;
    this.abort=new AbortController();
    const attempt=Object.freeze({localEpoch:this.epoch,sequence:++this.sequence,signal:this.abort.signal});
    this.active=attempt;this.supplier=null;return attempt;
  }
  isCurrent(attempt:LocalBindingAttempt):boolean {
    return this.active===attempt&&attempt.localEpoch===this.epoch&&!attempt.signal.aborted;
  }
  /** Values arrive only AFTER final supplier-specific bounded validation.
   * Generic types avoid pretending its provisional return fields are final. */
  associateSupplier(attempt:LocalBindingAttempt,requestEpoch:E,requestHandle:H):boolean {
    if(!this.isCurrent(attempt))return false;
    if(this.supplier)return Object.is(this.supplier.requestEpoch,requestEpoch)&&Object.is(this.supplier.requestHandle,requestHandle);
    this.supplier=Object.freeze({requestEpoch,requestHandle});return true;
  }
  acceptsReceipt(attempt:LocalBindingAttempt,requestEpoch:E,requestHandle:H):boolean {
    return this.isCurrent(attempt)&&this.supplier!==null&&Object.is(this.supplier.requestEpoch,requestEpoch)&&Object.is(this.supplier.requestHandle,requestHandle);
  }
  invalidate():void {
    if(this.epoch<Number.MAX_SAFE_INTEGER)++this.epoch;
    // Abort is a cancellation request, NEVER evidence of native termination.
    try{this.abort?.abort();}catch{}
    // Keep active and supplier until actual terminal ownership is confirmed.
  }
  /** Final adapter must call only after real terminal receipt/actual operation
   * settlement; never from a UI timeout, cancel request, unmount or advance. */
  settleActual(attempt:LocalBindingAttempt):boolean {
    if(this.active!==attempt)return false;
    this.active=null;this.abort=null;this.supplier=null;return true;
  }
}
