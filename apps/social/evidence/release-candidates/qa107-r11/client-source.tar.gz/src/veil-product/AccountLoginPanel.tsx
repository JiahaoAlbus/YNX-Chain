import React, {useEffect, useState, useSyncExternalStore} from 'react';
import {AppState, Pressable, Text, View} from 'react-native';
import type {AccountEntryCase} from './accountEntry';
import {accountLoginGate} from './accountLogin';
import {productCopy, type VeilLocale} from './copy';
import {styles} from './theme';

const copy = {
  en: {
    begin: 'Sign in', create: 'Create or sign in to an account', observe: 'Check sign-in', cancel: 'Cancel sign-in',
    original: 'Original sign-in', retained: 'This flow stays with its original case, including after cancellation or a return here. Switching requires a separate supported recovery flow.',
    UNAVAILABLE: 'Secure sign-in is not available in this build.',
    VERIFIED_CALLBACK_REQUIRED: 'The secure return link is not ready for this installation. Sign-in has not started.',
    AUTHORIZATION_OPENED: 'Continue in the secure browser, then return here.',
    AWAIT_CALLBACK: 'Waiting for your browser sign-in. No device access has been granted.',
    REVIEW_REQUIRED: 'The original sign-in needs review. It has not been replaced or retried.',
    ACCOUNT_OBSERVED: 'Your account was identified. Device approval is still required before messaging.',
    CANCELLED: 'Sign-in was cancelled locally. This does not confirm remote session revocation.',
    REFUSED: 'Sign-in could not continue. No device access has been granted.',
    BUSY: 'The original sign-in operation is still running.',
    OBSERVATION_PENDING: 'Still waiting for the original sign-in operation. It has not been restarted.',
    CLOSED: 'This sign-in attempt is closed. No device access has been granted.',
  },
  zh: {
    begin: '登录', create: '创建或登录账户', observe: '查看登录进度', cancel: '取消登录',
    original: '原登录流程', retained: '此流程始终归属原入口，取消或返回此页面也不会切换。更换入口需另有受支持的恢复流程。',
    UNAVAILABLE: '当前构建的安全登录暂不可用。',
    VERIFIED_CALLBACK_REQUIRED: '此安装版本的安全返回链接尚未就绪，尚未发起登录。',
    AUTHORIZATION_OPENED: '请在安全浏览器中继续登录，然后返回这里。',
    AWAIT_CALLBACK: '正在等待浏览器登录结果，尚未授予设备访问权限。',
    REVIEW_REQUIRED: '原登录操作需要检查，未替换或重试。',
    ACCOUNT_OBSERVED: '已识别你的账户，聊天前仍需完成设备批准。',
    CANCELLED: '已在本地取消登录，这不代表远端会话已撤销。',
    REFUSED: '登录暂不能继续，未授予设备访问权限。',
    BUSY: '原登录操作仍在进行。',
    OBSERVATION_PENDING: '仍在等待原登录操作，未重新发起。',
    CLOSED: '此次登录已关闭，未授予设备访问权限。',
  },
} as const;

export function AccountLoginPanel({intent, locale, disabled}: {intent: AccountEntryCase; locale: VeilLocale; disabled: boolean}) {
  const [details, setDetails] = useState(false);
  const attempt = useSyncExternalStore(accountLoginGate.subscribe, accountLoginGate.getSnapshot, accountLoginGate.getSnapshot);
  const run = (operation: 'begin' | 'observe' | 'cancel') => {
    const original = accountLoginGate.getSnapshot().intent;
    if (operation === 'begin' && original !== null) return;
    if (operation !== 'begin' && original === null) return;
    void accountLoginGate.execute(operation, original ?? intent);
  };
  useEffect(() => {
    const observe = () => {
      if (accountLoginGate.getSnapshot().intent !== null && !accountLoginGate.isPending()) void accountLoginGate.observeOriginal();
    };
    observe(); // Remount observes SAME retained intent; never creates a begin.
    const subscription = AppState.addEventListener('change', state => {
      if (state === 'active') observe();
    });
    return () => { subscription.remove(); }; // Gate owns attempt/feedback beyond this panel.
  }, []);
  const text = copy[locale];
  return <View>
    {attempt.intent && <><Text style={styles.strong}>{text.original}: {productCopy(locale, attempt.intent)}</Text><Text style={styles.caption}>{text.retained}</Text></>}
    <View style={styles.wrapRow}>{(['begin', 'observe', 'cancel'] as const).map(operation => {
      if (operation !== 'begin' && attempt.intent === null) return null;
      const label = operation === 'begin' && intent === 'newIdentityFirstDevice' ? text.create : text[operation];
      const unavailable = disabled || attempt.pending || (operation === 'begin' ? attempt.intent !== null : attempt.intent === null);
      return (
      <Pressable key={operation} accessibilityRole="button" accessibilityLabel={label}
        disabled={unavailable} accessibilityState={{disabled: unavailable}}
        onPress={() => run(operation)} style={[styles.button, unavailable && styles.buttonDisabled, unavailable && {opacity: 1}]}>
        <Text style={[styles.buttonText, unavailable && {color: '#344b59'}]}>{label}</Text>
      </Pressable>);
    })}</View>
    {attempt.status && <Text accessibilityLiveRegion="polite" style={styles.text}>{text[attempt.status]}</Text>}
    {(attempt.diagnostic || attempt.failureDiagnostic) && <>
      <Pressable accessibilityRole="button" onPress={() => setDetails(value => !value)}><Text style={styles.text}>{productCopy(locale, 'diagnostics')}</Text></Pressable>
      {details && <>
        <Text style={styles.caption}>{locale === 'zh' ? '仅显示本进程记录的首个诊断，不会重发请求；旧进程未保存的原因无法补回。返回链接通过不代表账户或设备已授权。' : 'First diagnostic recorded in this process only. No request is retried and missing details from an old process cannot be recovered. Passing return-link checks is not account or device approval.'}</Text>
        {attempt.diagnostic && <Text selectable style={styles.caption}>{locale === 'zh' ? '返回链接' : 'Return link'}: {attempt.diagnostic.state} ({attempt.diagnostic.completedChecks}/{attempt.diagnostic.totalChecks}) / {attempt.diagnostic.check} / {attempt.diagnostic.outcome}</Text>}
        {attempt.failureDiagnostic && <Text selectable style={styles.caption}>{locale === 'zh' ? '原登录诊断' : 'Original sign-in diagnostic'}: {attempt.failureDiagnostic.state} / {attempt.failureDiagnostic.operation} / {attempt.failureDiagnostic.reason} / HTTP {attempt.failureDiagnostic.httpStatus} / {locale === 'zh' ? '远端结果未知' : 'Remote outcome unknown'}: {String(attempt.failureDiagnostic.remoteOutcomeUnknown)} / {attempt.failureDiagnostic.exception}</Text>}
      </>}
    </>}
  </View>;
}
