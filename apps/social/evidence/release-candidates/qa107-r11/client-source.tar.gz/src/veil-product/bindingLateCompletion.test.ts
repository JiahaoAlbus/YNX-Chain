import assert from 'node:assert/strict';import test from 'node:test';
import {NativeBindingAdapter,type NativeBindingHttpModule,type NativeBindingReply} from './bindingNativeAdapter';
import {accountBindingInput,requestAccountBinding} from './accountBinding';
const token='PUBLIC_LATE_CALLBACK_NOT_A_GRANT';const body=JSON.stringify({status:'ACCOUNT_BOUND',subject:'public-subject',generation:0,deviceAuthorization:'REQUIRED'});
function deferred<T>(){let resolve!:(v:T)=>void;const promise=new Promise<T>(r=>{resolve=r;});return {promise,resolve};}
const tick=()=>new Promise<void>(r=>setImmediate(r));
test('outgate DTO before switch with deferred postawait epoch read cannot publish after actual advance barrier',async()=>{
 const finalRead=deferred<string>();let epoch='1',reads=0,cancelled=0,sends=0;
 const module:NativeBindingHttpModule={readBindingHttpEpoch:()=>++reads===3?finalRead.promise:Promise.resolve(epoch),reserveBindingHttp:async()=>String(sends+1),sendBindingHttp:async(handle,e)=>{sends++;return {epoch:e,handle,status:200,body,error:null};},cancelBindingHttp:async()=>{cancelled++;return false;},advanceBindingHttpContext:async()=>{epoch='2';return epoch;}};
 const adapter=new NativeBindingAdapter(async()=>module),old=adapter.request(token,100);await tick();assert.equal(reads,3);assert.equal(sends,1);
 await adapter.advanceContext();assert.equal(cancelled,1);finalRead.resolve('1');assert.equal((await old).kind,'unavailable');
 const next=await adapter.request(token,100);assert.equal(next.kind,'metadata');assert.equal(sends,2);assert.equal(cancelled,1);
});
test('outgate callback after deadline and account switch is refused and never relabelled with new request epoch',async()=>{
 const late=deferred<NativeBindingReply>();let epoch='1',sent=0;const handles:string[]=[];const cancelled:string[]=[];
 const module:NativeBindingHttpModule={readBindingHttpEpoch:async()=>epoch,reserveBindingHttp:async()=>String(handles.length+1),sendBindingHttp:(handle,e)=>{handles.push(handle);sent++;return sent===1?late.promise:Promise.resolve({epoch:e,handle,status:200,body,error:null});},cancelBindingHttp:async h=>{cancelled.push(h);return false;},advanceBindingHttpContext:async()=>{epoch='2';return epoch;}};
 const adapter=new NativeBindingAdapter(async()=>module);const result=await adapter.request(token,3);assert.deepEqual(result,{kind:'unavailable',reason:'TIMEOUT'});await adapter.advanceContext();assert.deepEqual(cancelled,['1']);assert.equal((await adapter.request(token,2)).kind,'unavailable');
 late.resolve({epoch:'1',handle:'1',status:200,body,error:null});await tick();assert.deepEqual(result,{kind:'unavailable',reason:'TIMEOUT'});
 const next=await adapter.request(token,100);assert.equal(next.kind,'metadata');assert.deepEqual(handles,['1','2']);assert.deepEqual(cancelled,['1']);
});
test('normal production path stays NOT_ADMITTED for both native review deltas and lacks approved callback',async()=>{
 assert.equal(accountBindingInput.nativeTransport,'NORMAL_NATIVE_ADAPTER_MATCHED_NOT_ADMITTED_RUNTIME_CALLBACK_NOT_VERIFIED');assert.equal(accountBindingInput.status,'UNAVAILABLE_AUTH_PRODUCER');assert.deepEqual(await requestAccountBinding(token),{kind:'unavailable',reason:'TRANSPORT_UNAVAILABLE'});
});
