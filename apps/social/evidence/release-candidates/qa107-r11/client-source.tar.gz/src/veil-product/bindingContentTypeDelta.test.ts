import assert from 'node:assert/strict';
import {test} from 'node:test';
import {NativeBindingAdapter,decodeNativeBindingReply,type NativeBindingHttpModule,type NativeBindingReply} from './bindingNativeAdapter';
import {accountBindingInput,requestAccountBinding} from './accountBinding';

const token='PUBLIC_MIME_CONTROL_NOT_A_GRANT';
const refused:NativeBindingReply={epoch:'1',handle:'1',status:200,body:null,error:'HTTP_CONTENT_TYPE_REFUSED'};
function deferred<T>(){let resolve!:(value:T)=>void;const promise=new Promise<T>(r=>{resolve=r;});return {promise,resolve};}
const tick=()=>new Promise<void>(resolve=>setImmediate(resolve));

test('actual five-field MIME refusal preserves status and rejects body/header inventions',()=>{
  const result=decodeNativeBindingReply(refused,'1','1');
  assert.equal(result.status,200);assert.equal(result.body,null);assert.equal(result.error,'HTTP_CONTENT_TYPE_REFUSED');assert.ok(Object.isFrozen(result));
  assert.equal(decodeNativeBindingReply({...refused,status:415},'1','1').status,415);
  for(const raw of [{...refused,body:'{}'},{...refused,contentType:'application/json'},{...refused,error:'HTTP_CONTENT_TYPE_OK'},{...refused,handle:'2'},{...refused,epoch:'2'}])assert.throws(()=>decodeNativeBindingReply(raw,'1','1'));
});

test('MIME refusal never parses metadata and cancels only original handle even when cancel returns false',async()=>{
  const cancelled:string[]=[];
  const module:NativeBindingHttpModule={readBindingHttpEpoch:async()=> '1',reserveBindingHttp:async()=> '1',sendBindingHttp:async()=>refused,cancelBindingHttp:async handle=>{cancelled.push(handle);return false;},advanceBindingHttpContext:async()=> '2'};
  const adapter=new NativeBindingAdapter(async()=>module);
  assert.deepEqual(await adapter.request(token),{kind:'unavailable',reason:'TRANSPORT_UNAVAILABLE'});
  assert.deepEqual(cancelled,['1']);
});

test('captured MIME refusal delivered after context advance cannot skip postawait current-context fence',async()=>{
  let epoch='1',reads=0;
  const send=deferred<NativeBindingReply>(),cancelled:string[]=[];
  const module:NativeBindingHttpModule={readBindingHttpEpoch:async()=>{reads++;return epoch;},reserveBindingHttp:async()=> '1',sendBindingHttp:()=>send.promise,cancelBindingHttp:async handle=>{cancelled.push(handle);return false;},advanceBindingHttpContext:async()=>{epoch='2';return epoch;}};
  const adapter=new NativeBindingAdapter(async()=>module),pending=adapter.request(token);
  await tick();assert.equal(reads,2);
  await adapter.advanceContext();
  send.resolve(refused);
  assert.deepEqual(await pending,{kind:'unavailable',reason:'TRANSPORT_UNAVAILABLE'});
  assert.equal(reads,2);assert.deepEqual(cancelled,['1']);
});

test('new supplier error matching is not admission or an approved auth producer',async()=>{
  assert.equal(accountBindingInput.status,'UNAVAILABLE_AUTH_PRODUCER');
  assert.equal(accountBindingInput.deployment,'NOT_DEPLOYED');
  assert.equal(accountBindingInput.nativeTransport,'NORMAL_NATIVE_ADAPTER_MATCHED_NOT_ADMITTED_RUNTIME_CALLBACK_NOT_VERIFIED');
  assert.deepEqual(await requestAccountBinding(token),{kind:'unavailable',reason:'TRANSPORT_UNAVAILABLE'});
});
