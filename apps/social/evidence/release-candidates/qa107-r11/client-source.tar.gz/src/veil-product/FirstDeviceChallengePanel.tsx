import { FirstDeviceEnrollmentPanel } from './FirstDeviceEnrollmentPanel';
import React, {useEffect, useSyncExternalStore} from 'react';
import {AppState, Pressable, Text, View} from 'react-native';
import {firstDeviceChallengeGate as gate, challengeCopy} from './firstDeviceChallenge';
import {accountLoginGate} from './accountLogin';
import {localAuthenticationGate} from './localDeviceSetup';
import {productCopy, type VeilLocale} from './copy';
import {styles} from './theme';

export function FirstDeviceChallengePanel({locale, disabled}: {locale: VeilLocale; disabled: boolean}) {
  const state = useSyncExternalStore(gate.subscribe, gate.getSnapshot, gate.getSnapshot);
  const login = useSyncExternalStore(accountLoginGate.subscribe, accountLoginGate.getSnapshot, accountLoginGate.getSnapshot);
  const keys = useSyncExternalStore(localAuthenticationGate.subscribe, localAuthenticationGate.getSnapshot, localAuthenticationGate.getSnapshot);
  const t = (key: Parameters<typeof productCopy>[1]) => productCopy(locale, key);
  useEffect(() => {
    const observe = () => { if (!gate.getSnapshot().pending) void gate.observe(); };
    observe(); // mounting or prerequisite changes NEVER Issue/cancel
    const subscription = AppState.addEventListener('change', value => { if (value === 'active') observe(); });
    const timer = setInterval(() => {
      const s = gate.getSnapshot();
      if (AppState.currentState === 'active' && ['OBSERVATION_PENDING', 'CHALLENGE_PENDING', 'CHALLENGE_CANCEL_PENDING'].includes(s.result?.status ?? '')) observe();
    }, 5000);
    return () => { clearInterval(timer); subscription.remove(); }; // retain gate/call
  }, [login.status, keys.result?.status]);
  return <View style={styles.card}>
    <Text style={styles.strong}>{t('registrationTitle')}</Text>
    <Text style={styles.text}>{t('registrationDetail')}</Text>
    <View style={styles.wrapRow}>
      <Pressable accessibilityRole="button" accessibilityLabel={t('registrationContinue')} disabled={disabled || !gate.canContinue()} accessibilityState={{disabled: disabled || !gate.canContinue()}} style={[styles.button, (disabled || !gate.canContinue()) && styles.buttonDisabled]} onPress={() => { void gate.continueByUser(); }}><Text style={styles.buttonText}>{t('registrationContinue')}</Text></Pressable>
      <Pressable accessibilityRole="button" accessibilityLabel={t('registrationObserve')} disabled={state.pending} accessibilityState={{disabled: state.pending}} style={[styles.button, state.pending && styles.buttonDisabled]} onPress={() => { void gate.observe(); }}><Text style={styles.buttonText}>{t('registrationObserve')}</Text></Pressable>
      <Pressable accessibilityRole="button" accessibilityLabel={t('registrationCancel')} disabled={disabled || !gate.canCancel()} accessibilityState={{disabled: disabled || !gate.canCancel()}} style={[styles.button, (disabled || !gate.canCancel()) && styles.buttonDisabled]} onPress={() => { void gate.cancelByUser(); }}><Text style={styles.buttonText}>{t('registrationCancel')}</Text></Pressable>
    </View>
    <Text accessibilityLiveRegion="polite" style={styles.text}>{t(state.pending ? 'registrationPending' : state.result ? challengeCopy[state.result.status] : 'registrationReady')}</Text>
    {state.cancelUnconfirmed && <Text style={styles.caption}>{t('registrationCancelUnconfirmed')}</Text>}
  <FirstDeviceEnrollmentPanel locale={locale} disabled={disabled} />
</View>;
}
