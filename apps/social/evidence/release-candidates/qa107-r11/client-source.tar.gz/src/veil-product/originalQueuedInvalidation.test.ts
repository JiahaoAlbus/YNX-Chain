import assert from 'node:assert/strict';
import test from 'node:test';
import {VeilProductController,retainPendingOriginals} from './productController';
// Public structural DTO only; no authenticated native provider or message.
const view=()=>({kind:'AUTHORIZED',accountViewRef:'public-a',viewRevision:'view-a',profile:{displayName:'Public',publicIdentifier:'public'},conversations:[{id:'conv',title:'Public',preview:'',unreadCount:0}],messages:[],activeConversationId:'conv',contacts:[],contactRequests:[],moments:[],devices:[],audiences:[],recoveries:[],actions:['sendMessage','reviewRecovery'],localAi:'unsupported'});
const command={type:'sendMessage' as const,viewRevision:'view-a',conversationId:'conv',body:'PUBLIC UNSENT',replyToMessageId:null};
for(const event of ['invalidate','deactivate'] as const)test(`OBR-I1 captured queued -> ${event} -> monotone unknown, exact original`,()=>{
 const c=new VeilProductController();c.activate();const r=c.beginRead();assert.ok(r);c.completeRead(r,{context:r.context,snapshot:view()});c.release(r);
 const op=c.beginExecute(command,9);assert.ok(op);const pending=(ref:string)=>({context:op.context,result:{kind:'pending',disposition:'queued',originalOperationRef:ref}});
 c.completeExecute(op,pending('captured'));assert.equal(c.getSnapshot().pending[0]?.disposition,'queued');
 const original=c.getSnapshot().pending[0]!;c[event]();
 const check=()=>{assert.deepEqual(c.getSnapshot().pending[0],{...original,disposition:'unknown'});assert.equal(c.getSnapshot().snapshot,null);assert.equal(c.beginExecute(command,10),null);};
 check();c.invalidate();check();assert.equal(c.completeExecute(op,pending('captured')),null);check();assert.equal(c.completeExecute(op,pending('conflict')),null);check();
 c.release(op);c.activate();const refresh=c.beginRead();assert.ok(refresh);c.completeRead(refresh,{context:refresh.context,snapshot:view()});c.release(refresh);assert.equal(c.beginExecute(command,10),null);
 const row=c.getSnapshot().pending[0]!;assert.equal(row.resolution,'unresolved');assert.equal(row.nextStep,'review-only');
 const rows=c.getSnapshot().pending;assert.equal(retainPendingOriginals(rows,{...row,disposition:'queued'}),rows);
 assert.throws(()=>retainPendingOriginals(rows,{...row,originalOperationRef:'conflict'}),/VEIL_PENDING_ASSOCIATION_INVALID/);
});
