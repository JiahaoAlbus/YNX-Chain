import assert from 'node:assert/strict';import test from 'node:test';
import {BindingRequestLifecycle} from './bindingRequestLifecycle';import {VeilProductController} from './productController';
function deferred<T>(){let resolve!:(v:T)=>void;const promise=new Promise<T>(r=>{resolve=r;});return {promise,resolve};}
test('local request lifecycle fences exact attempt and supplier tuple without interpreting auth generation',()=>{
 const fence=new BindingRequestLifecycle<number,string>();const a=fence.begin();assert.ok(a);assert.equal(fence.begin(),null);assert.ok(Object.isFrozen(a));
 assert.equal(fence.acceptsReceipt(a,0,'PUBLIC_REQUEST_A'),false);
 assert.equal(fence.associateSupplier(a,0,'PUBLIC_REQUEST_A'),true);assert.equal(fence.associateSupplier(a,0,'PUBLIC_REQUEST_A'),true);
 assert.equal(fence.associateSupplier(a,1,'PUBLIC_REQUEST_A'),false);assert.equal(fence.associateSupplier(a,0,'PUBLIC_REQUEST_B'),false);
 assert.equal(fence.acceptsReceipt(a,0,'PUBLIC_REQUEST_A'),true);assert.equal(fence.acceptsReceipt(a,1,'PUBLIC_REQUEST_A'),false);assert.equal(fence.acceptsReceipt(a,0,'PUBLIC_REQUEST_B'),false);
 assert.equal(fence.settleActual(a),true);assert.equal(fence.acceptsReceipt(a,0,'PUBLIC_REQUEST_A'),false);
});
test('cancellation/account invalidation retain admission until real completion, then stale finally cannot release newer attempt',async()=>{
 const fence=new BindingRequestLifecycle<number,string>();const a=fence.begin();assert.ok(a);fence.associateSupplier(a,7,'PUBLIC_REQUEST_A');
 const physical=deferred<void>();let accepted:boolean|undefined;
 const work=physical.promise.then(()=>{accepted=fence.acceptsReceipt(a,7,'PUBLIC_REQUEST_A');}).finally(()=>fence.settleActual(a));
 fence.invalidate();assert.equal(a.signal.aborted,true);assert.equal(fence.begin(),null);assert.equal(fence.acceptsReceipt(a,7,'PUBLIC_REQUEST_A'),false);assert.equal(fence.associateSupplier(a,7,'PUBLIC_REQUEST_A'),false);
 physical.resolve();await work;assert.equal(accepted,false);
 const b=fence.begin();assert.ok(b);fence.associateSupplier(b,8,'PUBLIC_REQUEST_B');assert.equal(fence.settleActual(a),false);assert.equal(fence.begin(),null);assert.equal(fence.acceptsReceipt(b,8,'PUBLIC_REQUEST_B'),true);assert.equal(fence.acceptsReceipt(b,7,'PUBLIC_REQUEST_A'),false);
});
test('repeated invalidation/unmount does not manufacture account state or mutate product controller',()=>{
 const controller=new VeilProductController();const before=controller.getSnapshot();const fence=new BindingRequestLifecycle<number,string>();const a=fence.begin();assert.ok(a);
 fence.associateSupplier(a,0,'PUBLIC_REQUEST_ZERO');fence.invalidate();fence.invalidate();assert.equal(fence.begin(),null);assert.equal(controller.getSnapshot(),before);assert.equal(before.snapshot,null);assert.equal(fence.settleActual(a),true);
 const b=fence.begin();assert.ok(b);assert.ok(b.localEpoch>a.localEpoch);assert.equal(fence.acceptsReceipt(b,0,'PUBLIC_REQUEST_ZERO'),false);
});
