import assert from 'node:assert/strict';
import test from 'node:test';
import { bindEnrollmentModule, decodeEnrollment, FirstDeviceEnrollmentGate, type EnrollmentStatus } from './firstDeviceEnrollment';
import { decodeChallenge } from './firstDeviceChallengeBridge';
import { productCopy } from './copy';
const value = (status: EnrollmentStatus) => ({ status, nativeBoundary: 'REQUIRED', deviceAuthorization: 'REQUIRED' });
function deferred<T>() { let resolve!: (v: T) => void; const promise = new Promise<T>(r => { resolve = r; }); return { promise, resolve }; }

test('actual adapter only forwards fixed zero-argument native methods with original receiver', async () => {
  const calls: string[] = [];
  const native = {
    async prepareFirstDeviceEnrollment(...args: unknown[]) { assert.equal(this, native); assert.equal(args.length, 0); calls.push('prepare'); return value('ENROLLMENT_PENDING'); },
    async observeFirstDeviceEnrollment(...args: unknown[]) { assert.equal(this, native); assert.equal(args.length, 0); calls.push('observe'); return value('CHALLENGE_ISSUED_UNVERIFIED'); },
  };
  const module = bindEnrollmentModule(native)!;
  await module.observeFirstDeviceEnrollment(); await module.prepareFirstDeviceEnrollment();
  assert.deepEqual(calls, ['observe', 'prepare']); assert.equal(bindEnrollmentModule({}), null);
});

test('mount/foreground observation does not prepare; explicit continuation prepares only once', async () => {
  let prepares = 0; let observes = 0;
  const gate = new FirstDeviceEnrollmentGate(async () => ({
    async observeFirstDeviceEnrollment() { observes++; return value('CHALLENGE_ISSUED_UNVERIFIED'); },
    async prepareFirstDeviceEnrollment() { prepares++; return value('NATIVE_PROOF_AUTHORIZATION_REQUIRED'); },
  }));
  await gate.observe(); await gate.observe(); assert.equal(prepares, 0); assert.equal(gate.canPrepare(), true);
  assert.equal((await gate.prepareByUser()).status, 'NATIVE_PROOF_AUTHORIZATION_REQUIRED');
  await gate.prepareByUser(); assert.equal(prepares, 1); assert.equal(observes, 3);
  await gate.observe(); assert.equal(gate.canPrepare(), false); await gate.prepareByUser(); assert.equal(prepares, 1);
});

test('physical future survives unsubscribe/remount and duplicate click; late result stays original', async () => {
  const late = deferred<unknown>(); let prepares = 0;
  const gate = new FirstDeviceEnrollmentGate(async () => ({
    async observeFirstDeviceEnrollment() { return value('CHALLENGE_ISSUED_UNVERIFIED'); },
    prepareFirstDeviceEnrollment() { prepares++; return late.promise; },
  }));
  await gate.observe(); const first = gate.prepareByUser(); const second = gate.prepareByUser(); assert.equal(first, second);
  const off = gate.subscribe(() => {}); off(); const remount = gate.observe(); assert.equal(remount, first);
  await new Promise(r => setImmediate(r)); assert.equal(prepares, 1); assert.equal(gate.snapshot().pending, true);
  late.resolve(value('NATIVE_PROOF_AUTHORIZATION_REQUIRED')); await first;
  assert.equal(gate.snapshot().result?.status, 'NATIVE_PROOF_AUTHORIZATION_REQUIRED'); assert.equal(gate.canPrepare(), false);
});

test('original cancel or expiry observed during preflight forbids prepare', async () => {
  for (const state of ['CHALLENGE_CANCEL_PENDING', 'CHALLENGE_CANCELED', 'ENROLLMENT_EXPIRED_RETAINED', 'ORIGINAL_A_LOGIN_REQUIRED'] as const) {
    let calls = 0; let reads = 0;
    const gate = new FirstDeviceEnrollmentGate(async () => ({
      async observeFirstDeviceEnrollment() { return value(++reads === 1 ? 'CHALLENGE_ISSUED_UNVERIFIED' : state); },
      async prepareFirstDeviceEnrollment() { calls++; return value('ENROLLMENT_PENDING'); },
    }));
    await gate.observe(); assert.equal((await gate.prepareByUser()).status, state); assert.equal(calls, 0);
  }
});

test('UNKNOWN from invocation/decoder never enables replacement prepare', async () => {
  let calls = 0;
  const gate = new FirstDeviceEnrollmentGate(async () => ({
    async observeFirstDeviceEnrollment() { return value('CHALLENGE_ISSUED_UNVERIFIED'); },
    async prepareFirstDeviceEnrollment() { calls++; throw Error('PUBLIC_FIXTURE'); },
  }));
  await gate.observe(); assert.equal((await gate.prepareByUser()).status, 'ENROLLMENT_UNKNOWN_RETAINED');
  await gate.observe(); await gate.prepareByUser(); assert.equal(calls, 1); assert.equal(gate.canPrepare(), false);
});

test('strict projection never admits secret/source/policy fields, accessors, non-REQUIRED boundary', () => {
  for (const bad of [null, {}, { ...value('ENROLLMENT_PENDING'), operation: 'not-exportable' },
    { ...value('ENROLLMENT_PENDING'), deviceAuthorization: 'AUTHORIZED' },
    { ...value('ENROLLMENT_PENDING'), get status() { throw Error('ACCESSOR_MUST_NOT_RUN'); } }]) assert.throws(() => decodeEnrollment(bad));
  for (const state of ['ENROLLMENT_PENDING', 'NATIVE_PROOF_AUTHORIZATION_REQUIRED', 'ENROLLMENT_COMMITTED_UNVERIFIED'] as const) {
    assert.equal(decodeEnrollment(value(state)).deviceAuthorization, 'REQUIRED');
    assert.equal(decodeChallenge(value(state)).status, state);
  }
});

test('both existing locale dictionaries keep issued registration distinct from device authorization', () => {
  assert.match(productCopy('en', 'registrationIssued'), /not|still|incomplete/i);
  assert.match(productCopy('zh', 'registrationIssued'), /未|仍/);
  assert.notEqual(productCopy('en', 'registrationContinue'), productCopy('zh', 'registrationContinue'));
});

test('missing normal native exports fail closed without alternate client or native owner', async () => {
  let loads = 0;
  const gate = new FirstDeviceEnrollmentGate(async () => { loads++; return null; });
  assert.equal((await gate.observe()).status, 'UNAVAILABLE'); await gate.prepareByUser(); await gate.observe();
  assert.equal(loads, 1); assert.equal(gate.canPrepare(), false);
});
