import assert from 'node:assert/strict';
import test from 'node:test';
import {decodeLocalDeviceSetup,localDeviceSetupStatuses,LocalDeviceSetupGate} from './localDeviceSetup';
const reply=(status='LOCAL_INITIALIZATION_PENDING')=>({status,nativeBoundary:'REQUIRED',deviceAuthorization:'REQUIRED'});
test('local setup results are exact diagnostics, never authority',()=>{
 for(const status of localDeviceSetupStatuses){const value=decodeLocalDeviceSetup(reply(status));assert.ok(Object.isFrozen(value));assert.equal(value.deviceAuthorization,'REQUIRED');}
 for(const delta of [{status:'AUTHORIZED'},{status:'OBSERVATION_TIMEOUT'},{nativeBoundary:'READY'},{deviceAuthorization:'APPROVED'},{privateKey:'forbidden'}])assert.throws(()=>decodeLocalDeviceSetup({...reply(),...delta}));
 let invoked=false;const raw=Object.defineProperty(reply(),'status',{enumerable:true,get(){invoked=true;return 'LOCAL_INITIALIZATION_PENDING';}});assert.throws(()=>decodeLocalDeviceSetup(raw));assert.equal(invoked,false);
});
test('observation timeout retains exact native call and original locale',async()=>{
 let finish!:(raw:unknown)=>void;const pending=new Promise<unknown>(resolve=>{finish=resolve;});let loads=0,calls=0;
 const gate=new LocalDeviceSetupGate(async()=>{loads++;return {initializeLocalDevice:async locale=>{calls++;assert.equal(locale,'zh');return pending;}};});
 assert.equal((await gate.observe('zh',2)).status,'OBSERVATION_TIMEOUT');
 assert.equal((await gate.observe('en',2)).status,'OBSERVATION_TIMEOUT');
 assert.equal(loads,1);assert.equal(calls,1);
 const last=gate.observe('en',100);finish(reply());assert.equal((await last).status,'LOCAL_INITIALIZATION_PENDING');assert.equal(calls,1);
});
test('missing module, rejection and invalid reply do not publish success',async()=>{
 for(const load of [async()=>null,async()=>{throw Error('test loader');},async()=>({initializeLocalDevice:async()=>{throw Error('test native');}}),async()=>({initializeLocalDevice:async()=>reply('AUTHORIZED')})])assert.equal((await new LocalDeviceSetupGate(load).observe('en',100)).status,'UNAVAILABLE');
 const gate=new LocalDeviceSetupGate(async()=>null);await assert.rejects(gate.observe('en',0));await assert.rejects(gate.observe('en',120001));
});
