import assert from 'node:assert/strict';import test from 'node:test';
import {performAccountBinding,bindingReadLimits,type BindingRequest} from './bindingTransport';import {accountBindingEndpoint,decodeAccountBindingText} from './accountBinding';
const publicToken='PUBLIC_RESIDUAL_TEST_NOT_A_GRANT';const text=JSON.stringify({status:'ACCOUNT_BOUND',subject:'public-subject',generation:0,deviceAuthorization:'REQUIRED'});const bytes=(s:string)=>new TextEncoder().encode(s);
const tick=()=>new Promise<void>(r=>setImmediate(r));
function response(body:ReadableStream<Uint8Array>,status=200,contentType='application/json',length?:string){const r=new Response(body,{status,headers:{'Content-Type':contentType}});Object.defineProperty(r,'url',{value:accountBindingEndpoint});if(length)r.headers.set('Content-Length',length);return r;}
const invoke=(body:ReadableStream<Uint8Array>,ms=100)=>performAccountBinding(publicToken,async()=>async()=>response(body),undefined,ms);
test('AB-C1 empty reads within independent bound followed by real metadata succeed without chunk inventory',async()=>{
 let pulls=0;const body=new ReadableStream<Uint8Array>({pull(c){if(++pulls<=8)c.enqueue(new Uint8Array());else{c.enqueue(bytes(text));c.close();}}},{highWaterMark:0});assert.equal((await invoke(body)).kind,'metadata');assert.equal(pulls,9);
});
test('AB-C1 immediate endless empty work terminates independently of scheduler timeout',async()=>{
 let pulls=0,cancels=0;const body=new ReadableStream<Uint8Array>({pull(c){pulls++;c.enqueue(new Uint8Array());},cancel(){cancels++;}},{highWaterMark:0});const result=await invoke(body,1000);assert.deepEqual(result,{kind:'unavailable',reason:'INVALID_RESPONSE'});assert.equal(pulls,bindingReadLimits.maxConsecutiveEmpty+1);assert.equal(cancels,1);
});
test('AB-C1 aggregate empty work interspersed with progress is independently bounded',async()=>{
 let pulls=0,cancels=0;const body=new ReadableStream<Uint8Array>({pull(c){pulls++;c.enqueue(pulls%2===0?bytes(' '):new Uint8Array());},cancel(){cancels++;}},{highWaterMark:0});assert.deepEqual(await invoke(body,1000),{kind:'unavailable',reason:'INVALID_RESPONSE'});assert.equal(pulls,bindingReadLimits.maxEmptyReads*2+1);assert.equal(cancels,1);
});
test('AB-C1 own read wait stops on timeout when provider cancellation never propagates',async()=>{
 let controller!:ReadableStreamDefaultController<Uint8Array>;let reads=0,cancels=0,releases=0;const body=new ReadableStream<Uint8Array>({start(c){controller=c;}},{highWaterMark:0});const publicResponse=response(body);const actual=body.getReader();
 Object.defineProperty(body,'getReader',{value:()=>({read:()=>{reads++;return actual.read();},cancel:()=>{cancels++;return new Promise<void>(()=>{});},releaseLock:()=>{releases++;actual.releaseLock();}})});
 const result=await performAccountBinding(publicToken,async()=>async()=>publicResponse,undefined,3);assert.deepEqual(result,{kind:'unavailable',reason:'TIMEOUT'});await tick();assert.equal(reads,1);assert.equal(cancels,1);assert.ok(releases>=1);
 controller.enqueue(bytes(text));controller.close();await tick();assert.equal(reads,1);assert.deepEqual(result,{kind:'unavailable',reason:'TIMEOUT'});
});
for(const mode of ['http','content-type','content-length'] as const)test(`AB-C2 ${mode} early refusal aborts and cancels once while cleanup rejects or hangs`,async()=>{
 for(const cleanup of ['reject','hang']){
  let cancels=0,aborts=0;const body=new ReadableStream<Uint8Array>({cancel(){cancels++;return cleanup==='reject'?Promise.reject(Error('PUBLIC_CANCEL_FAILURE')):new Promise<void>(()=>{});}},{highWaterMark:0});
  const result=await performAccountBinding(publicToken,async()=>async(_,init:BindingRequest)=>{init.signal.addEventListener('abort',()=>aborts++);return response(body,mode==='http'?503:200,mode==='content-type'?'text/plain':'application/json',mode==='content-length'?'8193':undefined);},undefined,100);
  assert.deepEqual(result,{kind:'unavailable',reason:mode==='http'?'HTTP_NOT_VERIFIED':'INVALID_RESPONSE'});await tick();assert.equal(cancels,1);assert.equal(aborts,1);
 }
});
test('AB-C2 read rejection after small chunk preserves primary, bounded cancel and reader release',async()=>{
 let reads=0,cancels=0,releases=0,aborts=0;const body=new ReadableStream<Uint8Array>({},{highWaterMark:0});
 Object.defineProperty(body,'getReader',{value:()=>({read:()=>++reads===1?Promise.resolve({done:false,value:bytes('{')}):Promise.reject(Error('PUBLIC_READ_ERROR')),cancel:()=>{cancels++;return Promise.reject(Error('PUBLIC_SECONDARY_CANCEL_ERROR'));},releaseLock:()=>{releases++;}})});
 const result=await performAccountBinding(publicToken,async()=>async(_,init)=>{init.signal.addEventListener('abort',()=>aborts++);return response(body);},undefined,100);assert.deepEqual(result,{kind:'unavailable',reason:'INVALID_RESPONSE'});await tick();assert.equal(reads,2);assert.equal(cancels,1);assert.equal(aborts,1);assert.equal(releases,1);
});
test('AB-C3 strict JSON rejects NBSP and other nonJSON whitespace at every delimiter',()=>{
 for(const ws of ['\u00a0','\uFEFF','\u2028','\v','\f'])for(const candidate of [ws+text,text.replace('"status":','"status"'+ws+':'),text.replace('"ACCOUNT_BOUND",','"ACCOUNT_BOUND"'+ws+','),text+ws])assert.throws(()=>decodeAccountBindingText(candidate));
});
test('AB-C3 all legal JSON whitespace accepts, string whitespace preserved and escaped duplicate names reject',()=>{
 for(const ws of [' ','\t','\r','\n',' \t\r\n'])assert.equal(decodeAccountBindingText(ws+text.replaceAll(':',ws+':'+ws).replaceAll(',',ws+','+ws)+ws).generation,0);
 assert.equal(decodeAccountBindingText(text.replace('public-subject','public\u00a0subject')).subject,'public\u00a0subject');
 assert.throws(()=>decodeAccountBindingText(text.replace('"generation":0','"generation":0,"\\u0067eneration":0')));
});
