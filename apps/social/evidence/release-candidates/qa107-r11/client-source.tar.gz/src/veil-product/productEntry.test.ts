import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import { en, zh, productCopy, productLocale } from './copy';
import { veilProductNativeConsumer, VeilProductUnavailableError } from './nativeConsumer';
import { messageStatusKey, productActionDisabled, productLimits, validateProductCommand, type VeilProductCommand } from './productModel';
import { createLocalePreferences, VEIL_LOCALE_KEY } from './localePreferences';
import { VEIL_MATRIX_EVENT, type VeilMatrixContent } from '../veilMatrixTransport';
import type { VeilCallContext } from './productBoundary';

let publicCallSequence = 0;
function publicCall(command?: VeilProductCommand): VeilCallContext {
  return { callId: ++publicCallSequence, epoch: 1, action: command?.type ?? 'readSnapshot', accountViewRef: command ? 'public-account' : null, viewRevision: command ? ('viewRevision' in command ? command.viewRevision : 'public-view') : null };
}

const commands: readonly VeilProductCommand[] = [
  { type: 'openConversation', viewRevision: 'public-view', conversationId: 'public-room' },
  { type: 'sendMessage', viewRevision: 'public-view', conversationId: 'public-room', body: 'public plaintext draft', replyToMessageId: null },
  { type: 'selectAttachment', viewRevision: 'public-view', conversationId: 'public-room' },
  { type: 'sendAttachment', viewRevision: 'public-view', conversationId: 'public-room', selectionReference: 'public-selection', caption: '' },
  { type: 'openAttachment', viewRevision: 'public-view', conversationId: 'public-room', messageId: 'public-message', attachmentReference: 'public-attachment' },
  { type: 'requestContact', viewRevision: 'public-view', identifier: 'public-user' },
  { type: 'acceptContact', viewRevision: 'public-view', requestId: 'public-request' },
  { type: 'publishMoment', viewRevision: 'public-view', body: 'public moment draft', audienceId: 'public-audience' },
  { type: 'reviewDevice', viewRevision: 'public-view', deviceId: 'public-device-label' },
  { type: 'setLocalAi', viewRevision: 'public-view', preference: 'on' },
  { type: 'reviewRecovery', originalOperationRef: 'public-original' },
];

test('Installed consumer returns unavailable snapshot, never an authorized sample or provider', async () => {
  const value = (await veilProductNativeConsumer.readSnapshot(publicCall())).snapshot;
  assert.equal(value.kind, 'UNAVAILABLE');
  assert.deepEqual(Object.keys(value).sort(), ['gaps', 'kind', 'localOwner']);
  assert.ok(Object.isFrozen(value));
  assert.ok(Object.isFrozen(veilProductNativeConsumer));
  assert.equal('perform' in veilProductNativeConsumer, false);
  for (const command of commands) assert.equal(productActionDisabled(value, command.type), true);
});

test('Bounded typed local commands carry real inputs but public ids/revisions cannot grant success', async () => {
  for (const command of commands) {
    assert.equal(validateProductCommand(command), null);
    assert.deepEqual((await veilProductNativeConsumer.execute(command, publicCall(command))).result, { kind: 'error', code: 'UNAVAILABLE' });
  }
});

test('Invalid drafts are bounded and keep typed errors, including extra Boolean grant/proof fields', async () => {
  const base = { type: 'sendMessage', viewRevision: 'public-view', conversationId: 'public-room', body: 'public draft', replyToMessageId: null } as const;
  for (const body of ['', ' ', 'x'.repeat(productLimits.body + 1), '\u0000']) {
    assert.deepEqual((await veilProductNativeConsumer.execute({ ...base, body }, publicCall(base))).result, { kind: 'error', code: 'INPUT_INVALID', field: 'body' });
  }
  assert.deepEqual(validateProductCommand({ ...base, viewRevision: '' }), { kind: 'error', code: 'INPUT_INVALID', field: 'viewRevision' });
  assert.deepEqual(validateProductCommand({ ...base, grant: true } as VeilProductCommand), { kind: 'error', code: 'INPUT_INVALID', field: 'command' });
  assert.deepEqual(validateProductCommand({ ...base, proof: 'public-not-a-grant' } as VeilProductCommand), { kind: 'error', code: 'INPUT_INVALID', field: 'command' });
  assert.deepEqual(validateProductCommand({ type: 'requestContact', viewRevision: 'public-view', identifier: 'x'.repeat(productLimits.identifier + 1) }), { kind: 'error', code: 'INPUT_INVALID', field: 'identifier' });
  assert.deepEqual(validateProductCommand({ type: 'publishMoment', viewRevision: 'public-view', body: 'public draft', audienceId: '' }), { kind: 'error', code: 'INPUT_INVALID', field: 'audienceId' });
});

test('Normal consumer preserves pre-await read context and rejects command accessors without evaluating them', async () => {
  const context = publicCall();
  const expected = { ...context };
  const pending = veilProductNativeConsumer.readSnapshot(context);
  Object.assign(context, { callId: context.callId + 1000, accountViewRef: 'mutated-account' });
  assert.deepEqual((await pending).context, expected);
  let getters = 0;
  const command = { type: 'sendMessage', viewRevision: 'public-view', conversationId: 'public-room', body: 'public draft', replyToMessageId: null } as const;
  const malicious = { ...command };
  Object.defineProperty(malicious, 'body', { enumerable: true, get() { getters++; return 'public secret'; } });
  await assert.rejects(veilProductNativeConsumer.execute(malicious, publicCall(command)), /BOUNDARY_INVALID/);
  assert.equal(getters, 0);
});

test('Queued/unknown submissions never display delivered/read, even if contradictory receipt fields arrive', () => {
  for (const delivery of ['unconfirmed', 'delivered', 'read'] as const) {
    assert.equal(messageStatusKey({ submission: 'queued', delivery }), 'queued');
    assert.equal(messageStatusKey({ submission: 'unknown', delivery }), 'unknown');
  }
  assert.equal(messageStatusKey({ submission: 'confirmed', delivery: 'unconfirmed' }), 'confirmed');
  assert.equal(messageStatusKey({ submission: 'confirmed', delivery: 'delivered' }), 'delivered');
});

test('Null, locked and recovery-required views do not enable message/contact mutations', () => {
  for (const value of [null, { kind: 'LOCKED' } as const, { kind: 'RECOVERY_REQUIRED', accountViewRef: 'public-account', viewRevision: 'public-view', items: [] } as const]) {
    for (const command of commands.filter(item => item.type !== 'reviewRecovery')) assert.equal(productActionDisabled(value, command.type), true);
  }
});

test('Consumer reuses actual checked opaque selector, refuses retired/invalid events, and creates no received row', async () => {
  const descriptor: VeilMatrixContent = {
    version: 2, suite: 'signal-session-0.104.0', ciphertext_type: 2,
    sender_message_id: '00000000-0000-4000-8000-000000000001',
    ciphertext: { url: 'mxc://public.example/opaque', sha256: '0'.repeat(64), size: 1 },
  };
  await assert.rejects(veilProductNativeConsumer.receiveOpaqueEvent(VEIL_MATRIX_EVENT, JSON.stringify(descriptor)), error => {
    assert.ok(error instanceof VeilProductUnavailableError);
    assert.equal(error.operation, 'receiveMessage');
    return true;
  });
  await assert.rejects(veilProductNativeConsumer.receiveOpaqueEvent(VEIL_MATRIX_EVENT, JSON.stringify({ ...descriptor, plaintext: 'public-extra' })), /VEIL_MATRIX_EVENT_INVALID/);
  await assert.rejects(veilProductNativeConsumer.receiveOpaqueEvent('m.room.encrypted', 'not-json'), /VEIL_LEGACY_CORE_RETIRED/);
  await assert.rejects(veilProductNativeConsumer.receiveOpaqueEvent('m.room.message', '{}'), /VEIL_PRODUCT_EVENT_NOT_ENCRYPTED/);
});

test('Owned locale persistence uses only en/zh namespace and serializes overlapping writes', async () => {
  const writes: Array<[string, string]> = [];
  let stored: string | null = null;
  const preferences = createLocalePreferences({
    async read(key) { assert.equal(key, VEIL_LOCALE_KEY); return stored; },
    async write(key, value) { writes.push([key, value]); await Promise.resolve(); stored = value; },
  });
  assert.equal(await preferences.read(), null);
  await Promise.all([preferences.write('zh'), preferences.write('en')]);
  assert.deepEqual(writes, [[VEIL_LOCALE_KEY, 'zh'], [VEIL_LOCALE_KEY, 'en']]);
  assert.equal(await preferences.read(), 'en');
  stored = 'not-a-locale';
  assert.equal(await preferences.read(), null);
});

test('Failed locale write does not suppress later preference persistence', async () => {
  let attempts = 0;
  const writes: string[] = [];
  const preferences = createLocalePreferences({
    async read() { return null; },
    async write(_key, value) { if (++attempts === 1) throw new Error('public-preference-failure'); writes.push(value); },
  });
  await assert.rejects(preferences.write('zh'), /public-preference-failure/);
  await preferences.write('en');
  assert.deepEqual(writes, ['en']);
});

test('Owned English/Chinese copy stays complete and distinguishes plaintext/uncertain outcomes', () => {
  assert.deepEqual(Object.keys(en).sort(), Object.keys(zh).sort());
  for (const key of Object.keys(en) as Array<keyof typeof en>) assert.ok(productCopy('en', key).trim() && productCopy('zh', key).trim());
  assert.equal(productLocale('zh-Hans'), 'zh');
  assert.equal(productLocale(undefined), 'en');
  assert.match(en.aiDetail, /authorized plaintext/);
  assert.match(zh.aiDetail, /授权明文/);
});

test('Same normal root binds every form, consumes real read models, and offers no fake provider or optimistic receipt', () => {
  const root = readFileSync(new URL('../VeilSocialApp.tsx', import.meta.url), 'utf8');
  const consumer = readFileSync(new URL('./nativeConsumer.ts', import.meta.url), 'utf8');
  assert.doesNotMatch(root + consumer, /from\s+['"][^'"]*(?:chatCrypto|nativeMatrix|walletAuth|\/api)['"]/);
  assert.doesNotMatch(root + consumer, /NativeMatrixConsumer|NativeModules|requireNativeModule|fetch\(/);
  assert.match(root, /export default function VeilSocialApp\(\)/);
  assert.match(root, /require\('\.\.\/assets\/ynx-original-logo\.png'\)/);
  assert.match(root, /width >= 880/);
  const inputs = [...root.matchAll(/<TextInput\b[\s\S]*?\/>/g)];
  assert.equal(inputs.length, 4);
  for (const [input] of inputs) { assert.match(input, /value=\{/); assert.match(input, /onChangeText=\{/); assert.match(input, /maxLength=\{/); }
  assert.match(root, /veilProductNativeConsumer\.execute\(command, lease\.context\)/);
  assert.match(root, /viewRevision: ready\.viewRevision, conversationId, body, replyToMessageId: replyTo/);
  assert.match(root, /result\.completion === 'confirmed'/);
  assert.match(root, /diagnostics && snapshot\?\.kind === 'UNAVAILABLE'/);
  assert.match(root, /localeRevision\.current === preferenceVersion/);
  assert.match(root, /draftScope\.current/);
});
