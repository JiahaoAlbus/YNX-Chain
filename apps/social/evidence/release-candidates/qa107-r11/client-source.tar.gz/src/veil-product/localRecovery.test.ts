import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {LocalRecoveryGate, decodeRecovery, recoveryStatuses} from './localRecovery';

const reply = (status = 'CIPHERTEXT_HELD_UNVERIFIED') => ({status, nativeBoundary: 'REQUIRED', deviceAuthorization: 'REQUIRED'});
test('no automatic operation on subscribe/remount; explicit call once', async () => {
  let calls = 0;
  const gate = new LocalRecoveryGate(async () => ({beginLocalRecoveryCheck: async () => { calls++; return reply(); }, observeLocalRecoveryCheck: async () => { throw Error('unexpected'); }}));
  const stop = gate.subscribe(() => {}); stop(); gate.subscribe(() => {});
  assert.equal(calls, 0);
  assert.equal((await gate.inspect()).status, 'CIPHERTEXT_HELD_UNVERIFIED');
  await gate.inspect();
  assert.equal(calls, 1);
  assert.equal(gate.getSnapshot().result?.deviceAuthorization, 'REQUIRED');
});
test('timeout/concurrent/remount retains physical call and late result', async () => {
  let complete!: (value: unknown) => void;
  let calls = 0;
  const gate = new LocalRecoveryGate(async () => ({beginLocalRecoveryCheck: () => { calls++; return new Promise(resolve => { complete = resolve; }); }, observeLocalRecoveryCheck: async () => { throw Error('unexpected observe'); }}));
  assert.equal((await gate.inspect(1)).status, 'OBSERVATION_PENDING');
  assert.equal(gate.getSnapshot().pending, true);
  const stop = gate.subscribe(() => {}); stop();
  const same = gate.inspect(1000);
  complete(reply());
  assert.equal((await same).status, 'CIPHERTEXT_HELD_UNVERIFIED');
  assert.equal(calls, 1);
  assert.equal(gate.getSnapshot().pending, false);
});
test('native observation deadline uses observe, never a second begin or loader', async () => {
  let begins = 0, observes = 0, loads = 0;
  const gate = new LocalRecoveryGate(async () => { loads++; return {
    beginLocalRecoveryCheck: async () => { begins++; return reply('OBSERVATION_PENDING'); },
    observeLocalRecoveryCheck: async () => { observes++; return reply('UNKNOWN_RETAINED'); },
  }; });
  await gate.inspect();
  await gate.inspect();
  await gate.inspect();
  assert.deepEqual([begins, observes, loads], [1, 1, 1]);
  assert.equal(gate.getSnapshot().result?.status, 'UNKNOWN_RETAINED');
});
test('linkage/bridge rejection stays retained without retry', async () => {
  let calls = 0;
  const gate = new LocalRecoveryGate(async () => ({beginLocalRecoveryCheck: async () => { calls++; throw Error('missing JNI'); }, observeLocalRecoveryCheck: async () => reply()}));
  assert.equal((await gate.inspect()).status, 'RECOVERY_REQUIRED');
  await gate.inspect(); assert.equal(calls, 1);
});
test('missing module never substitutes a provider', async () => {
  let loads = 0;
  const gate = new LocalRecoveryGate(async () => { loads++; return null; });
  assert.equal((await gate.inspect()).status, 'UNAVAILABLE');
  await gate.inspect(); assert.equal(loads, 1);
});
test('strict metadata rejects authority, extra IDs and accessors', () => {
  for (const status of recoveryStatuses) assert.equal(decodeRecovery(reply(status)).status, status);
  for (const value of [reply('RECOVERED'), {...reply(), deviceAuthorization: 'APPROVED'}, {...reply(), ids: 'public'}, [], null,
    {get status() { throw Error('getter executed'); }, nativeBoundary: 'REQUIRED', deviceAuthorization: 'REQUIRED'}]) {
    assert.throws(() => decodeRecovery(value), /RECOVERY_BOUNDARY_INVALID/);
  }
});
test('invalid observation input has no effects', async () => {
  let loads = 0;
  const gate = new LocalRecoveryGate(async () => { loads++; return null; });
  await assert.rejects(gate.inspect(0)); assert.equal(loads, 0);
  assert.equal(gate.getSnapshot().started, false);
});
test('normal Kotlin entry uses original dispatch and real scope methods only (source control, not SDK execution)', () => {
  const source = readFileSync(new URL('../../modules/native-matrix/android/src/main/java/com/ynx/social/matrix/VeilCryptoEngineModule.kt', import.meta.url), 'utf8');
  const start = source.indexOf('private fun localRecoveryCheck(');
  const end = source.indexOf('override fun definition()', start);
  assert.ok(start > 0 && end > start);
  const body = source.slice(start, end);
  assert.match(body, /val current = owner \?: return/);
  assert.match(body, /localRecovery = retained/);
  assert.match(body, /current.dispatch/);
  assert.match(body, /scope.inspectExistingLocalRecovery\(\)/);
  assert.match(body, /null -> "NO_ORIGINAL_OPERATION"/);
  assert.match(body, /61 -> "CIPHERTEXT_HELD_UNVERIFIED"/);
  assert.doesNotMatch(body, /currentOwner\(|VeilCryptoEngineOwner.open|beginLocalGenesis\(|\.cancel\(|localRecovery = null/);
});
