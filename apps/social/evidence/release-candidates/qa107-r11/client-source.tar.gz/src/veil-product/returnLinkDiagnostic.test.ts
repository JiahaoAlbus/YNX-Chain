import test from 'node:test';
import assert from 'node:assert/strict';
import {decodeReturnLinkDiagnostic, returnLinkChecks} from './returnLinkDiagnostic';
import {AccountLoginGate} from './accountLogin';

test('exact low-sensitivity enumeration only; no getters, unknown values or extra payload', () => {
  for (const check of returnLinkChecks) for (const outcome of ['RETURNED_FALSE', 'THREW_EXCEPTION']) assert.deepEqual(decodeReturnLinkDiagnostic({state:'REJECTED', check, outcome, completedChecks:0, totalChecks:12}), {state:'REJECTED', check, outcome, completedChecks:0, totalChecks:12});
  assert.deepEqual(decodeReturnLinkDiagnostic({state:'NOT_STARTED', check:'NOT_CHECKED', outcome:'NOT_CHECKED', completedChecks:0, totalChecks:12}), {state:'NOT_STARTED', check:'NOT_CHECKED', outcome:'NOT_CHECKED', completedChecks:0, totalChecks:12});
  for (const raw of [null, [], {check:'cookie', outcome:'RETURNED_FALSE'}, {check:'EXACT_RESOLVER',outcome:'APPROVED'}, {check:'NOT_CHECKED',outcome:'THREW_EXCEPTION'}, {check:'EXACT_RESOLVER',outcome:'RETURNED_FALSE', callback:'private'}]) assert.throws(() => decodeReturnLinkDiagnostic(raw));
  let touched = false;
  assert.throws(() => decodeReturnLinkDiagnostic({get check() {touched = true; return 'EXACT_RESOLVER';}, outcome:'RETURNED_FALSE'})); assert.equal(touched, false);
});
test('diagnostic preserves original failed login and first refusal across observation/cancel/remount', async () => {
  let begins = 0; let diagnostic = {state:'REJECTED', check:'APPROVED_PINS_PRESENT', outcome:'RETURNED_FALSE', completedChecks:3, totalChecks:12};
  const gate = new AccountLoginGate(async () => ({beginAccountLogin: async () => {begins++; return {status:'VERIFIED_CALLBACK_REQUIRED',deviceAuthorization:'REQUIRED'};}, observeAccountLogin: async () => ({status:'VERIFIED_CALLBACK_REQUIRED',deviceAuthorization:'REQUIRED'}), cancelAccountLogin: async () => ({status:'CANCELLED',deviceAuthorization:'REQUIRED'}), readAccountLoginDiagnostic: async () => diagnostic}));
  await gate.execute('begin','newIdentityFirstDevice'); await new Promise(resolve => setImmediate(resolve));
  assert.equal(gate.getSnapshot().diagnostic?.check,'APPROVED_PINS_PRESENT');
  diagnostic = {state:'REJECTED', check:'EXACT_RESOLVER',outcome:'THREW_EXCEPTION', completedChecks:11, totalChecks:12};
  await gate.execute('cancel','newIdentityFirstDevice'); await gate.observeOriginal(); await new Promise(resolve => setImmediate(resolve));
  assert.equal(gate.getSnapshot().diagnostic?.check,'APPROVED_PINS_PRESENT'); assert.equal(begins,1);
  assert.equal(gate.canSelectIntent('restoreIdentity'),false);
});
test('broken diagnostic cannot change original login outcome', async () => {
  const gate = new AccountLoginGate(async () => ({beginAccountLogin: async () => ({status:'VERIFIED_CALLBACK_REQUIRED',deviceAuthorization:'REQUIRED'}), observeAccountLogin: async () => null, cancelAccountLogin: async () => null, readAccountLoginDiagnostic: async () => {throw Error('not exported');}}));
  assert.equal((await gate.execute('begin','newIdentityFirstDevice')).status,'VERIFIED_CALLBACK_REQUIRED');
  await new Promise(resolve => setImmediate(resolve)); assert.equal(gate.getSnapshot().diagnostic,undefined);
});
