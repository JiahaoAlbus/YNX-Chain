import assert from 'node:assert/strict';
import test from 'node:test';
function requiredAt<T>(values: readonly T[], index: number): T {
  const value = values[index];
  assert.ok(value !== undefined, `expected retained row at index ${index}`);
  return value;
}

import { decodeSnapshotReply, decodeExecuteReply, VeilCallContext } from './productBoundary';
import { VeilProductController } from './productController';

// Public structural DTOs only. These are not a provider, identity, or approval.
const context: VeilCallContext = { callId: 1, epoch: 1, action: 'readSnapshot', accountViewRef: null, viewRevision: null };
const unavailable = () => ({ kind: 'UNAVAILABLE', gaps: [] });
const authorized = () => ({
  kind: 'AUTHORIZED', accountViewRef: 'public-account-a', viewRevision: 'public-view-a',
  profile: { displayName: 'Public QA', publicIdentifier: 'public-qa' },
  conversations: [], messages: [], activeConversationId: null, contacts: [], contactRequests: [],
  moments: [], devices: [], audiences: [], recoveries: [], actions: ['requestContact', 'reviewRecovery'], localAi: 'unsupported',
});
const command = { type: 'requestContact' as const, viewRevision: 'public-view-a', identifier: 'public-recipient' };
function activeController() {
  const c = new VeilProductController(); c.activate();
  const read = c.beginRead(); assert.ok(read);
  c.completeRead(read, { context: read.context, snapshot: authorized() }); c.release(read);
  assert.equal(c.getSnapshot().snapshot?.kind, 'AUTHORIZED'); return c;
}

test('r4 bounded immutable snapshot projections reject malformed and aliased inputs', () => {
  const raw = authorized();
  const decoded = decodeSnapshotReply({ context, snapshot: raw }, context);
  assert.ok(Object.isFrozen(decoded));
  assert.equal(decoded.kind, 'AUTHORIZED');
  raw.profile.displayName = 'mutated'; raw.actions.length = 0;
  if (decoded.kind === 'AUTHORIZED') {
    assert.equal(decoded.profile.displayName, 'Public QA'); assert.equal(decoded.actions.length, 2);
    assert.ok(Object.isFrozen(decoded.profile)); assert.ok(Object.isFrozen(decoded.actions));
  }
  const invalid = [
    { ...authorized(), localAi: 'invented' },
    { ...authorized(), profile: { displayName: 'x'.repeat(257), publicIdentifier: 'public' } },
    { ...authorized(), contacts: new Array(501).fill({}) },
    { ...authorized(), actions: ['requestContact', 'requestContact'] },
    { ...authorized(), unexpectedGrant: true },
    { ...authorized(), conversations: [undefined] },
    { ...authorized(), messages: new Array(2) },
  ];
  for (const snapshot of invalid) assert.throws(() => decodeSnapshotReply({ context, snapshot }, context));
  let invoked = false;
  const getter = Object.defineProperty(authorized(), 'profile', { enumerable: true, get() { invoked = true; return {}; } });
  assert.throws(() => decodeSnapshotReply({ context, snapshot: getter }, context)); assert.equal(invoked, false);
  const arrayGetter = Object.defineProperty([], '0', { enumerable: true, get() { invoked = true; return {}; } });
  assert.throws(() => decodeSnapshotReply({ context, snapshot: { ...authorized(), contacts: arrayGetter } }, context));
  assert.equal(invoked, false);
});

test('r4 every request tuple component and result account is checked', () => {
  const expected = { ...context, action: command.type, accountViewRef: 'public-account-a', viewRevision: command.viewRevision };
  const pending = { kind: 'pending', disposition: 'unknown', originalOperationRef: 'public-original-a' };
  for (const delta of [{ callId: 2 }, { epoch: 2 }, { action: 'readSnapshot' }, { accountViewRef: 'public-account-b' }, { viewRevision: 'public-view-b' }]) {
    assert.throws(() => decodeExecuteReply({ context: { ...expected, ...delta }, result: pending }, expected, command));
  }
  assert.throws(() => decodeExecuteReply({ context: expected, result: { kind: 'snapshot', completion: 'confirmed', originalOperationRef: 'public-original-b', snapshot: { ...authorized(), accountViewRef: 'public-account-b' } } }, expected, command));
  assert.throws(() => decodeExecuteReply({ context: expected, result: { ...pending, disposition: 'delivered' } }, expected, command));
  const result = decodeExecuteReply({ context: expected, result: pending }, expected, command);
  assert.ok(Object.isFrozen(result));
});

test('r4 pending sends cannot be resubmitted and refresh cannot overwrite originals', () => {
  const c = activeController(); const lease = c.beginExecute(command, 7); assert.ok(lease);
  c.completeExecute(lease, { context: lease.context, result: { kind: 'pending', disposition: 'unknown', originalOperationRef: 'public-original-a' } }); c.release(lease);
  assert.equal(c.getSnapshot().pending.length, 1);
  assert.equal(requiredAt(c.getSnapshot().pending, 0).draftRevision, 7);
  assert.equal(c.beginExecute(command, 8), null);
  const read = c.beginRead(); assert.ok(read);
  c.completeRead(read, { context: read.context, snapshot: authorized() }); c.release(read);
  assert.equal(requiredAt(c.getSnapshot().pending, 0).originalOperationRef, 'public-original-a');
  assert.equal(c.beginExecute(command, 9), null);
  const review = c.beginExecute({ type: 'reviewRecovery', originalOperationRef: 'public-original-a' }); assert.ok(review);
  c.completeExecute(review, { context: review.context, result: { kind: 'originalReview', originalOperationRef: 'public-original-a', resolution: 'unresolved', nextStep: 'review-only' } }); c.release(review);
  assert.equal(c.beginExecute(command, 10), null);
});

test('r4 bad result locks view without publishing foreign reference', () => {
  const c = activeController(); const lease = c.beginExecute(command, 4); assert.ok(lease);
  c.completeExecute(lease, { context: { ...lease.context, accountViewRef: 'public-account-b' }, result: { kind: 'pending', disposition: 'queued', originalOperationRef: 'foreign-original' } }); c.release(lease);
  assert.equal(c.getSnapshot().snapshot?.kind, 'LOCKED');
  assert.equal(c.getSnapshot().pending.length, 1);
  assert.equal(requiredAt(c.getSnapshot().pending, 0).originalOperationRef, null);
  assert.equal(c.getSnapshot().error, 'BOUNDARY_INVALID');
  assert.equal(c.beginExecute(command), null);
});

test('r4 synchronous shared admission fences deferred reads, execution and unmount', async () => {
  const c = activeController(); const read = c.beginRead(); assert.ok(read);
  assert.equal(c.beginRead(), null); assert.equal(c.beginExecute(command), null);
  let resolve!: (v: unknown) => void;
  const deferred = new Promise<unknown>(r => { resolve = r; });
  const work = deferred.then(raw => c.completeRead(read, raw)).finally(() => c.release(read));
  c.deactivate(); c.activate();
  assert.equal(c.beginRead(), null); // Native work still owns admission across remount.
  resolve({ context: read.context, snapshot: authorized() }); await work;
  assert.equal(c.getSnapshot().snapshot, null); // Old epoch cannot publish.
  const newer = c.beginRead(); assert.ok(newer);
  c.release(read); assert.equal(c.getSnapshot().busy, true);
  c.completeRead(newer, { context: newer.context, snapshot: unavailable() }); c.release(newer);
  assert.equal(c.getSnapshot().snapshot?.kind, 'UNAVAILABLE'); assert.equal(c.getSnapshot().busy, false);
});

test('r4 rejected deferred mutation preserves uncertainty and finally releases only owner', async () => {
  const c = activeController(); const lease = c.beginExecute(command, 3); assert.ok(lease);
  assert.equal(c.beginRead(), null); assert.equal(c.beginExecute(command), null);
  await Promise.reject(new Error('public-controlled-rejection')).catch(() => c.fail(lease)).finally(() => c.release(lease));
  assert.equal(c.getSnapshot().busy, false); assert.equal(c.getSnapshot().snapshot?.kind, 'LOCKED');
  assert.equal(requiredAt(c.getSnapshot().pending, 0).disposition, 'unknown');
  assert.equal(requiredAt(c.getSnapshot().pending, 0).originalOperationRef, null);
});

test('r4 multiple account-scoped unresolved originals survive unrelated calls and genuine review', () => {
  const c = activeController();
  const a = c.beginExecute(command, 1); assert.ok(a);
  c.completeExecute(a, { context: a.context, result: { kind: 'pending', disposition: 'queued', originalOperationRef: 'public-original-a' } }); c.release(a);
  const bRead = c.beginRead(); assert.ok(bRead);
  c.completeRead(bRead, { context: bRead.context, snapshot: { ...authorized(), accountViewRef: 'public-account-b' } }); c.release(bRead);
  const b = c.beginExecute(command, 2); assert.ok(b);
  c.completeExecute(b, { context: b.context, result: { kind: 'pending', disposition: 'unknown', originalOperationRef: 'public-original-b' } }); c.release(b);
  assert.equal(c.getSnapshot().pending.length, 2);
  const back = c.beginRead(); assert.ok(back);
  c.completeRead(back, { context: back.context, snapshot: authorized() }); c.release(back);
  assert.equal(c.beginExecute({ type: 'reviewRecovery', originalOperationRef: 'public-original-b' }), null);
  const review = c.beginExecute({ type: 'reviewRecovery', originalOperationRef: 'public-original-a' }); assert.ok(review);
  c.completeExecute(review, { context: review.context, result: { kind: 'originalReview', originalOperationRef: 'public-original-a', resolution: 'confirmed', nextStep: 'none' } }); c.release(review);
  const rows = c.getSnapshot().pending;
  assert.equal(rows.length, 2); assert.equal(requiredAt(rows, 0).resolution, 'confirmed'); assert.equal(requiredAt(rows, 1).resolution, 'unresolved');
  assert.equal(requiredAt(rows, 0).draftRevision, 1); assert.equal(requiredAt(rows, 1).draftRevision, 2);
  assert.ok(Object.isFrozen(requiredAt(rows, 0).command)); assert.ok(Object.isFrozen(requiredAt(rows, 0)));
  assert.equal(c.beginExecute(command, 3), null); // A fresh read is required after genuine resolution.
});

test('r4 recovery result cannot settle another original or invent retry permission', () => {
  const review = { type: 'reviewRecovery' as const, originalOperationRef: 'public-original-a' };
  const expected = { ...context, action: review.type, accountViewRef: 'public-account-a', viewRevision: 'public-view-a' };
  const base = { kind: 'originalReview', originalOperationRef: review.originalOperationRef, resolution: 'unresolved', nextStep: 'review-only' };
  for (const result of [{ ...base, originalOperationRef: 'public-original-b' }, { ...base, nextStep: 'new-draft' }, { ...base, resolution: 'confirmed' }, { ...base, resolution: 'invented' }]) {
    assert.throws(() => decodeExecuteReply({ context: expected, result }, expected, review));
  }
  assert.ok(Object.isFrozen(decodeExecuteReply({ context: expected, result: { ...base, resolution: 'aborted', nextStep: 'new-draft' } }, expected, review)));
});

test('r4 late execute after account invalidation cannot publish result or clear current view', () => {
  const c = activeController(); const lease = c.beginExecute(command, 5); assert.ok(lease);
  c.invalidate(); assert.equal(c.beginRead(), null);
  c.completeExecute(lease, { context: lease.context, result: { kind: 'pending', disposition: 'queued', originalOperationRef: 'stale-public-original' } }); c.release(lease);
  assert.equal(c.getSnapshot().snapshot, null); assert.equal(c.getSnapshot().pending.length, 1);
  const read = c.beginRead(); assert.ok(read);
  c.completeRead(read, { context: read.context, snapshot: { ...authorized(), accountViewRef: 'public-account-b' } }); c.release(read);
  assert.equal(c.getSnapshot().snapshot?.kind, 'AUTHORIZED');
  c.fail(lease); c.release(lease);
  assert.equal(c.getSnapshot().snapshot?.kind, 'AUTHORIZED'); assert.equal(c.getSnapshot().pending.length, 1);
});

test('r4 actual send command retains draft binding and blocks edited retries of unresolved send', () => {
  const c = new VeilProductController(); c.activate(); const read = c.beginRead(); assert.ok(read);
  const snapshot = { ...authorized(), conversations: [{ id: 'public-conversation', title: 'Public QA', preview: '', unreadCount: 0 }], activeConversationId: 'public-conversation', actions: ['sendMessage', 'reviewRecovery'] };
  c.completeRead(read, { context: read.context, snapshot }); c.release(read);
  const send = { type: 'sendMessage' as const, viewRevision: 'public-view-a', conversationId: 'public-conversation', body: 'Fixed public QA text', replyToMessageId: null };
  const lease = c.beginExecute(send, 11); assert.ok(lease);
  c.completeExecute(lease, { context: lease.context, result: { kind: 'pending', disposition: 'unknown', originalOperationRef: 'public-send-original' } }); c.release(lease);
  assert.equal(c.beginExecute(send, 11), null);
  assert.equal(c.beginExecute({ ...send, body: 'Edited public QA text' }, 12), null);
  assert.deepEqual(requiredAt(c.getSnapshot().pending, 0).command, send);
  assert.equal(requiredAt(c.getSnapshot().pending, 0).draftRevision, 11);
  assert.equal(requiredAt(c.getSnapshot().pending, 0).action, 'sendMessage');
});

test('r4 multiple unresolved original refs in one account are retained without overwrite', async () => {
  const { retainPendingOriginals, settlePendingOriginal } = await import('./productController');
  const first = { accountViewRef: 'public-account-a', viewRevision: 'public-view-a', localCallId: 10, action: command.type, command, draftRevision: 10, originalOperationRef: 'public-original-10', disposition: 'unknown' as const, resolution: 'unresolved' as const, nextStep: 'review-only' as const };
  const one = retainPendingOriginals([], first);
  const second = { ...first, localCallId: 11, draftRevision: 11, originalOperationRef: 'public-original-11', command: { ...command, identifier: 'public-other-recipient' } };
  const both = retainPendingOriginals(one, second);
  assert.equal(both.length, 2); assert.equal(requiredAt(both, 0).originalOperationRef, first.originalOperationRef);
  assert.deepEqual(retainPendingOriginals(both, first), both);
  assert.throws(() => retainPendingOriginals(both, { ...first, command: second.command }));
  assert.throws(() => retainPendingOriginals(both, { ...first, originalOperationRef: 'conflicting-public-ref' }));
  const settled = settlePendingOriginal(both, 'public-account-a', { kind: 'originalReview', originalOperationRef: 'public-original-11', resolution: 'confirmed', nextStep: 'none' });
  assert.equal(requiredAt(settled, 0).resolution, 'unresolved'); assert.equal(requiredAt(settled, 1).resolution, 'confirmed');
  assert.deepEqual(settlePendingOriginal(both, 'public-account-b', { kind: 'originalReview', originalOperationRef: first.originalOperationRef, resolution: 'confirmed', nextStep: 'none' }), both);
});
