import test from 'node:test';
import assert from 'node:assert/strict';
import { decodeAcceptedDeviceObservation, decodeProtectedMessageSession, decodeProductInventory, productObservationKey, ProductInventoryObservation, type ProductPortModule } from './nativeProductPorts';
import { decodeSnapshotReply } from './productBoundary';
const value={status:'INVENTORY_ONLY',epoch:'1',ownerStatus:1,closed:false,entryCount:0,enginePresent:false,changed:false,deviceAuthorization:'REQUIRED'};
const pause=()=>new Promise(resolve=>setTimeout(resolve,10));
function deferred<T>() {let resolve!:(v:T)=>void;const promise=new Promise<T>(r=>resolve=r);return {resolve,promise};}
test('inventory is strictly bounded and cannot become authorization',()=>{
 assert.equal(decodeProductInventory(value).status,'INVENTORY_ONLY');
 for(const raw of [{...value,status:'AUTHORIZED'},{...value,deviceAuthorization:'APPROVED'},{...value,epoch:'0'},{...value,epoch:'9223372036854775808'},{...value,entryCount:33},{...value,ownerStatus:-16},{...value,extra:1}])assert.throws(()=>decodeProductInventory(raw));
 assert.equal(decodeProductInventory({...value,ownerStatus:16}).status,'INVENTORY_ONLY');
 assert.equal(decodeProductInventory({...value,ownerStatus:25}).status,'INVENTORY_ONLY');
 assert.equal(decodeProductInventory({...value,ownerStatus:30}).status,'INVENTORY_ONLY');
 let invoked=false;assert.throws(()=>decodeProductInventory({get status(){invoked=true;return 'INVENTORY_ONLY';}}));assert.equal(invoked,false);
});
test('read shares physical promise without a native subscription or fabricated model',async()=>{
 const d=deferred<unknown>();let calls=0;
 const m:ProductPortModule={readNativeProductState:()=>{calls++;return d.promise;},subscribeNativeProductInvalidation:async()=>{throw Error();},unsubscribeNativeProductInvalidation:async()=>({status:'UNSUBSCRIBED'})};
 const p=new ProductInventoryObservation(async()=>m);const a=p.read();const b=p.read();assert.equal(a,b);await pause();assert.equal(calls,1);d.resolve(value);assert.equal((await a).status,'INVENTORY_ONLY');
});
test('detach during delayed subscription waits original receipt then actually unsubscribes once',async()=>{
 const d=deferred<unknown>();let starts=0,stops=0;
 const p=new ProductInventoryObservation(async()=>({readNativeProductState:async()=>value,subscribeNativeProductInvalidation:()=>{starts++;return d.promise;},unsubscribeNativeProductInvalidation:async()=>{stops++;return {status:'UNSUBSCRIBED'};}}));
 const off=p.subscribe(()=>{});await pause();off();assert.equal(stops,0);d.resolve(value);await pause();assert.equal(starts,1);assert.equal(stops,1);off();assert.equal(stops,1);
});
test('remount while unsubscribe pending does not overlap native registration',async()=>{
 const stop=deferred<unknown>();let starts=0,stops=0;
 const p=new ProductInventoryObservation(async()=>({readNativeProductState:async()=>value,subscribeNativeProductInvalidation:async()=>{starts++;return value;},unsubscribeNativeProductInvalidation:()=>{stops++;return stop.promise;}}));
 const a=p.subscribe(()=>{});await pause();a();await pause();const b=p.subscribe(()=>{});await pause();assert.equal(starts,1);stop.resolve({status:'UNSUBSCRIBED'});await pause();await pause();assert.equal(starts,2);b();await pause();assert.equal(stops,2);
});
test('native or missing-module failure stays unavailable',async()=>{
 assert.equal((await new ProductInventoryObservation(async()=>null).read()).status,'UNAVAILABLE');
 assert.equal((await new ProductInventoryObservation(async()=>({readNativeProductState:async()=>{throw Error('native16');},subscribeNativeProductInvalidation:async()=>value,unsubscribeNativeProductInvalidation:async()=>({})})).read()).status,'UNAVAILABLE');
});
const device = {
 version:1,kind:'accepted-device-observation',account:'qa-account',device:'qa-device',
 rootDigest:'1'.repeat(64),registrationDigest:'2'.repeat(64),finalDigest:'3'.repeat(64),
 currentDigest:'4'.repeat(64),currentSequence:'18446744073709551615',
 revocationCheckpointDigest:'5'.repeat(64),observedIssuedMS:1000,observedExpiresMS:2000,
};
test('normal device observation preserves native u64 and remains non-authorizing',()=>{
 const raw={...value,status:'DEVICE_OBSERVED',acceptedDevice:{...device}};
 const decoded=decodeProductInventory(raw);
 assert.equal(decoded.status,'DEVICE_OBSERVED');
 if(decoded.status!=='DEVICE_OBSERVED')assert.fail();
 assert.equal(decoded.acceptedDevice.currentSequence,'18446744073709551615');
 assert.equal(decoded.deviceAuthorization,'REQUIRED');
 raw.acceptedDevice.device='mutated';
 assert.equal(decoded.acceptedDevice.device,'qa-device');
 assert.ok(Object.isFrozen(decoded.acceptedDevice));
});
test('device observation rejects malformed, unsafe, closed and unknown projections',()=>{
 for(const delta of [
  {version:2},{kind:'AUTHORIZED'},{account:'white space'},{device:''},
  {rootDigest:'0'.repeat(64)},{finalDigest:'A'.repeat(64)},
  {currentSequence:'0'},{currentSequence:'01'},{currentSequence:'18446744073709551616'},
  {currentSequence:1},{observedIssuedMS:-1},{observedExpiresMS:1000},
  {observedIssuedMS:0.5},{observedExpiresMS:Number.MAX_SAFE_INTEGER+1},{privateKey:'forbidden'},
 ])assert.throws(()=>decodeAcceptedDeviceObservation({...device,...delta}));
 for(const delta of [{closed:true},{ownerStatus:16},{ownerStatus:25},{deviceAuthorization:'APPROVED'}])
  assert.throws(()=>decodeProductInventory({...value,status:'DEVICE_OBSERVED',acceptedDevice:device,...delta}));
 assert.throws(()=>decodeProductInventory({...value,acceptedDevice:device}));
 assert.throws(()=>decodeProductInventory({...value,status:'DEVICE_OBSERVED'}));
 let invoked=false;
 const accessor={...device};Object.defineProperty(accessor,'account',{enumerable:true,get(){invoked=true;return 'qa';}});
 assert.throws(()=>decodeAcceptedDeviceObservation(accessor));assert.equal(invoked,false);
 assert.throws(()=>decodeAcceptedDeviceObservation(Object.assign(Object.create({inherited:true}),device)));
});
test('device changes and loss invalidate the normal view even with unchanged epoch',()=>{
 const observed=decodeProductInventory({...value,status:'DEVICE_OBSERVED',acceptedDevice:device});
 const changed=decodeProductInventory({...value,status:'DEVICE_OBSERVED',acceptedDevice:{...device,currentDigest:'6'.repeat(64)}});
 assert.notEqual(productObservationKey(observed),productObservationKey(changed));
 assert.notEqual(productObservationKey(observed),productObservationKey(decodeProductInventory(value)));
 assert.notEqual(productObservationKey(observed),productObservationKey({status:'UNAVAILABLE'}));
});
test('normal product boundary exposes device observation without authorizing actions',()=>{
 const context={callId:1,epoch:1,action:'readSnapshot' as const,accountViewRef:null,viewRevision:null};
 const snapshot={kind:'UNAVAILABLE',gaps:['AUTHORIZED_PRODUCT_PROJECTION_UNAVAILABLE'],deviceObservation:device};
 const result=decodeSnapshotReply({context,snapshot},context);
 assert.equal(result.kind,'UNAVAILABLE');
 if(result.kind!=='UNAVAILABLE')assert.fail();
 assert.equal(result.deviceObservation?.device,'qa-device');
 assert.throws(()=>decodeSnapshotReply({context,snapshot:{...snapshot,actions:['sendMessage']}},context));
 assert.throws(()=>decodeSnapshotReply({context,snapshot:{...snapshot,deviceObservation:{...device,kind:'AUTHORIZED'}}},context));
 const lost=decodeSnapshotReply({context,snapshot:{kind:'UNAVAILABLE',gaps:snapshot.gaps}},context);
 assert.equal(lost.kind,'UNAVAILABLE');
 if(lost.kind==='UNAVAILABLE')assert.equal(lost.deviceObservation,undefined);
});
const protectedSession = {
 version:1,kind:'protected-message-session-observation',device:{...device},
 local:{name:'qa-alice',deviceId:1},remote:{name:'qa-bob',deviceId:2},
 purposeDigest:'6'.repeat(64),selectedSessionDigest:'7'.repeat(64),
 relationDigest:'8'.repeat(64),checkpointDigest:'9'.repeat(64),
 relationRevision:'18446744073709551615',purposeExpiresMS:1800,
};
test('actual protected session observation preserves nested native bindings without granting an action',()=>{
 const input={...protectedSession,local:{...protectedSession.local},device:{...device}};
 const session=decodeProtectedMessageSession(input);
 input.local.name='changed';input.device.account='changed';
 assert.equal(session.local.name,'qa-alice');assert.equal(session.device.account,'qa-account');
 assert.ok(Object.isFrozen(session.local));assert.ok(Object.isFrozen(session.device));
 const inventory=decodeProductInventory({...value,ownerStatus:0,status:'SESSION_OBSERVED',acceptedDevice:device,protectedSession});
 assert.equal(inventory.status,'SESSION_OBSERVED');
 if(inventory.status==='SESSION_OBSERVED')assert.equal(inventory.deviceAuthorization,'REQUIRED');
 const context={callId:1,epoch:1,action:'readSnapshot' as const,accountViewRef:null,viewRevision:null};
 const snapshot={kind:'UNAVAILABLE',gaps:['AUTHORIZED_PRODUCT_PROJECTION_UNAVAILABLE'],deviceObservation:device,sessionObservation:protectedSession};
 assert.equal(decodeSnapshotReply({context,snapshot},context).kind,'UNAVAILABLE');
 assert.throws(()=>decodeSnapshotReply({context,snapshot:{...snapshot,deviceObservation:undefined}},context));
 assert.throws(()=>decodeSnapshotReply({context,snapshot:{...snapshot,deviceObservation:{...device,account:'foreign'}}},context));
});
test('session observation rejects wrong-device, unknown, unsafe-address and stale-schema mixtures',()=>{
 const normal={...value,ownerStatus:0,status:'SESSION_OBSERVED',acceptedDevice:device,protectedSession};
 for(const delta of [{ownerStatus:1},{ownerStatus:16},{ownerStatus:25},{closed:true},
  {acceptedDevice:{...device,device:'foreign'}},{protectedSession:{...protectedSession,sessionKey:'forbidden'}}])
  assert.throws(()=>decodeProductInventory({...normal,...delta}));
 for(const delta of [
  {kind:'AUTHORIZED'},{device:{...device,version:2}},{remote:{...protectedSession.local}},
  {local:{name:'a',deviceId:0}},{local:{name:'a',deviceId:128}},
  {local:{name:'\u0000',deviceId:1}},{local:{name:'\ud800',deviceId:1}},
  {local:{name:'\u00e9'.repeat(65),deviceId:1}},{local:{name:'a',deviceId:1,extra:true}},
  {relationRevision:'18446744073709551616'},{purposeExpiresMS:0},
  {purposeExpiresMS:Number.MAX_SAFE_INTEGER+1},{relationDigest:'0'.repeat(64)}
 ])assert.throws(()=>decodeProtectedMessageSession({...protectedSession,...delta}));
 assert.equal(decodeProtectedMessageSession({...protectedSession,local:{name:'\u00e9'.repeat(64),deviceId:127}}).local.deviceId,127);
 let invoked=false;const local={...protectedSession.local};
 Object.defineProperty(local,'name',{enumerable:true,get(){invoked=true;return 'qa';}});
 assert.throws(()=>decodeProtectedMessageSession({...protectedSession,local}));assert.equal(invoked,false);
});
test('session replacement or loss changes normal observer identity',()=>{
 const a=decodeProductInventory({...value,ownerStatus:0,status:'SESSION_OBSERVED',acceptedDevice:device,protectedSession});
 const b=decodeProductInventory({...value,ownerStatus:0,status:'SESSION_OBSERVED',acceptedDevice:device,
  protectedSession:{...protectedSession,checkpointDigest:'a'.repeat(64)}});
 assert.notEqual(productObservationKey(a),productObservationKey(b));
 assert.notEqual(productObservationKey(a),productObservationKey(decodeProductInventory({...value,status:'DEVICE_OBSERVED',acceptedDevice:device})));
});

test('normal bridge forwards an owned original once through paired native exports',async()=>{
 const {NormalProductCalls}=await import('./nativeProductPorts');
 let calls=0;const gate=deferred<unknown>();
 const context={callId:1,epoch:1,action:'requestContact' as const,accountViewRef:'a',viewRevision:'v'};
 const command={type:'requestContact' as const,viewRevision:'v',identifier:'bob'};
 let capturedCommand='',capturedContext='';
 const module:ProductPortModule={readNativeProductState:async()=>value,subscribeNativeProductInvalidation:async()=>value,unsubscribeNativeProductInvalidation:async()=>({}),
  readNativeProductSnapshot:async()=>({}),executeNativeProductCommand:async(cmd,ctx)=>{calls++;capturedCommand=cmd;capturedContext=ctx;return gate.promise;}};
 const bridge=new NormalProductCalls(async()=>module);
 const first=bridge.execute(command,context),same=bridge.execute({...command},{...context});
 assert.equal(first,same);
 command.identifier='changed';context.accountViewRef='changed';
 await pause();
 assert.equal(JSON.parse(capturedCommand).identifier,'bob');
 assert.equal(JSON.parse(capturedContext).accountViewRef,'a');
 gate.resolve({context:JSON.parse(capturedContext),result:{kind:'pending',disposition:'unknown',originalOperationRef:'original-1'}});
 assert.equal((await first).result.kind,'pending');assert.equal(calls,1);
});
test('normal bridge post-dispatch rejection remains the same failed receipt, not unavailable',async()=>{
 const {NormalProductCalls}=await import('./nativeProductPorts');
 let calls=0;const failure=Error('PUBLIC original transport failure');
 const module:ProductPortModule={readNativeProductState:async()=>value,subscribeNativeProductInvalidation:async()=>value,unsubscribeNativeProductInvalidation:async()=>({}),
  readNativeProductSnapshot:async()=>({}),executeNativeProductCommand:async()=>{calls++;throw failure;}};
 const bridge=new NormalProductCalls(async()=>module);
 const context={callId:1,epoch:1,action:'requestContact' as const,accountViewRef:'a',viewRevision:'v'};
 const command={type:'requestContact' as const,viewRevision:'v',identifier:'bob'};
 const first=bridge.execute(command,context);
 await assert.rejects(first,e=>e===failure);
 const second=bridge.execute(command,context);assert.equal(first,second);
 await assert.rejects(second,e=>e===failure);assert.equal(calls,1);
});
test('normal bridge rejects overlapping and reused association without a second dispatch',async()=>{
 const {NormalProductCalls}=await import('./nativeProductPorts');
 let calls=0;const gate=deferred<unknown>();
 const module:ProductPortModule={readNativeProductState:async()=>value,subscribeNativeProductInvalidation:async()=>value,unsubscribeNativeProductInvalidation:async()=>({}),
  readNativeProductSnapshot:async(ctx)=>{calls++;return {context:JSON.parse(ctx),snapshot:{kind:'LOCKED'}};},
  executeNativeProductCommand:async()=>{calls++;return gate.promise;}};
 const bridge=new NormalProductCalls(async()=>module);
 const context={callId:1,epoch:1,action:'requestContact' as const,accountViewRef:'a',viewRevision:'v'};
 const command={type:'requestContact' as const,viewRevision:'v',identifier:'bob'};
 const first=bridge.execute(command,context);
 await assert.rejects(bridge.execute(command,{...context,callId:2}),/ORIGINAL_RETAINED/);
 gate.resolve({context,result:{kind:'error',code:'UNAVAILABLE'}});await first;
 await bridge.read({...context,callId:2,action:'readSnapshot'});
 await assert.rejects(bridge.execute(command,context),/ORIGINAL_RETAINED/);assert.equal(calls,2);
});
test('normal bridge neither upgrades observation nor accepts half-version exports',async()=>{
 const {NormalProductCalls}=await import('./nativeProductPorts');
 let calls=0;
 const module:ProductPortModule={readNativeProductState:async()=>value,subscribeNativeProductInvalidation:async()=>value,unsubscribeNativeProductInvalidation:async()=>({}),
  readNativeProductSnapshot:async()=>{calls++;return value;}};
 const bridge=new NormalProductCalls(async()=>module);
 assert.equal(await bridge.read({callId:1,epoch:1,action:'readSnapshot',accountViewRef:null,viewRevision:null}),null);
 const result=await bridge.execute({type:'requestContact',viewRevision:'v',identifier:'bob'},
  {callId:2,epoch:1,action:'requestContact',accountViewRef:'a',viewRevision:'v'});
 assert.deepEqual(result.result,{kind:'error',code:'UNAVAILABLE'});assert.equal(calls,0);
});
test('normal bridge rejects malformed input before invoking loaders or accessors',async()=>{
 const {NormalProductCalls}=await import('./nativeProductPorts');
 let loads=0,getters=0;
 const bridge=new NormalProductCalls(async()=>{loads++;return null;});
 const context={callId:1,epoch:1,action:'requestContact' as const,accountViewRef:'a',viewRevision:'v'};
 const command={type:'requestContact' as const,viewRevision:'v',identifier:'bob'};
 const accessor={...context};Object.defineProperty(accessor,'accountViewRef',{enumerable:true,get(){getters++;return 'a';}});
 assert.throws(()=>bridge.execute(command,accessor));
 assert.throws(()=>bridge.execute(command,{...context,action:'sendMessage'}));
 assert.throws(()=>bridge.execute(command,{...context,viewRevision:'other'}));
 const commandAccessor={...command};
 Object.defineProperty(commandAccessor,'identifier',{enumerable:true,get(){getters++;return 'bob';}});
 assert.throws(()=>bridge.execute(commandAccessor,context));
 assert.equal(loads,0);assert.equal(getters,0);
});
test('normal bridge rejects cross-context result without replaying the original',async()=>{
 const {NormalProductCalls}=await import('./nativeProductPorts');
 let calls=0;
 const context={callId:1,epoch:1,action:'requestContact' as const,accountViewRef:'a',viewRevision:'v'};
 const command={type:'requestContact' as const,viewRevision:'v',identifier:'bob'};
 const module:ProductPortModule={readNativeProductState:async()=>value,subscribeNativeProductInvalidation:async()=>value,unsubscribeNativeProductInvalidation:async()=>({}),
  readNativeProductSnapshot:async()=>({}),executeNativeProductCommand:async()=>{calls++;return {context:{...context,accountViewRef:'other'},result:{kind:'error',code:'UNAVAILABLE'}};}};
 const bridge=new NormalProductCalls(async()=>module);
 await assert.rejects(bridge.execute(command,context),/BOUNDARY_INVALID/);
 await assert.rejects(bridge.execute(command,context),/BOUNDARY_INVALID/);assert.equal(calls,1);
});
