import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import { LocalOwnerReadGate, decodeNativeLocalOwner, decodeLocalOwnerProjection, ownerReadFailure, ownerStates, pendingStoreStates } from './localOwner';
import { decodeSnapshotReply } from './productBoundary';
import { veilProductNativeConsumer } from './nativeConsumer';
const publicState = () => ({ ownerState: 'LOCAL_PENDING', queued: 0, pendingTickets: 2, reopenedPendingRows: 1, pendingStoreState: 'RECONCILIATION_REQUIRED', failureRetained: false, nativeBoundary: 'REQUIRED', localGenesisAttempted: false, localGenesisStatus: null });
const context = Object.freeze({callId: 1, epoch: 1, action: 'readSnapshot' as const, accountViewRef: null, viewRevision: null});
test('local genesis disposition stays diagnostic and unknown remains explicit', () => {
  for (const localGenesisStatus of [16, 21, 22, 23, 24, 25, 34, 36, 41, 42, 43, 44, null]) {
    const value = decodeNativeLocalOwner({...publicState(), localGenesisAttempted: true, localGenesisStatus});
    assert.equal(value.status, 'OBSERVED');
    if (value.status === 'OBSERVED') {
      assert.equal(value.localGenesisStatus, localGenesisStatus);
      assert.equal(value.localGenesisAttempted, true);
    }
    assert.equal(value.nativeBoundary, 'REQUIRED');
    assert.equal(decodeSnapshotReply({context, snapshot: {kind: 'UNAVAILABLE', gaps: [], localOwner: value}}, context).kind, 'UNAVAILABLE');
  }
  for (const localGenesisStatus of [0, 1, 40, 999, '41', NaN, 41.5, undefined]) {
    assert.throws(() => decodeNativeLocalOwner({...publicState(), localGenesisAttempted: true, localGenesisStatus}));
  }
  assert.throws(() => decodeNativeLocalOwner({...publicState(), localGenesisStatus: 41}));
  assert.throws(() => decodeNativeLocalOwner({...publicState(), localGenesisAttempted: 'true'}));
  let invoked = false;
  const getter = Object.defineProperty(publicState(), 'localGenesisStatus', {enumerable: true, get() {invoked = true; return 41;}});
  assert.throws(() => decodeNativeLocalOwner(getter));
  assert.equal(invoked, false);
});
test('normal owner projection is owned/bounded and can never authorize', () => {
  for (const ownerState of ownerStates) for (const pendingStoreState of [...pendingStoreStates, null]) {
    const raw = {...publicState(),ownerState,pendingStoreState};
    const value = decodeNativeLocalOwner(raw); raw.queued = 123;
    assert.ok(Object.isFrozen(value)); assert.equal(value.nativeBoundary,'REQUIRED');
    assert.equal(value.status,'OBSERVED'); if(value.status==='OBSERVED') assert.equal(value.queued,0);
    const snapshot=decodeSnapshotReply({context,snapshot:{kind:'UNAVAILABLE',gaps:[],localOwner:value}},context);
    assert.equal(snapshot.kind,'UNAVAILABLE'); assert.ok(Object.isFrozen(snapshot));
  }
  for(const delta of [{queued:-1},{pendingTickets:2147483648},{reopenedPendingRows:0.5},{queued:NaN},{ownerState:'AUTHORIZED'},{nativeBoundary:'AUTHORIZED'},{pendingStoreState:'AUTHORIZED'},{failureRetained:1},{secret:'forbidden'}]) assert.throws(()=>decodeNativeLocalOwner({...publicState(),...delta}));
  let invoked=false;const getter=Object.defineProperty(publicState(),'ownerState',{enumerable:true,get(){invoked=true;return 'LOCAL_PENDING';}});
  assert.throws(()=>decodeNativeLocalOwner(getter));assert.equal(invoked,false);
  assert.throws(()=>decodeNativeLocalOwner(new Array(7)));
  assert.throws(()=>decodeLocalOwnerProjection({status:'AUTHORIZED',nativeBoundary:'REQUIRED'}));
});
test('failure projection and extra authority fields are rejected at R4 boundary',()=>{
  for(const status of ['READ_FAILED','READ_TIMEOUT','INVALID_REPLY','MODULE_UNAVAILABLE'] as const) {
    const raw=ownerReadFailure(status);assert.ok(Object.isFrozen(decodeLocalOwnerProjection(raw)));
    assert.equal(decodeSnapshotReply({context,snapshot:{kind:'UNAVAILABLE',gaps:[],localOwner:raw}},context).kind,'UNAVAILABLE');
  }
  assert.throws(()=>decodeSnapshotReply({context,snapshot:{kind:'UNAVAILABLE',gaps:[],localOwner:{...decodeNativeLocalOwner(publicState()),grant:true}}},context));
  assert.throws(()=>decodeSnapshotReply({context:{...context,epoch:2},snapshot:{kind:'UNAVAILABLE',gaps:[],localOwner:decodeNativeLocalOwner(publicState())}},context));
});
test('timeout retains same in-flight read and never closes/cancels/reopens owner',async()=>{
  const gate=new LocalOwnerReadGate();let calls=0;let resolve!:(value:unknown)=>void;
  const pending=new Promise<unknown>(r=>{resolve=r;});const read=()=>{calls++;return pending;};
  assert.equal((await gate.read(read,2)).status,'READ_TIMEOUT');
  assert.equal((await gate.read(read,2)).status,'READ_TIMEOUT');assert.equal(calls,1);
  const completion=gate.read(read,100);resolve(publicState());assert.equal((await completion).status,'OBSERVED');assert.equal(calls,1);
  assert.equal((await gate.read(async()=>{calls++;throw Error('fixed-public-failure');},100)).status,'READ_FAILED');assert.equal(calls,2);
  assert.equal((await gate.read(async()=>({nativeBoundary:'AUTHORIZED'}),100)).status,'INVALID_REPLY');
  await assert.rejects(gate.read(read,31001));
});
test('installed optional reader never creates authorized data or native execute',async()=>{
  const reply=await veilProductNativeConsumer.readSnapshot(context);
  const snapshot=decodeSnapshotReply(reply,context);assert.equal(snapshot.kind,'UNAVAILABLE');
  if(snapshot.kind==='UNAVAILABLE') assert.equal(snapshot.localOwner?.status,'MODULE_UNAVAILABLE');
  const command={type:'requestContact' as const,viewRevision:'public-view',identifier:'public-only'};
  const result=await veilProductNativeConsumer.execute(command,{...context,action:command.type,accountViewRef:'public-account',viewRevision:'public-view'});
  assert.deepEqual(result.result,{kind:'error',code:'UNAVAILABLE'});
  assert.equal(veilProductNativeConsumer.subscribeInvalidation(()=>{throw Error('not an exported native event');}),null);
  const module=readFileSync(new URL('./localOwnerModule.ts',import.meta.url),'utf8');
  assert.match(module,/Platform.OS !== 'android'/);assert.match(module,/requireOptionalNativeModule<LocalOwnerModule>\('YNXSocialCryptoEngine'\)/);
  assert.doesNotMatch(module,/\.closeLocalOwner\(/);assert.doesNotMatch(module,/\.execute\(/);
});
