import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {LocalAuthenticationGate, decodeLocalAuthentication} from './localDeviceSetup';
const reply = (status: string) => ({status, nativeBoundary: 'REQUIRED', deviceAuthorization: 'REQUIRED'});
test('explicit authentication retains late physical call across timeout and remount', async () => {
 let finish!: (v: unknown) => void, calls=0, loads=0;
 const gate = new LocalAuthenticationGate(async () => {loads++; return {
  readLocalDeviceAuthenticationEligibility: async () => reply('AUTHENTICATION_ELIGIBLE'), continueLocalDevice: async (locale) => {calls++; assert.equal(locale,'zh'); return new Promise(resolve => {finish=resolve;});},
  observeLocalDeviceAuthentication: async () => {throw Error('unexpected');},
 };});
 const off=gate.subscribe(()=>{});off();assert.equal(calls,0);
 assert.equal((await gate.inspect('zh',1)).status,'AUTHENTICATION_PENDING');
 assert.equal(gate.getSnapshot().pending,true);
 const waiting=gate.inspect('en',100); finish(reply('LOCAL_KEYS_AUTHENTICATED'));
 assert.equal((await waiting).status,'LOCAL_KEYS_AUTHENTICATED');
 await gate.inspect('en');assert.equal(calls,1);assert.equal(loads,1);
 assert.equal(gate.getSnapshot().result?.deviceAuthorization,'REQUIRED');
});
test('native timeout observes same future without repeating submit', async () => {
 let starts=0, reads=0;
 const gate=new LocalAuthenticationGate(async()=>({readLocalDeviceAuthenticationEligibility: async () => reply('AUTHENTICATION_ELIGIBLE'), continueLocalDevice:async()=>{starts++;return reply('AUTHENTICATION_PENDING');},observeLocalDeviceAuthentication:async()=>{reads++;return reply('LOCAL_KEYS_AUTHENTICATED');}}));
 await gate.inspect('en');await gate.inspect('en');await gate.inspect('en');
 assert.deepEqual([starts,reads],[1,1]);
});
test('observed cancellation or screen lock permits only explicit next prompt',async()=>{
 for(const state of ['AUTHENTICATION_CANCELLED','SCREEN_LOCK_REQUIRED']) {
  let starts=0;
  const gate=new LocalAuthenticationGate(async()=>({readLocalDeviceAuthenticationEligibility: async () => reply('AUTHENTICATION_ELIGIBLE'), continueLocalDevice:async()=>{starts++;return reply(starts===1?state:'LOCAL_KEYS_AUTHENTICATED');},observeLocalDeviceAuthentication:async()=>{throw Error('unexpected');}}));
  assert.equal((await gate.inspect('zh')).status,state);assert.equal(starts,1);
  const off=gate.subscribe(()=>{});off();await Promise.resolve();assert.equal(starts,1);
  assert.equal((await gate.inspect('zh')).status,'LOCAL_KEYS_AUTHENTICATED');assert.equal(starts,2);
 }
});
test('failure or unavailable is retained without replacement',async()=>{
 for(const state of ['RECOVERY_REQUIRED','UNAVAILABLE']) {
  let starts=0;
  const gate=new LocalAuthenticationGate(async()=>({readLocalDeviceAuthenticationEligibility: async () => reply('AUTHENTICATION_ELIGIBLE'), continueLocalDevice:async()=>{starts++;return reply(state);},observeLocalDeviceAuthentication:async()=>{throw Error('unexpected');}}));
  await gate.inspect('en');await gate.inspect('en');assert.equal(starts,1);
 }
});
test('linkage and late destroyed refusal never becomes local success',async()=>{
 for(const call of [async()=>{throw Error('missing ABI');},async()=>reply('UNAVAILABLE')]){
  const gate=new LocalAuthenticationGate(async()=>({readLocalDeviceAuthenticationEligibility: async () => reply('AUTHENTICATION_ELIGIBLE'), continueLocalDevice:call,observeLocalDeviceAuthentication:call}));
  const value=await gate.inspect('en');assert.notEqual(value.status,'LOCAL_KEYS_AUTHENTICATED');
 }
});
test('strict public projection excludes keys, native status and grants',()=>{
 for(const raw of [reply('62'),reply('AUTHORIZED'),{...reply('LOCAL_KEYS_AUTHENTICATED'),deviceAuthorization:'APPROVED'},{...reply('LOCAL_KEYS_AUTHENTICATED'),publicKeys:[] }])assert.throws(()=>decodeLocalAuthentication(raw));
 let read=false; const raw=Object.defineProperty(reply('LOCAL_KEYS_AUTHENTICATED'),'status',{enumerable:true,get(){read=true;return 'LOCAL_KEYS_AUTHENTICATED';}});
 assert.throws(()=>decodeLocalAuthentication(raw));assert.equal(read,false);
});
test('invalid observations have no loading effects',async()=>{
 let loads=0;const gate=new LocalAuthenticationGate(async()=>{loads++;return null;});
 await assert.rejects(gate.inspect('en',0));assert.equal(loads,0);
});
test('Kotlin source contract only: original worker, receipt publication, owner-only projection',()=>{
 const root=new URL('../../modules/native-matrix/android/src/main/java/com/ynx/social/matrix/',import.meta.url);
 const module=readFileSync(new URL('VeilCryptoEngineModule.kt',root),'utf8');
 const owner=readFileSync(new URL('VeilCryptoEngineOwner.kt',root),'utf8');
 const begin=module.indexOf('private fun continueLocalDevice('),end=module.indexOf('override fun definition()',begin);
 assert.ok(begin>=0&&end>begin);const body=module.slice(begin,end);
 assert.doesNotMatch(body,/currentOwner\(|beginPreparedLocalGenesis\(|\.cancel\(|authenticatedSetup = null/);
 assert.match(body,/deviceAuthentication.consume\(request\)/);
 assert.match(body,/scope.authenticatePreparedExistingLocalRecovery\(input\)\s*\}\)\s*status = "LOCAL_KEYS_AUTHENTICATED"/);
 assert.match(body,/retained.complete\(setupProjection\(if \(currentOriginal\) status else "UNAVAILABLE"\)\)/);
 assert.match(owner,/owner.retainedRecoveryInput = captured/);
 assert.match(owner,/owner.authenticatedPublicProjection = projection/);
 assert.match(owner,/if \(owner.recoveryReadAttempted\) return checkNotNull/);
 assert.doesNotMatch(body,/ByteArray|nativeCopy|projection\[/);
});
test('early click then original setup and inspection can continue without consuming auth', async () => {
 let eligibility='LOCAL_SETUP_REQUIRED', starts=0, checks=0;
 const gate=new LocalAuthenticationGate(async()=>({
  readLocalDeviceAuthenticationEligibility:async()=>{checks++;return reply(eligibility);},
  continueLocalDevice:async()=>{starts++;return reply('LOCAL_KEYS_AUTHENTICATED');},
  observeLocalDeviceAuthentication:async()=>{throw Error('no pending original');},
 }));
 assert.equal((await gate.inspect('zh')).status,'LOCAL_SETUP_REQUIRED');
 assert.equal((await gate.inspect('zh')).status,'LOCAL_SETUP_REQUIRED');assert.equal(starts,0);
 eligibility='LOCAL_INSPECTION_REQUIRED';
 assert.equal((await gate.inspect('zh')).status,'LOCAL_INSPECTION_REQUIRED');assert.equal(starts,0);
 eligibility='AUTHENTICATION_ELIGIBLE';
 assert.equal((await gate.inspect('zh')).status,'LOCAL_KEYS_AUTHENTICATED');
 await gate.inspect('zh');assert.equal(starts,1);assert.equal(checks,4);
});
test('concurrent eligibility observations deduplicate before any prompt', async()=>{
 let finish!: (v:unknown)=>void, checks=0, starts=0;
 const gate=new LocalAuthenticationGate(async()=>({
  readLocalDeviceAuthenticationEligibility:async()=>{checks++;return new Promise(resolve=>{finish=resolve;});},
  continueLocalDevice:async()=>{starts++;return reply('LOCAL_KEYS_AUTHENTICATED');},
  observeLocalDeviceAuthentication:async()=>reply('UNAVAILABLE'),
 }));
 assert.equal((await gate.inspect('en',1)).status,'AUTHENTICATION_PENDING');
 const second=gate.inspect('zh',100);finish(reply('LOCAL_SETUP_REQUIRED'));
 assert.equal((await second).status,'LOCAL_SETUP_REQUIRED');assert.equal(checks,1);assert.equal(starts,0);
});
test('close between eligibility and admission refuses; never retry native on unknown',async()=>{
 let starts=0;
 const gate=new LocalAuthenticationGate(async()=>({
  readLocalDeviceAuthenticationEligibility:async()=>reply('AUTHENTICATION_ELIGIBLE'),
  continueLocalDevice:async()=>{starts++;return reply('RECOVERY_REQUIRED');},
  observeLocalDeviceAuthentication:async()=>reply('RECOVERY_REQUIRED'),
 }));
 await gate.inspect('en');await gate.inspect('en');assert.equal(starts,1);
});
test('Kotlin source only: no effects in eligibility and admission rechecks before future reservation',()=>{
 const source=readFileSync(new URL('../../modules/native-matrix/android/src/main/java/com/ynx/social/matrix/VeilCryptoEngineModule.kt',import.meta.url),'utf8');
 const begin=source.indexOf('private fun authenticationEligibility()'),end=source.indexOf('private fun continueLocalDevice(',begin);
 assert.ok(begin>=0&&end>begin);const preflight=source.slice(begin,end);
 assert.doesNotMatch(preflight,/currentOwner\(|\.dispatch\s*\{|deviceAuthentication\.|localRecoveryCheck\(|authenticatedSetup =/);
 assert.match(preflight,/snapshot.localGenesisAttempted/);
 const body=source.slice(end,source.indexOf('override fun definition()',end));
 assert.ok(body.indexOf('val eligibility = authenticationEligibility()')<body.indexOf('authenticatedSetup = retained'));
 assert.match(body,/if \(eligibility != "AUTHENTICATION_ELIGIBLE"\) return setupProjection\(eligibility\)/);
 assert.doesNotMatch(body,/localRecoveryCheck\(true\)/);
});
