import { localEntryPresentation } from './veil-product/entryPresentation';
import {ownerLifecycleGate} from './veil-product/ownerLifecycle';
import {OwnerLifecyclePanel} from './veil-product/OwnerLifecyclePanel';
import { selectAccountEntry, type AccountEntryCase } from './veil-product/accountEntry';
import { failRootOperation, clearAccountFeedback } from './veil-product/rootFeedback';
import React, { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { ActivityIndicator, AppState, Image, Keyboard, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { getLocales } from 'expo-localization';
import * as SecureStore from 'expo-secure-store';
import { ArrowLeft, ArrowUp, Check, ChevronRight, FilePlus2, Heart, Info, LockKeyhole, MessageCircle, Plus, Search, Settings, ShieldCheck, Smartphone, Sparkles, Users, X } from 'lucide-react-native';
import { productCopy, productLocale, type VeilCopyKey, type VeilLocale } from './veil-product/copy';
import { colors, styles } from './veil-product/theme';
import { veilProductNativeConsumer } from './veil-product/nativeConsumer';
import { messageStatusKey, productLimits, type VeilProductCommand, type VeilProductErrorCode } from './veil-product/productModel';
import { veilProductController } from './veil-product/productController';
import { createLocalePreferences } from './veil-product/localePreferences';
import { localDeviceSetupGate, localAuthenticationGate, canContinueLocalAuthentication, type LocalDeviceSetupResult, type LocalAuthenticationStatus } from './veil-product/localDeviceSetup';
import {AccountLoginPanel} from './veil-product/AccountLoginPanel';
import {accountLoginGate} from './veil-product/accountLogin';
import {LocalRecoveryPanel} from './veil-product/LocalRecoveryPanel';
import {FirstDeviceChallengePanel} from './veil-product/FirstDeviceChallengePanel';

type Section = 'chats' | 'friends' | 'moments' | 'settings';
type Icon = typeof MessageCircle;
const navigation: ReadonlyArray<{ key: Section; icon: Icon }> = [
  { key: 'chats', icon: MessageCircle }, { key: 'friends', icon: Users },
  { key: 'moments', icon: Heart }, { key: 'settings', icon: Settings },
];
const localePreferences = createLocalePreferences({
  async read(key) {
    if (Platform.OS === 'web') return globalThis.localStorage.getItem(key);
    return SecureStore.getItemAsync(key);
  },
  async write(key, value) {
    if (Platform.OS === 'web') globalThis.localStorage.setItem(key, value);
    else await SecureStore.setItemAsync(key, value);
  },
});
const errorCopy: Record<VeilProductErrorCode, VeilCopyKey> = {
  UNAVAILABLE: 'connectionTitle', INPUT_INVALID: 'inputInvalid', LOCKED: 'locked',
  STALE_VIEW: 'staleView', REVIEW_REQUIRED: 'reviewRequired', OUTCOME_UNKNOWN: 'unknown',
  BOUNDARY_INVALID: 'reviewRequired',
};
const localSetupCopy: Record<LocalDeviceSetupResult['status'], VeilCopyKey> = {
  LOCAL_INITIALIZATION_PENDING: 'localDevicePending', RECOVERY_REQUIRED: 'localDeviceRecovery',
  AUTHENTICATION_CANCELLED: 'localDeviceCancelled', SCREEN_LOCK_REQUIRED: 'localDeviceScreenLock',
  UNAVAILABLE: 'localDeviceUnavailable', OBSERVATION_TIMEOUT: 'localDeviceTimeout',
};
const localAuthenticationCopy: Record<'en' | 'zh', Record<LocalAuthenticationStatus, string>> = {
  en: {
    LOCAL_SETUP_REQUIRED: 'First prepare this device using the original local setup below, then return here. No authentication attempt has started.',
    LOCAL_INSPECTION_REQUIRED: 'First use Local recovery check to inspect the original operation, then return here. No authentication attempt has started.',
    AUTHENTICATION_ELIGIBLE: 'The original local operation can be checked. This is not authentication or device approval.',
    AUTHENTICATION_PENDING: 'The original device check is still pending. Observe it without starting another prompt.',
    LOCAL_KEYS_AUTHENTICATED: 'Local key verification is complete. Device authorization is still required; chat is not unlocked.',
    AUTHENTICATION_CANCELLED: 'Screen-lock verification was cancelled. Your original local operation is retained. You can explicitly confirm again.',
    SCREEN_LOCK_REQUIRED: 'Set a system screen lock, then confirm again. Your original local operation is retained.',
    RECOVERY_REQUIRED: 'The original local operation needs recovery. No new keys or device authorization were created.',
    UNAVAILABLE: 'The original local operation or native authentication interface is unavailable.',
  },
  zh: {
    LOCAL_SETUP_REQUIRED: '请先通过下方原本机设置准备此设备，再返回这里。尚未开始认证操作。',
    LOCAL_INSPECTION_REQUIRED: '请先使用“本机恢复检查”检查原操作，再返回这里。尚未开始认证操作。',
    AUTHENTICATION_ELIGIBLE: '原本机操作可继续检查；这不是认证成功或设备批准。',
    AUTHENTICATION_PENDING: '原设备检查仍在等待。可观察原结果，不会启动另一个验证窗口。',
    LOCAL_KEYS_AUTHENTICATED: '本机密钥验证已完成。设备仍需授权，聊天尚未解锁。',
    AUTHENTICATION_CANCELLED: '屏幕锁验证已取消，原本机操作仍保留。可主动再次确认。',
    SCREEN_LOCK_REQUIRED: '请先设置系统屏幕锁，再次确认。原本机操作仍保留。',
    RECOVERY_REQUIRED: '原本机操作需要恢复处理，没有创建新密钥或授予设备权限。',
    UNAVAILABLE: '原本机操作或原生认证接口不可用。',
  },
};

/** Main's normal root. Native consumer is source-owned; no fake supplier props. */
export default function VeilSocialApp() {
  const [locale, setLocale] = useState<VeilLocale>(() => productLocale(getLocales()[0]?.languageTag));
  const [localeSaveFailed, setLocaleSaveFailed] = useState(false);
  const [section, setSection] = useState<Section>('chats');
  const controller = veilProductController;
  const flow = useSyncExternalStore(controller.subscribe, controller.getSnapshot, controller.getSnapshot);
  const snapshot = flow.snapshot;
  const [search, setSearch] = useState('');
  const [friendSearch, setFriendSearch] = useState('');
  const [body, setBody] = useState('');
  const [identifier, setIdentifier] = useState('');
const [momentBody, setMomentBody] = useState('');
const [keyboardVisible, setKeyboardVisible] = useState(false);
const settingsScroll = useRef<ScrollView>(null);
const welcomeScroll = useRef<ScrollView>(null);
const languageAnchorPending = useRef(false);
useEffect(() => {
  if (section === 'settings') settingsScroll.current?.scrollTo({ y: 0, animated: false });
  if (section === 'chats') welcomeScroll.current?.scrollTo({ y: 0, animated: false });
}, [section]);
useEffect(() => {
  const shown = Keyboard.addListener('keyboardDidShow', () => setKeyboardVisible(true));
  const hidden = Keyboard.addListener('keyboardDidHide', () => setKeyboardVisible(false));
  return () => { shown.remove(); hidden.remove(); };
}, []);

  const [audienceId, setAudienceId] = useState<string | null>(null);
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [attachment, setAttachment] = useState<{ reference: string; name: string } | null>(null);
  const [feedback, setFeedback] = useState<VeilCopyKey | null>(null);
  const busy = flow.busy;
  const [dialog, setDialog] = useState(false);
  const [mobileConversation, setMobileConversation] = useState(false);
  const [diagnostics, setDiagnostics] = useState(false);
  const [selectedEntryIntent, setEntryIntent] = useState<AccountEntryCase>('newIdentityFirstDevice');
  const [localSetupFeedback, setLocalSetupFeedback] = useState<VeilCopyKey | null>(null);
  const localAuthentication = useSyncExternalStore(localAuthenticationGate.subscribe, localAuthenticationGate.getSnapshot, localAuthenticationGate.getSnapshot);
  const initialSetupBusy = useSyncExternalStore(localDeviceSetupGate.subscribe, localDeviceSetupGate.isPending, localDeviceSetupGate.isPending);
  const localLifecycle = useSyncExternalStore(ownerLifecycleGate.subscribe, ownerLifecycleGate.getSnapshot, ownerLifecycleGate.getSnapshot);
  const localClosing = localLifecycle.selected || (!!localLifecycle.result && localLifecycle.result.closeStatus !== 'NOT_SELECTED');
  const localSetupBusy = initialSetupBusy || localAuthentication.pending;
  const accountLoginAttempt = useSyncExternalStore(accountLoginGate.subscribe, accountLoginGate.getSnapshot, accountLoginGate.getSnapshot);
  const accountLoginBusy = accountLoginAttempt.pending;
  const entryIntent = accountLoginAttempt.intent ?? selectedEntryIntent;
  const entry = selectAccountEntry(entryIntent);
  const localEntry = localEntryPresentation(snapshot?.kind === 'UNAVAILABLE' ? snapshot.localOwner : undefined, entryIntent);
  const entryCapabilities = veilProductNativeConsumer.readAccountEntryCapabilities();
  const accountBindingInput = veilProductNativeConsumer.readAccountBindingInput();
  const alive = useRef(true);
  const localeRevision = useRef(0);
  const draftScope = useRef<string | null>(null);
  const bodyRevision = useRef(0);
  const identifierRevision = useRef(0);
  const momentRevision = useRef(0);
  const ready = snapshot?.kind === 'AUTHORIZED' ? snapshot : null;
  const deviceObservation = snapshot?.kind === 'UNAVAILABLE' ? snapshot.deviceObservation : undefined;
  const sessionObservation = snapshot?.kind === 'UNAVAILABLE' ? snapshot.sessionObservation : undefined;
  const conversationId = ready?.activeConversationId ?? null;
  const conversation = ready?.conversations.find(item => item.id === conversationId);
  const { width } = useWindowDimensions();
  const wide = width >= 880;
  const t = (key: VeilCopyKey) => productCopy(locale, key);

  const currentScope = snapshot?.kind === 'AUTHORIZED' || snapshot?.kind === 'RECOVERY_REQUIRED' ? snapshot.accountViewRef : null;
  const pendingOriginals = flow.pending.filter(item => item.accountViewRef === currentScope && (item.resolution === 'unresolved' || (item.resolution === 'aborted' && item.nextStep !== 'new-draft')));
  useEffect(() => {
    const nextScope = currentScope;
    clearAccountFeedback(draftScope.current, nextScope, setFeedback);
    if (nextScope !== draftScope.current) {
      void veilProductNativeConsumer.advanceAccountBindingContext().catch(() => {});
      setBody(''); setIdentifier(''); setMomentBody(''); setAudienceId(null);
      setReplyTo(null); setAttachment(null);
      ++bodyRevision.current; ++identifierRevision.current; ++momentRevision.current;
      setSearch(''); setFriendSearch('');
    }
    draftScope.current = nextScope;
  }, [currentScope]);
  useEffect(() => { setReplyTo(null); setAttachment(null); }, [conversationId, ready?.viewRevision]);
  const refresh = async () => {
    const lease = controller.beginRead();
    if (!lease) return;
    try {
      const raw = await veilProductNativeConsumer.readSnapshot(lease.context);
      controller.completeRead(lease, raw);
    } catch { controller.fail(lease); }
    finally { controller.release(lease); }
  };
  useEffect(() => {
    alive.current = true;
    const preferenceVersion = localeRevision.current;
    void localePreferences.read().then(value => {
      if (value && alive.current && localeRevision.current === preferenceVersion) setLocale(value);
    }).catch(() => {});
    controller.activate();
    const removeNativeInvalidation = veilProductNativeConsumer.subscribeInvalidation(() => controller.invalidate());
    const appState = AppState.addEventListener('change', state => {
      void veilProductNativeConsumer.advanceAccountBindingContext().catch(() => {});
      if (state === 'active') controller.activate(); else controller.deactivate();
    });
    return () => { alive.current = false; ++localeRevision.current; removeNativeInvalidation?.(); appState.remove(); controller.deactivate(); void veilProductNativeConsumer.advanceAccountBindingContext().catch(() => {}); };
  }, []);
  useEffect(() => { if (alive.current && flow.active && !flow.busy && flow.needsRead) void refresh(); }, [flow.active, flow.busy, flow.needsRead, flow.epoch]);
  const changeLocale = (value: VeilLocale) => {
    const current = ++localeRevision.current;
    setLocale(value); setLocaleSaveFailed(false);
    void localePreferences.write(value).catch(() => {
      if (alive.current && localeRevision.current === current) setLocaleSaveFailed(true);
    });
  };
  const prepareLocalDevice = async () => {
    if (Platform.OS !== 'android' || entryIntent !== 'newIdentityFirstDevice' || ready || localDeviceSetupGate.isPending() || accountLoginGate.isPending()) return;
    const current = controller.getSnapshot().snapshot;
    if (!localEntryPresentation(current?.kind === 'UNAVAILABLE' ? current.localOwner : undefined, accountLoginGate.getSnapshot().intent ?? entryIntent).canPrepare) return;
    setLocalSetupFeedback(null);
    const result = await localDeviceSetupGate.observe(locale);
    // This result never changes the product account, device or messaging state.
    if (alive.current && controller.getSnapshot().snapshot?.kind !== 'AUTHORIZED') {
      setLocalSetupFeedback(localSetupCopy[result.status]);
      void refresh();
    }
  };
  const blocked = (action: VeilProductCommand['type']) => !controller.canExecute(action);
  const run = async (command: VeilProductCommand) => {
    const draftRevision = command.type === 'sendMessage' || command.type === 'sendAttachment' ? bodyRevision.current : command.type === 'requestContact' ? identifierRevision.current : command.type === 'publishMoment' ? momentRevision.current : null;
    const lease = controller.beginExecute(command, draftRevision);
    if (!lease) return;
    setFeedback(null);
    try {
      const raw = await veilProductNativeConsumer.execute(command, lease.context);
      const result = controller.completeExecute(lease, raw);
      if (!alive.current || !result) return;
      if (result.kind === 'error') {
        setFeedback(errorCopy[result.code]);
      } else if (result.kind === 'pending') {
        setFeedback(result.disposition);
        // Keep the local draft. No optimistic message row or delivery receipt.
      } else if (result.kind === 'attachmentSelection') {
        setAttachment({ reference: result.selectionReference, name: result.displayName });
      } else if (result.kind === 'recovery') {
        setFeedback('recoveryNeeded');
      } else if (result.kind === 'originalReview') {
        setFeedback(result.resolution === 'unresolved' ? 'unknown' : 'confirmed');
        const original = pendingOriginals.find(item => item.originalOperationRef === result.originalOperationRef);
        if (original && result.resolution === 'confirmed') {
          if ((original.action === 'sendMessage' || original.action === 'sendAttachment') && bodyRevision.current === original.draftRevision) { setBody(''); setReplyTo(null); setAttachment(null); }
          if (original.action === 'requestContact' && identifierRevision.current === original.draftRevision) setIdentifier('');
          if (original.action === 'publishMoment' && momentRevision.current === original.draftRevision) setMomentBody('');
        }
      } else {
        if (result.completion === 'confirmed') {
          setFeedback('confirmed');
          if (command.type === 'sendMessage') {
            if (bodyRevision.current === draftRevision) { setBody(''); setReplyTo(null); }
          } else if (command.type === 'sendAttachment') setAttachment(null);
          else if (command.type === 'requestContact') { if (identifierRevision.current === draftRevision) setIdentifier(''); setDialog(false); }
          else if (command.type === 'publishMoment' && momentRevision.current === draftRevision) setMomentBody('');
        }
      }
    } catch {
      failRootOperation(controller, lease, () => alive.current, setFeedback);
    } finally {
      controller.release(lease);
    }
  };
  const select = (next: Section) => { setSection(next); setDialog(false); setMobileConversation(false); };
  const statusKey: VeilCopyKey = snapshot?.kind === 'LOCKED' ? 'locked' : snapshot?.kind === 'RECOVERY_REQUIRED' ? 'recoveryNeeded' : snapshot?.kind === 'AUTHORIZED' ? 'confirmed' : snapshot ? 'unavailable' : 'checking';
  const badge = <View style={styles.pill}><Text style={styles.pillText}>{t(statusKey)}</Text></View>;
  const actionButton = (label: VeilCopyKey, action: VeilProductCommand['type'], build: () => VeilProductCommand | null, extraBlocked = false, Glyph?: Icon) => {
    const disabled = blocked(action) || extraBlocked;
    return <Pressable accessibilityRole="button" accessibilityLabel={t(label)} accessibilityState={{ disabled }} disabled={disabled}
      onPress={() => { const command = build(); if (command) void run(command); }}
      style={[styles.button, disabled && styles.buttonDisabled]}>
      {Glyph && <Glyph size={18} color={disabled ? colors.muted : '#fff'} />}
      <Text style={[styles.buttonText, disabled && styles.buttonDisabledText]}>{t(label)}</Text>
    </Pressable>;
  };
  const empty = (Glyph: Icon, title: VeilCopyKey, detail: VeilCopyKey, atmospheric = false) =>
    <View style={styles.empty}>
      {atmospheric && <><View pointerEvents="none" style={styles.orbit} /><View pointerEvents="none" style={[styles.orbit, styles.orbitTwo]} /></>}
      <View style={styles.medallion}><Glyph size={38} color={colors.accent} strokeWidth={1.4} /></View>
      <View style={styles.emptyCopy}><Text style={[styles.title, styles.centered]}>{t(title)}</Text><Text style={[styles.text, styles.centered]}>{t(detail)}</Text></View>
    </View>;
  const searchBox = (kind: VeilCopyKey, value: string, change: (value: string) => void) => <View style={styles.search}>
    <Search size={18} color={colors.muted} /><TextInput value={value} onChangeText={change} accessibilityLabel={t(kind)}
      placeholder={t(kind)} placeholderTextColor={colors.muted} style={styles.input} maxLength={productLimits.query} autoCorrect={false} />
    {!!value && <Pressable onPress={() => change('')} accessibilityRole="button" accessibilityLabel={t('close')} hitSlop={12}><X size={18} color={colors.muted} /></Pressable>}
  </View>;
  const card = (Glyph: Icon, title: VeilCopyKey, detail: VeilCopyKey, content?: React.ReactNode) =>
    <View style={styles.card}><View style={styles.cardHeader}><Glyph color={colors.accent} size={24} /><Text style={[styles.strong, styles.grow]}>{t(title)}</Text></View><Text style={styles.text}>{t(detail)}</Text>{content}</View>;

  const conversationPane = <KeyboardAvoidingView style={styles.pane} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    {!wide && <View style={styles.paneTop}><Pressable onPress={() => setMobileConversation(false)} accessibilityRole="button" accessibilityLabel={t('back')}><ArrowLeft color={colors.accent} size={24} /></Pressable></View>}
    {ready && conversationId ? <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
      <Text style={styles.title}>{conversation?.title}</Text>
      {ready.messages.filter(message => message.conversationId === conversationId).map(message => <View key={message.id} style={[styles.bubble, message.direction === 'outgoing' && styles.outgoingBubble]}>
        <Text style={styles.strong}>{message.senderLabel}</Text><Text style={styles.text}>{message.body}</Text>
        <Text style={styles.caption}>{t(messageStatusKey(message))}</Text>
        <Pressable accessibilityRole="button" accessibilityLabel={t('reply')} onPress={() => setReplyTo(message.id)}><Text style={styles.strong}>{t('reply')}</Text></Pressable>
        {message.attachments.map(item => actionButton('attachment', 'openAttachment', () => ({ type: 'openAttachment', viewRevision: ready.viewRevision, conversationId, messageId: message.id, attachmentReference: item.reference }), false, FilePlus2))}
      </View>)}
    </ScrollView> : empty(MessageCircle, 'chooseChat', 'conversationDetail', true)}
    <View style={styles.composer}>
      {replyTo && <View style={styles.row}><Text style={styles.strong}>{t('reply')}</Text><Pressable accessibilityRole="button" accessibilityLabel={t('cancelReply')} onPress={() => setReplyTo(null)}><X size={18} color={colors.muted} /></Pressable></View>}
      <Text style={styles.caption}>{t('localDraft')}</Text>
      <View style={styles.composerField}>
        <Pressable disabled={blocked('selectAttachment') || !conversationId} accessibilityRole="button" accessibilityLabel={t('attachment')}
          accessibilityState={{ disabled: blocked('selectAttachment') || !conversationId }}
          onPress={() => { if (ready && conversationId) void run({ type: 'selectAttachment', viewRevision: ready.viewRevision, conversationId }); }}>
          <FilePlus2 size={23} color={blocked('selectAttachment') ? colors.disabled : colors.accent} />
        </Pressable>
        <TextInput value={body} onChangeText={value => { ++bodyRevision.current; setBody(value); }} multiline maxLength={productLimits.body} accessibilityLabel={t('messageDraft')}
          placeholder={t('messageDraft')} placeholderTextColor={colors.muted} style={styles.input} />
        <Pressable disabled={blocked('sendMessage') || !conversationId || !body.trim()} accessibilityRole="button" accessibilityLabel={t('send')}
          accessibilityState={{ disabled: blocked('sendMessage') || !conversationId || !body.trim() }}
          onPress={() => { if (ready && conversationId) void run({ type: 'sendMessage', viewRevision: ready.viewRevision, conversationId, body, replyToMessageId: replyTo }); }}
          style={[styles.button, (blocked('sendMessage') || !conversationId || !body.trim()) && styles.buttonDisabled]}>
          <ArrowUp size={20} color={blocked('sendMessage') ? colors.muted : '#fff'} />
        </Pressable>
      </View>
      {attachment && <View style={styles.wrapRow}><Text style={styles.text}>{attachment.name}</Text>
        {actionButton('sendAttachment', 'sendAttachment', () => ready && conversationId ? { type: 'sendAttachment', viewRevision: ready.viewRevision, conversationId, selectionReference: attachment.reference, caption: body } : null, !conversationId)}
      </View>}
    </View>
  </KeyboardAvoidingView>;
  const chats = <View style={wide ? styles.split : styles.pane}>
    {(wide || !mobileConversation) && <View style={wide ? styles.listPane : styles.pane}>
      <View style={styles.paneTop}><Text style={styles.title}>{t('chats')}</Text>{searchBox('search', search, setSearch)}</View>
      {ready ? <ScrollView>{ready.conversations.filter(item => (item.title + ' ' + item.preview).toLocaleLowerCase().includes(search.toLocaleLowerCase())).map(item =>
        <Pressable key={item.id} disabled={blocked('openConversation')} accessibilityRole="button" accessibilityLabel={item.title}
          accessibilityState={{ disabled: blocked('openConversation') }} style={styles.listRow}
          onPress={() => { setMobileConversation(true); void run({ type: 'openConversation', viewRevision: ready.viewRevision, conversationId: item.id }); }}>
          <Text style={styles.strong}>{item.title}</Text><Text style={styles.text}>{item.preview}</Text>
        </Pressable>)}</ScrollView> : search ? empty(Search, 'searchResults', 'searchUnavailable') : empty(MessageCircle, 'chatTitle', 'chatDetail')}
      {!wide && <Pressable onPress={() => setMobileConversation(true)} accessibilityRole="button" accessibilityLabel={t('chooseChat')} style={[styles.button, styles.buttonSecondary, styles.mobileChatLink]}>
        <Text style={[styles.buttonText, styles.buttonSecondaryText]}>{t('chooseChat')}</Text><ChevronRight color={colors.accent} size={18} />
      </Pressable>}
    </View>}
    {(wide || mobileConversation) && conversationPane}
  </View>;

const connectionNotice = snapshot?.kind !== 'AUTHORIZED' ? <View style={styles.compactNotice}>
  <Info size={16} color={colors.warm} /><Text style={[styles.caption, styles.grow]}>{t(statusKey)}</Text>
  <Pressable onPress={() => select('settings')} accessibilityRole="button" accessibilityLabel={t('details')}><Text style={styles.caption}>{t('details')}</Text></Pressable>
</View> : null;
  const friends = <ScrollView key="friends" style={styles.pane} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
    {connectionNotice}
    <View style={styles.wrapRow}><Text style={[styles.pageTitle, styles.grow]}>{t('friends')}</Text><Pressable accessibilityRole="button" accessibilityLabel={t('addFriend')} onPress={() => setDialog(true)} style={styles.button}><Plus size={18} color="#fff" /><Text style={styles.buttonText}>{t('addFriend')}</Text></Pressable></View>
    {searchBox('searchFriends', friendSearch, setFriendSearch)}
    {card(Users, 'friendsTitle', 'friendsDetail', ready ? <>
      {ready.contacts.filter(item => (item.displayName + ' ' + item.publicIdentifier).toLocaleLowerCase().includes(friendSearch.toLocaleLowerCase())).map(item => <View key={item.id}><Text style={styles.strong}>{item.displayName}</Text><Text style={styles.text}>{item.publicIdentifier}</Text></View>)}
    </> : <Text style={styles.text}>{t('friendsUnavailable')}</Text>)}
    {card(ShieldCheck, 'requests', ready ? 'requestsHint' : 'requestDetail', ready ? <>{ready.contactRequests.map(item => <View key={item.id} style={styles.wrapRow}><Text style={[styles.strong, styles.grow]}>{item.displayName}</Text>{actionButton('accept', 'acceptContact', () => ({ type: 'acceptContact', viewRevision: ready.viewRevision, requestId: item.id }))}</View>)}</> : badge)}
  </ScrollView>;
  const moments = <ScrollView key="moments" style={styles.pane} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
    {connectionNotice}
    <Text style={styles.pageTitle}>{t('moments')}</Text>
    {card(Heart, 'momentTitle', 'momentDetail', <>
      <View style={styles.search}><TextInput value={momentBody} onChangeText={value => { ++momentRevision.current; setMomentBody(value); }} maxLength={productLimits.moment} multiline placeholder={t('momentPlaceholder')} accessibilityLabel={t('momentPlaceholder')} placeholderTextColor={colors.muted} style={[styles.input, { minHeight: 80, maxHeight: 160, textAlignVertical: 'top' }]} /></View>
      <Text style={styles.strong}>{t('audience')}</Text>
      <View style={styles.wrapRow}>{ready?.audiences.map(item => <Pressable key={item.id} accessibilityRole="button" accessibilityState={{ selected: audienceId === item.id }} onPress={() => setAudienceId(item.id)} style={[styles.languageButton, audienceId === item.id && styles.languageSelected]}><Text style={styles.text}>{item.label}</Text></Pressable>)}</View>
      {!audienceId && <Text style={styles.caption}>{t('audienceRequired')}</Text>}
      {actionButton('publish', 'publishMoment', () => ready && audienceId ? { type: 'publishMoment', viewRevision: ready.viewRevision, body: momentBody, audienceId } : null, !audienceId || !momentBody.trim(), Plus)}
    </>)}
    {ready?.moments.map(item => <View key={item.id} style={styles.card}><Text style={styles.strong}>{item.authorLabel}</Text><Text style={styles.text}>{item.body}</Text><Text style={styles.caption}>{item.audienceLabel}</Text></View>)}
  </ScrollView>;
  const recoveryItems = ready?.recoveries ?? (snapshot?.kind === 'RECOVERY_REQUIRED' ? snapshot.items : []);
  const accountSetup = <>
    {!ready && <View style={styles.card}><Text style={styles.strong}>{t('accountEntry')}</Text>
      {Platform.OS === 'android' ? <AccountLoginPanel intent={entryIntent} locale={locale} disabled={localSetupBusy || busy} /> : <>
        <Text style={styles.caption}>{t('entryNotConnected')}</Text>
        {accountBindingInput.status === 'UNAVAILABLE_AUTH_PRODUCER' && <Text style={styles.caption}>{t('authProducerMissing')}</Text>}
      </>}
      <Text style={styles.text}>{t('accountEntryDetail')}</Text>
      <View style={styles.wrapRow}>{entryCapabilities.map(item => <Pressable key={item.intent} accessibilityRole="button" disabled={localSetupBusy || accountLoginBusy || !accountLoginGate.canSelectIntent(item.intent)} accessibilityState={{ selected: entryIntent === item.intent, disabled: localSetupBusy || accountLoginBusy || !accountLoginGate.canSelectIntent(item.intent) }} onPress={() => { if (!accountLoginGate.canSelectIntent(item.intent)) return; setLocalSetupFeedback(null); setEntryIntent(item.intent); }} style={[styles.languageButton, entryIntent === item.intent && styles.languageSelected]}><Text style={styles.strong}>{t(item.intent)}</Text></Pressable>)}</View>
      <Text style={styles.text}>{t(entryIntent === 'newIdentityFirstDevice' ? 'firstDeviceDetail' : entryIntent === 'existingIdentityAddDevice' ? 'addDeviceDetail' : entryIntent === 'restoreIdentity' ? 'restoreEntryDetail' : 'revokedEntryDetail')}</Text>
      <Text style={styles.caption}>{t('loginNotGrant')}</Text>
      {Platform.OS === 'android' && !localClosing && localEntry.mode !== 'closed' && entryIntent === 'newIdentityFirstDevice' && <>
        <Text style={styles.text}>{t('prepareLocalDeviceDetail')}</Text>
        <Pressable accessibilityRole="button" accessibilityLabel={t('prepareLocalDevice')} disabled={!localEntry.canPrepare || localSetupBusy || accountLoginBusy || busy}
          accessibilityState={{ disabled: !localEntry.canPrepare || localSetupBusy || accountLoginBusy || busy }} onPress={() => void prepareLocalDevice()}
          style={[styles.button, (!localEntry.canPrepare || localSetupBusy || accountLoginBusy || busy) && styles.buttonDisabled]}>
          <Text style={[styles.buttonText, (!localEntry.canPrepare || localSetupBusy || accountLoginBusy || busy) && styles.buttonDisabledText]}>{t(localSetupBusy ? 'preparingLocalDevice' : 'prepareLocalDevice')}</Text>
        </Pressable>
        {localEntry.mode !== 'prepare' && <Text style={styles.caption}>{t(localEntry.mode === 'checking' ? 'localEntryChecking' : localEntry.mode === 'retained' ? 'localEntryRetained' : 'localEntryUnavailable')}</Text>}
        {localSetupFeedback && <Text accessibilityLiveRegion="polite" style={styles.text}>{t(localSetupFeedback)}</Text>}
      </>}
      {diagnostics && <><Text style={styles.text}>{entry.requirements.join('\n')}</Text><Text style={styles.text}>{t('sourceEnrollmentGap')}</Text></>}
    </View>}
  </>;
  const originalLocalControls = <>
    {Platform.OS === 'android' && !localClosing && localEntry.showOriginal && <View style={styles.card}>
      <Text style={styles.strong}>{locale === 'zh' ? '继续设置此设备' : 'Continue setting up this device'}</Text>
      <Text style={styles.text}>{locale === 'zh' ? '通过系统屏幕锁验证原本机密钥。这不会登录账号或批准设备。' : 'Use the system screen lock to verify the original local keys. This does not sign in or approve a device.'}</Text>
      <Pressable accessibilityRole="button" disabled={localSetupBusy || accountLoginBusy || busy || !!localAuthentication.result && !canContinueLocalAuthentication(localAuthentication.result.status)}
        onPress={() => { void localAuthenticationGate.inspect(locale); }} style={styles.button}>
        <Text style={styles.buttonText}>{locale === 'zh' ? (localAuthentication.result?.status === 'AUTHENTICATION_PENDING' ? '观察原验证' : '验证此设备') : (localAuthentication.result?.status === 'AUTHENTICATION_PENDING' ? 'Observe original verification' : 'Verify this device')}</Text>
      </Pressable>
      {(localAuthentication.pending || localAuthentication.result) && <Text accessibilityLiveRegion="polite" style={styles.text}>{localAuthenticationCopy[locale][localAuthentication.pending ? 'AUTHENTICATION_PENDING' : localAuthentication.result!.status]}</Text>}
    </View>}
    {Platform.OS === 'android' && !localClosing && localEntry.showOriginal && <LocalRecoveryPanel locale={locale} disabled={localSetupBusy || accountLoginBusy || busy} />}
    {Platform.OS === 'android' && !ready && entryIntent === 'newIdentityFirstDevice' && (!localClosing && localEntry.showOriginal) && <FirstDeviceChallengePanel locale={locale} disabled={localSetupBusy || accountLoginBusy || busy} />}
  </>;
  const welcome = <ScrollView key="welcome" style={styles.pane} ref={welcomeScroll} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <Text style={styles.pageTitle}>{t('welcomeTitle')}</Text>
    <Text style={styles.text}>{t('welcomeDetail')}</Text>
    {accountSetup}
    {originalLocalControls}
    <Text style={styles.caption}>{t('setupStatusDetail')}</Text>
  </ScrollView>;
  const settings = <ScrollView key="settings" ref={settingsScroll} style={styles.pane} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" onContentSizeChange={() => { if (languageAnchorPending.current) { settingsScroll.current?.scrollTo({ y: 0, animated: false }); languageAnchorPending.current = false; } }}>
    <Text style={styles.pageTitle}>{t('settings')}</Text>
    <View style={styles.card}><Text style={styles.strong}>{t('language')}</Text><View style={styles.wrapRow}>
      {(['en', 'zh'] as const).map(value => <Pressable key={value} accessibilityRole="button" accessibilityState={{ selected: locale === value }} onPress={() => { languageAnchorPending.current = true; changeLocale(value); settingsScroll.current?.scrollTo({ y: 0, animated: false }); }} style={[styles.languageButton, locale === value && styles.languageSelected]}><View style={styles.row}><Text style={styles.strong}>{t(value === 'en' ? 'english' : 'chinese')}</Text>{locale === value && <Check size={17} color={colors.accent} />}</View></Pressable>)}
    </View>{localeSaveFailed && <Text style={styles.text}>{t('languageSaveFailed')}</Text>}</View>
    {accountSetup}
    {originalLocalControls}
    {card(Users, 'profile', ready ? 'profileHint' : 'profileDetail', ready ? <><Text style={styles.strong}>{ready.profile.displayName}</Text><Text style={styles.text}>{ready.profile.publicIdentifier}</Text></> : badge)}
    {Platform.OS === 'android' && <OwnerLifecyclePanel locale={locale} disabled={localSetupBusy || accountLoginBusy || busy} />}
    {card(Smartphone, 'devices', 'deviceDetail', <>
      {deviceObservation && <View style={{ gap: 8 }}>
        <Text style={styles.strong}>{locale === 'zh' ? '已取得此设备的验证结果' : 'Device verification observed'}</Text>
        <Text style={styles.text}>{deviceObservation.device}</Text>
        <Text style={styles.caption}>{sessionObservation
          ? (locale === 'zh' ? '已观察到安全会话。消息投递仍在接入中，暂时不能发送。' : 'A secure session was observed. Message delivery is still being connected; sending is unavailable.')
          : (locale === 'zh' ? '这是设备验证结果，不代表聊天已就绪。安全会话尚未接通，暂时不能发送消息。' : 'This is a device verification result, not chat readiness. Secure chat is not connected yet; messages cannot be sent.')}</Text>
      </View>}
      {ready?.devices.map(item => <View key={item.id} style={styles.wrapRow}><Text style={[styles.strong, styles.grow]}>{item.label}</Text>{actionButton('approve', 'reviewDevice', () => ({ type: 'reviewDevice', viewRevision: ready.viewRevision, deviceId: item.id }))}</View>)}
    </>)}
    {card(LockKeyhole, 'recovery', 'recoveryDetail', <>{recoveryItems.map(item => <View key={item.originalOperationRef} style={{ gap: 10 }}><Text style={styles.text}>{item.label}</Text>{actionButton('pendingOriginal', 'reviewRecovery', () => ({ type: 'reviewRecovery', originalOperationRef: item.originalOperationRef }))}</View>)}
      {pendingOriginals.map(item => <View key={item.localCallId} style={{ gap: 8 }}><Text style={styles.text}>{t(item.disposition)}</Text>{item.originalOperationRef ? actionButton('pendingOriginal', 'reviewRecovery', () => ({ type: 'reviewRecovery', originalOperationRef: item.originalOperationRef! })) : <Text style={styles.text}>{t('reviewRequired')}</Text>}</View>)}
    </>)}
    {card(Sparkles, 'localAi', 'aiDetail', actionButton(ready?.localAi === 'on' ? 'aiDisable' : 'aiEnable', 'setLocalAi', () => ready ? { type: 'setLocalAi', viewRevision: ready.viewRevision, preference: ready.localAi === 'on' ? 'off' : 'on' } : null, ready?.localAi === 'unsupported'))}

    <View style={styles.card}><View style={styles.wrapRow}><Text style={[styles.strong, styles.grow]}>{t('availability')}</Text>{badge}</View>
      {snapshot?.kind === 'UNAVAILABLE' && snapshot.localOwner && <Text style={styles.text}>{t(snapshot.localOwner.status === 'OBSERVED' ? (snapshot.localOwner.failureRetained || snapshot.localOwner.ownerState === 'INIT_FAILED' ? 'ownerReadFailed' : 'ownerObserved') : snapshot.localOwner.status === 'READ_TIMEOUT' ? 'ownerReadTimeout' : snapshot.localOwner.status === 'MODULE_UNAVAILABLE' ? 'ownerMissing' : 'ownerReadFailed')}</Text>}
      <Pressable onPress={() => void refresh()} disabled={busy} accessibilityRole="button" accessibilityLabel={t('refresh')} style={styles.button}><Text style={styles.buttonText}>{t('refresh')}</Text></Pressable>
      <Pressable onPress={() => setDiagnostics(value => !value)} accessibilityRole="button" accessibilityLabel={t('diagnostics')}><Text style={styles.text}>{t('diagnostics')}</Text></Pressable>
      {diagnostics && snapshot?.kind === 'UNAVAILABLE' && <>
        <Text style={styles.text}>{snapshot.gaps.join('\n')}</Text>
        {snapshot.localOwner && <Text style={styles.text}>{JSON.stringify(snapshot.localOwner)}</Text>}
        <Text style={styles.text}>{t('nativeDependencyGap')}</Text>
        {([['nativeGap', 'nativeGapDetail'], ['issuerGap', 'issuerGapDetail'], ['storeGap', 'storeGapDetail'], ['restoreGap', 'restoreGapDetail']] as const).map(([title, detail]) => <View key={title}><Text style={styles.strong}>{t(title)}</Text><Text style={styles.text}>{t(detail)}</Text></View>)}
      </>}
    </View><Text style={styles.text}>{t('privacy')}</Text>
  </ScrollView>;
  const nav = (horizontal: boolean) => <View style={horizontal ? styles.mobileNav : styles.rail}>
    {navigation.map(({ key, icon: Glyph }) => <Pressable key={key} accessibilityRole="tab" accessibilityLabel={t(key)} accessibilityState={{ selected: section === key }} onPress={() => select(key)} style={[styles.nav, horizontal ? styles.grow : styles.railNav, section === key && styles.navActive]}><Glyph size={23} color={section === key ? colors.accent : colors.muted} strokeWidth={1.7} /><Text style={[styles.navText, section === key && styles.navTextActive]}>{t(key)}</Text></Pressable>)}
  </View>;
  return <SafeAreaProvider><SafeAreaView style={styles.root} edges={['top', 'bottom', 'left', 'right']}><KeyboardAvoidingView style={styles.pane} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
    <View style={[styles.header, keyboardVisible && styles.keyboardHeader]}><Image source={require('../assets/ynx-original-logo.png')} accessibilityLabel="YNX" resizeMode="contain" style={styles.logo} /><View style={styles.grow}><Text style={styles.brand}>{t('product')}</Text>{!keyboardVisible && <Text style={styles.caption}>{t('subtitle')}</Text>}</View>{busy || !snapshot ? <ActivityIndicator color={colors.accent} /> : <Pressable onPress={() => select('settings')} accessibilityRole="button" accessibilityLabel={t('openSettings')} hitSlop={12}><Settings size={23} color={colors.accent} /></Pressable>}</View>
    <View style={[styles.body, wide && styles.desktop]}>{wide && nav(false)}<View style={styles.workspace}>
      {(flow.error || feedback) && <View style={styles.feedback} accessibilityLiveRegion="polite"><Text style={styles.text}>{t(flow.error ? errorCopy[flow.error] : feedback!)}</Text></View>}
      {section === 'chats' ? (ready ? chats : welcome) : section === 'friends' ? friends : section === 'moments' ? moments : settings}
    </View></View>{!wide && !keyboardVisible && nav(true)}
    </KeyboardAvoidingView>
    <Modal visible={dialog} transparent animationType="fade" onRequestClose={() => setDialog(false)}><KeyboardAvoidingView style={styles.dialogShade} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}><ScrollView style={{ width: '100%', maxWidth: 480 }} contentContainerStyle={{ flexGrow: 1, justifyContent: 'center' }} keyboardShouldPersistTaps="handled"><View style={styles.dialog} accessibilityViewIsModal>
      <View style={styles.row}><Text style={[styles.title, styles.grow]}>{t('addFriend')}</Text><Pressable onPress={() => setDialog(false)} accessibilityRole="button" accessibilityLabel={t('close')} hitSlop={12}><X size={23} color={colors.muted} /></Pressable></View>
      <Text style={styles.text}>{t('friendsDetail')}</Text>
      <View style={styles.search}><TextInput value={identifier} onChangeText={value => { ++identifierRevision.current; setIdentifier(value); }} maxLength={productLimits.identifier} accessibilityLabel={t('identifier')} placeholder={t('requestDraft')} placeholderTextColor={colors.muted} style={styles.input} autoCapitalize="none" /></View>
      {!ready && <Text style={styles.text}>{t('friendsUnavailable')}</Text>}
      {actionButton('request', 'requestContact', () => ready ? { type: 'requestContact', viewRevision: ready.viewRevision, identifier } : null, !identifier.trim())}
      <Pressable onPress={() => setDialog(false)} accessibilityRole="button" accessibilityLabel={t('cancel')}><Text style={[styles.strong, styles.centered]}>{t('cancel')}</Text></Pressable>
    </View></ScrollView></KeyboardAvoidingView></Modal>
  </SafeAreaView></SafeAreaProvider>;
}
