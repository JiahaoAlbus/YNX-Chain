package com.ynx.social.pqauth.internal;

import android.content.Context;
import android.os.Build;
import android.os.Process;
import android.os.UserManager;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyInfo;
import android.security.keystore.KeyProperties;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructStat;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileDescriptor;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyStore;
import java.util.Arrays;
import javax.crypto.AEADBadTagException;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;

/* Private normal CryptoEngine candidate, no Expo/UI factory or secret getter.
 * No actual key/provider operations are run by its compile-only delivery.
 * Controlled internal direct-buffer/provider copies are NOT all-memory wipe.
 */
final class VeilOwnKeyPlatformProtector implements AutoCloseable {
    private static final byte[] DOMAIN="YNX/SOCIAL/OWN-PQ-STORAGE/V1".getBytes(StandardCharsets.US_ASCII);
    private static final byte[] CLASSIC_DOMAIN="YNX/SOCIAL/OWN-CLASSIC-STORAGE/V1".getBytes(StandardCharsets.US_ASCII);
    private final Thread owner=Thread.currentThread();
    private final int uid=Process.myUid(), pid=Process.myPid(), gid=Os.getgid();
    private final Context context;
    private final String alias;
    private FileChannel channel;
    private FileOutputStream stream;
    private FileLock lock;
    private FileDescriptor aliasFd;
    private Throwable aliasCloseFailure;
    private SecretKey key;
    private Throwable closePrimary;
    private Throwable initPrimary;
    private boolean initializationAttempted;
    private FrameworkPin dataPin, dataInfoPin, installedDataPin, noBackupPin;
    private static final class FrameworkPin {
        final File directory;
        final long dev, ino;
        FileDescriptor fd;
        Throwable closeFailure;
        FrameworkPin(File d,StructStat s){directory=d;dev=s.st_dev;ino=s.st_ino;}
    }
    private VeilOwnKeyPlatformProtector(Context c,String a){context=c;alias=a;}
    // Source-owned caller supplies the reviewed authenticated platform policy.
    // No devicegrant precondition, no default unauthenticated QA policy.
    private static VeilOwnKeyPlatformProtector prepare(Context c,String alias) throws Exception {
        if(alias==null||!alias.matches("ynx\\.social\\.ownkey\\.v1\\.[0-9a-f]{32}"))throw new GeneralSecurityException("OWN_ALIAS_PROFILE");
        VeilOwnKeyPlatformProtector p=new VeilOwnKeyPlatformProtector(c,alias);p.guard();return p;
        // NO directory/lock/key operation until native global owner is retained.
    }
    private void initializeNew(KeyGenParameterSpec policy) throws Exception {
        guard();if(initializationAttempted)throw new GeneralSecurityException("OWN_INIT_NO_RETRY");initializationAttempted=true;
        try {
        if(policy==null||alias==null||!alias.equals(policy.getKeystoreAlias())||policy.getKeySize()!=256||
            policy.getPurposes()!=(KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)||
            !policy.isUserAuthenticationRequired()||policy.getUserAuthenticationValidityDurationSeconds()<1||
            policy.getUserAuthenticationValidityDurationSeconds()>120||!policy.isRandomizedEncryptionRequired()||
            !Arrays.equals(policy.getBlockModes(),new String[]{KeyProperties.BLOCK_MODE_GCM})||
            !Arrays.equals(policy.getEncryptionPaddings(),new String[]{KeyProperties.ENCRYPTION_PADDING_NONE}))
            throw new GeneralSecurityException("OWN_KEY_AUTH_POLICY");
        reserve();VeilOwnKeyPlatformProtector p=this;
            p.guard();KeyStore s=KeyStore.getInstance("AndroidKeyStore");s.load(null);
            if(s.containsAlias(alias))throw new GeneralSecurityException("OWN_ALIAS_COLLISION_PRESERVED");
            KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");g.init(policy);
            p.guard();g.generateKey(); // failure may have created alias; NEVER delete/retry/regenerate.
            p.lookup(s);
        }catch(Throwable primary){initPrimary=primary;cleanup(primary);throw primary;}
    }
    private void initializeExisting() throws Exception {
        guard();if(initializationAttempted)throw new GeneralSecurityException("OWN_INIT_NO_RETRY");initializationAttempted=true;
        try {reserve();KeyStore s=KeyStore.getInstance("AndroidKeyStore");s.load(null);lookup(s);}
        catch(Throwable primary){initPrimary=primary;cleanup(primary);throw primary;}
    }
    private void reserve() throws Exception {
        VeilOwnKeyPlatformProtector p=this;Context c=context;
        try {
            p.guard();File data=c.getDataDir();p.guard();
            if(data==null||!data.isAbsolute())
                throw new GeneralSecurityException("OWN_CE_DATA_IDENTITY");
            p.pinFramework(data,true);
            p.pinDataViews(c);
            p.guard();File parent=c.getNoBackupFilesDir();p.guard();p.verifyFrameworkPins();
            if(parent==null||!parent.isAbsolute()||!"no_backup".equals(parent.getName()))
                throw new GeneralSecurityException("OWN_CE_NO_BACKUP_IDENTITY");
            StructStat expectedParent=Os.lstat(new File(data,"no_backup").getPath());
            StructStat actualParent=Os.lstat(parent.getPath());
            p.frameworkPolicy(expectedParent);p.frameworkPolicy(actualParent);
            if(expectedParent.st_dev!=actualParent.st_dev||expectedParent.st_ino!=actualParent.st_ino)
                throw new GeneralSecurityException("OWN_CE_NO_BACKUP_IDENTITY");
            p.pinFramework(parent,false);p.guard();p.verifyFrameworkPins();
            File dir=new File(parent,"veil-own-key-v1");
            if(!dir.exists()){if(!dir.mkdir())throw new GeneralSecurityException("OWN_DIRECTORY_CREATE");
                if(!dir.setReadable(false,false)||!dir.setWritable(false,false)||!dir.setExecutable(false,false)||
                    !dir.setReadable(true,true)||!dir.setWritable(true,true)||!dir.setExecutable(true,true))
                    throw new GeneralSecurityException("OWN_DIRECTORY_MODE");}
            p.checkDir(dir);p.guard();p.verifyFrameworkPins();
            if(!dir.getCanonicalFile().equals(new File(parent.getCanonicalFile(),"veil-own-key-v1")))throw new GeneralSecurityException("OWN_DIRECTORY_PATH");
            File f=new File(dir,alias+".lock");
            if(f.createNewFile()){
                if(!f.setReadable(false,false)||!f.setWritable(false,false)||!f.setExecutable(false,false)||
                    !f.setReadable(true,true)||!f.setWritable(true,true))throw new GeneralSecurityException("OWN_LOCK_MODE");
            }
            p.guard();p.verifyFrameworkPins();
            StructStat st=Os.lstat(f.getPath());if(!OsConstants.S_ISREG(st.st_mode)||st.st_uid!=uid||st.st_gid!=gid||(st.st_mode&07777)!=0600)
                throw new GeneralSecurityException("OWN_EXISTING_LOCK_MODE");
            p.aliasFd=Os.open(f.getPath(),OsConstants.O_RDWR|OsConstants.O_NOFOLLOW|OsConstants.O_CLOEXEC,0600);
                StructStat opened=Os.fstat(p.aliasFd);
                if(opened.st_dev!=st.st_dev||opened.st_ino!=st.st_ino||!OsConstants.S_ISREG(opened.st_mode)||
                    opened.st_uid!=uid||opened.st_gid!=gid||(opened.st_mode&07777)!=0600)
                    throw new GeneralSecurityException("OWN_LOCK_OPEN_IDENTITY");
                p.stream=new FileOutputStream(p.aliasFd);
                p.aliasFd=null; // Confirmed transfer only after wrapper publication.
                p.channel=p.stream.getChannel();
            p.lock=p.channel.tryLock();
            if(p.lock==null)throw new GeneralSecurityException("OWN_ALIAS_BUSY");
            p.guard();p.verifyFrameworkPins();
        }catch(Throwable primary){throw primary;} // outer initialize owns exactly one cleanup attempt
    }
    private void checkDir(File d)throws Exception{
        StructStat st=Os.lstat(d.getPath());if(!OsConstants.S_ISDIR(st.st_mode)||st.st_uid!=uid||st.st_gid!=gid||(st.st_mode&07777)!=0700)
            throw new GeneralSecurityException("OWN_EXISTING_DIRECTORY_MODE");
    }
    private void frameworkPolicy(StructStat st)throws Exception{
        int mode=st.st_mode&07777;
        if(!OsConstants.S_ISDIR(st.st_mode)||st.st_uid!=uid||st.st_gid!=gid||(mode!=0700&&mode!=0771))
            throw new GeneralSecurityException("OWN_FRAMEWORK_DIRECTORY_PROFILE");
    }
    private void pinFramework(File directory,boolean data)throws Exception{
        guard();StructStat st=Os.lstat(directory.getPath());frameworkPolicy(st);
        if((data?dataPin:noBackupPin)!=null)throw new GeneralSecurityException("OWN_FRAMEWORK_PIN_ONCE");
        FrameworkPin pin=new FrameworkPin(directory,st);
        if(data)dataPin=pin;else noBackupPin=pin;
        // Pin registration precedes open; assignment retains the returned FD
        // before fstat/any subsequent allocation can fail.
        pin.fd=Os.open(directory.getPath(),OsConstants.O_RDONLY|OsConstants.O_NOFOLLOW|OsConstants.O_CLOEXEC,0);
        verifyFrameworkPins();
    }
    private void pinDataViews(Context c)throws Exception{
        android.content.pm.ApplicationInfo info=c.getApplicationInfo();
        android.content.pm.ApplicationInfo installed=c.getPackageManager().getApplicationInfo(
            com.ynx.social.matrix.VeilAppIsolation.requireOwnedPackage(c),0);
        if(info==null||installed==null||info.dataDir==null||installed.dataDir==null||
            dataInfoPin!=null||installedDataPin!=null)
            throw new GeneralSecurityException("OWN_CE_DATA_IDENTITY");
        File local=new File(info.dataDir),registered=new File(installed.dataDir);
        if(!local.isAbsolute()||!registered.isAbsolute())
            throw new GeneralSecurityException("OWN_CE_DATA_IDENTITY");
        StructStat localStat=Os.lstat(local.getPath()),registeredStat=Os.lstat(registered.getPath());
        frameworkPolicy(localStat);frameworkPolicy(registeredStat);
        if(localStat.st_dev!=dataPin.dev||localStat.st_ino!=dataPin.ino||
            registeredStat.st_dev!=dataPin.dev||registeredStat.st_ino!=dataPin.ino)
            throw new GeneralSecurityException("OWN_CE_DATA_IDENTITY");
        dataInfoPin=new FrameworkPin(local,localStat);
        dataInfoPin.fd=Os.open(local.getPath(),OsConstants.O_RDONLY|
            OsConstants.O_NOFOLLOW|OsConstants.O_CLOEXEC,0);
        verifyFrameworkPins();
        installedDataPin=new FrameworkPin(registered,registeredStat);
        installedDataPin.fd=Os.open(registered.getPath(),OsConstants.O_RDONLY|
            OsConstants.O_NOFOLLOW|OsConstants.O_CLOEXEC,0);
        verifyFrameworkPins();
    }
    private void verifyFrameworkPin(FrameworkPin pin)throws Exception{
        if(pin==null)return;
        if(pin.fd==null||pin.closeFailure!=null)throw new GeneralSecurityException("OWN_FRAMEWORK_PIN_LIFETIME");
        StructStat current=Os.lstat(pin.directory.getPath()),held=Os.fstat(pin.fd);
        frameworkPolicy(current);frameworkPolicy(held);
        if(!pin.directory.isAbsolute()||
            current.st_dev!=pin.dev||current.st_ino!=pin.ino||held.st_dev!=pin.dev||held.st_ino!=pin.ino)
            throw new GeneralSecurityException("OWN_FRAMEWORK_PATH_REPLACED");
    }
    private void verifyFrameworkPins()throws Exception{
        verifyFrameworkPin(dataPin);verifyFrameworkPin(dataInfoPin);
        verifyFrameworkPin(installedDataPin);verifyFrameworkPin(noBackupPin);
        if(noBackupPin!=null){
            if(dataPin==null)throw new GeneralSecurityException("OWN_CE_NO_BACKUP_IDENTITY");
            StructStat child=Os.lstat(new File(dataPin.directory,"no_backup").getPath());
            frameworkPolicy(child);
            if(child.st_dev!=noBackupPin.dev||child.st_ino!=noBackupPin.ino)
                throw new GeneralSecurityException("OWN_CE_NO_BACKUP_IDENTITY");
        }
    }
    private void guard()throws Exception{
        if(Thread.currentThread()!=owner)throw new GeneralSecurityException("OWN_WRONG_WORKER");
        if(Build.VERSION.SDK_INT<24||context==null||context.getApplicationContext()!=context||context.isDeviceProtectedStorage()||
            Process.myUid()!=uid||Process.myPid()!=pid||
            Os.getuid()!=uid||Os.geteuid()!=uid||Os.getgid()!=gid||Os.getegid()!=gid)
            throw new GeneralSecurityException("OWN_CALLING_PROCESS");
        String packageName=com.ynx.social.matrix.VeilAppIsolation.requireOwnedPackage(context);
        android.content.pm.ApplicationInfo info=context.getApplicationInfo();
        android.content.pm.ApplicationInfo installed=context.getPackageManager().getApplicationInfo(packageName,0);
        if(info==null||installed==null||info.uid!=uid||installed.uid!=uid||
            !packageName.equals(info.packageName)||!packageName.equals(installed.packageName))
            throw new GeneralSecurityException("OWN_INSTALLED_PACKAGE_UID");
        if(dataPin!=null){File actual=context.getDataDir();
            if(actual==null||!actual.isAbsolute())throw new GeneralSecurityException("OWN_CE_DATA_CHANGED");
            StructStat actualStat=Os.lstat(actual.getPath());frameworkPolicy(actualStat);
            if(actualStat.st_dev!=dataPin.dev||actualStat.st_ino!=dataPin.ino)
                throw new GeneralSecurityException("OWN_CE_DATA_CHANGED");
            if(dataInfoPin!=null){
                if(info.dataDir==null||installed.dataDir==null)throw new GeneralSecurityException("OWN_CE_DATA_CHANGED");
                File local=new File(info.dataDir),registered=new File(installed.dataDir);
                if(!local.isAbsolute()||!registered.isAbsolute())throw new GeneralSecurityException("OWN_CE_DATA_CHANGED");
                StructStat localStat=Os.lstat(local.getPath()),registeredStat=Os.lstat(registered.getPath());
                frameworkPolicy(localStat);frameworkPolicy(registeredStat);
                if(localStat.st_dev!=dataPin.dev||localStat.st_ino!=dataPin.ino||
                    registeredStat.st_dev!=dataPin.dev||registeredStat.st_ino!=dataPin.ino)
                    throw new GeneralSecurityException("OWN_CE_DATA_CHANGED");
            }
            verifyFrameworkPins();
        }
        UserManager u=context.getSystemService(UserManager.class);if(u==null||!u.isUserUnlocked())throw new GeneralSecurityException("OWN_USER_LOCKED");
    }
    private void lookup(KeyStore s)throws Exception{
        guard();Key k=s.getKey(alias,null);if(!(k instanceof SecretKey)||!"AES".equals(k.getAlgorithm()))throw new GeneralSecurityException("OWN_KEY_MISSING_NO_REGENERATION");
        SecretKey candidate=(SecretKey)k;KeyInfo i=(KeyInfo)SecretKeyFactory.getInstance("AES","AndroidKeyStore").getKeySpec(candidate,KeyInfo.class);
        if(i.getKeySize()!=256||i.getPurposes()!=(KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)||
            i.getOrigin()!=KeyProperties.ORIGIN_GENERATED||!i.isUserAuthenticationRequired()||
            i.getUserAuthenticationValidityDurationSeconds()<1||i.getUserAuthenticationValidityDurationSeconds()>120||
            !Arrays.equals(i.getBlockModes(),new String[]{KeyProperties.BLOCK_MODE_GCM})||
            !Arrays.equals(i.getEncryptionPaddings(),new String[]{KeyProperties.ENCRYPTION_PADDING_NONE}))throw new GeneralSecurityException("OWN_KEY_PROFILE");
        key=candidate; // Opaque platform key. NEVER getEncoded().
    }
    private int aad(byte[] a,boolean classic)throws Exception{
        byte[] domain=classic?CLASSIC_DOMAIN:DOMAIN;
        if(a==null||a.length>7168)throw new GeneralSecurityException("OWN_AAD_BOUNDS");
        ByteBuffer b=ByteBuffer.wrap(a);if(b.remaining()<domain.length+20)throw new GeneralSecurityException("OWN_AAD_SHAPE");
        for(byte v:domain)if(b.get()!=v)throw new GeneralSecurityException("OWN_AAD_DOMAIN");
        if(b.getInt()!=1||b.getInt()!=(classic?1:87)||b.getLong()<1)throw new GeneralSecurityException("OWN_AAD_PROFILE");
        byte[] name=alias.getBytes(StandardCharsets.US_ASCII);int n=b.getInt();
        if(n!=name.length||b.remaining()<n+33+2592+4)throw new GeneralSecurityException("OWN_AAD_ALIAS");
        for(byte v:name)if(b.get()!=v)throw new GeneralSecurityException("OWN_AAD_ALIAS");
        if(b.get()!=5)throw new GeneralSecurityException("OWN_CLASSIC_PROFILE");b.position(b.position()+32+2592);
        int ownerBytes=b.getInt();if(ownerBytes<1||ownerBytes>4096||b.remaining()!=ownerBytes+(classic?4:0))throw new GeneralSecurityException("OWN_ASSOCIATION_BOUNDS");
        if(!classic)return 4896;b.position(b.position()+ownerBytes);int length=b.getInt();
        if(length<1||length>256)throw new GeneralSecurityException("OWN_CLASSIC_SERIALIZED_BOUNDS");return length;
    }
    private static void buffer(ByteBuffer b,int n,boolean writable)throws Exception{
        if(b==null||!b.isDirect()||b.capacity()!=n||b.position()!=0||b.limit()!=n||(writable&&b.isReadOnly()))throw new GeneralSecurityException("OWN_DIRECT_SPAN");
    }
    private static void wipe(ByteBuffer b){if(b!=null&&!b.isReadOnly())for(int i=0;i<b.capacity();i++)b.put(i,(byte)0);}
    private void ready()throws Exception{guard();if(initPrimary!=null)VeilOwnKeyPlatformProtector.<RuntimeException>rethrow(initPrimary);if(key==null)throw new GeneralSecurityException("OWN_PROTECTOR_CLOSED");}
    private static void provider(Cipher c)throws Exception{if(!c.getProvider().getName().startsWith("AndroidKeyStore"))throw new GeneralSecurityException("OWN_PROVIDER_PROFILE");}
    // JNI supplies direct native spans. No raw private byte[] method exists.
    private int seal(ByteBuffer clear,byte[] a,ByteBuffer nonce,ByteBuffer ciphertext)throws Exception{
        ready();int n=aad(a,false);return encrypt(clear,a,nonce,ciphertext,n);
    }
    private int sealClassic(ByteBuffer clear,byte[] a,ByteBuffer nonce,ByteBuffer ciphertext)throws Exception{
        ready();int n=aad(a,true);return encrypt(clear,a,nonce,ciphertext,n);
    }
    private int encrypt(ByteBuffer clear,byte[] a,ByteBuffer nonce,ByteBuffer ciphertext,int size)throws Exception{
        buffer(clear,size,false);buffer(nonce,12,true);buffer(ciphertext,size+16,true);
        byte[] copy=a.clone();boolean success=false;
        try {Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key);provider(c);
            byte[] iv=c.getIV();if(iv==null||iv.length!=12)throw new GeneralSecurityException("OWN_PROVIDER_NONCE");
            c.updateAAD(copy);int n=c.doFinal(clear.asReadOnlyBuffer(),ciphertext.duplicate());
            if(n!=size+16)throw new GeneralSecurityException("OWN_PROVIDER_TAG");nonce.duplicate().put(iv);success=true;return n;
        }finally{Arrays.fill(copy,(byte)0);if(!success){wipe(nonce);wipe(ciphertext);}}
    }
    private int unseal(ByteBuffer ciphertext,byte[] a,byte[] nonce,ByteBuffer clear)throws Exception{
        ready();int n=aad(a,false);return decrypt(ciphertext,a,nonce,clear,n);
    }
    private int unsealClassic(ByteBuffer ciphertext,byte[] a,byte[] nonce,ByteBuffer clear)throws Exception{
        ready();int n=aad(a,true);return decrypt(ciphertext,a,nonce,clear,n);
    }
    private int decrypt(ByteBuffer ciphertext,byte[] a,byte[] nonce,ByteBuffer clear,int size)throws Exception{
        buffer(ciphertext,size+16,false);buffer(clear,size,true);if(nonce==null||nonce.length!=12)throw new GeneralSecurityException("OWN_NONCE_BOUNDS");
        byte[] copy=a.clone();boolean success=false;
        try {Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,nonce));provider(c);c.updateAAD(copy);
            int n=c.doFinal(ciphertext.asReadOnlyBuffer(),clear.duplicate());if(n!=size)throw new GeneralSecurityException("OWN_AUTHENTICATED_LENGTH");success=true;return n;
        }catch(AEADBadTagException invalid){return -2; /* Known authentication refusal; no partial plaintext returned. */}
        finally {Arrays.fill(copy,(byte)0);if(!success)wipe(clear);}
    }
    private void cleanup(Throwable primary){key=null;boolean failed=false;
        try{if(lock!=null)lock.release();lock=null;}catch(Throwable x){failed=true;if(x!=primary)try{primary.addSuppressed(x);}catch(Throwable ignored){}}
        try{if(channel!=null)channel.close();channel=null;}catch(Throwable x){failed=true;if(x!=primary)try{primary.addSuppressed(x);}catch(Throwable ignored){}}
        try{if(stream!=null)stream.close();stream=null;}catch(Throwable x){failed=true;if(x!=primary)try{primary.addSuppressed(x);}catch(Throwable ignored){}}
        Throwable extra=closeFrameworkPins(closeAliasFd(null));
        if(extra!=null){failed=true;if(extra!=primary)try{primary.addSuppressed(extra);}catch(Throwable ignored){}}
        if(failed)closePrimary=primary; // retain fields + exact fatal primary, no automatic cleanup retry
    }
    private Throwable closeFrameworkPin(FrameworkPin pin,Throwable first){
        if(pin==null||pin.fd==null)return first;
        Throwable failure=pin.closeFailure;
        if(failure==null)try{Os.close(pin.fd);pin.fd=null;return first;}catch(Throwable t){pin.closeFailure=t;failure=t;}
        if(first==null)return failure;
        if(first!=failure)try{first.addSuppressed(failure);}catch(Throwable ignored){}
        return first; // Uncertain close never retries that descriptor.
    }
    private Throwable closeAliasFd(Throwable first){
        if(aliasFd==null)return first;
        Throwable failure=aliasCloseFailure;
        if(failure==null)try{Os.close(aliasFd);aliasFd=null;return first;}
        catch(Throwable t){aliasCloseFailure=t;failure=t;}
        if(first==null)return failure;
        if(first!=failure)try{first.addSuppressed(failure);}catch(Throwable ignored){}
        return first; // Retain uncertain FD and exact cause; never blindly retry.
    }
    private Throwable closeFrameworkPins(Throwable first){
        first=closeFrameworkPin(noBackupPin,first);
        first=closeFrameworkPin(installedDataPin,first);
        first=closeFrameworkPin(dataInfoPin,first);return closeFrameworkPin(dataPin,first);
    }
    @SuppressWarnings("unchecked") private static <T extends Throwable> void rethrow(Throwable t)throws T {throw (T)t;}
    @Override public void close()throws Exception{
        if(Thread.currentThread()!=owner)throw new GeneralSecurityException("OWN_WRONG_WORKER");
        if(closePrimary!=null)VeilOwnKeyPlatformProtector.<RuntimeException>rethrow(closePrimary);
        key=null;Throwable first=null;try{if(lock!=null)lock.release();lock=null;}catch(Throwable t){first=t;}
        try{if(channel!=null)channel.close();channel=null;}catch(Throwable t){if(first==null)first=t;else if(first!=t)try{first.addSuppressed(t);}catch(Throwable ignored){}}
        try{if(stream!=null)stream.close();stream=null;}catch(Throwable t){if(first==null)first=t;else if(first!=t)try{first.addSuppressed(t);}catch(Throwable ignored){}}
        first=closeFrameworkPins(closeAliasFd(first));
        if(first!=null){closePrimary=first;VeilOwnKeyPlatformProtector.<RuntimeException>rethrow(first);}
    }
}
