package com.ynx.social.matrix;

import java.security.GeneralSecurityException;
import java.util.Arrays;

/* PRIVATE normal pre-device storage intent, never a SourceWitness/device grant.
 * The original normal producer supplies its retained local intent association;
 * this class freezes those exact PUBLIC bytes, not a new signed/authority tuple.
 * No secret, mode switch, subject claim, accepted flag or public getter exists.
 */
final class VeilLocalGenesisInput {
    private final Thread owner;
    private final String alias;
    private final long storageGeneration;
    private final byte[] originalAssociation;
    private final int authWindowSeconds;
    private VeilOwnKeyPrivateCommand submittingCommand;
    private boolean released;

    VeilLocalGenesisInput(String originalAlias, long originalGeneration,
            byte[] originalAssociationBytes, int authenticatedWindowSeconds)
            throws GeneralSecurityException {
        if (originalAlias == null || !originalAlias.matches("ynx\\.social\\.ownkey\\.v1\\.[0-9a-f]{32}"))
            throw new GeneralSecurityException("LOCAL_GENESIS_ALIAS");
        if (originalGeneration < 1)
            throw new GeneralSecurityException("LOCAL_GENESIS_STORAGE_GENERATION");
        if (originalAssociationBytes == null || originalAssociationBytes.length < 1 ||
                originalAssociationBytes.length > 4096)
            throw new GeneralSecurityException("LOCAL_GENESIS_ASSOCIATION_BOUNDS");
        if (authenticatedWindowSeconds < 1 || authenticatedWindowSeconds > 120)
            throw new GeneralSecurityException("LOCAL_GENESIS_AUTH_WINDOW");
        owner = Thread.currentThread();
        alias = originalAlias;
        storageGeneration = originalGeneration;
        authWindowSeconds = authenticatedWindowSeconds;
        // Last potentially failing construction step; no later allocation/hook.
        originalAssociation = originalAssociationBytes.clone();
    }

    private void requireOwner() throws GeneralSecurityException {
        if (Thread.currentThread() != owner)
            throw new GeneralSecurityException("LOCAL_GENESIS_WRONG_WORKER");
        if (released)
            throw new GeneralSecurityException("LOCAL_GENESIS_INPUT_RELEASED");
    }

    // Existing-only reconciliation may compare the original PUBLIC metadata
    // after genesis failed, without reopening genesis admission or its effects.
    void requireRecoveryExpectations(VeilOwnKeyPrivateCommand command, String candidateAlias,
            long candidateGeneration, byte[] candidateAssociation) throws GeneralSecurityException {
        requireOwner();
        if (submittingCommand != command || command == null || !alias.equals(candidateAlias)
                || storageGeneration != candidateGeneration || !Arrays.equals(originalAssociation, candidateAssociation))
            throw new GeneralSecurityException("LOCAL_RECOVERY_GENESIS_MISMATCH");
    }

    // Normal command claims once before JNI. This is lifecycle, NOT authority.
    void claimForSubmission(VeilOwnKeyPrivateCommand command) throws GeneralSecurityException {
        requireOwner();
        if (command == null || submittingCommand != null)
            throw new GeneralSecurityException("LOCAL_GENESIS_INPUT_ALREADY_SUBMITTED");
        submittingCommand = command;
    }

    // Actual JNI consumer calls this private method before reading fields/copy.
    private void requireSubmitted() throws GeneralSecurityException {
        requireOwner();
        if (submittingCommand == null)
            throw new GeneralSecurityException("LOCAL_GENESIS_INPUT_NOT_SUBMITTED");
        submittingCommand.requireNativeAdmission(this);
    }

    String aliasForSubmittedCommand(VeilOwnKeyPrivateCommand command) throws GeneralSecurityException {
        requireSubmitted();
        if (submittingCommand != command)
            throw new GeneralSecurityException("LOCAL_GENESIS_FOREIGN_COMMAND");
        return alias;
    }

    long generationForSubmittedCommand(VeilOwnKeyPrivateCommand command) throws GeneralSecurityException {
        requireSubmitted();
        if (submittingCommand != command)
            throw new GeneralSecurityException("LOCAL_GENESIS_FOREIGN_COMMAND");
        return storageGeneration;
    }

    // Cancellation BEFORE JNI only. Submitted input stays held with original
    // command/native owner, including failure/UNKNOWN; no blanket dispose API.
    void cancelBeforeSubmission() throws GeneralSecurityException {
        requireOwner();
        if (submittingCommand != null)
            throw new GeneralSecurityException("LOCAL_GENESIS_SUBMITTED_INPUT_RETAINED");
        Arrays.fill(originalAssociation, (byte)0);
        released = true;
    }
}
