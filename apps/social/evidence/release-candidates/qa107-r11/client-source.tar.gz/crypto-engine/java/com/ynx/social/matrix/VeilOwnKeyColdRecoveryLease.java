package com.ynx.social.matrix;

import android.content.Context;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import kotlin.Unit;

/** Private journal-owning cold receiver. Public bookkeeping is not authority.
 * No UI factory, old command/TLS reconstruction, fresh reservation or key work. */
final class VeilOwnKeyColdRecoveryLease {
    private final Thread worker = Thread.currentThread();
    private final Context context;
    private final VeilDeviceEnrollmentPendingStore.ColdBorrow borrow;
    private String alias;
    private long generation;
    private byte[] association;
    private byte[] ids;
    private boolean captureAttempted, captured, active, checking, beginAttempted;
    private boolean pathAttempted, pathActive, releaseAttempted, released, retired;
    private Throwable primary, releaseFailure;
    private int firstNativeFailure, lastStatus;
    private boolean nativeFailureRetained;
    private VeilOwnKeyLocalStoreContext.Outcome prepared, pathOutcome, closeOutcome;

    VeilOwnKeyColdRecoveryLease(Context actualContext, VeilDeviceEnrollmentPendingStore.ColdBorrow actualBorrow) {
        if (actualContext == null || actualBorrow == null) throw new NullPointerException();
        context = actualContext; borrow = actualBorrow;
    }
    private void worker() { if (Thread.currentThread() != worker) throw new IllegalStateException("COLD_WRONG_WORKER"); }
    private void retain(Throwable t) {
        if (primary == null) primary = t;
        else if (primary != t) try { primary.addSuppressed(t); } catch (Throwable ignored) { }
    }
    private RuntimeException propagate(Throwable t) { return VeilOwnKeyColdRecoveryLease.<RuntimeException, RuntimeException>raise(t); }
    @SuppressWarnings("unchecked") private static <T extends Throwable,R> R raise(Throwable t) throws T { throw (T)t; }
    void initializeOriginal() {
        worker(); if (captureAttempted) throw new IllegalStateException("COLD_CAPTURE_ONCE");
        captureAttempted = true;
        try {
            VeilAppIsolation.requireOwnedPackage(context);
            borrow.withRecord(record -> {
                alias = record.getAlias(); generation = record.getStorageGeneration();
                association = record.association(); ids = record.getNativeIds().copyBytes();
                return Unit.INSTANCE;
            });
            VeilLocalRecoveryInput.validatePublicShape(alias, generation, association, ids);
            VeilAppIsolation.requireOwnedPackage(context); borrow.revalidate(); captured = true;
        } catch (Throwable t) { retain(t); throw propagate(t); }
    }
    boolean isRetired() { worker(); return retired; }
    Throwable retainedPrimary() { worker(); return primary; }
    int retainedFirstNativeFailure() { worker(); return firstNativeFailure; }
    private void checkForNative() throws Throwable {
        worker();
        if (!active || !captured || released || checking) throw new GeneralSecurityException("COLD_LEASE_NOT_ACTIVE");
        checking = true;
        try { VeilAppIsolation.requireOwnedPackage(context); borrow.revalidate(); }
        finally { checking = false; }
        // A retained first cause is not permission, but must not block cleanup.
    }
    private Context contextForNative() throws Throwable { checkForNative(); return context; }
    private String aliasForNative() throws Throwable { checkForNative(); return alias; }
    private long generationForNative() throws Throwable { checkForNative(); return generation; }
    private byte[] associationForNative() throws Throwable { return publicCopy(association); }
    private byte[] originalIdsForNative() throws Throwable { return publicCopy(ids); }
    private byte[] publicCopy(byte[] original) throws Throwable {
        checkForNative(); byte[] copy = original.clone();
        try { checkForNative(); return copy; } catch (Throwable t) { Arrays.fill(copy, (byte)0); throw t; }
    }
    private VeilOwnKeyLocalStoreContext.Profile profile() throws Exception {
        String name = VeilAppIsolation.requireOwnedPackage(context);
        return "com.ynx.social".equals(name) ? VeilOwnKeyLocalStoreContext.Profile.SOCIAL_V1
            : "com.ynx.social.m1qa".equals(name) ? VeilOwnKeyLocalStoreContext.Profile.M1_QA_V1
            : VeilOwnKeyLocalStoreContext.Profile.PUBLIC_VEIL_QA_V1;
    }
    private void requireReady(VeilOwnKeyLocalStoreContext.Outcome outcome) throws Throwable {
        if (outcome.status() != VeilOwnKeyLocalStoreContext.Status.UNVERIFIED_LOCAL_READY) {
            Throwable failure = outcome.primary();
            if (failure == null) failure = new GeneralSecurityException("COLD_PLATFORM_UNRESOLVED");
            retain(failure); if (outcome.secondary() != null) retain(outcome.secondary()); throw primary;
        }
    }
    /** Native may invoke this only in its same-global, one-shot OPEN_WINDOW. */
    private int openExistingForNative() throws Throwable {
        checkForNative();
        if (pathAttempted || primary != null) throw new GeneralSecurityException("COLD_PATH_ONCE");
        pathAttempted = true;
        try {
            final VeilOwnKeyLocalStoreContext.Profile selected = profile();
            borrow.retainPlatformOutcome(() -> {
                prepared = VeilOwnKeyLocalStoreContext.prepareExisting(context, selected, alias, generation, this::checkForNative);
                return prepared;
            });
            requireReady(prepared); checkForNative();
            borrow.retainPlatformOutcome(() -> {
                pathOutcome = prepared.owner().withExistingDatabasePath(path -> {
                    checkForNative(); if (pathActive) throw new GeneralSecurityException("COLD_PATH_REENTRY");
                    pathActive = true;
                    try {
                        int value = VeilOwnKeyPrivateCommand.nativeOpenColdDatabase(this, path);
                        if (value != 180) {
                            if (!nativeFailureRetained) { firstNativeFailure = value; nativeFailureRetained = true; }
                            throw new GeneralSecurityException("COLD_NATIVE_EXISTING_OPEN_REFUSED");
                        }
                        checkForNative();
                    } finally { pathActive = false; }
                });
                return pathOutcome;
            });
            requireReady(pathOutcome); checkForNative(); return 180;
        } catch (Throwable t) { retain(t); throw primary; }
    }
    /** Only actual native releasable C-custody invokes this callback. Never a
     * public release flag. Failed close is cached; no blind OS-close retry. */
    private void releaseForNative() throws Throwable {
        checkForNative();
        if (releaseAttempted) {
            if (releaseFailure != null) throw releaseFailure;
            throw new GeneralSecurityException("COLD_RELEASE_ALREADY_ATTEMPTED");
        }
        releaseAttempted = true;
        try {
            closeOutcome = borrow.closeRetainedPlatformOwner();
            borrow.finishNativeCleanup();
            released = true;
            Arrays.fill(association, (byte)0); Arrays.fill(ids, (byte)0);
            // No active-lease postcheck after actual retirement.
        } catch (Throwable t) { retain(t); releaseFailure = primary; throw releaseFailure; }
    }
    int begin() { return dispatch(0); }
    int observe() { return dispatch(1); }
    int reconcile() { return dispatch(2); }
    int discharge() { return dispatch(3); }
    int cleanup() { return dispatch(4); }
    int release() { return dispatch(5); }
    private int dispatch(int operation) {
        worker();
        if (retired && operation == 5) return 184; // original Java receipt, no JNI/effect
        if (active || released || !captured) throw new IllegalStateException("COLD_DISPATCH_LIFETIME");
        if (operation == 0 && beginAttempted) throw new IllegalStateException("COLD_BEGIN_ONCE");
        if (operation != 0 && !beginAttempted) throw new IllegalStateException("COLD_BEGIN_REQUIRED");
        if ((operation == 0 || operation == 2 || operation == 3) && (primary != null || nativeFailureRetained))
            throw propagate(primary != null ? primary : new IllegalStateException("COLD_FIRST_NATIVE_FAILURE_RETAINED"));
        if (operation == 5 && releaseFailure != null) throw propagate(releaseFailure);
        try {
            if (VeilOwnKeyPrivateCommand.nativeColdRecoveryAbiVersion() != 1)
                throw new GeneralSecurityException("COLD_ABI_REQUIRED");
            active = true;
            return borrow.withCleanup(() -> {
                try {
                    checkForNative();
                    if (operation == 0) { beginAttempted = true; borrow.markNativeAttempted(); }
                    int status;
                    switch (operation) {
                        case 0: status = VeilOwnKeyPrivateCommand.nativeBeginColdRecovery(context, this); break;
                        case 1: status = VeilOwnKeyPrivateCommand.nativeObserveColdRecovery(context, this); break;
                        case 2: status = VeilOwnKeyPrivateCommand.nativeReconcileColdRecovery(context, this); break;
                        case 3: status = VeilOwnKeyPrivateCommand.nativeDischargeColdRecovery(context, this); break;
                        case 4: status = VeilOwnKeyPrivateCommand.nativeCleanupColdRecovery(context, this); break;
                        case 5: status = VeilOwnKeyPrivateCommand.nativeReleaseColdRecovery(context, this); break;
                        default: throw new AssertionError();
                    }
                    lastStatus = status;
                    if (status < 180 || status > 184) { if (!nativeFailureRetained) { firstNativeFailure = status; nativeFailureRetained = true; } }
                    if (operation == 5 && status == 184 && released) retired = true;
                    else if (!released) checkForNative();
                    else throw new GeneralSecurityException("COLD_RETIREMENT_UNCONFIRMED");
                    return status;
                } catch (Throwable t) { retain(t); throw propagate(t); }
            });
        } catch (Throwable t) { retain(t); throw propagate(t); }
        finally { active = false; }
    }
}
