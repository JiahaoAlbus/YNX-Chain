package com.ynx.social.matrix

/** Normal-worker business orchestration. Neither Binding nor an observed view
 * grants Native authority. Native device/session checks and per-operation
 * admission remain mandatory. No default/JS/runtime-created supplier exists.
 *
 * VeilMatrixProductBinding below owns product state and courier integration.
 * Only its actual Native source remains an upstream owning producer, not
 * supplied by the seven private execution actions or PUBLIC test controls.
 */
internal class VeilNativeMessageBusiness private constructor(
    private val native: NativePort,
    private val binding: Binding
) : VeilSocialMessagingCoordinator.Business {
    internal enum class Completion { PENDING, COMMITTED, ABORTED, UNKNOWN }
    internal interface Original {
        val reference: String
        fun checkCurrent()
        /** Same original normal command/context, checked by its producer. */
        fun requireRequest(command: Map<String, Any?>, context: Map<String, Any?>)
        /** Verified original commit/readback, never merely HTTP success. */
        fun completion(): Completion
        /** Retire only this original. Failure leaves its custody intact. */
        fun close()
    }
    internal interface Message : Original {
        /** Owned copies of existing Native wire inputs, not new wire schemas. */
        fun sessionRecords(): ByteArray
        fun frame(): ByteArray
        /** Same original protected outbox/inbox and transport. Must retain its
         * attempted state before I/O and never re-encrypt on an uncertain reply. */
        fun consumeOriginalOutput(output: VeilNativeMessageOutput)
    }
    internal interface Contact : Original {
        /** Uses the genuine ongoing request-bound actor, not an init cookie. */
        fun executeOriginal()
    }
    internal interface Binding {
        fun validate(command: Map<String, Any?>): String? = null
        fun nextIncoming(capture: (Message) -> Unit) {}
        fun checkCurrent()
        /** Authorized projection from the original protected product store.
         * It must not synthesize authorization from inventory or HTTP status. */
        fun projection(): Map<String, Any?>
        fun openConversation(command: Map<String, Any?>): Map<String, Any?>
        /** Capture transfers ownership only when it returns normally. Publish
         * before effects. An exception/partial acquisition stays at this owner. */
        fun prepare(command: Map<String, Any?>, context: Map<String, Any?>,
                    capture: (Original) -> Unit)
        fun hasRetainedWork(): Boolean
    }
    internal interface NativeOperation
    internal interface NativePort {
        fun deviceCurrent()
        fun openSession(records: ByteArray)
        fun epoch(): Long
        fun acquire(epoch: Long, frame: ByteArray): NativeOperation
        fun execute(original: NativeOperation, epoch: Long, frame: ByteArray): Long
        fun advance(original: NativeOperation, epoch: Long): Long
        fun output(original: NativeOperation, epoch: Long, consume: (VeilNativeMessageOutput) -> Unit)
        fun retire(original: NativeOperation, epoch: Long)
        fun hasRetainedWork(): Boolean
    }
    private enum class Phase { CAPTURED, NATIVE_HELD, OUTPUT, COMMIT, RETIRED, CLOSED }
    private class Pending(val original: Original, val incoming: Boolean) {
        var phase = Phase.CAPTURED
        var native: NativeOperation? = null
        var epoch = 0L
        var frame: ByteArray? = null
        var unknown = false
        var closeAttempted = false
    }
    private val worker = Thread.currentThread()
    private var pending: Pending? = null
    private var preparing = false
    private var firstFailure: Throwable? = null
    private var lastView: Map<String, Any?>? = null

    private fun checked() = check(Thread.currentThread() === worker) { "VEIL_PRODUCT_WRONG_WORKER" }
    private fun current() {
        checked()
        binding.checkCurrent()
        native.deviceCurrent()
    }
    private fun view(): Map<String, Any?> {
        current()
        val value = binding.projection()
        require(value["kind"] == "AUTHORIZED")
        for (key in listOf("accountViewRef", "viewRevision")) reference(value[key])
        current()
        return value.also { lastView = it }
    }
    private fun fail(failure: Throwable) {
        if (firstFailure == null) firstFailure = failure
        else if (firstFailure !== failure) firstFailure!!.addSuppressed(failure)
        pending?.unknown = true
    }
    private fun error(code: String) = mapOf<String, Any?>("kind" to "error", "code" to code)
    private fun waiting(p: Pending) = mapOf<String, Any?>(
        "kind" to "pending", "disposition" to if (p.unknown) "unknown" else "queued",
        "originalOperationRef" to p.original.reference)
    private fun recovery(): Map<String, Any?> {
        val p = pending
        val previous = lastView
        if (p == null || previous == null) return mapOf(
            "kind" to "UNAVAILABLE", "gaps" to listOf("RESTORE_PRODUCT_BINDING_UNAVAILABLE"))
        return mapOf("kind" to "RECOVERY_REQUIRED",
            "accountViewRef" to previous.getValue("accountViewRef"),
            "viewRevision" to previous.getValue("viewRevision"),
            "items" to listOf(mapOf("originalOperationRef" to p.original.reference,
                "label" to "Check the original operation", "state" to "unknown")))
    }

    /** Cached delivery is still subject to the real source/device authority.
     * Unlike read(), this cannot poll, prepare, advance, consume or resend work.
     * An existing UNKNOWN operation and its first failure remain untouched. */
    override fun requireDeliveryCurrent() { current() }

    override fun read(context: Map<String, Any?>): Map<String, Any?> {
        checked()
        if (firstFailure != null || pending?.unknown == true) return recovery()
        return try {
            if (pending == null) {
                view()
                binding.nextIncoming { original ->
                    check(pending == null) { "VEIL_PRODUCT_ORIGINAL_ALREADY_CAPTURED" }
                    reference(original.reference)
                    pending = Pending(original, true)
                }
            }
            pending?.let { progress(it) } // One step, never a loop or new intent.
            if (pending?.unknown == true) recovery() else view().also {
                if (pending?.phase == Phase.CLOSED) pending = null
            }
        } catch (failure: Throwable) {
            if (pending == null && failure is VeilMatrixProductBinding.HistoryCapacity)
                mapOf("kind" to "UNAVAILABLE", "gaps" to listOf("SOCIAL_STORAGE_CAPACITY"))
            else { fail(failure); recovery() }
        }
    }
    /** Read-only startup projection. Unlike a normal inbox read this neither
     * polls Matrix nor prepares/decrypts a message during login publication. */
    internal fun requireStartupProjection() {
        checked()
        firstFailure?.let { throw it }
        check(pending == null && !preparing) { "VEIL_PRODUCT_ORIGINAL_RETAINED" }
        view() // Actual Native device + owning source + private store, not inventory.
    }

    override fun execute(command: Map<String, Any?>, context: Map<String, Any?>): Map<String, Any?> {
        checked()
        if (command["type"] == "reviewRecovery") return review(command, context)
        if (firstFailure != null || pending != null || preparing) return error("REVIEW_REQUIRED")
        val type = command["type"] as? String ?: return error("INPUT_INVALID")
        if (type !in setOf("openConversation", "sendMessage", "requestContact", "acceptContact"))
            return error("UNAVAILABLE")
        try {
            val before = view()
            if (before["accountViewRef"] != context["accountViewRef"] ||
                before["viewRevision"] != context["viewRevision"] ||
                command["viewRevision"] != context["viewRevision"]) return error("STALE_VIEW")
            if ((before["actions"] as? List<*>)?.contains(type) != true) return error("LOCKED")
            if (type == "openConversation") {
                current()
                val opened = binding.openConversation(command)
                require(opened["kind"] == "AUTHORIZED" &&
                    opened["accountViewRef"] == before["accountViewRef"] &&
                    opened["activeConversationId"] == command["conversationId"])
                current()
                lastView = opened
                return mapOf("kind" to "snapshot", "snapshot" to opened,
                    "completion" to "read", "originalOperationRef" to null)
            }
            binding.validate(command)?.let { return error(it) }
            preparing = true
            binding.prepare(command, context) { original ->
                check(pending == null) { "VEIL_PRODUCT_ORIGINAL_ALREADY_CAPTURED" }
                reference(original.reference)
                require(if (type == "sendMessage") original is Message else original is Contact)
                pending = Pending(original, false)
            }
            val selected = checkNotNull(pending) { "VEIL_PRODUCT_ORIGINAL_NOT_CAPTURED" }
            preparing = false
            selected.original.requireRequest(command, context)
            current()
            progress(selected)
            if (selected.phase != Phase.CLOSED) return waiting(selected)
            val after = view()
            check(after["accountViewRef"] == before["accountViewRef"])
            if (type == "sendMessage") check(after["activeConversationId"] == command["conversationId"])
            pending = null
            return mapOf("kind" to "snapshot", "snapshot" to after,
                "completion" to "confirmed", "originalOperationRef" to selected.original.reference)
        } catch (failure: Throwable) {
            // The producer still owns a partial acquire which could not be
            // captured. Never replace it or infer no effect from no local token.
            fail(failure)
            return pending?.let { waiting(it) } ?: error("OUTCOME_UNKNOWN")
        }
    }

    /** Existing sync worker hands over an owned, authenticated original.
     * No selector, cipher kind or public transport event can construct one. */
    fun receive(original: Message) {
        checked()
        check(pending == null && !preparing && firstFailure == null)
        reference(original.reference)
        val selected = Pending(original, true)
        pending = selected
        try { current(); progress(selected) }
        catch (failure: Throwable) { fail(failure); throw failure }
    }

    private fun progress(p: Pending) {
        check(pending === p)
        if (p.unknown || firstFailure != null || p.closeAttempted) return
        current()
        p.original.checkCurrent()
        when (p.phase) {
            Phase.CAPTURED -> {
                if (p.original is Contact) {
                    p.phase = Phase.COMMIT // Before the actual request.
                    p.original.executeOriginal()
                } else {
                    val message = p.original as Message
                    val records = message.sessionRecords()
                    try { native.openSession(records) } finally { records.fill(0) }
                    val frame = message.frame()
                    p.frame = frame
                    VeilNativeProductPorts.validateFrame(frame, if (p.incoming) 2 else 1)
                    p.epoch = native.epoch()
                    p.native = native.acquire(p.epoch, frame)
                    // Stage before entering native, so a thrown return can never
                    // cause the original prepare/encrypt to run a second time.
                    p.phase = Phase.NATIVE_HELD
                    val status = native.execute(checkNotNull(p.native), p.epoch, frame)
                    require(status == 0L || status == 30L)
                    if (status == 30L) return
                    p.phase = Phase.OUTPUT
                }
            }
            Phase.NATIVE_HELD -> {
                val status = native.advance(checkNotNull(p.native), p.epoch)
                require(status == 0L || status == 30L)
                if (status == 30L) return
                p.phase = Phase.OUTPUT
            }
            else -> Unit
        }
        if (p.phase == Phase.OUTPUT) {
            p.phase = Phase.COMMIT // Never retransmit if the consumer throws.
            native.output(checkNotNull(p.native), p.epoch) { output ->
                p.original.checkCurrent()
                (p.original as Message).consumeOriginalOutput(output)
            }
        }
        if (p.phase == Phase.COMMIT) {
            current()
            p.original.checkCurrent()
            when (p.original.completion()) {
                Completion.PENDING -> return
                Completion.UNKNOWN, Completion.ABORTED -> { p.unknown = true; return }
                Completion.COMMITTED -> finish(p)
            }
        }
    }

    private fun finish(p: Pending) {
        // Verified durable commit is distinct from sending and peer delivery.
        current()
        p.original.checkCurrent()
        if (p.phase != Phase.RETIRED) {
            p.native?.let { native.retire(it, p.epoch) }
            p.phase = Phase.RETIRED
        }
        check(!p.closeAttempted)
        p.closeAttempted = true
        p.original.close()
        p.phase = Phase.CLOSED
        p.frame?.fill(0); p.frame = null
        // Retain the completed original until its authorized view is published.
    }

    private fun review(command: Map<String, Any?>, context: Map<String, Any?>): Map<String, Any?> {
        val p = pending ?: return error("REVIEW_REQUIRED")
        if (command["originalOperationRef"] != p.original.reference ||
            lastView?.get("accountViewRef") != context["accountViewRef"]) return error("STALE_VIEW")
        // Query the same retained owner only. No prepare, execute, transmit,
        // retirement or cleanup retry happens as a side effect of this read.
        return try {
            current()
            p.original.checkCurrent()
            val state = p.original.completion()
            current()
            mapOf("kind" to "originalReview", "originalOperationRef" to p.original.reference,
                "resolution" to if (p.closeAttempted) "unresolved" else when (state) {
                    Completion.COMMITTED -> "confirmed"
                    Completion.ABORTED -> "aborted"
                    else -> "unresolved"
                },
                "nextStep" to if (p.closeAttempted || state == Completion.PENDING ||
                    state == Completion.UNKNOWN) "review-only" else if (state == Completion.COMMITTED) "none" else "new-draft")
        } catch (failure: Throwable) {
            fail(failure)
            mapOf("kind" to "originalReview", "originalOperationRef" to p.original.reference,
                "resolution" to "unresolved", "nextStep" to "review-only")
        }
    }
    override fun hasRetainedWork(): Boolean {
        checked()
        if (pending != null || preparing || firstFailure != null) return true
        return try { native.hasRetainedWork() || binding.hasRetainedWork() }
        catch (failure: Throwable) { fail(failure); true }
    }
    fun uses(original: Binding) = binding === original
    internal fun retainedFailure(): Throwable? { checked(); return firstFailure }

    private class Ports(private val ports: VeilNativeProductPorts) : NativePort {
        private class Owned(val source: Ports, val original: VeilNativeProductPorts.Operation) : NativeOperation
        private fun selected(op: NativeOperation): VeilNativeProductPorts.Operation {
            check(op is Owned && op.source === this)
            return op.original
        }
        override fun deviceCurrent() = ports.requireAcceptedDeviceCurrent()
        override fun openSession(records: ByteArray) = ports.openMessageSession(records)
        override fun epoch() = ports.currentMessageEpoch()
        override fun acquire(epoch: Long, frame: ByteArray): NativeOperation = Owned(this, ports.acquire(epoch, frame))
        override fun execute(original: NativeOperation, epoch: Long, frame: ByteArray): Long =
            if (frame[5].toInt() == 2) ports.receive(selected(original), epoch, frame)
            else ports.execute(selected(original), epoch, 2, frame)
        override fun advance(original: NativeOperation, epoch: Long) =
            ports.execute(selected(original), epoch, 3, byteArrayOf())
        override fun output(original: NativeOperation, epoch: Long, consume: (VeilNativeMessageOutput) -> Unit) =
            ports.withOriginalOutput(selected(original), epoch, consume)
        override fun retire(original: NativeOperation, epoch: Long) = ports.retireOriginalOutput(selected(original), epoch)
        override fun hasRetainedWork() = ports.hasRetainedMessages()
    }
    companion object {
        fun owned(ports: VeilNativeProductPorts, binding: Binding): VeilNativeMessageBusiness {
            ports.requireAcceptedDeviceCurrent()
            binding.checkCurrent()
            ports.requireAcceptedDeviceCurrent()
            return VeilNativeMessageBusiness(Ports(ports), binding)
        }
        /** Internal dependency seam for PUBLIC unit controls, not an Expo/SDK
         * provider installer. Production uses owned() with actual product ports. */
        internal fun control(native: NativePort, binding: Binding) = VeilNativeMessageBusiness(native, binding)
        private fun reference(value: Any?) {
            require(value is String && value.length in 1..256 &&
                value.none { it.code < 32 || it.code == 127 })
        }
    }
}


/** Concrete normal-product consumer. NativeSource supplies only ORIGINAL
 * authenticated device/relation/session custody. Projection, local journal,
 * ciphertext HTTP and normal command dispatch are owned here, not by A or JS.
 * No implementation of NativeSource is fabricated when admission is absent. */
internal class VeilMatrixProductBinding private constructor(
    private val source: NativeSource,
    private val store: Store,
    private val courier: VeilMatrixCiphertextHttpTransport,
    private val storageIdentity: Any = store
) : VeilNativeMessageBusiness.Binding {
    internal data class Identity(val accountViewRef: String, val displayName: String, val publicIdentifier: String)
    internal data class Route(val id: String, val title: String, val peerIdentifier: String,
                              val roomId: String, val localSender: String, val remoteSender: String)
    internal data class Invitation(val id: String, val displayName: String)
    internal interface MessageAuthority : VeilNativeMessageBusiness.Original {
        fun sessionRecords(): ByteArray
        /** Actual ratchet + original output durable commit, not an HTTP result,
         * stored Boolean, output presence or an inventory observation. */
        fun requireCommittedOutput(output: VeilNativeMessageOutput)
    }
    internal interface NativeSource {
        fun checkCurrent()
        fun identity(): Identity
        /** Current bilateral, non-revoked relations with their original routes.
         * DTO fields alone cannot implement this owning source. */
        fun routes(): List<Route>
        fun invitations(): List<Invitation>
        fun prepareMessage(command: Map<String, Any?>, context: Map<String, Any?>,
                           logicalId: String, originalFrame: ByteArray,
                           capture: (MessageAuthority) -> Unit)
        fun prepareIncoming(route: Route, eventId: String, logicalId: String,
                            originalFrame: ByteArray, capture: (MessageAuthority) -> Unit)
        fun prepareContact(command: Map<String, Any?>, context: Map<String, Any?>,
                           capture: (VeilNativeMessageBusiness.Contact) -> Unit)
        fun hasRetainedWork(): Boolean
    }
    internal interface Records {
        fun state(): org.json.JSONObject?
        fun state(value: org.json.JSONObject)
        fun operation(id: String): org.json.JSONObject?
        fun operation(id: String, value: org.json.JSONObject)
        fun operations(): List<String>
        fun history(id: String): org.json.JSONObject?
        fun history(id: String, value: org.json.JSONObject)
        fun removeHistory(id: String)
    }
    internal interface Store {
        /** Protected transaction completes before returning; no network inside. */
        fun <T> transaction(block: (Records) -> T): T
    }
    private val worker = Thread.currentThread()
    private var retained: VeilNativeMessageBusiness.Original? = null
    private var failure: Throwable? = null
    private fun current() {
        check(Thread.currentThread() === worker) { "VEIL_PRODUCT_WRONG_WORKER" }
        source.checkCurrent()
    }
    override fun checkCurrent() = current()
    private fun identity(): Identity {
        current()
        val value = source.identity()
        ref(value.accountViewRef); bounded(value.displayName, 256); bounded(value.publicIdentifier, 512)
        current()
        return value
    }
    private fun routes(): List<Route> {
        current()
        val values = source.routes().toList()
        require(values.size <= 250 && values.map { it.id }.distinct().size == values.size)
        values.forEach { ref(it.id); bounded(it.title, 256); bounded(it.peerIdentifier, 512)
            require(it.roomId.startsWith("!") && it.localSender.startsWith("@") && it.remoteSender.startsWith("@"))
            ref(it.roomId); ref(it.localSender); ref(it.remoteSender) }
        current()
        return values
    }
    private fun state(records: Records, identity: Identity): org.json.JSONObject {
        val state = records.state() ?: org.json.JSONObject().put("version", 1)
            .put("account", identity.accountViewRef).put("revision", 0L).put("active", org.json.JSONObject.NULL)
        require(state.get("version") == 1 && state.getString("account") == identity.accountViewRef)
        val revision = state.get("revision")
        require((revision is Long || revision is Int) && (revision as Number).toLong() in 0..9007199254740990L)
        return state
    }
    private fun bump(records: Records, identity: Identity) {
        val value = state(records, identity)
        value.put("revision", Math.addExact(value.getLong("revision"), 1))
        records.state(value)
    }
    private fun record(records: Records, id: String, identity: Identity): org.json.JSONObject {
        val value = checkNotNull(records.operation(id)) { "VEIL_PRODUCT_ORIGINAL_JOURNAL_REQUIRED" }
        require(value.get("version") == 1 && value.getString("reference") == id &&
            value.getString("account") == identity.accountViewRef)
        return value
    }
    private fun unfinished(records: Records, identity: Identity) =
        records.operations().also { require(it.size <= 4096) }
            .filter { record(records, it, identity).getString("status") != "CLOSED" }
    override fun projection(): Map<String, Any?> {
        val who = identity()
        val routes = routes()
        val invitations = source.invitations().toList()
        require(invitations.size <= 100 && invitations.map { it.id }.distinct().size == invitations.size)
        invitations.forEach { ref(it.id); bounded(it.displayName, 256) }
        val view = store.transaction { records ->
            val state = state(records, who)
            val active = state.opt("active").let { if (it == null || it === org.json.JSONObject.NULL) null else it as String }
                ?.takeIf { id -> routes.any { it.id == id } }
            val ids = records.operations().also { require(it.size <= 4096) }
            val operations = ids.map { record(records, it, who) }.sortedBy {
                val n = it.get("sequence")
                require((n is Long || n is Int) && (n as Number).toLong() in 1..9007199254740990L)
                (n as Number).toLong()
            }
            val messages = operations.filter { it.optString("conversationId") == active &&
                it.getString("type") == "message" &&
                (it.getString("direction") == "outgoing" || it.getString("status") in setOf("COMMITTED", "CLOSED")) }
                .takeLast(250).map { item ->
                    mapOf("id" to item.getString("logicalId"), "conversationId" to item.getString("conversationId"),
                        "senderLabel" to if (item.getString("direction") == "outgoing") who.displayName
                            else routes.single { it.id == item.getString("conversationId") }.title,
                        "body" to item.getString("body"), "direction" to item.getString("direction"),
                        "submission" to if (item.getString("status") in setOf("COMMITTED", "CLOSED")) "confirmed" else "unknown",
                        "delivery" to "unconfirmed", "attachments" to emptyList<Any>())
                }
            val recoveries = operations.filter { it.getString("status") != "CLOSED" }.map {
                mapOf("originalOperationRef" to it.getString("reference"),
                    "label" to "Check the original operation", "state" to "unknown")
            }
            require(recoveries.size <= 128)
            mapOf<String, Any?>("kind" to "AUTHORIZED", "accountViewRef" to who.accountViewRef,
                "viewRevision" to state.getLong("revision").toString(),
                "profile" to mapOf("displayName" to who.displayName, "publicIdentifier" to who.publicIdentifier),
                "activeConversationId" to active,
                "conversations" to routes.map { mapOf("id" to it.id, "title" to it.title, "preview" to "", "unreadCount" to 0) },
                "messages" to messages, "contacts" to routes.map {
                    mapOf("id" to it.id, "displayName" to it.title, "publicIdentifier" to it.peerIdentifier) },
                "contactRequests" to invitations.map { mapOf("id" to it.id, "displayName" to it.displayName) },
                "moments" to emptyList<Any>(), "devices" to emptyList<Any>(), "audiences" to emptyList<Any>(),
                "recoveries" to recoveries, "localAi" to "unsupported",
                "actions" to if (recoveries.isEmpty()) listOf("openConversation", "sendMessage", "requestContact", "acceptContact")
                    else listOf("openConversation", "reviewRecovery"))
        }
        current()
        return view
    }
    override fun openConversation(command: Map<String, Any?>): Map<String, Any?> {
        val who = identity()
        val selected = routes().single { it.id == command["conversationId"] }
        store.transaction { records ->
            val state = state(records, who)
            check(state.getLong("revision").toString() == command["viewRevision"]) { "VEIL_PRODUCT_STALE_VIEW" }
            state.put("active", selected.id).put("revision", Math.addExact(state.getLong("revision"), 1))
            records.state(state)
        }
        current()
        return projection()
    }
    override fun validate(command: Map<String, Any?>): String? =
        if (command["type"] == "sendMessage" && command["replyToMessageId"] != null) "UNAVAILABLE" else null
    override fun prepare(command: Map<String, Any?>, context: Map<String, Any?>,
                         capture: (VeilNativeMessageBusiness.Original) -> Unit) {
        current()
        check(retained == null && failure == null) { "VEIL_PRODUCT_ORIGINAL_RETAINED" }
        val who = identity()
        val draft = java.util.Collections.unmodifiableMap(LinkedHashMap(command))
        val call = java.util.Collections.unmodifiableMap(LinkedHashMap(context))
        require(call["accountViewRef"] == who.accountViewRef)
        store.transaction { records ->
            check(unfinished(records, who).isEmpty()) { "VEIL_PRODUCT_RESTORE_ORIGINAL_REQUIRED" }
            check(state(records, who).getLong("revision").toString() == call["viewRevision"])
        }
        if (draft["type"] == "sendMessage") {
            require(draft["replyToMessageId"] == null) { "VEIL_PRODUCT_REPLY_NOT_CONNECTED" }
            val route = routes().single { it.id == draft["conversationId"] }
            val body = draft["body"] as String
            bounded(body, 16000)
            val id = java.util.UUID.randomUUID().toString()
            val frame = com.ynx.social.veil.VeilMessageFrame.send(logical(id), body.toByteArray(Charsets.UTF_8))
            val original = Message(who, route, id, draft, call, frame, false, null, body, null)
            retained = original
            capture(original)
            original.persistInitial()
            val borrowed = frame.copyOf()
            try { source.prepareMessage(draft, call, id, borrowed, original::captureAuthority) }
            finally { borrowed.fill(0) }
            original.requireAuthority()
        } else {
            require(draft["type"] in setOf("requestContact", "acceptContact"))
            source.prepareContact(draft, call) { authority ->
                check(retained == null) { "VEIL_PRODUCT_ORIGINAL_ALREADY_CAPTURED" }
                val original = Contact(who, draft, call, authority)
                retained = original
                capture(original)
                original.persistInitial()
            }
            check(retained != null) { "VEIL_PRODUCT_ORIGINAL_NOT_CAPTURED" }
        }
        current()
    }
    /** Internal normal sync handoff only. The source binds the peer and event;
     * downloaded bytes alone never authorize a device or decrypt a message. */
    fun incoming(conversationId: String, eventId: String, sender: String,
                 content: VeilMatrixCiphertextHttpTransport.Content,
                 capture: (VeilNativeMessageBusiness.Message) -> Unit) {
        current(); check(retained == null && failure == null)
        val who = identity()
        val route = routes().single { it.id == conversationId && it.remoteSender == sender }
        ref(eventId); require(eventId.startsWith("$"))
        store.transaction { records ->
            check(unfinished(records, who).isEmpty()) { "VEIL_PRODUCT_RESTORE_ORIGINAL_REQUIRED" }
            check(records.operation(content.logicalId) == null) { "VEIL_PRODUCT_ORIGINAL_ALREADY_SEEN" }
        }
        val original = Message(who, route, content.logicalId, emptyMap(), emptyMap(), null, true, eventId, "", content)
        retained = original
        try {
            capture(original)
            original.persistInitial()
            val bytes = courier.download(content, original)
            try {
                val frame = com.ynx.social.veil.VeilMessageFrame.receive(logical(content.logicalId), content.kind, bytes)
                original.installIncomingFrame(frame)
                val borrowed = frame.copyOf()
                try { source.prepareIncoming(route, eventId, content.logicalId, borrowed, original::captureAuthority) }
                finally { borrowed.fill(0) }
                original.requireAuthority()
            } finally { bytes.fill(0) }
            current()
        } catch (error: Throwable) { original.retain(error) }
    }


    internal class HistoryCapacity(cause: Throwable? = null) :
        IllegalStateException("VEIL_MATRIX_HISTORY_STORAGE_CAPACITY", cause)
    private fun opaque(value: org.json.JSONObject, key: String): String? =
        if (!value.has(key) || value.isNull(key)) null else value.getString(key).also { bounded(it, 2048) }
    private fun events(rows: org.json.JSONArray): List<VeilMatrixCiphertextHttpTransport.SyncEvent> {
        require(rows.length() <= 128)
        return (0 until rows.length()).map { event(rows.getJSONObject(it)) }
    }
    private fun eventRows(values: List<VeilMatrixCiphertextHttpTransport.SyncEvent>) =
        org.json.JSONArray().also { result -> values.forEach { result.put(eventRow(it)) } }
    private fun sameEvent(a: VeilMatrixCiphertextHttpTransport.SyncEvent,
                          b: VeilMatrixCiphertextHttpTransport.SyncEvent): Boolean =
        a.roomId == b.roomId && a.eventId == b.eventId && a.sender == b.sender &&
            VeilMatrixCiphertextHttpTransport.parseContent(a.content) ==
                VeilMatrixCiphertextHttpTransport.parseContent(b.content)
    private fun admitted(values: List<VeilMatrixCiphertextHttpTransport.SyncEvent>, known: List<Route>) {
        values.forEach { entry -> require(known.any { it.roomId == entry.roomId &&
            (it.remoteSender == entry.sender || it.localSender == entry.sender) }) }
    }
    private fun boundaries(state: org.json.JSONObject): List<VeilMatrixCiphertextHttpTransport.SyncEvent> {
        val saved = if (state.has("syncBoundaries")) state.getJSONArray("syncBoundaries") else org.json.JSONArray()
        require(saved.length() <= 250)
        return (0 until saved.length()).map { event(saved.getJSONObject(it)) }.also {
            require(it.map { entry -> entry.roomId }.distinct().size == it.size)
        }
    }
    private fun gapRooms(gap: org.json.JSONObject): List<org.json.JSONObject> {
        val values = gap.getJSONArray("rooms"); require(values.length() in 1..250)
        return (0 until values.length()).map { values.getJSONObject(it) }.also {
            require(it.map { room -> room.getString("room") }.distinct().size == it.size)
        }
    }
    private fun originalGap(records: Records, who: Identity, expected: org.json.JSONObject): org.json.JSONObject {
        val state = state(records, who)
        check(opaque(expected, "since") == cursor(state) && queue(state).length() == 0)
        check(state.getJSONObject("syncGap").toString() == expected.toString()) {
            "VEIL_MATRIX_HISTORY_ORIGINAL_CHANGED" }
        return state
    }
    private fun retainHistoryFailure(who: Identity, expected: org.json.JSONObject, error: Throwable): Nothing {
        if (syncFailure == null || syncFailure is VeilMatrixCiphertextHttpTransport.SyncGap ||
            syncFailure is java.io.IOException || syncFailure is HistoryCapacity) syncFailure = error
        val first = checkNotNull(syncFailure)
        try {
            store.transaction { records ->
                val state = originalGap(records, who, expected)
                val gap = state.getJSONObject("syncGap")
                if (!gap.has("failure")) gap.put("failure",
                    if (error.message == "VEIL_MATRIX_HISTORY_UNAVAILABLE" ||
                        error.message == "VEIL_MATRIX_HISTORY_BOUNDARY_REQUIRED") error.message
                    else "VEIL_MATRIX_HISTORY_ORIGINAL_UNKNOWN")
                records.state(state)
            }
        } catch (secondary: Throwable) { if (secondary !== first) first.addSuppressed(secondary) }
        throw first
    }
    private fun digest(value: String): String = java.security.MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it.toInt() and 255) }
    private fun historyId(gap: org.json.JSONObject, type: String, value: String): String =
        "matrix-history-" + gap.getString("id") + "-" + type + "-" + digest(value)
    private fun tokenId(gap: org.json.JSONObject, room: String, token: String) =
        historyId(gap, "token", room + "\u0000" + token)
    private fun eventId(gap: org.json.JSONObject, value: VeilMatrixCiphertextHttpTransport.SyncEvent) =
        historyId(gap, "event", value.roomId + "\u0000" + value.eventId)
    private fun logicalId(gap: org.json.JSONObject, value: VeilMatrixCiphertextHttpTransport.SyncEvent) =
        historyId(gap, "logical", VeilMatrixCiphertextHttpTransport.parseContent(value.content).logicalId)
    private fun owner(value: org.json.JSONObject, who: Identity, gap: org.json.JSONObject) {
        check(value.getString("account") == who.accountViewRef &&
            value.getString("gap") == gap.getString("id") && value.getInt("version") == 1) {
            "VEIL_MATRIX_HISTORY_RECORD_OWNER" }
    }
    private fun originalToken(records: Records, who: Identity, gap: org.json.JSONObject,
                              room: String, token: String): org.json.JSONObject? =
        records.history(tokenId(gap, room, token))?.also {
            owner(it, who, gap)
            check(it.getString("room") == room && it.getString("from") == token) {
                "VEIL_MATRIX_HISTORY_TOKEN_INDEX_CONFLICT" }
        }
    private fun originalIndex(records: Records, who: Identity, gap: org.json.JSONObject,
                              value: VeilMatrixCiphertextHttpTransport.SyncEvent,
                              logical: Boolean): org.json.JSONObject? =
        records.history(if (logical) logicalId(gap, value) else eventId(gap, value))?.also {
            owner(it, who, gap)
            check(sameEvent(event(it.getJSONObject("event")), value)) {
                "VEIL_MATRIX_HISTORY_EVENT_CONFLICT" }
        }
    private fun readPage(records: Records, who: Identity, gap: org.json.JSONObject,
                         reference: org.json.JSONObject): org.json.JSONObject {
        val hash = reference.getString("hash")
        val id = reference.getString("id")
        check(id == historyId(gap, "page", hash))
        val page = checkNotNull(records.history(id)) { "VEIL_MATRIX_HISTORY_SEGMENT_REQUIRED" }
        owner(page, who, gap)
        check(digest(page.toString()) == hash) { "VEIL_MATRIX_HISTORY_SEGMENT_HASH" }
        require(events(page.getJSONArray("rows")).size <= 32)
        require(events(page.getJSONArray("originalRows")).size <= 32)
        require(events(page.getJSONArray("prefix")).size <= 32)
        return page
    }
    private fun nextPage(page: org.json.JSONObject): org.json.JSONObject? =
        if (page.isNull("next")) null else page.getJSONObject("next")
    /** Each immutable segment retains a <=32 identity lookahead. Empty-page
     * chains therefore do not trigger an unbounded scan on a normal read. */
    private fun prefix(records: Records, who: Identity, gap: org.json.JSONObject, room: String,
                       head: org.json.JSONObject?): List<VeilMatrixCiphertextHttpTransport.SyncEvent> {
        if (head == null) return emptyList()
        val page = readPage(records, who, gap, head)
        check(page.getString("room") == room) { "VEIL_MATRIX_HISTORY_SEGMENT_ROOM" }
        return events(page.getJSONArray("prefix")).also { require(it.size <= 32) }
    }
    /** These indices identify this protected read batch, not trusted devices.
     * The storage engine's actual 4096-record/64MiB quota remains in force. */
    private fun savePage(records: Records, who: Identity, gap: org.json.JSONObject, room: String,
                         from: String?, end: String?, rawHash: String,
                         originalRows: List<VeilMatrixCiphertextHttpTransport.SyncEvent>,
                         accepted: List<VeilMatrixCiphertextHttpTransport.SyncEvent>,
                         next: org.json.JSONObject?): org.json.JSONObject {
        require(originalRows.size <= 32 && accepted.size <= 32)
        val page = org.json.JSONObject().put("version", 1).put("account", who.accountViewRef)
            .put("gap", gap.getString("id")).put("room", room).put("from", from ?: org.json.JSONObject.NULL)
            .put("end", end ?: org.json.JSONObject.NULL).put("responseHash", rawHash)
            .put("originalRows", eventRows(originalRows)).put("rows", eventRows(accepted))
            .put("prefix", eventRows((accepted + prefix(records, who, gap, room, next)).take(32)))
            .put("next", next ?: org.json.JSONObject.NULL)
        val hash = digest(page.toString())
        val id = historyId(gap, "page", hash)
        check(records.history(id) == null) { "VEIL_MATRIX_HISTORY_SEGMENT_ALREADY_CAPTURED" }
        for (entry in accepted) {
            check(originalIndex(records, who, gap, entry, false) == null &&
                originalIndex(records, who, gap, entry, true) == null) {
                "VEIL_MATRIX_HISTORY_BOUNDARY_CONFLICT" }
            val index = org.json.JSONObject().put("version", 1).put("account", who.accountViewRef)
                .put("gap", gap.getString("id")).put("page", id).put("event", eventRow(entry))
            records.history(eventId(gap, entry), index)
            records.history(logicalId(gap, entry), index)
        }
        if (from != null) {
            check(originalToken(records, who, gap, room, from) == null) {
                "VEIL_MATRIX_HISTORY_CURSOR_CYCLE" }
            records.history(tokenId(gap, room, from), org.json.JSONObject().put("version", 1)
                .put("account", who.accountViewRef).put("gap", gap.getString("id")).put("room", room)
                .put("from", from).put("end", end ?: org.json.JSONObject.NULL).put("page", id)
                .put("responseHash", rawHash))
        }
        records.history(id, page)
        gap.put("segments", Math.addExact(gap.getLong("segments"), 1L))
        return org.json.JSONObject().put("id", id).put("hash", hash)
    }
    private fun captureGap(records: Records, who: Identity, batch: VeilMatrixCiphertextHttpTransport.SyncGap) {
        val state = state(records, who)
        check(cursor(state) == batch.since && queue(state).length() == 0 && !state.has("syncGap"))
        val existing = boundaries(state)
        val rooms = org.json.JSONArray()
        val gap = org.json.JSONObject().put("id", java.util.UUID.randomUUID().toString())
            .put("since", batch.since ?: org.json.JSONObject.NULL).put("next", batch.next)
            .put("tail", eventRows(batch.events)).put("rooms", rooms).put("segments", 0L)
        val roomIds = (batch.boundaries.map { it.room } + batch.events.map { it.roomId }).distinct()
        for (room in roomIds) {
            val boundary = batch.boundaries.singleOrNull { it.room == room }
            val anchor = existing.singleOrNull { it.roomId == room }
            if (anchor != null) {
                val content = VeilMatrixCiphertextHttpTransport.parseContent(anchor.content)
                check(matchesSaved(record(records, content.logicalId, who), anchor))
            }
            val tail = batch.events.filter { it.roomId == room }
            val index = if (anchor == null) -1 else tail.indexOfFirst { it.eventId == anchor.eventId }
            if (index >= 0) check(sameEvent(tail[index], checkNotNull(anchor))) {
                "VEIL_MATRIX_HISTORY_EVENT_CONFLICT" }
            val accepted = if (index >= 0) tail.drop(index + 1) else tail
            val head = savePage(records, who, gap, room, null, null,
                digest(eventRows(tail).toString()), tail, accepted, null)
            rooms.put(org.json.JSONObject().put("room", room)
                .put("previous", boundary?.previous ?: org.json.JSONObject.NULL)
                .put("from", boundary?.previous ?: org.json.JSONObject.NULL)
                .put("anchor", anchor?.let { eventRow(it) } ?: org.json.JSONObject.NULL)
                .put("head", head).put("connected", boundary == null || index >= 0))
        }
        state.put("syncGap", gap)
        records.state(state)
    }
    /** One normal read fetches one backward page. Each page and its exact
     * token/event indices are protected records, not an ever-growing JSON list. */
    private fun fillHistoryPage(who: Identity, known: List<Route>, saved: org.json.JSONObject) {
        val original = saved.getJSONObject("syncGap")
        if (original.has("failure")) error(original.getString("failure"))
        try {
            check(opaque(original, "since") == cursor(saved)) { "VEIL_MATRIX_HISTORY_ORIGINAL_CURSOR_CHANGED" }
            val selected = gapRooms(original).first { !it.getBoolean("connected") }
            val room = selected.getString("room"); require(known.any { it.roomId == room })
            val from = opaque(selected, "from") ?: error("VEIL_MATRIX_HISTORY_BOUNDARY_REQUIRED")
            if (selected.isNull("anchor")) error("VEIL_MATRIX_HISTORY_BOUNDARY_REQUIRED")
            val anchor = event(selected.getJSONObject("anchor"))
            store.transaction { records ->
                originalGap(records, who, original)
                check(originalToken(records, who, original, room, from) == null) {
                    "VEIL_MATRIX_HISTORY_CURSOR_CYCLE" }
            }
            val guard = object : VeilMatrixCiphertextHttpTransport.Guard {
                override fun checkCurrent() = current()
                override fun persistOriginal(snapshot: VeilMatrixCiphertextHttpTransport.Snapshot) {
                    error("VEIL_MATRIX_HISTORY_IS_READ_ONLY")
                }
            }
            val page = courier.history(room, from, guard)
            admitted(page.events, known)
            val ordered = page.events.asReversed()
            val boundary = ordered.indexOfFirst { it.eventId == anchor.eventId }
            if (boundary >= 0) check(sameEvent(ordered[boundary], anchor)) { "VEIL_MATRIX_HISTORY_EVENT_CONFLICT" }
            val connected = boundary >= 0
            val candidate = if (connected) ordered.drop(boundary + 1) else ordered
            current()
            store.transaction { records ->
                val state = originalGap(records, who, original)
                val updated = state.getJSONObject("syncGap")
                val target = gapRooms(updated).single { it.getString("room") == room }
                if (page.end != null) check(page.end != from &&
                    originalToken(records, who, updated, room, page.end) == null) {
                    "VEIL_MATRIX_HISTORY_CURSOR_CYCLE" }
                val head = if (target.isNull("head")) null else target.getJSONObject("head")
                val newer = prefix(records, who, updated, room, head)
                var overlap = 0
                for (size in minOf(candidate.size, newer.size) downTo 1) {
                    if (candidate.takeLast(size).zip(newer.take(size)).all { (a, b) -> sameEvent(a, b) }) {
                        overlap = size; break
                    }
                }
                for ((position, entry) in candidate.withIndex()) {
                    val byEvent = originalIndex(records, who, updated, entry, false)
                    val byLogical = originalIndex(records, who, updated, entry, true)
                    if (position < candidate.size - overlap) check(byEvent == null && byLogical == null) {
                        "VEIL_MATRIX_HISTORY_BOUNDARY_CONFLICT" }
                    else check(byEvent != null && byLogical != null &&
                        byEvent.getString("page") == byLogical.getString("page")) {
                        "VEIL_MATRIX_HISTORY_BOUNDARY_CONFLICT" }
                }
                val next = savePage(records, who, updated, room, from, page.end, page.responseSha256,
                    page.events, candidate.dropLast(overlap), head)
                target.put("head", next).put("connected", connected).put("from", page.end ?: org.json.JSONObject.NULL)
                updated.remove("capacity")
                if (!connected && page.end == null) updated.put("failure", "VEIL_MATRIX_HISTORY_UNAVAILABLE")
                records.state(state)
            }
            current()
            if (!connected && page.end == null) {
                syncFailure = IllegalStateException("VEIL_MATRIX_HISTORY_UNAVAILABLE")
                throw checkNotNull(syncFailure)
            }
            syncFailure = null
        } catch (capacity: HistoryCapacity) {
            // No Native operation was attempted. Confirm the original protected
            // gap survived the rolled-back write before allowing a normal retry.
            try {
                store.transaction { records ->
                    val state = originalGap(records, who, original)
                    state.getJSONObject("syncGap").put("capacity", "SOCIAL_STORAGE_CAPACITY")
                    records.state(state)
                }
                current()
            } catch (unknown: Throwable) {
                throw IllegalStateException("VEIL_MATRIX_HISTORY_CAPACITY_STATE_UNKNOWN", capacity).also {
                    it.addSuppressed(unknown)
                }
            }
            syncFailure = capacity
            throw capacity
        } catch (network: java.io.IOException) {
            syncFailure = network; current()
        } catch (error: Throwable) {
            if (error === syncFailure && error.message == "VEIL_MATRIX_HISTORY_UNAVAILABLE") throw error
            retainHistoryFailure(who, original, error)
        }
    }
    private fun retirePage(records: Records, who: Identity, state: org.json.JSONObject,
                           reference: org.json.JSONObject) {
        val gap = state.getJSONObject("syncGap")
        check(gapRooms(gap).all { it.getBoolean("connected") } && queue(state).length() == 0)
        val page = readPage(records, who, gap, reference)
        val room = gapRooms(gap).single { it.getString("room") == page.getString("room") }
        check(room.getJSONObject("head").toString() == reference.toString())
        for (entry in events(page.getJSONArray("rows"))) {
            val content = VeilMatrixCiphertextHttpTransport.parseContent(entry.content)
            check(matchesSaved(record(records, content.logicalId, who), entry)) {
                "VEIL_MATRIX_HISTORY_SEGMENT_NOT_COMMITTED" }
            for (logical in listOf(false, true)) {
                val index = checkNotNull(originalIndex(records, who, gap, entry, logical))
                check(index.getString("page") == reference.getString("id"))
                records.removeHistory(if (logical) logicalId(gap, entry) else eventId(gap, entry))
            }
        }
        opaque(page, "from")?.let { from ->
            val token = checkNotNull(originalToken(records, who, gap, page.getString("room"), from))
            check(token.getString("page") == reference.getString("id"))
            records.removeHistory(tokenId(gap, page.getString("room"), from))
        }
        records.removeHistory(reference.getString("id"))
        room.put("head", nextPage(page) ?: org.json.JSONObject.NULL)
        gap.put("segments", Math.subtractExact(gap.getLong("segments"), 1L)).remove("activePage")
        if (gapRooms(gap).all { it.isNull("head") }) {
            check(gap.getLong("segments") == 0L)
            state.put("syncCursor", gap.getString("next")).remove("syncNext")
            state.remove("syncGap")
        }
    }
    /** After the exact boundary is joined, only one oldest protected segment
     * enters the <=128 Native queue. Its removal shares the final CLOSED commit. */
    private fun loadHistoryQueue(who: Identity) {
        current()
        store.transaction { records ->
            val state = state(records, who)
            val gap = state.getJSONObject("syncGap")
            check(!gap.has("failure") && gapRooms(gap).all { it.getBoolean("connected") })
            check(queue(state).length() == 0 && !gap.has("activePage"))
            val selected = gapRooms(gap).first { !it.isNull("head") }
            val reference = selected.getJSONObject("head")
            val page = readPage(records, who, gap, reference)
            check(page.getString("room") == selected.getString("room")) { "VEIL_MATRIX_HISTORY_SEGMENT_ROOM" }
            val values = events(page.getJSONArray("rows"))
            if (values.isEmpty()) retirePage(records, who, state, reference)
            else {
                gap.put("activePage", reference)
                state.put("syncQueue", eventRows(values)).put("syncNext", gap.getString("next"))
            }
            records.state(state)
        }
        current()
    }

    private var syncFailure: Throwable? = null
    private fun cursor(value: org.json.JSONObject): String? =
        if (value.has("syncCursor")) value.getString("syncCursor").also { bounded(it, 2048) } else null
    private fun queue(value: org.json.JSONObject): org.json.JSONArray =
        (if (value.has("syncQueue")) value.getJSONArray("syncQueue") else org.json.JSONArray())
            .also { require(it.length() <= 128) }
    private fun event(row: org.json.JSONObject): VeilMatrixCiphertextHttpTransport.SyncEvent {
        require(row.keys().asSequence().toSet() == setOf("roomId", "eventId", "sender", "content"))
        return VeilMatrixCiphertextHttpTransport.SyncEvent(row.getString("roomId"),
            row.getString("eventId"), row.getString("sender"), row.getString("content"))
    }
    private fun eventRow(value: VeilMatrixCiphertextHttpTransport.SyncEvent) = org.json.JSONObject()
        .put("roomId", value.roomId).put("eventId", value.eventId)
        .put("sender", value.sender).put("content", value.content)
    private fun matchesSaved(saved: org.json.JSONObject, expected: VeilMatrixCiphertextHttpTransport.SyncEvent): Boolean {
        val content = VeilMatrixCiphertextHttpTransport.parseContent(expected.content)
        return saved.getString("type") == "message" && saved.getString("status") == "CLOSED" &&
            saved.getString("logicalId") == content.logicalId && saved.getString("roomId") == expected.roomId &&
            saved.getString("eventId") == expected.eventId && saved.getString("sender") == expected.sender &&
            saved.getString("media") == content.media && saved.getInt("ciphertextType") == content.kind &&
            saved.getString("ciphertextSha256") == content.sha256 && saved.getInt("ciphertextBytes") == content.bytes
    }
    /** Queue and next cursor are committed together only when each original
     * event has a verified Native/business terminal. This is progress, not trust. */
    private fun acknowledge(records: Records, who: Identity, value: VeilMatrixCiphertextHttpTransport.SyncEvent) {
        val state = state(records, who)
        val rows = queue(state)
        if (rows.length() == 0 || event(rows.getJSONObject(0)) != value) return
        val content = VeilMatrixCiphertextHttpTransport.parseContent(value.content)
        check(matchesSaved(record(records, content.logicalId, who), value)) { "VEIL_MATRIX_SYNC_ORIGINAL_NOT_COMMITTED" }
        val remaining = org.json.JSONArray()
        for (index in 1 until rows.length()) remaining.put(rows.getJSONObject(index))
        state.put("syncQueue", remaining)
        val anchors = boundaries(state).filter { it.roomId != value.roomId } + value
        state.put("syncBoundaries", eventRows(anchors))
        if (remaining.length() == 0) {
            if (state.has("syncGap")) {
                val gap = state.getJSONObject("syncGap")
                retirePage(records, who, state, gap.getJSONObject("activePage"))
            } else {
                val next = state.getString("syncNext"); bounded(next, 2048)
                state.put("syncCursor", next).remove("syncNext")
            }
        }
        records.state(state)
    }
    override fun nextIncoming(capture: (VeilNativeMessageBusiness.Message) -> Unit) {
        current()
        if (retained != null || failure != null) return
        val who = identity()
        val known = routes()
        if (known.isEmpty()) return
        var saved = store.transaction { records ->
            if (unfinished(records, who).isNotEmpty()) return@transaction null
            state(records, who)
        } ?: return
        var rows = queue(saved)
        if (rows.length() == 0 && saved.has("syncGap")) {
            if (!gapRooms(saved.getJSONObject("syncGap")).all { it.getBoolean("connected") }) {
                fillHistoryPage(who, known, saved)
                saved = store.transaction { state(it, who) }
            }
            if (saved.has("syncGap") && !saved.getJSONObject("syncGap").has("failure") &&
                gapRooms(saved.getJSONObject("syncGap")).all { it.getBoolean("connected") })
                loadHistoryQueue(who)
            saved = store.transaction { state(it, who) }
            rows = queue(saved)
            if (rows.length() == 0) return // One network page or one empty-segment retirement per normal call.
        }
        if (rows.length() == 0) {
            val since = cursor(saved)
            val guard = object : VeilMatrixCiphertextHttpTransport.Guard {
                override fun checkCurrent() = current()
                override fun persistOriginal(snapshot: VeilMatrixCiphertextHttpTransport.Snapshot) {
                    error("VEIL_MATRIX_SYNC_IS_READ_ONLY")
                }
            }
            val admittedRooms = known.map { it.roomId }.distinct()
            val batch = try {
                courier.sync(since, admittedRooms, guard)
            } catch (gap: VeilMatrixCiphertextHttpTransport.SyncGap) {
                admitted(gap.events, known)
                store.transaction { records -> captureGap(records, who, gap) }
                syncFailure = gap
                current()
                return // Saved gap will be fetched, never silently crossed.
            } catch (network: java.io.IOException) {
                // A later normal read can make one new read-only GET. This is
                // not replay of an effectful Native/POST/PUT original.
                syncFailure = network
                current()
                return
            }
            current()
            syncFailure = null
            val captured = org.json.JSONArray()
            for (entry in batch.events) {
                require(known.any { it.roomId == entry.roomId &&
                    (it.remoteSender == entry.sender || it.localSender == entry.sender) })
                captured.put(eventRow(entry))
            }
            store.transaction { records ->
                val state = state(records, who)
                check(cursor(state) == since && queue(state).length() == 0)
                state.put("syncQueue", captured)
                if (captured.length() == 0) {
                    state.put("syncCursor", batch.next)
                } else state.put("syncNext", batch.next)
                records.state(state)
            }
            current()
            rows = captured
        }
        if (rows.length() == 0) return
        val selected = event(rows.getJSONObject(0))
        val content = VeilMatrixCiphertextHttpTransport.parseContent(selected.content)
        val already = store.transaction { it.operation(content.logicalId) }
        if (already != null) {
            // Exact self echoes also need an original CLOSED Native/business
            // result. This does not establish peer delivery.
            check(matchesSaved(already, selected)) { "VEIL_MATRIX_SYNC_ORIGINAL_CONFLICT" }
            store.transaction { acknowledge(it, who, selected) }
            current()
            return
        }
        val route = known.single { it.roomId == selected.roomId && it.remoteSender == selected.sender }
        incoming(route.id, selected.eventId, selected.sender, content, capture)
    }
    internal fun retainedSyncFailure(): Throwable? { current(); return syncFailure }

    private abstract inner class Operation(
        val who: Identity, final override val reference: String,
        val command: Map<String, Any?>, val context: Map<String, Any?>
    ) : VeilNativeMessageBusiness.Original {
        var firstFailure: Throwable? = null
        var closed = false
        fun retain(error: Throwable): Nothing {
            if (firstFailure == null) firstFailure = error
            else if (firstFailure !== error) firstFailure!!.addSuppressed(error)
            failure = firstFailure
            try { update { it.put("status", "UNKNOWN") } }
            catch (secondary: Throwable) { if (secondary !== firstFailure) firstFailure!!.addSuppressed(secondary) }
            throw checkNotNull(firstFailure)
        }
        override fun checkCurrent() {
            current(); check(!closed && retained === this)
            require(identity().accountViewRef == who.accountViewRef)
        }
        override fun requireRequest(command: Map<String, Any?>, context: Map<String, Any?>) {
            checkCurrent(); require(this.command == command && this.context == context)
        }
        fun update(block: (org.json.JSONObject) -> Unit) {
            current()
            store.transaction { records ->
                val value = record(records, reference, who)
                block(value)
                records.operation(reference, value)
                bump(records, who)
            }
            current()
        }
        fun status() = store.transaction { record(it, reference, who).getString("status") }
        fun finish(after: (Records) -> Unit = {}) {
            current()
            store.transaction { records ->
                val value = record(records, reference, who)
                value.put("status", "CLOSED")
                records.operation(reference, value)
                after(records)
                bump(records, who)
            }
            current()
            closed = true; retained = null
        }
    }
    private inner class Message(
        who: Identity, val route: Route, id: String,
        command: Map<String, Any?>, context: Map<String, Any?>,
        private var originalFrame: ByteArray?, val incoming: Boolean,
        val eventId: String?, private var body: String,
        private val incomingContent: VeilMatrixCiphertextHttpTransport.Content?
    ) : Operation(who, id, command, context), VeilNativeMessageBusiness.Message,
        VeilMatrixCiphertextHttpTransport.Guard {
        private var authority: MessageAuthority? = null
        private var transport: VeilMatrixCiphertextHttpTransport.Original? = null
        private var outputSeen = false
        private var closeAttempted = false
        fun captureAuthority(value: MessageAuthority) {
            check(authority == null) { "VEIL_PRODUCT_ORIGINAL_ALREADY_CAPTURED" }
            authority = value
        }
        override fun requireRequest(command: Map<String, Any?>, context: Map<String, Any?>) {
            super.requireRequest(command, context)
            checkNotNull(authority).requireRequest(command, context)
        }
        fun requireAuthority() { checkNotNull(authority) { "VEIL_PRODUCT_NATIVE_MESSAGE_SOURCE_REQUIRED" }.checkCurrent() }
        override fun checkCurrent() {
            super.checkCurrent()
            authority?.checkCurrent()
        }
        fun persistInitial() {
            checkCurrent()
            store.transaction { records ->
                check(records.operation(reference) == null)
                records.operation(reference, org.json.JSONObject().put("version", 1).put("reference", reference)
                    .put("account", who.accountViewRef).put("type", "message")
                    .put("sequence", Math.addExact(state(records, who).getLong("revision"), 1))
                    .put("logicalId", reference).put("conversationId", route.id)
                    .put("roomId", route.roomId).put("sender", if (incoming) route.remoteSender else route.localSender)
                    .put("direction", if (incoming) "incoming" else "outgoing").put("body", body)
                    .put("originalCommand", org.json.JSONObject(command).put("replyToMessageId",
                        command["replyToMessageId"] ?: org.json.JSONObject.NULL))
                    .put("originalContext", org.json.JSONObject(context))
                    .put("eventId", eventId ?: org.json.JSONObject.NULL).put("status", "PREPARED").also { value ->
                        incomingContent?.let { content -> value.put("media", content.media)
                            .put("ciphertextSha256", content.sha256).put("ciphertextBytes", content.bytes)
                            .put("ciphertextType", content.kind) }
                    })
                bump(records, who)
            }
            checkCurrent()
        }
        fun installIncomingFrame(frame: ByteArray) {
            check(incoming && originalFrame == null); originalFrame = frame
            update { it.put("originalFrame", java.util.Base64.getEncoder().encodeToString(frame)) }
        }
        override fun sessionRecords(): ByteArray {
            checkCurrent(); return checkNotNull(authority).sessionRecords()
        }
        override fun frame(): ByteArray {
            checkCurrent(); return checkNotNull(originalFrame).copyOf()
        }
        override fun consumeOriginalOutput(output: VeilNativeMessageOutput) {
            checkCurrent(); check(!outputSeen)
            outputSeen = true
            try {
                require(output.direction == if (incoming) 2 else 1)
                val id = output.logicalId()
                try { require(id.contentEquals(logical(reference))) } finally { id.fill(0) }
                val owner = checkNotNull(authority)
                owner.requireCommittedOutput(output)
                checkCurrent()
                val bytes = output.body()
                try {
                    if (incoming) {
                        body = Charsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                            .decode(java.nio.ByteBuffer.wrap(bytes)).toString()
                        bounded(body, 16000)
                        update { it.put("body", body).put("status", "COMMITTED") }
                    } else {
                        // This local sealed journal is additional product persistence,
                        // never a substitute for the original Native ratchet commit.
                        update { it.put("ciphertext", java.util.Base64.getEncoder().encodeToString(bytes))
                            .put("ciphertextType", output.kind).put("status", "NATIVE_COMMITTED") }
                        val tx = courier.capture(output, route.roomId, route.localSender, reference, this)
                        transport = tx
                        tx.send()
                        checkCurrent()
                        check(owner.completion() == VeilNativeMessageBusiness.Completion.COMMITTED)
                        update { it.put("status", "COMMITTED") }
                    }
                } finally { bytes.fill(0) }
                checkCurrent()
            } catch (error: Throwable) { retain(error) }
        }
        override fun persistOriginal(snapshot: VeilMatrixCiphertextHttpTransport.Snapshot) {
            checkCurrent()
            require(!incoming && snapshot.logicalId == reference && snapshot.transactionId == reference &&
                snapshot.roomId == route.roomId && snapshot.sender == route.localSender)
            update { it.put("transportPhase", snapshot.phase.name)
                .put("ciphertextSha256", snapshot.ciphertextSha256).put("ciphertextBytes", snapshot.ciphertextBytes)
                .put("media", snapshot.media ?: org.json.JSONObject.NULL)
                .put("eventId", snapshot.eventId ?: org.json.JSONObject.NULL)
                .put("status", if (snapshot.phase == VeilMatrixCiphertextHttpTransport.Phase.UNKNOWN) "UNKNOWN" else "NATIVE_COMMITTED") }
        }
        override fun completion(): VeilNativeMessageBusiness.Completion {
            checkCurrent()
            val saved = status()
            checkCurrent()
            if (firstFailure != null || saved == "UNKNOWN") return VeilNativeMessageBusiness.Completion.UNKNOWN
            val native = checkNotNull(authority).completion()
            checkCurrent()
            return if (native == VeilNativeMessageBusiness.Completion.COMMITTED && saved == "COMMITTED") native
                else if (native == VeilNativeMessageBusiness.Completion.ABORTED) native
                else VeilNativeMessageBusiness.Completion.PENDING
        }
        override fun close() {
            checkCurrent(); check(!closeAttempted && completion() == VeilNativeMessageBusiness.Completion.COMMITTED)
            closeAttempted = true
            try {
                transport?.retireAfterNativeCommit {
                    check(checkNotNull(authority).completion() == VeilNativeMessageBusiness.Completion.COMMITTED)
                }
                checkNotNull(authority).close()
                // Authority close is not proof of journal success. A late store
                // failure retains this exact operation for explicit recovery.
                finish { records ->
                    if (incoming) {
                        val rows = queue(state(records, who))
                        if (rows.length() > 0) {
                            val selected = event(rows.getJSONObject(0))
                            if (selected.roomId == route.roomId && selected.eventId == eventId)
                                acknowledge(records, who, selected)
                        }
                    }
                }
                originalFrame?.fill(0); originalFrame = null; body = ""
            } catch (error: Throwable) { retain(error) }
        }
    }
    private inner class Contact(who: Identity, command: Map<String, Any?>, context: Map<String, Any?>,
                                private val authority: VeilNativeMessageBusiness.Contact) :
        Operation(who, authority.reference, command, context), VeilNativeMessageBusiness.Contact {
        private var attempted = false
        private var closeAttempted = false
        fun persistInitial() {
            ref(reference)
            checkCurrent()
            store.transaction { records ->
                check(records.operation(reference) == null)
                records.operation(reference, org.json.JSONObject().put("version", 1).put("reference", reference)
                    .put("account", who.accountViewRef).put("type", "contact").put("status", "PREPARED")
                    .put("sequence", Math.addExact(state(records, who).getLong("revision"), 1))
                    .put("originalCommand", org.json.JSONObject(command)).put("originalContext", org.json.JSONObject(context)))
                bump(records, who)
            }
        }
        override fun checkCurrent() { super.checkCurrent(); authority.checkCurrent() }
        override fun requireRequest(command: Map<String, Any?>, context: Map<String, Any?>) {
            super.requireRequest(command, context); authority.requireRequest(command, context)
        }
        override fun executeOriginal() {
            checkCurrent(); check(!attempted); attempted = true
            try {
                update { it.put("status", "ATTEMPTED") }
                authority.executeOriginal()
                checkCurrent()
                if (authority.completion() == VeilNativeMessageBusiness.Completion.COMMITTED)
                    update { it.put("status", "COMMITTED") }
            } catch (error: Throwable) { retain(error) }
        }
        override fun completion(): VeilNativeMessageBusiness.Completion {
            checkCurrent()
            if (firstFailure != null) return VeilNativeMessageBusiness.Completion.UNKNOWN
            return authority.completion()
        }
        override fun close() {
            checkCurrent(); check(!closeAttempted && completion() == VeilNativeMessageBusiness.Completion.COMMITTED)
            closeAttempted = true
            try { authority.close(); finish() } catch (error: Throwable) { retain(error) }
        }
    }
    override fun hasRetainedWork(): Boolean {
        check(Thread.currentThread() === worker) { "VEIL_PRODUCT_WRONG_WORKER" }
        if (retained != null || failure != null) return true
        return try {
            current()
            if (source.hasRetainedWork() || courier.hasRetainedWork()) true
            else {
                val who = identity()
                store.transaction { unfinished(it, who).isNotEmpty() }
            }
        } catch (original: Throwable) {
            // Current/lease/store failures cannot terminate the normal owner's
            // close loop, drop custody, or become a fresh close/replay attempt.
            failure = original
            true
        }
    }
    internal fun retainedCloseFailure(): Throwable? {
        check(Thread.currentThread() === worker) { "VEIL_PRODUCT_WRONG_WORKER" }
        return failure
    }
    fun uses(source: NativeSource, store: VeilNativeStore,
             courier: VeilMatrixCiphertextHttpTransport) =
        this.source === source && this.storageIdentity === store && this.courier === courier
    companion object {
        fun owned(source: NativeSource, store: VeilNativeStore,
                  courier: VeilMatrixCiphertextHttpTransport): VeilMatrixProductBinding =
            VeilMatrixProductBinding(source, object : Store {
                override fun <T> transaction(block: (Records) -> T): T = store.transaction { tx ->
                    block(object : Records {
                        private fun read(kind: VeilRecordKind, id: String): org.json.JSONObject? {
                            val bytes = tx.read(kind, id) ?: return null
                            try {
                                val value = Charsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                                    .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                                    .decode(java.nio.ByteBuffer.wrap(bytes)).toString()
                                val reader = org.json.JSONTokener(value)
                                val json = reader.nextValue()
                                require(json is org.json.JSONObject && reader.nextClean() == '\u0000')
                                return json
                            } finally { bytes.fill(0) }
                        }
                        private fun write(kind: VeilRecordKind, id: String, value: org.json.JSONObject) {
                            val bytes = value.toString().toByteArray(Charsets.UTF_8)
                            try { tx.write(kind, id, bytes) }
                            catch (capacity: IllegalArgumentException) {
                                if (capacity.message == "VEIL_STORAGE_BUDGET_EXCEEDED") throw HistoryCapacity(capacity)
                                throw capacity
                            } finally { bytes.fill(0) }
                        }
                        override fun state() = read(VeilRecordKind.SOCIAL_PRODUCT_STATE, "normal-product-v1")
                        override fun state(value: org.json.JSONObject) = write(VeilRecordKind.SOCIAL_PRODUCT_STATE, "normal-product-v1", value)
                        override fun operation(id: String) = read(VeilRecordKind.SOCIAL_PRODUCT_OPERATION, id)
                        override fun operation(id: String, value: org.json.JSONObject) = write(VeilRecordKind.SOCIAL_PRODUCT_OPERATION, id, value)
                        override fun operations() = tx.ids(VeilRecordKind.SOCIAL_PRODUCT_OPERATION)
                        override fun history(id: String) = read(VeilRecordKind.SOCIAL_PRODUCT_STATE, id)
                        override fun history(id: String, value: org.json.JSONObject) =
                            write(VeilRecordKind.SOCIAL_PRODUCT_STATE, id, value)
                        override fun removeHistory(id: String) = tx.remove(VeilRecordKind.SOCIAL_PRODUCT_STATE, id)
                    })
                }
            }, courier, store)
        /** PUBLIC JVM controls only. Production always uses owned + actual store. */
        internal fun control(source: NativeSource, store: Store, courier: VeilMatrixCiphertextHttpTransport) =
            VeilMatrixProductBinding(source, store, courier)
        private fun logical(id: String): ByteArray {
            val value = java.util.UUID.fromString(id)
            require(value.version() == 4 && value.variant() == 2 && value.toString() == id)
            return java.nio.ByteBuffer.allocate(16).putLong(value.mostSignificantBits).putLong(value.leastSignificantBits).array()
        }
        private fun ref(value: String) { bounded(value, 256); require(value.none { it == '\r' || it == '\n' || it == '\t' }) }
        private fun bounded(value: String, max: Int) {
            require(value.isNotBlank() && value.length <= max &&
                value.none { it.code in 0..8 || it.code in 11..12 || it.code in 14..31 || it.code == 127 })
        }
    }
}

