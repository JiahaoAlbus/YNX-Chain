package com.ynx.social.matrix

import android.app.Activity
import java.util.Collections
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.CompletableFuture
import java.util.concurrent.FutureTask
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/**
 * One original, process-local native login flow. Returned futures are immutable
 * safe OBSERVATIONS, not the retained worker future. No credential/subject DTO.
 */
class VeilSocialLoginCoordinator private constructor(
    private val client: VeilSocialLoginClient,
    private val browser: VeilLoginBrowserAccess
) : AutoCloseable {
    constructor(browserPort: VeilSocialLoginBrowserPort) : this(VeilSocialLoginClient(browserPort.loginProfile), browserPort)
    private val gate = Any()
    internal fun returnLinkDiagnostic(): Map<String, Any> = browser.diagnostic()
    private val failures = VeilLoginFailureDiagnostic()
    internal fun loginFailureDiagnostic(): Map<String, Any> = failures.snapshot()
    private val worker = ThreadPoolExecutor(1, 1, 30, TimeUnit.SECONDS, ArrayBlockingQueue<Runnable>(1),
        { task -> Thread(task, "YNX-login-owned-io").apply { isDaemon = true } }).apply { allowCoreThreadTimeOut(true) }
    private var selected: VeilSocialLoginClient.Intent? = null
    private var status = "UNAVAILABLE"
    private var closed = false
    private var closeAttempted = false
    private var closeActionsFinished = false
    private var closeFailure: Throwable? = null
    private var cancelled = false
    private var running = false
    private var startedAt = 0L
    private var originalFuture: FutureTask<Unit>? = null
    private var pendingCallback: (() -> Pair<VeilSocialLoginClient.BrowserHandoff, String>?)? = null
    private var callbackSeen = false
    private var accountObserved = false
    private var firstDeviceOriginal: VeilCryptoEngineOwner.FirstDeviceIntent? = null
    private var firstDeviceStatus = "CHALLENGE_REQUIRED"
    private var enrollmentStarted = false
    private var sourceAttempted = false
    private var sourceStatus: String? = null
    private var sourceCancellationFailure: Throwable? = null
    private var sourceCancellationSelected = false
    private var sourceFailure: Throwable? = null
    private fun retainSourceFailure(failure: Throwable) = synchronized(gate) {
        val first = sourceFailure
        if (first == null) sourceFailure = failure
        else if (first !== failure) first.addSuppressed(failure)
    }
    private fun sourceAllowed(original: VeilCryptoEngineOwner.FirstDeviceIntent, epoch: Long): Boolean = synchronized(gate) {
        !closed && !cancelled && !firstDeviceCancelRequested && !firstDeviceCancelAttempted &&
            publicationEpoch == epoch && firstDeviceOriginal === original
    }
    private fun cancelSourceOriginal(original: VeilCryptoEngineOwner.FirstDeviceIntent) {
        synchronized(gate) {
            if (sourceCancellationSelected) return
            sourceCancellationSelected = true
        }
        try { original.cancelSourceCurrent() }
        catch (failure: Throwable) { synchronized(gate) {
            if (sourceCancellationFailure == null) sourceCancellationFailure = failure
        } }
    }
    // Original login IO worker; no monitor across HTTP or permanent owner receipt.
    private fun sourceRoundTrip(original: VeilCryptoEngineOwner.FirstDeviceIntent, epoch: Long): String {
        synchronized(gate) {
            if (sourceAttempted) return sourceStatus ?: "SOURCE_UNKNOWN_RETAINED"
            sourceAttempted = true
            sourceStatus = "SOURCE_CHECK_PENDING"
        }
        var nativeAccountEntered = false
        var visible = "SOURCE_UNKNOWN_RETAINED"
        fun perform(): String {
            check(sourceAllowed(original, epoch))
            val prepared = checkNotNull(client.retainedPreparation(original))
            val selected = client.selectFirstDeviceSource(original, prepared) as? VeilSocialLoginClient.Outcome.SourceSelection
                ?: return "SOURCE_UNKNOWN_RETAINED"
            check(sourceAllowed(original, epoch))
            val started = original.beginSourceCurrent(prepared, selected.value)
            if (started.status != 71) return VeilFirstDeviceSourceWire.status(started.status)
            check(sourceAllowed(original, epoch))
            val nonce = started.nonceCopy()
            val fetched = try { client.fetchFirstDeviceSource(original, prepared, nonce) }
                finally { nonce.fill(0) }
            val evidence = (fetched as? VeilSocialLoginClient.Outcome.SourceEvidence)?.bytes
                ?: return "SOURCE_UNKNOWN_RETAINED"
            try {
                check(sourceAllowed(original, epoch))
                val sourceCode = original.acceptSourceCurrent(prepared, evidence)
                if (sourceCode != 72) return VeilFirstDeviceSourceWire.status(sourceCode)
                val borrowed = client.borrowAccountChannel(original, prepared)
                nativeAccountEntered = true
                val accountCode = original.prepareNativeAccountChannel(prepared, borrowed)
                if (accountCode == VeilNativeAccountChannel.INSTANCE_REQUIRED) return "ACCOUNT_SERVICE_INSTANCE_REQUIRED"
                if (accountCode != VeilNativeAccountChannel.FACTS_UNADMITTED) return "ACCOUNT_CHANNEL_UNKNOWN_RETAINED"
                check(sourceAllowed(original, epoch))
                // Exactly the original one refresh: no new request, nonce, grant or budget.
                val refreshNonce = started.nonceCopy()
                val refreshed = try { client.fetchFirstDeviceSource(original, prepared, refreshNonce) }
                    finally { refreshNonce.fill(0) }
                val pending = (refreshed as? VeilSocialLoginClient.Outcome.SourceEvidence)?.bytes
                    ?: return "SOURCE_UNKNOWN_RETAINED"
                try {
                    check(sourceAllowed(original, epoch))
                    val refreshedCode = original.acceptSourceCurrent(prepared, pending)
                    if (refreshedCode != 72) return VeilFirstDeviceSourceWire.status(refreshedCode)
                    // This normal call reaches A's same-owner signing path; 204 is still NOT success.
                    check(sourceAllowed(original, epoch))
                    val signedCode = original.prepareNativeAccountChannel(prepared, borrowed)
                    if (signedCode == VeilNativeAccountChannel.INSTANCE_REQUIRED) return "ACCOUNT_SERVICE_INSTANCE_REQUIRED"
                    if (signedCode != VeilNativeAccountChannel.FACTS_UNADMITTED) return "ACCOUNT_CHANNEL_UNKNOWN_RETAINED"
                    check(sourceAllowed(original, epoch))
                    val signatures = original.observeNativeSignatures(prepared, borrowed)
                        ?: return "SOURCE_UNKNOWN_RETAINED"
                    signatures.use {
                        check(sourceAllowed(original, epoch))
                        val outcome = it.finalizeOriginal(client, original, borrowed)
                        return consumeEnrollmentOutcome(original, epoch, outcome)
                    }
                } finally { pending.fill(0) }
            } finally { evidence.fill(0) }
        }
        try { visible = perform() }
        catch (failure: LinkageError) { retainSourceFailure(failure); visible = "SOURCE_NATIVE_INTERFACE_REQUIRED" }
        catch (failure: Throwable) { retainSourceFailure(failure); visible = "SOURCE_UNKNOWN_RETAINED" }
        finally {
            if (!sourceAllowed(original, epoch)) cancelSourceOriginal(original)
            if (nativeAccountEntered) {
                try { original.closeNativeSignatures() }
                catch (failure: Throwable) {
                    retainSourceFailure(failure)
                    visible = "SOURCE_UNKNOWN_RETAINED"
                }
            }
            // Publication follows cleanup, not a return expression evaluated before finally.
            synchronized(gate) {
                if (!sourceAllowed(original, epoch)) visible = "SOURCE_UNKNOWN_RETAINED"
                sourceStatus = visible
            }
        }
        return visible
    }

    private fun consumeEnrollmentOutcome(original: VeilCryptoEngineOwner.FirstDeviceIntent,
        epoch: Long, outcome: VeilSocialLoginClient.Outcome): String {
        if (outcome !is VeilSocialLoginClient.Outcome.EnrollmentRecords)
            return (outcome as? VeilSocialLoginClient.Outcome.ChallengeState)?.status ?: "ENROLLMENT_UNKNOWN_RETAINED"
        check(sourceAllowed(original, epoch) && outcome.original === original)
        val bytes = outcome.originalCopy()
        try {
            return consumeProductStartObservation(
                publicationCurrent = { sourceAllowed(original, epoch) },
                originalStart = { original.acceptCommittedDeviceRecords(outcome.prepared, bytes) }
            )
        } finally { bytes.fill(0) }
    }

    internal fun prepareFirstDeviceEnrollment(): CompletableFuture<Map<String, String>> = enrollmentOperation(false)
    internal fun observeFirstDeviceEnrollment(): CompletableFuture<Map<String, String>> = enrollmentOperation(true)

    private fun enrollmentOperation(observe: Boolean): CompletableFuture<Map<String, String>> = synchronized(gate) {
        fun result() = CompletableFuture.completedFuture(mapOf("status" to firstDeviceObservationLocked(), "deviceAuthorization" to "REQUIRED"))
        val original = firstDeviceOriginal ?: return@synchronized result()
        if (closed || cancelled || running || firstDeviceCancelRequested || firstDeviceCancelAttempted) return@synchronized result()
        if (observe && !enrollmentStarted) return@synchronized result()
        if (!observe && (enrollmentStarted || firstDeviceStatus != "CHALLENGE_ISSUED_UNVERIFIED")) return@synchronized result()
        original.requestForOriginal()
        enrollmentStarted = true // sticky across timeout/failure, never another prepare or intent
        // Observe returns the retained completed/UNKNOWN snapshot while a bounded
        // refresh runs. Masking it with PENDING here makes every UI poll hide
        // the previous completion. Only the first prepare selects PENDING.
        if (!observe) firstDeviceStatus = "ENROLLMENT_PENDING"
        val originalClient = client
        val coordinatorEpoch = publicationEpoch
        val clientEpoch = originalClient.challengePublicationEpoch()
        launchLocked(loginOperation = false) {
            var observed = "ENROLLMENT_UNKNOWN_RETAINED"
            try {
                val outcome = if (observe) originalClient.observeFirstDevice(original) else originalClient.prepareFirstDevice(original)
                observed = consumeEnrollmentOutcome(original, coordinatorEpoch, outcome)
                if (!observe && observed == "NATIVE_PROOF_AUTHORIZATION_REQUIRED")
                    observed = sourceRoundTrip(original, coordinatorEpoch)
                else if (observe && observed == "NATIVE_PROOF_AUTHORIZATION_REQUIRED")
                    observed = synchronized(gate) { sourceStatus ?: observed }
                observed
            } finally {
                publishFirstDevice(original, originalClient, coordinatorEpoch, clientEpoch, observed, false)
            }
        }
        result()
    }
    private var firstDeviceCancelRequested = false
    private var firstDeviceCancelAttempted = false
    private var publicationEpoch = 0L

    private fun firstDeviceObservationLocked(): String = when {
        !closed && !cancelled -> firstDeviceStatus
        firstDeviceOriginal == null -> "UNAVAILABLE"
        firstDeviceCancelAttempted -> "CHALLENGE_CANCEL_UNKNOWN_RETAINED"
        else -> "CHALLENGE_UNKNOWN_RETAINED"
    }

    private fun publishFirstDevice(original: VeilCryptoEngineOwner.FirstDeviceIntent,
        originalClient: VeilSocialLoginClient, coordinatorEpoch: Long, clientEpoch: Long,
        observed: String, cancellation: Boolean) = synchronized(gate) {
        val current = !closed && !cancelled && (cancellation || !firstDeviceCancelRequested) && publicationEpoch == coordinatorEpoch &&
            client === originalClient && firstDeviceOriginal === original &&
            originalClient.challengePublicationCurrent(original, clientEpoch)
        firstDeviceStatus = if (current) observed
            else if (cancellation) "CHALLENGE_CANCEL_UNKNOWN_RETAINED" else "CHALLENGE_UNKNOWN_RETAINED"
        // Never undo a cancel acknowledgment already performed by the client.
        // This fence controls observation only, not the original private custody.
    }

    internal fun firstDeviceEligibility(): String = synchronized(gate) {
        when {
            closed || cancelled -> "UNAVAILABLE"
            selected != VeilSocialLoginClient.Intent.A || !accountObserved -> "ORIGINAL_A_LOGIN_REQUIRED"
            running -> "OBSERVATION_PENDING"
            else -> "ORIGINAL_A_LOGIN_OBSERVED"
        }
    }
    internal fun issueFirstDeviceChallenge(original: VeilCryptoEngineOwner.FirstDeviceIntent): CompletableFuture<Map<String, String>> = synchronized(gate) {
        firstDeviceOriginal?.let {
            return@synchronized if (it === original) safe(firstDeviceObservationLocked()) else safe("ORIGINAL_INTENT_REQUIRED")
        }
        val eligibility = firstDeviceEligibility()
        if (eligibility != "ORIGINAL_A_LOGIN_OBSERVED") return@synchronized safe(eligibility)
        original.requestForOriginal() // no factory accepting a status or UI tuple
        firstDeviceOriginal = original
        firstDeviceStatus = "CHALLENGE_PENDING"
        val originalClient = client
        val originalEpoch = publicationEpoch
        val clientEpoch = originalClient.challengePublicationEpoch()
        launchLocked(loginOperation = false) {
            var observed = "CHALLENGE_UNKNOWN_RETAINED"
            try {
                val result = originalClient.issueFirstDevice(original)
                if (result is VeilSocialLoginClient.Outcome.ChallengeState) observed = result.status
            } finally { publishFirstDevice(original, originalClient, originalEpoch, clientEpoch, observed, false) }
            ""
        }
        safe(firstDeviceObservationLocked())
    }
    internal fun observeFirstDeviceChallenge(): CompletableFuture<Map<String, String>> = synchronized(gate) {
        safe(firstDeviceObservationLocked()) // an observation never restarts physical IO
    }
    internal fun cancelFirstDeviceChallenge(): CompletableFuture<Map<String, String>> = synchronized(gate) {
        if (closed) return@synchronized safe(firstDeviceObservationLocked())
        if (firstDeviceOriginal == null) return@synchronized safe("CHALLENGE_REQUIRED")
        firstDeviceCancelRequested = true
        if (!running) scheduleFirstDeviceCancelLocked()
        safe(firstDeviceObservationLocked())
    }
    private fun scheduleFirstDeviceCancelLocked() {
        if (firstDeviceCancelAttempted || closed) return
        val original = firstDeviceOriginal ?: return
        firstDeviceCancelAttempted = true
        firstDeviceStatus = "CHALLENGE_CANCEL_PENDING"
        val originalClient = client
        val originalEpoch = publicationEpoch
        val clientEpoch = originalClient.challengePublicationEpoch()
        launchLocked(loginOperation = false) {
            var observed = "CHALLENGE_CANCEL_UNKNOWN_RETAINED"
            try {
                cancelSourceOriginal(original)
                val result = originalClient.cancelFirstDevice(original)
                if (result is VeilSocialLoginClient.Outcome.ChallengeState) observed = result.status
            } finally { publishFirstDevice(original, originalClient, originalEpoch, clientEpoch, observed, true) }
            ""
        }
    }

    fun begin(selected: String, activity: Activity): CompletableFuture<Map<String, String>> = beginOwned(selected, activity)
    fun observeOriginal(): CompletableFuture<Map<String, String>> = synchronized(gate) { snapshot() }

    private fun beginOwned(value: String, activity: Activity?): CompletableFuture<Map<String, String>> = synchronized(gate) {
        if (closed) return@synchronized safe("CLOSED")
        val wanted = VeilSocialLoginClient.Intent.entries.firstOrNull { it.name == value } ?: return@synchronized safe("REFUSED")
        if (selected != null) return@synchronized if (selected == wanted) snapshot() else safe("REFUSED")
        selected = wanted
        launchLocked {
            if (!browser.reserve(activity, ::acceptCallback)) return@launchLocked "VERIFIED_CALLBACK_REQUIRED"
            if (!allowed()) { browser.retire(); return@launchLocked "CANCELLED" }
            when (val result = client.start(wanted)) {
                is VeilSocialLoginClient.Outcome.Authorization ->
                    if (allowed() && browser.open(activity, result.browser)) "AUTHORIZATION_OPENED" else if (allowed()) "REVIEW_REQUIRED" else "CANCELLED"
                else -> project(result, VeilLoginFailureDiagnostic.Operation.START)
            }
        }
        snapshot()
    }

    /** Local fence first. Remote cancellation is attempted only when physical IO
     * is free; a busy cancel remains local and never advertises remote revoke. */
    fun cancelOriginal(): CompletableFuture<Map<String, String>> {
        synchronized(gate) {
            if (closed) return safe("CLOSED")
            if (!cancelled) publicationEpoch++
            cancelled = true; status = "CANCELLED"; pendingCallback = null
        }
        client.cancelLocal()
        browser.retire()
        synchronized(gate) {
            if (!running && selected != null) launchLocked {
                firstDeviceOriginal?.let { cancelSourceOriginal(it) }
                project(client.cancelRemote(), VeilLoginFailureDiagnostic.Operation.CANCEL); "CANCELLED"
            }
            return safe("CANCELLED")
        }
    }

    override fun close() {
        synchronized(gate) {
            if (closeAttempted) {
                check(closeActionsFinished) { "VEIL_LOGIN_CLOSE_PENDING" }
                closeFailure?.let { throw it }
                return
            }
            closeAttempted = true
            if (!closed) publicationEpoch++
            closed = true; cancelled = true; status = "CLOSED"; pendingCallback = null
        }
        fun retain(failure: Throwable) = synchronized(gate) {
            val original = closeFailure
            if (original == null) closeFailure = failure
            else if (original !== failure) original.addSuppressed(failure)
        }
        // Each physical close is selected only once. A failing browser or HTTP
        // cancellation must not skip the remaining local cleanup, nor make a
        // later close retry an uncertain original effect.
        try {
            try { browser.retire() } catch (failure: Throwable) { retain(failure) }
            try { client.close() } catch (failure: Throwable) { retain(failure) }
            // Running/queued original work keeps its executor until its own
            // finally exits. Never interrupt it or release Native custody here.
            synchronized(gate) {
                if (!running) {
                    // The original finally may have selected cancellation and
                    // shut down this executor while browser/client close ran.
                    // Selection is not success: retain its original failure.
                    if (!sourceCancellationSelected) {
                        firstDeviceOriginal?.let { original ->
                            try { worker.execute { cancelSourceOriginal(original) } }
                            catch (failure: Throwable) {
                                if (sourceCancellationFailure == null) sourceCancellationFailure = failure
                                retain(failure)
                            }
                        }
                    }
                    try { worker.shutdown() } catch (failure: Throwable) { retain(failure) }
                }
            }
        } finally {
            synchronized(gate) { closeActionsFinished = true }
        }
        synchronized(gate) { closeFailure?.let { throw it } }
    }

    private fun allowed() = synchronized(gate) { !closed && !cancelled }

    private fun acceptCallback(validate: () -> Pair<VeilSocialLoginClient.BrowserHandoff, String>?) {
        synchronized(gate) {
            if (closed || cancelled || callbackSeen || selected == null || pendingCallback != null) return
            // At most one original callback retained during browser-launch exit.
            pendingCallback = validate
            if (!running) scheduleCallbackLocked()
        }
    }

    private fun scheduleCallbackLocked() {
        val validate = pendingCallback ?: return
        pendingCallback = null
        launchLocked {
            if (!allowed()) return@launchLocked "CANCELLED"
            val original = validate() ?: return@launchLocked "REVIEW_REQUIRED"
            synchronized(gate) {
                if (closed || cancelled || callbackSeen) return@launchLocked "CANCELLED"
                callbackSeen = true
                pendingCallback = null
            }
            val bound = client.bindCallback(original.first, original.second)
            if (bound !== VeilSocialLoginClient.Outcome.CallbackBound) return@launchLocked project(bound, VeilLoginFailureDiagnostic.Operation.CALLBACK)
            if (!allowed()) return@launchLocked "CANCELLED"
            val redeemed = client.redeem()
            if (redeemed !is VeilSocialLoginClient.Outcome.State || redeemed.phase != "FAMILY_RESPONSE_CAPTURED_UNVERIFIED") return@launchLocked project(redeemed, VeilLoginFailureDiagnostic.Operation.REDEEM)
            if (!allowed()) return@launchLocked "CANCELLED"
            project(client.observeAccount(), VeilLoginFailureDiagnostic.Operation.ACCOUNT_OBSERVE)
        }
    }

    private fun launchLocked(loginOperation: Boolean = true, action: () -> String) {
        if (running) return
        running = true; startedAt = System.nanoTime()
        if (loginOperation) status = "OBSERVATION_PENDING"
        val task = FutureTask<Unit> {
            var next = "REVIEW_REQUIRED"
            try { next = action() } catch (failure: Exception) { if (loginOperation) failures.exception(failure); next = "REVIEW_REQUIRED" }
            finally {
                val retiredOriginal = synchronized(gate) {
                    status = when { closed -> "CLOSED"; cancelled -> "CANCELLED"; loginOperation -> next; else -> status }
                    running = false
                    if (!closed && firstDeviceCancelRequested && !firstDeviceCancelAttempted) scheduleFirstDeviceCancelLocked()
                    else if (!closed && !cancelled && pendingCallback != null) scheduleCallbackLocked()
                    if (closed || cancelled) firstDeviceOriginal else null
                }
                retiredOriginal?.let { cancelSourceOriginal(it) }
                synchronized(gate) { if (closed) worker.shutdown() }
            }
        }
        originalFuture = task // private actual task, never exposed/cancelled by JS
        try { worker.execute(task) }
        catch (failure: java.util.concurrent.RejectedExecutionException) {
            if (loginOperation) failures.exception(failure)
            running = false
            if (loginOperation) status = if (closed) "CLOSED" else "REVIEW_REQUIRED"
            else firstDeviceStatus = "CHALLENGE_UNKNOWN_RETAINED"
        }
    }

    private fun snapshot(): CompletableFuture<Map<String, String>> {
        val visible = when {
            closed -> "CLOSED"
            cancelled -> "CANCELLED"
            running -> "OBSERVATION_PENDING" // elapsed observation is NOT IO exit
            status == "AUTHORIZATION_OPENED" -> "AWAIT_CALLBACK"
            else -> status
        }
        return safe(visible)
    }

    private fun project(result: VeilSocialLoginClient.Outcome, operation: VeilLoginFailureDiagnostic.Operation): String {
        if (result is VeilSocialLoginClient.Outcome.Refused) failures.refused(result, operation)
        return when (result) {
        is VeilSocialLoginClient.Outcome.AccountObserved -> {
            synchronized(gate) { accountObserved = true }
            "ACCOUNT_OBSERVED"
        }
        is VeilSocialLoginClient.Outcome.Refused -> when (result.reason) {
            VeilSocialLoginClient.Failure.BUSY -> "BUSY"
            VeilSocialLoginClient.Failure.CLOSED -> "CLOSED"
            VeilSocialLoginClient.Failure.CANCELLED -> "CANCELLED"
            else -> "REVIEW_REQUIRED"
        }
        is VeilSocialLoginClient.Outcome.State -> when (result.phase) {
            "AWAIT_CALLBACK" -> "AWAIT_CALLBACK"
            "CANCELLED" -> "CANCELLED"
            else -> "REVIEW_REQUIRED"
        }
        VeilSocialLoginClient.Outcome.LocallyCancelledRemoteNotAsserted -> "CANCELLED"
        else -> "REVIEW_REQUIRED"
    }

    }

    override fun toString() = "VeilSocialLoginCoordinator[private original]"
    companion object {
        /** Publication fence only, never a Native approval or rollback. A late
         * close keeps the already-consumed original at its real owner. */
        internal fun consumeProductStartObservation(
            publicationCurrent: () -> Boolean,
            originalStart: () -> VeilCryptoEngineOwner.ProductStartObservation
        ): String {
            check(publicationCurrent()) { "VEIL_LOGIN_PUBLICATION_NOT_CURRENT" }
            val result = originalStart()
            check(publicationCurrent()) { "VEIL_LOGIN_PUBLICATION_NOT_CURRENT" }
            return when (result) {
                VeilCryptoEngineOwner.ProductStartObservation.NATIVE_SOURCE_REQUIRED ->
                    "ENROLLMENT_ACCEPTED_PRODUCT_SOURCE_REQUIRED"
                VeilCryptoEngineOwner.ProductStartObservation.ATTACHED_OBSERVED ->
                    "NATIVE_PRODUCT_ATTACHED_OBSERVED"
            }
        }
        private fun safe(status: String): CompletableFuture<Map<String, String>> =
            CompletableFuture.completedFuture(Collections.unmodifiableMap(linkedMapOf("status" to status, "deviceAuthorization" to "REQUIRED")))
        internal fun publicFixture(client: VeilSocialLoginClient, browser: VeilLoginBrowserAccess) = VeilSocialLoginCoordinator(client, browser)
    }
    internal fun beginPublicControl(selected: String): CompletableFuture<Map<String, String>> = beginOwned(selected, null)
}
