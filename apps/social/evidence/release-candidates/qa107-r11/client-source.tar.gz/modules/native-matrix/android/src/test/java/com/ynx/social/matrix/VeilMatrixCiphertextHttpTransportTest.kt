package com.ynx.social.matrix

import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import okio.BufferedSource
import okio.ForwardingSource
import okio.buffer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.UUID

/** PUBLIC HTTP interceptors: zero network/accounts/private signing. Real
 * transport implementation is exercised; this is not courier or chat acceptance. */
class VeilMatrixCiphertextHttpTransportTest {
    private val clearCipher = "PUBLIC opaque ciphertext".toByteArray()
    private val id = UUID.fromString("00000000-0000-4000-8000-000000000001")
    private fun output(): VeilNativeMessageOutput {
        val logical = ByteBuffer.allocate(16).putLong(id.mostSignificantBits).putLong(id.leastSignificantBits).array()
        val wire = ByteBuffer.allocate(28 + clearCipher.size).put("YNXO".toByteArray())
            .put(1).put(1).put(2).put(0).put(logical).putInt(clearCipher.size).put(clearCipher).array()
        return VeilNativeMessageOutput.decode(wire, wire.size.toLong(), logical, 1)
    }
    private class Guard : VeilMatrixCiphertextHttpTransport.Guard {
        val saved = mutableListOf<VeilMatrixCiphertextHttpTransport.Snapshot>()
        var stopped = false
        var persistenceError: Throwable? = null
        override fun checkCurrent() { check(!stopped) { "PUBLIC source stopped" } }
        override fun persistOriginal(snapshot: VeilMatrixCiphertextHttpTransport.Snapshot) {
            saved.add(snapshot)
            persistenceError?.let { throw it }
        }
    }
    private fun client(block: (Request) -> Response) = OkHttpClient.Builder()
        .followRedirects(false).followSslRedirects(false).retryOnConnectionFailure(false)
        .addInterceptor(Interceptor { chain -> block(chain.request()) }).build()
    private fun response(request: Request, value: String, code: Int = 200): Response =
        Response.Builder().request(request).protocol(Protocol.HTTP_1_1).code(code).message("PUBLIC")
            .body(value.toResponseBody("application/json".toMediaType())).build()
    private fun content() = JSONObject().put("version", 2)
        .put("suite", VeilMatrixCiphertextHttpTransport.SUITE).put("ciphertext_type", 2)
        .put("sender_message_id", id.toString()).put("ciphertext", JSONObject()
            .put("url", "mxc://qa.invalid/opaque").put("sha256", digest(clearCipher)).put("size", clearCipher.size))
    private fun event(content: JSONObject = content(), sender: String = "@alice:qa.invalid") =
        JSONObject().put("type", VeilMatrixCiphertextHttpTransport.EVENT).put("event_id", "$" + "PUBLIC")
            .put("room_id", "!room:qa.invalid").put("sender", sender).put("content", content).toString()
    private fun transport(http: OkHttpClient) = VeilMatrixCiphertextHttpTransport.control(
        "https://qa.invalid/", "PUBLIC-test-token".toCharArray(), http)
    private fun capture(t: VeilMatrixCiphertextHttpTransport, guard: Guard) = output().use {
        t.capture(it, "!room:qa.invalid", "@alice:qa.invalid", "PUBLIC-transaction", guard)
    }
    private fun failure(body: () -> Unit): Throwable {
        try { body() } catch (value: Throwable) { return value }
        throw AssertionError("expected rejection")
    }
    private fun digest(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes)
        .joinToString("") { "%02x".format(it.toInt() and 255) }

    @Test fun originalCiphertextUsesUploadPutAndExactEventReadback() {
        val guard = Guard()
        val requests = mutableListOf<Request>()
        var sentContent: JSONObject? = null
        val t = transport(client { r ->
            requests.add(r)
            assertEquals("qa.invalid", r.url.host)
            assertEquals("Bearer PUBLIC-test-token", r.header("Authorization"))
            when (r.method) {
                "POST" -> {
                    assertEquals(VeilMatrixCiphertextHttpTransport.Phase.UPLOAD_ATTEMPTED, guard.saved.last().phase)
                    val body = checkNotNull(r.body); assertTrue(body.isOneShot())
                    val out = Buffer(); body.writeTo(out); assertArrayEquals(clearCipher, out.readByteArray())
                    response(r, """{"content_uri":"mxc://qa.invalid/opaque"}""")
                }
                "PUT" -> {
                    assertEquals(VeilMatrixCiphertextHttpTransport.Phase.EVENT_ATTEMPTED, guard.saved.last().phase)
                    assertEquals("PUBLIC-transaction", r.url.pathSegments.last())
                    val out = Buffer(); checkNotNull(r.body).writeTo(out)
                    sentContent = JSONObject(out.readUtf8())
                    assertFalse(checkNotNull(sentContent).has("body"))
                    response(r, """{"event_id":"${'$'}PUBLIC"}""")
                }
                else -> response(r, event(checkNotNull(sentContent)))
            }
        })
        val original = capture(t, guard)
        assertEquals(VeilMatrixCiphertextHttpTransport.Phase.OBSERVED, original.send().phase)
        assertEquals(listOf("POST", "PUT", "GET"), requests.map { it.method })
        assertTrue(t.hasRetainedWork())
        var verified = 0
        original.retireAfterNativeCommit { verified++ }
        assertEquals(1, verified); assertFalse(t.hasRetainedWork()); t.close()
    }
    @Test fun unknownUploadDoesNotRepeatPostOrCreateNewOriginal() {
        var calls = 0
        val dropped = IOException("PUBLIC lost response")
        val t = transport(client { calls++; throw dropped })
        val guard = Guard(); val original = capture(t, guard)
        val err = failure { original.send() }
        assertTrue(err is VeilMatrixCiphertextHttpTransport.Failure)
        assertSame(dropped, original.retainedFailure())
        failure { original.send() }
        failure { capture(t, guard) }
        failure { t.close() }
        assertEquals(1, calls)
        assertEquals(VeilMatrixCiphertextHttpTransport.Phase.UNKNOWN, original.snapshot().phase)
    }
    @Test fun journalFailureStopsBeforeNetworkAndKeepsCause() {
        var calls = 0
        val t = transport(client { calls++; response(it, "{}") })
        val expected = IOException("PUBLIC durable marker failed")
        val guard = Guard().also { it.persistenceError = expected }
        val original = capture(t, guard)
        failure { original.send() }
        assertEquals(0, calls); assertSame(expected, original.retainedFailure()); assertTrue(t.hasRetainedWork())
    }
    @Test fun cancellationDuringResponseCloseCannotPublishMediaOrSendEvent() {
        val guard = Guard()
        var calls = 0
        val t = transport(client { r ->
            calls++
            val bytes = """{"content_uri":"mxc://qa.invalid/opaque"}""".toByteArray()
            val input = object : ForwardingSource(Buffer().write(bytes)) {
                override fun close() { super.close(); guard.stopped = true }
            }.buffer()
            val body = object : ResponseBody() {
                override fun contentType() = "application/json".toMediaType()
                override fun contentLength() = bytes.size.toLong()
                override fun source(): BufferedSource = input
            }
            Response.Builder().request(r).protocol(Protocol.HTTP_1_1).code(200).message("PUBLIC").body(body).build()
        })
        val original = capture(t, guard)
        failure { original.send() }
        assertEquals(1, calls); assertNull(original.snapshot().media)
        assertEquals(VeilMatrixCiphertextHttpTransport.Phase.UNKNOWN, original.snapshot().phase)
    }
    @Test fun uncertainEventReadbackOnlyGetsAndNeverRepeatsPut() {
        val methods = mutableListOf<String>()
        var firstGet = true
        val t = transport(client { r ->
            methods.add(r.method)
            when(r.method) {
                "POST" -> response(r, """{"content_uri":"mxc://qa.invalid/opaque"}""")
                "PUT" -> response(r, """{"event_id":"${'$'}PUBLIC"}""")
                else -> {
                    if (firstGet) { firstGet = false; throw IOException("PUBLIC lost readback") }
                    response(r, event())
                }
            }
        })
        val original = capture(t, Guard())
        failure { original.send() }
        assertEquals(VeilMatrixCiphertextHttpTransport.Phase.OBSERVED, original.readback().phase)
        assertEquals(listOf("POST","PUT","GET","GET"), methods)
        assertNotNull(original.retainedFailure()) // Historical first cause retained.
    }
    @Test fun mismatchedEventSenderIsNotObserved() {
        val t = transport(client { r ->
            when(r.method) {
                "POST" -> response(r, """{"content_uri":"mxc://qa.invalid/opaque"}""")
                "PUT" -> response(r, """{"event_id":"${'$'}PUBLIC"}""")
                else -> response(r, event(sender="@mallory:qa.invalid"))
            }
        })
        val original = capture(t, Guard()); failure { original.send() }
        assertEquals(VeilMatrixCiphertextHttpTransport.Phase.UNKNOWN, original.snapshot().phase)
        failure { original.retireAfterNativeCommit {} }; assertTrue(t.hasRetainedWork())
    }
    @Test fun remoteMediaUsesOwnHomeserverAndMustMatchHash() {
        val paths = mutableListOf<List<String>>()
        val t = transport(client { r ->
            assertEquals("qa.invalid", r.url.host)
            assertNull(r.url.queryParameter("access_token"))
            paths.add(r.url.pathSegments)
            Response.Builder().request(r).protocol(Protocol.HTTP_1_1).code(200).message("PUBLIC")
                .body(clearCipher.toResponseBody("application/octet-stream".toMediaType())).build()
        })
        val content = VeilMatrixCiphertextHttpTransport.Content(id.toString(),2,"mxc://remote.invalid/opaque",digest(clearCipher),clearCipher.size)
        assertArrayEquals(clearCipher, t.download(content,Guard()))
        assertEquals(listOf("_matrix","client","v1","media","download","remote.invalid","opaque"), paths.single())
        failure { t.download(content.copy(sha256="0".repeat(64)),Guard()) }
    }
    @Test fun oversizedJsonAndRedirectNeverBecomeUploadSuccess() {
        for (code in listOf(200, 307)) {
            var calls=0
            val t=transport(client { r ->
                calls++
                response(r,if(code==200)" ".repeat(8193) else """{"content_uri":"mxc://qa.invalid/opaque"}""",code)
            })
            val original=capture(t,Guard());failure { original.send() }
            assertEquals(1,calls);assertEquals(VeilMatrixCiphertextHttpTransport.Phase.UNKNOWN,original.snapshot().phase)
        }
    }
    @Test fun strictExistingEnvelopeDoesNotAcceptNumericStringsOrTrailingData() {
        for (value in listOf(
            content().put("ciphertext_type","2").toString(),
            content().also { it.getJSONObject("ciphertext").put("size",clearCipher.size.toString()) }.toString(),
            content().toString()+"{}"
        )) failure { VeilMatrixCiphertextHttpTransport.parseContent(value) }
    }
    @Test fun transportObservationDoesNotBypassNativeCommitOrSecureConfig() {
        failure { VeilMatrixCiphertextHttpTransport.create("http://qa.invalid/","PUBLIC".toCharArray()) }
        failure { VeilMatrixCiphertextHttpTransport.create("https://qa.invalid/?token=x","PUBLIC".toCharArray()) }
        failure { VeilMatrixCiphertextHttpTransport.create("https://qa.invalid/","bad\nvalue".toCharArray()) }
        val t=transport(client { r ->
            when(r.method) {
                "POST"->response(r,"""{"content_uri":"mxc://qa.invalid/opaque"}""")
                "PUT"->response(r,"""{"event_id":"${'$'}PUBLIC"}""")
                else->response(r,event())
            }
        })
        val original=capture(t,Guard());original.send()
        val refused=IllegalStateException("PUBLIC native commit refused")
        assertSame(refused,failure { original.retireAfterNativeCommit { throw refused } })
        assertTrue(t.hasRetainedWork())
    }
}


/** New /sync controls only; never an actual Matrix server or authorization. */
class VeilMatrixCiphertextSyncTest {
    private class Guard : VeilMatrixCiphertextHttpTransport.Guard {
        var live = true
        override fun checkCurrent() { check(live) { "PUBLIC sync cancelled" } }
        override fun persistOriginal(snapshot: VeilMatrixCiphertextHttpTransport.Snapshot) =
            throw AssertionError("read-only sync cannot commit an operation")
    }
    private fun transport(block: (Request) -> Response) = VeilMatrixCiphertextHttpTransport.control(
        "https://qa.invalid/", "PUBLIC-sync-token".toCharArray(), OkHttpClient.Builder()
            .followRedirects(false).followSslRedirects(false).retryOnConnectionFailure(false)
            .addInterceptor { block(it.request()) }.build())
    private fun response(r: Request, body: JSONObject) = Response.Builder().request(r)
        .protocol(Protocol.HTTP_1_1).code(200).message("PUBLIC")
        .body(body.toString().toResponseBody("application/json".toMediaType())).build()
    @Test fun oneSyncUsesOriginalCursorAuthorizationAndExactBoundedFilter() {
        var calls = 0
        val t = transport { r ->
            calls++
            assertEquals("GET", r.method); assertEquals("/_matrix/client/v3/sync", r.url.encodedPath)
            assertEquals("Bearer PUBLIC-sync-token", r.header("Authorization"))
            assertEquals("PUBLIC/since+token", r.url.queryParameter("since"))
            assertEquals("0", r.url.queryParameter("timeout")); assertEquals("offline", r.url.queryParameter("set_presence"))
            assertNull(r.url.queryParameter("access_token"))
            val filter = JSONObject(checkNotNull(r.url.queryParameter("filter"))).getJSONObject("room")
            assertEquals("!room:qa.invalid", filter.getJSONArray("rooms").getString(0))
            assertEquals(32, filter.getJSONObject("timeline").getInt("limit"))
            assertEquals(VeilMatrixCiphertextHttpTransport.EVENT, filter.getJSONObject("timeline").getJSONArray("types").getString(0))
            response(r, JSONObject().put("next_batch", "PUBLIC/next+token").put("rooms", JSONObject()))
        }
        val result = t.sync("PUBLIC/since+token", listOf("!room:qa.invalid"), Guard())
        assertEquals("PUBLIC/next+token", result.next); assertEquals("PUBLIC/since+token", result.since)
        assertTrue(result.events.isEmpty()); assertEquals(1, calls)
    }
    @Test fun limitedGapCarriesOriginalBoundariesWithoutAcceptedEvents() {
        val t = transport { r -> response(r, JSONObject().put("next_batch", "PUBLIC-next")
            .put("rooms", JSONObject().put("join", JSONObject().put("!room:qa.invalid",
                JSONObject().put("timeline", JSONObject().put("limited", true).put("prev_batch", "PUBLIC-prev")
                    .put("events", org.json.JSONArray())))))) }
        try { t.sync("PUBLIC-since", listOf("!room:qa.invalid"), Guard()); fail("gap accepted") }
        catch (gap: VeilMatrixCiphertextHttpTransport.SyncGap) {
            assertEquals("PUBLIC-since", gap.since); assertEquals("PUBLIC-next", gap.next)
            assertEquals("PUBLIC-prev", gap.previous); assertEquals("!room:qa.invalid", gap.room)
        }
    }
    @Test fun outOfScopeRoomAndOversizedTimelineAreRejected() {
        for (unknown in listOf(true, false)) {
            val t = transport { r ->
                val events = org.json.JSONArray()
                if (!unknown) repeat(33) { events.put(JSONObject().put("type", "PUBLIC-irrelevant")) }
                response(r, JSONObject().put("next_batch", "PUBLIC-next").put("rooms",
                    JSONObject().put("join", JSONObject().put(if (unknown) "!unknown:qa.invalid" else "!room:qa.invalid",
                        JSONObject().put("timeline", JSONObject().put("limited", false).put("events", events))))))
            }
            try { t.sync(null, listOf("!room:qa.invalid"), Guard()); fail("scope/bound bypassed") }
            catch (_: IllegalArgumentException) {}
        }
    }
    @Test fun cancelledCurrentCannotReturnAParsedBatch() {
        val guard = Guard()
        val t = transport { r -> guard.live = false; response(r, JSONObject().put("next_batch", "PUBLIC-next")) }
        try { t.sync(null, listOf("!room:qa.invalid"), guard); fail("cancelled batch returned") }
        catch (error: IllegalStateException) { assertEquals("PUBLIC sync cancelled", error.message) }
    }
    @Test fun authenticatedHistoryUsesExactBackwardCursorAndDoesNotExhaustEmptyPage() {
        var calls = 0
        var expectedHash: String? = null
        val t = transport { r ->
            calls++
            assertEquals("GET", r.method)
            assertEquals("b", r.url.queryParameter("dir"))
            assertEquals("32", r.url.queryParameter("limit"))
            assertEquals("PUBLIC-from", r.url.queryParameter("from"))
            assertNull(r.url.queryParameter("to"))
            assertEquals("Bearer PUBLIC-sync-token", r.header("Authorization"))
            val body = JSONObject().put("start", "PUBLIC-from").put("end", "PUBLIC-middle")
                .put("chunk", org.json.JSONArray())
            expectedHash = java.security.MessageDigest.getInstance("SHA-256")
                .digest(body.toString().toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it.toInt() and 255) }
            response(r, body)
        }
        val page = t.history("!room:qa.invalid", "PUBLIC-from", Guard())
        assertTrue(page.events.isEmpty()); assertEquals("PUBLIC-middle", page.end); assertEquals(1, calls)
        assertEquals(expectedHash, page.responseSha256)
    }
    @Test fun historyMissingEndIsExplicitAndDoesNotAttestAnOriginalBoundary() {
        val t = transport { r ->
            assertEquals("PUBLIC-from", r.url.queryParameter("from")); assertEquals("b", r.url.queryParameter("dir"))
            response(r, JSONObject().put("start", "PUBLIC-from").put("chunk", org.json.JSONArray()))
        }
        val page = t.history("!room:qa.invalid", "PUBLIC-from", Guard())
        assertNull(page.end); assertTrue(page.events.isEmpty())
    }
    @Test fun historyWrongStartOrNonadvancingEndIsRejected() {
        for (wrong in listOf(true, false)) {
            val t = transport { r -> response(r, JSONObject().put("start", if (wrong) "PUBLIC-other" else "PUBLIC-from")
                .put("end", "PUBLIC-from").put("chunk", org.json.JSONArray())) }
            try { t.history("!room:qa.invalid", "PUBLIC-from", Guard()); fail("wrong history accepted") }
            catch (_: IllegalArgumentException) { assertTrue(wrong) }
            catch (_: IllegalStateException) { assertFalse(wrong) }
        }
    }

}

