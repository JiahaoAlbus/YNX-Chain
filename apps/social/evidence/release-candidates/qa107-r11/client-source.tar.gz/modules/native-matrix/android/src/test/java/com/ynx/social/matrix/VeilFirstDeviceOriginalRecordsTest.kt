package com.ynx.social.matrix

import org.junit.Assert.*
import org.junit.Test

/** Public shape tests, not real signatures, Native admission or device authorization. */
class VeilFirstDeviceOriginalRecordsTest {
    private fun transport(envelope: String = "AQ", prefix: String = "[]") =
        "{\"version\":1,\"finalOriginal\":\"$envelope\",\"currentOriginal\":\"Ag\"," +
            "\"currentPredecessors\":$prefix,\"independentTerminalOriginal\":\"Aw\",\"checkpointOriginal\":\"BA\"}"
    private fun encoded(text: String) = VeilFirstDeviceEnrollmentWire.b64(text.toByteArray(Charsets.UTF_8))
    private fun decode(text: String) = VeilFirstDeviceEnrollmentWire.deviceRecordBytes(encoded(text))
    private fun rejected(text: String) {
        try { decode(text); fail("invalid public transport accepted") }
        catch (_: IllegalArgumentException) {}
        catch (_: org.json.JSONException) {}
    }
    @Test fun originalBytesStayExactAndPrivateToCaller() {
        val text = transport()
        val first = decode(text)
        assertArrayEquals(text.toByteArray(Charsets.UTF_8), first)
        first[0] = 0
        assertArrayEquals(text.toByteArray(Charsets.UTF_8), decode(text))
    }
    @Test fun rejectsAliasesUnknownFieldsDuplicateAndNoncanonicalWrapper() {
        val raw = transport()
        for (text in listOf(" $raw", "$raw\n", raw.replace("\"version\":1", "\"version\":1,\"version\":1"),
            raw.replace("\"version\":1", "\"version\":1.0"), raw.replace("finalOriginal", "final_original"),
            raw.replace("\"checkpointOriginal\":\"BA\"", "\"checkpointOriginal\":\"BA\",\"extra\":0")))
            rejected(text)
    }
    @Test fun rejectsWrongEncodingAndInvalidPredecessors() {
        for (envelope in listOf("", "AQ==", "AR", "+/8")) rejected(transport(envelope))
        rejected(transport(prefix = "null"))
        rejected(transport(prefix = "[1]"))
        rejected(transport(prefix = List(256) { "\"AQ\"" }.joinToString(",", "[", "]")))
        assertTrue(decode(transport(prefix = List(255) { "\"AQ\"" }.joinToString(",", "[", "]"))).isNotEmpty())
    }
    @Test fun exactEnvelopeAndHTTPBoundsSupportTheActualNativeABI() {
        val legal = VeilFirstDeviceEnrollmentWire.b64(ByteArray(65536))
        assertTrue(decode(transport(legal)).isNotEmpty())
        rejected(transport(VeilFirstDeviceEnrollmentWire.b64(ByteArray(65537))))
        val four = transport(legal).replace("\"Ag\"", "\"$legal\"")
            .replace("\"Aw\"", "\"$legal\"").replace("\"BA\"", "\"$legal\"")
        assertTrue(decode(four).size <= VeilFirstDeviceEnrollmentWire.DEVICE_RECORDS_LIMIT)
        assertTrue(encoded(four).length + 8192 <= VeilFirstDeviceEnrollmentWire.RESPONSE_LIMIT)
        try {
            VeilFirstDeviceEnrollmentWire.deviceRecordBytes(
                VeilFirstDeviceEnrollmentWire.b64(ByteArray(VeilFirstDeviceEnrollmentWire.DEVICE_RECORDS_LIMIT + 1)))
            fail("outer bound bypassed")
        } catch (_: IllegalArgumentException) {}
    }
}
