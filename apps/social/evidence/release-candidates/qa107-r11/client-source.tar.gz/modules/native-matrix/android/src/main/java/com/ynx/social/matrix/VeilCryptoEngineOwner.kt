package com.ynx.social.matrix

import android.content.Context
import com.ynx.social.veil.VeilNativeProductControllerBridge
import java.util.ArrayDeque
import java.util.IdentityHashMap
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ExecutionException
import java.util.concurrent.TimeUnit

/** Normal internal Android owning lifecycle, NOT native admission or an Expo API.
 * The fixed ABI2 native controller is loaded/opened on this same worker.
 * Its current root refusal is NOT admission or message readiness. No synthetic
 * lease, fallback actor or UI-controlled native entry is supplied here.
 */
internal class VeilCryptoEngineOwner private constructor(private val context: Context) {
    internal enum class State { STARTING, LOCAL_PENDING, RECOVERY_PENDING, CLOSING, DRAIN_REQUIRED, CLOSE_UNRESOLVED, CLOSED, INIT_FAILED }
    internal enum class NativeBoundary { REQUIRED }
    /** Result observation only. Neither value constructs device authority. */
    internal enum class ProductStartObservation { NATIVE_SOURCE_REQUIRED, ATTACHED_OBSERVED }
    internal enum class CloseDisposition { CLOSED_LOCAL_ONLY, PENDING_RECONCILIATION_REQUIRED }
    internal data class Snapshot(val state: State, val queued: Int, val originalTickets: Int,
        val reopenedRows: Int, val pendingStatus: VeilDeviceEnrollmentPendingStore.Status?,
        val failureRetained: Boolean, val nativeBoundary: NativeBoundary = NativeBoundary.REQUIRED,
        val localGenesisAttempted: Boolean = false, val localGenesisStatus: Int? = null)
    internal class Receipt<T> internal constructor(private val owner: VeilCryptoEngineOwner,
        private val future: CompletableFuture<T>) {
        fun done(): Boolean = future.isDone
        // Timeout/interruption does NOT cancel work or resolve its ownership.
        fun await(timeoutMillis: Long): T {
            check(Thread.currentThread() !== owner.worker) { "VEIL_OWNER_WAIT_ON_WORKER" }
            require(timeoutMillis in 1..30000)
            try { return future.get(timeoutMillis, TimeUnit.MILLISECONDS) }
            catch (failure: ExecutionException) { throw failure.cause ?: failure }
            catch (failure: InterruptedException) { Thread.currentThread().interrupt(); throw failure }
        }
    }
    private class Work(val action: (PendingScope) -> Unit, val result: CompletableFuture<Unit>,
        val ownedPublicBytes: ByteArray? = null)
    private val gate = Object()
    private val queue = ArrayDeque<Work>()
    private val tickets = IdentityHashMap<VeilDeviceEnrollmentCoordinator.Ticket, Boolean>()
    private val initResult = CompletableFuture<Unit>()
    private var closeResult: CompletableFuture<CloseDisposition>? = null
    private var closeRequested = false
    private var state = State.STARTING
    private var firstFailure: Throwable? = null
    private var pendingStatus: VeilDeviceEnrollmentPendingStore.Status? = null
    private var reopenedRows = 0
    private var ticketCount = 0
    private var lostPending = false
    private var untrackedTicket: VeilDeviceEnrollmentCoordinator.Ticket? = null
    private var coordinator: VeilDeviceEnrollmentCoordinator? = null
    private var activeScope: PendingScope? = null
    private var nativeCustody: VeilNativeWorkerCustody? = null
    private var productPorts: VeilNativeProductPorts? = null
    private var productMessaging: VeilSocialMessagingCoordinator? = null
    private var nativeMessageBusiness: VeilNativeMessageBusiness? = null
    private var nativeMessageBindingAttempt: VeilNativeMessageBusiness.Binding? = null
    private var nativeMessageAttached = false
    private var nativeMessageAttachFailure: Throwable? = null
    private var nativeMatrixBinding: VeilMatrixProductBinding? = null
    // Worker-owned originals survive timeout, callback failure and UNKNOWN.
    // Neither a local pair nor its numeric status grants device authority.
    private var localGenesisInput: VeilLocalGenesisInput? = null
    private var localGenesisCommand: VeilOwnKeyPrivateCommand? = null
    private var localGenesisJournalBinding: VeilLocalGenesisJournalBinding? = null
    private var localGenesisStatus: Int? = null
    private var retainedRecoveryInput: VeilLocalRecoveryInput? = null
    private var recoveryReadAttempted = false
    private var recoveryReadStatus: Int? = null
    private var authenticatedPublicProjection: ByteArray? = null
    private var firstDeviceIntent: FirstDeviceIntent? = null
    private var coldRecoveryLease: VeilOwnKeyColdRecoveryLease? = null

    /** Process-local original. Only this owner can supply its actual retained
     * projection/input; neither a status DTO nor a public byte tuple can do so.
     * Public material is linkable. No first-trust or YPA1 evidence is created. */
    internal inner class FirstDeviceIntent internal constructor(
        private val original: VeilLocalRecoveryInput,
        projection: ByteArray
    ) {
        private val request: VeilFirstDeviceChallengeWire.Request
        private var canceled = false
        init {
            check(Thread.currentThread() === worker && activeScope?.live == true)
            check(original === retainedRecoveryInput && projection === authenticatedPublicProjection)
            check(!closeRequested && !lostPending && firstDeviceIntent == null)
            original.revalidateOriginal(checkNotNull(localGenesisCommand))
            request = VeilFirstDeviceChallengeWire.Request.fromProjection(projection)
        }
        internal fun requestForOriginal(): VeilFirstDeviceChallengeWire.Request = synchronized(gate) {
            check(firstDeviceIntent === this && original === retainedRecoveryInput && !canceled)
            check(!closeRequested && !lostPending && state !in setOf(State.CLOSING, State.CLOSED, State.CLOSE_UNRESOLVED, State.INIT_FAILED))
            request
        }
        private var sourcePrepared: VeilFirstDeviceEnrollmentWire.Prepared? = null
        private var sourceBeginStatus: Int? = null
        private var sourceCancelAttempted = false
        private var accountChannelBorrow: VeilSocialLoginClient.AccountChannelBorrow? = null
        private var signatureObservationAttempted = false
        private var signatureCleanupStatus: Int? = null
        private fun <T> onOriginalWorker(ownedPublicBytes: ByteArray? = null, body: () -> T): T {
            var value: T? = null
            val receipt = dispatchOwnedPublic(ownedPublicBytes) {
                check(firstDeviceIntent === this && retainedRecoveryInput === original)
                original.revalidateOriginal(checkNotNull(localGenesisCommand))
                value = body()
            }
            while (true) {
                try { receipt.await(30000); break }
                catch (_: java.util.concurrent.TimeoutException) { /* same receipt, not another dispatch */ }
            }
            @Suppress("UNCHECKED_CAST")
            return value as T
        }
        internal fun beginSourceCurrent(prepared: VeilFirstDeviceEnrollmentWire.Prepared,
            selection: VeilFirstDeviceSourceWire.Selection): VeilFirstDeviceSourceWire.Start = onOriginalWorker {
            requestForOriginal()
            check(authenticatedPublicProjection != null && sourcePrepared == null)
            check(prepared.original.operation == request.operation)
            sourcePrepared = prepared
            val nonce = ByteArray(32)
            val scope = selection.scopeCopy(); val head = selection.headCopy(); val catalog = selection.catalogCopy()
            val issuer = prepared.issuerMessageCopy(); val target = prepared.targetMessageCopy()
            try {
                val code = checkNotNull(localGenesisCommand).beginSourceCurrent(original, scope, head, catalog, issuer, target, nonce)
                sourceBeginStatus = code
                VeilFirstDeviceSourceWire.Start(code, if (code == 71) nonce else null)
            } finally { nonce.fill(0); scope.fill(0); head.fill(0); catalog.fill(0); issuer.fill(0); target.fill(0) }
        }
        internal fun acceptSourceCurrent(prepared: VeilFirstDeviceEnrollmentWire.Prepared, evidence: ByteArray): Int {
            // IO may stop waiting without cancelling the queued receipt. The
            // worker must not borrow an array the IO finally block will wipe.
            val retained = evidence.copyOf()
            return onOriginalWorker(retained) {
                requestForOriginal()
                check(sourcePrepared === prepared && sourceBeginStatus == 71 && !sourceCancelAttempted)
                checkNotNull(localGenesisCommand).acceptSourceCurrent(original, retained)
            }
        }
        internal fun prepareNativeAccountChannel(prepared: VeilFirstDeviceEnrollmentWire.Prepared,
            borrow: VeilSocialLoginClient.AccountChannelBorrow): Int = onOriginalWorker {
            requestForOriginal()
            check(sourcePrepared === prepared && sourceBeginStatus == 71 && !sourceCancelAttempted)
            check(accountChannelBorrow == null || accountChannelBorrow === borrow)
            accountChannelBorrow = borrow // retained before crossing the native boundary
            VeilNativeAccountChannel.prepare(context, original, borrow)
        }
        internal fun observeNativeSignatures(prepared: VeilFirstDeviceEnrollmentWire.Prepared,
            borrow: VeilSocialLoginClient.AccountChannelBorrow): VeilNativeAccountChannel.ObservedSignatures? = onOriginalWorker {
            requestForOriginal()
            check(sourcePrepared === prepared && sourceBeginStatus == 71 && !sourceCancelAttempted)
            check(accountChannelBorrow === borrow && !signatureObservationAttempted)
            signatureObservationAttempted = true // null/partial/late failure never re-observes or signs
            val observed = VeilNativeAccountChannel.observe(context, original, borrow, prepared)
            try {
                requestForOriginal()
                borrow.requireSourceRefresh()
                observed
            } catch (primary: Throwable) { observed?.close(); throw primary }
        }

        internal fun acceptCommittedDeviceRecords(prepared: VeilFirstDeviceEnrollmentWire.Prepared,
            records: ByteArray): ProductStartObservation {
            val retained = records.copyOf()
            return onOriginalWorker(retained) {
                requestForOriginal()
                check(sourcePrepared === prepared && sourceBeginStatus == 71 && !sourceCancelAttempted)
                check(signatureObservationAttempted && accountChannelBorrow != null)
                // The same original worker owns native acquire/current and any
                // partial failure. HTTP records and result observations do not
                // supply the separate genuine source/store/courier owner.
                val scope = checkNotNull(activeScope)
                scope.acceptDeviceRecords(retained, false)
                requestForOriginal()
                val result = scope.startOriginalAcceptedProduct()
                requestForOriginal()
                result
            }
        }

        /** Cleanup deliberately uses immutable identity, not the expired authorization predicate.
         * It never clears the retained request, journal, attempts or UNKNOWN. */
        internal fun closeNativeSignatures(): Int? {
            var code: Int? = null
            val receipt = dispatchOwnedPublic(null) {
                check(firstDeviceIntent === this && retainedRecoveryInput === original)
                check(Thread.currentThread() === worker)
                val borrowed = accountChannelBorrow
                if (borrowed != null) {
                    code = VeilNativeAccountChannel.closeSignatures(context, original, borrowed)
                    signatureCleanupStatus = code
                    check(code == VeilNativeAccountChannel.SIGNATURE_RAM_CLOSED) {
                        "FIRST_DEVICE_SIGNATURE_CLEANUP_UNRESOLVED"
                    }
                }
            }
            while (true) {
                try { receipt.await(30000); break }
                catch (_: java.util.concurrent.TimeoutException) { /* same cleanup receipt, not replay */ }
            }
            return code
        }

        internal fun cancelSourceCurrent() = onOriginalWorker {
            if (sourcePrepared != null && !sourceCancelAttempted) {
                sourceCancelAttempted = true
                checkNotNull(localGenesisCommand).cancelSourceCurrent(original)
            }
            Unit
        }
        internal fun acknowledgeCancellation() = synchronized(gate) {
            check(firstDeviceIntent === this)
            canceled = true
        }
        internal fun unresolved(): Boolean = synchronized(gate) { !canceled }
        override fun toString() = "FirstDeviceIntent[owner retained; unverified]"
    }
    private val worker = Thread({ runWorker() }, "YNX-Social-CryptoEngine-Owner").apply {
        // Process death is not reconciliation. The pending journal survives;
        // no native private owner has been admitted by this component.
        isDaemon = true
    }

    fun initialized(): Receipt<Unit> = Receipt(this, initResult)
    fun read(): Snapshot = synchronized(gate) {
        Snapshot(state, queue.size, ticketCount, reopenedRows, pendingStatus, firstFailure != null,
            localGenesisAttempted = localGenesisInput != null, localGenesisStatus = localGenesisStatus)
    }
    fun dispatch(action: (PendingScope) -> Unit): Receipt<Unit> = dispatchOwnedPublic(null, action)
    private fun dispatchOwnedPublic(ownedPublicBytes: ByteArray?, action: (PendingScope) -> Unit): Receipt<Unit> {
        var accepted = false
        try {
            check(Thread.currentThread() !== worker) { "VEIL_OWNER_REENTRANT_DISPATCH" }
            val result = CompletableFuture<Unit>()
            synchronized(gate) {
                check(state !in setOf(State.CLOSING, State.CLOSED, State.INIT_FAILED, State.CLOSE_UNRESOLVED) && !closeRequested) {
                    "VEIL_OWNER_NOT_ACCEPTING_WORK"
                }
                check(queue.size < MAX_QUEUED) { "VEIL_OWNER_QUEUE_FULL" }
                queue.addLast(Work(action, result, ownedPublicBytes))
                accepted = true
                gate.notifyAll()
            }
            return Receipt(this, result)
        } catch (primary: Throwable) {
            if (!accepted) ownedPublicBytes?.fill(0)
            throw primary
        }
    }
    fun close(): Receipt<CloseDisposition> {
        // Reject BEFORE changing queue/close flags; a callback cannot destroy
        // its enclosing coordinator or synchronously close another scope.
        check(Thread.currentThread() !== worker) { "VEIL_OWNER_CLOSE_INSIDE_WORKER" }
        synchronized(gate) {
            val old = closeResult
            if (old != null && (!old.isDone || state in setOf(State.CLOSED, State.INIT_FAILED, State.CLOSE_UNRESOLVED))) {
                return Receipt(this, old)
            }
            val result = CompletableFuture<CloseDisposition>()
            closeResult = result; closeRequested = true; gate.notifyAll()
            return Receipt(this, result)
        }
    }
    private fun retainFailure(failure: Throwable): Throwable = synchronized(gate) {
        val first = firstFailure
        if (first == null) firstFailure = failure
        else if (first !== failure) try { first.addSuppressed(failure) } catch (_: Throwable) { }
        firstFailure!!
    }
    private fun refresh() {
        val status = coordinator!!.durableStatus()
        synchronized(gate) { pendingStatus = status; ticketCount = tickets.size + if (untrackedTicket == null) 0 else 1 }
    }
    private fun runWorker() {
        var localOpened = false
        try {
            coordinator = VeilDeviceEnrollmentCoordinator.openAppPrivate(context)
            coordinator!!.withReopenedRecords { rows -> reopenedRows = rows.size }
            refresh()
            localOpened = true
            // Store the custody object BEFORE any native/linkage operation.
            // A failure must retain its exact primary and this local owner.
            nativeCustody = VeilNativeWorkerCustody()
            nativeCustody!!.open()
            synchronized(gate) { state = if (reopenedRows > 0 || pendingStatus == VeilDeviceEnrollmentPendingStore.Status.UNKNOWN)
                State.RECOVERY_PENDING else State.LOCAL_PENDING }
            initResult.complete(Unit)
        } catch (primary: Throwable) {
            retainFailure(primary)
            var cleanupFailed = localOpened
            if (!localOpened) try { coordinator?.close() }
            catch (secondary: Throwable) { cleanupFailed = true; retainFailure(secondary) }
            synchronized(gate) {
                state = if (localOpened) State.RECOVERY_PENDING
                    else if (cleanupFailed) State.CLOSE_UNRESOLVED else State.INIT_FAILED
                while (queue.isNotEmpty()) queue.removeFirst().result.completeExceptionally(primary)
                val result = closeResult ?: CompletableFuture<CloseDisposition>().also { closeResult = it }
                result.completeExceptionally(primary); closeRequested = false
            }
            initResult.completeExceptionally(primary)
            if (!cleanupFailed) { coordinator = null; return }
            // Retain failed cleanup owner on THIS worker; no forced release.
        }
        while (true) {
            val work = synchronized(gate) {
                while (queue.isEmpty() && !closeRequested) {
                    try { gate.wait() } catch (failure: InterruptedException) {
                        retainFailure(failure) // not permission to drop ownership
                    }
                }
                if (queue.isNotEmpty()) queue.removeFirst() else {
                    // Atomically select the close barrier while admission is
                    // still closed. Keep it closed through actual release.
                    state = State.CLOSING
                    null
                }
            }
            if (work != null) {
                executeWork(work)
            } else {
                val result = synchronized(gate) { closeResult!! }
                try { refresh() }
                catch (failure: Throwable) {
                    val primary = retainFailure(failure)
                    synchronized(gate) {
                        state = State.DRAIN_REQUIRED; closeRequested = false
                        result.completeExceptionally(primary)
                    }
                    // Status failure is not release permission. Keep this exact
                    // worker/coordinator and permit only explicit recovery work;
                    // a later close rechecks the actual status, not a cached OK.
                    continue
                }
                val originalWorkRetained = try {
                    nativeMessageAttachFailure != null ||
                        nativeMatrixBinding?.hasRetainedWork() == true ||
                        nativeMessageBusiness?.hasRetainedWork() == true ||
                        productMessaging?.hasRetainedWork() == true ||
                        productPorts?.hasRetainedMessages() == true ||
                        coldRecoveryLease?.isRetired() == false ||
                        coordinator?.hasColdJournalBorrow() == true ||
                        firstDeviceIntent?.unresolved() == true || tickets.isNotEmpty() ||
                        untrackedTicket != null || lostPending || reopenedRows > 0 ||
                        pendingStatus == VeilDeviceEnrollmentPendingStore.Status.UNKNOWN
                } catch (failure: Throwable) {
                    val primary = retainFailure(failure)
                    synchronized(gate) {
                        state = State.DRAIN_REQUIRED
                        closeRequested = false
                        result.completeExceptionally(primary)
                    }
                    // A failed ownership observation is not a cleanup grant.
                    // Keep this worker and every original; finish the receipt
                    // rather than letting an exception terminate the thread.
                    continue
                }
                if (originalWorkRetained) {
                    synchronized(gate) {
                        state = State.DRAIN_REQUIRED; closeRequested = false
                        result.complete(CloseDisposition.PENDING_RECONCILIATION_REQUIRED)
                    }
                    continue // same worker/coordinator retained; exact original cleanup can be queued
                }
                try {
                    // A failed command construction is not evidence that native
                    // effects are absent. Retain the original worker and input.
                    if (localGenesisInput != null && localGenesisCommand == null) {
                        synchronized(gate) {
                            state = State.DRAIN_REQUIRED; closeRequested = false
                            result.complete(CloseDisposition.PENDING_RECONCILIATION_REQUIRED)
                        }
                        continue
                    }
                    localGenesisJournalBinding?.closeAdmission()
                    localGenesisCommand?.closeAdmission()
                    productPorts?.stopWatching()
                    productPorts?.closeMessageSessionForClose()
                    productPorts?.releaseAcceptedDeviceForClose()
                    if (nativeCustody?.releaseForThreadExit() != true) {
                        synchronized(gate) {
                            state = State.DRAIN_REQUIRED; closeRequested = false
                            result.complete(CloseDisposition.PENDING_RECONCILIATION_REQUIRED)
                        }
                        continue
                    }
                    coordinator!!.close()
                    coordinator = null
                    synchronized(gate) {
                        state = State.CLOSED; closeRequested = false
                        pendingStatus = VeilDeviceEnrollmentPendingStore.Status.CLOSED
                        result.complete(CloseDisposition.CLOSED_LOCAL_ONLY)
                    }
                    return
                } catch (failure: Throwable) {
                    val primary = retainFailure(failure)
                    synchronized(gate) {
                        state = State.CLOSE_UNRESOLVED; closeRequested = false
                        result.completeExceptionally(primary)
                    }
                    // No release retry/clearing fiction if the current close port
                    // cannot establish resolution; keep reference and worker.
                }
            }
        }
    }
    private fun executeWork(work: Work) {
        var scope: PendingScope? = null
        var failure: Throwable? = null
        try {
            scope = PendingScope(this)
            activeScope = scope
            work.action(scope)
        } catch (primary: Throwable) {
            failure = primary
            retainFailure(primary)
            synchronized(gate) { state = State.RECOVERY_PENDING }
        } finally {
            work.ownedPublicBytes?.fill(0)
            scope?.live = false
            activeScope = null
        }
        // Publish the original receipt only after owned-copy/scope cleanup.
        if (failure == null) work.result.complete(Unit)
        else work.result.completeExceptionally(failure)
    }
    internal class PendingScope internal constructor(private val owner: VeilCryptoEngineOwner) {
        internal var live = true
        private fun checked(): VeilDeviceEnrollmentCoordinator {
            check(Thread.currentThread() === owner.worker && live && owner.activeScope === this) { "VEIL_OWNER_SCOPE_INACTIVE_OR_WRONG_THREAD" }
            return owner.coordinator!!
        }
fun readProductInventory(watch: Boolean): Map<String, Any> {
    checked()
    val ports = owner.productPorts ?: VeilNativeProductPorts().also { owner.productPorts = it }
    return ports.read(watch)
}
/** Authenticated producer transport only, on this original live worker.
 * The caller must supply original signed records, never a login status DTO. */
fun acceptDeviceRecords(originalRecords: ByteArray, restore: Boolean) {
    checked()
    synchronized(owner.gate) {
        check(!owner.closeRequested && !owner.lostPending)
        val ports = owner.productPorts ?: VeilNativeProductPorts().also { owner.productPorts = it }
        ports.acceptDeviceRecords(originalRecords, restore)
    }
}
/** Normal product calls share the actual worker queue and close fence. */
fun processProductRequest(request: VeilSocialMessagingCoordinator.Request): Map<String, Any?> {
    checked()
    synchronized(owner.gate) { check(!owner.closeRequested && !owner.lostPending) }
    val product = owner.productMessaging ?: VeilSocialMessagingCoordinator().also { owner.productMessaging = it }
    return product.process(request)
}
/** Genuine producer handoff only; there is no JS or observation-to-grant path. */
fun attachMessageProduct(original: VeilSocialMessagingCoordinator.Business) {
    checked()
    synchronized(owner.gate) {
        check(!owner.closeRequested && !owner.lostPending)
        val product = owner.productMessaging ?: VeilSocialMessagingCoordinator().also { owner.productMessaging = it }
        product.attach(original)
    }
}
/** Original Native producer handoff. No JS setter or default source. */
fun attachNativeMessageProduct(original: VeilNativeMessageBusiness.Binding) {
    checked()
    synchronized(owner.gate) {
        check(!owner.closeRequested && !owner.lostPending)
        owner.nativeMessageAttachFailure?.let { throw it }
        owner.nativeMessageBindingAttempt?.let {
            check(it === original) { "VEIL_PRODUCT_ORIGINAL_BINDING_RETAINED" }
            check(owner.nativeMessageAttached && owner.nativeMessageBusiness?.uses(original) == true) {
                "VEIL_PRODUCT_ORIGINAL_ATTACHMENT_UNRESOLVED" }
            return
        }
        // Capture the original before constructor/current/attach callbacks.
        // Failed construction or publication is not permission to substitute
        // another business or retry the original installation.
        owner.nativeMessageBindingAttempt = original
        try {
            val ports = checkNotNull(owner.productPorts)
            val business = VeilNativeMessageBusiness.owned(ports, original)
            owner.nativeMessageBusiness = business
            attachMessageProduct(business)
            owner.nativeMessageAttached = true
        } catch (failure: Throwable) {
            owner.nativeMessageAttachFailure = failure
            throw failure
        }
    }
}
/** Normal enrollment consumption uses this actual factory result on the same
 * worker. A must first supply genuine original resources through the existing
 * attachNativeMatrixProduct path; no empty/default installer is constructed. */
fun startOriginalAcceptedProduct(): ProductStartObservation {
    checked()
    synchronized(owner.gate) {
        check(!owner.closeRequested && !owner.lostPending)
        owner.nativeMessageAttachFailure?.let { throw it }
        checkNotNull(owner.productPorts).requireAcceptedDeviceCurrent()
        val original = owner.nativeMatrixBinding ?: return ProductStartObservation.NATIVE_SOURCE_REQUIRED
        attachNativeMessageProduct(original)
        check(owner.nativeMessageAttached)
        checkNotNull(owner.nativeMessageBusiness).requireStartupProjection()
        checkNotNull(owner.productPorts).requireAcceptedDeviceCurrent()
        return ProductStartObservation.ATTACHED_OBSERVED
    }
}
/** Same normal worker installation from actual supplied Native custody/store.
 * This does not create a lease, enroll keys or infer authority from login/UI. */
fun attachNativeMatrixProduct(source: VeilMatrixProductBinding.NativeSource,
                              store: VeilNativeStore,
                              courier: VeilMatrixCiphertextHttpTransport) {
    checked()
    synchronized(owner.gate) {
        check(!owner.closeRequested && !owner.lostPending)
        val existing = owner.nativeMatrixBinding
        if (existing != null) {
            check(existing.uses(source, store, courier)) { "VEIL_PRODUCT_ORIGINAL_BINDING_RETAINED" }
            attachNativeMessageProduct(existing)
            return
        }
        checkNotNull(owner.productPorts).requireAcceptedDeviceCurrent()
        source.checkCurrent()
        val binding = VeilMatrixProductBinding.owned(source, store, courier)
        owner.nativeMatrixBinding = binding
        attachNativeMessageProduct(binding)
    }
}
/** Authenticated normal sync caller, never an Expo event-to-authority setter. */
fun receiveMatrixCiphertext(conversationId: String, eventId: String, sender: String, contentJson: String) {
    checked()
    synchronized(owner.gate) { check(!owner.closeRequested && !owner.lostPending) }
    val binding = checkNotNull(owner.nativeMatrixBinding)
    var original: VeilNativeMessageBusiness.Message? = null
    binding.incoming(conversationId, eventId, sender,
        VeilMatrixCiphertextHttpTransport.parseContent(contentJson)) {
        check(original == null); original = it
    }
    receiveNativeMessage(checkNotNull(original))
}
fun receiveNativeMessage(original: VeilNativeMessageBusiness.Message) {
    checked()
    synchronized(owner.gate) { check(!owner.closeRequested && !owner.lostPending) }
    checkNotNull(owner.nativeMessageBusiness).receive(original)
}
fun stopProductInvalidation() {
    checked()
    owner.productPorts?.stopWatching()
}
fun supportsDurableLocalGenesis(): Boolean {

            checked()
            return try { VeilNativeProductControllerBridge.nativeLocalGenesisBindingAbiVersion() == 1 }
            catch (_: UnsatisfiedLinkError) { false }
        }
        fun prepareLocalGenesis(): VeilLocalGenesisProducer.Original {
            val c = checked()
            synchronized(owner.gate) {
                check(owner.state == State.LOCAL_PENDING && !owner.closeRequested && !owner.lostPending)
                check(owner.localGenesisInput == null && owner.localGenesisCommand == null)
            }
            check(supportsDurableLocalGenesis()) { "VEIL_LOCAL_GENESIS_BINDING_ABI_REQUIRED" }
            val original = c.prepareLocalGenesis("installation-local-v1")
            check(c.getOriginalLocalGenesis("installation-local-v1") === original)
            c.revalidateLocalGenesis(original)
            owner.refresh()
            return original
        }
        fun revalidateLocalGenesis(original: VeilLocalGenesisProducer.Original) {
            checked().revalidateLocalGenesis(original)
        }
        fun beginPreparedLocalGenesis(original: VeilLocalGenesisProducer.Original): Int {
            val c = checked()
            // Serialize final owner admission and close with the write-ahead
            // handoff. No await or UI callback between mark, install and JNI.
            synchronized(owner.gate) {
                check(owner.state == State.LOCAL_PENDING && !owner.closeRequested && !owner.lostPending)
                check(owner.localGenesisInput == null && owner.localGenesisCommand == null)
                check(supportsDurableLocalGenesis()) { "VEIL_LOCAL_GENESIS_BINDING_ABI_REQUIRED" }
                c.revalidateLocalGenesis(original)
                val input = c.markLocalGenesisBeforeSubmission(original)
                // Retain before callback installation can fail. SUBMITTED and
                // the original input must survive every subsequent exception.
                owner.localGenesisInput = input
                owner.localGenesisJournalBinding = VeilLocalGenesisJournalBinding.install(input) { ids ->
                    check(checked() === c)
                    c.bindLocalGenesisNativeIds(original, ids)
                }
                val command = VeilOwnKeyPrivateCommand(owner.context)
                owner.localGenesisCommand = command
                val status = command.beginLocalGenesis(input)
                owner.localGenesisStatus = status
                owner.refresh()
                return status
            }
        }
        // Internal producer port only: construct the original input on this
        // same worker from the product's retained local intent. No Expo/JS
        // factory accepts aliases, generations, account claims or auth windows.
        fun beginLocalGenesis(original: VeilLocalGenesisInput): Int {
            checked()
            synchronized(owner.gate) {
                check(owner.state == State.LOCAL_PENDING && !owner.closeRequested && !owner.lostPending) {
                    "VEIL_OWNER_LOCAL_GENESIS_NOT_ADMITTED"
                }
                check(owner.localGenesisInput == null && owner.localGenesisCommand == null) {
                    "VEIL_OWNER_ORIGINAL_LOCAL_GENESIS_RETAINED"
                }
                owner.localGenesisInput = original
            }
            val command = VeilOwnKeyPrivateCommand(owner.context)
            owner.localGenesisCommand = command
            val status = command.beginLocalGenesis(original)
            synchronized(owner.gate) { owner.localGenesisStatus = status }
            return status
        }
        fun readLocalGenesisStatus(): Int {
            checked()
            val command = owner.localGenesisCommand ?: error("VEIL_OWNER_LOCAL_GENESIS_NOT_REQUESTED")
            synchronized(owner.gate) { owner.localGenesisStatus = null }
            val status = command.readLocalStatus()
            synchronized(owner.gate) { owner.localGenesisStatus = status }
            return status
        }
        /** Read-only metadata capture on the original failed command. No JNI,
         * new Original, journal transition, native IDs or recovery authority. */
        /** Same-worker inspection: absence is not a recovery error or authority.
         * Only an untouched fresh journal can return null; all retained cases
         * still use the original command and existing refusal/UNKNOWN path. */
        fun beginColdRecovery(): Int {
            val c = checked()
            var initialize = false
            val original = synchronized(owner.gate) {
                check(!owner.closeRequested && !owner.lostPending)
                check(owner.localGenesisInput == null && owner.localGenesisCommand == null)
                var lease = owner.coldRecoveryLease
                if (lease == null) {
                    val borrow = c.retainedColdJournalBorrow() ?: c.acquireColdJournalBorrow()
                    lease = VeilOwnKeyColdRecoveryLease(owner.context, borrow)
                    owner.coldRecoveryLease = lease
                    initialize = true
                }
                lease
            }
            if (initialize) original.initializeOriginal()
            return original.begin()
        }
        fun observeColdRecovery(): Int { checked(); return checkNotNull(owner.coldRecoveryLease).observe() }
        fun reconcileColdRecovery(): Int { checked(); return checkNotNull(owner.coldRecoveryLease).reconcile() }
        fun dischargeColdRecovery(): Int { checked(); return checkNotNull(owner.coldRecoveryLease).discharge() }
        fun cleanupColdRecovery(): Int { checked(); return checkNotNull(owner.coldRecoveryLease).cleanup() }
        fun releaseColdRecovery(): Int { checked(); return checkNotNull(owner.coldRecoveryLease).release() }
        fun retainedColdJournalBorrow(): VeilDeviceEnrollmentPendingStore.ColdBorrow? = checked().retainedColdJournalBorrow()
        fun acquireColdJournalBorrow(): VeilDeviceEnrollmentPendingStore.ColdBorrow {
            val c = checked()
            synchronized(owner.gate) {
                check(!owner.closeRequested && !owner.lostPending)
                check(owner.localGenesisInput == null && owner.localGenesisCommand == null)
                return c.acquireColdJournalBorrow()
            }
        }
        fun inspectExistingLocalRecovery(): Int? {
            val c = checked()
            synchronized(owner.gate) {
                check(!owner.closeRequested && !owner.lostPending)
                val original = c.localGenesisStatus()
                if (owner.state == State.LOCAL_PENDING && owner.firstFailure == null &&
                    owner.localGenesisInput == null && owner.localGenesisCommand == null &&
                    owner.retainedRecoveryInput == null && !owner.recoveryReadAttempted &&
                    owner.ticketCount == 0 && owner.reopenedRows == 0 &&
                    c.durableStatus() == VeilDeviceEnrollmentPendingStore.Status.FRESH &&
                    original.record == null && original.disposition == "NO_LOCAL_INTENT") return null
            }
            val input = prepareExistingLocalRecovery()
            return readPreparedExistingLocalRecovery(input)
        }
        fun prepareExistingLocalRecovery(): VeilLocalRecoveryInput {
            val c = checked()
            synchronized(owner.gate) {
                check(!owner.closeRequested && !owner.lostPending)
                val command = owner.localGenesisCommand ?: error("VEIL_RECOVERY_ORIGINAL_COMMAND_REQUIRED")
                owner.retainedRecoveryInput?.let {
                    it.revalidateOriginal(command)
                    return it
                }
                val observed = c.localGenesisStatus()
                check(observed.disposition == "SUBMITTED_UNVERIFIED_RESTORE_REQUIRED")
                val record = checkNotNull(observed.record)
                check(record.phase == VeilLocalGenesisProducer.Phase.SUBMITTED)
                val ids = checkNotNull(record.nativeIds).copyBytes()
                val association = record.association()
                try {
                    val captured = command.captureExistingRecoveryInput(record.alias, record.storageGeneration, association, ids) {
                        check(Thread.currentThread() === owner.worker && owner.activeScope?.live == true)
                        check(owner.coordinator === c && owner.localGenesisCommand === command &&
                            !owner.closeRequested && !owner.lostPending)
                        val current = c.localGenesisStatus()
                        check(current.record === record && current.disposition == "SUBMITTED_UNVERIFIED_RESTORE_REQUIRED")
                    }
                    owner.retainedRecoveryInput = captured
                    return captured
                } finally { association.fill(0); ids.fill(0) }
            }
        }
        /** Same-worker readback of the retained original operation only.
         * A returned ciphertext-held status does not authorize a device or
         * replace the original genesis failure with a successful state. */
        /** R62 local public material, not device authority or UI readiness.
         * Keep the original worker/command and serialize against owner close.
         */
        fun authenticatePreparedExistingLocalRecovery(original: VeilLocalRecoveryInput) {
            checked()
            synchronized(owner.gate) {
                check(!owner.closeRequested && !owner.lostPending)
                val command = owner.localGenesisCommand
                    ?: error("VEIL_RECOVERY_ORIGINAL_COMMAND_REQUIRED")
                check(owner.retainedRecoveryInput === original && owner.recoveryReadStatus == 61)
                check(owner.authenticatedPublicProjection == null)
                original.revalidateOriginal(command)
                val projection = command.authenticateExistingLocalPair(original)
                try {
                    check(projection.size == 2657 && projection[0] == 5.toByte())
                    original.revalidateOriginal(command)
                    // Owned public bytes only. No JS projection or grant conversion.
                    owner.authenticatedPublicProjection = projection
                } catch (failure: Throwable) {
                    projection.fill(0)
                    throw failure
                }
            }
        }

        fun readPreparedExistingLocalRecovery(original: VeilLocalRecoveryInput): Int {
            val c = checked()
            synchronized(owner.gate) {
                check(!owner.closeRequested && !owner.lostPending)
                check(owner.coordinator === c)
                val command = owner.localGenesisCommand
                    ?: error("VEIL_RECOVERY_ORIGINAL_COMMAND_REQUIRED")
                original.revalidateOriginal(command)
                check(owner.retainedRecoveryInput === original)
                if (owner.recoveryReadAttempted) return checkNotNull(owner.recoveryReadStatus) {
                    "VEIL_RECOVERY_ORIGINAL_READ_UNRESOLVED"
                }
                owner.recoveryReadAttempted = true
                val status = command.readExistingLocalPair(original)
                owner.recoveryReadStatus = status
                return status
            }
        }

        fun originalFirstDeviceIntent(): FirstDeviceIntent {
            checked()
            synchronized(owner.gate) {
                check(!owner.closeRequested && !owner.lostPending)
                val original = checkNotNull(owner.retainedRecoveryInput)
                original.revalidateOriginal(checkNotNull(owner.localGenesisCommand))
                owner.firstDeviceIntent?.let { it.requestForOriginal(); return it }
                val projection = checkNotNull(owner.authenticatedPublicProjection)
                return owner.FirstDeviceIntent(original, projection).also { owner.firstDeviceIntent = it }
            }
        }

        /** Internal same-worker normal-message calls, never raw Expo selectors
         * or a constructor for accepted contact/session authority. */
        fun openMessageSession(originalRecords: ByteArray) {
            checked()
            synchronized(owner.gate) {
                check(!owner.closeRequested && !owner.lostPending)
                checkNotNull(owner.productPorts).openMessageSession(originalRecords)
            }
        }
        fun acquireMessageOperation(expectedEpoch: Long, originalFrame: ByteArray): VeilNativeProductPorts.Operation {
            checked()
            return checkNotNull(owner.productPorts).acquire(expectedEpoch, originalFrame)
        }
        fun executeMessageOperation(original: VeilNativeProductPorts.Operation, expectedEpoch: Long,
            action: Int, frame: ByteArray): Long {
            checked()
            return checkNotNull(owner.productPorts).execute(original, expectedEpoch, action, frame)
        }
        fun withOriginalMessageOutput(original: VeilNativeProductPorts.Operation, expectedEpoch: Long,
            consume: (VeilNativeMessageOutput) -> Unit) {
            checked()
            checkNotNull(owner.productPorts).withOriginalOutput(original, expectedEpoch, consume)
        }
        fun retireOriginalMessageOutput(original: VeilNativeProductPorts.Operation, expectedEpoch: Long) {
            checked()
            checkNotNull(owner.productPorts).retireOriginalOutput(original, expectedEpoch)
        }

        fun request(association: VeilDeviceEnrollmentCoordinator.Association, approval: VeilDeviceApproval,
            ttlMillis: Long = VeilDeviceEnrollmentCoordinator.MAX_LIFETIME_MILLIS): VeilDeviceEnrollmentCoordinator.Ticket? {
            val c = checked()
            synchronized(owner.gate) { check(owner.state == State.LOCAL_PENDING && !owner.lostPending) { "VEIL_OWNER_RECOVERY_ONLY" } }
            try {
                val ticket = c.request(association, approval, ttlMillis) ?: return null
                owner.untrackedTicket = ticket
                owner.tickets[ticket] = true; owner.untrackedTicket = null
                owner.refresh(); return ticket
            } catch (failure: Throwable) { owner.lostPending = true; throw failure }
        }
        fun inspect(ticket: VeilDeviceEnrollmentCoordinator.Ticket) = checked().inspect(ticket)
        fun reject(ticket: VeilDeviceEnrollmentCoordinator.Ticket) = checked().reject(ticket)
        fun recoverInterrupted(ticket: VeilDeviceEnrollmentCoordinator.Ticket) = checked().recoverInterrupted(ticket)
        fun expire(): Int = checked().expire()
        fun takeOutcome(ticket: VeilDeviceEnrollmentCoordinator.Ticket): VeilDeviceEnrollmentCoordinator.Outcome {
            val outcome = checked().takeOutcome(ticket)
            if (outcome.decision == VeilDeviceEnrollmentCoordinator.Decision.TERMINAL) owner.tickets.remove(ticket)
            owner.refresh(); return outcome
        }
        fun withReopenedRecords(body: (List<VeilDeviceEnrollmentPendingStore.Entry>) -> Unit) = checked().withReopenedRecords(body)
    }
    internal companion object {
        const val MAX_QUEUED = 16
        fun open(context: Context): VeilCryptoEngineOwner {
            val owner = VeilCryptoEngineOwner(context)
            owner.worker.start()
            return owner
        }
    }
}

/** Private worker-bound bookkeeping, not a native authority constructor.
 * Only the frozen Java carrier declares JNI symbols. Unknown/error outcomes
 * retain custody; 24 is never thread-exit permission. No reopen after failure.
 */
internal class VeilNativeWorkerCustody {
    private val thread = Thread.currentThread()
    private var attempted = false
    private var released = false
    private var primary: Throwable? = null
    private fun owner() { check(Thread.currentThread() === thread) { "VEIL_NATIVE_WRONG_WORKER" } }
    private fun fail(code: Int): Nothing = throw IllegalStateException("VEIL_NATIVE_LIFECYCLE_$code")
    private fun <T> preserving(body: () -> T): T {
        owner()
        primary?.let { throw it }
        try { return body() } catch (failure: Throwable) { primary = failure; throw failure }
    }
    fun open() = preserving {
        check(!attempted) { "VEIL_NATIVE_OPEN_ALREADY_ATTEMPTED" }
        attempted = true
        System.loadLibrary("ynx_native_operation")
        val abi = VeilNativeProductControllerBridge.nativeAbiVersion()
        check(abi == 2) { "VEIL_NATIVE_ABI_MISMATCH" }
        val opened = VeilNativeProductControllerBridge.nativeOpen()
        if (opened !in setOf(0, 1, 20)) fail(opened)
        val status = VeilNativeProductControllerBridge.nativeStatus()
        // Initialization observes the exact original owning outcome, not a
        // later integer that might mask panic, unknown or accidental release.
        check(status == opened) { "VEIL_NATIVE_OPEN_STATUS_MISMATCH" }
    }
    fun releaseForThreadExit(): Boolean = preserving {
        check(attempted) { "VEIL_NATIVE_NOT_OPENED" }
        if (released) return@preserving true // no second TLS close/reopen
        val status = VeilNativeProductControllerBridge.nativeStatus()
        if (status !in setOf(0, 1, 20, 24)) fail(status)
        val closed = VeilNativeProductControllerBridge.nativeClose()
        if (closed == 8) return@preserving false
        if (closed != 24) fail(closed)
        val disposition = VeilNativeProductControllerBridge.nativeReleaseNoEffectForThreadExit()
        if (disposition == 8) return@preserving false
        if (disposition != 36) fail(disposition)
        released = true
        true
    }
}
