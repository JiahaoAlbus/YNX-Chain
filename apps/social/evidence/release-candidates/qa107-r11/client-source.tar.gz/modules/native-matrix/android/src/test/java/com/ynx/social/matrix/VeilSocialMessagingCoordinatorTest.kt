package com.ynx.social.matrix

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** PUBLIC dispatch controls only; not a native supplier, identity or chat test. */
class VeilSocialMessagingCoordinatorTest {
    private fun context(id: Int = 1, action: String = "requestContact") = JSONObject(mapOf(
        "callId" to id, "epoch" to 1, "action" to action, "accountViewRef" to "qa-a", "viewRevision" to "v1")).toString()
    private fun command() = """{"type":"requestContact","viewRevision":"v1","identifier":"qa-b"}"""
    private fun request(id: Int = 1) = VeilSocialMessagingCoordinator.Request.decode(context(id), command())
    private inline fun fails(body: () -> Unit): Throwable {
        try { body() } catch (failure: Throwable) { return failure }
        throw AssertionError("expected rejection")
    }
    private open class PublicBusiness : VeilSocialMessagingCoordinator.Business {
        var calls = 0
        var reads = 0
        var deliveryChecks = 0
        var deliveryFailure: Throwable? = null
        override fun read(context: Map<String, Any?>): Map<String, Any?> {
            reads++
            return mapOf("kind" to "LOCKED")
        }
        override fun execute(command: Map<String, Any?>, context: Map<String, Any?>): Map<String, Any?> {
            calls++
            return mapOf("kind" to "pending", "disposition" to "unknown", "originalOperationRef" to "public-original")
        }
        override fun requireDeliveryCurrent() {
            deliveryChecks++
            deliveryFailure?.let { throw it }
        }
        override fun hasRetainedWork() = true
    }
    @Test fun missingProducerCannotBecomeAuthority() {
        val c = VeilSocialMessagingCoordinator()
        val result = c.process(request())
        assertEquals(mapOf("kind" to "error", "code" to "UNAVAILABLE"), result["result"])
        assertFalse(c.hasRetainedWork())
        val read = c.process(VeilSocialMessagingCoordinator.Request.decode(context(2, "readSnapshot")))
        assertEquals("UNAVAILABLE", (read["snapshot"] as Map<*, *>)["kind"])
    }
    @Test fun exactOriginalRunsOnceAndChangedOrOlderInputCannotReplay() {
        val c = VeilSocialMessagingCoordinator(); val b = PublicBusiness(); c.attach(b)
        val first = c.process(request())
        assertSame(first, c.process(request()))
        assertEquals(1, b.deliveryChecks)
        fails { c.process(VeilSocialMessagingCoordinator.Request.decode(context(), command().replace("qa-b", "qa-c"))) }
        assertEquals(1, b.calls)
        c.process(request(2))
        fails { c.process(request()) }
        assertEquals(2, b.calls)
        fails { c.attach(PublicBusiness()) }
    }
    @Test fun cachedReadChecksAuthorityWithoutReadingAgain() {
        val c = VeilSocialMessagingCoordinator(); val b = PublicBusiness(); c.attach(b)
        val request = VeilSocialMessagingCoordinator.Request.decode(context(1, "readSnapshot"))
        val first = c.process(request)
        repeat(2) { assertSame(first, c.process(request)) }
        assertEquals(1, b.reads); assertEquals(2, b.deliveryChecks); assertEquals(0, b.calls)
    }
    @Test fun cachedPlaintextRefusalRetainsFirstFailureAndCannotRevive() {
        val c = VeilSocialMessagingCoordinator()
        val b = object : PublicBusiness() {
            override fun read(context: Map<String, Any?>): Map<String, Any?> {
                reads++
                return mapOf("kind" to "AUTHORIZED", "messages" to listOf(mapOf("body" to "PUBLIC test body")))
            }
        }
        c.attach(b)
        val request = VeilSocialMessagingCoordinator.Request.decode(context(1, "readSnapshot"))
        assertEquals("AUTHORIZED", (c.process(request)["snapshot"] as Map<*, *>)["kind"])
        val refusal = IllegalStateException("PUBLIC device revoked before delivery")
        b.deliveryFailure = refusal
        assertSame(refusal, fails { c.process(request) })
        b.deliveryFailure = null
        assertSame(refusal, fails { c.process(request) })
        assertSame(refusal, fails { c.process(VeilSocialMessagingCoordinator.Request.decode(context(2, "readSnapshot"))) })
        assertEquals(1, b.reads); assertEquals(1, b.deliveryChecks)
        assertTrue(c.hasRetainedWork())
        fails { c.attach(PublicBusiness()) }
    }
    @Test fun cachedCommandRefusalDoesNotRepeatOriginalEffect() {
        val c = VeilSocialMessagingCoordinator(); val b = PublicBusiness(); c.attach(b)
        val first = c.process(request())
        val refusal = IllegalStateException("PUBLIC original source closed")
        b.deliveryFailure = refusal
        assertSame(refusal, fails { c.process(request()) })
        assertEquals("public-original", (first["result"] as Map<*, *>)["originalOperationRef"])
        assertEquals(1, b.calls); assertEquals(1, b.deliveryChecks); assertTrue(c.hasRetainedWork())
    }
    @Test fun queuedObserversShareOneWorkerResultButEachDeliveryIsChecked() {
        val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
        val entered = java.util.concurrent.CountDownLatch(1)
        val release = java.util.concurrent.CountDownLatch(1)
        try {
            val pair = executor.submit(java.util.concurrent.Callable {
                val c = VeilSocialMessagingCoordinator()
                val b = object : PublicBusiness() {
                    override fun execute(command: Map<String, Any?>, context: Map<String, Any?>): Map<String, Any?> {
                        entered.countDown()
                        check(release.await(5, java.util.concurrent.TimeUnit.SECONDS))
                        return super.execute(command, context)
                    }
                }
                c.attach(b); c to b
            }).get(5, java.util.concurrent.TimeUnit.SECONDS)
            val first = executor.submit(java.util.concurrent.Callable { pair.first.process(request()) })
            assertTrue(entered.await(5, java.util.concurrent.TimeUnit.SECONDS))
            val second = executor.submit(java.util.concurrent.Callable { pair.first.process(request()) })
            release.countDown()
            assertSame(first.get(5, java.util.concurrent.TimeUnit.SECONDS), second.get(5, java.util.concurrent.TimeUnit.SECONDS))
            val counts = executor.submit(java.util.concurrent.Callable { pair.second.calls to pair.second.deliveryChecks })
                .get(5, java.util.concurrent.TimeUnit.SECONDS)
            assertEquals(1 to 1, counts)
        } finally {
            release.countDown(); executor.shutdownNow()
            assertTrue(executor.awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS))
        }
    }
    @Test fun originalFailureAndCloseCustodyAreRetained() {
        val c = VeilSocialMessagingCoordinator()
        val original = IllegalStateException("PUBLIC unknown")
        val b = object : PublicBusiness() {
            override fun execute(command: Map<String, Any?>, context: Map<String, Any?>): Map<String, Any?> {
                calls++; throw original
            }
        }
        c.attach(b)
        assertSame(original, fails { c.process(request()) })
        assertSame(original, fails { c.process(request(2)) })
        assertEquals(1, b.calls); assertTrue(c.hasRetainedWork())
    }
    @Test fun malformedDuplicateAndCrossViewInputsAreRejected() {
        for (bad in listOf(
            context().replace("\"callId\":1", "\"callId\":0"),
            context().replace("\"epoch\":1", "\"epoch\":1,\"epoch\":2"),
            context().dropLast(1) + ",\"nativeHandle\":7}",
            context().replace("requestContact", "sendMessage"),
            context().replace("v1", "v2")
        )) fails { VeilSocialMessagingCoordinator.Request.decode(bad, command()) }
        for (bad in listOf(command().replace("\"qa-b\"", "qa-b"), command().dropLast(1)+",\"trusted\":\"yes\"}",
            command().replace("qa-b", "\\uD800"), command().replace("qa-b", "x".repeat(513))))
            fails { VeilSocialMessagingCoordinator.Request.decode(context(), bad) }
    }
    @Test fun wrongWorkerCannotDispatch() {
        val c = VeilSocialMessagingCoordinator(); val b = PublicBusiness(); c.attach(b)
        var rejected = false
        val thread = Thread { rejected = fails { c.process(request()) } is IllegalStateException }
        thread.start(); thread.join()
        assertTrue(rejected); assertEquals(0, b.calls)
    }
    @Test fun outputIsOwnedAndPrivateFieldsNeverCrossTheBoundary() {
        val mutable = mutableMapOf<String, Any?>("kind" to "pending", "disposition" to "unknown", "originalOperationRef" to "public-original")
        val c = VeilSocialMessagingCoordinator()
        c.attach(object : PublicBusiness() {
            override fun execute(command: Map<String, Any?>, context: Map<String, Any?>) = mutable
        })
        val captured = c.process(request()); mutable["originalOperationRef"] = "changed"
        assertEquals("public-original", (captured["result"] as Map<*, *>)["originalOperationRef"])
        val leaking = VeilSocialMessagingCoordinator()
        leaking.attach(object : PublicBusiness() {
            override fun execute(command: Map<String, Any?>, context: Map<String, Any?>) = mapOf<String, Any?>("privateKey" to "PUBLIC forbidden shape")
        })
        fails { leaking.process(request()) }; assertTrue(leaking.hasRetainedWork())
    }
    @Test fun failedRetainedWorkInspectionCannotReleaseOriginalOwner() {
        val original = IllegalStateException("PUBLIC cleanup")
        val c = VeilSocialMessagingCoordinator()
        c.attach(object : PublicBusiness() { override fun hasRetainedWork(): Boolean = throw original })
        assertTrue(c.hasRetainedWork())
        assertSame(original, fails { c.process(request()) })
    }
}
