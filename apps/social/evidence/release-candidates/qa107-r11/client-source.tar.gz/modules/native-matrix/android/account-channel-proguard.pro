-keep class com.ynx.social.matrix.VeilNativeAccountChannel { *; }
-keepclassmembers class com.ynx.social.matrix.VeilSocialLoginClient$AccountChannelBorrow {
    private void requireCurrent();
    private long revisionForNative();
    private byte[] cookieForNative();
    private byte[] issuerForNative();
    private byte[] targetForNative();
    private byte[] bodyForNative();
}
# Exact selected Rust JNI names and result fields; sole libsignal provider.
-keep class org.rustls.platformverifier.CertificateVerifier { *; }
-keep class org.rustls.platformverifier.VerificationResult { *; }
-keep class org.rustls.platformverifier.StatusCode { *; }
