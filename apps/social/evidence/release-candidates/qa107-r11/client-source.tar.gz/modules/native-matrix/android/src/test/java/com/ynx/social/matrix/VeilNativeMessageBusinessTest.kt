package com.ynx.social.matrix

import java.nio.ByteBuffer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** PUBLIC owning-lifecycle controls. No JNI, device, cryptography or real I/O. */
class VeilNativeMessageBusinessTest {
    private fun frame(incoming: Boolean = false): ByteArray = ByteBuffer.allocate(29)
        .put("YNXM".toByteArray()).put(1).put(if (incoming) 2 else 1)
        .put(if (incoming) 2 else 1).put(0)
        .put(ByteArray(16) { if (it == 0) 1 else 0 }).putInt(1).put(65).array()
    private fun view(): Map<String, Any?> = mapOf(
        "kind" to "AUTHORIZED", "accountViewRef" to "PUBLIC-alice", "viewRevision" to "v1",
        "profile" to mapOf("displayName" to "PUBLIC Alice", "publicIdentifier" to "PUBLIC-alice"),
        "conversations" to listOf(mapOf("id" to "PUBLIC-peer", "title" to "PUBLIC Bob", "preview" to "", "unreadCount" to 0)),
        "messages" to emptyList<Any>(), "activeConversationId" to "PUBLIC-peer",
        "contacts" to emptyList<Any>(), "contactRequests" to emptyList<Any>(),
        "moments" to emptyList<Any>(), "devices" to emptyList<Any>(), "audiences" to emptyList<Any>(),
        "recoveries" to emptyList<Any>(), "actions" to listOf("sendMessage", "requestContact", "openConversation"),
        "localAi" to "unsupported")
    private fun command(type: String = "sendMessage") = if (type == "sendMessage") mapOf<String, Any?>(
        "type" to type, "viewRevision" to "v1", "conversationId" to "PUBLIC-peer", "body" to "A", "replyToMessageId" to null)
        else mapOf<String, Any?>("type" to type, "viewRevision" to "v1", "identifier" to "PUBLIC-bob")
    private fun context(type: String = "sendMessage", id: Int = 1) = mapOf<String, Any?>(
        "callId" to id, "epoch" to 1, "action" to type, "accountViewRef" to "PUBLIC-alice", "viewRevision" to "v1")
    private open class Original : VeilNativeMessageBusiness.Original {
        override val reference = "PUBLIC-original"
        var closes = 0
        var checks = 0
        var bindings = 0
        var closeFailure: Throwable? = null
        var state = VeilNativeMessageBusiness.Completion.COMMITTED
        override fun checkCurrent() { checks++ }
        override fun requireRequest(command: Map<String, Any?>, context: Map<String, Any?>) { bindings++ }
        override fun completion() = state
        override fun close() { closes++; closeFailure?.let { throw it } }
    }
    private inner class Message(val incoming: Boolean = false) : Original(), VeilNativeMessageBusiness.Message {
        var consumed = 0
        var transferFailure: Throwable? = null
        override fun sessionRecords() = byteArrayOf(1)
        override fun frame() = this@VeilNativeMessageBusinessTest.frame(incoming)
        override fun consumeOriginalOutput(output: VeilNativeMessageOutput) {
            consumed++
            assertEquals(if (incoming) 2 else 1, output.direction)
            transferFailure?.let { throw it }
        }
    }
    private class Contact : Original(), VeilNativeMessageBusiness.Contact {
        var executions = 0
        override fun executeOriginal() { executions++ }
    }
    private inner class Binding(val original: Original) : VeilNativeMessageBusiness.Binding {
        var prepares = 0
        var checks = 0
        var currentFailure: Throwable? = null
        var lateFailure: Throwable? = null
        var skip = false
        var duplicate = false
        var projectionFailure: Throwable? = null
        override fun checkCurrent() { checks++; currentFailure?.let { throw it } }
        override fun projection(): Map<String, Any?> {
            projectionFailure?.let { throw it }
            return view()
        }
        override fun openConversation(command: Map<String, Any?>) = view()
        override fun prepare(command: Map<String, Any?>, context: Map<String, Any?>,
                             capture: (VeilNativeMessageBusiness.Original) -> Unit) {
            prepares++
            if (!skip) capture(original)
            if (duplicate) capture(original)
            lateFailure?.let { throw it }
        }
        override fun hasRetainedWork() = lateFailure != null || skip
    }
    private class Op : VeilNativeMessageBusiness.NativeOperation
    private inner class Native : VeilNativeMessageBusiness.NativePort {
        var acquisitions = 0; var executes = 0; var advances = 0; var copies = 0; var retires = 0
        var currentChecks = 0
        var held = false; var wait = false; var incoming = false
        var currentFailure: Throwable? = null
        var afterRetire: (() -> Unit)? = null
        val operation = Op()
        override fun deviceCurrent() { currentChecks++; currentFailure?.let { throw it } }
        override fun openSession(records: ByteArray) { assertArrayEquals(byteArrayOf(1), records) }
        override fun epoch() = 1L
        override fun acquire(epoch: Long, frame: ByteArray): VeilNativeMessageBusiness.NativeOperation {
            acquisitions++; held = true; incoming = frame[5].toInt() == 2; return operation
        }
        override fun execute(original: VeilNativeMessageBusiness.NativeOperation, epoch: Long, frame: ByteArray): Long {
            assertSame(operation, original); executes++; return if (wait) 30 else 0
        }
        override fun advance(original: VeilNativeMessageBusiness.NativeOperation, epoch: Long): Long {
            assertSame(operation, original); advances++; return 0
        }
        override fun output(original: VeilNativeMessageBusiness.NativeOperation, epoch: Long,
                            consume: (VeilNativeMessageOutput) -> Unit) {
            assertSame(operation, original); copies++
            val logical = ByteArray(16) { if (it == 0) 1 else 0 }
            val wire = ByteBuffer.allocate(29).put("YNXO".toByteArray()).put(1)
                .put(if (incoming) 2 else 1).put(if (incoming) 1 else 2).put(0)
                .put(logical).putInt(1).put(65).array()
            VeilNativeMessageOutput.decode(wire, 29, logical, if (incoming) 2 else 1).use(consume)
        }
        override fun retire(original: VeilNativeMessageBusiness.NativeOperation, epoch: Long) {
            assertSame(operation, original); retires++; held = false; afterRetire?.invoke()
        }
        override fun hasRetainedWork() = held
    }

    @Test fun normalCoordinatorDispatchConsumesSameNativeOriginalOnce() {
        val m = Message(); val b = Binding(m); val n = Native()
        val business = VeilNativeMessageBusiness.control(n, b)
        val coordinator = VeilSocialMessagingCoordinator(); coordinator.attach(business)
        val commandJson = JSONObject(command()).put("replyToMessageId", JSONObject.NULL).toString()
        val request = VeilSocialMessagingCoordinator.Request.decode(JSONObject(context()).toString(), commandJson)
        val first = coordinator.process(request)
        assertEquals("confirmed", (first["result"] as Map<*, *>)["completion"])
        val sourceChecks = b.checks; val deviceChecks = n.currentChecks
        assertSame(first, coordinator.process(request))
        assertEquals(sourceChecks + 1, b.checks); assertEquals(deviceChecks + 1, n.currentChecks)
        assertEquals(1, b.prepares); assertEquals(1, n.acquisitions); assertEquals(1, n.executes)
        assertEquals(1, m.consumed); assertEquals(1, m.bindings); assertEquals(1, m.closes)
        assertEquals(1, n.retires); assertFalse(business.hasRetainedWork())
    }
    @Test fun cachedReadRefusesSourceOrDeviceRevocationWithoutNewWork() {
        for (sourceRefusal in listOf(true, false)) {
            val b = Binding(Message()); val n = Native()
            val business = VeilNativeMessageBusiness.control(n, b)
            val coordinator = VeilSocialMessagingCoordinator(); coordinator.attach(business)
            val request = VeilSocialMessagingCoordinator.Request.decode(JSONObject(context("readSnapshot")).toString())
            assertEquals("AUTHORIZED", (coordinator.process(request)["snapshot"] as Map<*, *>)["kind"])
            val beforeSource = b.checks; val beforeDevice = n.currentChecks
            val refusal = IllegalStateException("PUBLIC original authority revoked")
            if (sourceRefusal) b.currentFailure = refusal else n.currentFailure = refusal
            try { coordinator.process(request); fail("revoked cached plaintext returned") }
            catch (failure: Throwable) { assertSame(refusal, failure) }
            b.currentFailure = null; n.currentFailure = null
            try { coordinator.process(request); fail("cached authority revived") }
            catch (failure: Throwable) { assertSame(refusal, failure) }
            assertEquals(beforeSource + 1, b.checks)
            assertEquals(beforeDevice + if (sourceRefusal) 0 else 1, n.currentChecks)
            assertEquals(0, b.prepares); assertEquals(0, n.acquisitions); assertEquals(0, n.executes)
            assertTrue(coordinator.hasRetainedWork())
        }
    }
    @Test fun deliveryValidationPreservesOriginalUnknownAndDoesNotAdvance() {
        val original = IllegalStateException("PUBLIC original output unknown")
        val m = Message().also { it.transferFailure = original }
        val b = Binding(m); val n = Native(); val business = VeilNativeMessageBusiness.control(n, b)
        assertEquals("unknown", business.execute(command(), context())["disposition"])
        val sourceChecks = b.checks; val deviceChecks = n.currentChecks
        business.requireDeliveryCurrent()
        assertEquals(sourceChecks + 1, b.checks); assertEquals(deviceChecks + 1, n.currentChecks)
        assertSame(original, business.retainedFailure()); assertTrue(business.hasRetainedWork())
        assertEquals(1, b.prepares); assertEquals(1, n.executes); assertEquals(1, m.consumed)
        assertEquals(0, n.advances); assertEquals(0, n.retires); assertEquals(0, m.closes)
    }
    @Test fun wrongWorkerCannotValidateCachedDelivery() {
        val b = Binding(Message()); val n = Native(); val business = VeilNativeMessageBusiness.control(n, b)
        var caught: Throwable? = null
        Thread { try { business.requireDeliveryCurrent() } catch (failure: Throwable) { caught = failure } }
            .also { it.start(); it.join() }
        assertEquals("VEIL_PRODUCT_WRONG_WORKER", caught?.message)
        assertEquals(0, b.checks); assertEquals(0, n.currentChecks); assertEquals(0, b.prepares)
    }
    @Test fun heldNativeWorkAdvancesOriginalWithoutPreparingAgain() {
        val m = Message(); val b = Binding(m); val n = Native().also { it.wait = true }
        val business = VeilNativeMessageBusiness.control(n, b)
        assertEquals("queued", business.execute(command(), context())["disposition"])
        assertTrue(business.hasRetainedWork())
        assertEquals("AUTHORIZED", business.read(context("readSnapshot", 2))["kind"])
        assertEquals(1, n.acquisitions); assertEquals(1, n.executes); assertEquals(1, n.advances)
        assertEquals(1, m.consumed); assertEquals(1, m.closes); assertFalse(business.hasRetainedWork())
    }
    @Test fun uncertainTransportNeverResendsAndKeepsOriginalError() {
        val failure = IllegalStateException("PUBLIC lost reply")
        val m = Message().also { it.transferFailure = failure }
        val b = Binding(m); val n = Native(); val business = VeilNativeMessageBusiness.control(n, b)
        assertEquals("unknown", business.execute(command(), context())["disposition"])
        repeat(2) { assertEquals("RECOVERY_REQUIRED", business.read(context("readSnapshot", it + 2))["kind"]) }
        business.execute(mapOf("type" to "reviewRecovery", "originalOperationRef" to m.reference), context("reviewRecovery", 5))
        assertEquals(1, m.consumed); assertEquals(0, m.closes); assertEquals(0, n.retires)
        assertEquals(1, n.executes); assertEquals(0, n.advances); assertSame(failure, business.retainedFailure())
        assertTrue(business.hasRetainedWork())
    }
    @Test fun closeFailureDoesNotRetryOrDropCustody() {
        val failure = IllegalStateException("PUBLIC close")
        val m = Message().also { it.closeFailure = failure }
        val business = VeilNativeMessageBusiness.control(Native(), Binding(m))
        assertEquals("unknown", business.execute(command(), context())["disposition"])
        val result = business.execute(mapOf("type" to "reviewRecovery", "originalOperationRef" to m.reference), context("reviewRecovery", 2))
        assertEquals("unresolved", result["resolution"]); assertEquals(1, m.closes)
        assertSame(failure, business.retainedFailure()); assertTrue(business.hasRetainedWork())
    }
    @Test fun postCommitViewFailureStillReportsExactOriginal() {
        val m = Message(); val b = Binding(m); val n = Native()
        n.afterRetire = { b.projectionFailure = IllegalStateException("PUBLIC view") }
        val business = VeilNativeMessageBusiness.control(n, b)
        val result = business.execute(command(), context())
        assertEquals("unknown", result["disposition"]); assertEquals(m.reference, result["originalOperationRef"])
        assertEquals(1, m.closes); assertTrue(business.hasRetainedWork())
    }
    @Test fun staleViewAndUnavailableActionNeverPrepare() {
        val m = Message(); val b = Binding(m); val n = Native()
        val business = VeilNativeMessageBusiness.control(n, b)
        assertEquals("STALE_VIEW", business.execute(command(), context() + ("viewRevision" to "v2"))["code"])
        assertEquals("UNAVAILABLE", business.execute(mapOf("type" to "publishMoment"), context("publishMoment"))["code"])
        assertEquals(0, b.prepares); assertEquals(0, n.acquisitions)
    }
    @Test fun latePrepareFailureRetainsOriginalAndNeverExecutes() {
        val failure = IllegalStateException("PUBLIC late capture")
        val m = Message(); val b = Binding(m).also { it.lateFailure = failure }; val n = Native()
        val business = VeilNativeMessageBusiness.control(n, b)
        val result = business.execute(command(), context())
        assertEquals("unknown", result["disposition"]); assertEquals(m.reference, result["originalOperationRef"])
        assertEquals(0, n.acquisitions); assertSame(failure, business.retainedFailure()); assertTrue(business.hasRetainedWork())
    }
    @Test fun missingOrDuplicateCaptureCannotBecomeSuccess() {
        for (duplicate in listOf(false, true)) {
            val m = Message(); val b = Binding(m).also { it.skip = !duplicate; it.duplicate = duplicate }
            val n = Native(); val business = VeilNativeMessageBusiness.control(n, b)
            val result = business.execute(command(), context())
            assertNotEquals("snapshot", result["kind"]); assertEquals(0, n.executes)
            assertTrue(business.hasRetainedWork())
        }
    }
    @Test fun contactUsesOriginalPurposeBoundRequestNotMessageOrCookie() {
        val c = Contact(); val b = Binding(c); val n = Native()
        val business = VeilNativeMessageBusiness.control(n, b)
        assertEquals("confirmed", business.execute(command("requestContact"), context("requestContact"))["completion"])
        assertEquals(1, c.executions); assertEquals(1, c.bindings); assertEquals(1, c.closes)
        assertEquals(0, n.acquisitions); assertFalse(business.hasRetainedWork())
    }
    @Test fun receiveConsumesNativePlaintextOnlyThroughOriginalStore() {
        val m = Message(true); val b = Binding(m); val n = Native()
        val business = VeilNativeMessageBusiness.control(n, b)
        business.receive(m)
        assertEquals(1, m.consumed); assertEquals(1, n.executes); assertTrue(n.incoming)
        business.read(context("readSnapshot")); assertFalse(business.hasRetainedWork())
    }
    @Test fun nativeRefusalCannotBeOverriddenByAnAuthorizedLookingView() {
        val refusal = IllegalStateException("PUBLIC Native current refused")
        val b = Binding(Message()); val n = Native().also { it.currentFailure = refusal }
        val business = VeilNativeMessageBusiness.control(n, b)
        assertEquals("OUTCOME_UNKNOWN", business.execute(command(), context())["code"])
        assertEquals(0, b.prepares); assertEquals(0, n.acquisitions); assertSame(refusal, business.retainedFailure())
    }
    @Test fun wrongWorkerCannotUseBusiness() {
        val business = VeilNativeMessageBusiness.control(Native(), Binding(Message()))
        var failure: Throwable? = null
        Thread { try { business.read(context("readSnapshot")) } catch (value: Throwable) { failure = value } }.also { it.start(); it.join() }
        assertTrue(failure is IllegalStateException)
    }
}



/** Concrete consumer integration controls with PUBLIC authority and in-memory
 * transaction stand-ins. Not Android key storage, Native or two-client acceptance. */
class VeilMatrixProductBindingTest {
    private class MemoryStore : VeilMatrixProductBinding.Store {
        var savedState: String? = null
        var transactionOpen = false
        val saved = linkedMapOf<String, String>()
        val history = linkedMapOf<String, String>()
        var historyLimitBytes = Long.MAX_VALUE
        var failHistoryWrites = false
        var failHistoryRemoval = false
        var failOperationRead = false
        var failStatus: String? = null
        val storeFailure = IllegalStateException("PUBLIC store failure")
        override fun <T> transaction(block: (VeilMatrixProductBinding.Records) -> T): T {
            check(!transactionOpen); transactionOpen = true
            try {
            var localState = savedState
            val local = LinkedHashMap(saved)
            val localHistory = LinkedHashMap(history)
            val result = block(object : VeilMatrixProductBinding.Records {
                override fun state() = localState?.let { JSONObject(it) }
                override fun state(value: JSONObject) { localState = value.toString() }
                override fun operation(id: String) = local[id]?.let { JSONObject(it) }
                override fun operation(id: String, value: JSONObject) {
                    if (value.getString("status") == failStatus) throw storeFailure
                    local[id] = value.toString()
                }
                override fun operations(): List<String> {
                    if (failOperationRead) throw storeFailure
                    return local.keys.toList()
                }
                override fun history(id: String) = localHistory[id]?.let { JSONObject(it) }
                override fun history(id: String, value: JSONObject) {
                    if (failHistoryWrites) throw storeFailure
                    val bytes = value.toString()
                    val total = localHistory.entries.sumOf { if (it.key == id) 0L else it.value.toByteArray().size.toLong() }
                    if (total + bytes.toByteArray().size > historyLimitBytes) throw VeilMatrixProductBinding.HistoryCapacity()
                    localHistory[id] = bytes
                }
                override fun removeHistory(id: String) {
                    if (failHistoryRemoval) throw storeFailure
                    localHistory.remove(id)
                }
            })
            savedState = localState; saved.clear(); saved.putAll(local)
            history.clear(); history.putAll(localHistory)
            return result
            } finally { transactionOpen = false }
        }
        fun only() = JSONObject(saved.values.single())
    }
    private class Source : VeilMatrixProductBinding.NativeSource {
        val route = VeilMatrixProductBinding.Route("PUBLIC-peer", "PUBLIC Bob", "PUBLIC-bob",
            "!room:qa.invalid", "@alice:qa.invalid", "@bob:qa.invalid")
        var prepares = 0; var checks = 0; var closes = 0; var verifies = 0; var contactCalls = 0
        var stopped = false
        var custodyFailure: Throwable? = null
        var commitFailure: Throwable? = null; var closeFailure: Throwable? = null
        override fun checkCurrent() { checks++; check(!stopped) { "PUBLIC device revoked" } }
        override fun identity() = VeilMatrixProductBinding.Identity("PUBLIC-alice", "PUBLIC Alice", "PUBLIC-alice")
        override fun routes() = listOf(route)
        override fun invitations() = emptyList<VeilMatrixProductBinding.Invitation>()
        private inner class Authority(override val reference: String,
                                      val command: Map<String, Any?>, val context: Map<String, Any?>) :
            VeilMatrixProductBinding.MessageAuthority {
            override fun checkCurrent() = this@Source.checkCurrent()
            override fun requireRequest(command: Map<String, Any?>, context: Map<String, Any?>) {
                assertEquals(this.command, command); assertEquals(this.context, context)
            }
            override fun sessionRecords() = byteArrayOf(1)
            override fun requireCommittedOutput(output: VeilNativeMessageOutput) {
                verifies++; commitFailure?.let { throw it }
            }
            override fun completion() = VeilNativeMessageBusiness.Completion.COMMITTED
            override fun close() { closes++; closeFailure?.let { throw it } }
        }
        override fun prepareMessage(command: Map<String, Any?>, context: Map<String, Any?>, logicalId: String,
                                    originalFrame: ByteArray, capture: (VeilMatrixProductBinding.MessageAuthority) -> Unit) {
            prepares++; assertEquals(1, originalFrame[5].toInt())
            assertEquals(command["body"], String(originalFrame, 28, originalFrame.size - 28, Charsets.UTF_8))
            capture(Authority(logicalId, command, context))
        }
        override fun prepareIncoming(route: VeilMatrixProductBinding.Route, eventId: String, logicalId: String,
                                     originalFrame: ByteArray, capture: (VeilMatrixProductBinding.MessageAuthority) -> Unit) {
            prepares++; assertEquals(this.route, route); assertEquals(2, originalFrame[5].toInt())
            capture(Authority(logicalId, emptyMap(), emptyMap()))
        }
        override fun prepareContact(command: Map<String, Any?>, context: Map<String, Any?>,
                                    capture: (VeilNativeMessageBusiness.Contact) -> Unit) {
            prepares++
            capture(object : VeilNativeMessageBusiness.Contact {
                override val reference = "PUBLIC-contact-original"
                override fun checkCurrent() = this@Source.checkCurrent()
                override fun requireRequest(command: Map<String, Any?>, context: Map<String, Any?>) {}
                override fun completion() = VeilNativeMessageBusiness.Completion.COMMITTED
                override fun close() { closes++; closeFailure?.let { throw it } }
                override fun executeOriginal() { contactCalls++ }
            })
        }
        override fun hasRetainedWork(): Boolean {
            custodyFailure?.let { throw it }
            return false
        }
    }
    private class Op(val frame: ByteArray) : VeilNativeMessageBusiness.NativeOperation
    private class Native(val store: MemoryStore) : VeilNativeMessageBusiness.NativePort {
        var executes = 0; var retires = 0; var held = false
        override fun deviceCurrent() {}
        override fun openSession(records: ByteArray) { assertArrayEquals(byteArrayOf(1), records) }
        override fun epoch() = 1L
        override fun acquire(epoch: Long, frame: ByteArray): VeilNativeMessageBusiness.NativeOperation {
            val id = ByteBuffer.wrap(frame, 8, 16).let { java.util.UUID(it.long, it.long).toString() }
            assertEquals("PREPARED", JSONObject(checkNotNull(store.saved[id])).getString("status"))
            held = true; return Op(frame.copyOf())
        }
        override fun execute(original: VeilNativeMessageBusiness.NativeOperation, epoch: Long, frame: ByteArray): Long {
            executes++; return 0
        }
        override fun advance(original: VeilNativeMessageBusiness.NativeOperation, epoch: Long): Long =
            throw AssertionError("PUBLIC control does not need advance")
        override fun output(original: VeilNativeMessageBusiness.NativeOperation, epoch: Long,
                            consume: (VeilNativeMessageOutput) -> Unit) {
            val frame = (original as Op).frame
            val incoming = frame[5].toInt() == 2
            val bytes = if (incoming) "PUBLIC reply".toByteArray() else byteArrayOf(0x44, 1, 2, 3)
            val logical = frame.copyOfRange(8, 24)
            val wire = ByteBuffer.allocate(28 + bytes.size).put("YNXO".toByteArray()).put(1)
                .put(if (incoming) 2 else 1).put(if (incoming) 1 else 2).put(0)
                .put(logical).putInt(bytes.size).put(bytes).array()
            VeilNativeMessageOutput.decode(wire, wire.size.toLong(), logical, if (incoming) 2 else 1).use(consume)
        }
        override fun retire(original: VeilNativeMessageBusiness.NativeOperation, epoch: Long) { retires++; held = false }
        override fun hasRetainedWork() = held
    }
    private class Harness {
        val store = MemoryStore()
        val source = Source()
        val methods = mutableListOf<String>()
        var failureOn: String? = null
        var content: JSONObject? = null
        var checkBeforeHttp: (() -> Unit)? = null
        var syncEvents = org.json.JSONArray()
        var syncNext = "PUBLIC-sync-next"
        var syncLimited = false
        var historyEvents = org.json.JSONArray()
        var historyEnd: String? = null
        val historyFrom = mutableListOf<String?>()
        val syncSince = mutableListOf<String?>()
        private val client = okhttp3.OkHttpClient.Builder().followRedirects(false)
            .followSslRedirects(false).retryOnConnectionFailure(false)
            .addInterceptor { chain ->
                val r = chain.request()
                methods.add(r.method); checkBeforeHttp?.invoke()
                if (failureOn == r.method) throw java.io.IOException("PUBLIC lost response")
                val text = when (r.method) {
                    "POST" -> """{"content_uri":"mxc://qa.invalid/opaque"}"""
                    "PUT" -> {
                        val out = okio.Buffer(); checkNotNull(r.body).writeTo(out)
                        content = JSONObject(out.readUtf8())
                        JSONObject().put("event_id", "$" + "PUBLIC-event").toString()
                    }
                    else -> when {
                        r.url.encodedPath.endsWith("/sync") -> {
                            syncSince.add(r.url.queryParameter("since"))
                            assertEquals("0", r.url.queryParameter("timeout"))
                            assertEquals("offline", r.url.queryParameter("set_presence"))
                            JSONObject().put("next_batch", syncNext).put("rooms", JSONObject().put("join",
                                JSONObject().put("!room:qa.invalid", JSONObject().put("timeline",
                                    JSONObject().put("limited", syncLimited).put("prev_batch", "PUBLIC-prev-gap")
                                        .put("events", syncEvents))))).toString()
                        }
                        r.url.encodedPath.endsWith("/messages") -> {
                            historyFrom.add(r.url.queryParameter("from"))
                            assertEquals("b", r.url.queryParameter("dir"))
                            assertNull(r.url.queryParameter("to"))
                            JSONObject().put("start", r.url.queryParameter("from") ?: "PUBLIC-first-visible")
                                .put("chunk", historyEvents).also { row -> historyEnd?.let { row.put("end", it) } }.toString()
                        }
                        r.url.encodedPath.contains("/media/download/") ->
                            String(byteArrayOf(0x44, 1, 2, 3), Charsets.ISO_8859_1)
                        else -> JSONObject().put("event_id", "$" + "PUBLIC-event")
                            .put("room_id", "!room:qa.invalid").put("sender", "@alice:qa.invalid")
                            .put("type", VeilMatrixCiphertextHttpTransport.EVENT).put("content", checkNotNull(content)).toString()
                    }
                }
                okhttp3.Response.Builder().request(r).protocol(okhttp3.Protocol.HTTP_1_1)
                    .code(200).message("PUBLIC").body(okhttp3.ResponseBody.create(null, text)).build()
            }.build()
        val courier = VeilMatrixCiphertextHttpTransport.control("https://qa.invalid/", "PUBLIC-token".toCharArray(), client)
        val binding = VeilMatrixProductBinding.control(source, store, courier)
        val native = Native(store)
        val business = VeilNativeMessageBusiness.control(native, binding)
        fun select() {
            binding.openConversation(mapOf("conversationId" to "PUBLIC-peer", "viewRevision" to binding.projection()["viewRevision"]))
        }
        fun command(type: String = "sendMessage"): Map<String, Any?> {
            val revision = binding.projection()["viewRevision"]
            return if (type == "sendMessage") mapOf("type" to type, "viewRevision" to revision,
                "conversationId" to "PUBLIC-peer", "body" to "PUBLIC hello", "replyToMessageId" to null)
            else mapOf("type" to type, "viewRevision" to revision, "identifier" to "PUBLIC-bob")
        }
        fun context(command: Map<String, Any?>) = mapOf<String, Any?>("callId" to 1, "epoch" to 1,
            "action" to command["type"], "accountViewRef" to "PUBLIC-alice", "viewRevision" to command["viewRevision"])
        fun send(): Map<String, Any?> { val c = command(); return business.execute(c, context(c)) }
    }
    @Test fun normalCoordinatorCallsConcreteJournalAndCiphertextTransport() {
        val h = Harness(); h.select()
        h.checkBeforeHttp = {
            val saved = h.store.only()
            assertEquals("NATIVE_COMMITTED", saved.getString("status"))
            assertTrue(saved.has("ciphertext"))
        }
        val coordinator = VeilSocialMessagingCoordinator(); coordinator.attach(h.business)
        val command = h.command()
        val request = VeilSocialMessagingCoordinator.Request.decode(JSONObject(h.context(command)).toString(),
            JSONObject(command).put("replyToMessageId", JSONObject.NULL).toString())
        val response = coordinator.process(request)
        assertEquals("confirmed", (response["result"] as Map<*, *>)["completion"])
        assertSame(response, coordinator.process(request))
        assertEquals(listOf("POST", "PUT", "GET"), h.methods)
        assertEquals(1, h.source.prepares); assertEquals(1, h.source.verifies)
        assertEquals(1, h.native.retires); assertEquals(1, h.source.closes)
        assertEquals("CLOSED", h.store.only().getString("status"))
        val messages = h.binding.projection()["messages"] as List<*>
        assertEquals("PUBLIC hello", (messages.single() as Map<*, *>)["body"])
        assertEquals("unconfirmed", (messages.single() as Map<*, *>)["delivery"])
        assertFalse(h.business.hasRetainedWork())
        assertFalse(checkNotNull(h.content).has("body"))
    }
    @Test fun nativeCommitRefusalCannotReachCourierOrClearOriginal() {
        val h = Harness(); h.select()
        val rejected = IllegalStateException("PUBLIC original ratchet not committed")
        h.source.commitFailure = rejected
        assertEquals("unknown", h.send()["disposition"])
        assertTrue(h.methods.isEmpty()); assertEquals("UNKNOWN", h.store.only().getString("status"))
        assertEquals(0, h.native.retires); assertEquals(0, h.source.closes)
        assertSame(rejected, h.business.retainedFailure())
        assertTrue(h.business.hasRetainedWork())
    }
    @Test fun failedSealedJournalPreventsNetworkAndKeepsCause() {
        val h = Harness(); h.select(); h.store.failStatus = "NATIVE_COMMITTED"
        assertEquals("unknown", h.send()["disposition"])
        assertTrue(h.methods.isEmpty()); assertEquals("UNKNOWN", h.store.only().getString("status"))
        assertSame(h.store.storeFailure, h.business.retainedFailure())
        assertEquals(0, h.native.retires)
    }
    @Test fun lostUploadReplySurvivesReconstructionWithoutNewSend() {
        val h = Harness(); h.select(); h.failureOn = "POST"
        assertEquals("unknown", h.send()["disposition"])
        val original = h.store.only().getString("reference")
        repeat(2) { assertEquals("RECOVERY_REQUIRED", h.business.read(emptyMap())["kind"]) }
        val restored = VeilMatrixProductBinding.control(h.source, h.store, h.courier)
        assertTrue(restored.hasRetainedWork())
        val view = restored.projection()
        val recovery = (view["recoveries"] as List<*>).single() as Map<*, *>
        assertEquals(original, recovery["originalOperationRef"])
        assertFalse((view["actions"] as List<*>).contains("sendMessage"))
        assertEquals(listOf("POST"), h.methods); assertEquals(1, h.source.prepares)
        assertEquals(0, h.native.retires)
    }
    @Test fun closedHistoryRemainsAfterBindingReconstruction() {
        val h = Harness(); h.select(); assertEquals("confirmed", h.send()["completion"])
        val restored = VeilMatrixProductBinding.control(h.source, h.store, h.courier)
        val view = restored.projection()
        assertEquals("PUBLIC hello", ((view["messages"] as List<*>).single() as Map<*, *>)["body"])
        assertFalse(restored.hasRetainedWork())
        assertEquals("PUBLIC-peer", view["activeConversationId"])
    }
    @Test fun incomingGoesThroughDownloadNativeOutputAndSameJournal() {
        val store = MemoryStore(); val source = Source(); var downloads = 0
        val ciphertext = byteArrayOf(0x44, 7, 8, 9)
        val client = okhttp3.OkHttpClient.Builder().followRedirects(false).followSslRedirects(false)
            .retryOnConnectionFailure(false).addInterceptor { chain ->
                downloads++; assertEquals("PREPARED", store.only().getString("status"))
                assertEquals("GET", chain.request().method)
                okhttp3.Response.Builder().request(chain.request()).protocol(okhttp3.Protocol.HTTP_1_1)
                    .code(200).message("PUBLIC").body(okhttp3.ResponseBody.create(null, ciphertext)).build()
            }.build()
        val courier = VeilMatrixCiphertextHttpTransport.control("https://qa.invalid/", "PUBLIC-token".toCharArray(), client)
        val binding = VeilMatrixProductBinding.control(source, store, courier)
        binding.openConversation(mapOf("conversationId" to "PUBLIC-peer", "viewRevision" to "0"))
        val business = VeilNativeMessageBusiness.control(Native(store), binding)
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(ciphertext)
            .joinToString("") { "%02x".format(it.toInt() and 255) }
        val content = VeilMatrixCiphertextHttpTransport.Content("00000000-0000-4000-8000-000000000002", 2,
            "mxc://remote.invalid/opaque", digest, ciphertext.size)
        var original: VeilNativeMessageBusiness.Message? = null
        binding.incoming("PUBLIC-peer", "$" + "remote-event", "@bob:qa.invalid", content) { original = it }
        business.receive(checkNotNull(original))
        assertEquals("AUTHORIZED", business.read(emptyMap())["kind"])
        assertEquals(1, downloads); assertEquals(1, source.verifies)
        assertEquals("CLOSED", store.only().getString("status"))
        assertEquals("PUBLIC reply", ((binding.projection()["messages"] as List<*>).single() as Map<*, *>)["body"])
        assertFalse(business.hasRetainedWork())
    }
    @Test fun revokedOrWrongPeerCannotDownloadOrPrepare() {
        val h = Harness()
        try {
            h.binding.incoming("PUBLIC-peer", "$" + "bad", "@mallory:qa.invalid",
                VeilMatrixCiphertextHttpTransport.Content("00000000-0000-4000-8000-000000000002", 2,
                    "mxc://qa.invalid/x", "a".repeat(64), 1)) { fail("wrong peer captured") }
            fail("wrong peer accepted")
        } catch (_: NoSuchElementException) {}
        assertTrue(h.methods.isEmpty()); assertTrue(h.store.saved.isEmpty())
        h.source.stopped = true
        try { h.binding.projection(); fail("revoked device published") } catch (_: IllegalStateException) {}
        assertEquals(0, h.source.prepares)
    }
    @Test fun contactUsesItsOriginalSourceAndDurableOperation() {
        val h = Harness()
        val command = h.command("requestContact")
        assertEquals("confirmed", h.business.execute(command, h.context(command))["completion"])
        assertEquals(1, h.source.contactCalls); assertEquals(1, h.source.closes)
        assertEquals("contact", h.store.only().getString("type")); assertEquals("CLOSED", h.store.only().getString("status"))
        assertEquals(0, h.native.executes); assertTrue(h.methods.isEmpty())
    }
    @Test fun lateCloseFailureRetainsJournalAndNeverRecloses() {
        val h = Harness(); h.select()
        val broken = IllegalStateException("PUBLIC close uncertain")
        h.source.closeFailure = broken
        assertEquals("unknown", h.send()["disposition"])
        repeat(2) { h.business.read(emptyMap()) }
        assertSame(broken, h.business.retainedFailure())
        assertEquals(1, h.source.closes); assertEquals(1, h.native.retires)
        assertEquals("UNKNOWN", h.store.only().getString("status")); assertTrue(h.business.hasRetainedWork())
    }
    @Test fun unsupportedReplyAndWrongStoreAccountDoNotCreateAuthority() {
        val h = Harness(); h.select()
        val command = h.command() + ("replyToMessageId" to "PUBLIC-old-message")
        assertEquals("UNAVAILABLE", h.business.execute(command, h.context(command))["code"])
        assertTrue(h.store.saved.isEmpty()); assertEquals(0, h.source.prepares)
        h.store.savedState = JSONObject().put("version", 1).put("account", "PUBLIC-another-account")
            .put("revision", 0).put("active", JSONObject.NULL).toString()
        try { h.binding.projection(); fail("wrong account published") } catch (_: IllegalArgumentException) {}
        assertEquals(0, h.source.prepares); assertTrue(h.methods.isEmpty())
    }
    @Test fun failedIncomingDownloadKeepsExactFailureAtOriginalOwner() {
        val store = MemoryStore(); val source = Source()
        val missing = java.io.IOException("PUBLIC receive download interrupted")
        var downloads = 0
        val client = okhttp3.OkHttpClient.Builder().followRedirects(false).followSslRedirects(false)
            .retryOnConnectionFailure(false).addInterceptor { downloads++; throw missing }.build()
        val courier = VeilMatrixCiphertextHttpTransport.control("https://qa.invalid/", "PUBLIC-token".toCharArray(), client)
        val binding = VeilMatrixProductBinding.control(source, store, courier)
        var captured: VeilNativeMessageBusiness.Message? = null
        try {
            binding.incoming("PUBLIC-peer", "$" + "interrupted-event", "@bob:qa.invalid",
                VeilMatrixCiphertextHttpTransport.Content("00000000-0000-4000-8000-000000000003", 2,
                    "mxc://remote.invalid/opaque", "a".repeat(64), 4)) { captured = it }
            fail("download unexpectedly succeeded")
        } catch (error: java.io.IOException) { assertSame(missing, error) }
        assertNotNull(captured)
        assertEquals("UNKNOWN", store.only().getString("status"))
        assertEquals(VeilNativeMessageBusiness.Completion.UNKNOWN, checkNotNull(captured).completion())
        assertEquals(1, downloads); assertEquals(0, source.prepares)
        assertTrue(binding.hasRetainedWork())
    }

    private fun syncEvent(id: String = "00000000-0000-4000-8000-000000000009",
                          sender: String = "@bob:qa.invalid"): JSONObject {
        val bytes = byteArrayOf(0x44, 1, 2, 3)
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it.toInt() and 255) }
        val content = JSONObject().put("version", 2).put("suite", VeilMatrixCiphertextHttpTransport.SUITE)
            .put("ciphertext_type", 2).put("sender_message_id", id)
            .put("ciphertext", JSONObject().put("url", "mxc://qa.invalid/opaque")
                .put("sha256", digest).put("size", bytes.size))
        return JSONObject().put("type", VeilMatrixCiphertextHttpTransport.EVENT)
            .put("event_id", "$" + "incoming-sync").put("sender", sender).put("content", content)
    }
    @Test fun normalReadFetchesSyncAndAdvancesOnlyAfterNativeAndJournalClose() {
        val h = Harness(); h.select()
        h.syncEvents.put(syncEvent())
        h.checkBeforeHttp = {
            assertFalse(h.store.transactionOpen)
            assertFalse(JSONObject(checkNotNull(h.store.savedState)).has("syncCursor"))
            if (h.store.saved.isNotEmpty()) {
                val saved = JSONObject(checkNotNull(h.store.savedState))
                assertEquals(1, saved.getJSONArray("syncQueue").length())
                assertEquals("PREPARED", h.store.only().getString("status"))
            }
        }
        val view = h.business.read(emptyMap())
        assertEquals("AUTHORIZED", view["kind"])
        assertEquals("PUBLIC reply", ((view["messages"] as List<*>).single() as Map<*, *>)["body"])
        val persisted = JSONObject(checkNotNull(h.store.savedState))
        assertEquals("PUBLIC-sync-next", persisted.getString("syncCursor"))
        assertEquals(0, persisted.getJSONArray("syncQueue").length())
        assertEquals("CLOSED", h.store.only().getString("status"))
        assertEquals(1, h.source.verifies); assertEquals(1, h.source.closes); assertEquals(1, h.native.retires)
        assertEquals(listOf("GET", "GET"), h.methods); assertEquals(listOf<String?>(null), h.syncSince)
    }
    @Test fun syncNativeRefusalKeepsOriginalQueueAndOldCursor() {
        val h = Harness(); h.select(); h.syncEvents.put(syncEvent())
        h.source.commitFailure = IllegalStateException("PUBLIC Native did not commit")
        assertEquals("RECOVERY_REQUIRED", h.business.read(emptyMap())["kind"])
        val saved = JSONObject(checkNotNull(h.store.savedState))
        assertFalse(saved.has("syncCursor")); assertEquals(1, saved.getJSONArray("syncQueue").length())
        assertEquals("UNKNOWN", h.store.only().getString("status"))
        h.business.read(emptyMap())
        assertEquals(1, h.source.prepares); assertEquals(0, h.source.closes)
        assertEquals(listOf("GET", "GET"), h.methods)
    }
    @Test fun syncFinalStoreFailureCannotAcknowledgeCursor() {
        val h = Harness(); h.select(); h.syncEvents.put(syncEvent()); h.store.failStatus = "CLOSED"
        assertEquals("RECOVERY_REQUIRED", h.business.read(emptyMap())["kind"])
        val saved = JSONObject(checkNotNull(h.store.savedState))
        assertFalse(saved.has("syncCursor")); assertEquals(1, saved.getJSONArray("syncQueue").length())
        assertEquals("UNKNOWN", h.store.only().getString("status"))
        assertSame(h.store.storeFailure, h.business.retainedFailure())
    }
    @Test fun exactSelfEchoAcknowledgesWithoutNativeReexecutionOrDeliveryClaim() {
        val h = Harness(); h.select(); h.send()
        val event = JSONObject().put("type", VeilMatrixCiphertextHttpTransport.EVENT)
            .put("event_id", "$" + "PUBLIC-event").put("sender", "@alice:qa.invalid")
            .put("content", checkNotNull(h.content))
        h.syncEvents.put(event)
        h.binding.nextIncoming { fail("self echo must not be decrypted again") }
        assertEquals("PUBLIC-sync-next", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
        assertEquals(1, h.source.prepares); assertEquals(1, h.native.executes)
        assertEquals("unconfirmed", ((h.binding.projection()["messages"] as List<*>).single() as Map<*, *>)["delivery"])
    }
    @Test fun duplicateConflictRetainsQueueWithoutNewNativeCall() {
        val h = Harness(); h.select(); h.send()
        val altered = JSONObject(checkNotNull(h.content).toString())
        altered.getJSONObject("ciphertext").put("sha256", "f".repeat(64))
        h.syncEvents.put(JSONObject().put("type", VeilMatrixCiphertextHttpTransport.EVENT)
            .put("event_id", "$" + "PUBLIC-event").put("sender", "@alice:qa.invalid").put("content", altered))
        try { h.binding.nextIncoming { fail("conflict captured") }; fail("conflict accepted") }
        catch (error: IllegalStateException) { assertEquals("VEIL_MATRIX_SYNC_ORIGINAL_CONFLICT", error.message) }
        val saved = JSONObject(checkNotNull(h.store.savedState))
        assertFalse(saved.has("syncCursor")); assertEquals(1, saved.getJSONArray("syncQueue").length())
        assertEquals(1, h.source.prepares)
    }
    @Test fun limitedTimelinePreservesExactGapAndDoesNotPretendFullHistory() {
        val h = Harness(); h.select(); h.syncEvents.put(syncEvent()); h.syncLimited = true
        h.binding.nextIncoming { fail("gap must not be crossed") }
        val error = h.binding.retainedSyncFailure() as VeilMatrixCiphertextHttpTransport.SyncGap
        assertEquals("PUBLIC-prev-gap", error.previous)
        val state = JSONObject(checkNotNull(h.store.savedState))
        assertFalse(state.has("syncCursor"))
        val gap = state.getJSONObject("syncGap")
        val room = gap.getJSONArray("rooms").getJSONObject(0)
        assertEquals("!room:qa.invalid", room.getString("room"))
        assertEquals("PUBLIC-prev-gap", room.getString("previous"))
        assertEquals("PUBLIC-sync-next", gap.getString("next"))
        assertEquals(1, gap.getJSONArray("tail").length())
        assertEquals(0, h.source.prepares); assertTrue(h.store.saved.isEmpty())
    }
    @Test fun emptyBatchResumesOpaqueCursorAndReadOnlyNetworkFailureCanRecover() {
        val h = Harness(); h.select()
        h.failureOn = "GET"
        assertEquals("AUTHORIZED", h.business.read(emptyMap())["kind"])
        assertNotNull(h.binding.retainedSyncFailure())
        assertFalse(JSONObject(checkNotNull(h.store.savedState)).has("syncCursor"))
        h.failureOn = null
        assertEquals("AUTHORIZED", h.business.read(emptyMap())["kind"])
        assertNull(h.binding.retainedSyncFailure())
        assertEquals("PUBLIC-sync-next", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
        h.syncNext = "PUBLIC-sync-after"
        assertEquals("AUTHORIZED", h.business.read(emptyMap())["kind"])
        assertEquals("PUBLIC-sync-next", h.syncSince.last())
        assertEquals("PUBLIC-sync-after", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
        assertEquals(0, h.source.prepares); assertTrue(h.store.saved.isEmpty())
    }

    private fun beginHistoryGap(h: Harness): JSONObject {
        h.select()
        val anchor = syncEvent("00000000-0000-4000-8000-000000000090")
            .put("event_id", "$" + "history-anchor").put("room_id", "!room:qa.invalid")
        h.syncEvents.put(anchor)
        assertEquals("AUTHORIZED", h.business.read(emptyMap())["kind"])
        assertEquals("CLOSED", h.store.only().getString("status"))
        h.syncEvents = org.json.JSONArray().put(syncEvent())
        h.syncNext = "PUBLIC-sync-tail"; h.syncLimited = true
        assertEquals("AUTHORIZED", h.business.read(emptyMap())["kind"])
        assertEquals("PUBLIC-sync-next", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
        return anchor
    }
    private fun historyEvent(last: String, label: String) =
        syncEvent("00000000-0000-4000-8000-0000000000$last")
            .put("event_id", "$" + label).put("room_id", "!room:qa.invalid")
    @Test fun backwardPagesAndEmptyPageRestoreExactBoundaryBeforeNativeAndCursor() {
        val h = Harness(); val anchor = beginHistoryGap(h)
        val first = historyEvent("10", "first")
        val second = historyEvent("11", "second")
        val third = historyEvent("12", "third")
        h.historyEnd = "PUBLIC-empty-end"
        assertEquals("AUTHORIZED", h.business.read(emptyMap())["kind"])
        assertEquals(1, h.source.prepares)
        h.historyEvents = org.json.JSONArray().put(third).put(second)
        h.historyEnd = "PUBLIC-older-end"
        assertEquals("AUTHORIZED", h.business.read(emptyMap())["kind"])
        assertEquals(1, h.source.prepares) // No reverse-order decryption while the gap is open.
        val midway = JSONObject(checkNotNull(h.store.savedState))
        assertEquals(0, midway.optJSONArray("syncQueue")?.length() ?: 0)
        assertEquals("PUBLIC-sync-next", midway.getString("syncCursor"))
        val restored = VeilMatrixProductBinding.control(h.source, h.store, h.courier)
        val native = Native(h.store)
        val business = VeilNativeMessageBusiness.control(native, restored)
        h.historyEvents = org.json.JSONArray().put(first).put(anchor); h.historyEnd = null
        assertEquals("AUTHORIZED", business.read(emptyMap())["kind"])
        val pending = JSONObject(checkNotNull(h.store.savedState))
        assertTrue(pending.has("syncGap")); assertEquals(0, pending.getJSONArray("syncQueue").length())
        assertEquals("PUBLIC-sync-next", pending.getString("syncCursor"))
        drainHistory(h, business)
        val complete = JSONObject(checkNotNull(h.store.savedState))
        assertFalse(complete.has("syncGap"))
        assertEquals("PUBLIC-sync-tail", complete.getString("syncCursor"))
        assertEquals(listOf("PUBLIC-prev-gap", "PUBLIC-empty-end", "PUBLIC-older-end"), h.historyFrom)
        assertEquals(2, h.syncSince.size) // The captured limited tail was not fetched again.
        assertEquals(5, h.source.prepares); assertEquals(4, native.executes)
        val ids = (restored.projection()["messages"] as List<*>).map { (it as Map<*, *>)["id"] }
        assertEquals(listOf("90", "10", "11", "12", "09").map {
            "00000000-0000-4000-8000-0000000000$it" }, ids)
    }
    @Test fun missingEndWithoutOriginalBoundaryIsUnavailableNotGapCompletion() {
        val h = Harness(); beginHistoryGap(h)
        h.historyEvents.put(historyEvent("13", "not-the-boundary")); h.historyEnd = null
        assertEquals("UNAVAILABLE", h.business.read(emptyMap())["kind"])
        val state = JSONObject(checkNotNull(h.store.savedState))
        assertEquals("PUBLIC-sync-next", state.getString("syncCursor"))
        assertEquals("VEIL_MATRIX_HISTORY_UNAVAILABLE", state.getJSONObject("syncGap").getString("failure"))
        assertEquals(1, h.source.prepares)
        val calls = h.methods.size
        val restored = VeilMatrixProductBinding.control(h.source, h.store, h.courier)
        assertEquals("UNAVAILABLE", VeilNativeMessageBusiness.control(Native(h.store), restored).read(emptyMap())["kind"])
        assertEquals(calls, h.methods.size)
    }
    @Test fun initialLimitedTimelineDoesNotInventAnExistingHistoryBoundary() {
        val h = Harness(); h.select(); h.syncLimited = true; h.syncEvents.put(syncEvent())
        h.business.read(emptyMap())
        assertEquals("UNAVAILABLE", h.business.read(emptyMap())["kind"])
        val state = JSONObject(checkNotNull(h.store.savedState))
        assertFalse(state.has("syncCursor")); assertEquals(0, h.historyFrom.size)
        assertEquals("VEIL_MATRIX_HISTORY_BOUNDARY_REQUIRED", state.getJSONObject("syncGap").getString("failure"))
        assertEquals(0, h.source.prepares)
    }
    @Test fun opaqueHistoryCycleRetainsFirstGapAndNeverExecutesNative() {
        val h = Harness(); beginHistoryGap(h)
        h.historyEnd = "PUBLIC-middle"; h.business.read(emptyMap())
        h.historyEnd = "PUBLIC-prev-gap"
        assertEquals("UNAVAILABLE", h.business.read(emptyMap())["kind"])
        val state = JSONObject(checkNotNull(h.store.savedState))
        val gap = state.getJSONObject("syncGap")
        assertTrue(gap.has("failure")); assertEquals("PUBLIC-sync-next", state.getString("syncCursor"))
        assertEquals("PUBLIC-middle", gap.getJSONArray("rooms").getJSONObject(0).getString("from"))
        assertEquals(1, h.source.prepares)
        val first = h.business.retainedFailure()
        h.business.read(emptyMap()); assertSame(first, h.business.retainedFailure())
        assertEquals(2, h.historyFrom.size)
    }
    @Test fun historyDuplicateWithDifferentContentDoesNotReplaceBoundary() {
        val h = Harness(); val anchor = beginHistoryGap(h)
        val conflict = JSONObject(anchor.toString())
        conflict.getJSONObject("content").getJSONObject("ciphertext").put("sha256", "f".repeat(64))
        h.historyEvents.put(conflict); h.historyEnd = null
        assertEquals("UNAVAILABLE", h.business.read(emptyMap())["kind"])
        assertEquals("CLOSED", h.store.only().getString("status"))
        assertEquals(1, h.source.prepares)
        assertEquals("PUBLIC-sync-next", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
        assertEquals("VEIL_MATRIX_HISTORY_EVENT_CONFLICT", h.business.retainedFailure()?.message)
    }
    @Test fun exactContiguousPageOverlapIsNotDecryptedTwice() {
        val h = Harness(); val anchor = beginHistoryGap(h)
        val one = historyEvent("14", "one")
        val two = historyEvent("15", "two")
        h.historyEvents = org.json.JSONArray().put(two); h.historyEnd = "PUBLIC-overlap"
        h.business.read(emptyMap())
        h.historyEvents = org.json.JSONArray().put(two).put(one).put(anchor); h.historyEnd = null
        h.business.read(emptyMap())
        drainHistory(h)
        assertEquals(4, h.source.prepares)
        assertEquals("PUBLIC-sync-tail", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
    }
    @Test fun historyNativeAndFinalStoreRefusalKeepConnectedGapAndOldCursor() {
        for (nativeFailure in listOf(true, false)) {
            val h = Harness(); val anchor = beginHistoryGap(h)
            h.historyEvents = org.json.JSONArray().put(historyEvent("16", "refusal")).put(anchor)
            if (nativeFailure) h.source.commitFailure = IllegalStateException("PUBLIC history Native refused")
            else h.store.failStatus = "CLOSED"
            assertEquals("RECOVERY_REQUIRED", h.business.read(emptyMap())["kind"])
            val state = JSONObject(checkNotNull(h.store.savedState))
            assertEquals("PUBLIC-sync-next", state.getString("syncCursor"))
            assertTrue(state.getJSONObject("syncGap").getJSONArray("rooms").getJSONObject(0).getBoolean("connected"))
            assertEquals(1, state.getJSONArray("syncQueue").length())
            val failed = JSONObject(checkNotNull(h.store.saved["00000000-0000-4000-8000-000000000016"]))
            assertEquals("UNKNOWN", failed.getString("status"))
            h.business.read(emptyMap()); assertEquals(2, h.source.prepares)
            assertEquals(1, h.historyFrom.size)
        }
    }
    @Test fun historyReadNetworkFailureKeepsOriginalPageAndNextNormalReadCanRecover() {
        val h = Harness(); val anchor = beginHistoryGap(h)
        h.failureOn = "GET"
        assertEquals("AUTHORIZED", h.business.read(emptyMap())["kind"])
        assertTrue(h.binding.retainedSyncFailure() is java.io.IOException)
        h.failureOn = null; h.historyEvents = org.json.JSONArray().put(anchor)
        assertEquals("AUTHORIZED", h.business.read(emptyMap())["kind"])
        drainHistory(h)
        assertEquals(2, h.source.prepares)
        assertEquals("PUBLIC-sync-tail", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
        assertEquals(listOf("PUBLIC-prev-gap"), h.historyFrom)
    }
    private fun drainHistory(h: Harness, business: VeilNativeMessageBusiness = h.business) {
        repeat(512) {
            if (!JSONObject(checkNotNull(h.store.savedState)).has("syncGap")) return
            assertEquals("AUTHORIZED", business.read(emptyMap())["kind"])
            assertTrue((JSONObject(checkNotNull(h.store.savedState)).optJSONArray("syncQueue")?.length() ?: 0) <= 128)
        }
        fail("PUBLIC bounded test calls did not finish the protected original history")
    }
    private fun longHistoryEvent(number: Int) = syncEvent("10000000-0000-4000-8000-" + number.toString().padStart(12, '0'))
        .put("event_id", "$" + "long-history-$number").put("room_id", "!room:qa.invalid")
    @Test fun moreThan128EventsAnd32PagesRecoverAcrossProtectedSegmentReconstruction() {
        val h = Harness(); val anchor = beginHistoryGap(h)
        var binding = h.binding
        var native = h.native
        var business = h.business
        repeat(34) { page ->
            h.historyEvents = org.json.JSONArray()
            for (number in (170 - page * 5) downTo (166 - page * 5)) h.historyEvents.put(longHistoryEvent(number))
            if (page == 33) h.historyEvents.put(anchor)
            h.historyEnd = if (page == 33) null else "PUBLIC-long-page-$page"
            assertEquals("AUTHORIZED", business.read(emptyMap())["kind"])
            assertEquals("PUBLIC-sync-next", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
            if (page < 33) assertEquals(1, h.source.prepares)
            if (page == 17) {
                assertTrue(h.store.history.isNotEmpty())
                binding = VeilMatrixProductBinding.control(h.source, h.store, h.courier)
                native = Native(h.store)
                business = VeilNativeMessageBusiness.control(native, binding)
            }
        }
        assertEquals(34, h.historyFrom.size)
        val inFlight = JSONObject(checkNotNull(h.store.savedState))
        assertTrue(inFlight.has("syncGap"))
        assertEquals(4, inFlight.getJSONArray("syncQueue").length())
        val before = h.historyFrom.size
        drainHistory(h, business)
        assertEquals(before, h.historyFrom.size)
        assertEquals(172, h.source.prepares)
        assertEquals("PUBLIC-sync-tail", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
        assertTrue(h.store.history.isEmpty()) // Only actual CLOSED segments were released.
        val ids = (binding.projection()["messages"] as List<*>).map { (it as Map<*, *>)["id"] }
        assertEquals(172, ids.size)
        assertEquals((1..170).map { "10000000-0000-4000-8000-" + it.toString().padStart(12, '0') }, ids.drop(1).dropLast(1))
        assertEquals(171, native.executes)
    }
    @Test fun conflictWithAnEarlierPersistedSegmentIsRejectedAfterReconstruction() {
        val h = Harness(); beginHistoryGap(h)
        val original = longHistoryEvent(50)
        h.historyEvents = org.json.JSONArray().put(original); h.historyEnd = "PUBLIC-one"
        h.business.read(emptyMap())
        h.historyEvents = org.json.JSONArray().put(longHistoryEvent(49)); h.historyEnd = "PUBLIC-two"
        h.business.read(emptyMap())
        val conflict = JSONObject(original.toString())
        conflict.getJSONObject("content").getJSONObject("ciphertext").put("sha256", "f".repeat(64))
        h.historyEvents = org.json.JSONArray().put(conflict); h.historyEnd = "PUBLIC-three"
        val binding = VeilMatrixProductBinding.control(h.source, h.store, h.courier)
        val business = VeilNativeMessageBusiness.control(Native(h.store), binding)
        assertEquals("UNAVAILABLE", business.read(emptyMap())["kind"])
        assertEquals("VEIL_MATRIX_HISTORY_EVENT_CONFLICT", business.retainedFailure()?.message)
        assertEquals(1, h.source.prepares)
        assertEquals("PUBLIC-sync-next", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
    }
    @Test fun conflictWithOriginalLimitedTailCannotBeHiddenInAnOlderPage() {
        val h = Harness(); beginHistoryGap(h)
        val altered = JSONObject(h.syncEvents.getJSONObject(0).toString()).put("room_id", "!room:qa.invalid")
        altered.getJSONObject("content").getJSONObject("ciphertext").put("size", 99)
        h.historyEvents.put(longHistoryEvent(60)); h.historyEnd = "PUBLIC-tail-check"
        h.business.read(emptyMap())
        h.historyEvents = org.json.JSONArray().put(altered); h.historyEnd = "PUBLIC-conflict"
        assertEquals("UNAVAILABLE", h.business.read(emptyMap())["kind"])
        assertEquals(1, h.source.prepares)
        assertEquals("PUBLIC-sync-next", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
    }
    @Test fun moreThan32EmptyPagesKeepTokensAndDetectOldCycleAcrossReconstruction() {
        val h = Harness(); beginHistoryGap(h)
        repeat(34) { page ->
            h.historyEnd = "PUBLIC-empty-$page"
            assertEquals("AUTHORIZED", h.business.read(emptyMap())["kind"])
        }
        val binding = VeilMatrixProductBinding.control(h.source, h.store, h.courier)
        val business = VeilNativeMessageBusiness.control(Native(h.store), binding)
        h.historyEnd = "PUBLIC-empty-0"
        assertEquals("UNAVAILABLE", business.read(emptyMap())["kind"])
        assertEquals("VEIL_MATRIX_HISTORY_CURSOR_CYCLE", business.retainedFailure()?.message)
        assertEquals(1, h.source.prepares)
        assertEquals("PUBLIC-sync-next", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
    }
    @Test fun trueCapacityHasRecoverableStatusWithoutDiscardingSegmentsOrGrantingSuccess() {
        val h = Harness(); val anchor = beginHistoryGap(h)
        h.historyEvents.put(longHistoryEvent(1)); h.historyEnd = "PUBLIC-capacity-next"
        h.store.historyLimitBytes = h.store.history.values.sumOf { it.toByteArray().size.toLong() }
        val held = h.store.history.toMap()
        val view = h.business.read(emptyMap())
        assertEquals("UNAVAILABLE", view["kind"])
        assertEquals(listOf("SOCIAL_STORAGE_CAPACITY"), view["gaps"])
        assertNull(h.business.retainedFailure())
        assertEquals(held, h.store.history)
        val saved = JSONObject(checkNotNull(h.store.savedState))
        assertEquals("SOCIAL_STORAGE_CAPACITY", saved.getJSONObject("syncGap").getString("capacity"))
        assertFalse(saved.getJSONObject("syncGap").has("failure"))
        assertEquals("PUBLIC-sync-next", saved.getString("syncCursor"))
        h.store.historyLimitBytes = Long.MAX_VALUE
        val restored = VeilMatrixProductBinding.control(h.source, h.store, h.courier)
        val business = VeilNativeMessageBusiness.control(Native(h.store), restored)
        assertEquals("AUTHORIZED", business.read(emptyMap())["kind"])
        h.historyEvents = org.json.JSONArray().put(anchor); h.historyEnd = null
        assertEquals("AUTHORIZED", business.read(emptyMap())["kind"])
        drainHistory(h, business)
        assertEquals(3, h.source.prepares)
        assertTrue(h.store.history.isEmpty())
        assertEquals(listOf("PUBLIC-prev-gap", "PUBLIC-prev-gap", "PUBLIC-capacity-next"), h.historyFrom)
    }
    @Test fun segmentStoreWriteFailureIsNotReclassifiedAsRecoverableCapacity() {
        val h = Harness(); beginHistoryGap(h)
        val protected = h.store.history.toMap()
        h.store.failHistoryWrites = true
        h.historyEvents.put(longHistoryEvent(1)); h.historyEnd = "PUBLIC-store-failure"
        assertEquals("UNAVAILABLE", h.business.read(emptyMap())["kind"])
        assertSame(h.store.storeFailure, h.business.retainedFailure())
        assertEquals(protected, h.store.history)
        val state = JSONObject(checkNotNull(h.store.savedState))
        assertTrue(state.getJSONObject("syncGap").has("failure"))
        assertEquals("PUBLIC-sync-next", state.getString("syncCursor"))
        assertEquals(1, h.source.prepares)
    }
    @Test fun committedEarlierSegmentDoesNotAdvanceGlobalCursorWhenLaterNativeFails() {
        val h = Harness(); val anchor = beginHistoryGap(h)
        h.historyEvents = org.json.JSONArray().put(longHistoryEvent(2)); h.historyEnd = "PUBLIC-before-oldest"
        h.business.read(emptyMap())
        h.historyEvents = org.json.JSONArray().put(longHistoryEvent(1)).put(anchor); h.historyEnd = null
        h.business.read(emptyMap())
        assertEquals(2, h.source.prepares)
        assertEquals("PUBLIC-sync-next", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
        h.source.commitFailure = IllegalStateException("PUBLIC later segment Native refusal")
        assertEquals("RECOVERY_REQUIRED", h.business.read(emptyMap())["kind"])
        assertEquals("PUBLIC-sync-next", JSONObject(checkNotNull(h.store.savedState)).getString("syncCursor"))
        assertTrue(h.store.history.isNotEmpty())
        assertEquals("CLOSED", JSONObject(checkNotNull(h.store.saved["10000000-0000-4000-8000-000000000001"])).getString("status"))
        assertEquals("UNKNOWN", JSONObject(checkNotNull(h.store.saved["10000000-0000-4000-8000-000000000002"])).getString("status"))
    }
    @Test fun failedSegmentReleaseRollsBackCursorQueueAndOriginalJournalClose() {
        val h = Harness(); val anchor = beginHistoryGap(h)
        h.historyEvents = org.json.JSONArray().put(longHistoryEvent(1)).put(anchor); h.historyEnd = null
        h.store.failHistoryRemoval = true
        assertEquals("RECOVERY_REQUIRED", h.business.read(emptyMap())["kind"])
        assertSame(h.store.storeFailure, h.business.retainedFailure())
        val state = JSONObject(checkNotNull(h.store.savedState))
        assertEquals("PUBLIC-sync-next", state.getString("syncCursor"))
        assertEquals(1, state.getJSONArray("syncQueue").length())
        assertTrue(state.getJSONObject("syncGap").has("activePage"))
        assertTrue(h.store.history.isNotEmpty())
        assertEquals("UNKNOWN", JSONObject(checkNotNull(h.store.saved["10000000-0000-4000-8000-000000000001"])).getString("status"))
    }


    @Test fun closeInspectionCurrentFailureRetainsOriginalWithoutThrowingOrRetry() {
        val h = Harness(); h.source.stopped = true
        assertTrue(h.binding.hasRetainedWork())
        val first = checkNotNull(h.binding.retainedCloseFailure())
        assertEquals("PUBLIC device revoked", first.message)
        h.source.stopped = false
        val checks = h.source.checks
        assertTrue(h.binding.hasRetainedWork())
        assertSame(first, h.binding.retainedCloseFailure())
        assertEquals(checks, h.source.checks)
        assertEquals(0, h.source.prepares); assertEquals(0, h.source.closes)
        assertTrue(h.methods.isEmpty()); assertTrue(h.store.saved.isEmpty())
    }
    @Test fun closeInspectionProducerFailureKeepsExactCauseAndDoesNotReleaseCustody() {
        val h = Harness()
        val first = IllegalStateException("PUBLIC producer ownership unknown")
        h.source.custodyFailure = first
        assertTrue(h.binding.hasRetainedWork())
        assertSame(first, h.binding.retainedCloseFailure())
        h.source.custodyFailure = IllegalStateException("PUBLIC later observation")
        assertTrue(h.binding.hasRetainedWork())
        assertSame(first, h.binding.retainedCloseFailure())
        assertEquals(0, h.source.closes); assertEquals(0, h.native.retires)
    }
    @Test fun closeInspectionStoreFailureDoesNotPretendThereAreNoOriginals() {
        val h = Harness(); h.store.failOperationRead = true
        assertTrue(h.binding.hasRetainedWork())
        assertSame(h.store.storeFailure, h.binding.retainedCloseFailure())
        h.store.failOperationRead = false
        assertTrue(h.binding.hasRetainedWork())
        assertSame(h.store.storeFailure, h.binding.retainedCloseFailure())
        assertEquals(0, h.source.closes); assertEquals(0, h.native.retires)
    }
    @Test fun closeInspectionKeepsPriorNativeUnknownWithoutFreshAuthorityObservation() {
        val h = Harness(); h.select()
        val original = IllegalStateException("PUBLIC Native commit unknown")
        h.source.commitFailure = original
        assertEquals("unknown", h.send()["disposition"])
        val checks = h.source.checks
        assertTrue(h.binding.hasRetainedWork())
        assertSame(original, h.binding.retainedCloseFailure())
        assertEquals(checks, h.source.checks)
        assertEquals("UNKNOWN", h.store.only().getString("status"))
        assertEquals(0, h.source.closes); assertEquals(0, h.native.retires)
    }
    @Test fun cleanCloseInspectionIsReadOnlyAndNotANativeRelease() {
        val h = Harness()
        assertFalse(h.binding.hasRetainedWork())
        assertNull(h.binding.retainedCloseFailure())
        assertEquals(0, h.source.prepares); assertEquals(0, h.source.closes)
        assertEquals(0, h.native.executes); assertEquals(0, h.native.retires)
        assertTrue(h.methods.isEmpty()); assertNull(h.store.savedState)
    }
    @Test fun wrongWorkerCannotInspectOrReplaceOriginalCloseFailure() {
        val h = Harness()
        var caught: Throwable? = null
        val thread = Thread { try { h.binding.hasRetainedWork() } catch (error: Throwable) { caught = error } }
        thread.start(); thread.join()
        assertEquals("VEIL_PRODUCT_WRONG_WORKER", caught?.message)
        assertNull(h.binding.retainedCloseFailure())
        assertFalse(h.binding.hasRetainedWork())
    }


    @Test fun cachedDeliveryValidationUsesCurrentWithoutPollingOrSending() {
        val h = Harness()
        val checks = h.source.checks
        h.business.requireDeliveryCurrent()
        assertEquals(checks + 1, h.source.checks)
        assertTrue(h.methods.isEmpty()); assertNull(h.store.savedState)
        assertEquals(0, h.source.prepares); assertEquals(0, h.native.executes)
        assertEquals(0, h.source.closes); assertEquals(0, h.native.retires)
    }
    @Test fun startupProjectionUsesCurrentOriginalWithoutPollingOrSending() {
        val h = Harness()
        h.business.requireStartupProjection()
        assertTrue(h.source.checks > 0)
        assertTrue(h.methods.isEmpty())
        assertEquals(0, h.source.prepares); assertEquals(0, h.native.executes)
    }
    @Test fun startupProjectionCannotMaskAnOriginalNativeFailure() {
        val h = Harness(); h.select()
        val original = IllegalStateException("PUBLIC prior Native unknown")
        h.source.commitFailure = original; h.send()
        try { h.business.requireStartupProjection(); fail("UNKNOWN startup accepted") }
        catch (error: Throwable) { assertSame(original, error) }
        assertEquals("UNKNOWN", h.store.only().getString("status"))
        assertEquals(1, h.source.prepares); assertEquals(0, h.source.closes)
    }

}

/** PUBLIC result/publication controls, not a genuine Native factory or login. */
class VeilSocialLoginProductStartTest {
    private fun invoke(current: () -> Boolean, start: () -> VeilCryptoEngineOwner.ProductStartObservation) =
        VeilSocialLoginCoordinator.consumeProductStartObservation(current, start)
    @Test fun absentOwningFactoryRemainsExplicitlyRequired() {
        assertEquals("ENROLLMENT_ACCEPTED_PRODUCT_SOURCE_REQUIRED",
            invoke({ true }) { VeilCryptoEngineOwner.ProductStartObservation.NATIVE_SOURCE_REQUIRED })
    }
    @Test fun actualFactoryObservationPublishesOnlyAfterBothPublicationChecks() {
        var checks = 0; var starts = 0
        assertEquals("NATIVE_PRODUCT_ATTACHED_OBSERVED", invoke({ checks++; true }) {
            starts++; VeilCryptoEngineOwner.ProductStartObservation.ATTACHED_OBSERVED
        })
        assertEquals(2, checks); assertEquals(1, starts)
    }
    @Test fun cancellationBeforeConsumptionDoesNotStartOrAcquireAgain() {
        var starts = 0
        try { invoke({ false }) { starts++; VeilCryptoEngineOwner.ProductStartObservation.ATTACHED_OBSERVED }
            fail("cancelled start published")
        } catch (error: IllegalStateException) { assertEquals("VEIL_LOGIN_PUBLICATION_NOT_CURRENT", error.message) }
        assertEquals(0, starts)
    }
    @Test fun lateCancellationDoesNotPublishOrPretendConsumedOriginalWasUndone() {
        var checks = 0; var retainedOriginal = 0
        try { invoke({ ++checks == 1 }) {
            retainedOriginal++; VeilCryptoEngineOwner.ProductStartObservation.ATTACHED_OBSERVED
        }; fail("late cancelled start published")
        } catch (error: IllegalStateException) { assertEquals("VEIL_LOGIN_PUBLICATION_NOT_CURRENT", error.message) }
        assertEquals(1, retainedOriginal); assertEquals(2, checks)
    }
    @Test fun originalFactoryFailureIsNotMappedToSuccessOrMissingSource() {
        val original = IllegalStateException("PUBLIC original factory unknown")
        var calls = 0
        try { invoke({ true }) { calls++; throw original }; fail("factory failure swallowed") }
        catch (error: Throwable) { assertSame(original, error) }
        assertEquals(1, calls)
    }
    @Test fun publicationFailureRetainsItsExactCauseAfterOriginalConsumption() {
        val original = IllegalStateException("PUBLIC publication owner closed")
        var checks = 0; var starts = 0
        try { invoke({ if (++checks == 2) throw original else true }) {
            starts++; VeilCryptoEngineOwner.ProductStartObservation.NATIVE_SOURCE_REQUIRED
        }; fail("publication error swallowed")
        } catch (error: Throwable) { assertSame(original, error) }
        assertEquals(1, starts)
    }
}

