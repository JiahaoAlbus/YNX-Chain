package com.ynx.social.matrix

import org.junit.Assert.*
import org.junit.Test
import java.nio.ByteBuffer

/** PUBLIC fixture framing only. Does not load JNI, grant a device or send a message. */
class VeilNativeMessageOutputBindingTest {
    @Test fun closeQueryAfterUnboundInventoryNeedsNoNativeAbi() {
        val ports = VeilNativeProductPorts()
        try {
            ports.read(false)
            fail("PUBLIC JVM fixture must not have a bound Native inventory")
        } catch (original: UnsatisfiedLinkError) {
            assertNotNull(original.message)
            // Query the same object retained after inventory failed. This is
            // not native cleanup, device authority or full Owner-close proof.
            assertFalse(ports.hasRetainedMessages())
            assertFalse(ports.hasRetainedMessages())
        }
    }
    @Test fun closeQueryRetainsPartialAndUnknownLocalCustody() {
        val ports = VeilNativeProductPorts()
        val field = VeilNativeProductPorts::class.java.getDeclaredField("operations")
        field.isAccessible = true
        val map = field.get(ports) as Map<*, *>
        val original = VeilNativeProductPorts.Operation(17L)
        // Test-only PUBLIC local custody entry, not an acquired Native selector
        // or authorized session. No production setter or grant is introduced.
        java.util.Map::class.java
            .getMethod("put", java.lang.Object::class.java, java.lang.Object::class.java)
            .invoke(map, original, true)
        assertNull(original.logical)
        assertTrue(ports.hasRetainedMessages())
        for (code in listOf(16L, 25L)) {
            original.outputStatus = code
            assertTrue(ports.hasRetainedMessages())
            assertEquals(code, original.outputStatus)
            assertEquals(1, map.size)
            assertSame(original, map.keys.single())
        }
    }
    @Test fun closeQueryRejectsWrongWorkerWithoutNativeAbi() {
        val ports = VeilNativeProductPorts()
        val failure = java.util.concurrent.atomic.AtomicReference<Throwable>()
        val other = Thread {
            try { ports.hasRetainedMessages() }
            catch (error: Throwable) { failure.set(error) }
        }
        other.start()
        other.join(2000)
        assertFalse("PUBLIC close query must be finite", other.isAlive)
        assertTrue(failure.get() is IllegalStateException)
        assertEquals("VEIL_PRODUCT_WRONG_WORKER", failure.get().message)
        assertFalse(ports.hasRetainedMessages())
    }
    private val logical = ByteArray(16) { (it + 1).toByte() }
    private fun frame(direction: Int = 2, kind: Int = 1, body: ByteArray = "hello".toByteArray()): ByteArray {
        val b = ByteArray(28 + body.size)
        b[0] = 89; b[1] = 78; b[2] = 88; b[3] = 79
        b[4] = 1; b[5] = direction.toByte(); b[6] = kind.toByte()
        logical.copyInto(b, 8); ByteBuffer.wrap(b, 24, 4).putInt(body.size); body.copyInto(b, 28)
        return b
    }
    private fun refused(body: () -> Unit) {
        try { body(); fail("expected refusal") } catch (_: IllegalArgumentException) {}
    }
    @Test fun exactWrittenRangeAndOwnedCopy() {
        val raw = frame(); val capacity = ByteArray(VeilNativeMessageOutput.MAX_OUTPUT) { 0x7f }
        raw.copyInto(capacity)
        val out = VeilNativeMessageOutput.decode(capacity, raw.size.toLong(), logical, 2)
        capacity.fill(0)
        assertArrayEquals("hello".toByteArray(), out.body())
        val exposed = out.body(); exposed.fill(0)
        assertArrayEquals("hello".toByteArray(), out.body())
        val second = out.duplicate(); assertTrue(out.sameOriginal(second))
        out.close()
        try { out.body(); fail("closed body") } catch (_: IllegalStateException) {}
        assertArrayEquals("hello".toByteArray(), second.body()); second.close()
    }
    @Test fun noDirectionOrLogicalSubstitution() {
        val raw = frame()
        refused { VeilNativeMessageOutput.decode(raw, raw.size.toLong(), logical, 1) }
        val different = logical.copyOf(); different[9] = 42
        refused { VeilNativeMessageOutput.decode(raw, raw.size.toLong(), different, 2) }
        refused { VeilNativeMessageOutput.decode(raw, raw.size.toLong(), ByteArray(16), 2) }
    }
    @Test fun strictMagicVersionKindAndReserved() {
        for (offset in listOf(0, 3, 4, 6, 7)) {
            val raw = frame(); raw[offset] = 5
            refused { VeilNativeMessageOutput.decode(raw, raw.size.toLong(), logical, 2) }
        }
        for (kind in 2..3) {
            val raw = frame(1, kind, byteArrayOf(0x44, 1, 2))
            VeilNativeMessageOutput.decode(raw, raw.size.toLong(), logical, 1).close()
        }
    }
    @Test fun lengthsDoNotParseCapacityOrOverflow() {
        val raw = frame()
        for (written in listOf(-16L, 0L, 28L, raw.size.toLong() + 1, Long.MAX_VALUE))
            refused { VeilNativeMessageOutput.decode(raw, written, logical, 2) }
        val bad = raw.copyOf(); ByteBuffer.wrap(bad, 24, 4).putInt(Int.MAX_VALUE)
        refused { VeilNativeMessageOutput.decode(bad, bad.size.toLong(), logical, 2) }
        val tooMuch = frame(body = ByteArray(65537) { 65 })
        refused { VeilNativeMessageOutput.decode(tooMuch, tooMuch.size.toLong(), logical, 2) }
        val trailing = raw + byteArrayOf(1)
        refused { VeilNativeMessageOutput.decode(trailing, trailing.size.toLong(), logical, 2) }
    }
    @Test fun malformedUtf8RefusedAndRepeatedReadUnchanged() {
        val invalid = frame(body = byteArrayOf(0xc0.toByte(), 0xaf.toByte()))
        try {
            VeilNativeMessageOutput.decode(invalid, invalid.size.toLong(), logical, 2)
            fail("malformed UTF8")
        } catch (_: java.nio.charset.CharacterCodingException) {}
        val valid = frame(body = byteArrayOf(0xf0.toByte(), 0x9f.toByte(), 0x98.toByte(), 0x80.toByte()))
        val a = VeilNativeMessageOutput.decode(valid, valid.size.toLong(), logical, 2)
        val b = VeilNativeMessageOutput.decode(valid, valid.size.toLong(), logical, 2)
        assertTrue(a.sameOriginal(b)); a.close(); b.close()
    }
}
