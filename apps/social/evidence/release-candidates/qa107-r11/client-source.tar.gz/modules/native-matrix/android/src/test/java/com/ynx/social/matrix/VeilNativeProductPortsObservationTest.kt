package com.ynx.social.matrix

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** PUBLIC shape controls only. These fixtures are not native authorization,
 * qualified signing records, an installed client or a protocol acceptance test. */
class VeilNativeProductPortsObservationTest {
    private fun observation() = JSONObject().put("version", 1)
        .put("kind", "accepted-device-observation").put("account", "qa-account")
        .put("device", "qa-device").put("rootDigest", "1".repeat(64))
        .put("registrationDigest", "2".repeat(64)).put("finalDigest", "3".repeat(64))
        .put("currentDigest", "4".repeat(64)).put("currentSequence", "18446744073709551615")
        .put("revocationCheckpointDigest", "5".repeat(64))
        .put("observedIssuedMS", 1000L).put("observedExpiresMS", 2000L)

    private fun refused(raw: JSONObject) {
        try { VeilNativeProductPorts.decodeAcceptedDevice(raw); fail("invalid observation accepted") }
        catch (_: IllegalArgumentException) { }
    }

    @Test fun exactPublicProjectionPreservesU64WithoutGrant() {
        val raw = observation()
        val result = VeilNativeProductPorts.decodeAcceptedDevice(raw)
        assertEquals("18446744073709551615", result["currentSequence"])
        assertEquals("accepted-device-observation", result["kind"])
        assertEquals(2000L, result["observedExpiresMS"])
        assertFalse(result.containsKey("authorized"))
        raw.put("account", "changed")
        assertEquals("qa-account", result["account"])
    }

    @Test fun rejectsExtraFieldsAndWrongPurpose() {
        refused(observation().put("authorized", true))
        refused(observation().put("privateKey", "not-a-key"))
        refused(observation().put("kind", "AUTHORIZED"))
        refused(observation().put("version", 2))
        refused(observation().apply { remove("currentDigest") })
    }

    @Test fun rejectsDigestAndIdentityConfusion() {
        for (field in listOf("rootDigest", "registrationDigest", "finalDigest",
            "currentDigest", "revocationCheckpointDigest")) {
            refused(observation().put(field, "0".repeat(64)))
            refused(observation().put(field, "A".repeat(64)))
            refused(observation().put(field, "1".repeat(63)))
        }
        for (value in listOf("", "white space", "a".repeat(513), "\u0000", "\u00e9")) {
            refused(observation().put("account", value))
            refused(observation().put("device", value))
        }
    }

    @Test fun rejectsLossyOrNonCanonicalSequence() {
        for (value in listOf("0", "01", "-1", "18446744073709551616", "1".repeat(21)))
            refused(observation().put("currentSequence", value))
        refused(observation().put("currentSequence", 1L))
    }

    @Test fun rejectsInvalidAndUnsafeTimeFieldsWithoutExtendingThem() {
        refused(observation().put("observedIssuedMS", -1L))
        refused(observation().put("observedIssuedMS", 0.5))
        refused(observation().put("observedExpiresMS", 1000L))
        refused(observation().put("observedExpiresMS", 9007199254740992L))
        refused(observation().put("observedExpiresMS", "2000"))
    }

    private fun session() = JSONObject().put("version", 1)
        .put("kind", "protected-message-session-observation").put("device", observation())
        .put("local", JSONObject().put("name", "qa-alice").put("deviceId", 1))
        .put("remote", JSONObject().put("name", "qa-bob").put("deviceId", 2))
        .put("purposeDigest", "6".repeat(64)).put("selectedSessionDigest", "7".repeat(64))
        .put("relationDigest", "8".repeat(64)).put("checkpointDigest", "9".repeat(64))
        .put("relationRevision", "18446744073709551615").put("purposeExpiresMS", 1800L)

    private fun sessionRefused(raw: JSONObject) {
        try { VeilNativeProductPorts.decodeMessageSession(raw); fail("invalid session accepted") }
        catch (_: Exception) { }
    }

    @Test fun protectedSessionPreservesExactPublicBindingsWithoutAuthority() {
        val raw = session()
        val decoded = VeilNativeProductPorts.decodeMessageSession(raw)
        assertEquals("protected-message-session-observation", decoded["kind"])
        assertEquals("18446744073709551615", decoded["relationRevision"])
        assertFalse(decoded.containsKey("sessionKey"))
        raw.getJSONObject("local").put("name", "changed")
        assertEquals("qa-alice", (decoded["local"] as Map<*, *>)["name"])
    }

    @Test fun protectedSessionRejectsMismatchedOrUnsafeProjection() {
        sessionRefused(session().put("kind", "AUTHORIZED"))
        sessionRefused(session().put("sessionKey", "not-a-key"))
        sessionRefused(session().put("remote", session().getJSONObject("local")))
        sessionRefused(session().put("relationDigest", "0".repeat(64)))
        sessionRefused(session().put("relationRevision", "18446744073709551616"))
        sessionRefused(session().put("purposeExpiresMS", 0L))
        sessionRefused(session().put("purposeExpiresMS", 9007199254740992L))
        for (name in listOf("", "\u0000", "\ud800", "\u00e9".repeat(65))) {
            sessionRefused(session().put("local", JSONObject().put("name", name).put("deviceId", 1)))
        }
        for (id in listOf(0, 128)) {
            sessionRefused(session().put("local", JSONObject().put("name", "a").put("deviceId", id)))
        }
        val bounded = session().put("local", JSONObject().put("name", "\u00e9".repeat(64)).put("deviceId", 127))
        assertEquals(127, (VeilNativeProductPorts.decodeMessageSession(bounded)["local"] as Map<*, *>)["deviceId"])
    }
}
