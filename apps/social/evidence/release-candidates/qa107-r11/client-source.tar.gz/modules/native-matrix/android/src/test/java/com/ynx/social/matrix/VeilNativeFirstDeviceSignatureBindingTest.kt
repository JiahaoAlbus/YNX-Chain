package com.ynx.social.matrix

import java.lang.reflect.Modifier
import java.util.Base64

/** PUBLIC codec/binding controls. Old fixture construction is reused, not its test suite.
 * Native owner, HTTP and signatures here are deliberately synthetic, never qualification. */
internal object VeilNativeFirstDeviceSignatureBindingTest {
    private data class Fixture(val prepared: VeilFirstDeviceEnrollmentWire.Prepared,
        val original: VeilCryptoEngineOwner.FirstDeviceIntent,
        val client: VeilSocialLoginClient, val holder: Any) : AutoCloseable {
        override fun close() = client.close()
    }

    private fun fixture(): Fixture {
        val old = Class.forName("com.ynx.social.matrix.VeilSocialLoginClientSourcePhaseTest")
        val factory = old.getDeclaredField("newOriginal").apply { isAccessible = true }
        val create: (VeilFirstDeviceChallengeWire.Request) -> VeilCryptoEngineOwner.FirstDeviceIntent = { request ->
            val constructor = VeilCryptoEngineOwner.FirstDeviceIntent::class.java
                .getDeclaredConstructor(VeilFirstDeviceChallengeWire.Request::class.java).apply { isAccessible = true }
            constructor.newInstance(request)
        }
        factory.set(null, create)
        val type = Class.forName("com.ynx.social.matrix.VeilSocialLoginClientSourcePhaseTest\$Flow")
        val holder = type.getDeclaredConstructor(java.lang.Long.TYPE).apply { isAccessible = true }.newInstance(20000L)
        fun field(name: String): Any = type.getDeclaredField(name).apply { isAccessible = true }.get(holder)
        return Fixture(field("prepared") as VeilFirstDeviceEnrollmentWire.Prepared,
            field("original") as VeilCryptoEngineOwner.FirstDeviceIntent, field("client") as VeilSocialLoginClient, holder)
    }

    private fun parts(p: VeilFirstDeviceEnrollmentWire.Prepared): Array<ByteArray?> = arrayOf(
        ByteArray(64) { 11 }, ByteArray(4627) { 12 }, ByteArray(64) { 13 }, ByteArray(4627) { 14 },
        Base64.getUrlDecoder().decode(p.original.operation.removePrefix("fd1-")),
        Base64.getUrlDecoder().decode(p.original.value("nonce")), p.issuerMessageCopy(), p.targetMessageCopy())

    private fun expect(value: Boolean, label: String) { check(value) { label } }
    private fun rejected(action: () -> Unit) {
        var refused = false
        try { action() } catch (_: IllegalArgumentException) { refused = true }
        catch (_: IllegalStateException) { refused = true }
        expect(refused, "public observation must be refused")
    }

    fun runFinalization() {
        for (mode in listOf("success", "close-error", "cancelled")) fixture().use { f ->
            for (name in listOf("select", "current")) f.holder.javaClass.getDeclaredMethod(name).apply { isAccessible = true }.invoke(f.holder)
            val borrow = f.client.borrowAccountChannel(f.original, f.prepared).also { it.retainNativeFactsUnadmitted() }
            val raw = parts(f.prepared)
            val proofCopies = raw.take(4).map { it!!.copyOf() }
            val observed = VeilNativeAccountChannel.ObservedSignatures.decode(f.prepared, raw)
            val calls = f.holder.javaClass.getDeclaredField("calls").apply { isAccessible = true }.get(f.holder)
            val requestsField = calls.javaClass.getDeclaredField("requests").apply { isAccessible = true }
            fun requests(): List<*> = requestsField.get(calls) as List<*>
            val before = requests().size
            if (mode == "cancelled") {
                f.client.cancelLocal()
                rejected { observed.finalizeOriginal(f.client, f.original, borrow) }
                expect(requests().size == before, "cancelled before effect")
            } else {
                val p = f.prepared
                val response = "{\"revision\":\"${p.revision}\",\"state\":\"committed\",\"operation\":\"${p.original.operation}\",\"identity\":\"${p.identity}\",\"device\":\"${p.device}\",\"deviceAuthorization\":\"REQUIRED\"}"
                val close: () -> Unit = { if (mode == "close-error") throw java.io.IOException("PUBLIC_CLOSE_FAILURE") }
                calls.javaClass.declaredMethods.single { it.name == "plan" && it.parameterCount == 6 }.apply { isAccessible = true }
                    .invoke(calls, "finalize", response, 200, emptyList<String>(), null, close)
                val result = observed.finalizeOriginal(f.client, f.original, borrow)
                if (mode == "success") expect((result as? VeilSocialLoginClient.Outcome.ChallengeState)?.status == "ENROLLMENT_COMMITTED_UNVERIFIED", "HTTP observation never grants device")
                else expect(result is VeilSocialLoginClient.Outcome.Refused, "late response close failure refused")
                expect(requests().size == before + 1, "one finalize request")
                val sent = requests().last() as okhttp3.Request
                expect(sent.url.encodedPath.endsWith("/finalize"), "existing normal route")
                val wire = okio.Buffer().also { checkNotNull(sent.body).writeTo(it) }.readUtf8()
                for (proof in proofCopies) expect(wire.contains(Base64.getUrlEncoder().withoutPadding().encodeToString(proof)), "same held public proof bytes")
                rejected { observed.finalizeOriginal(f.client, f.original, borrow) }
                expect(requests().size == before + 1, "no automatic replay")
            }
            expect(raw.all { it == null }, "original observation copies erased")
            proofCopies.forEach { it.fill(0) }
            println("PASS finalization $mode; PUBLIC scripted response only")
        }
        println("RESULT 3 PASS 0 FAIL; no real service or native signatures")
    }

    fun run() {
        var passed = 0
        val failures = mutableListOf<String>()
        fun control(name: String, body: () -> Unit) {
            try { body(); passed++; println("PASS $name") }
            catch (failure: Throwable) { failures.add(name); println("FAIL $name ${failure.javaClass.simpleName}: ${failure.message}") }
        }
        control("exact eight public parts accepted as observation only") {
            fixture().use { f ->
                val raw = parts(f.prepared)
                VeilNativeAccountChannel.ObservedSignatures.decode(f.prepared, raw).use {
                    expect(it.toString() == "FirstDeviceSignatures[public observation; unverified]", "no authority/string leak")
                }
                expect(raw.all { it == null }, "observation disposed")
            }
        }
        control("close wipes owned copies without mutating prepared wires") {
            fixture().use { f ->
                val issuer = f.prepared.issuerMessageCopy()
                val raw = parts(f.prepared)
                val aliases = raw.map { it!! }
                val observed = VeilNativeAccountChannel.ObservedSignatures.decode(f.prepared, raw)
                observed.close(); observed.close()
                expect(aliases.all { bytes -> bytes.all { it == 0.toByte() } }, "all copies wiped")
                expect(issuer.contentEquals(f.prepared.issuerMessageCopy()), "original prepared retained")
            }
        }
        for ((name, mutate) in listOf<Pair<String, (Array<ByteArray?>) -> Unit>>(
            "wrong original operation" to { it[4]!![0] = (it[4]!![0].toInt() xor 1).toByte() },
            "Source nonce cannot substitute challenge nonce" to { it[5]!![0] = (it[5]!![0].toInt() xor 1).toByte() },
            "issuer classic length" to { it[0] = ByteArray(63) },
            "issuer PQ length" to { it[1] = ByteArray(4626) },
            "target classic length" to { it[2] = ByteArray(65) },
            "target PQ length" to { it[3] = ByteArray(4628) },
            "null JNI part" to { it[2] = null },
            "wrong role wires" to { val i = it[6]; it[6] = it[7]; it[7] = i },
            "changed issuer wire" to { it[6]!![it[6]!!.lastIndex] = 1 },
            "oversized target wire" to { it[7] = ByteArray(65537) },
            "missing issuer wire" to { it[6] = ByteArray(0) }
        )) control(name) {
            fixture().use { f ->
                val raw = parts(f.prepared); mutate(raw)
                val aliases = raw.filterNotNull()
                rejected { VeilNativeAccountChannel.ObservedSignatures.decode(f.prepared, raw) }
                expect(raw.all { it == null } && aliases.all { b -> b.all { it == 0.toByte() } }, "rejected carrier erased")
            }
        }
        for (size in listOf(0, 7, 9)) control("exact array arity $size rejected") {
            fixture().use { f ->
                val raw = parts(f.prepared).copyOf(size)
                rejected { VeilNativeAccountChannel.ObservedSignatures.decode(f.prepared, raw) }
            }
        }
        control("expired original rejected without renewal") {
            fixture().use { f ->
                val fields = f.prepared.original.javaClass.getDeclaredField("fields").apply { isAccessible = true }
                val old = fields.get(f.prepared.original) as Map<*, *>
                val expired = old.entries.associate { it.key as String to it.value as String }.toMutableMap()
                expired["expiresMs"] = (System.currentTimeMillis() - 1).toString()
                fields.set(f.prepared.original, expired)
                rejected { VeilNativeAccountChannel.ObservedSignatures.decode(f.prepared, parts(f.prepared)) }
            }
        }
        control("JNI descriptors remain private static native and bounded public arrays") {
            val methods = VeilNativeAccountChannel::class.java.declaredMethods
            for (name in listOf("nativePrepare", "nativeObserveSignatures", "nativeCloseSignatures")) {
                val method = methods.single { it.name == name }
                expect(Modifier.isPrivate(method.modifiers) && Modifier.isStatic(method.modifiers) && Modifier.isNative(method.modifiers), "private static native $name")
                expect(method.parameterTypes.map { it.name } == listOf("android.content.Context", "com.ynx.social.matrix.VeilLocalRecoveryInput", "com.ynx.social.matrix.VeilSocialLoginClient\$AccountChannelBorrow"), "exact original descriptor")
                expect(method.returnType.name == if (name == "nativeObserveSignatures") "[[B" else "int", "exact return descriptor")
            }
            expect(VeilNativeAccountChannel.SIGNATURE_RAM_CLOSED == 44 && VeilNativeAccountChannel.FACTS_UNADMITTED == 204, "no code promoted to authority")
        }
        fun borrowed(f: Fixture): VeilSocialLoginClient.AccountChannelBorrow {
            for (name in listOf("select", "current")) f.holder.javaClass.getDeclaredMethod(name).apply { isAccessible = true }.invoke(f.holder)
            return f.client.borrowAccountChannel(f.original, f.prepared).also { it.retainNativeFactsUnadmitted() }
        }
        control("closed observation cannot finalize or replay") {
            fixture().use { f ->
                val borrow = borrowed(f)
                val observed = VeilNativeAccountChannel.ObservedSignatures.decode(f.prepared, parts(f.prepared))
                observed.close()
                rejected { observed.finalizeOriginal(f.client, f.original, borrow) }
            }
        }
        control("another prepared object cannot consume observation") {
            fixture().use { a -> fixture().use { b ->
                val borrow = borrowed(b)
                val observed = VeilNativeAccountChannel.ObservedSignatures.decode(a.prepared, parts(a.prepared))
                rejected { observed.finalizeOriginal(b.client, b.original, borrow) }
            } }
        }
        control("original exhausted budget blocks finalization") {
            fixture().use { f ->
                val borrow = borrowed(f)
                val raw = parts(f.prepared)
                val observed = VeilNativeAccountChannel.ObservedSignatures.decode(f.prepared, raw)
                borrow.javaClass.getDeclaredField("budgetNanos").apply { isAccessible = true }.setLong(borrow, 0)
                rejected { observed.finalizeOriginal(f.client, f.original, borrow) }
                expect(raw.all { it == null }, "failed submission erases only copies")
            }
        }
        println("RESULT $passed PASS ${failures.size} FAIL; PUBLIC binding/HTTP/native-owner stand-ins only")
        check(failures.isEmpty()) { failures.joinToString() }
    }
}
