# JNI exports and C FindClass/GetMethodID calls require these exact names.
# Keep only the native product boundary and its private runtime collaborators.
-keep class com.ynx.social.veil.VeilNativeProductControllerBridge { *; }
-keep class com.ynx.social.matrix.VeilOwnKeyPrivateCommand { *; }
-keep class com.ynx.social.matrix.VeilLocalGenesisInput { *; }
-keep class com.ynx.social.matrix.VeilLocalRecoveryInput { *; }
-keep class com.ynx.social.matrix.VeilLocalGenesisJournalBinding { *; }
-keep class com.ynx.social.matrix.VeilOwnKeyLocalStoreCallbacks { *; }
-keep class com.ynx.social.matrix.VeilOwnKeyLocalStoreContext { *; }
-keep class com.ynx.social.matrix.VeilOwnKeyLocalStoreContext$* { *; }
-keep class com.ynx.social.pqauth.internal.VeilOwnKeyBootstrapPolicy { *; }
-keep class com.ynx.social.pqauth.internal.VeilOwnKeyPlatformProtector { *; }
