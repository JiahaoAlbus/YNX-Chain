package com.ynx.social.matrix

import okhttp3.Dns
import java.net.InetAddress

/** Fixed routing, not a registration grant. Signer pins and verified domain remain mandatory. */
internal enum class VeilSocialLoginProfile(
    val packageName: String, val clientId: String, val callback: String,
    val callbackClass: String, val signerResource: String, val apiMount: String = "",
    val cookieIdName: String = "__Host-ynx-social-login-id",
    val cookieBindingName: String = "__Host-ynx-social-login-binding"
) {
M1_QA("com.ynx.social.m1qa", "ynx-social-v1-m1qa-sso-v1",
    "https://social.ynxweb4.com/sso/m1qa/callback",
    "com.ynx.social.matrix.VeilSocialQaLoginCallbackActivity", "ynx_social_m1qa_login_signer_sha256", "/m1qa",
    "__Host-ynx-social-m1qa-login-id", "__Host-ynx-social-m1qa-login-binding"),
PRODUCTION(
"com.ynx.social", "ynx-social-v1-sso-v1",
        "https://social.ynxweb4.com/sso/callback",
        "com.ynx.social.matrix.VeilSocialLoginCallbackActivity", "ynx_social_login_signer_sha256"),
    PARALLEL_QA("com.ynx.social.veilqa", "ynx-social-v1-veilqa-sso-v1",
        "https://social.ynxweb4.com/sso/veilqa/callback",
        "com.ynx.social.matrix.VeilSocialQaLoginCallbackActivity", "ynx_social_qa_login_signer_sha256");

    companion object {
        fun forPackage(packageName: String): VeilSocialLoginProfile =
            entries.singleOrNull { it.packageName == packageName }
                ?: throw IllegalArgumentException("SOCIAL_LOGIN_PACKAGE_UNSUPPORTED")
    }

    // Deployment routing only. The request URL, TLS hostname/SNI, cookies and
    // signed identity remain canonical; other hosts and profiles use system DNS.
    internal fun transportDns(system: Dns = Dns.SYSTEM): Dns =
        if (this != M1_QA) system else object : Dns {
            override fun lookup(hostname: String): List<InetAddress> =
                if (hostname == "social.ynxweb4.com") {
                    listOf(InetAddress.getByAddress(hostname, byteArrayOf(43, 134.toByte(), 23, 58)))
                } else system.lookup(hostname)
        }
}
