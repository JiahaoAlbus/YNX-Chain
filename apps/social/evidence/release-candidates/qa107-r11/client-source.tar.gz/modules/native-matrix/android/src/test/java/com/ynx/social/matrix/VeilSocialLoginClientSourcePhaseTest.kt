package com.ynx.social.matrix

import okhttp3.Call
import okhttp3.Callback
import okhttp3.CookieJar
import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody
import okio.Buffer
import okio.BufferedSource
import okio.ForwardingSource
import okio.Timeout
import okio.buffer
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.net.InetAddress
import java.net.UnknownHostException
import java.security.MessageDigest
import java.util.ArrayDeque

/** Offline full-Client regression, not a login/device/native acceptance test.
 * The standalone runner supplies a TEST_ONLY original-request owner stand-in.
 * All HTTP responses, public keys and signatures below are synthetic public data.
 * No network, JNI, key generation, signing, device grant or browser is executed.
 */
internal object VeilSocialLoginClientSourcePhaseTest {
    private const val UNKNOWN = "ENROLLMENT_UNKNOWN_RETAINED"
    private const val PENDING = "NATIVE_PROOF_AUTHORIZATION_REQUIRED"
    private lateinit var newOriginal: (VeilFirstDeviceChallengeWire.Request) -> VeilCryptoEngineOwner.FirstDeviceIntent

    fun run(factory: (VeilFirstDeviceChallengeWire.Request) -> VeilCryptoEngineOwner.FirstDeviceIntent) {
        newOriginal = factory
        var passed = 0
        val failures = mutableListOf<String>()
        fun case(name: String, action: () -> Unit) {
            try { action(); passed++; println("PASS $name") }
            catch (failure: Throwable) {
                failures.add(name)
                println("FAIL $name: ${failure.javaClass.simpleName}: ${failure.message}")
            }
        }

        case("m1qa_normal_factory_uses_fixed_peer_without_changing_tls_or_policy") {
            val baseline = OkHttpClient()
            for (profile in VeilSocialLoginProfile.entries) {
                VeilSocialLoginClient(profile).use { client ->
                    val factory = field("factory").get(client) as OkHttpClient
                    if (profile == VeilSocialLoginProfile.M1_QA) {
                        val peers = factory.dns.lookup("social.ynxweb4.com")
                        expect(peers.size == 1 && peers.single().hostAddress == "43.134.23.58", "QA peer not selected")
                        expect(peers.single().hostName == "social.ynxweb4.com", "canonical hostname lost")
                    } else expect(factory.dns === Dns.SYSTEM, "non-QA DNS overridden")
                    expect(factory.hostnameVerifier === baseline.hostnameVerifier, "hostname verifier replaced")
                    expect(factory.connectionSpecs == baseline.connectionSpecs, "TLS policy replaced")
                    expect(factory.cookieJar === CookieJar.NO_COOKIES && factory.cache == null, "ambient state enabled")
                    expect(!factory.followRedirects && !factory.followSslRedirects && !factory.retryOnConnectionFailure,
                        "redirect or replay policy changed")
                    expect(factory.connectTimeoutMillis == 15000 && factory.readTimeoutMillis == 15000 &&
                        factory.writeTimeoutMillis == 15000 && factory.callTimeoutMillis == 15000, "timeout changed")
                }
            }
        }
        case("qa_peer_applies_only_to_exact_canonical_host") {
            val lookedUp = mutableListOf<String>()
            val systemPeer = listOf(InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1)))
            val systemFailure = UnknownHostException("PUBLIC_TEST_ONLY")
            val system = object : Dns {
                override fun lookup(hostname: String): List<InetAddress> {
                    lookedUp.add(hostname)
                    if (hostname == "missing.invalid") throw systemFailure
                    return systemPeer
                }
            }
            val qa = VeilSocialLoginProfile.M1_QA.transportDns(system)
            expect(qa.lookup("social.ynxweb4.com").single().hostAddress == "43.134.23.58" && lookedUp.isEmpty(),
                "canonical QA lookup used public DNS")
            for (host in listOf("wallet-auth.ynxweb4.com", "social.ynxweb4.com.invalid", "social.ynxweb4.com.")) {
                expect(qa.lookup(host) === systemPeer, "unrelated host rerouted")
                expect(lookedUp.last() == host, "system lookup changed")
            }
            val failure = runCatching { qa.lookup("missing.invalid") }.exceptionOrNull()
            expect(failure === systemFailure, "system failure replaced or retried")
            expect(lookedUp.count { it == "missing.invalid" } == 1, "system lookup retried")
            expect(VeilSocialLoginProfile.PRODUCTION.transportDns(system) === system &&
                VeilSocialLoginProfile.PARALLEL_QA.transportDns(system) === system, "QA routing leaked across profiles")
        }
        case("native_peer_selection_requires_current_original_borrow") { flow { f ->
            f.select(); f.current()
            val borrow = f.client.borrowAccountChannel(f.original, f.prepared)
            borrow.requireM1QaTransport()
            val count = f.calls.requests.size
            f.client.cancelLocal()
            expect(runCatching { borrow.requireM1QaTransport() }.isFailure, "cancelled borrow selected peer")
            expect(f.calls.requests.size == count, "transport selection dispatched account request")
        } }
        case("selection_closes_before_pending_then_finalize_without_observe") { flow { f ->
            f.select()
            expect(phase(f.client) == PENDING, "selection did not restore pending proof")
            f.finalizeOnce()
        } }
        case("evidence_closes_before_pending_then_finalize_without_observe") { flow { f ->
            f.select(); f.current()
            expect(phase(f.client) == PENDING, "evidence did not restore pending proof")
            f.finalizeOnce()
        } }
        case("refresh_keeps_original_body_nonce_and_pending_phase") { flow { f ->
            f.select(); f.current()
            val firstBody = requestBytes(f.calls.requests.last())
            val borrow = f.client.borrowAccountChannel(f.original, f.prepared)
            borrow.retainNativeFactsUnadmitted()
            f.current()
            expect(firstBody.contentEquals(requestBytes(f.calls.requests.last())), "refresh changed original body")
            expect(phase(f.client) == PENDING, "refresh did not restore pending proof")
        } }
        case("http_refusal_stays_unknown_and_cannot_finalize") { flow { f ->
            f.calls.plan("source-selection", f.selectionBody, code = 503)
            f.refused(f.client.selectFirstDeviceSource(f.original, f.prepared), VeilSocialLoginClient.Failure.HTTP_REFUSED)
            f.noFinalize()
        } }
        case("ambiguous_evidence_does_not_retry_or_finalize") { flow { f ->
            f.select()
            f.calls.plan("source-current", f.evidenceBody, executeFailure = IOException("PUBLIC_UNKNOWN"))
            val failed = f.client.fetchFirstDeviceSource(f.original, f.prepared, f.nonce)
            f.refused(failed, VeilSocialLoginClient.Failure.NO_RESPONSE)
            expect((failed as VeilSocialLoginClient.Outcome.Refused).remoteOutcomeUnknown, "unknown IO was erased")
            val count = f.calls.requests.size
            f.refused(f.client.fetchFirstDeviceSource(f.original, f.prepared, f.nonce))
            expect(f.calls.requests.size == count, "ambiguous evidence was resent")
            f.noFinalize()
        } }
        case("malformed_selection_does_not_restore") { flow { f ->
            f.calls.plan("source-selection", "{\"state\":\"wrong\"}")
            f.refused(f.client.selectFirstDeviceSource(f.original, f.prepared))
        } }
        case("wrong_evidence_operation_does_not_restore") { flow { f ->
            f.select()
            f.calls.plan("source-current", f.evidenceBody.replace(f.request.operation, "fd1-other"))
            f.refused(f.client.fetchFirstDeviceSource(f.original, f.prepared, f.nonce))
        } }
        for (evidence in listOf(false, true)) {
            case("${if (evidence) "evidence" else "selection"}_io_close_failure_stays_unknown") { flow { f ->
                if (evidence) f.select()
                val step = f.planSource(evidence) { throw IOException("PUBLIC_CLOSE_FAILURE") }
                f.refused(f.source(evidence), VeilSocialLoginClient.Failure.NO_RESPONSE)
                expect(step.closeCount == 1, "physical stream close repeated")
                f.noFinalize()
            } }
        }
        case("late_cancel_after_parse_does_not_restore") { flow { f ->
            f.planSource(false) { f.client.cancelLocal() }
            f.refused(f.source(false), VeilSocialLoginClient.Failure.CANCELLED)
        } }
        case("late_epoch_change_does_not_restore") { flow { f ->
            f.planSource(false) { field("epoch").setLong(f.client, field("epoch").getLong(f.client) + 1) }
            f.refused(f.source(false), VeilSocialLoginClient.Failure.CANCELLED)
        } }
        case("late_different_original_with_same_public_bytes_does_not_restore") { flow { f ->
            f.planSource(false) { field("challengeOriginal").set(f.client, newOriginal(f.request)) }
            f.refused(f.source(false), VeilSocialLoginClient.Failure.ASSOCIATION_REQUIRED)
        } }
        case("late_different_prepared_with_same_public_bytes_does_not_restore") { flow { f ->
            f.planSource(false) {
                field("enrollmentPrepared").set(f.client, VeilFirstDeviceEnrollmentWire.Prepared.decode(f.preparedBody, f.prepared.original))
            }
            f.refused(f.source(false), VeilSocialLoginClient.Failure.ASSOCIATION_REQUIRED)
        } }
        case("late_enrollment_original_replacement_does_not_restore") { flow { f ->
            f.planSource(false) {
                field("enrollmentOriginal").set(f.client, VeilFirstDeviceEnrollmentWire.Original.retained(f.request, f.challenge))
            }
            f.refused(f.source(false), VeilSocialLoginClient.Failure.ASSOCIATION_REQUIRED)
        } }
        case("late_original_owner_cancellation_does_not_restore") { flow { f ->
            f.planSource(false) { f.original.acknowledgeCancellation() }
            f.refused(f.source(false))
        } }
        for (evidence in listOf(false, true)) {
            case("${if (evidence) "evidence" else "selection"}_expires_during_close") { flow(1500) { f ->
                if (evidence) f.select()
                f.planSource(evidence) {
                    val remaining = f.prepared.original.expiresMs - System.currentTimeMillis()
                    if (remaining >= 0) Thread.sleep(remaining + 2)
                }
                f.refused(f.source(evidence), VeilSocialLoginClient.Failure.ASSOCIATION_REQUIRED)
                f.noFinalize()
            } }
        }
        case("refresh_late_original_monotonic_budget_expiry_does_not_restore") { flow { f ->
            f.select(); f.current()
            val borrow = f.client.borrowAccountChannel(f.original, f.prepared)
            borrow.retainNativeFactsUnadmitted()
            f.planSource(true) {
                borrow.javaClass.getDeclaredField("budgetNanos").apply { isAccessible = true }.setLong(borrow, 0)
            }
            f.refused(f.source(true))
        } }
        case("primary_bounded_response_refusal_survives_close_failure") { flow { f ->
            val step = f.calls.plan("source-selection", "x".repeat(8193), closeAction = { throw IOException("PUBLIC_SECONDARY_CLOSE") })
            f.refused(f.source(false), VeilSocialLoginClient.Failure.INVALID_RESPONSE)
            expect(step.closeCount == 1, "close did not stay single")
        } }
        println("RESULT full_client_public_jvm: $passed passed, ${failures.size} failed")
        expect(failures.isEmpty(), "failed cases: ${failures.joinToString()}")
    }


    /** Close-only PUBLIC controls. No authorization, Native call or network. */
    fun runCloseControls() {
        var passed = 0
        val failures = mutableListOf<String>()
        fun case(name: String, action: (CloseProbe) -> Unit) {
            val probe = CloseProbe()
            try { action(probe); passed++; println("PASS close_$name") }
            catch (failure: Throwable) {
                failures.add(name)
                println("FAIL close_$name: ${failure.javaClass.simpleName}: ${failure.message}")
            } finally { probe.disposeTestWorker() }
        }
        case("normal_is_single_and_idempotent") { p ->
            p.coordinator.close()
            p.coordinator.close()
            expect(p.retireCalls == 1, "browser close repeated")
            expect(p.worker.isShutdown, "idle worker was not shut down")
            expect((p.client.start(VeilSocialLoginClient.Intent.A) as? VeilSocialLoginClient.Outcome.Refused)?.reason ==
                VeilSocialLoginClient.Failure.CLOSED, "client still admits login")
        }
        case("browser_failure_still_closes_client_and_idle_worker") { p ->
            val original = IOException("PUBLIC_BROWSER_CLOSE")
            val retainedSource = IOException("PUBLIC_RETAINED_SOURCE")
            p.retireFailure = original
            p.coordinatorField("sourceFailure").set(p.coordinator, retainedSource)
            expect(runCatching { p.coordinator.close() }.exceptionOrNull() === original, "primary close error replaced")
            expect((p.client.start(VeilSocialLoginClient.Intent.A) as? VeilSocialLoginClient.Outcome.Refused)?.reason ==
                VeilSocialLoginClient.Failure.CLOSED, "browser error skipped client close")
            expect(p.worker.isShutdown, "browser error skipped idle worker shutdown")
            expect(p.coordinatorField("sourceFailure").get(p.coordinator) === retainedSource, "retained source error erased")
        }
        case("failed_close_repeats_observation_not_effect") { p ->
            val original = IOException("PUBLIC_BROWSER_CLOSE")
            p.retireFailure = original
            expect(runCatching { p.coordinator.close() }.exceptionOrNull() === original, "original close failed differently")
            expect(runCatching { p.coordinator.close() }.exceptionOrNull() === original, "repeat lost original error")
            expect(p.retireCalls == 1, "failed browser close retried")
        }
        case("http_cancel_failure_keeps_running_original_until_exit") { p ->
            val original = IOException("PUBLIC_CANCEL_CLOSE")
            p.cancelFailure = original
            p.beginRunning()
            expect(runCatching { p.coordinator.close() }.exceptionOrNull() === original, "HTTP close error replaced")
            expect(p.cancelCalls.get() == 1 && p.retireCalls == 1, "close stage skipped or repeated")
            expect(!p.worker.isShutdown, "running original executor prematurely closed")
            expect(runCatching { p.coordinator.close() }.exceptionOrNull() === original, "repeat lost HTTP error")
            expect(p.cancelCalls.get() == 1, "uncertain HTTP cancellation retried")
            p.release.countDown()
            expect(p.worker.awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS), "original exit did not shut down worker")
        }
        case("first_error_preserves_secondary_close_error") { p ->
            val primary = IOException("PUBLIC_BROWSER_CLOSE")
            val secondary = IOException("PUBLIC_HTTP_CLOSE")
            p.retireFailure = primary
            p.cancelFailure = secondary
            p.beginRunning()
            expect(runCatching { p.coordinator.close() }.exceptionOrNull() === primary, "first close error lost")
            expect(primary.suppressed.size == 1 && primary.suppressed.single() === secondary, "secondary close error lost")
            expect(p.cancelCalls.get() == 1, "browser failure skipped HTTP cancellation")
            expect(runCatching { p.coordinator.close() }.exceptionOrNull() === primary, "repeated close erased errors")
            expect(p.retireCalls == 1 && p.cancelCalls.get() == 1, "repeated failed close dispatched cleanup again")
            p.release.countDown()
            expect(p.worker.awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS), "failed close abandoned original worker")
        }
        case("reentrant_close_does_not_claim_finished_or_repeat_cleanup") { p ->
            var inner: Throwable? = null
            var entered = false
            p.onRetire = {
                if (!entered) {
                    entered = true
                    inner = runCatching { p.coordinator.close() }.exceptionOrNull()
                }
            }
            p.coordinator.close()
            expect(inner is IllegalStateException && inner?.message == "VEIL_LOGIN_CLOSE_PENDING", "reentrant close reported completion")
            expect(p.retireCalls == 1 && p.worker.isShutdown, "reentrant close repeated or abandoned cleanup")
            p.coordinator.close()
            expect(p.retireCalls == 1, "completed close repeated cleanup")
        }
        println("RESULT close_public_jvm: $passed passed, ${failures.size} failed")
        expect(failures.isEmpty(), "failed close cases: ${failures.joinToString()}")
    }


    /** Deterministic retained-intent interleavings using the actual IO finally.
     * factory is a TEST_ONLY cancellation original; no authority is fabricated. */
    fun runCloseInterleavingControls(factory: (() -> Unit) -> VeilCryptoEngineOwner.FirstDeviceIntent) {
        var passed = 0
        val failed = mutableListOf<String>()
        fun case(name: String, phase: String, sourceFails: Boolean, closeFails: Boolean) {
            val p = CloseProbe()
            val calls = java.util.concurrent.atomic.AtomicInteger()
            val sourceError = IOException("PUBLIC_ORIGINAL_SOURCE_CANCELLATION")
            val browserError = IOException("PUBLIC_ORIGINAL_BROWSER_CLOSE")
            val httpError = IOException("PUBLIC_ORIGINAL_HTTP_CLOSE")
            val priorError = IOException("PUBLIC_RETAINED_PRIOR_SOURCE_ERROR")
            val original = factory { calls.incrementAndGet(); if (sourceFails) throw sourceError }
            fun value(name: String) = p.coordinatorField(name).get(p.coordinator)
            fun finishOriginal() {
                p.release.countDown()
                expect(p.worker.awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS),
                    "original finally did not exit during external close")
                expect(value("sourceCancellationSelected") == true && calls.get() == 1,
                    "actual finally did not select original cancellation exactly once")
            }
            try {
                p.coordinatorField("firstDeviceOriginal").set(p.coordinator, original)
                p.coordinatorField("sourceFailure").set(p.coordinator, priorError)
                p.coordinatorField("sourceStatus").set(p.coordinator, "SOURCE_UNKNOWN_RETAINED")
                if (phase == "browser") p.onRetire = { finishOriginal() }
                else p.onCancel = { finishOriginal() }
                if (closeFails) { p.retireFailure = browserError; p.cancelFailure = httpError }
                p.beginRunning()
                val first = runCatching { p.coordinator.close() }.exceptionOrNull()
                expect(value("firstDeviceOriginal") === original, "retained intent discarded")
                expect(calls.get() == 1, "original cancellation repeated")
                expect(value("sourceFailure") === priorError, "prior source failure erased")
                expect(value("sourceStatus") == "SOURCE_UNKNOWN_RETAINED", "original UNKNOWN erased")
                expect(value("sourceCancellationFailure") === (if (sourceFails) sourceError else null),
                    "source cause replaced with synthetic scheduling error")
                if (closeFails) {
                    expect(first === browserError, "first close failure replaced")
                    expect(first?.suppressed?.toList() == (if (phase == "http") listOf(httpError) else emptyList()),
                        "synthetic or lost secondary close error")
                } else expect(first == null, "synthetic close failure: ${first?.javaClass?.simpleName}")
                expect(runCatching { p.coordinator.close() }.exceptionOrNull() === first,
                    "repeated close changed original outcome")
                expect(p.retireCalls == 1 && calls.get() == 1, "repeated physical cleanup")
                expect(p.cancelCalls.get() == (if (phase == "http") 1 else 0), "repeated HTTP cancellation")
                passed++
                println("PASS close_interleaving_$name")
            } catch (failure: Throwable) {
                failed.add(name)
                println("FAIL close_interleaving_$name: ${failure.javaClass.simpleName}: ${failure.message}")
            } finally { p.disposeTestWorker() }
        }
        case("browser_original_finishes", "browser", false, false)
        case("http_original_finishes", "http", false, false)
        case("browser_source_error_retained", "browser", true, false)
        case("http_source_and_close_errors_retained", "http", true, true)
        println("RESULT close_retained_intent_public_jvm: $passed passed, ${failed.size} failed")
        expect(failed.isEmpty(), "failed retained-intent close cases: ${failed.joinToString()}")
    }

    private class CloseProbe {
        var retireCalls = 0
        val cancelCalls = java.util.concurrent.atomic.AtomicInteger()
        var retireFailure: Throwable? = null
        var cancelFailure: Throwable? = null
        var onRetire: () -> Unit = {}
        var onCancel: () -> Unit = {}
        val entered = java.util.concurrent.CountDownLatch(1)
        val release = java.util.concurrent.CountDownLatch(1)
        val client = VeilSocialLoginClient.publicFixture(Call.Factory { request ->
            object : Call {
                override fun request() = request
                override fun execute(): Response {
                    entered.countDown()
                    if (!release.await(5, java.util.concurrent.TimeUnit.SECONDS)) throw IOException("PUBLIC_TEST_WAIT_EXPIRED")
                    throw IOException("PUBLIC_TEST_REQUEST_FINISHED")
                }
                override fun enqueue(responseCallback: Callback) { throw AssertionError("UNEXPECTED_PUBLIC_ASYNC") }
                override fun cancel() {
                    cancelCalls.incrementAndGet()
                    onCancel()
                    cancelFailure?.let { throw it }
                    release.countDown()
                }
                override fun isExecuted() = entered.count == 0L
                override fun isCanceled() = cancelCalls.get() > 0
                override fun timeout() = Timeout()
                override fun clone(): Call = throw AssertionError("UNEXPECTED_PUBLIC_CLONE")
            }
        }, VeilSocialLoginProfile.M1_QA)
        private val browser = object : VeilLoginBrowserAccess {
            override fun reserve(activity: android.app.Activity?,
                callback: (() -> Pair<VeilSocialLoginClient.BrowserHandoff, String>?) -> Unit) = true
            override fun open(activity: android.app.Activity?, handoff: VeilSocialLoginClient.BrowserHandoff) = false
            override fun retire() { retireCalls++; onRetire(); retireFailure?.let { throw it } }
        }
        val coordinator = VeilSocialLoginCoordinator.publicFixture(client, browser)
        fun coordinatorField(name: String) = VeilSocialLoginCoordinator::class.java.getDeclaredField(name).apply { isAccessible = true }
        val worker get() = coordinatorField("worker").get(coordinator) as java.util.concurrent.ThreadPoolExecutor
        fun beginRunning() {
            coordinator.beginPublicControl("A")
            expect(entered.await(5, java.util.concurrent.TimeUnit.SECONDS), "normal PUBLIC start did not enter actual IO worker")
        }
        fun disposeTestWorker() {
            release.countDown()
            runCatching { coordinator.close() }
            // Test-fixture teardown only, AFTER assertions. The frozen RED
            // implementation leaks idle workers; never count this as a pass.
            worker.shutdown()
            check(worker.awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS))
        }
    }

    private fun field(name: String) = VeilSocialLoginClient::class.java.getDeclaredField(name).apply { isAccessible = true }
    private fun phase(client: VeilSocialLoginClient) = field("challengeState").get(client) as String
    private fun expect(value: Boolean, label: String) { if (!value) throw AssertionError(label) }
    private fun requestBytes(request: Request): ByteArray = Buffer().run { checkNotNull(request.body).writeTo(this); readByteArray() }
    private fun flow(ttlMs: Long = 30000, action: (Flow) -> Unit) {
        val fixture = Flow(ttlMs)
        try { action(fixture) } finally { fixture.client.close() }
    }

    private class Step(val path: String, val body: String, val code: Int, val cookies: List<String>,
        val executeFailure: IOException?, val closeAction: () -> Unit) { var closeCount = 0 }
    private class ScriptedCalls : Call.Factory {
        val requests = mutableListOf<Request>()
        private val steps = ArrayDeque<Step>()
        fun plan(operation: String, body: String, code: Int = 200, cookies: List<String> = emptyList(),
            executeFailure: IOException? = null, closeAction: () -> Unit = {}): Step {
            val path = if (operation.startsWith("login/")) "/m1qa/v4/$operation" else "/m1qa/v4/first-device/$operation"
            return Step(path, body, code, cookies, executeFailure, closeAction).also { steps.addLast(it) }
        }
        override fun newCall(request: Request): Call {
            val step = steps.pollFirst() ?: throw AssertionError("UNPLANNED_PUBLIC_CALL")
            expect(request.method == "POST" && request.url.encodedPath == step.path, "unexpected request route")
            requests.add(request)
            return object : Call {
                private var executed = false
                private var cancelled = false
                private val bounded = Timeout()
                override fun request() = request
                override fun execute(): Response {
                    expect(!executed, "same call executed twice"); executed = true
                    step.executeFailure?.let { throw it }
                    val stream = object : ForwardingSource(Buffer().writeUtf8(step.body)) {
                        override fun close() { step.closeCount++; step.closeAction(); super.close() }
                    }.buffer()
                    val body = object : ResponseBody() {
                        override fun contentType() = "application/json".toMediaType()
                        override fun contentLength() = -1L
                        override fun source(): BufferedSource = stream
                    }
                    return Response.Builder().request(request).protocol(Protocol.HTTP_1_1).code(step.code)
                        .message("PUBLIC_FIXTURE").header("Content-Type", "application/json").body(body)
                        .apply { step.cookies.forEach { addHeader("Set-Cookie", it) } }.build()
                }
                override fun enqueue(responseCallback: Callback) { throw AssertionError("UNEXPECTED_ASYNC_CALL") }
                override fun cancel() { cancelled = true }
                override fun isExecuted() = executed
                override fun isCanceled() = cancelled
                override fun timeout() = bounded
                override fun clone(): Call = throw AssertionError("UNEXPECTED_CALL_CLONE")
            }
        }
    }

    private class Flow(ttlMs: Long) {
        val calls = ScriptedCalls()
        val client = VeilSocialLoginClient.publicFixture(calls, VeilSocialLoginProfile.M1_QA)
        private val pair = ByteArray(2657) { (it % 251 + 1).toByte() }.also { it[0] = 5 }
        val request = VeilFirstDeviceChallengeWire.Request.fromProjection(pair)
        val original = newOriginal(request)
        private val issued = System.currentTimeMillis() - 1000
        private val expires = System.currentTimeMillis() + ttlMs
        val nonce = ByteArray(32) { 9 }
        private val challengeBody = "{\"state\":\"CHALLENGE_ISSUED\",\"deviceAuthorization\":\"REQUIRED\",\"challenge\":" +
            json(linkedMapOf("operation" to request.operation, "nonce" to b64(nonce), "requestDigest" to request.digest,
                "issuedAtMs" to issued.toString(), "expiresMs" to expires.toString())) + "}"
        val challenge = VeilFirstDeviceChallengeWire.Challenge.decode(challengeBody, request)
        private val identity = "PUBLIC-FIXTURE-IDENTITY"
        private val device = "PUBLIC-FIXTURE-DEVICE"
        val preparedBody = makePrepared()
        val prepared: VeilFirstDeviceEnrollmentWire.Prepared
        val selectionBody = json(linkedMapOf("state" to "UNTRUSTED_SOURCE_SELECTION", "deviceAuthorization" to "REQUIRED",
            "scope" to b64(byteArrayOf(1)), "head" to "0".repeat(64), "catalog" to "1".repeat(64)))
        val evidenceBody = json(linkedMapOf("state" to "SOURCE_EVIDENCE_UNADMITTED", "deviceAuthorization" to "REQUIRED",
            "operation" to request.operation, "revision" to "1", "sourceEvidence" to b64(byteArrayOf(1, 2, 3))))

        init {
            val profile = VeilSocialLoginProfile.M1_QA
            val token = "A".repeat(43)
            val authorize = "https://wallet-auth.ynxweb4.com/v2/browser-sessions/authorize".toHttpUrl().newBuilder()
                .addQueryParameter("clientId", profile.clientId).addQueryParameter("origin", "https://social.ynxweb4.com")
                .addQueryParameter("redirectUri", profile.callback).addQueryParameter("state", token)
                .addQueryParameter("codeChallenge", token).addQueryParameter("codeChallengeMethod", "S256").build()
            calls.plan("login/start", "{\"authorizeUrl\":\"$authorize\"}", cookies = listOf(profile.cookieIdName, profile.cookieBindingName)
                .map { "$it=$token; Path=/; Secure; HttpOnly; SameSite=Lax" })
            expect(client.start(VeilSocialLoginClient.Intent.A) is VeilSocialLoginClient.Outcome.Authorization, "public login fixture start")
            calls.plan("login/account", "{\"status\":\"ACCOUNT_OBSERVED\",\"subject\":\"PUBLIC-FIXTURE\",\"generation\":1,\"deviceAuthorization\":\"REQUIRED\"}")
            expect(client.observeAccount() is VeilSocialLoginClient.Outcome.AccountObserved, "public account fixture")
            calls.plan("challenge", challengeBody)
            expect((client.issueFirstDevice(original) as? VeilSocialLoginClient.Outcome.ChallengeState)?.status == "CHALLENGE_ISSUED_UNVERIFIED", "public challenge fixture")
            calls.plan("prepare", preparedBody)
            expect((client.prepareFirstDevice(original) as? VeilSocialLoginClient.Outcome.ChallengeState)?.status == PENDING, "public prepare fixture")
            prepared = checkNotNull(client.retainedPreparation(original))
        }

        fun planSource(evidence: Boolean, close: () -> Unit = {}): Step = calls.plan(
            if (evidence) "source-current" else "source-selection", if (evidence) evidenceBody else selectionBody,
            closeAction = { expect(phase(client) == UNKNOWN, "phase restored before physical close"); close() })
        fun source(evidence: Boolean): VeilSocialLoginClient.Outcome = if (evidence)
            client.fetchFirstDeviceSource(original, prepared, nonce) else client.selectFirstDeviceSource(original, prepared)
        fun select() {
            val step = planSource(false)
            expect(source(false) is VeilSocialLoginClient.Outcome.SourceSelection, "selection fixture failed")
            expect(step.closeCount == 1, "selection response not closed exactly once")
        }
        fun current() {
            val step = planSource(true)
            val result = source(true)
            expect(result is VeilSocialLoginClient.Outcome.SourceEvidence, "evidence fixture failed")
            (result as VeilSocialLoginClient.Outcome.SourceEvidence).bytes.fill(0)
            expect(step.closeCount == 1, "evidence response not closed exactly once")
        }
        fun refused(result: VeilSocialLoginClient.Outcome, reason: VeilSocialLoginClient.Failure? = null) {
            expect(result is VeilSocialLoginClient.Outcome.Refused, "unexpected definitive success")
            if (reason != null) expect((result as VeilSocialLoginClient.Outcome.Refused).reason == reason, "wrong primary refusal")
            expect(phase(client) == UNKNOWN, "failure restored pending proof")
        }
        private fun finalizePublicFixture() = client.finalizeFirstDevice(original, prepared,
            ByteArray(64), ByteArray(4627), ByteArray(64), ByteArray(4627))
        fun noFinalize() {
            val count = calls.requests.size
            finalizePublicFixture()
            expect(calls.requests.size == count, "failed source permitted finalize IO")
        }
        fun finalizeOnce() {
            calls.plan("finalize", json(linkedMapOf("revision" to "1", "state" to "committed", "operation" to request.operation,
                "identity" to identity, "device" to device, "deviceAuthorization" to "REQUIRED")))
            val result = finalizePublicFixture()
            expect((result as? VeilSocialLoginClient.Outcome.ChallengeState)?.status == "ENROLLMENT_COMMITTED_UNVERIFIED", "normal finalize blocked after source success")
            val count = calls.requests.size
            finalizePublicFixture()
            expect(calls.requests.size == count, "finalize replayed")
            expect(calls.requests.none { it.url.encodedPath.endsWith("/observe") }, "extra observe disguised missing transition")
        }
        private fun makePrepared(): String {
            val classic = pair.copyOfRange(0, 33)
            val pq = pair.copyOfRange(33, 2625)
            val service = ascii("https://public.invalid")
            val leaf = directoryFrame("YNX/SOCIAL/FIRST-LEAF/V1", ascii(identity), ascii(device), classic, pq, number(1), number(1), service)
            val oldHead = ByteArray(32) { 3 }; val newHead = ByteArray(32) { 4 }
            val principal = frame(1, listOf(ascii(identity), ascii(device), ascii("LIBSIGNAL-0.104.0-XEDDSA-CANDIDATE"), classic,
                ascii("ML-DSA-87"), pq, number(1), number(1), number(2), newHead,
                MessageDigest.getInstance("SHA-256").digest(directoryFrame("YNX/SOCIAL/FIRST-DEVICE-REFERENCE/V1", leaf)), service))
            val transcript = frame(3, listOf(ascii("YNX-SOCIAL"), ascii("PUBLIC-QA"), number(1), ascii("enroll"), principal, principal,
                oldHead, newHead, number(1), number(2), nonce, number(issued), number(expires), nonce,
                directoryFrame("YNX/SOCIAL/FIRST-ACTIVE-DEVICE/V1", leaf), ByteArray(0)))
            fun signing(purpose: String, role: String) = b64(frame(4, listOf(ascii("YNX/SOCIAL/PQ-AUTH/SIGN/V1"), ascii(purpose), ascii(role), transcript)))
            return json(linkedMapOf("revision" to "1", "state" to "prepared", "operation" to request.operation,
                "identity" to identity, "device" to device, "deviceAuthorization" to "REQUIRED",
                "issuerMessage" to signing("authorization", "issuer"), "targetMessage" to signing("possession", "target")))
        }
    }

    private fun ascii(value: String) = value.toByteArray(Charsets.US_ASCII)
    private fun number(value: Long) = ByteBuffer.allocate(8).putLong(value).array()
    private fun b64(bytes: ByteArray) = VeilFirstDeviceEnrollmentWire.b64(bytes)
    private fun json(fields: Map<String, String>) = VeilFirstDeviceEnrollmentWire.json(fields).toString(Charsets.UTF_8)
    private fun directoryFrame(domain: String, vararg fields: ByteArray) = ByteArrayOutputStream().run {
        write(ascii(domain)); write(0)
        fields.forEach { write(ByteBuffer.allocate(4).putInt(it.size).array()); write(it) }
        toByteArray()
    }
    private fun frame(type: Int, fields: List<ByteArray>) = ByteArrayOutputStream().run {
        write(ByteBuffer.allocate(8).putInt(0x59504131).put(type.toByte()).put(1.toByte()).putShort(fields.size.toShort()).array())
        fields.forEachIndexed { index, bytes ->
            write(ByteBuffer.allocate(6).putShort((index + 1).toShort()).putInt(bytes.size).array()); write(bytes)
        }
        toByteArray()
    }
}
