package com.ynx.social.matrix;

import android.app.Activity;
import android.app.Instrumentation;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.util.TypedValue;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;

/** Isolated candidate check, never production device authorization. */
public final class VeilPqInstalledInstrumentation extends Instrumentation {
    private static void writePublicIcon(Drawable icon, int width, int height, File file) throws Exception {
        if (width < 1 || height < 1 || width > 1024 || height > 1024)
            throw new IllegalStateException("QA_NATIVE_BRIDGE_ICON_DIMENSION_BOUND");
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        try {
            icon.setBounds(0, 0, width, height);
            icon.draw(new Canvas(bitmap));
            try (FileOutputStream output = new FileOutputStream(file)) {
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output))
                    throw new IllegalStateException("QA_NATIVE_BRIDGE_ICON_RENDER_FAILED");
            }
        } finally { bitmap.recycle(); }
    }
    private static JSONObject publicDrawable(Drawable drawable) throws Exception {
        JSONObject data = new JSONObject();
        if (drawable == null) return data.put("present", false);
        return data.put("present", true).put("type", drawable.getClass().getName())
            .put("intrinsicWidth", drawable.getIntrinsicWidth()).put("intrinsicHeight", drawable.getIntrinsicHeight())
            .put("bounds", drawable.getBounds().toShortString());
    }
    private static JSONObject publicResource(Resources resources, int id) throws Exception {
        JSONObject data = new JSONObject().put("id", id);
        if (id == 0) return data.put("resolved", false);
        TypedValue value = new TypedValue(); resources.getValue(id, value, true);
        return data.put("resolved", true).put("density", value.density).put("type", value.type)
            .put("resourceId", value.resourceId).put("path", value.string == null ? JSONObject.NULL : value.string.toString());
    }
    /** PackageManager icon rendering ONLY; no Activity, launcher or account UI is started. */
    private String renderOwnedLauncherIcon() throws Exception {
        Context context = getTargetContext();
        if (!"com.ynx.social.veilqa".equals(context.getPackageName()))
            throw new IllegalStateException("QA_NATIVE_BRIDGE_ICON_TARGET_NOT_OWNED");
        Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        ResolveInfo resolved = launch == null ? null : context.getPackageManager().resolveActivity(launch, 0);
        if (resolved == null || resolved.activityInfo == null ||
            !context.getPackageName().equals(resolved.activityInfo.packageName))
            throw new IllegalStateException("QA_NATIVE_BRIDGE_ICON_ACTIVITY_UNAVAILABLE");
        Drawable icon = resolved.activityInfo.loadIcon(context.getPackageManager());
        if (icon == null) throw new IllegalStateException("QA_NATIVE_BRIDGE_ICON_UNAVAILABLE");
        File directory = new File(context.getFilesDir(), "veil-native-bridge-public-qa");
        if (!directory.isDirectory() && !directory.mkdirs())
            throw new IllegalStateException("QA_NATIVE_BRIDGE_ICON_PUBLIC_PATH_UNAVAILABLE");
        Resources resources = context.getPackageManager().getResourcesForApplication(resolved.activityInfo.applicationInfo);
        int iconId = resolved.activityInfo.getIconResource();
        int width = icon.getIntrinsicWidth(), height = icon.getIntrinsicHeight();
        JSONObject observation = new JSONObject().put("component", resolved.activityInfo.name)
            .put("densityDpi", resources.getDisplayMetrics().densityDpi)
            .put("density", resources.getDisplayMetrics().density)
            .put("drawableBeforeRender", publicDrawable(icon)).put("resolvedIcon", publicResource(resources, iconId));
        writePublicIcon(icon, width, height, new File(directory, "launcher-icon-native.png"));
        observation.put("nativeBounds", icon.getBounds().toShortString());
        writePublicIcon(icon, 512, 512, new File(directory, "launcher-icon-render.png"));
        observation.put("render512Bounds", icon.getBounds().toShortString());
        if (icon instanceof AdaptiveIconDrawable) {
            AdaptiveIconDrawable adaptive = (AdaptiveIconDrawable) icon;
            observation.put("adaptiveForeground", publicDrawable(adaptive.getForeground()))
                .put("adaptiveBackground", publicDrawable(adaptive.getBackground()));
            try (XmlResourceParser parser = resources.getXml(iconId)) {
                int event;
                while ((event = parser.next()) != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                    if (event == org.xmlpull.v1.XmlPullParser.START_TAG &&
                        ("foreground".equals(parser.getName()) || "background".equals(parser.getName()))) {
                        int childId = parser.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "drawable", 0);
                        observation.put("resolved" + parser.getName(), publicResource(resources, childId));
                    }
                }
            }
            writePublicIcon(adaptive.getForeground(), width, height, new File(directory, "adaptive-foreground-native.png"));
            writePublicIcon(adaptive.getBackground(), width, height, new File(directory, "adaptive-background-native.png"));
        }
        try (FileOutputStream output = new FileOutputStream(new File(directory, "icon-observation.json"))) {
            output.write(observation.toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }
        return "ACTIVITYINFO_LOADICON_NATIVE_AND_512; densityDpi=" + resources.getDisplayMetrics().densityDpi +
            "; intrinsic=" + width + "x" + height + "; component=" + resolved.activityInfo.name +
            "; publicMetadata=files/veil-native-bridge-public-qa/icon-observation.json; NOT_ACTUAL_LAUNCHER_SCREENSHOT";
    }
    private boolean ownedSqlPortOnly;
    private boolean ownedNativeBridgeOnly;
    private boolean ownedFrozenVerifierOnly;
    private boolean ownedBridgeLifecycleOnly;
    private boolean ownedPublicWrapIdentityOnly;
    private boolean ownedPublicWrapOnly;
    private String ownedPublicWrapMode;
    @Override public void onCreate(Bundle arguments) {
        super.onCreate(arguments);
        ownedSqlPortOnly = arguments != null && "true".equals(arguments.getString("ownedSqlPortOnly"));
        ownedNativeBridgeOnly = arguments != null && "true".equals(arguments.getString("ownedNativeBridgeOnly"));
        ownedFrozenVerifierOnly = arguments != null && "true".equals(arguments.getString("ownedFrozenVerifierOnly"));
        ownedBridgeLifecycleOnly = arguments != null && "true".equals(arguments.getString("ownedBridgeLifecycleOnly"));
        ownedPublicWrapIdentityOnly = arguments != null && "true".equals(arguments.getString("ownedPublicWrapIdentityOnly"));
        ownedPublicWrapOnly = arguments != null && "true".equals(arguments.getString("ownedPublicWrapOnly"));
        ownedPublicWrapMode = arguments == null ? null : arguments.getString("ownedPublicWrapMode");
        start();
    }

    /** One NONSECRET probe call; no automatic create/retry/recovery or alias cleanup. */
    private void runOwnedPublicWrap(Bundle report) throws Exception {
        if (!"create".equals(ownedPublicWrapMode) && !"reopen".equals(ownedPublicWrapMode))
            throw new IllegalStateException("QA_PUBLICWRAP_MODE_REQUIRED");
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper())
            throw new IllegalStateException("QA_PUBLICWRAP_BACKGROUND_THREAD_REQUIRED");
        Context context = getTargetContext();
        VeilPublicWrapProcessInstalledCheck.Guard guard = VeilPublicWrapProcessInstalledCheck.capture(
            context, VeilPublicWrapProcessInstalledCheck.SCOPE, VeilPublicWrapProcessInstalledCheck.ALIAS);
        if (android.os.Process.myUid() != 10213 || android.os.Build.VERSION.SDK_INT != 36)
            throw new IllegalStateException("QA_PUBLICWRAP_FROZEN_CALLER_MISMATCH");
        String sid = guard.publicSidAtUse();
        report.putInt("publicWrapActualApi", android.os.Build.VERSION.SDK_INT);
        report.putInt("publicWrapActualUid", android.os.Process.myUid());
        report.putString("publicWrapActualSid", sid);
        report.putString("publicWrapInvocation", "create".equals(ownedPublicWrapMode) ? "CREATE_ONCE" : "REOPEN_ONCE_NO_CREATE");
        String receipt = "create".equals(ownedPublicWrapMode)
            ? com.ynx.social.pqauth.internal.PublicWrapNonSecretProbe.createAndSeal(context)
            : com.ynx.social.pqauth.internal.PublicWrapNonSecretProbe.reopenAndCheck(context);
        // The exact reviewed probe accepts NO payload/alias/UID override; returns public metadata ONLY.
        report.putString("publicWrapProviderReceipt", receipt);
        guard.verifyAtUse();
        JSONObject r = new JSONObject(receipt);
        if (!"PASS".equals(r.optString("status")) || r.optBoolean("productionAdmission", true)
            || !VeilPublicWrapProcessInstalledCheck.SCOPE.equals(r.optString("scope"))
            || !("create".equals(ownedPublicWrapMode) ? "CREATE_SEAL" : "COLD_REOPEN").equals(r.optString("mode")))
            throw new IllegalStateException("QA_PUBLICWRAP_PROBE_FAILED_STOP_UNKNOWN");
        org.json.JSONArray events = r.getJSONArray("identityEvents");
        if (events.length() < 1) throw new IllegalStateException("QA_PUBLICWRAP_IDENTITY_EVENTS_REQUIRED");
        for (int n = 0; n < events.length(); n++) {
            JSONObject event = events.getJSONObject(n);
            if (event.getInt("uid") != android.os.Process.myUid() || event.getInt("pid") != android.os.Process.myPid()
                || !sid.equals(event.getString("sid")))
                throw new IllegalStateException("QA_PUBLICWRAP_KEYOP_PROCESS_MISMATCH_STOP_UNKNOWN");
        }
        java.util.Set<String> cases = new java.util.HashSet<>();
        org.json.JSONArray supplied = r.getJSONArray("cases");
        for (int n = 0; n < supplied.length(); n++)
            if (!cases.add(supplied.getString(n))) throw new IllegalStateException("QA_PUBLICWRAP_DUPLICATE_CASE");
        for (String id : new String[]{"ciphertext-tamper", "tag-tamper", "nonce-tamper", "aad-record-id-tamper", "aad-generation-tamper"}) {
            boolean tag = cases.remove(id + ":AEADBadTagException"), padding = cases.remove(id + ":BadPaddingException");
            if (tag == padding) throw new IllegalStateException("QA_PUBLICWRAP_TAMPER_EXCEPTION_REQUIRED");
        }
        for (String id : new String[]{"public-roundtrip", "exact-record-retry-no-reseal", "empty-nonsecret", "max-bounded-public-data",
            "oversize-rejected", "eight-provider-nonces-distinct-observed-not-proof", "closed-handle-denied",
            "create".equals(ownedPublicWrapMode) ? "exact-ciphertext-checkpoint-fsync" : "same-uid-sid-different-pid-checkpoint"})
            if (!cases.remove(id)) throw new IllegalStateException("QA_PUBLICWRAP_CASE_REQUIRED");
        if (supplied.length() != 13 || !cases.isEmpty()) throw new IllegalStateException("QA_PUBLICWRAP_CASE_COUNT");
        report.putString("publicWrapProvider", "PASS_NONSECRET_PLATFORM_COMPONENT_ONLY");
        report.putString("production", "NOT_VERIFIED_AUTHFALSE_NOT_USER_GRANT_RUNTIME_COMPLETE_FALSE");
    }

    @Override public void onStart() {
        Bundle report = new Bundle();
        report.putInt("qaProcessId", android.os.Process.myPid());
        report.putString("nativeBridge", "BRIDGE115_NOT_RUN_DEFAULT_PQ_SQL_SELECTION_PREVIOUS_RESULT_RETAINED");
        report.putString("nativeFrozenVerifier", "NOT_RUN_OTHER_COMPONENT_SELECTION");
        report.putString("nativeBridgeLifecycle", "NOT_RUN_OTHER_COMPONENT_SELECTION");
        report.putString("publicWrapCallingProcess", "NOT_RUN_OTHER_COMPONENT_SELECTION");
        report.putString("publicWrapProvider", "NOT_RUN_CONTRACT_UNAVAILABLE");
        try {
            if (ownedPublicWrapOnly) {
                report.putString("candidate", "PQ70_NOT_RUN_COMPONENT_SELECTION_PREVIOUS_RESULT_RETAINED");
                report.putString("sqlitePort", "SQL33_NOT_RUN_COMPONENT_SELECTION_PREVIOUS_RESULT_RETAINED");
                if (ownedSqlPortOnly || ownedNativeBridgeOnly || ownedFrozenVerifierOnly || ownedBridgeLifecycleOnly || ownedPublicWrapIdentityOnly)
                    throw new IllegalStateException("QA_PUBLICWRAP_SELECTION_CONFLICT");
                runOwnedPublicWrap(report);
                finish(Activity.RESULT_OK, report); return;
            }
            if (ownedPublicWrapIdentityOnly) {
                report.putString("candidate", "PQ70_NOT_RUN_COMPONENT_SELECTION_PREVIOUS_RESULT_RETAINED");
                report.putString("sqlitePort", "SQL33_NOT_RUN_COMPONENT_SELECTION_PREVIOUS_RESULT_RETAINED");
                if (ownedSqlPortOnly || ownedNativeBridgeOnly || ownedFrozenVerifierOnly || ownedBridgeLifecycleOnly)
                    throw new IllegalStateException("QA_PUBLICWRAP_SELECTION_CONFLICT");
                report.putString("publicWrapCallingProcess", VeilPublicWrapProcessInstalledCheck.runIdentityOnly(getTargetContext()));
                report.putString("production", "NOT_VERIFIED_RUNTIME_COMPLETE_FALSE_NO_KEY_OPERATIONS");
                finish(Activity.RESULT_OK, report); return;
            }
            if (ownedBridgeLifecycleOnly) {
                report.putString("candidate", "PQ70_NOT_RUN_COMPONENT_SELECTION_PREVIOUS_RESULT_RETAINED");
                report.putString("sqlitePort", "SQL33_NOT_RUN_COMPONENT_SELECTION_PREVIOUS_RESULT_RETAINED");
                if (ownedSqlPortOnly || ownedNativeBridgeOnly || ownedFrozenVerifierOnly)
                    throw new IllegalStateException("QA_NATIVE_BRIDGE_SELECTION_CONFLICT");
                report.putString("nativeBridgeLifecycle", VeilNativeBridgeLifecycleInstalledCheck.runOwnedFixture(getTargetContext()));
                report.putString("production", "NOT_VERIFIED_SECTION5_3_UNFINISHED_RUNTIME_COMPLETE_FALSE");
                finish(Activity.RESULT_OK, report); return;
            }
            if (ownedFrozenVerifierOnly) {
                report.putString("candidate", "PQ70_NOT_RUN_COMPONENT_SELECTION_PREVIOUS_RESULT_RETAINED");
                report.putString("sqlitePort", "SQL33_NOT_RUN_COMPONENT_SELECTION_PREVIOUS_RESULT_RETAINED");
                if (ownedSqlPortOnly || ownedNativeBridgeOnly || ownedBridgeLifecycleOnly)
                    throw new IllegalStateException("QA_FROZEN_VERIFIER_SELECTION_CONFLICT");
                report.putString("nativeFrozenVerifier", VeilNativeFrozenVerifierInstalledCheck.runOwnedFixture(getTargetContext()));
                report.putString("production", "NOT_VERIFIED_SECTION5_3_UNFINISHED_RUNTIME_COMPLETE_FALSE");
                finish(Activity.RESULT_OK, report);
                return;
            }
            if (ownedNativeBridgeOnly) {
                report.putString("candidate", "PQ70_NOT_RUN_COMPONENT_SELECTION_PREVIOUS_RESULT_RETAINED");
                report.putString("sqlitePort", "SQL33_NOT_RUN_COMPONENT_SELECTION_PREVIOUS_RESULT_RETAINED");
                if (ownedSqlPortOnly) throw new IllegalStateException("QA_NATIVE_BRIDGE_SELECTION_CONFLICT");
                report.putString("nativeBridge", VeilNativeBridgeInstalledCheck.runOwnedFixture(getTargetContext()));
                report.putString("launcherIcon", renderOwnedLauncherIcon());
                report.putString("production", "NOT_VERIFIED_SECTION5_3_UNFINISHED_RUNTIME_COMPLETE_FALSE");
                finish(Activity.RESULT_OK, report);
                return;
            }
            report.putString("sqlitePort", VeilNativeSqlSnapshotInstalledCheck.runOwnedFixture(getTargetContext()));
            if (ownedSqlPortOnly) {
                report.putString("candidate", "PQ_NOT_RUN_COMPONENT_SELECTION_PREVIOUS70_FAIL_RETAINED");
                report.putString("production", "NOT_VERIFIED_SECTION5_3_UNFINISHED");
                finish(Activity.RESULT_OK, report);
                return;
            }
            report.putString("candidate", VeilPqAndroidInstalledCheck.runSynthetic(
                getTargetContext().getFilesDir().toPath().resolve("pq-identity-public-qa")));
            report.putString("production", "NOT_VERIFIED_SECTION5_3_UNFINISHED");
            finish(Activity.RESULT_OK, report);
        } catch (Throwable failure) {
            report.putString(ownedPublicWrapOnly ? "publicWrapProvider" : ownedPublicWrapIdentityOnly ? "publicWrapCallingProcess" : ownedBridgeLifecycleOnly ? "nativeBridgeLifecycle" : ownedFrozenVerifierOnly ? "nativeFrozenVerifier" : ownedNativeBridgeOnly ? "nativeBridge" : "candidate", ownedPublicWrapOnly ? "FAIL_STOP_RETAIN_UNKNOWN_NO_RETRY" : "FAIL");
            report.putString("failureClass", failure.getClass().getName());
            String message = failure.getMessage();
            if (message != null && message.matches("(?:VEIL_|QA_)[A-Z0-9_]{1,160}")) {
                report.putString("failureCode", message);
            }
            report.putString("production", "NOT_VERIFIED_SECTION5_3_UNFINISHED");
            finish(Activity.RESULT_CANCELED, report);
        }
    }
}
