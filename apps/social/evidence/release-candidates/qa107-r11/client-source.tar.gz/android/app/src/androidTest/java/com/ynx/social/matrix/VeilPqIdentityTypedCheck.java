package com.ynx.social.matrix;

import static com.ynx.social.matrix.VeilPqIdentityCandidate.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Real libsignal classic JNI AND real ML-DSA JNI; explicitly synthetic PUBLIC
 * subject/grant/directory/baseline fixtures. Never a production admission test. */
public final class VeilPqIdentityTypedCheck {
  private static int checks;
  private static void check(boolean ok,String label) { if(!ok)throw new AssertionError(label); checks++; System.out.println("PASS "+label); }
  private static void reject(Runnable call,String label) {
    try { call.run(); } catch (IllegalArgumentException|IllegalStateException expected) {check(true,label);return;}
    throw new AssertionError("accepted: "+label);
  }
  private static PublicBytes b(int n,int fill) {byte[] a=new byte[n];Arrays.fill(a,(byte)fill);return new PublicBytes(a);}
  private static Principal principal(NativeKey key,String identity,String device,int fill) {
    return new Principal(identity,device,CLASSIC_PROFILE,key.classicalPublic(),"ML-DSA-87",key.pqPublic(),1,1,7,b(32,fill),b(32,fill+1),"qa-node.invalid");
  }
  private static SessionTranscript session(Principal i,Principal r,int publicExport) {
    return new SessionTranscript("YNX-SOCIAL","synthetic-public-realm",1,b(32,9),"SYNTHETIC-NOT-BASELINE-EXPORT",
        b(32,3),i,r,b(32,10),b(32,11),1000,61000,b(32,12),b(0,0),b(0,0),b(32,13),
        "SYNTHETIC-NOT-KEM",b(64,14),b(64,15),b(32,publicExport),b(32,16),b(32,17));
  }
  private static DeviceGrantTranscript grant(Action action,Principal issuer,Principal target,int nextState) {
    return new DeviceGrantTranscript("YNX-SOCIAL","synthetic-public-realm",1,action,issuer,target,b(32,21),b(32,nextState),
        7,8,b(32,23),1000,61000,b(32,24),b(128,25),action==Action.MIGRATE?b(64,26):b(0,0));
  }
  private static SignaturePair change(SignaturePair p,int component) {
    byte[] classic=p.classicalSignature().copy(),pq=p.pqSignature().copy(),digest=p.inputDigest().copy();
    if(component==0)classic[0]^=1; else if(component==1)pq[0]^=1; else digest[0]^=1;
    return new SignaturePair(p.purpose(),p.role(),new PublicBytes(digest),new PublicBytes(classic),new PublicBytes(pq));
  }
  private static void emit(Path dir,String prefix,SigningRequest request,SignaturePair p) throws Exception {
    Files.write(dir.resolve(prefix+".message"),request.signingInput());
    Files.write(dir.resolve(prefix+".proof"),p.publicEncoding());
    Files.write(dir.resolve(prefix+".transcript"),request.transcript());
    Files.write(dir.resolve(prefix+".purpose"),request.purpose().getBytes(java.nio.charset.StandardCharsets.UTF_8));
    Files.write(dir.resolve(prefix+".role"),request.role().getBytes(java.nio.charset.StandardCharsets.UTF_8));
  }
  public static String runSynthetic(Path publicEvidence) throws Exception {
    checks=0;
    try(NativeKey i=VeilPqAndroidInstalledCheck.createTrackedKey("typed-initial",1); NativeKey r=VeilPqAndroidInstalledCheck.createTrackedKey("typed-initial",2); NativeKey newDevice=VeilPqAndroidInstalledCheck.createTrackedKey("typed-initial",3)) {
      Principal pi=principal(i,"qa-alice","qa-device-i",1),pr=principal(r,"qa-bob","qa-device-r",4);
      Principal target=principal(newDevice,"qa-alice","qa-new-device",20);
      SessionTranscript t=session(pi,pr,18);
      SessionSigning si=new SessionSigning(t,SessionRole.INITIATOR),sr=new SessionSigning(t,SessionRole.RESPONDER);
      SignaturePair is=i.signCandidate(si),rs=r.signCandidate(sr);
      var both=verifyMutualCandidate(t,is,rs,pi,pr);
      check(both.initiator().status().equals("CRYPTOGRAPHIC_PAIR_VALID_UNTRUSTED") &&
          Arrays.equals(both.initiator().transcriptDigest().copy(),both.responder().transcriptDigest().copy()),
          "actual libsignal classic AND ML-DSA JNI verify both exact typed roles over one full T without trust claim");
      check(pi.classicalPublic().copy().length==33 && is.classicalSignature().copy().length==64 && is.pqSignature().copy().length==4627,
          "actual libsignal serialized identity and signature, not QA Ed25519 or primitive substitution");
      emit(publicEvidence,"session-i",si,is);emit(publicEvidence,"session-r",sr,rs);
      for(SessionRole role:SessionRole.values()) {
        SessionSigning request=new SessionSigning(t,role);SignaturePair original=role==SessionRole.INITIATOR?is:rs;
        Principal expected=role==SessionRole.INITIATOR?pi:pr;
        for(int fault=0;fault<3;fault++) {
          SignaturePair bad=change(original,fault);
          reject(()->verifyCandidate(request,bad,expected),"either classic/PQ/digest failure rejects typed role before evidence");
        }
        reject(()->verifyCandidate(request,original,role==SessionRole.INITIATOR?pr:pi),"independently expected complete principal cannot be substituted");
      }
      reject(()->verifyMutualCandidate(t,rs,is,pi,pr),"session role proof reflection rejected");
      reject(()->verifyMutualCandidate(session(pi,pr,19),is,rs,pi,pr),"baseline public export change invalidates both-session binding");
      reject(()->r.signCandidate(si),"wrong native key holder cannot sign another device principal");
      byte[] exposed=is.pqSignature().copy();exposed[0]^=1;
      check(verifyCandidate(si,is,pi)!=null,"returned public byte arrays cannot mutate immutable signature proof");
      exposed=pi.pqPublic().copy();exposed[0]^=1;
      check(verifyCandidate(si,is,pi)!=null,"returned public arrays cannot mutate immutable principal pin");
      for(Action action:Action.values()) {
        Principal proposed=action==Action.ENROLL?pi:target;
        DeviceGrantTranscript g=grant(action,pi,proposed,22);
        GrantSigning issuer=new GrantSigning(g,GrantRole.ISSUER),possession=new GrantSigning(g,GrantRole.TARGET_POSSESSION);
        SignaturePair issued=i.signCandidate(issuer);
        SignaturePair targetProof=action==Action.REVOKE?null:(action==Action.ENROLL?i:newDevice).signCandidate(possession);
        var result=verifyGrantCandidate(g,issued,targetProof,pi,proposed);
        check(result.action()==action && result.issuer().status().equals("CRYPTOGRAPHIC_PAIR_VALID_UNTRUSTED"),
            "actual typed "+action+" complete issuer classic AND PQ binding is evidence only, not approval");
        emit(publicEvidence,"grant-"+action.name().toLowerCase()+"-issuer",issuer,issued);
        reject(()->verifyGrantCandidate(grant(action,pi,proposed,28),issued,targetProof,pi,proposed),"complete next-state mutation rejected for "+action);
        for(int component=0;component<2;component++) {
          SignaturePair bad=change(issued,component);
          reject(()->verifyGrantCandidate(g,bad,targetProof,pi,proposed),"single issuer signature corruption cannot authorize "+action);
        }
        reject(()->verifyGrantCandidate(g,issued,targetProof,pr,proposed),"issuer resolves from independently expected current principal for "+action);
        if(action!=Action.REVOKE) {
          check(result.targetPossession()!=null && result.targetPossession().role().equals("target"),"actual target classic AND PQ possession required for "+action);
          emit(publicEvidence,"grant-"+action.name().toLowerCase()+"-target",possession,targetProof);
          reject(()->verifyGrantCandidate(g,issued,null,pi,proposed),"missing target possession rejected for "+action);
          reject(()->verifyGrantCandidate(g,issued,issued,pi,proposed),"issuer proof cannot replace target-purpose possession for "+action);
          for(int component=0;component<2;component++) {
            SignaturePair bad=change(targetProof,component);
            reject(()->verifyGrantCandidate(g,issued,bad,pi,proposed),"single target signature corruption rejected for "+action);
          }
        } else check(result.targetPossession()==null,"revoke does not require compromised target consent, still no authoritative revocation");
      }
      reject(()->grant(Action.ENROLL,pi,target,22),"first enrollment cannot claim a different device/pair without independent first binding");
      reject(()->grant(Action.ADD,pi,pr,22),"cross-subject device grant rejected");
      reject(()->new GrantSigning(null,GrantRole.ISSUER),"missing typed grant cannot be encoded");
      reject(VeilPqIdentityCandidate::requireProductionReady,"Root subject and real authority/checkpoint/review missing prevents production admission");
      check(productionGates().contains(ProductionGate.ACCOUNT_SUBJECT_NOT_PROVIDED),"Root shared A subject accurately remains NOT_PROVIDED");
      newDevice.close();newDevice.close();
      reject(()->newDevice.signCandidate(new GrantSigning(grant(Action.ADD,pi,target,22),GrantRole.TARGET_POSSESSION)),"closed candidate native key cannot sign");
      check(verifyCandidate(si,is,pi)!=null,"public proof verification is not secret destruction or device revocation");
    }
    // Bounded actual native key registry; failure never creates a fake handle.
    List<NativeKey> budget=new ArrayList<>();
    try {
      for(int j=0;j<32;j++)budget.add(VeilPqAndroidInstalledCheck.createTrackedKey("typed-budget32",j+1));
      reject(()->{try(NativeKey extra=VeilPqAndroidInstalledCheck.createTrackedKey("typed-budget33-rejection",33)){}},"actual native registry rejects 33rd live PQ key");
    } finally {for(NativeKey key:budget)key.close();}
    try(NativeKey recovered=VeilPqAndroidInstalledCheck.createTrackedKey("typed-capacity-recovery",1)) {check(recovered.pqPublic().copy().length==2592,"closing native keys frees capacity without silent key reuse");}
    return "PASS "+checks+" typed identity/grant checks: real libsignal0.104.0 JNI AND real ML-DSA-87; synthetic public trust only; SECTION5.3 UNFINISHED";
  }
  public static void main(String[] args) throws Exception {
    if(args.length!=2)throw new IllegalArgumentException("owned JNI path and public evidence directory required");
    System.load(args[0]);System.out.println(runSynthetic(Path.of(args[1])));
  }
}
