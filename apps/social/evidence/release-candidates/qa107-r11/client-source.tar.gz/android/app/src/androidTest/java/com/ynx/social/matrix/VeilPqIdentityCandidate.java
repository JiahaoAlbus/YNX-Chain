package com.ynx.social.matrix;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import org.signal.libsignal.protocol.IdentityKeyPair;
import org.signal.libsignal.protocol.ecc.ECPublicKey;

/** Dormant, typed native crypto candidate. Never issues trust, a device grant or
 * a session. Production enrollment/checkpoint/review are NOT PROVIDED here. */
public final class VeilPqIdentityCandidate {
  private VeilPqIdentityCandidate() {}
  public static final String CLASSIC_PROFILE = "LIBSIGNAL-0.104.0-XEDDSA-CANDIDATE";
  public enum ProductionGate {
    ACCOUNT_SUBJECT_NOT_PROVIDED, INDEPENDENT_DEVICE_AUTHORITY_NOT_PROVIDED,
    PROTECTED_CHECKPOINT_NOT_PROVIDED, BASELINE_EXPORT_CONFIRMATION_NOT_PROVIDED,
    DURABLE_REPLAY_COMMIT_NOT_PROVIDED, COMPOSITION_REVIEW_NOT_APPROVED
  }
  public static Set<ProductionGate> productionGates() { return Set.of(ProductionGate.values()); }
  public static void requireProductionReady() {
    throw new IllegalStateException("VEIL_PQ_PRODUCTION_NOT_PROVIDED: " + productionGates());
  }
  public enum SessionRole { INITIATOR, RESPONDER }
  public enum GrantRole { ISSUER, TARGET_POSSESSION }
  public enum Action { ENROLL, ADD, REVOKE, ROTATE, MIGRATE }
  private static String name(Enum<?> value) { return value.name().toLowerCase(java.util.Locale.ROOT); }

  /** Immutable PUBLIC bytes only. No secret/handle representation. */
  public static final class PublicBytes {
    private final byte[] bytes;
    public PublicBytes(byte[] bytes) {
      if (bytes == null || bytes.length > 65536) throw fail("PUBLIC_BYTE_BUDGET");
      this.bytes = bytes.clone();
    }
    public byte[] copy() { return bytes.clone(); }
    private byte[] raw() { return bytes; }
    private void size(int min, int max) { if (bytes.length < min || bytes.length > max) throw fail("PUBLIC_BYTE_LENGTH"); }
  }
  private static void ascii(String s, int max) {
    if (s == null || s.isEmpty() || s.length() > max) throw fail("PUBLIC_ASCII");
    for (int i=0;i<s.length();i++) if (s.charAt(i)<33 || s.charAt(i)>126) throw fail("PUBLIC_ASCII");
  }
  private static void number(long n, long min) { if (n<min || n>9007199254740991L) throw fail("PUBLIC_INTEGER"); }
  private static void lifetime(long issued, long expires) {
    number(issued,0); number(expires,0);
    if (expires<=issued || expires-issued>120000) throw fail("PUBLIC_LIFETIME");
  }
  private static IllegalArgumentException fail(String code) { return new IllegalArgumentException("VEIL_PQ_"+code); }

  public record Principal(String identity, String device, String classicalAlgorithm,
      PublicBytes classicalPublic, String pqAlgorithm, PublicBytes pqPublic,
      long keyVersion, long policyVersion, long directoryEpoch, PublicBytes directoryRoot,
      PublicBytes deviceGrant, String route) {
    public Principal {
      ascii(identity,128); ascii(device,128); ascii(classicalAlgorithm,64); ascii(route,256);
      if (!CLASSIC_PROFILE.equals(classicalAlgorithm) || !"ML-DSA-87".equals(pqAlgorithm)) throw fail("PROFILE");
      classicalPublic.size(33,33); pqPublic.size(2592,2592);
      if (classicalPublic.raw()[0]!=5) throw fail("CLASSIC_KEY_ENCODING");
      number(keyVersion,1); number(policyVersion,1); number(directoryEpoch,1);
      directoryRoot.size(32,32); deviceGrant.size(32,32);
    }
    public byte[] publicEncoding() {
      return frame(1,identity,device,classicalAlgorithm,classicalPublic,pqAlgorithm,pqPublic,
          keyVersion,policyVersion,directoryEpoch,directoryRoot,deviceGrant,route);
    }
  }
  public record SessionTranscript(String application, String realm, long extensionVersion,
      PublicBytes baselineProfile, String baselineVersion, PublicBytes sessionId,
      Principal initiator, Principal responder, PublicBytes nonceI, PublicBytes nonceR,
      long issuedAt, long expiresAt, PublicBytes ephemeralI, PublicBytes ephemeralR,
      PublicBytes prekeyI, PublicBytes prekeyR, String kemAlgorithm, PublicBytes kemPublic,
      PublicBytes kemCiphertext, PublicBytes baselineTranscript, PublicBytes offerDigest,
      PublicBytes capabilityPolicy) {
    public SessionTranscript {
      if (!"YNX-SOCIAL".equals(application) || extensionVersion!=1) throw fail("VERSION");
      ascii(realm,128); ascii(baselineVersion,64); ascii(kemAlgorithm,64);
      baselineProfile.size(32,32); sessionId.size(32,32); nonceI.size(32,32); nonceR.size(32,32);
      if (initiator==null || responder==null || (initiator.identity.equals(responder.identity) &&
          initiator.device.equals(responder.device)) || Arrays.equals(nonceI.raw(),nonceR.raw())) throw fail("REFLECTION");
      lifetime(issuedAt,expiresAt); ephemeralI.size(1,1024); ephemeralR.size(0,1024);
      prekeyI.size(0,4096); prekeyR.size(1,4096); kemPublic.size(1,4096); kemCiphertext.size(1,4096);
      baselineTranscript.size(1,16384); offerDigest.size(32,32); capabilityPolicy.size(32,32);
    }
    public byte[] publicEncoding() {
      return frame(2,application,realm,extensionVersion,baselineProfile,baselineVersion,sessionId,
          new PublicBytes(initiator.publicEncoding()),new PublicBytes(responder.publicEncoding()),
          nonceI,nonceR,issuedAt,expiresAt,ephemeralI,ephemeralR,prekeyI,prekeyR,kemAlgorithm,
          kemPublic,kemCiphertext,baselineTranscript,offerDigest,capabilityPolicy);
    }
  }
  /** Complete draft authorization, not a directory approval or active membership. */
  public record DeviceGrantTranscript(String application, String realm, long extensionVersion,
      Action action, Principal issuer, Principal target, PublicBytes previousState, PublicBytes nextState,
      long previousEpoch, long nextEpoch, PublicBytes requestId, long issuedAt, long expiresAt,
      PublicBytes trustedBinding, PublicBytes activeDeviceSet, PublicBytes migrationBinding) {
    public DeviceGrantTranscript {
      if (!"YNX-SOCIAL".equals(application) || extensionVersion!=1 || action==null || issuer==null || target==null)
        throw fail("GRANT_VERSION");
      ascii(realm,128); lifetime(issuedAt,expiresAt); number(previousEpoch,1); number(nextEpoch,2);
      previousState.size(32,32); nextState.size(32,32); requestId.size(32,32); trustedBinding.size(32,32);
      activeDeviceSet.size(1,8192); migrationBinding.size(0,4096);
      if (!issuer.identity.equals(target.identity) || nextEpoch!=previousEpoch+1 ||
          Arrays.equals(previousState.raw(),nextState.raw()) || ((action==Action.MIGRATE)!=(migrationBinding.raw().length>0)))
        throw fail("GRANT_TRANSITION");
      if (action==Action.ENROLL && (!issuer.device.equals(target.device) ||
          !Arrays.equals(issuer.classicalPublic.raw(),target.classicalPublic.raw()) ||
          !Arrays.equals(issuer.pqPublic.raw(),target.pqPublic.raw()))) throw fail("FIRST_PAIR_BINDING");
    }
    public byte[] publicEncoding() {
      return frame(3,application,realm,extensionVersion,name(action),new PublicBytes(issuer.publicEncoding()),
          new PublicBytes(target.publicEncoding()),previousState,nextState,previousEpoch,nextEpoch,requestId,
          issuedAt,expiresAt,trustedBinding,activeDeviceSet,migrationBinding);
    }
  }
  public sealed interface SigningRequest permits SessionSigning, GrantSigning {
    Principal signer(); String purpose(); String role(); byte[] transcript();
    default byte[] signingInput() { return frame(4,"YNX/SOCIAL/PQ-AUTH/SIGN/V1",purpose(),role(),new PublicBytes(transcript())); }
  }
  public record SessionSigning(SessionTranscript value, SessionRole sessionRole) implements SigningRequest {
    public SessionSigning { if (value==null || sessionRole==null) throw fail("SESSION_REQUEST"); }
    public Principal signer() { return sessionRole==SessionRole.INITIATOR ? value.initiator : value.responder; }
    public String purpose() { return "session"; }
    public String role() { return name(sessionRole); }
    public byte[] transcript() { return value.publicEncoding(); }
  }
  public record GrantSigning(DeviceGrantTranscript value, GrantRole grantRole) implements SigningRequest {
    public GrantSigning { if (value==null || grantRole==null) throw fail("GRANT_REQUEST"); }
    public Principal signer() { return grantRole==GrantRole.ISSUER ? value.issuer : value.target; }
    public String purpose() { return grantRole==GrantRole.ISSUER ? "authorization" : "possession"; }
    public String role() { return grantRole==GrantRole.ISSUER ? "issuer" : "target"; }
    public byte[] transcript() { return value.publicEncoding(); }
  }
  public record SignaturePair(String purpose, String role, PublicBytes inputDigest,
      PublicBytes classicalSignature, PublicBytes pqSignature) {
    public SignaturePair {
      boolean valid=("session".equals(purpose) && ("initiator".equals(role)||"responder".equals(role))) ||
          ("authorization".equals(purpose)&&"issuer".equals(role)) || ("possession".equals(purpose)&&"target".equals(role));
      if (!valid) throw fail("PROOF_ROLE");
      inputDigest.size(32,32); classicalSignature.size(64,64); pqSignature.size(4627,4627);
    }
    public byte[] publicEncoding() { return frame(5,purpose,role,inputDigest,classicalSignature,pqSignature); }
  }
  /** Constructor is private: only real AND verification produces this evidence.
   * It has NO trust/admission/confirmed-session status or conversion API. */
  public static final class SignatureEvidence {
    private final PublicBytes transcriptDigest, signerDigest;
    private final String purpose, role;
    private SignatureEvidence(SigningRequest r) {
      transcriptDigest=new PublicBytes(hash(r.transcript())); signerDigest=new PublicBytes(hash(r.signer().publicEncoding()));
      purpose=r.purpose(); role=r.role();
    }
    public PublicBytes transcriptDigest() { return transcriptDigest; }
    public PublicBytes signerDigest() { return signerDigest; }
    public String purpose() { return purpose; }
    public String role() { return role; }
    public String status() { return "CRYPTOGRAPHIC_PAIR_VALID_UNTRUSTED"; }
  }
  public record MutualSignatureEvidence(SignatureEvidence initiator, SignatureEvidence responder) {}
  public record GrantSignatureEvidence(Action action, SignatureEvidence issuer, SignatureEvidence targetPossession) {}

  /** Fresh independent candidate key only. Does not create an account/device grant.
   * Classic private key stays in actual libsignal JNI; PQ key in locked native heap.
   * No getter exports either key or either native handle. No persistence is invented. */
  public static final class NativeKey implements AutoCloseable {
    private IdentityKeyPair classic;
    private long pqToken;
    private final PublicBytes classicPublic, pqPublic;
    private NativeKey() {
      classic=IdentityKeyPair.generate();
      classicPublic=new PublicBytes(classic.getPublicKey().serialize());
      pqToken=createPq();
      try { pqPublic=new PublicBytes(publicPq(pqToken)); }
      catch (Throwable e) { destroyPq(pqToken); pqToken=0; classic=null; throw e; }
    }
    public PublicBytes classicalPublic() { return classicPublic; }
    public PublicBytes pqPublic() { return pqPublic; }
    public synchronized SignaturePair signCandidate(SigningRequest request) {
      if (pqToken==0 || classic==null) throw fail("KEY_CLOSED");
      if (!Arrays.equals(request.signer().classicalPublic.raw(),classicPublic.raw()) ||
          !Arrays.equals(request.signer().pqPublic.raw(),pqPublic.raw())) throw fail("SIGNER_KEY_BINDING");
      byte[] m=request.signingInput();
      byte[] c=classic.getPrivateKey().calculateSignature(m), p=signPq(pqToken,m);
      return new SignaturePair(request.purpose(),request.role(),new PublicBytes(hash(m)),new PublicBytes(c),new PublicBytes(p));
    }
    public synchronized void close() {
      if (pqToken!=0) { destroyPq(pqToken); pqToken=0; classic=null; }
      // libsignal SimpleOwner releases classical keys through its own lifecycle;
      // no fabricated explicit destructor or serialization-based zeroization.
    }
  }
  public static NativeKey createCandidateKey() { return new NativeKey(); }
  public static SignatureEvidence verifyCandidate(SigningRequest request, SignaturePair proof, Principal locallyExpectedSigner) {
    if (!Arrays.equals(request.signer().publicEncoding(),locallyExpectedSigner.publicEncoding()) ||
        !request.purpose().equals(proof.purpose) || !request.role().equals(proof.role)) throw fail("EXPECTED_SIGNER_OR_ROLE");
    byte[] m=request.signingInput();
    if (!MessageDigest.isEqual(hash(m),proof.inputDigest.raw())) throw fail("INPUT_ASSOCIATION");
    boolean classicValid;
    try { classicValid=new ECPublicKey(locallyExpectedSigner.classicalPublic.copy()).verifySignature(m,proof.classicalSignature.copy()); }
    catch (Exception e) { throw fail("CLASSIC_VERIFY"); }
    boolean pqValid=verifyPq(locallyExpectedSigner.pqPublic.copy(),m,proof.pqSignature.copy());
    if (!(classicValid && pqValid)) throw fail("AND_SIGNATURE_REQUIRED");
    return new SignatureEvidence(request);
  }
  public static MutualSignatureEvidence verifyMutualCandidate(SessionTranscript t, SignaturePair i, SignaturePair r,
      Principal expectedI, Principal expectedR) {
    SignatureEvidence ei=verifyCandidate(new SessionSigning(t,SessionRole.INITIATOR),i,expectedI);
    SignatureEvidence er=verifyCandidate(new SessionSigning(t,SessionRole.RESPONDER),r,expectedR);
    return new MutualSignatureEvidence(ei,er); // Signature evidence, NOT key confirmation.
  }
  public static GrantSignatureEvidence verifyGrantCandidate(DeviceGrantTranscript t, SignaturePair issuer,
      SignaturePair possession, Principal expectedIssuer, Principal expectedTarget) {
    if (!Arrays.equals(t.target.publicEncoding(),expectedTarget.publicEncoding())) throw fail("EXPECTED_TARGET");
    SignatureEvidence ei=verifyCandidate(new GrantSigning(t,GrantRole.ISSUER),issuer,expectedIssuer);
    SignatureEvidence target=null;
    if (t.action!=Action.REVOKE) {
      if (possession==null) throw fail("TARGET_POSSESSION_REQUIRED");
      target=verifyCandidate(new GrantSigning(t,GrantRole.TARGET_POSSESSION),possession,expectedTarget);
    } else if (possession!=null) throw fail("REVOKE_PROOF_POLICY");
    return new GrantSignatureEvidence(t.action,ei,target); // Never a VeilVerifiedDeviceGrant.
  }
  private static byte[] hash(byte[] bytes) {
    try { return MessageDigest.getInstance("SHA-256").digest(bytes); }
    catch (Exception e) { throw new IllegalStateException("SHA256_UNAVAILABLE",e); }
  }
  private static byte[] frame(int type, Object... fields) {
    try {
      ByteArrayOutputStream bytes=new ByteArrayOutputStream(); DataOutputStream out=new DataOutputStream(bytes);
      out.writeBytes("YPA1"); out.writeByte(type); out.writeByte(1); out.writeShort(fields.length);
      for (int i=0;i<fields.length;i++) {
        byte[] body;
        if (fields[i] instanceof PublicBytes b) body=b.raw();
        else if (fields[i] instanceof String s) { ascii(s,256); body=s.getBytes(StandardCharsets.US_ASCII); }
        else if (fields[i] instanceof Long n) {
          number(n,0); ByteArrayOutputStream number=new ByteArrayOutputStream(); DataOutputStream integer=new DataOutputStream(number);
          integer.writeLong(n); body=number.toByteArray();
        } else throw fail("ENCODING_TYPE");
        out.writeShort(i+1); out.writeInt(body.length); out.write(body);
        if (bytes.size()>65536) throw fail("FRAME_BUDGET");
      }
      byte[] result=bytes.toByteArray();
      if (type==4 && fields[3] instanceof PublicBytes b) b.size(1,49152);
      return result;
    } catch (java.io.IOException e) { throw new IllegalStateException("PUBLIC_ENCODING",e); }
  }
  private static synchronized native long createPq();
  private static synchronized native byte[] publicPq(long token);
  private static synchronized native byte[] signPq(long token, byte[] message);
  private static synchronized native boolean verifyPq(byte[] publicKey, byte[] message, byte[] signature);
  private static synchronized native void destroyPq(long token);
}
