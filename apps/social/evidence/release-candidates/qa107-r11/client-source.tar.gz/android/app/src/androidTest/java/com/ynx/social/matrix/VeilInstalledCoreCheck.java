package com.ynx.social.matrix;

import android.app.Activity;
import android.app.Instrumentation;
import android.os.Bundle;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/** QA APK only. Native loading/key generation is NOT session admission. */
public final class VeilInstalledCoreCheck extends Instrumentation {
  @Override public void onCreate(Bundle arguments) {
    super.onCreate(arguments);
    start();
  }

  @Override public void onStart() {
    Bundle result = new Bundle();
    recordLockLimit(result);
    int status = Activity.RESULT_CANCELED;
    try {
      ClassLoader loader = getTargetContext().getClassLoader();
      requireAbsent("com.ynx.social.matrix.YNXSocialMatrixModule", loader);
      requireAbsent("com.ynx.social.matrix.MatrixBindingRecord", loader);
      result.putString("retiredBridge", "PASS_ANDROID_OLD_BRIDGE_CLASS_ABSENT_ONLY");
      System.loadLibrary("ynx_veil");
      Class<?> identity = Class.forName(
          "org.signal.libsignal.protocol.IdentityKeyPair", true, loader);
      require(identity.getMethod("generate").invoke(null) != null);
      Class<?> kemType = Class.forName(
          "org.signal.libsignal.protocol.kem.KEMKeyType", true, loader);
      Class<?> kemPair = Class.forName(
          "org.signal.libsignal.protocol.kem.KEMKeyPair", true, loader);
      Object kyber = kemType.getField("KYBER_1024").get(null);
      require(kemPair.getMethod("generate", kemType).invoke(null, kyber) != null);
      Class.forName("com.ynx.social.matrix.VeilSignalOutbox", false, loader);
      Class.forName("com.ynx.social.matrix.VeilSignalInbox", false, loader);
      Class.forName("com.ynx.social.matrix.VeilMatrixPipeline", false, loader);
      checkFailedResultCleanup();
      result.putString("failedResultCleanup", "PASS_LOCAL_DISPOSAL_ONLY");
      checkWriteBudget();
      result.putString("writeBudget", "PASS_LOCAL_RESERVATION_ONLY");
      checkPrimaryFailureAndPendingOwnership();
      result.putString("primaryFailureAndPendingOwnership", "PASS_LOCAL_LIFECYCLE_ONLY");
      result.putString("enrollmentPolicy", VeilEnrollmentPolicyCheck.run(getTargetContext()));
      result.putString("spqrSyntheticDiagnostic",
          com.ynx.social.veilqa.spqr.VeilSpqrRuntimeCheck.runSynthetic());
      result.putString("deviceFanoutSyntheticDiagnostic",
          VeilAuthorizedDeviceFanoutCheck.runSynthetic());
      result.putString("nativeCarrier", "LOAD_AND_EPHEMERAL_KEY_GENERATION_PASS");
      result.putString("libsignalVersion", "0.104.0");
      result.putString("protectedSession", "NOT_VERIFIED");
      result.putString("productionActivation", "NOT_PERFORMED");
      status = Activity.RESULT_OK;
    } catch (Throwable failure) {
      // Do not serialize exception messages, objects, generated keys or state.
      result.putString("nativeCarrier", "FAIL");
      result.putString("failureType", failure.getClass().getName());
      String code = failure.getMessage();
      if (code != null && code.matches("(?:VEIL_|QA_)[A-Z0-9_]{1,100}")) {
        result.putString("failureCode", code);
      }
      int sites = 0;
      for (StackTraceElement frame : failure.getStackTrace()) {
        if (frame.getClassName().startsWith("com.ynx.social.")) {
          result.putString(sites == 0 ? "failureSite" : "failureSite" + sites,
              frame.getClassName() + "."
              + frame.getMethodName() + ":" + frame.getLineNumber());
          if (++sites == 8) break;
        }
      }
    }
    finish(status, result);
  }

  private static void recordLockLimit(Bundle result) {
    // Test-process policy only: never dump proc status, keys, state or user data.
    try (BufferedReader reader = new BufferedReader(new FileReader("/proc/self/limits"))) {
      for (int lines = 0; lines < 64; ++lines) {
        String line = reader.readLine();
        if (line == null) break;
        if (!line.startsWith("Max locked memory")) continue;
        String[] fields = line.substring("Max locked memory".length()).trim().split("\\s+");
        if (fields.length == 3 && fields[0].matches("[0-9]{1,20}|unlimited")
            && fields[1].matches("[0-9]{1,20}|unlimited") && fields[2].equals("bytes")) {
          result.putString("processLockLimitSoftBytes", fields[0]);
          result.putString("processLockLimitHardBytes", fields[1]);
        }
        return;
      }
    } catch (IOException ignored) {
      result.putString("processLockLimit", "UNAVAILABLE");
    }
  }

  private static void require(boolean condition) {
    if (!condition) throw new AssertionError("NATIVE_OPERATION_FAILED");
  }

  private static void requireAbsent(String name, ClassLoader loader) throws ClassNotFoundException {
    try {
      Class.forName(name, false, loader);
    } catch (ClassNotFoundException expected) {
      return;
    }
    throw new AssertionError("QA_RETIRED_CORE_CLASS_PRESENT");
  }

  private static void checkFailedResultCleanup() {
    byte[] uncommitted = new byte[] {1, 2, 3};
    require(VeilTransactionResult.discardFailed(uncommitted) == null);
    for (byte value : uncommitted) require(value == 0);
    int[] closes = new int[] {0};
    AutoCloseable pending = () -> ++closes[0];
    require(VeilTransactionResult.discardFailed(pending) == null && closes[0] == 1);
    Exception original = new Exception("QA_CLOSE_FAILURE");
    AutoCloseable broken = () -> { throw original; };
    require(VeilTransactionResult.discardFailed(broken) == original);
    require(VeilTransactionResult.discardFailed(null) == null);
  }

  private static void checkWriteBudget() {
    VeilWriteBudget.requireReplacement(0, 0, 0, 1);
    VeilWriteBudget.requireReplacement(4096, 64L * 1024 * 1024, 29, 1);
    rejectBudget(4096, 29L * 4096, 0, 1);
    rejectBudget(1, 64L * 1024 * 1024, 0, 1);
    rejectBudget(0, 0, 0, 8 * 1024 * 1024 + 1);
    rejectBudget(0, 0, 29, 1);
    rejectBudget(Long.MAX_VALUE, Long.MAX_VALUE, 0, 1);
  }

  private static void rejectBudget(long rows, long total, long existing, int bytes) {
    try {
      VeilWriteBudget.requireReplacement(rows, total, existing, bytes);
    } catch (IllegalArgumentException expected) {
      return;
    }
    throw new AssertionError("QA_STORAGE_BUDGET_ACCEPTED");
  }

  private static void checkPrimaryFailureAndPendingOwnership() {
    Exception primary = new Exception("QA_PRIMARY_FAILURE");
    Exception secondary = new Exception("QA_END_TRANSACTION_FAILURE");
    require(VeilTransactionResult.preserveFailure(primary, secondary) == primary);
    require(primary.getSuppressed().length == 1 && primary.getSuppressed()[0] == secondary);
    require(VeilTransactionResult.preserveFailure(primary, primary) == primary);
    require(primary.getSuppressed().length == 1);
    byte[] wire = new byte[] {4, 5, 6};
    VeilSignalOutbox.PendingCiphertext pending = new VeilSignalOutbox.PendingCiphertext(
        org.signal.libsignal.protocol.message.CiphertextMessage.WHISPER_TYPE,
        java.util.UUID.randomUUID(), wire);
    wire[0] = 9;
    byte[] copy = pending.serialize();
    require(copy[0] == 4);
    java.util.Arrays.fill(copy, (byte) 0);
    require(VeilTransactionResult.discardFailed(pending) == null);
    pending.close();
    try {
      pending.serialize();
    } catch (IllegalStateException expected) {
      require("VEIL_PENDING_CIPHERTEXT_CLOSED".equals(expected.getMessage()));
      return;
    }
    throw new AssertionError("QA_CLOSED_CIPHERTEXT_EXPORTED");
  }
}
