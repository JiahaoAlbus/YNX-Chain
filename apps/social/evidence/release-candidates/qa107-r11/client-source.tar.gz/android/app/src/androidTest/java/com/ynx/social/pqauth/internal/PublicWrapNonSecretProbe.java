package com.ynx.social.pqauth.internal;

import android.content.Context;
import java.io.*;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import javax.crypto.AEADBadTagException;
import javax.crypto.BadPaddingException;
import org.json.*;

/** Exact owned API36 NONSECRET fixture entry. Never accepts a caller payload or alias. */
public final class PublicWrapNonSecretProbe {
    private PublicWrapNonSecretProbe() {}
    private static final byte[] PUBLIC_CLEAR = "YNX PUBLIC NONSECRET ANDROID KEYSTORE QA 20261005".getBytes(StandardCharsets.US_ASCII);
    private static final WrapRecord.Binding BINDING = new WrapRecord.Binding("provider-cold-reopen", 1);
    private static final String LEAF = "ynx-publicwrap-" + WrapRecord.SCOPE;
    public static String createAndSeal(Context targetContext) { return run(targetContext, false); }
    public static String reopenAndCheck(Context targetContext) { return run(targetContext, true); }
    private static String run(Context context, boolean reopen) {
        JSONObject result = new JSONObject(), provider = new JSONObject(); JSONArray events = new JSONArray(), cases = new JSONArray();
        String stage = "calling-process-guard";
        try {
            result.put("scope", WrapRecord.SCOPE); result.put("profile", WrapRecord.PROFILE);
            result.put("mode", reopen ? "COLD_REOPEN" : "CREATE_SEAL");
            result.put("payload", "FIXED_PUBLIC_NONSECRET_ONLY");
            result.put("identityEvents", events); result.put("provider", provider); result.put("cases", cases);
            EnginePlatformWrap.Guard guard = new EnginePlatformWrap.Guard(context, events); guard.check(stage);
            File root = context.getFilesDir(); if (root == null) throw new IOException("APP_FILES_UNAVAILABLE");
            File recordFile = new File(root, LEAF + ".checkpoint"), lockFile = new File(root, LEAF + ".lock");
            stage = "owned-checkpoint-lock";
            try (RandomAccessFile lock = new RandomAccessFile(lockFile, "rw"); FileChannel channel = lock.getChannel()) {
                FileLock acquired = channel.tryLock(); if (acquired == null) throw new IOException("QA_SCOPE_BUSY");
                try (FileLock held = acquired) {
                    WrapRecord record;
                    if (reopen) {
                        stage = "cold-checkpoint-identity";
                        record = readCheckpoint(recordFile, guard);
                        pass(cases, "same-uid-sid-different-pid-checkpoint");
                        stage = "existing-key-lookup-no-create";
                        try (EnginePlatformWrap wrap = EnginePlatformWrap.lookupQa(guard, provider)) {
                            stage = "cold-provider-tests"; test(wrap, record, cases);
                        }
                    } else {
                        if (recordFile.exists()) throw new IOException("CHECKPOINT_COLLISION_PRESERVED");
                        stage = "unique-alias-create";
                        try (EnginePlatformWrap wrap = EnginePlatformWrap.createQa(guard, provider)) {
                            stage = "provider-seal"; record = wrap.seal(BINDING, PUBLIC_CLEAR);
                            stage = "provider-tests"; test(wrap, record, cases);
                            stage = "checkpoint-exclusive-create-fsync";
                            writeCheckpoint(recordFile, record, guard);
                            pass(cases, "exact-ciphertext-checkpoint-fsync");
                        }
                    }
                }
            }
            result.put("status", "PASS"); result.put("stage", "COMPLETE");
            result.put("platformKeyDisposition", "RETAINED_EXACT_ALIAS_NO_DELETE");
            result.put("productionAdmission", false);
        } catch (Exception failure) {
            // Never serialize exception message/cause/stack, payload or key handle.
            try {
                result.put("status", "FAIL"); result.put("stage", stage);
                result.put("primaryExceptionClass", failure.getClass().getName());
                result.put("retryPolicy", "STOP_RETAIN_INSPECT_NO_REGENERATION_OR_CLEANUP_DELETE");
            } catch (JSONException formattingFailure) { return "{\"status\":\"FAIL\",\"stage\":\"PUBLIC_RESULT_FORMATTING\"}"; }
        }
        return result.toString();
    }
    private static void test(EnginePlatformWrap wrap, WrapRecord original, JSONArray cases) throws Exception {
        byte[] opened = null;
        try { opened = wrap.unseal(original); require(Arrays.equals(opened, PUBLIC_CLEAR)); pass(cases, "public-roundtrip"); }
        finally { wipe(opened); }
        byte[] encoded = original.encode();
        try {
            WrapRecord decoded = WrapRecord.decode(encoded, BINDING);
            try { opened = wrap.unseal(decoded); require(Arrays.equals(opened, PUBLIC_CLEAR)); pass(cases, "exact-record-retry-no-reseal"); }
            finally { wipe(opened); opened = null; }
        } finally { wipe(encoded); }
        byte[] changed = original.ciphertext(); changed[0] ^= 1;
        rejectAuth(wrap, new WrapRecord(BINDING, original.nonce(), changed), cases, "ciphertext-tamper"); wipe(changed);
        changed = original.ciphertext(); changed[changed.length - 1] ^= 1;
        rejectAuth(wrap, new WrapRecord(BINDING, original.nonce(), changed), cases, "tag-tamper"); wipe(changed);
        changed = original.nonce(); changed[0] ^= 1;
        rejectAuth(wrap, new WrapRecord(BINDING, changed, original.ciphertext()), cases, "nonce-tamper"); wipe(changed);
        rejectAuth(wrap, new WrapRecord(new WrapRecord.Binding("wrong-record", 1), original.nonce(), original.ciphertext()), cases, "aad-record-id-tamper");
        rejectAuth(wrap, new WrapRecord(new WrapRecord.Binding("provider-cold-reopen", 2), original.nonce(), original.ciphertext()), cases, "aad-generation-tamper");
        byte[] empty = new byte[0]; WrapRecord emptyRecord = wrap.seal(BINDING, empty);
        try { opened = wrap.unseal(emptyRecord); require(opened.length == 0); pass(cases, "empty-nonsecret"); }
        finally { wipe(opened); opened = null; }
        byte[] bounded = new byte[WrapRecord.MAX_CLEAR]; Arrays.fill(bounded, (byte)'Q');
        try { opened = wrap.unseal(wrap.seal(BINDING, bounded)); require(Arrays.equals(opened, bounded)); pass(cases, "max-bounded-public-data"); }
        finally { wipe(opened); opened = null; wipe(bounded); }
        try { wrap.seal(BINDING, new byte[WrapRecord.MAX_CLEAR + 1]); throw new IOException("OVERSIZE_ACCEPTED"); }
        catch (IllegalArgumentException expectedBounds) { pass(cases, "oversize-rejected"); }
        byte[][] nonces = new byte[8][];
        try {
            for (int i = 0; i < nonces.length; ++i) {
                nonces[i] = wrap.seal(BINDING, PUBLIC_CLEAR).nonce();
                for (int j = 0; j < i; ++j) require(!Arrays.equals(nonces[i], nonces[j]));
            }
            pass(cases, "eight-provider-nonces-distinct-observed-not-proof");
        } finally { for (byte[] n : nonces) wipe(n); }
        wrap.close();
        try { wrap.seal(BINDING, PUBLIC_CLEAR); throw new IOException("CLOSED_ACCEPTED"); }
        catch (IllegalStateException expectedClosed) { pass(cases, "closed-handle-denied"); }
    }
    private static void rejectAuth(EnginePlatformWrap wrap, WrapRecord bad, JSONArray cases, String id) throws Exception {
        byte[] unexpected = null;
        try { unexpected = wrap.unseal(bad); throw new IOException("AUTH_FAILURE_ACCEPTED"); }
        catch (AEADBadTagException expectedTag) { pass(cases, id + ":AEADBadTagException"); }
        catch (BadPaddingException expectedTag) { pass(cases, id + ":BadPaddingException"); }
        finally { wipe(unexpected); }
    }
    private static void writeCheckpoint(File file, WrapRecord record, EnginePlatformWrap.Guard guard) throws Exception {
        guard.check("checkpoint-write");
        if (!file.createNewFile()) throw new IOException("CHECKPOINT_COLLISION_PRESERVED");
        // Partial/unknown file is retained on failure. No regeneration or automatic delete/retry.
        byte[] bytes = record.encode(), sid = guard.sid().getBytes(StandardCharsets.US_ASCII);
        try (FileOutputStream stream = new FileOutputStream(file); DataOutputStream out = new DataOutputStream(stream)) {
            out.writeInt(0x59514331); out.writeInt(WrapRecord.UID); out.writeInt(guard.pid());
            out.writeInt(sid.length); out.write(sid); out.writeInt(bytes.length); out.write(bytes); out.flush(); stream.getFD().sync();
        } finally { wipe(bytes); wipe(sid); }
    }
    private static WrapRecord readCheckpoint(File file, EnginePlatformWrap.Guard guard) throws Exception {
        guard.check("checkpoint-read");
        if (!file.isFile() || file.length() > WrapRecord.MAX_RECORD + 512) throw new IOException("CHECKPOINT_UNAVAILABLE_OR_BOUNDS");
        try (DataInputStream in = new DataInputStream(new FileInputStream(file))) {
            if (in.readInt() != 0x59514331 || in.readInt() != WrapRecord.UID) throw new IOException("CHECKPOINT_SCOPE");
            int priorPid = in.readInt(); if (priorPid <= 0 || priorPid == guard.pid()) throw new IOException("COLD_PROCESS_NOT_OBSERVED");
            int n = in.readInt(); if (n < 1 || n > 256) throw new IOException("SID_BOUNDS");
            byte[] sid = new byte[n]; in.readFully(sid);
            try { require(guard.sid().equals(new String(sid, StandardCharsets.US_ASCII))); } finally { wipe(sid); }
            n = in.readInt(); if (n < 1 || n > WrapRecord.MAX_RECORD) throw new IOException("RECORD_BOUNDS");
            byte[] record = new byte[n];
            try { in.readFully(record); if (in.read() != -1) throw new IOException("TRAILING_RECORD_DATA"); return WrapRecord.decode(record, BINDING); }
            finally { wipe(record); }
        }
    }
    private static void require(boolean condition) throws IOException { if (!condition) throw new IOException("QA_ASSERTION_FAILED"); }
    private static void wipe(byte[] b) { if (b != null) Arrays.fill(b, (byte)0); }
    private static void pass(JSONArray cases, String id) { cases.put(id); }
}
