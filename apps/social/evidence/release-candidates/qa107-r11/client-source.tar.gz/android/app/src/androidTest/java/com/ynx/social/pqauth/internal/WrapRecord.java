package com.ynx.social.pqauth.internal;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;

// QA local checkpoint format ONLY; not a production own-key record or message wire format.
final class WrapRecord {
    static final int MAX_CLEAR = 4096, NONCE_BYTES = 12, TAG_BYTES = 16, MAX_AAD = 1024, MAX_RECORD = 8192;
    static final String SCOPE = "5f21eea6a6f84897be2d7761e0c5702e";
    static final String PACKAGE = "com.ynx.social.veilqa";
    static final String ALIAS = "ynx.social.veilqa.publicwrap.20261005." + SCOPE;
    static final String PROFILE = "YNX/SOCIAL/PUBLICWRAP/NONSECRET-QA/API36/V1";
    static final int UID = 10213;
    static final class Binding {
        private final byte[] value;
        Binding(String recordId, long generation) {
            if (!recordId.matches("[A-Za-z0-9_-]{1,64}") || generation < 1) throw new IllegalArgumentException("BINDING_BOUNDS");
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                DataOutputStream d = new DataOutputStream(out);
                for (String s : new String[]{PROFILE, PACKAGE, SCOPE, ALIAS, "QA_NONSECRET", recordId}) {
                    byte[] b = s.getBytes(StandardCharsets.UTF_8); d.writeInt(b.length); d.write(b);
                }
                d.writeInt(UID); d.writeLong(generation); d.flush(); value = out.toByteArray();
                if (value.length > MAX_AAD) throw new IllegalArgumentException("AAD_BOUNDS");
            } catch (IOException impossible) { throw new AssertionError(impossible); }
        }
        byte[] aad() { return value.clone(); }
    }
    final Binding binding;
    private final byte[] nonce, ciphertext;
    WrapRecord(Binding binding, byte[] nonce, byte[] ciphertext) {
        if (binding == null || nonce == null || nonce.length != NONCE_BYTES || ciphertext == null
                || ciphertext.length < TAG_BYTES || ciphertext.length > MAX_CLEAR + TAG_BYTES)
            throw new IllegalArgumentException("ENVELOPE_BOUNDS");
        this.binding = binding; this.nonce = nonce.clone(); this.ciphertext = ciphertext.clone();
    }
    byte[] nonce() { return nonce.clone(); }
    byte[] ciphertext() { return ciphertext.clone(); }
    byte[] encode() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); DataOutputStream d = new DataOutputStream(out);
        byte[] aad = binding.aad();
        try {
            d.writeInt(0x59515731); d.writeInt(1); d.writeInt(aad.length); d.write(aad);
            d.write(nonce); d.writeInt(ciphertext.length); d.write(ciphertext); d.flush();
            byte[] result = out.toByteArray();
            if (result.length > MAX_RECORD) throw new IOException("RECORD_BOUNDS");
            return result;
        } finally { Arrays.fill(aad, (byte)0); }
    }
    static WrapRecord decode(byte[] encoded, Binding expected) throws IOException {
        if (encoded == null || encoded.length > MAX_RECORD || expected == null) throw new IOException("RECORD_BOUNDS");
        DataInputStream d = new DataInputStream(new ByteArrayInputStream(encoded));
        if (d.readInt() != 0x59515731 || d.readInt() != 1) throw new IOException("RECORD_PROFILE");
        int a = d.readInt(); if (a < 1 || a > MAX_AAD) throw new IOException("AAD_BOUNDS");
        byte[] aad = new byte[a], wanted = expected.aad();
        try {
            d.readFully(aad); if (!MessageDigest.isEqual(aad, wanted)) throw new IOException("RECORD_BINDING");
        } finally { Arrays.fill(aad, (byte)0); Arrays.fill(wanted, (byte)0); }
        byte[] nonce = new byte[NONCE_BYTES]; d.readFully(nonce);
        int n = d.readInt(); if (n < TAG_BYTES || n > MAX_CLEAR + TAG_BYTES || n != d.available()) throw new IOException("CIPHERTEXT_BOUNDS");
        byte[] ciphertext = new byte[n]; d.readFully(ciphertext);
        return new WrapRecord(expected, nonce, ciphertext);
    }
}
