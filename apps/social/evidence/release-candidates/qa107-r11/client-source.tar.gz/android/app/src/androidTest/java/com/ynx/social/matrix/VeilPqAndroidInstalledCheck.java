package com.ynx.social.matrix;

import android.os.Build;
import android.os.Process;
import java.nio.file.Files;
import java.nio.file.Path;
import static com.ynx.social.matrix.VeilPqIdentityCandidate.*;

/** Test-only carrier. Main runs this on its actual dedicated emulator. No Main
 * factory, account/device admission, checkpoint or production trust conversion. */
public final class VeilPqAndroidInstalledCheck {
  private VeilPqAndroidInstalledCheck() {}
  private static final ThreadLocal<String> phase=new ThreadLocal<>();
  private static final ThreadLocal<String> publicEnvironment=new ThreadLocal<>();
  static NativeKey createTrackedKey(String stage,int index) {
    phase.set(stage+"; allocationIndex="+index);
    long before=lockedBytesNative();
    String measuredEnvironment=publicEnvironment.get();
    NativeKey key;
    try {
      key=createCandidateKey();
    } catch(RuntimeException|Error failure) {
      // Entire secondary expression, including lambda allocation, is protected.
      // No entropy/probe in catch: use immutable pre-attempt measurements only.
      try { VeilPqQaObservation.bestEffort(() -> System.out.println(
          "VEIL_PQ_QA_ALLOCATION_FAILED; "+phase.get()+"; code="+failure.getMessage()+
          "; lockedBefore="+before+"; lockedAtFailure=NOT_RESAMPLED"+
          "; publicEnvironment="+measuredEnvironment+
          "; primitiveSubstage=SEE_NATIVE_STAGE_IN_CODE; diagnosticVariant=OWN_NATIVE_ALLOCATION_DIAGNOSTIC_V2; NO_LIMIT_OR_MLOCK_CHANGE"));
      } catch(Throwable ignored) {}
      throw failure;
    }
    // A bad success sink must not turn an allocated key into a leaked failure.
    try { VeilPqQaObservation.bestEffort(() -> System.out.println(
        "VEIL_PQ_QA_ALLOCATED; "+phase.get()+"; lockedBefore="+before+"; lockedAfter="+lockedBytesNative()+"; nativeObservation="+allocationObservationNative()));
    } catch(Throwable ignored) {}
    return key;
  }
  private static void require(boolean ok,String code) {
    if(!ok)throw new IllegalStateException("VEIL_PQ_ANDROID_"+code);
  }
  public static synchronized String runSynthetic(Path ownedPublicEvidence) throws Exception {
    try { return runBody(ownedPublicEvidence); }
    finally {
      try { phase.remove(); publicEnvironment.remove(); } catch(Throwable ignored) {}
    }
  }
  private static String runBody(Path ownedPublicEvidence) throws Exception {
    require(Build.VERSION.SDK_INT>=26 && Process.is64Bit(),"API_OR_PROCESS_ABI_UNSUPPORTED");
    // Main stages the exact arm64 library; never load a desktop dylib or a stub.
    System.loadLibrary("veil_pq_identity_candidate");
    long[] env=environmentNative();
    require(env!=null && env.length==6 && env[0]>=26 && env[1]==8 && env[2]>0,"NATIVE_ENVIRONMENT_UNAVAILABLE");
    require(env[5]==3,"OS_RNG_SMOKE_FAILED");
    publicEnvironment.set(java.util.Arrays.toString(env));
    System.out.println("VEIL_PQ_QA_ENVIRONMENT; api,wordBytes,pageBytes,memlockSoft,memlockHard,rngFlags="+java.util.Arrays.toString(env));
    long before=lockedBytesNative(),during,after;
    require(before>=0,"LOCKED_MEMORY_OBSERVATION_NOT_PROVIDED");
    try(NativeKey local=createTrackedKey("single-own-key-precheck",1)) {
      // A SINGLE locally held fresh private pair, never importing a remote key.
      require(local.pqPublic().copy().length==2592,"LOCAL_KEY_UNAVAILABLE");
      during=lockedBytesNative();
      require(during>before,"LOCKED_SECRET_REGISTRY_NOT_OBSERVED");
    }
    after=lockedBytesNative();
    require(after==before,"LOCKED_SECRET_CLOSE_NOT_OBSERVED");
    System.out.println("VEIL_PQ_QA_SINGLE_KEY_PRECHECK_PASS; lockedBefore="+before+"; lockedDuring="+during+"; lockedAfter="+after);
    // Do not raise/lower RLIMIT_MEMLOCK or weaken mlock to force the QA through.
    // Original 70 cases include bounded 32-key registry tests. Insufficient OS
    // locked memory is a real runtime limitation/failure, NOT a skipped PASS.
    Files.createDirectories(ownedPublicEvidence);
    String original;
    phase.set("typed-check-entry");
    try {
      original=VeilPqIdentityTypedCheck.runSynthetic(ownedPublicEvidence);
    } catch(Exception|Error failure) {
      try { VeilPqQaObservation.bestEffort(() -> System.out.println(
          "VEIL_PQ_QA_TYPED_FAILED; lastPhase="+phase.get()+"; lockedAfterCleanup="+lockedBytesNative()+
          "; class="+failure.getClass().getName()+"; code="+failure.getMessage()+"; ORIGINAL70_NOT_PASSED; PRODUCTION_NOT_VERIFIED"));
      } catch(Throwable ignored) {}
      throw failure;
    }
    require(original.startsWith("PASS 70 "),"ORIGINAL_TYPED_CHECK_COUNT_MISMATCH");
    require(productionGates().contains(ProductionGate.ACCOUNT_SUBJECT_NOT_PROVIDED),"PRODUCTION_GATES_CHANGED");
    return "ANDROID_INSTALLED_CANDIDATE_PASS; api="+env[0]+"; wordBytes="+env[1]+"; pageBytes="+env[2]+
        "; memlockSoft="+env[3]+"; memlockHard="+env[4]+"; lockedBefore="+before+
        "; lockedDuring="+during+"; lockedAfter="+after+"; OS_RNG_SMOKE_PASS; "+original+
        "; subject/authority/checkpoint NOT_PROVIDED; SECTION5.3 UNFINISHED";
  }
  private static native String allocationObservationNative();
  private static native long[] environmentNative();
  private static native long lockedBytesNative();
}
