package com.ynx.social.matrix;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

/** Android policy/authority refusal diagnostics; never creates or reads keys. */
final class VeilEnrollmentPolicyCheck {
  static String run(android.content.Context context) {
    String alias = "ynx.social.veil.v2.qa-policy-only";
    VeilDeviceBinding binding = new VeilDeviceBinding("qa-policy-owner", "qa-device", "qa-public-id", alias);
    VeilNativeEnrollment.validatePolicy(binding, policy(alias, 256, true, 60, "GCM"));
    reject(binding, policy("ynx.social.veil.v2.other", 256, true, 60, "GCM"));
    reject(binding, policy(alias, 128, true, 60, "GCM"));
    reject(binding, policy(alias, 256, false, 60, "GCM"));
    reject(binding, policy(alias, 256, true, -1, "GCM"));
    reject(binding, policy(alias, 256, true, 121, "GCM"));
    reject(binding, policy(alias, 256, true, 60, "CBC"));
    VeilNativeAuthority authority = new VeilNativeAuthority(binding,
        (proof, expected, generation) -> { throw new IllegalStateException("QA_NO_DEVICE_PROVIDER"); },
        () -> android.os.SystemClock.elapsedRealtime());
    VeilNativeLease unadmitted = VeilNativeLease.Companion.issue(binding);
    try {
      VeilNativeEnrollment.INSTANCE.enroll(context, authority, unadmitted, policy(alias, 256, true, 60, "GCM"));
    } catch (IllegalStateException expected) {
      if (!"VEIL_LEASE_REVOKED_OR_FOREIGN".equals(expected.getMessage())) throw expected;
      return "PASS_POLICY_AND_UNADMITTED_LEASE_REFUSAL_ONLY_NO_KEYS_CREATED";
    }
    throw new AssertionError("QA_UNADMITTED_KEY_ENROLLMENT_ACCEPTED");
  }

  private static KeyGenParameterSpec policy(String alias, int bits, boolean auth, int seconds, String mode) {
    return new KeyGenParameterSpec.Builder(alias,
        KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
        .setKeySize(bits).setBlockModes(mode)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true).setUserAuthenticationRequired(auth)
        .setUserAuthenticationValidityDurationSeconds(seconds).build();
  }

  private static void reject(VeilDeviceBinding binding, KeyGenParameterSpec policy) {
    try {
      VeilNativeEnrollment.validatePolicy(binding, policy);
    } catch (IllegalArgumentException expected) {
      return;
    }
    throw new AssertionError("QA_INVALID_KEY_POLICY_ACCEPTED");
  }
}
