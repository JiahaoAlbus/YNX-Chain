package com.ynx.social.matrix;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.Unit;

/** Actual SQLite adapter only; authorization gates below are synthetic fixtures. */
public final class VeilNativeSqlSnapshotInstalledCheck {
    private VeilNativeSqlSnapshotInstalledCheck() {}
    private static void require(boolean ok, String code) {
        if (!ok) throw new IllegalStateException("QA_SQL_" + code);
    }
    private static void refused(Runnable action, String code) {
        try { action.run(); }
        catch (IllegalArgumentException | IllegalStateException expected) { return; }
        throw new IllegalStateException("QA_SQL_" + code + "_NOT_REFUSED");
    }
    private static void refusedCode(Runnable action, String expected) {
        try { action.run(); }
        catch (IllegalArgumentException | IllegalStateException failure) {
            require(expected.equals(failure.getMessage()), "WRONG_REJECTION_STAGE");
            return;
        }
        throw new IllegalStateException("QA_SQL_REJECTION_NOT_OBSERVED");
    }
    private static VeilCheckpointSqlite.NamedValue value(String column, VeilCheckpointSqlite.Value value) {
        return new VeilCheckpointSqlite.NamedValue(column, value);
    }

    public static String runOwnedFixture(Context context) throws Exception {
        require("com.ynx.social.veilqa".equals(context.getPackageName()), "TARGET_NOT_OWNED");
        String name = "veil-sql-port-qa-" + UUID.randomUUID() + ".sqlite";
        SQLiteDatabase db = context.openOrCreateDatabase(name, Context.MODE_PRIVATE, null);
        AtomicBoolean alive = new AtomicBoolean(true);
        AtomicBoolean frozen = new AtomicBoolean(false);
        Thread owner = Thread.currentThread();
        Runnable lifetime = () -> require(alive.get() && Thread.currentThread() == owner && db.isOpen(), "SCOPE_INACTIVE");
        VeilNativeSqlSnapshot sql = new VeilNativeSqlSnapshot(db, () -> {
            lifetime.run();
            require(!frozen.get() && db.inTransaction(), "ORDINARY_SQL_INACTIVE");
            return Unit.INSTANCE;
        }, false);
        VeilNativeSqlSnapshot privateReader = new VeilNativeSqlSnapshot(db, () -> {
            lifetime.run();
            require(frozen.get() && db.inTransaction(), "PRIVATE_READ_INACTIVE");
            return Unit.INSTANCE;
        }, true);
        VeilCheckpointSqlite.Budget budget = new VeilCheckpointSqlite.Budget(4, 3, 4, 8, 32, 64);
        List<VeilCheckpointSqlite.Value> none = Collections.emptyList();
        String rows = "SELECT kind,id,sealed FROM records ORDER BY kind,id";
        int checks = 0;
        try {
            db.execSQL("CREATE TABLE records(kind TEXT NOT NULL,id TEXT NOT NULL,sealed BLOB NOT NULL,PRIMARY KEY(kind,id))");
            db.beginTransaction();
            sql.insert("records", Arrays.asList(value("kind", new VeilCheckpointSqlite.Value.Text("SESSION")),
                value("id", new VeilCheckpointSqlite.Value.Text("owned-qa")),
                value("sealed", new VeilCheckpointSqlite.Value.Blob(new byte[] {1,2,3}))));
            VeilCheckpointSqlite.Snapshot first = sql.query(rows, none, budget);
            require(first.getSize() == 1 && first.row(0).text(0,32).equals("SESSION"), "INSERT_AND_TYPED_QUERY"); checks++;
            byte[] detached = first.row(0).blob(2);
            detached[0] = 99;
            require(sql.query(rows, none, budget).row(0).blob(2)[0] == 1, "DETACHED_COPY"); checks++;
            refused(() -> sql.query(rows, none, new VeilCheckpointSqlite.Budget(4,3,2,8,32,64)), "BLOB_CELL"); checks++;
            refused(() -> sql.query(rows, none, new VeilCheckpointSqlite.Budget(4,3,4,2,32,64)), "BLOB_TOTAL"); checks++;
            refused(() -> sql.query(rows, none, new VeilCheckpointSqlite.Budget(0,3,4,8,32,64)), "ROW_LIMIT"); checks++;
            refused(() -> sql.query(rows, none, new VeilCheckpointSqlite.Budget(4,2,4,8,32,64)), "COLUMN_LIMIT"); checks++;
            refused(() -> sql.query(rows, none, new VeilCheckpointSqlite.Budget(4,3,4,8,2,64)), "TEXT_CELL"); checks++;
            StringBuilder corrupt = new StringBuilder("A\u0000");
            for (int i=0;i<100000;i++) corrupt.append('x');
            db.execSQL("UPDATE records SET kind=? WHERE id=?", new Object[] {corrupt.toString(), "owned-qa"});
            refusedCode(() -> sql.query(rows, none, budget), "VEIL_SQL_TEXT_ENCODED_CELL_BUDGET"); checks++;
            db.execSQL("UPDATE records SET kind=? WHERE id=?", new Object[] {"SESSION", "owned-qa"});
            VeilCheckpointSqlite.Value unicode = sql.query("SELECT char(233) AS n", none,
                new VeilCheckpointSqlite.Budget(1,1,0,0,1,1)).row(0).value(0);
            require(unicode instanceof VeilCheckpointSqlite.Value.Text &&
                ((VeilCheckpointSqlite.Value.Text)unicode).getText().equals("\u00e9"), "UTF16_BUDGET_PRESERVED"); checks++;
            refusedCode(() -> sql.query("SELECT char(128512) AS n", none,
                new VeilCheckpointSqlite.Budget(1,1,0,0,1,1)), "VEIL_SQL_TEXT_ENCODED_CELL_BUDGET"); checks++;
            refusedCode(() -> sql.query(rows, none, new VeilCheckpointSqlite.Budget(8192,3,4,8,32,64)),
                "VEIL_SQL_GLOBAL_QUERY_BUDGET"); checks++;
            refusedCode(() -> sql.update("records", Collections.singletonList(value("id",
                new VeilCheckpointSqlite.Value.Text(corrupt.toString()))), "id=?",
                Collections.singletonList(new VeilCheckpointSqlite.Value.Text("owned-qa"))), "VEIL_SQL_WRITE_TEXT_BUDGET"); checks++;
            refusedCode(() -> sql.insert("veil_checkpoint_chunks_v1", Arrays.asList(
                value("op", new VeilCheckpointSqlite.Value.Text("owned-qa")),
                value("part", new VeilCheckpointSqlite.Value.Integer(0)),
                value("bytes", new VeilCheckpointSqlite.Value.Blob(new byte[65537])))), "VEIL_SQL_WRITE_BLOB_BUDGET"); checks++;
            refusedCode(() -> sql.update("records", Collections.singletonList(value("unexpected",
                new VeilCheckpointSqlite.Value.Blob(new byte[] {1}))), "id=?",
                Collections.singletonList(new VeilCheckpointSqlite.Value.Text("owned-qa"))), "VEIL_SQL_WRITE_COLUMN_FORBIDDEN"); checks++;
            for (int i=0;i<4095;i++) db.execSQL("INSERT INTO records(kind,id,sealed) VALUES(?,?,?)",
                new Object[] {"FILL", "row-"+i, new byte[] {1}});
            refusedCode(() -> sql.insert("records", Arrays.asList(value("kind", new VeilCheckpointSqlite.Value.Text("SESSION")),
                value("id", new VeilCheckpointSqlite.Value.Text("over-limit")),
                value("sealed", new VeilCheckpointSqlite.Value.Blob(new byte[] {1})))), "VEIL_SQL_RECORD_REPLACEMENT_BUDGET"); checks++;
            db.execSQL("DELETE FROM records WHERE kind=?", new Object[] {"FILL"});
            require(sql.query("SELECT 9223372036854775807 AS n", none, budget).row(0).integer(0) == Long.MAX_VALUE,
                "INTEGER_PRESERVED"); checks++;
            require(sql.query("SELECT NULL AS n", none, budget).row(0).value(0) == VeilCheckpointSqlite.Value.Null.INSTANCE,
                "NULL_PRESERVED"); checks++;
            refused(() -> sql.query("SELECT 1.5 AS n", none, budget), "REAL_NOT_COERCED"); checks++;
            refused(() -> sql.query("SELECT randomblob(100000000) AS n", none, budget), "RANDOM_BLOB"); checks++;
            refused(() -> sql.executeSchema("DROP TABLE records"), "SCHEMA_ESCAPE"); checks++;
            int updated = sql.update("records", Collections.singletonList(value("sealed",
                new VeilCheckpointSqlite.Value.Blob(new byte[] {4,5,6,7}))), "kind=? AND id=?",
                Arrays.asList(new VeilCheckpointSqlite.Value.Text("SESSION"),new VeilCheckpointSqlite.Value.Text("owned-qa")));
            require(updated == 1 && sql.query(rows, none, budget).row(0).blob(2).length == 4, "COMPOSITE_UPDATE"); checks++;
            refused(() -> sql.update("records", Collections.singletonList(value("sealed",
                new VeilCheckpointSqlite.Value.Blob(new byte[] {8}))), "1=1", none), "WHERE_ESCAPE"); checks++;
            byte[] large = new byte[8 * 1024 * 1024 + 28];
            large[0] = 7;
            large[large.length - 1] = 9;
            sql.update("records", Collections.singletonList(value("sealed", new VeilCheckpointSqlite.Value.Blob(large))),
                "kind=? AND id=?", Arrays.asList(new VeilCheckpointSqlite.Value.Text("SESSION"),
                    new VeilCheckpointSqlite.Value.Text("owned-qa")));
            VeilCheckpointSqlite.Budget wide = new VeilCheckpointSqlite.Budget(1,3,large.length,large.length,32,64);
            byte[] readLarge = sql.query(rows, none, wide).row(0).blob(2);
            require(readLarge.length == large.length && readLarge[0] == 7 && readLarge[readLarge.length-1] == 9,
                "MAXIMUM_RECORD_READBACK"); checks++;
            try (android.database.Cursor nativeRecord = VeilNativeRecordCursorKt.veilNativeRecordCursor(db, rows, null)) {
                require(nativeRecord.moveToFirst() && nativeRecord.getBlob(2).length == large.length,
                    "NATIVE_RECORD_CURSOR_MAXIMUM_READBACK"); checks++;
            }
            try (android.database.Cursor nativeQuery = VeilNativeRecordCursorKt.veilNativeRecordQuery(db,
                "records", new String[] {"sealed"}, "kind=? AND id=?",
                new String[] {"SESSION", "owned-qa"}, null, null, null, null)) {
                require(nativeQuery.moveToFirst() && nativeQuery.getBlob(0).length == large.length,
                    "NATIVE_QUERY_FACTORY_MAXIMUM_READBACK"); checks++;
            }
            sql.update("records", Collections.singletonList(value("sealed", new VeilCheckpointSqlite.Value.Blob(new byte[] {4,5,6,7}))),
                "kind=? AND id=?", Arrays.asList(new VeilCheckpointSqlite.Value.Text("SESSION"),
                    new VeilCheckpointSqlite.Value.Text("owned-qa")));
            AtomicReference<Throwable> otherFailure = new AtomicReference<>();
            Thread other = new Thread(() -> {
                try { sql.query(rows, none, budget); }
                catch (Throwable failure) { otherFailure.set(failure); }
            }, "owned-sql-negative");
            other.start(); other.join(5000);
            require(!other.isAlive() && otherFailure.get() instanceof IllegalStateException, "CROSS_THREAD"); checks++;
            frozen.set(true);
            refused(() -> sql.query(rows, none, budget), "FROZEN_READ"); checks++;
            refused(() -> sql.update("records", Collections.singletonList(value("sealed",
                new VeilCheckpointSqlite.Value.Blob(new byte[] {8}))), "id=?",
                Collections.singletonList(new VeilCheckpointSqlite.Value.Text("owned-qa"))), "FROZEN_WRITE"); checks++;
            require(privateReader.query(rows, none, budget).row(0).blob(2).length == 4, "PRIVATE_FROZEN_READ"); checks++;
            refused(() -> privateReader.insert("records", Collections.singletonList(value("id",
                new VeilCheckpointSqlite.Value.Text("bad")))), "PRIVATE_WRITE"); checks++;
            db.setTransactionSuccessful();
            db.endTransaction();
            refused(() -> sql.query(rows, none, budget), "OUTSIDE_TRANSACTION"); checks++;
            alive.set(false);
            refused(() -> privateReader.query(rows, none, budget), "ESCAPED_SCOPE"); checks++;
        } finally {
            alive.set(false);
            try { if (db.inTransaction()) db.endTransaction(); }
            finally { db.close(); }
        }
        // Only our own new non-sensitive fixture database is reopened, never user records.
        SQLiteDatabase reopened = context.openOrCreateDatabase(name, Context.MODE_PRIVATE, null);
        try (android.database.Cursor cursor = reopened.rawQuery("SELECT sealed FROM records WHERE kind=? AND id=?",
            new String[] {"SESSION","owned-qa"})) {
            require(cursor.moveToFirst() && Arrays.equals(cursor.getBlob(0),new byte[] {4,5,6,7}), "DURABLE_REOPEN"); checks++;
        } finally { reopened.close(); }
        require(checks == 33, "CHECK_COUNT");
        return "PASS_33_ACTUAL_SQLITE_PORT_CHECKS; synthetic guards/data; native lease/Keystore/CAS NOT_VERIFIED";
    }
}
