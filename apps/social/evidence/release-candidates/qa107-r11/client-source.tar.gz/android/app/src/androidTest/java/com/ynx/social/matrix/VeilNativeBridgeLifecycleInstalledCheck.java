package com.ynx.social.matrix;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.Unit;

/** Installed native bridge component ONLY. Grants, binding, clock and bytes are SYNTHETIC.
 * No enrolled key, sealer, legacy transaction, CAS or production authorization is exercised.
 */
public final class VeilNativeBridgeLifecycleInstalledCheck {
    private VeilNativeBridgeLifecycleInstalledCheck() {}
    private static int checks;
    private static final int EXPECTED_CHECKS = 171;
    // Strong retention prevents finalizer cleanup of a fixture an unfinished worker may use.
    private static final java.util.List<Fixture> QUARANTINED = new ArrayList<>();
    private static final java.util.List<Thread> QUARANTINED_SUPERVISORS = new ArrayList<>();
    private static final java.util.List<Fixture> ADMITTED_UNFINISHED = new ArrayList<>();
    private static final java.util.List<String> CALLER_QUARANTINE_NAMES = new ArrayList<>();
    private static Throwable preserve(Throwable primary, Throwable cleanup) {
        if (primary == null) return cleanup;
        if (cleanup != null && cleanup != primary) primary.addSuppressed(cleanup);
        return primary;
    }
    private static void propagate(Throwable failure) {
        if (failure == null) return;
        if (failure instanceof RuntimeException) throw (RuntimeException) failure;
        if (failure instanceof Error) throw (Error) failure;
        throw new IllegalStateException("QA_NATIVE_BRIDGE_WORKER_CLEANUP_FAILURE", failure);
    }
    private static Throwable joinWorker(Thread worker, long timeoutMillis, Throwable primary,
        Runnable quarantine) {
        Throwable result = primary;
        try { worker.join(timeoutMillis); }
        catch (InterruptedException cleanup) {
            Thread.currentThread().interrupt();
            result = preserve(result, cleanup);
        }
        if (worker.isAlive()) {
            result = quarantineOutcome(result, quarantine, "QA_NATIVE_BRIDGE_WORKER");
        }
        return result;
    }
    /** Supervision without clearing ANY interrupt flag; isAlive(false) observes termination. */
    private static Throwable awaitTermination(Thread worker, Throwable primary, Runnable quarantine) {
        return awaitTermination(worker, primary, quarantine, 5000);
    }
    private static Throwable awaitTermination(Thread worker, Throwable primary, Runnable quarantine, long millis) {
        long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(millis);
        while (worker.isAlive() && System.nanoTime() < deadline) Thread.yield();
        if (worker.isAlive()) {
            return quarantineOutcome(primary, quarantine, "QA_NATIVE_BRIDGE_SUPERVISION");
        }
        return primary;
    }
    private static Throwable quarantineOutcome(Throwable primary, Runnable quarantine, String prefix) {
        boolean confirmed = false;
        try { quarantine.run(); confirmed = true; }
        catch (Throwable cleanup) { primary = preserve(primary, cleanup); }
        return preserve(primary, new IllegalStateException(prefix + (confirmed
            ? "_UNFINISHED_QUARANTINED" : "_UNFINISHED_QUARANTINE_UNCONFIRMED")));
    }
    private static void supervisedCleanupNegative(boolean interrupt) {
        AtomicReference<Throwable> failure = new AtomicReference<>();
        java.util.concurrent.atomic.AtomicBoolean flag = new java.util.concurrent.atomic.AtomicBoolean();
        Thread caller = new Thread(() -> {
            try { cleanupNegative(interrupt); }
            catch (Throwable error) { failure.set(error); }
            finally { flag.set(Thread.currentThread().isInterrupted()); }
        }, "owned-bridge-helper-negative-caller");
        caller.setDaemon(true);
        caller.start();
        propagate(awaitTermination(caller, null, () -> {
            synchronized (QUARANTINED_SUPERVISORS) { QUARANTINED_SUPERVISORS.add(caller); }
        }));
        propagate(failure.get());
        require(flag.get() == interrupt, "ISOLATED_CALLER_INTERRUPT_NOT_CLEARED");
    }
    private static void finishFailedEffectCall(Throwable primary, IllegalStateException effectFailure,
        AtomicLong effects) {
        // F1: cleanup errors remain suppressed on the SAME primary, never replaced by an assertion.
        if (primary != effectFailure || primary.getSuppressed().length != 0) {
            if (primary != null) propagate(primary);
            throw new IllegalStateException("QA_NATIVE_BRIDGE_QUEUED_EFFECT_PRIMARY_MISSING");
        }
        require(primary == effectFailure && primary.getSuppressed().length == 0, "QUEUED_EFFECT_PRIMARY_RETAINED");
        require(effects.get() == 1, "QUEUED_EFFECT_ONCE");
    }
    /** SAME actual failed-effect caller for ordinary coverage and controlled cleanup negatives. */
    private static void failedEffectCaller(Fixture f, Thread revoker, IllegalStateException effectFailure,
        AtomicLong effects, boolean interruptJoin, long joinMillis) {
        Throwable primary = null;
        try {
            f.bridge.withScope(f.binding, scope -> {
                VeilCheckpointSqlite.ProducerLifecycle life = scope.lifecycle();
                life.begin(); insert(scope.checkedSql(), "serialized-revoke");
                revoker.start();
                awaitRealRevokeQueue(revoker);
                scope.authorizationOnly().checkLive();
                scope.freezeSqlAndBusinessHandles();
                scope.commitOnce(() -> { effects.incrementAndGet(); throw effectFailure; });
                throw new IllegalStateException("QA_NATIVE_BRIDGE_EFFECT_FAILURE_MISSING");
            });
        } catch (Throwable failure) {
            primary = failure;
        } finally {
            if (interruptJoin && primary == effectFailure) Thread.currentThread().interrupt();
            primary = joinWorker(revoker, joinMillis, primary, f::quarantine);
        }
        finishFailedEffectCall(primary, effectFailure, effects);
    }
    private static void callerFixtureNegative(Context context, boolean interrupt) throws Exception {
        Fixture f = new Fixture(context);
        CountDownLatch release = new CountDownLatch(1);
        AtomicReference<Throwable> workerFailure = new AtomicReference<>();
        Thread revoker = new Thread(() -> {
            try {
                f.authority.revoke();
                release.await(); // Controlled unfinished worker AFTER real native revoke.
            } catch (Throwable error) {
                workerFailure.set(error);
                if (error instanceof InterruptedException) Thread.currentThread().interrupt();
            }
        }, "owned-bridge-native-caller-negative-revoke");
        revoker.setDaemon(true);
        f.track(revoker);
        IllegalStateException sentinel = new IllegalStateException("QA_NATIVE_BRIDGE_CALLER_EFFECT_PRIMARY");
        AtomicLong effects = new AtomicLong();
        AtomicReference<Throwable> escaped = new AtomicReference<>();
        java.util.concurrent.atomic.AtomicBoolean flag = new java.util.concurrent.atomic.AtomicBoolean();
        Thread caller = new Thread(() -> {
            try (Fixture ignored = f) {
                failedEffectCaller(f, revoker, sentinel, effects, interrupt, interrupt ? 5000 : 1);
                throw new IllegalStateException("QA_NATIVE_BRIDGE_CALLER_ESCAPE_MISSING");
            } catch (Throwable error) { escaped.set(error); }
            finally { flag.set(Thread.currentThread().isInterrupted()); }
        }, "owned-bridge-native-caller-negative");
        caller.setDaemon(true);
        Throwable primary = null;
        try {
            caller.start();
            propagate(awaitTermination(caller, null, f::quarantine));
            require(escaped.get() == sentinel, "CALLER_EXACT_ESCAPING_SENTINEL");
            require(effects.get() == 1, "CALLER_ACTUAL_EFFECT_ONCE");
            Throwable[] suppressed = sentinel.getSuppressed();
            int at = interrupt ? 1 : 0;
            require(suppressed.length == (interrupt ? 3 : 2)
                && (!interrupt || suppressed[0] instanceof InterruptedException)
                && "QA_NATIVE_BRIDGE_WORKER_UNFINISHED_QUARANTINED".equals(suppressed[at].getMessage())
                && "QA_NATIVE_BRIDGE_FIXTURE_QUARANTINED_NO_CLOSE_OR_DELETE".equals(suppressed[at + 1].getMessage())
                && suppressed[at] != suppressed[at + 1], "CALLER_EXACT_CLEANUP_SUPPRESSION_CHAIN");
            require(flag.get() == interrupt, "CALLER_INTERRUPT_NOT_CLEARED");
            synchronized (QUARANTINED) {
                require(f.quarantined && QUARANTINED.contains(f), "ACTUAL_FIXTURE_STRONGLY_QUARANTINED");
            }
            require(f.storeCloseCalls == 0 && f.databaseDeleteCalls == 0 && f.database.exists(),
                "ACTUAL_FIXTURE_NO_CLOSE_DELETE_BEFORE_RELEASE");
            refused(f::close, "QA_NATIVE_BRIDGE_FIXTURE_QUARANTINED_NO_CLOSE_OR_DELETE");
            require(f.storeCloseCalls == 0 && f.databaseDeleteCalls == 0 && revoker.isAlive(),
                "ACTUAL_LIVE_WORKER_CLOSE_DELETE_REFUSED");
        } catch (Throwable failure) { primary = failure; }
        finally {
            release.countDown();
            primary = awaitTermination(caller, primary, f::quarantine);
            primary = awaitTermination(revoker, primary, f::quarantine);
        }
        propagate(primary);
        require(!caller.isAlive() && !revoker.isAlive() && workerFailure.get() == null,
            "CALLER_AND_NATIVE_WORKER_TERMINATED");
        require(f.quarantined && f.storeCloseCalls == 0 && f.databaseDeleteCalls == 0,
            "ACTUAL_QUARANTINE_RETAINED_AFTER_TERMINATION");
        refused(f::close, "QA_NATIVE_BRIDGE_FIXTURE_QUARANTINED_NO_CLOSE_OR_DELETE");
        require(f.storeCloseCalls == 0 && f.databaseDeleteCalls == 0 && f.database.exists(),
            "ACTUAL_TERMINATED_FIXTURE_NO_CLOSE_DELETE");
        f.absentAfterRollback("serialized-revoke");
        refused(() -> f.bridge.withScope(f.binding, scope -> Unit.INSTANCE), "VEIL_LEASE_REVOKED_OR_FOREIGN");
        require(f.protectorCalls.get() == 0, "CALLER_NO_PROTECTOR_CALLS");
        CALLER_QUARANTINE_NAMES.add(f.database.getName()); // Bounded public synthetic fixture names only.
        // Intentionally retained two uniquely owned DBs; no automatic de-quarantine/reap/delete.
    }
    private static boolean atRevokeQueue(Thread worker) {
        if (worker.getState() != Thread.State.WAITING) return false;
        boolean authority = false, lock = false, queue = false;
        for (StackTraceElement frame : worker.getStackTrace()) {
            String type = frame.getClassName();
            authority |= type.equals("com.ynx.social.matrix.VeilNativeAuthority") && frame.getMethodName().equals("revoke");
            lock |= type.startsWith("java.util.concurrent.locks.ReentrantLock");
            queue |= type.startsWith("java.util.concurrent.locks.AbstractQueuedSynchronizer");
        }
        return authority && lock && queue && worker.getState() == Thread.State.WAITING;
    }
    private static void awaitRealRevokeQueue(Thread worker) {
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
        while (System.nanoTime() < deadline) {
            if (atRevokeQueue(worker)) { require(true, "REAL_REVOKE_QUEUE_OBSERVED"); return; }
            if (!worker.isAlive()) break;
            if (Thread.currentThread().isInterrupted())
                throw new IllegalStateException("QA_NATIVE_BRIDGE_QUEUE_OBSERVER_INTERRUPTED");
            Thread.yield();
        }
        throw new IllegalStateException("QA_NATIVE_BRIDGE_REAL_REVOKE_QUEUE_NOT_OBSERVED");
    }
    /** No DB/native capability: isolated interrupted-join and timeout cleanup negatives. */
    private static void cleanupNegative(boolean interrupt) {
        if (Thread.currentThread().isInterrupted())
            throw new IllegalStateException("QA_NATIVE_BRIDGE_UNEXPECTED_INCOMING_INTERRUPT");
        CountDownLatch release = new CountDownLatch(1);
        final class Resource {
            boolean quarantined;
            int closes, deletes;
            void close() {
                if (quarantined) throw new IllegalStateException("QA_NATIVE_BRIDGE_ISOLATED_RESOURCE_QUARANTINED");
                closes++; deletes++;
            }
        }
        Resource resource = new Resource();
        Thread worker = new Thread(() -> {
            try { release.await(); }
            catch (InterruptedException failure) { Thread.currentThread().interrupt(); }
        }, "owned-bridge-isolated-cleanup");
        worker.setDaemon(true);
        worker.start();
        Throwable primary = null;
        try {
            long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
            boolean latchWait = false;
            while (System.nanoTime() < deadline) {
                if (worker.getState() == Thread.State.WAITING) {
                    for (StackTraceElement frame : worker.getStackTrace())
                        latchWait |= frame.getClassName().equals("java.util.concurrent.CountDownLatch")
                            && frame.getMethodName().equals("await");
                    if (latchWait) break;
                }
                Thread.yield();
            }
            require(latchWait, "ISOLATED_LATCH_WAIT_OBSERVED");
            require(!atRevokeQueue(worker), "LATCH_WAIT_IS_NOT_AUTHORITY_QUEUE");
            IllegalStateException sentinel = new IllegalStateException("QA_NATIVE_BRIDGE_ISOLATED_PRIMARY");
            if (interrupt) Thread.currentThread().interrupt();
            Throwable result = joinWorker(worker, interrupt ? 5000 : 1, sentinel, () -> resource.quarantined = true);
            require(result == sentinel, "JOIN_PRIMARY_IDENTITY");
            Throwable[] suppressed = result.getSuppressed();
            require(interrupt ? suppressed.length == 2 && suppressed[0] instanceof InterruptedException
                && "QA_NATIVE_BRIDGE_WORKER_UNFINISHED_QUARANTINED".equals(suppressed[1].getMessage())
                : suppressed.length == 1 && "QA_NATIVE_BRIDGE_WORKER_UNFINISHED_QUARANTINED".equals(suppressed[0].getMessage()),
                "JOIN_DISTINCT_CLEANUP_SUPPRESSED");
            require(Thread.currentThread().isInterrupted() == interrupt, "JOIN_INTERRUPT_FLAG_PRESERVED");
            require(resource.quarantined, "UNFINISHED_RESOURCE_QUARANTINE");
            refused(resource::close, "QA_NATIVE_BRIDGE_ISOLATED_RESOURCE_QUARANTINED");
            require(resource.closes == 0 && resource.deletes == 0, "NO_UNFINISHED_RESOURCE_CLEANUP");
        } catch (Throwable failure) {
            primary = failure;
        } finally {
            release.countDown();
            primary = awaitTermination(worker, primary, () -> resource.quarantined = true);
        }
        propagate(primary);
        require(!worker.isAlive(), "ISOLATED_WORKER_TERMINATED");
        require(resource.quarantined && resource.closes == 0 && resource.deletes == 0,
            "ISOLATED_QUARANTINE_RETAINED");
    }
    private static void require(boolean value, String code) {
        if (!value) throw new IllegalStateException("QA_NATIVE_BRIDGE_" + code);
        checks++;
    }
    private static void refused(Runnable action, String code) {
        try { action.run(); }
        catch (IllegalStateException expected) {
            require(code.equals(expected.getMessage()), "WRONG_REFUSAL");
            return;
        }
        throw new IllegalStateException("QA_NATIVE_BRIDGE_REFUSAL_MISSING");
    }
    private static final VeilCheckpointSqlite.Budget BUDGET =
        new VeilCheckpointSqlite.Budget(1, 1, 29, 29, 0, 0);
    private static final String QUERY = "SELECT sealed FROM records WHERE kind=? AND id=?";
    private static java.util.List<VeilCheckpointSqlite.Value> args(String id) {
        return Arrays.asList(new VeilCheckpointSqlite.Value.Text("SESSION"),
            new VeilCheckpointSqlite.Value.Text(id));
    }
    private static void insert(VeilCheckpointSqlite.SqlPort sql, String id) {
        byte[] bytes = new byte[29]; // Synthetic storage-shaped bytes, NOT valid encrypted secrets.
        bytes[0] = 17;
        require(sql.insert("records", Arrays.asList(
            new VeilCheckpointSqlite.NamedValue("kind", new VeilCheckpointSqlite.Value.Text("SESSION")),
            new VeilCheckpointSqlite.NamedValue("id", new VeilCheckpointSqlite.Value.Text(id)),
            new VeilCheckpointSqlite.NamedValue("sealed", new VeilCheckpointSqlite.Value.Blob(bytes)))) != -1,
            "SQL_INSERT");
    }

    private static final class Fixture implements AutoCloseable {
        final AtomicLong clock = new AtomicLong(1000);
        final AtomicLong protectorCalls = new AtomicLong();
        final VeilDeviceBinding nativeBinding;
        final VeilCheckpointCommit.Binding binding;
        final VeilNativeAuthority authority;
        final VeilNativeStore store;
        final VeilCheckpointSqlite.NativeStoreBridge bridge;
        final File database;
        final java.util.List<Thread> workers = new ArrayList<>();
        final Object lifecycleLock = new Object();
        boolean quarantined;
        boolean cleanupAdmitted;
        CountDownLatch beforeCleanup, allowCleanup;
        CountDownLatch afterAdmission, allowClose;
        void cleanupBarrier() {
            if (beforeCleanup == null) return;
            beforeCleanup.countDown();
            try {
                if (!allowCleanup.await(5, TimeUnit.SECONDS))
                    throw new IllegalStateException("QA_NATIVE_BRIDGE_ADMISSION_BARRIER_TIMEOUT");
            } catch (InterruptedException failure) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("QA_NATIVE_BRIDGE_ADMISSION_BARRIER_INTERRUPTED", failure);
            }
        }
        int storeCloseCalls, databaseDeleteCalls;
        void track(Thread worker) { synchronized (lifecycleLock) { workers.add(worker); } }
        void quarantine() {
            synchronized (lifecycleLock) {
                if (cleanupAdmitted) throw new IllegalStateException("QA_NATIVE_BRIDGE_CLEANUP_ALREADY_ADMITTED");
                quarantined = true;
                synchronized (QUARANTINED) { if (!QUARANTINED.contains(this)) QUARANTINED.add(this); }
            }
        }
        Fixture(Context context) throws Exception {
            String uuid = UUID.randomUUID().toString();
            nativeBinding = new VeilDeviceBinding("synthetic-bridge-" + uuid, "synthetic-device-" + uuid,
                "synthetic-fingerprint-" + uuid, "ynx.social.veil.v2.synthetic-bridge-" + uuid);
            binding = new VeilCheckpointCommit.Binding(nativeBinding.getOwner(), nativeBinding.getDevice(),
                nativeBinding.getSocialIdentityFingerprint(), nativeBinding.getKeyAlias());
            VeilDeviceGrantVerifier syntheticVerifier = (proof, expected, minimum) -> {
                if (!nativeBinding.equals(expected) || !Arrays.equals(proof, new byte[] {1}) || minimum > 7)
                    throw new IllegalStateException("QA_NATIVE_BRIDGE_SYNTHETIC_GRANT_REJECTED");
                return new VeilVerifiedDeviceGrant(expected, 7, 61000, VeilDeviceApproval.TRUSTED_DEVICE);
            };
            authority = new VeilNativeAuthority(nativeBinding, syntheticVerifier, () -> clock.get());
            VeilNativeLease lease = authority.admit(new byte[] {1});
            VeilCheckpointProtector throwOnly = new VeilCheckpointProtector() {
                @Override public VeilStorageCheckpoint load(VeilDeviceBinding ignored) {
                    protectorCalls.incrementAndGet();
                    throw new IllegalStateException("QA_NATIVE_BRIDGE_PROTECTOR_FORBIDDEN");
                }
                @Override public void advance(VeilDeviceBinding ignored, VeilStorageCheckpoint base,
                    VeilStorageCheckpoint next) {
                    protectorCalls.incrementAndGet();
                    throw new IllegalStateException("QA_NATIVE_BRIDGE_PROTECTOR_FORBIDDEN");
                }
            };
            // Derive ONLY this unique synthetic binding's noBackup DB path for bounded cleanup.
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (DataOutputStream out = new DataOutputStream(bytes)) {
                for (String value : Arrays.asList("ynx-social-veil-native-store-v2", nativeBinding.getOwner(),
                    nativeBinding.getDevice(), nativeBinding.getSocialIdentityFingerprint(),
                    nativeBinding.getKeyAlias(), "SESSION", "checkpoint-domain")) {
                    byte[] encoded = value.getBytes(StandardCharsets.UTF_8);
                    out.writeInt(encoded.length); out.write(encoded);
                }
            }
            StringBuilder name = new StringBuilder();
            for (byte b : MessageDigest.getInstance("SHA-256").digest(bytes.toByteArray()))
                name.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
            database = new File(new File(context.getNoBackupFilesDir(), "veil-v2"), name + ".sqlite");
            require(!database.exists() && !new File(database + "-wal").exists()
                && !new File(database + "-shm").exists() && !new File(database + "-journal").exists(),
                "UUID_DATABASE_COLLISION");
            store = new VeilNativeStore(context, authority, lease, throwOnly);
            bridge = store.checkpointBridge$ynx_social_native_matrix_debug();
        }
        void absentAfterRollback(String id) {
            // Independent actual disk read of this owned synthetic DB, not authority or an anchor.
            try (SQLiteDatabase db = SQLiteDatabase.openDatabase(database.getAbsolutePath(), null,
                     SQLiteDatabase.OPEN_READONLY);
                 Cursor rows = db.rawQuery("SELECT COUNT(*) FROM records WHERE kind=? AND id=?",
                     new String[] {"SESSION", id})) {
                require(rows.moveToFirst() && rows.getLong(0) == 0, "ROLLBACK_DISK_READBACK");
            }
        }
        @Override public void close() {
            cleanupBarrier();
            synchronized (lifecycleLock) {
            for (Thread worker : workers) if (worker.isAlive()) quarantine();
            if (quarantined) throw new IllegalStateException("QA_NATIVE_BRIDGE_FIXTURE_QUARANTINED_NO_CLOSE_OR_DELETE");
            if (cleanupAdmitted) throw new IllegalStateException("QA_NATIVE_BRIDGE_CLEANUP_ALREADY_ADMITTED");
            cleanupAdmitted = true;
            if (afterAdmission != null) {
                afterAdmission.countDown();
                try {
                    if (!allowClose.await(5, TimeUnit.SECONDS))
                        throw new IllegalStateException("QA_NATIVE_BRIDGE_SLOW_CLOSE_BARRIER_TIMEOUT");
                } catch (InterruptedException failure) {
                    Thread.currentThread().interrupt();
                    throw new IllegalStateException("QA_NATIVE_BRIDGE_SLOW_CLOSE_BARRIER_INTERRUPTED", failure);
                }
            }
            storeCloseCalls++;
            store.close();
            require(protectorCalls.get() == 0, "NO_PROTECTOR_CALLS");
            if (database.exists()) {
                databaseDeleteCalls++;
                require(SQLiteDatabase.deleteDatabase(database), "OWNED_DB_CLEANUP");
            }
            }
        }
    }

    /** Actual caller is NOT tracked as its own worker. Supervisor wins cleanup admission
     * before resume, even though the actual authority revoker has already terminated.
     * The second schedule observes a close contender BLOCKED on the SAME lifecycle lock.
     */
    private static void supervisionAdmissionNegative(Context context, boolean contend) throws Exception {
        Fixture f = new Fixture(context);
        f.beforeCleanup = new CountDownLatch(1); f.allowCleanup = new CountDownLatch(1);
        AtomicReference<Throwable> escaped = new AtomicReference<>();
        AtomicReference<Throwable> revokeFailure = new AtomicReference<>();
        IllegalStateException sentinel = new IllegalStateException("QA_NATIVE_BRIDGE_SUPERVISION_EFFECT_PRIMARY");
        AtomicLong effects = new AtomicLong();
        Thread revoker = new Thread(() -> {
            try { f.authority.revoke(); } catch (Throwable failure) { revokeFailure.set(failure); }
        }, "owned-lifecycle-real-revoker");
        f.track(revoker);
        Thread caller = new Thread(() -> {
            try (Fixture ignored = f) {
                failedEffectCaller(f, revoker, sentinel, effects, false, 5000);
                // Same native effect sentinel; helper verified its identity and ordinary join.
                throw sentinel;
            } catch (Throwable failure) { escaped.set(failure); }
        }, "owned-lifecycle-paused-cleanup-caller");
        caller.setDaemon(true); revoker.setDaemon(true);
        Throwable primary = null;
        try {
            caller.start();
            require(f.beforeCleanup.await(5, TimeUnit.SECONDS), "ACTUAL_CALLER_BEFORE_CLOSE");
            require(!revoker.isAlive() && revokeFailure.get() == null, "REVOKER_ENDED_BEFORE_SUPERVISION");
            // A bounded actual supervision timeout, NOT a pre-call latch treated as revoke proof.
            long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(25);
            while (caller.isAlive() && System.nanoTime() < deadline) Thread.yield();
            require(caller.isAlive(), "SUPERVISOR_TIMEOUT_OBSERVED");
            synchronized (f.lifecycleLock) {
                if (contend) {
                    f.allowCleanup.countDown();
                    deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
                    boolean blockedClose = false;
                    while (System.nanoTime() < deadline) {
                        if (caller.getState() == Thread.State.BLOCKED) {
                            for (StackTraceElement frame : caller.getStackTrace())
                                blockedClose |= frame.getClassName().endsWith("VeilNativeBridgeLifecycleInstalledCheck$Fixture")
                                    && frame.getMethodName().equals("close");
                            if (blockedClose) break;
                        }
                        Thread.yield();
                    }
                    if (!blockedClose) throw new IllegalStateException("QA_NATIVE_BRIDGE_CLOSE_LOCK_CONTENDER_NOT_OBSERVED");
                }
                f.quarantine(); // Same lock as close admission; irreversible before caller resumes.
            }
            f.allowCleanup.countDown();
            propagate(awaitTermination(caller, null, f::quarantine));
            require(!caller.isAlive() && escaped.get() == sentinel, "SUPERVISION_SAME_ESCAPING_PRIMARY");
            require(sentinel.getSuppressed().length == 1 &&
                "QA_NATIVE_BRIDGE_FIXTURE_QUARANTINED_NO_CLOSE_OR_DELETE".equals(sentinel.getSuppressed()[0].getMessage()),
                "SUPERVISION_EXACT_CLOSE_SUPPRESSION");
            synchronized (f.lifecycleLock) {
                require(f.quarantined && !f.cleanupAdmitted && f.storeCloseCalls == 0 && f.databaseDeleteCalls == 0
                    && f.database.exists(), "SHARED_LOCK_NO_CLEANUP_ADMISSION");
            }
            require(effects.get() == 1 && f.protectorCalls.get() == 0 && !caller.isInterrupted(), "SUPERVISION_EFFECT_ONCE_FLAGS_NO_PROTECTOR");
            refused(f::close, "QA_NATIVE_BRIDGE_FIXTURE_QUARANTINED_NO_CLOSE_OR_DELETE");
            CALLER_QUARANTINE_NAMES.add(f.database.getName());
        } catch (Throwable failure) { primary = failure; }
        finally {
            if (caller.isAlive()) {
                try { f.quarantine(); } catch (Throwable cleanup) { primary = preserve(primary, cleanup); }
            }
            f.allowCleanup.countDown();
            primary = awaitTermination(caller, primary, f::quarantine);
        }
        propagate(primary);
    }

    private static void retainSupervisor(Thread thread) {
        synchronized (QUARANTINED_SUPERVISORS) { QUARANTINED_SUPERVISORS.add(thread); }
    }
    /** Both helpers see an INCOMING interrupted child and a distinct throwing callback.
     * No fixture is claimed quarantined when the callback never succeeds. */
    private static void throwingQuarantineNegative(boolean join) throws Exception {
        CountDownLatch started = new CountDownLatch(1), release = new CountDownLatch(1);
        Thread worker = new Thread(() -> {
            started.countDown();
            try { release.await(); } catch (InterruptedException failure) { Thread.currentThread().interrupt(); }
        }, "owned-lifecycle-throwing-quarantine-worker");
        worker.setDaemon(true); worker.start();
        IllegalStateException sentinel = new IllegalStateException("QA_NATIVE_BRIDGE_THROWING_QUARANTINE_PRIMARY");
        IllegalStateException cleanup = new IllegalStateException("QA_NATIVE_BRIDGE_THROWING_QUARANTINE_CALLBACK");
        AtomicReference<Throwable> result = new AtomicReference<>();
        java.util.concurrent.atomic.AtomicBoolean flag = new java.util.concurrent.atomic.AtomicBoolean();
        AtomicLong attempts = new AtomicLong();
        Thread caller = new Thread(() -> {
            Thread.currentThread().interrupt(); // Incoming to helper, NOT cleared by test.
            try {
                Runnable throwsCleanup = () -> { attempts.incrementAndGet(); throw cleanup; };
                result.set(join ? joinWorker(worker, 25, sentinel, throwsCleanup)
                    : awaitTermination(worker, sentinel, throwsCleanup, 25));
            } catch (Throwable failure) { result.set(failure); }
            finally { flag.set(Thread.currentThread().isInterrupted()); }
        }, "owned-lifecycle-throwing-quarantine-caller");
        caller.setDaemon(true);
        Throwable primary = null;
        try {
            require(started.await(5, TimeUnit.SECONDS), "THROWING_CALLBACK_WORKER_STARTED");
            caller.start();
            propagate(awaitTermination(caller, null, () -> retainSupervisor(caller)));
            require(result.get() == sentinel, "THROWING_CALLBACK_SAME_PRIMARY");
            Throwable[] chain = sentinel.getSuppressed(); int at = join ? 1 : 0;
            require(chain.length == (join ? 3 : 2) && (!join || chain[0] instanceof InterruptedException)
                && chain[at] == cleanup && cleanup != sentinel
                && ((join ? "QA_NATIVE_BRIDGE_WORKER" : "QA_NATIVE_BRIDGE_SUPERVISION")
                    + "_UNFINISHED_QUARANTINE_UNCONFIRMED").equals(chain[at + 1].getMessage()),
                "THROWING_CALLBACK_EXACT_UNCONFIRMED_CHAIN");
            require(flag.get(), "THROWING_CALLBACK_INCOMING_INTERRUPT_PRESERVED");
            require(attempts.get() == 1 && worker.isAlive(), "THROWING_CALLBACK_ONCE_NOT_QUARANTINED");
        } catch (Throwable failure) { primary = failure; }
        finally {
            release.countDown();
            primary = awaitTermination(worker, primary, () -> retainSupervisor(worker));
            if (caller.isAlive()) primary = awaitTermination(caller, primary, () -> retainSupervisor(caller));
        }
        propagate(primary);
        require(!worker.isAlive(), "THROWING_CALLBACK_WORKER_TERMINATED");
    }
    private static void closeFirstNegative(Context context) throws Exception {
        Fixture f = new Fixture(context);
        f.afterAdmission = new CountDownLatch(1); f.allowClose = new CountDownLatch(1);
        IllegalStateException sentinel = new IllegalStateException("QA_NATIVE_BRIDGE_CLOSE_FIRST_EFFECT_PRIMARY");
        AtomicLong effects = new AtomicLong();
        AtomicReference<Throwable> escaped = new AtomicReference<>(), supervised = new AtomicReference<>(), revokeFailure = new AtomicReference<>();
        java.util.concurrent.atomic.AtomicBoolean callerFlag = new java.util.concurrent.atomic.AtomicBoolean(), supervisorFlag = new java.util.concurrent.atomic.AtomicBoolean();
        Thread revoker = new Thread(() -> {
            try { f.authority.revoke(); } catch (Throwable failure) { revokeFailure.set(failure); }
        }, "owned-lifecycle-close-first-revoker");
        revoker.setDaemon(true); f.track(revoker);
        Thread caller = new Thread(() -> {
            try (Fixture ignored = f) {
                failedEffectCaller(f, revoker, sentinel, effects, false, 5000);
                throw sentinel;
            } catch (Throwable failure) { escaped.set(failure); }
            finally { callerFlag.set(Thread.currentThread().isInterrupted()); }
        }, "owned-lifecycle-close-first-caller");
        caller.setDaemon(true);
        Thread supervisor = new Thread(() -> {
            Thread.currentThread().interrupt();
            try { supervised.set(awaitTermination(caller, sentinel, f::quarantine, 25)); }
            catch (Throwable failure) { supervised.set(failure); }
            finally { supervisorFlag.set(Thread.currentThread().isInterrupted()); }
        }, "owned-lifecycle-close-first-supervisor");
        supervisor.setDaemon(true);
        Throwable primary = null;
        try {
            caller.start();
            require(f.afterAdmission.await(5, TimeUnit.SECONDS), "CLOSE_FIRST_CLEANUP_ADMITTED");
            require(!revoker.isAlive() && revokeFailure.get() == null, "CLOSE_FIRST_REVOKER_TERMINATED");
            supervisor.start();
            long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5); boolean blocked = false;
            while (System.nanoTime() < deadline) {
                if (supervisor.getState() == Thread.State.BLOCKED) {
                    for (StackTraceElement frame : supervisor.getStackTrace())
                        blocked |= frame.getClassName().endsWith("VeilNativeBridgeLifecycleInstalledCheck$Fixture")
                            && frame.getMethodName().equals("quarantine");
                    if (blocked) break;
                }
                Thread.yield();
            }
            require(blocked, "CLOSE_FIRST_SUPERVISOR_BLOCKED_ON_SAME_LOCK");
            f.allowClose.countDown();
            propagate(awaitTermination(caller, null, () -> retainSupervisor(caller)));
            propagate(awaitTermination(supervisor, null, () -> retainSupervisor(supervisor)));
            require(supervised.get() == sentinel, "CLOSE_FIRST_SUPERVISOR_SAME_PRIMARY");
            Throwable[] chain = sentinel.getSuppressed();
            require(chain.length == 2 && "QA_NATIVE_BRIDGE_CLEANUP_ALREADY_ADMITTED".equals(chain[0].getMessage())
                && "QA_NATIVE_BRIDGE_SUPERVISION_UNFINISHED_QUARANTINE_UNCONFIRMED".equals(chain[1].getMessage()),
                "CLOSE_FIRST_ALREADY_ADMITTED_CHAIN");
            require(escaped.get() == sentinel, "CLOSE_FIRST_CALLER_SAME_PRIMARY");
            require(!caller.isAlive() && !supervisor.isAlive(), "CLOSE_FIRST_THREADS_TERMINATED");
            synchronized (f.lifecycleLock) {
                require(f.storeCloseCalls == 1 && f.databaseDeleteCalls == 1 && !f.database.exists(), "CLOSE_FIRST_ACTUAL_CLEANUP_ONCE");
                synchronized (QUARANTINED) {
                    require(f.cleanupAdmitted && !f.quarantined && !QUARANTINED.contains(f), "CLOSE_FIRST_NOT_QUARANTINE_FIRST");
                }
            }
            require(effects.get() == 1 && f.protectorCalls.get() == 0 && !callerFlag.get(), "CLOSE_FIRST_EFFECT_FLAGS_NO_PROTECTOR");
            require(supervisorFlag.get(), "CLOSE_FIRST_SUPERVISOR_INTERRUPT_PRESERVED");
        } catch (Throwable failure) { primary = failure; }
        finally {
            f.allowClose.countDown();
            primary = awaitTermination(caller, primary, () -> retainSupervisor(caller));
            primary = awaitTermination(supervisor, primary, () -> retainSupervisor(supervisor));
            if (caller.isAlive() || supervisor.isAlive()) synchronized (ADMITTED_UNFINISHED) { ADMITTED_UNFINISHED.add(f); }
        }
        propagate(primary);
    }

    public static synchronized String runOwnedFixture(Context context) throws Exception {
        if (Thread.currentThread().isInterrupted())
            throw new IllegalStateException("QA_NATIVE_BRIDGE_EXTERNAL_SUPERVISOR_INTERRUPT");
        checks = 0;
        CALLER_QUARANTINE_NAMES.clear(); // Receipt metadata only; NEVER clear actual fixture quarantine.
        require("com.ynx.social.veilqa".equals(context.getPackageName()), "TARGET_NOT_OWNED");
        throwingQuarantineNegative(true);
        throwingQuarantineNegative(false);
        closeFirstNegative(context);
        supervisionAdmissionNegative(context, false);
        supervisionAdmissionNegative(context, true);
        supervisedCleanupNegative(true);
        supervisedCleanupNegative(false);
        callerFixtureNegative(context, true);
        callerFixtureNegative(context, false);
        AtomicReference<VeilCheckpointSqlite.SqlPort> escaped = new AtomicReference<>();
        AtomicReference<VeilCheckpointSqlite.AuthorizationOnly> escapedAuth = new AtomicReference<>();
        AtomicReference<VeilCheckpointSqlite.ProducerLifecycle> escapedLife = new AtomicReference<>();
        try (Fixture f = new Fixture(context)) {
            f.bridge.requireOutsideTransaction();
            f.bridge.withScope(f.binding, scope -> {
                VeilCheckpointSqlite.SqlPort sql = scope.checkedSql();
                VeilCheckpointSqlite.ProducerLifecycle life = scope.lifecycle();
                escaped.set(sql); escapedAuth.set(scope.authorizationOnly()); escapedLife.set(life);
                refused(() -> sql.query(QUERY, args("rollback"), BUDGET), "VEIL_CHECKPOINT_NATIVE_SQL_INACTIVE");
                refused(() -> insert(sql, "prebegin"), "VEIL_CHECKPOINT_NATIVE_SQL_INACTIVE");
                life.begin();
                refused(f.bridge::requireOutsideTransaction, "VEIL_NATIVE_EXTERNAL_OPERATION_INSIDE_SCOPE");
                insert(sql, "rollback");
                require(sql.query(QUERY, args("rollback"), BUDGET).row(0).blob(0)[0] == 17,
                    "ACTUAL_SQL_READBACK");
                AtomicReference<Throwable> wrong = new AtomicReference<>();
                Thread thread = new Thread(() -> {
                    try { sql.query(QUERY, args("rollback"), BUDGET); }
                    catch (Throwable error) { wrong.set(error); }
                }, "owned-native-bridge-wrong-thread");
                f.track(thread);
                thread.start();
                propagate(joinWorker(thread, 5000, null, f::quarantine));
                require(!thread.isAlive() && wrong.get() instanceof IllegalStateException
                    && "VEIL_CHECKPOINT_NATIVE_SCOPE_CLOSED".equals(wrong.get().getMessage()), "WRONG_THREAD");
                refused(f.authority::revoke, "VEIL_REENTRANT_REVOCATION_REJECTED");
                scope.freezeSqlAndBusinessHandles();
                scope.authorizationOnly().checkLive();
                refused(() -> sql.query(QUERY, args("rollback"), BUDGET), "VEIL_CHECKPOINT_NATIVE_SQL_INACTIVE");
                refused(() -> insert(sql, "frozen"), "VEIL_CHECKPOINT_NATIVE_SQL_INACTIVE");
                refused(scope::checkedSql, "VEIL_CHECKPOINT_NATIVE_SQL_INACTIVE");
                refused(() -> sql.update("records", Collections.singletonList(
                    new VeilCheckpointSqlite.NamedValue("sealed", new VeilCheckpointSqlite.Value.Blob(new byte[29]))),
                    "kind=? AND id=?", args("rollback")), "VEIL_CHECKPOINT_NATIVE_SQL_INACTIVE");
                refused(() -> sql.executeSchema("CREATE TABLE veil_checkpoint_committed_ops_v1 (op TEXT PRIMARY KEY, commitment_hash TEXT NOT NULL)"),
                    "VEIL_CHECKPOINT_NATIVE_SQL_INACTIVE");
                refused(() -> life.verifyFrozenState(f.binding,
                    new VeilCheckpointCommit.Checkpoint(1, String.join("", Collections.nCopies(64,"0"))),
                    String.join("", Collections.nCopies(64,"0"))),
                    "VEIL_CHECKPOINT_NATIVE_BUSINESS_CHANGED_AFTER_FREEZE");
                life.rollbackAndEnd();
                require(!life.inTransaction(), "FROZEN_ROLLBACK_END");
                return Unit.INSTANCE;
            });
            refused(() -> escaped.get().query(QUERY, args("rollback"), BUDGET), "VEIL_CHECKPOINT_NATIVE_SCOPE_CLOSED");
            refused(() -> escapedAuth.get().checkLive(), "VEIL_CHECKPOINT_NATIVE_SCOPE_CLOSED");
            refused(() -> escapedLife.get().rollbackAndEnd(), "VEIL_CHECKPOINT_NATIVE_SCOPE_CLOSED");
            f.absentAfterRollback("rollback");
            f.absentAfterRollback("prebegin");
            f.bridge.requireOutsideTransaction();
            IllegalStateException primary = new IllegalStateException("QA_NATIVE_BRIDGE_PRIMARY_EFFECT_FAILURE");
            AtomicLong effects = new AtomicLong();
            try {
                f.bridge.withScope(f.binding, scope -> {
                    VeilCheckpointSqlite.ProducerLifecycle life = scope.lifecycle();
                    life.begin(); insert(scope.checkedSql(), "failed-effect");
                    scope.freezeSqlAndBusinessHandles();
                    try {
                        scope.commitOnce(() -> { effects.incrementAndGet(); throw primary; });
                        throw new IllegalStateException("QA_NATIVE_BRIDGE_EFFECT_FAILURE_MISSING");
                    } catch (IllegalStateException failure) { require(failure == primary, "PRIMARY_EFFECT_IDENTITY"); }
                    // Lease denies the retry before reaching the bridge-local attempt check.
                    refused(() -> scope.commitOnce(() -> { effects.incrementAndGet(); return Unit.INSTANCE; }),
                        "VEIL_LEASE_SCOPE_INACTIVE");
                    life.rollbackAndEnd();
                    require(!life.inTransaction(), "FAILED_EFFECT_ROLLBACK");
                    throw primary;
                });
                throw new IllegalStateException("QA_NATIVE_BRIDGE_PRIMARY_NOT_PROPAGATED");
            } catch (IllegalStateException failure) { require(failure == primary, "PRIMARY_OUTER_IDENTITY"); }
            require(effects.get() == 1, "EFFECT_EXACTLY_ONCE");
            f.absentAfterRollback("failed-effect");
        }
        try (Fixture f = new Fixture(context)) {
            f.bridge.withScope(f.binding, scope -> {
                VeilCheckpointSqlite.ProducerLifecycle life = scope.lifecycle();
                life.begin();
                VeilCheckpointSqlite.SqlPort sql = scope.checkedSql();
                VeilCheckpointSqlite.AuthorizationOnly auth = scope.authorizationOnly();
                insert(sql, "expired");
                scope.freezeSqlAndBusinessHandles();
                f.clock.set(61000); // Monotonic synthetic clock reaches exact expiry, never rolled back.
                refused(auth::checkLive, "VEIL_LEASE_EXPIRED");
                refused(() -> sql.query(QUERY, args("expired"), BUDGET), "VEIL_LEASE_EXPIRED");
                life.rollbackAndEnd();
                require(!life.inTransaction(), "EXPIRED_CLEANUP_END");
                return Unit.INSTANCE;
            });
            f.absentAfterRollback("expired");
            refused(() -> f.bridge.withScope(f.binding, scope -> Unit.INSTANCE), "VEIL_LEASE_EXPIRED");
        }
        for (boolean failedEffect : new boolean[] {false, true}) try (Fixture f = new Fixture(context)) {
            CountDownLatch completed = new CountDownLatch(1);
            AtomicReference<Throwable> failure = new AtomicReference<>();
            Thread revoker = new Thread(() -> {
                try { f.authority.revoke(); }
                catch (Throwable error) { failure.set(error); }
                finally { completed.countDown(); }
            }, "owned-native-bridge-revoke");
            f.track(revoker);
            IllegalStateException effectFailure = new IllegalStateException("QA_NATIVE_BRIDGE_QUEUED_EFFECT_FAILURE");
            AtomicLong effects = new AtomicLong();
            if (failedEffect) {
                failedEffectCaller(f, revoker, effectFailure, effects, false, 5000);
            } else {
              Throwable primary = null;
              try {
                f.bridge.withScope(f.binding, scope -> {
                    VeilCheckpointSqlite.ProducerLifecycle life = scope.lifecycle();
                    life.begin(); insert(scope.checkedSql(), "serialized-revoke");
                    revoker.start();
                    awaitRealRevokeQueue(revoker);
                    scope.authorizationOnly().checkLive();
                    scope.freezeSqlAndBusinessHandles();
                    life.rollbackAndEnd();
                    return Unit.INSTANCE;
                });
              } catch (Throwable failureInScope) {
                primary = failureInScope;
              } finally {
                primary = joinWorker(revoker, 5000, primary, f::quarantine);
              }
              propagate(primary);
            }
            require(!revoker.isAlive() && completed.getCount() == 0 && failure.get() == null,
                "REVOKE_COMPLETES_AFTER_SCOPE");
            refused(() -> f.bridge.withScope(f.binding, scope -> Unit.INSTANCE), "VEIL_LEASE_REVOKED_OR_FOREIGN");
            f.absentAfterRollback("serialized-revoke");
        }
        if (Thread.currentThread().isInterrupted())
            throw new IllegalStateException("QA_NATIVE_BRIDGE_EXTERNAL_SUPERVISOR_INTERRUPT");
        if (checks != EXPECTED_CHECKS) throw new IllegalStateException(
            "QA_NATIVE_BRIDGE_ASSERTION_COUNT_EXPECTED_" + EXPECTED_CHECKS + "_GOT_" + checks);
        return "PASS_" + checks + "_ACTUAL_NATIVE_AUTHORITY_STORE_BRIDGE_COMPONENT_CHECKS; "
            + "B1 real WAITING+ReentrantLock+AQS+revoke queue observed; B2 cleanup negatives/quarantine; "
            + "F1 actual caller interrupted/timeout sentinel+suppression+flag preserved; I1 shared lifecycle lock and quarantine-first negatives; L141-I1 throwing cleanup retained and actual close-first already-admitted disposition; four actual fixture DBs quarantined without close/delete; "
            + "quarantinedDbNames=" + CALLER_QUARANTINE_NAMES + "; "
            + "SYNTHETIC verifier/binding/monotonic-clock/data; no Keystore/sealer/legacy-transaction/CAS; "
            + "RUNTIME_COMPLETE=false; production trust NOT_VERIFIED";
    }
}
