package com.ynx.social.matrix;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;
import kotlin.Unit;

/** Actual NativeStore frozen-verifier component, SYNTHETIC grants/data ONLY.
 * No reflection, raw SQL handle, sealer, protected successful commit or anchor.
 */
public final class VeilNativeFrozenVerifierInstalledCheck {
    private VeilNativeFrozenVerifierInstalledCheck() {}
    private static int checks;
    private static final int EXPECTED_CHECKS = 100;
    private static final String INTENTS = "veil_checkpoint_intents_v1";
    private static final String CHUNKS = "veil_checkpoint_chunks_v1";
    private static final String MARKERS = "veil_checkpoint_committed_ops_v1";
    private static final String RECORD_ID = "synthetic-known-session";
    private static final byte[] SEALED = new byte[] {17,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28};
    private static final VeilCheckpointSqlite.Budget RECORD_BUDGET = new VeilCheckpointSqlite.Budget(1,3,29,29,32,64);
    private static final VeilCheckpointSqlite.Budget SCALAR_BUDGET = new VeilCheckpointSqlite.Budget(1,1,0,0,0,0);
    private static void require(boolean ok, String code) {
        if (!ok) throw new IllegalStateException("QA_FROZEN_VERIFIER_" + code);
        checks++;
    }
    private static void refused(Runnable action, String code) {
        try { action.run(); }
        catch (IllegalStateException failure) { require(code.equals(failure.getMessage()), "WRONG_REFUSAL"); return; }
        throw new IllegalStateException("QA_FROZEN_VERIFIER_REFUSAL_MISSING");
    }
    private static String sha(byte[] bytes) throws Exception {
        StringBuilder result = new StringBuilder();
        for (byte value : MessageDigest.getInstance("SHA-256").digest(bytes))
            result.append(String.format(java.util.Locale.ROOT, "%02x", value & 255));
        return result.toString();
    }
    /** Independent original Store encoding: BE UTF8 length-prefixed domain/binding/kind/id. */
    private static byte[] aad(VeilDeviceBinding b, String kind, String id) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) {
            for (String value : Arrays.asList("ynx-social-veil-native-store-v2", b.getOwner(), b.getDevice(),
                b.getSocialIdentityFingerprint(), b.getKeyAlias(), kind, id)) {
                byte[] encoded = value.getBytes(StandardCharsets.UTF_8);
                out.writeInt(encoded.length); out.write(encoded);
            }
        }
        return bytes.toByteArray();
    }
    /** One known SESSION row (already canonical kind/id order), not a hash exported by Store. */
    private static String business(VeilDeviceBinding b, long revision) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) {
            out.write(aad(b, "SESSION", "checkpoint-domain")); out.writeLong(revision);
            byte[] rowAad = aad(b, "SESSION", RECORD_ID);
            out.writeInt(rowAad.length); out.write(rowAad);
            out.writeInt(SEALED.length); out.write(SEALED);
        }
        return sha(bytes.toByteArray());
    }
    private static VeilCheckpointSqlite.NamedValue v(String name, Object value) {
        VeilCheckpointSqlite.Value typed;
        if (value == null) typed = VeilCheckpointSqlite.Value.Null.INSTANCE;
        else if (value instanceof String) typed = new VeilCheckpointSqlite.Value.Text((String) value);
        else if (value instanceof Long) typed = new VeilCheckpointSqlite.Value.Integer((Long) value);
        else typed = new VeilCheckpointSqlite.Value.Blob((byte[]) value);
        return new VeilCheckpointSqlite.NamedValue(name, typed);
    }
    /** Independent known-row auxiliary encoding; compare public snapshot helper BEFORE freeze. */
    private static void table(DataOutputStream out, String name, Object... row) throws Exception {
        out.writeUTF(name); out.writeInt(1); out.writeInt(row.length);
        for (Object value : row) {
            if (value == null) out.writeByte(0);
            else if (value instanceof Long) { out.writeByte(1); out.writeLong((Long) value); }
            else {
                byte[] bytes = value instanceof String ? ((String) value).getBytes(StandardCharsets.UTF_8) : (byte[]) value;
                out.writeByte(value instanceof String ? 2 : 3); out.writeInt(bytes.length); out.write(bytes);
            }
        }
    }
    private static final class Fixture implements AutoCloseable {
        final VeilDeviceBinding nativeBinding;
        final VeilCheckpointCommit.Binding binding;
        final VeilNativeStore store;
        final VeilCheckpointSqlite.NativeStoreBridge bridge;
        final File database;
        final AtomicLong protectorCalls = new AtomicLong();
        final String op = UUID.randomUUID().toString();
        final String base, next, cipher;
        String phase = "PREPARED", marker;
        byte[] chunk = new byte[] {3, 5, 7};
        Fixture(Context context) throws Exception {
            String uuid = UUID.randomUUID().toString();
            nativeBinding = new VeilDeviceBinding("synthetic-frozen-" + uuid, "synthetic-device-" + uuid,
                "synthetic-fingerprint-" + uuid, "ynx.social.veil.v2.synthetic-frozen-" + uuid);
            binding = new VeilCheckpointCommit.Binding(nativeBinding.getOwner(), nativeBinding.getDevice(),
                nativeBinding.getSocialIdentityFingerprint(), nativeBinding.getKeyAlias());
            AtomicLong clock = new AtomicLong(1000);
            VeilDeviceGrantVerifier verifier = (proof, expected, minimum) -> {
                if (!nativeBinding.equals(expected) || !Arrays.equals(proof, new byte[] {1}) || minimum > 7)
                    throw new IllegalStateException("QA_FROZEN_VERIFIER_SYNTHETIC_GRANT_REJECTED");
                return new VeilVerifiedDeviceGrant(expected, 7, 61000, VeilDeviceApproval.TRUSTED_DEVICE);
            };
            VeilNativeAuthority authority = new VeilNativeAuthority(nativeBinding, verifier, () -> clock.get());
            VeilNativeLease lease = authority.admit(new byte[] {1});
            VeilCheckpointProtector protector = new VeilCheckpointProtector() {
                @Override public VeilStorageCheckpoint load(VeilDeviceBinding ignored) {
                    protectorCalls.incrementAndGet(); throw new IllegalStateException("QA_FROZEN_VERIFIER_PROTECTOR_FORBIDDEN");
                }
                @Override public void advance(VeilDeviceBinding ignored, VeilStorageCheckpoint b, VeilStorageCheckpoint n) {
                    protectorCalls.incrementAndGet(); throw new IllegalStateException("QA_FROZEN_VERIFIER_PROTECTOR_FORBIDDEN");
                }
            };
            database = new File(new File(context.getNoBackupFilesDir(), "veil-v2"),
                sha(aad(nativeBinding, "SESSION", "checkpoint-domain")) + ".sqlite");
            require(!database.exists() && !new File(database + "-wal").exists()
                && !new File(database + "-shm").exists() && !new File(database + "-journal").exists(), "UUID_COLLISION");
            base = business(nativeBinding, 0); next = business(nativeBinding, 1);
            cipher = sha(chunk); marker = sha("synthetic-marker".getBytes(StandardCharsets.UTF_8));
            store = new VeilNativeStore(context, authority, lease, protector);
            bridge = store.checkpointBridge$ynx_social_native_matrix_debug();
        }
        String auxiliary() throws Exception {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (DataOutputStream out = new DataOutputStream(bytes)) {
                table(out, INTENTS, op, nativeBinding.getOwner(), nativeBinding.getDevice(), nativeBinding.getSocialIdentityFingerprint(),
                    nativeBinding.getKeyAlias(), 0L, base, 1L, next, cipher, 7L, phase, 3L, 1L, null);
                table(out, CHUNKS, op, 0L, chunk);
                table(out, MARKERS, op, marker);
            }
            return sha(bytes.toByteArray());
        }
        void seed(VeilCheckpointSqlite.SqlPort sql) {
            sql.executeSchema("CREATE TABLE IF NOT EXISTS veil_checkpoint_intents_v1 (op TEXT PRIMARY KEY NOT NULL, owner TEXT NOT NULL, device TEXT NOT NULL, identity_fp TEXT NOT NULL, key_alias TEXT NOT NULL, base_rev INTEGER NOT NULL, base_hash TEXT NOT NULL, next_rev INTEGER NOT NULL, next_hash TEXT NOT NULL, cipher_hash TEXT NOT NULL, auth_gen INTEGER NOT NULL, phase TEXT NOT NULL, candidate_bytes INTEGER NOT NULL, chunk_count INTEGER NOT NULL, receipt BLOB)");
            sql.executeSchema("CREATE TABLE IF NOT EXISTS veil_checkpoint_chunks_v1 (op TEXT NOT NULL, part INTEGER NOT NULL, bytes BLOB NOT NULL, PRIMARY KEY(op,part))");
            sql.executeSchema("CREATE TABLE IF NOT EXISTS veil_checkpoint_committed_ops_v1 (op TEXT PRIMARY KEY NOT NULL, commitment_hash TEXT NOT NULL)");
            require(sql.insert("records", Arrays.asList(v("kind", "SESSION"), v("id", RECORD_ID), v("sealed", SEALED))) != -1, "SEED_RECORD");
            require(sql.insert(INTENTS, Arrays.asList(v("op", op), v("owner", nativeBinding.getOwner()), v("device", nativeBinding.getDevice()),
                v("identity_fp", nativeBinding.getSocialIdentityFingerprint()), v("key_alias", nativeBinding.getKeyAlias()),
                v("base_rev", 0L), v("base_hash", base), v("next_rev", 1L), v("next_hash", next), v("cipher_hash", cipher),
                v("auth_gen", 7L), v("phase", phase), v("candidate_bytes", 3L), v("chunk_count", 1L), v("receipt", null))) != -1, "SEED_INTENT");
            require(sql.insert(CHUNKS, Arrays.asList(v("op", op), v("part", 0L), v("bytes", chunk))) != -1, "SEED_CHUNK");
            require(sql.insert(MARKERS, Arrays.asList(v("op", op), v("commitment_hash", marker))) != -1, "SEED_MARKER");
        }
        @Override public void close() {
            store.close();
            require(protectorCalls.get() == 0, "NO_PROTECTOR_CALLS");
            require(SQLiteDatabase.deleteDatabase(database), "OWNED_UUID_DB_CLEANUP");
        }
    }
    private static String changed(String hash) { return (hash.charAt(0) == 'a' ? "b" : "a") + hash.substring(1); }
    private static void scenario(Context context, int which) throws Exception {
        try (Fixture f = new Fixture(context)) {
            final String baseline = f.auxiliary();
            f.bridge.withScope(f.binding, scope -> {
                VeilCheckpointSqlite.ProducerLifecycle life = scope.lifecycle();
                life.begin();
                VeilCheckpointSqlite.SqlPort sql = scope.checkedSql();
                f.seed(sql);
                VeilCheckpointSqlite.Snapshot rows = sql.query("SELECT kind,id,sealed FROM records ORDER BY kind,id", Collections.emptyList(), RECORD_BUDGET);
                require(rows.getSize() == 1 && "SESSION".equals(rows.row(0).text(0, 32))
                    && RECORD_ID.equals(rows.row(0).text(1, 32)) && Arrays.equals(SEALED, rows.row(0).blob(2)), "ACTUAL_KNOWN_RECORD");
                require(sql.query("SELECT revision FROM checkpoint WHERE slot=1", Collections.emptyList(), SCALAR_BUDGET).row(0).integer(0) == 0, "ACTUAL_REVISION_ZERO");
                require(baseline.equals(VeilCheckpointSqlite.Companion.auxiliaryFingerprint(sql)), "INDEPENDENT_AUX_BASELINE");
                String table = which == 2 ? MARKERS : which == 3 ? INTENTS : CHUNKS;
                String column = which == 2 ? "commitment_hash" : which == 3 ? "phase" : "bytes";
                Object replacement = which == 2 ? changed(f.marker) : which == 3 ? "LOCAL_APPLIED" : new byte[] {3,5,8};
                List<VeilCheckpointSqlite.NamedValue> update = Collections.singletonList(v(column, replacement));
                List<VeilCheckpointSqlite.Value> opArg = Collections.singletonList(new VeilCheckpointSqlite.Value.Text(f.op));
                String current = baseline;
                if (which >= 2) {
                    require(sql.update(table, update, "op=?", opArg) == 1, "PRE_FREEZE_ISOLATED_MUTATION");
                    if (which == 2) f.marker = (String) replacement;
                    else if (which == 3) f.phase = (String) replacement;
                    else f.chunk = (byte[]) replacement;
                    try { current = f.auxiliary(); } catch (Exception failure) { throw new IllegalStateException("QA_FROZEN_VERIFIER_AUX_ENCODING", failure); }
                    require(current.equals(VeilCheckpointSqlite.Companion.auxiliaryFingerprint(sql)), "INDEPENDENT_MUTATED_AUX");
                    require(!baseline.equals(current), "ISOLATED_AUX_CHANGED");
                }
                scope.freezeSqlAndBusinessHandles();
                VeilCheckpointCommit.Checkpoint expected = new VeilCheckpointCommit.Checkpoint(0, f.base);
                if (which >= 2) refused(() -> life.verifyFrozenState(f.binding, expected, baseline), "VEIL_CHECKPOINT_NATIVE_AUXILIARY_CHANGED_AFTER_FREEZE");
                life.verifyFrozenState(f.binding, expected, current); require(true, "ACTUAL_FROZEN_VERIFY_SUCCESS_COMPONENT_ONLY");
                if (which == 0) refused(() -> life.verifyFrozenState(f.binding, new VeilCheckpointCommit.Checkpoint(0, changed(f.base)), baseline), "VEIL_CHECKPOINT_NATIVE_BUSINESS_CHANGED_AFTER_FREEZE");
                if (which == 1) refused(() -> life.verifyFrozenState(f.binding, expected, changed(baseline)), "VEIL_CHECKPOINT_NATIVE_AUXILIARY_CHANGED_AFTER_FREEZE");
                refused(() -> sql.update(table, update, "op=?", opArg), "VEIL_CHECKPOINT_NATIVE_SQL_INACTIVE");
                refused(() -> sql.query("SELECT revision FROM checkpoint WHERE slot=1", Collections.emptyList(), SCALAR_BUDGET), "VEIL_CHECKPOINT_NATIVE_SQL_INACTIVE");
                life.verifyFrozenState(f.binding, expected, current); require(true, "LATE_WRITE_REFUSED_STATE_UNCHANGED");
                life.rollbackAndEnd(); require(!life.inTransaction(), "PRIVILEGED_FROZEN_ROLLBACK");
                return Unit.INSTANCE;
            });
            f.bridge.withScope(f.binding, scope -> {
                VeilCheckpointSqlite.ProducerLifecycle life = scope.lifecycle(); life.begin();
                VeilCheckpointSqlite.SqlPort sql = scope.checkedSql();
                require(sql.query("SELECT kind,id,sealed FROM records ORDER BY kind,id", Collections.emptyList(), RECORD_BUDGET).getSize() == 0, "ROLLBACK_RECORD_ABSENT");
                require(sql.query("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('veil_checkpoint_intents_v1','veil_checkpoint_chunks_v1','veil_checkpoint_committed_ops_v1')", Collections.emptyList(), SCALAR_BUDGET).row(0).integer(0) == 0, "ROLLBACK_ALL_AUX_DDL_ABSENT");
                life.rollbackAndEnd(); return Unit.INSTANCE;
            });
        }
    }
    public static synchronized String runOwnedFixture(Context context) throws Exception {
        checks = 0;
        require("com.ynx.social.veilqa".equals(context.getPackageName()), "TARGET_NOT_OWNED");
        for (int which = 0; which < 5; which++) scenario(context, which);
        if (checks != EXPECTED_CHECKS) throw new IllegalStateException("QA_FROZEN_VERIFIER_ASSERTION_COUNT_MISMATCH");
        return "PASS; cases=5; assertions=" + checks + "; actualNativeFrozenVerifier=true; SYNTHETIC_GRANT_DATA_ONLY; PROTECTED_COMMIT_NOT_RUN; RUNTIME_COMPLETE_FALSE";
    }
}
