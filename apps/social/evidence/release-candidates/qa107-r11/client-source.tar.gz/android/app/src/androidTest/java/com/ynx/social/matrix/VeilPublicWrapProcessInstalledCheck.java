package com.ynx.social.matrix;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Process;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/** Public process observation ONLY. Not a native lease, device grant or key factory. */
final class VeilPublicWrapProcessInstalledCheck {
    static final String TARGET = "com.ynx.social.veilqa";
    static final String SCOPE = "5f21eea6a6f84897be2d7761e0c5702e";
    static final String ALIAS = "ynx.social.veilqa.publicwrap.20261005." + SCOPE;
    private static final int SID_MAX = 256;

    private static IllegalStateException refusal(String code) {
        return new IllegalStateException("QA_PUBLICWRAP_" + code);
    }

    /** Read this actual process, never shell metadata or Context.applicationInfo.uid. */
    private static String actualSid() {
        byte[] data = new byte[SID_MAX];
        int size = 0;
        try (FileInputStream input = new FileInputStream("/proc/self/attr/current")) {
            int value;
            while ((value = input.read()) != -1) {
                if (size == data.length) throw refusal("SID_BOUND");
                data[size++] = (byte) value;
            }
        } catch (IOException failure) {
            // Deliberately do not propagate arbitrary file/provider exception messages.
            throw refusal("SID_UNAVAILABLE");
        }
        while (size > 0 && (data[size - 1] == 0 || data[size - 1] == '\n')) size--;
        if (size == 0) throw refusal("SID_EMPTY");
        for (int n = 0; n < size; n++) {
            if (data[n] < 33 || data[n] > 126) throw refusal("SID_GRAMMAR");
        }
        String sid = new String(data, 0, size, StandardCharsets.US_ASCII);
        if (!sid.matches("u:r:untrusted_app(?:_[0-9]+)?:s0(?::c[0-9]+(?:\\.c[0-9]+)?(?:,c[0-9]+(?:\\.c[0-9]+)?)*)?"))
            throw refusal("SID_NOT_OWNED_APP_DOMAIN");
        return sid;
    }

    private static String actualName() {
        if (Build.VERSION.SDK_INT < 28) throw refusal("PUBLIC_PROCESS_API_UNAVAILABLE");
        String name = Application.getProcessName();
        if (!TARGET.equals(name)) throw refusal("PROCESS_NOT_OWNED_TARGET");
        return name;
    }

    private static void requireScope(Context context, String scope, String alias) {
        if (context == null) throw refusal("CONTEXT_REQUIRED");
        if (!TARGET.equals(context.getPackageName())) throw refusal("TARGET_NOT_OWNED");
        if (!SCOPE.equals(scope) || !ALIAS.equals(alias)) throw refusal("SCOPE_ALIAS_NOT_OWNED");
    }

    private static int requireActualUidBinding(Context context, int uid) {
        // PackageManager is corroboration of the measured UID, NOT its replacement.
        // Exact single package also refuses shared-UID/SDK-sandbox namespace ambiguity.
        PackageManager manager = context.getPackageManager();
        if (uid < Process.FIRST_APPLICATION_UID || manager == null)
            throw refusal("CALLER_UID_NOT_APP");
        String[] packages = manager.getPackagesForUid(uid);
        if (packages == null || packages.length != 1 || !TARGET.equals(packages[0]))
            throw refusal("CALLER_UID_NAMESPACE_MISMATCH");
        try {
            int targetUid = manager.getApplicationInfo(TARGET, 0).uid;
            if (targetUid != uid) throw refusal("CALLER_UID_METADATA_MISMATCH");
            return targetUid;
        } catch (PackageManager.NameNotFoundException failure) {
            throw refusal("TARGET_PACKAGE_METADATA_UNAVAILABLE");
        }
    }

    /** QA-only non-transferable guard. Issued from actual process reads, never supplied IDs. */
    static final class Guard {
        private final Context context;
        private final Thread thread;
        private final int uid;
        private final int pid;
        private final String sid;
        private final String name;
        private Guard(Context context, int uid, int pid, String sid, String name) {
            this.context = context;
            this.thread = Thread.currentThread();
            this.uid = uid;
            this.pid = pid;
            this.sid = sid;
            this.name = name;
        }
        /** Future caller must invoke around each synchronous provider operation.
         * Provider itself must ALSO capture at the actual create/seal/lookup site.
         * This outer check cannot prove a provider's worker/Binder calling namespace.
         */
        void verifyAtUse() {
            if (Thread.currentThread() != thread) throw refusal("GUARD_THREAD_MISMATCH");
            requireScope(context, SCOPE, ALIAS);
            if (Process.myUid() != uid || Process.myPid() != pid)
                throw refusal("CALLING_PROCESS_CHANGED");
            requireActualUidBinding(context, Process.myUid());
            if (!name.equals(actualName()) || !sid.equals(actualSid()))
                throw refusal("CALLING_DOMAIN_CHANGED");
        }
        String publicSidAtUse() { verifyAtUse(); return sid; }
        private JSONObject publicObservation() throws Exception {
            verifyAtUse();
            return new JSONObject().put("actualUid", uid).put("actualPid", pid)
                .put("targetPackageUid", requireActualUidBinding(context, Process.myUid()))
                .put("actualSid", sid).put("actualProcessName", name)
                .put("target", TARGET).put("scope", SCOPE).put("alias", ALIAS)
                .put("identitySource", "PROCESS_MYUID_MYPID_PROC_SELF_ATTR_CURRENT")
                .put("contextUidUsed", false).put("shellUidUsed", false)
                .put("keyOperations", "NOT_RUN_PROVIDER_CONTRACT_UNAVAILABLE")
                .put("aliasCollisionCheck", "NOT_RUN_NO_KEYSTORE_ACCESS")
                .put("productionAuthority", "REQUIRED")
                .put("runtimeComplete", false);
        }
    }

    static Guard capture(Context context, String scope, String alias) {
        requireScope(context, scope, alias);
        int uid = Process.myUid(), pid = Process.myPid();
        if (pid <= 0) throw refusal("PID_UNAVAILABLE");
        requireActualUidBinding(context, uid);
        Guard guard = new Guard(context, uid, pid, actualSid(), actualName());
        guard.verifyAtUse();
        return guard;
    }

    private interface RefusedCall { void run(); }
    private static void expectRefusal(String code, RefusedCall call) {
        try { call.run(); }
        catch (IllegalStateException failure) {
            if (("QA_PUBLICWRAP_" + code).equals(failure.getMessage())) return;
            throw failure;
        }
        throw refusal("NEGATIVE_UNEXPECTED_SUCCESS");
    }

    static String runIdentityOnly(Context context) throws Exception {
        int checks = 0;
        Guard guard = capture(context, SCOPE, ALIAS); checks++;
        guard.verifyAtUse(); checks++;
        expectRefusal("SCOPE_ALIAS_NOT_OWNED", () -> capture(context, SCOPE + "0", ALIAS)); checks++;
        expectRefusal("SCOPE_ALIAS_NOT_OWNED", () -> capture(context, SCOPE, ALIAS + ".other")); checks++;
        Context wrongTarget = new ContextWrapper(context) {
            @Override public String getPackageName() { return "com.ynx.social"; }
        };
        expectRefusal("TARGET_NOT_OWNED", () -> capture(wrongTarget, SCOPE, ALIAS)); checks++;
        expectRefusal("CONTEXT_REQUIRED", () -> capture(null, SCOPE, ALIAS)); checks++;
        JSONObject observation = guard.publicObservation(); checks++;
        if (checks != 7) throw refusal("IDENTITY_ASSERTION_COUNT");
        return observation.put("identityComponentAssertions", checks)
            .put("result", "PROCESS_IDENTITY_COMPONENT_ONLY").toString();
    }
}
