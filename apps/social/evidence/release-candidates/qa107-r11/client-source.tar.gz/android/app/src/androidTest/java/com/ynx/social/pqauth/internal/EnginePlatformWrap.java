package com.ynx.social.pqauth.internal;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Process;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyInfo;
import android.security.keystore.KeyProperties;
import java.io.*;
import java.security.*;
import java.util.Arrays;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.json.*;

// Internal CryptoEngine candidate. No public factory, key getter, JNI export or UI/JS API.
// This build admits ONLY the exact NONSECRET QA scope, not private production payload.
final class EnginePlatformWrap implements AutoCloseable {
    static final class Guard {
        private final Context context;
        private final JSONArray events;
        private Integer pid;
        private String sid;
        Guard(Context context, JSONArray events) { this.context = context; this.events = events; }
        void check(String operation) throws Exception {
            int uid = Process.myUid(), currentPid = Process.myPid();
            String currentSid = readSid();
            JSONObject e = new JSONObject(); e.put("operation", operation); e.put("uid", uid);
            e.put("pid", currentPid); e.put("sid", currentSid); events.put(e);
            if (Build.VERSION.SDK_INT != 36 || context == null
                    || !WrapRecord.PACKAGE.equals(context.getPackageName())
                    || !WrapRecord.PACKAGE.equals(Application.getProcessName())
                    || uid != WrapRecord.UID
                    || context.getPackageManager().getApplicationInfo(WrapRecord.PACKAGE, 0).uid != uid
                    || !currentSid.matches("u:r:untrusted_app[A-Za-z0-9_]*:s0(?::c[0-9]+(?:,c[0-9]+)*)?"))
                throw new SecurityException("CALLING_PROCESS_SCOPE_MISMATCH");
            if (pid != null && (pid != currentPid || !sid.equals(currentSid))) throw new SecurityException("CALLING_PROCESS_CHANGED");
            pid = currentPid; sid = currentSid;
        }
        int pid() { if (pid == null) throw new IllegalStateException("GUARD_NOT_CHECKED"); return pid; }
        String sid() { if (sid == null) throw new IllegalStateException("GUARD_NOT_CHECKED"); return sid; }
        private static String readSid() throws IOException {
            try (InputStream in = new FileInputStream("/proc/self/attr/current")) {
                byte[] b = new byte[257]; int n = 0, r;
                while (n < b.length && (r = in.read(b, n, b.length - n)) != -1) n += r;
                if (n == 0 || n > 256) throw new IOException("SID_UNAVAILABLE_OR_BOUNDS");
                return new String(b, 0, n, java.nio.charset.StandardCharsets.US_ASCII).trim();
            }
        }
    }
    private final Guard guard;
    private final JSONObject provider;
    private SecretKey key;
    private EnginePlatformWrap(Guard guard, SecretKey key, JSONObject provider) { this.guard = guard; this.key = key; this.provider = provider; }
    static EnginePlatformWrap createQa(Guard g, JSONObject info) throws Exception {
        g.check("create-collision-check");
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (store.containsAlias(WrapRecord.ALIAS)) throw new IllegalStateException("ALIAS_COLLISION_PRESERVED");
        g.check("create");
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(WrapRecord.ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).setUserAuthenticationRequired(false).build());
        // QA authentication=false is explicit, not a production accessibility/authorization policy.
        generator.generateKey(); // No getEncoded/export. Existing aliases are never deleted or enumerated.
        return lookupQa(g, info);
    }
    static EnginePlatformWrap lookupQa(Guard g, JSONObject info) throws Exception {
        g.check("lookup");
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (!store.containsAlias(WrapRecord.ALIAS)) throw new KeyStoreException("QA_KEY_NOT_FOUND_NO_REGENERATION");
        Key candidate = store.getKey(WrapRecord.ALIAS, null);
        if (!(candidate instanceof SecretKey) || !"AES".equals(candidate.getAlgorithm())) throw new KeyStoreException("KEY_PROFILE");
        SecretKey secret = (SecretKey) candidate;
        g.check("key-info");
        KeyInfo k = (KeyInfo) SecretKeyFactory.getInstance("AES", "AndroidKeyStore").getKeySpec(secret, KeyInfo.class);
        if (k.getKeySize() != 256 || k.getPurposes() != (KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                || k.getOrigin() != KeyProperties.ORIGIN_GENERATED || k.isUserAuthenticationRequired()
                || !Arrays.equals(k.getBlockModes(), new String[]{KeyProperties.BLOCK_MODE_GCM})
                || !Arrays.equals(k.getEncryptionPaddings(), new String[]{KeyProperties.ENCRYPTION_PADDING_NONE}))
            throw new KeyStoreException("KEY_AUTHORIZATION_PROFILE");
        info.put("keyStoreProvider", store.getProvider().getName()); info.put("keySize", k.getKeySize());
        info.put("securityLevel", k.getSecurityLevel()); info.put("hardwareClaim", "REPORTED_LEVEL_ONLY_NOT_ATTESTATION");
        info.put("purposes", k.getPurposes()); info.put("qaUserAuthenticationRequired", k.isUserAuthenticationRequired());
        return new EnginePlatformWrap(g, secret, info);
    }
    synchronized WrapRecord seal(WrapRecord.Binding binding, byte[] clear) throws Exception {
        requireOpen();
        if (binding == null || clear == null || clear.length > WrapRecord.MAX_CLEAR) throw new IllegalArgumentException("CLEAR_BOUNDS");
        byte[] input = null, aad = null;
        try {
            aad = binding.aad(); input = clear.clone();
            guard.check("seal");
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key);
            providerCheck(c); byte[] nonce = c.getIV();
            if (nonce == null || nonce.length != WrapRecord.NONCE_BYTES) throw new GeneralSecurityException("PROVIDER_NONCE_PROFILE");
            c.updateAAD(aad); byte[] ciphertext = c.doFinal(input);
            if (ciphertext.length != input.length + WrapRecord.TAG_BYTES) throw new GeneralSecurityException("PROVIDER_TAG_PROFILE");
            return new WrapRecord(binding, nonce, ciphertext);
        } finally {
            if (input != null) Arrays.fill(input, (byte)0);
            if (aad != null) Arrays.fill(aad, (byte)0);
        }
    }
    synchronized byte[] unseal(WrapRecord record) throws Exception {
        requireOpen(); if (record == null) throw new IllegalArgumentException("RECORD_REQUIRED");
        byte[] nonce = record.nonce(), aad = record.binding.aad(), ciphertext = record.ciphertext();
        try {
            guard.check("unseal");
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, nonce)); providerCheck(c);
            c.updateAAD(aad);
            // No update plaintext sink. Only authenticated doFinal result can leave this internal method.
            byte[] clear = c.doFinal(ciphertext);
            if (clear.length > WrapRecord.MAX_CLEAR) { Arrays.fill(clear, (byte)0); throw new GeneralSecurityException("CLEAR_BOUNDS"); }
            return clear;
        } finally { Arrays.fill(nonce, (byte)0); Arrays.fill(aad, (byte)0); Arrays.fill(ciphertext, (byte)0); }
    }
    private void providerCheck(Cipher c) throws Exception {
        String name = c.getProvider().getName();
        if (!name.startsWith("AndroidKeyStore")) throw new GeneralSecurityException("CIPHER_PROVIDER_PROFILE");
        provider.put("cipherProvider", name);
    }
    private void requireOpen() { if (key == null) throw new IllegalStateException("WRAPPER_CLOSED"); }
    @Override public synchronized void close() { key = null; } // Drops reference, not platform key deletion or whole-memory erasure.
}
