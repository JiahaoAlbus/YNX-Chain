package com.ynx.social.matrix;

/** QA-only secondary observation. No RNG, native API or production override. */
final class VeilPqQaObservation {
  private VeilPqQaObservation() {}
  static void bestEffort(Runnable observation) {
    try { observation.run(); } catch(Throwable ignored) {
      // Do not allocate suppression metadata, retry or replace a primary error.
    }
  }
}
