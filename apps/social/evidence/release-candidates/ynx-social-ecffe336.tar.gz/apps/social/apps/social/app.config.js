const path = require("path");

module.exports = {
  expo: {
    name: "YNX Social",
    slug: "ynx-social",
    version: "1.0.2-testnet-preview",
    orientation: "portrait",
    icon: path.resolve(__dirname, "assets/icon.png"),
    userInterfaceStyle: "light",
    // Keep the Social profile scheme and register the frozen Wallet/Auth
    // callback as a second scheme. The latter is not interchangeable with a
    // generic Social link: its host is checked by the native manifest.
    scheme: ["ynxsocial", "ynx-social"],
    splash: { image: path.resolve(__dirname, "assets/splash.png"), resizeMode: "contain", backgroundColor: "#FFFFFF" },
    ios: {
      bundleIdentifier: "com.ynx.social",
      supportsTablet: true,
      infoPlist: {
        LSApplicationQueriesSchemes: ["ynxwallet"],
        NSContactsUsageDescription: "YNX Social matches locally selected contact hashes only after you allow access.",
        NSPhotoLibraryUsageDescription: "Choose an image to share in a Social post or message.",
        NSCameraUsageDescription: "Scan a YNX Social profile QR only when you choose the QR discovery method."
      }
    },
    android: {
      package: "com.ynx.social",
      allowBackup: false,
      adaptiveIcon: { foregroundImage: path.resolve(__dirname, "assets/adaptive-icon.png"), backgroundColor: "#FFFFFF" },
      permissions: ["READ_CONTACTS", "READ_MEDIA_IMAGES", "CAMERA"],
      blockedPermissions: [
        "android.permission.RECORD_AUDIO",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.WRITE_CONTACTS"
      ]
    },
    plugins: ["expo-secure-store", ["expo-camera", { cameraPermission: "Scan a YNX Social profile QR only when you choose QR discovery." }], ["expo-image-picker", { photosPermission: "Choose images you explicitly share in YNX Social." }], ["expo-contacts", { contactsPermission: "Match contacts only after you explicitly allow YNX Social." }]],
    extra: { product: "social", chainId: "ynx_6423-1", evmChainId: 6423, asset: "YNXT" }
  }
};
