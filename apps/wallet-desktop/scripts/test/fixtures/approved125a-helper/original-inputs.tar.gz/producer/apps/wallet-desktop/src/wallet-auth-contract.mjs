import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { parseProductSessionRegistry, YNX_EVM_CHAIN_ID as SHARED_EVM_CHAIN_ID, YNX_TESTNET_CHAIN_QUANTITY as SHARED_CHAIN_QUANTITY } from "@ynx-chain/wallet-auth";

// Preserve the prior installed source and the exact A-issued compatible SDK.
// Unknown bytes fail closed rather than claiming an old source receipt.
const reviewedProtocolSources = Object.freeze({
  "7435a65bedac4fc6abd7d36a07cb8ab4c4ab957841475a36819a43b442b67130": "529471f3822d2bac43ea47a1ab8004fa2ae79885",
  "96d27a2a18c538725278db45675cf96a1ccc3f3d0f5af14b9950dd6334594a41": "1d4201b1a462dfd7b879fa810d2e3bd43a8642b1",
  // Exact SDK R3 frozen source receipt, not chain/Source admission.
  "8d1c4f1d0b64c8d61bdee964ebf062e2c7067920745fbce6a620a2b8c3849ded": "0ec5ce5d9a65649dd8f8f4b591c2beaf2d003bfc",
  // Exact frozen R3b reference-return successor; not Source admission.
  "460b4e514ae748de5d73defa932c3aa840cb4cd50b5525a6eda1e8461e423544": "b164a68376ad784bfd5f83513611f6a4ee008070",
  // Exact SDK46 normal-package source, checked against its frozen full-prefix
  // inventory AND original Git source. Receipt only, not v4/Source admission.
  "6f67298154ebf44b9fd1c5b01c75dbb16cee425ab8164e53dc9c8e504892741c": "59a3797ea3421129171565e37870568e424ec085",
  // Coherent SDK49 normal prefix9606 and original afa53 source: receipt only.
  // This neither admits v4 Native custody nor supplies its pairing/issuer.
  "e3cab9c1139cbcd0100eac430b0267614c7b12b43432e06448b5bdf01c6f7db4": "afa53c4dddba6bb9e06b6619dea45af189978fb6",
});
const sourceSha256 = createHash("sha256").update(readFileSync(new URL("./product-session-v2.js", import.meta.resolve("@ynx-chain/wallet-auth")))).digest("hex");
const sourceCommit = reviewedProtocolSources[sourceSha256];
if (!sourceCommit) throw new Error("The packaged Wallet authorization protocol has no reviewed source receipt.");
export const WALLET_AUTH_PROTOCOL_SOURCE = Object.freeze({
  package: "@ynx-chain/wallet-auth",
  sourceCommit,
  sourcePath: "packages/wallet-auth/src/product-session-v2.js",
  sourceSha256,
  protocol: "product-session-v2"
});

export const PRODUCT_SESSION_REGISTRY = parseProductSessionRegistry(JSON.parse(readFileSync(
  new URL("../product-session-registry.json", import.meta.resolve("@ynx-chain/wallet-auth")), "utf8"
)));
export const YNX_TESTNET_CHAIN_QUANTITY = SHARED_CHAIN_QUANTITY;
export const YNX_EVM_CHAIN_ID = SHARED_EVM_CHAIN_ID;
