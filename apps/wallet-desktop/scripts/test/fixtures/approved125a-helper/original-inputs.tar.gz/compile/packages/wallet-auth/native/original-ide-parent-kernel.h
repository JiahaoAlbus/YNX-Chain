#pragma once
#ifdef __OBJC__
#import <Foundation/Foundation.h>
#import <mach/message.h>
#include "original-ide-parent-prelude.h"
#include "original-ide-parent-source-binding.h"
#include <vector>
#include <sys/stat.h>
namespace ynx_auth_ide_private {
struct ResourceCloseDebt {struct Entry {int descriptor;struct stat identity;};std::vector<Entry> unknown;bool clean()const{return unknown.empty();}};
struct KernelProcess {ProcessOriginal original{};NSData *__strong codeIdentity=nil;NSString *__strong image=nil;};
KernelProcess observeKernel(pid_t);
audit_token_t originalSelfAudit();
bool verifyKernelAudit(const std::array<unsigned char,32>&,const ProcessOriginal&);
bool sameKernel(const KernelProcess&,const KernelProcess&);
NSString *actualNodeParentResources();
bool actualNodeEntry(NSString *resources,NSString *entryFileURL);
// Observed child entry is a kernel/file fact, never a Source grant.
bool originalObservedNodeEntry(const KernelProcess&,NSString *resources);
bool registeredResources(NSString *resources,const SourceBinding&,ResourceCloseDebt&);
// File-byte matching only, not Source/process admission. Qualified identity
// holder supplies its authenticated registration; old four-op SourceBinding
// is not constructed or lent to the identity path.
bool identityResourceBytes(NSString *resources,NSDictionary *registration,ResourceCloseDebt&);
std::array<unsigned char,32> originalRequestDigest(const SourceBinding&);
Prelude originalPrelude(PreludeKind,const SourceBinding&);
bool originalPreludeBinding(const Prelude&,const SourceBinding&);
std::uint64_t monotonicMS();
std::uint64_t wallMS();
}
#endif
