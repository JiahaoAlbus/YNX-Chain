#pragma once
#include <cstdint>
#include <memory>
#include "pay_native_permission_private.hpp"
namespace ynx_auth_private {
// Retain an uncertain descriptor number as evidence, never close it again:
// a failed close may already have released/recycled that number.
struct TemporaryDescriptor {
 int fd=-1;bool selected=false,completed=false;
 bool hold(int value){if(value<0||unresolved())return false;fd=value;selected=false;completed=false;return true;}
 template<class Closer> bool closeOnce(Closer closer){
  if(selected)return completed;if(fd<0)return true;selected=true;
  completed=closer(fd)==0;if(completed)fd=-1;return completed;
 }
 bool unresolved()const{return fd>=0;}
 int identity()const{return fd;}
 bool available()const{return fd<0;}
};
// Known child custody is a join fence, not uncertain cleanup failure.
struct ChildOwnership {static bool joined(unsigned children){return children==0;}};
// Internal source-state validator: shape/current fences, never an approval.
struct SourceClock {
 std::uint64_t floor=0,generation=0;
 bool observe(std::uint64_t now,std::uint64_t issued,std::uint64_t expires,std::uint64_t head,std::uint64_t profile,bool revoked){
  if(revoked||!head||head!=profile||head<generation||now<floor||now<issued||expires<=issued||now>=expires)return false;
  floor=now;generation=head;return true;
 }
};
enum class JointPhase { reserved,unknown,committed,retired,closed };
struct JointLifecycle {
 JointPhase phase=JointPhase::reserved;bool attempted=false,cleanupSelected=false,cleanupComplete=false;
 bool enterCommit(){if(attempted||phase!=JointPhase::reserved)return false;attempted=true;phase=JointPhase::unknown;return true;}
 bool completeReadback(){if(phase!=JointPhase::unknown)return false;phase=JointPhase::committed;return true;}
 void retire(){if(phase!=JointPhase::closed)phase=JointPhase::retired;}
 bool selectCleanup(){if(cleanupSelected)return false;cleanupSelected=true;retire();return true;}
 void completedCleanup(bool completed){cleanupComplete=completed;if(completed)phase=JointPhase::closed;}
};
}
#ifdef __OBJC__
#import <Foundation/Foundation.h>
@class YNXAuthIdentityCurrentOwner;
@class YNXIDEHelperMessagePeer;
@interface YNXAuthIdentitySourceAuthority : NSObject

+ (instancetype)acquireOriginalWalletNativePayClientSource:(NSError**)error;
- (BOOL)assertOriginalWalletNativePayClientCurrent:(NSError**)error;
- (const void*)originalWalletNativePaySourceMarker:(NSError**)error;
- (NSDictionary*)copyOriginalWalletNativePayClientContext:(NSError**)error;
#ifdef __cplusplus
- (std::shared_ptr<ynx_auth_private::PayObservedPermission>)borrowOriginalWalletNativePayPermission:(NSError**)error;
#endif
- (BOOL)closeOriginalWalletNativePaySource:(NSError**)error;
+ (instancetype)acquireOriginalSource:(NSError **)error;
// Separate original protected Wallet PQ catalog Source. No Auth/IDE purpose,
// input path/provider, ordinary signing permit or Go DATA may qualify this.
+ (instancetype)acquireOriginalWalletPQHostCatalogSource:(NSError **)error;
// Distinct Source acquisition stage, not a device-slot/HTTP signer factory.
// No arguments can inject a Source/Root/profile/key/path. Error+nonnil is the
// SAME cleanup partial; caller must retain it before inspecting error.
+ (instancetype)acquireOriginalProductSessionDeviceV4Source:(NSError **)error;
- (BOOL)assertOriginalProductSessionDeviceV4SourceCurrent:(NSError **)error;
// Exact authenticated public scope for THIS dedicated Source, bounded by
// pre/post physical current. Not a key slot or account/Root signing permit.
- (NSDictionary *)copyOriginalProductSessionDeviceV4Scope:(NSError **)error;
+ (instancetype)acquireOriginalProductSessionDeviceV4PendingSource:(NSError **)error;
+ (instancetype)acquireOriginalProductSessionDeviceV4ProvisioningSource:(NSError **)error;
- (BOOL)assertOriginalProductSessionDeviceV4ProvisioningSourceCurrent:(NSError **)error;
- (NSDictionary *)copyOriginalProductSessionDeviceV4ProvisioningScope:(NSError **)error;
// Native-only fixed Main loader input from THIS original release selection.
// Retains the exact module file/current; not a caller path or user approval.
- (NSString *)copyOriginalProductSessionDeviceV4ApprovalModulePath:(NSError **)error;
- (NSDictionary *)copyOriginalProductSessionDeviceV4ProvisioningJournal:(NSError **)error;
+ (instancetype)acquireOriginalProductSessionDeviceV4QuerySource:(NSError **)error;
+ (instancetype)acquireOriginalProductSessionHTTPProofV5Source:(NSError **)error;
- (BOOL)assertOriginalProductSessionHTTPProofV5SourceCurrent:(NSError **)error;
- (NSDictionary *)copyOriginalProductSessionHTTPProofV5Scope:(NSError **)error;
- (NSString *)copyOriginalProductSessionHTTPProofV5ModulePath:(NSError **)error;
+ (instancetype)acquireOriginalProductSessionDeviceV4RegisteredFinalizationSource:(NSError **)error;
- (BOOL)assertOriginalProductSessionDeviceV4RegisteredFinalizationSourceCurrent:(NSError **)error;
- (NSDictionary*)readOriginalProductSessionDeviceV4RegisteredFinalizationScope:(NSError **)error;
- (NSDictionary*)copyOriginalProductSessionDeviceV4RegisteredFinalizationContext:(NSError **)error;
- (NSString*)copyOriginalProductSessionDeviceV4RegisteredFinalizationModulePath:(NSError **)error;
- (BOOL)assertOriginalProductSessionDeviceV4QuerySourceCurrent:(NSError **)error;
// Private current query scope + original profile window/journal selection.
// No creation approval, raw key access or caller-selectable path.
- (NSDictionary *)copyOriginalProductSessionDeviceV4QueryContext:(NSError **)error;
- (NSString *)copyOriginalProductSessionDeviceV4QueryModulePath:(NSError **)error;
- (BOOL)assertOriginalProductSessionDeviceV4PendingSourceCurrent:(NSError **)error;
- (NSDictionary *)copyOriginalProductSessionDeviceV4PendingScope:(NSError **)error;
- (NSDictionary *)copyOriginalWalletPQHostCatalogContext:(NSError **)error;
// Helper's own independently admitted Source, bound to ONE actual incoming
// OS message. Peer identity supplies target only, never Source permission.
// Failure plus nonnil result is the same cleanup partial; capture it first.
+ (instancetype)acquireOriginalHelperSourceForMessagePeer:(YNXIDEHelperMessagePeer*)peer error:(NSError**)error;
// Derived from actual parent app + actual runtime/node; no caller path.
+ (instancetype)acquireOriginalIDEConsumerSource:(NSError **)error;
+ (instancetype)acquireOriginalIDEContractRelaySource:(NSError **)error;
+ (instancetype)acquireOriginalIDEProjectAuthoritySource:(NSError **)error;
+ (instancetype)acquireOriginalIDEProjectControlAuthoritySource:(NSError **)error;
- (NSDictionary *)copyOriginalIDEProjectControlCapture:(NSError **)error;
// Dedicated original Source purpose only, never Relay/old login/key-call ACL.
// Read-only Native snapshots; caller project/publisher IDs restrict selection.
- (NSDictionary *)copyOriginalIDECurrentProject:(NSString *)projectID error:(NSError **)error;
- (NSDictionary *)copyOriginalIDECurrentServiceRegistration:(NSString *)projectID error:(NSError **)error;
- (NSDictionary *)copyOriginalIDEProjectSelectionLocal:(NSError **)error;
- (NSDictionary *)copyOriginalIDECurrentPublisher:(NSString *)publisherID forProject:(NSString *)projectID error:(NSError **)error;
+ (instancetype)acquireOriginalIDEParentSource:(NSError **)error;
// Dedicated identity-purpose Wallet owner; never old four-operation admission.
+ (instancetype)acquireOriginalIDEIdentityWalletSource:(NSError **)error;
- (BOOL)assertCurrent:(NSError **)error;
- (BOOL)assertAuthenticatedNativePurpose:(NSError **)error;
- (NSDictionary *)copyOriginalSelection:(NSError **)error;
// Native Wallet only. Requires the dedicated Root-signed CONTROL custody
// selection; old capture-only profiles cannot lend private key permission.
- (NSDictionary *)copyOriginalIDEProjectControlSigningContext:(NSError **)error;
- (NSNumber *)copyOriginalCurrentSequence:(NSError **)error;
// Private provisioning receiver input: exact signed public originals, DATA only.
// This never lends a current signer or authenticates a reserve request.
- (NSDictionary *)copyOriginalProvisioningPublicOriginals:(NSError **)error;
// Private original privileged Native receiver. No path/UID/Root/key/approval
// argument: target comes from actual kernel getuid and the existing registry.
// Requires the SAME independently admitted Source purpose RECEIVE; login and
// raw DATA cannot authorize installation. Exact public originals only, not a
// recovery/signing/export/transaction capability. Partial stays this owner.
- (NSDictionary *)installOriginalIDEIdentityPublicOriginals:(NSError **)error;
// Actual cold filesystem readback against THIS Source's immutable originals.
// This is DATA only, not identity/key recovery or a new Native admission.
- (NSDictionary *)copyOriginalIDEInstalledPublicOriginals:(NSError **)error;
// Private Native caller only. Returns authenticated DATA, never admission.
// The original caller owns once-selection/lifetime/HostState+entered binding;
// no caller policy, key, path, current original or clock is accepted here.
- (NSDictionary *)verifyOriginalFirstEnterWitness:(NSData *)witness
 binding:(NSDictionary *)binding requestId:(NSString *)requestId
 nonce:(NSString *)nonce error:(NSError **)error;
// Same original Source/task and independent compiled release, not a JS verifier.
- (BOOL)assertOriginalIDEIdentityProofConsumerReady:(NSData *)request error:(NSError **)error;
- (BOOL)assertOriginalIDEIdentityReceiveExecutionAvailable:(NSError **)error;
- (BOOL)verifyOriginalIDEIdentityProof:(NSData *)wire expectedRequest:(NSData *)request invocation:(NSData *)invocation error:(NSError **)error;
// Native-only immutable observation of this SAME actual verified N1/request/
// invocation. Rechecks original Source/request/fixed expiry before returning.
// DATA only, NOT publication permission, a publisher signature or retry token.
- (NSDictionary *)copyOriginalIDEVerifiedProofForRequest:(NSData *)request invocation:(NSData *)invocation error:(NSError **)error;
// Private local-only relay project observation. Requires a dedicated verified
// Source profile; old four-operation/identity/publication profiles cannot lend
// this scope. Never HTTP, verifier process, signature, renewal or JS policy.
- (NSDictionary *)copyOriginalIDEContractRelayScopeLocal:(NSError **)error;
- (NSDictionary *)copyOriginalIDEContractRelayPeerBindingLocal:(NSError **)error;
- (BOOL)pinOriginalIDEContractRelayRuntime:(NSError **)error;
- (BOOL)assertOriginalIDEContractRelayRuntimeCurrent:(NSError **)error;
- (NSDictionary *)copyOriginalIDEContractRelayLaunchLocal:(NSError **)error;
- (void)retire;
- (BOOL)join:(NSError **)error;
- (BOOL)close:(NSError **)error;
@end
// Implemented by the original R91 Native request category in the SAME image.
@interface YNXAuthIdentitySourceAuthority (OriginalIDEIdentityRequestFence)
- (BOOL)assertOriginalIDEIdentityRequestCurrent:(NSData *)request invocation:(NSData *)invocation error:(NSError **)error;
@end
#endif
