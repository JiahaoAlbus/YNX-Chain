# Finance Broker Sandbox integration — incremental checkpoint

Authority: `YNX_Codex_Weekly_v3_Credential_Independent_ZH.md`, read 2026-09-19. This adds to Finance; it does not replace planning, reports, Wallet or the existing chain. No network configuration migration is included.

## Verified documentation, not verified credentials

Official sources read on 2026-09-19:

- [Authentication](https://docs.alpaca.markets/us/docs/authentication): Broker Sandbox and its auth host are distinct from personal Trading/Paper. M2M client credentials support body-posted client secret and private-key JWT; legacy authentication remains documented.
- [Broker getting started](https://docs.alpaca.markets/us/docs/getting-started-with-broker-api): assets `/v1/assets`, Broker orders `/v1/trading/accounts/{account_id}/orders`, SSE events and `X-Request-ID` audit correlation.
- [Trading account](https://docs.alpaca.markets/us/reference/gettradingaccount): Finance reads cash, buying power and the trading/account/suspension fences from `/v1/trading/accounts/{account_id}/account`; it does not use the account-registration route or personal `/v2/account` endpoint for trading preflight.
- [Broker orders](https://docs.alpaca.markets/us/reference/getallordersforaccount): account-scoped `/v1/trading/accounts/{account_id}/orders`, bounded to 500 per read by this adapter.
- [Broker positions](https://docs.alpaca.markets/us/v1.4.2/reference/getpositionsforaccount): account-scoped `/v1/trading/accounts/{account_id}/positions`.
- [Trade events v2](https://docs.alpaca.markets/us/v1.1/reference/subscribetotradev2sse): `/v2/events/trades` is the documented SSE event source; the legacy v1 route is deprecated for new partners.
- [Broker FAQ](https://docs.alpaca.markets/us/docs/broker-api-faq): Broker and personal Trading API serve different account models. No external stress tests are authorized.

Implementation: Go standard-library HTTP, no third-party Alpaca SDK. Broker REST path version v1; no claim that a locally pinned SDK/schema is the provider's latest release. Fixed sandbox origins, no redirects or environment proxy, bounded time/body, no automatic retries. Official account entitlements remain unknown.

## Authentication choice

Default `client_credentials` uses `client_secret_post`, caches tokens in server memory with expiry safety margin and concurrent refresh serialization. Tokens are credentials, not durable business state. The implementation never prints them. Explicit `legacy_basic` supports operators actually provisioned Broker key/secret credentials; there is no silent fallback between modes. `private_key_jwt` is **unsupported**, not emulated; if that is the only provisioned method, implement it before activation. Broker credentials must never enter Web/mobile bundles or public status.

## Implemented credential-independent boundary and explicit gaps

Implemented: fail-closed server configuration; normalized asset search, account/cash/buying-power, orders and positions reads; provider-verified owner watchlists; bounded read-only reconciliation; safe provider errors/request IDs; public no-secret module status; guest not-configured UI; and read-only doctor. The persistent resolver is backed by Finance state v2 and is keyed by authenticated YNX subject + provider + trading environment. It also stores the operator-verified Wallet public key used for order approval, so the browser never asks a user to type either a Broker asset UUID or Wallet public key. There is no shared global Broker account and no browser-supplied provider account selection. Raw provider order status and bounded HTTP request IDs are retained with order/outbox/journal audit data; SSE cursor remains a separate recovery field.

The accepted `finance-order-approval-v1` files are imported byte-for-byte with four source SHA-256 values. Finance derives the subject from trusted session identity, validates exact decimals without floats, persists challenges/orders/journal/outbox, arbitrates reject/revoke/expire/consume through one CAS and allocates one stable `client_order_id`. Manual and AI-produced draft fields use the same deterministic validator. Provider submit/cancel calls are implemented only behind both server-side Sandbox write activation and the exact operator receipt. The authenticated product execution route can durably queue one idempotent approved request but cannot perform a provider write; only the controlled worker can claim it.

Implemented product entry: public provider-backed asset search; authenticated owner watchlist; owner snapshot; controlled refresh/reconcile; persisted local approval/outbox/journal recovery; an idempotent owner execution-request route; and a cancellation-intent route. Challenge/callback and execution request are authenticated Finance-profile writes. The operator-only worker provides account linking, query, reconciliation, bounded SSE application, one-shot dispatch and one-shot cancellation. Provider submit/cancel still require the separate write flag and exact activation receipt; no browser route can invoke them directly.

The final local pre-submit fence uses `execution_blocked` for an expired approval or changed owner-to-provider mapping. Those states contain no provider order, raw status or provider HTTP request ID and are not counted as provider rejection. Provider-read preflight failures remain bounded retryable requests, while canonical provider rejection still requires `PROVIDER_REJECTED` plus the provider request correlation required by the worker.

Runtime configuration reads and validates the pinned Broker origin, token origin, Market Data origin, activation receipt, and independently enforces concurrency-safe Broker read, Broker write and Market Data sliding one-minute limits before contacting the provider. Defaults keep trading writes and live trading false. If `YNX_FINANCE_DATABASE_URL` is configured, server and worker both require the PostgreSQL CAS backend; they do not fall back to the bootstrap file. The file-oriented backup CLI rejects database-backed mode until a database-native backup path exists.

Safe enablement is deliberately operator controlled: verify the owner mapping and read-only account/asset/quote/position/order entitlement, record the exact Wallet-approved order id, enable Sandbox writes with the 64-hex activation receipt, queue the exact order through the authenticated product execution request, then run one `dispatch-one` worker command. `verify-approved` remains the explicitly confirmed verification sequence and creates its own one-time execution request. Roll back by disabling the write flag and reconciling any correlated or ambiguous order; never repeat a provider-correlated or provider-rejected order.

Still unverified: official credentials, market-data entitlement, simulated funding, real v2 SSE transport, an authorized low-frequency provider write, public deployment and visible Wallet approval. All unconfigured provider reads fail explicitly and no fallback asset, balance, order or trade is synthesized.

Frozen shared authority: `finance-order-approval-v1.md` SHA-256 `f236823ba32a892c4157745490d2ff2767dcc33928b4d4b9dbbbfb8e0dc334f3` plus schema `c3e61e2...`, transport `f45c7ab4...` and vectors `f8f4810e...`. Product Session identity is not order approval. DEX/Card signatures are not repurposed. Submission is disabled by default. It becomes eligible only when configuration is valid, the Sandbox write flag and exact activation receipt agree, the owner mapping and canonical fee evidence exist, Wallet approval has been consumed, the product has queued an idempotent execution request, and an operator runs the one-shot worker; there is no browser provider-write route.

Six independent statuses: implemented=credential-independent-core; contractTested=local-fixture-only; officialSandboxVerified=false; publicDeployed=false; publicVerified=false; productionApproved=false. The presence of credentials or a successful asset GET cannot change these aggregate gates.
