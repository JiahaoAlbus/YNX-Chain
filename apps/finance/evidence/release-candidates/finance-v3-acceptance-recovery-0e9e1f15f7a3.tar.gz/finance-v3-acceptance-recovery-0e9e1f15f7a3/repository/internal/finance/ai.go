package finance

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type AIRequest struct {
	Kind           string         `json:"kind"`
	Account        string         `json:"account"`
	RecordIDs      []string       `json:"recordIds"`
	ContextClasses []string       `json:"contextClasses"`
	Context        map[string]any `json:"context"`
	Permission     string         `json:"permission"`
	OutputLocale   string         `json:"outputLocale"`
}

// AISecuritiesOrderIntent is advisory context only. It deliberately omits an
// asset id: the user must still select the exact provider-backed asset and
// complete the independent Wallet approval flow before any order can exist.
type AISecuritiesOrderIntent struct {
	Symbol     string `json:"symbol"`
	Side       string `json:"side"`
	Qty        string `json:"qty"`
	LimitPrice string `json:"limitPrice"`
}

type AIProvider interface {
	Status(context.Context) (provider, model string, available bool, err error)
	Estimate(context.Context, AIRequest) (string, error)
	Stream(context.Context, AIRequest, func(string)) (map[string]any, error)
}

type HTTPAIProvider struct {
	URL    string
	APIKey string
	Client *http.Client
}

func (p *HTTPAIProvider) Status(ctx context.Context) (string, string, bool, error) {
	if strings.TrimSpace(p.URL) == "" {
		return "YNX AI Gateway", "", false, errors.New("YNX AI Gateway is not configured")
	}
	var health struct {
		OK    bool   `json:"ok"`
		Model string `json:"model"`
	}
	if err := p.get(ctx, "/health", &health); err != nil {
		return "YNX AI Gateway", "", false, err
	}
	return "YNX AI Gateway", health.Model, health.OK, nil
}

func (p *HTTPAIProvider) Estimate(ctx context.Context, request AIRequest) (string, error) {
	return "unavailable from AI Gateway; no monetary charge is inferred", nil
}

func (p *HTTPAIProvider) Stream(ctx context.Context, request AIRequest, emit func(string)) (map[string]any, error) {
	raw, _ := json.Marshal(request)
	query := "Return one reviewable Finance analysis draft as strict JSON. Never execute or claim to execute an action. Input: " + string(raw)
	if request.Kind == "draft_broker_order" {
		query = "Return only strict JSON matching {\"schemaVersion\":\"finance.ai.broker-order-draft.v1\",\"draftOnly\":true,\"orderDraft\":{\"symbol\":string,\"side\":\"buy\"|\"sell\",\"qty\":canonical-whole-share-string,\"limitPrice\":canonical-fixed-decimal-USD-string,\"timeInForce\":\"day\",\"warnings\":[non-empty-string]}}. Use exactly these root and orderDraft fields. qty must be a base-10 integer from 1 through 1000000. limitPrice must be from 0.0001 through 999999999.9999, with at most four fractional digits and no sign, exponent, fraction, whitespace, leading zero, or trailing fractional zero. Never execute, approve, select an asset id, or claim a broker action. Input: " + string(raw)
	}
	endpoint := strings.TrimRight(p.URL, "/") + "/ai/stream?session=" + url.QueryEscape("finance:"+request.Account) + "&q=" + url.QueryEscape(query)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint, nil)
	if err != nil {
		return nil, err
	}
	if p.APIKey != "" {
		req.Header.Set("X-YNX-AI-Key", p.APIKey)
	}
	resp, err := p.client().Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, fmt.Errorf("AI Gateway returned HTTP %d", resp.StatusCode)
	}
	var result map[string]any
	var complete strings.Builder
	scanner := bufio.NewScanner(resp.Body)
	scanner.Buffer(make([]byte, 4096), 256*1024)
	for scanner.Scan() {
		line := scanner.Text()
		if !strings.HasPrefix(line, "data: ") {
			continue
		}
		var event map[string]any
		if err := json.Unmarshal([]byte(strings.TrimPrefix(line, "data: ")), &event); err != nil {
			return nil, errors.New("AI Gateway stream contained invalid SSE JSON")
		}
		if delta, ok := event["text"].(string); ok {
			complete.WriteString(delta)
			emit(delta)
		}
	}
	if err := scanner.Err(); err != nil {
		return nil, err
	}
	if complete.Len() > 0 {
		decoder := json.NewDecoder(strings.NewReader(complete.String()))
		decoder.UseNumber()
		if err := decoder.Decode(&result); err != nil || decoder.Decode(&struct{}{}) != io.EOF {
			return nil, errors.New("AI_RESULT_INVALID_JSON")
		}
	}
	if result == nil {
		return nil, errors.New("AI Gateway stream ended without a reviewable result")
	}
	return result, nil
}

func (p *HTTPAIProvider) get(ctx context.Context, path string, out any) error {
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, strings.TrimRight(p.URL, "/")+path, nil)
	if p.APIKey != "" {
		req.Header.Set("X-YNX-AI-Key", p.APIKey)
	}
	resp, err := p.client().Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("AI Gateway returned HTTP %d", resp.StatusCode)
	}
	return json.NewDecoder(resp.Body).Decode(out)
}

func (p *HTTPAIProvider) post(ctx context.Context, path string, input, out any) error {
	raw, _ := json.Marshal(input)
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, strings.TrimRight(p.URL, "/")+path, bytes.NewReader(raw))
	req.Header.Set("Content-Type", "application/json")
	if p.APIKey != "" {
		req.Header.Set("Authorization", "Bearer "+p.APIKey)
	}
	resp, err := p.client().Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("AI Gateway returned HTTP %d", resp.StatusCode)
	}
	return json.NewDecoder(resp.Body).Decode(out)
}

func (p *HTTPAIProvider) client() *http.Client {
	if p.Client != nil {
		return p.Client
	}
	return &http.Client{Timeout: 30 * time.Second}
}

func (s *Service) StartAI(ctx context.Context, account, kind string, recordIDs, classes []string, consent bool, portfolio Portfolio, outputLocale ...string) (AIJob, error) {
	locale := ""
	if len(outputLocale) == 1 {
		locale = outputLocale[0]
	}
	return s.StartAIWithIntent(ctx, account, kind, recordIDs, classes, consent, portfolio, locale, nil)
}

func (s *Service) StartAIWithIntent(ctx context.Context, account, kind string, recordIDs, classes []string, consent bool, portfolio Portfolio, outputLocale string, orderIntent *AISecuritiesOrderIntent) (AIJob, error) {
	if !consent || (kind != "categorize" && kind != "explain_fees" && kind != "draft_budget" && kind != "detect_anomalies" && kind != "explain_recurring" && kind != "draft_broker_order") {
		return AIJob{}, errors.New("supported AI workflow and explicit context permission are required")
	}
	state := s.Store.Account(account)
	if !state.Privacy.AllowAIActivityContext {
		return AIJob{}, errors.New("AI activity context is disabled in privacy settings")
	}
	owned := map[string]Activity{}
	for _, activity := range portfolio.Activity {
		owned[activity.ID] = activity
	}
	selected := []Activity{}
	for _, id := range recordIDs {
		activity, ok := owned[id]
		if !ok {
			return AIJob{}, errors.New("AI context contains a record not owned by this account")
		}
		selected = append(selected, activity)
	}
	if len(selected) > 50 {
		return AIJob{}, errors.New("select no more than 50 owned records")
	}
	if kind == "draft_broker_order" {
		if len(selected) == 0 {
			if len(recordIDs) != 0 || len(classes) != 0 {
				return AIJob{}, errors.New("empty securities chain context must not claim activity records or classes")
			}
		} else if len(classes) != 1 || classes[0] != "owned_activity" {
			return AIJob{}, errors.New("selected Finance activity requires the owned_activity context class")
		}
	} else {
		if len(selected) == 0 {
			return AIJob{}, errors.New("select between one and 50 owned records")
		}
		if len(classes) != 1 || classes[0] != "owned_activity" {
			return AIJob{}, errors.New("Finance AI only accepts the owned_activity context class")
		}
	}
	locale := "en"
	if outputLocale != "" {
		locale = outputLocale
	}
	if !allowedLocale(locale) {
		return AIJob{}, errors.New("AI output locale is unsupported")
	}
	requestRecordIDs := append([]string{}, recordIDs...)
	requestClasses := append([]string{}, classes...)
	request := AIRequest{Kind: kind, Account: account, RecordIDs: requestRecordIDs, ContextClasses: requestClasses, Context: map[string]any{"activity": selected, "categories": state.Categories, "budgets": state.Budgets}, Permission: "draft-only; no transaction, transfer, trade, borrow, lend, stake, freeze, or account-control authority", OutputLocale: locale}
	if kind == "draft_broker_order" {
		if orderIntent == nil || !validAIOrderIntent(*orderIntent) {
			return AIJob{}, errors.New("AI_BROKER_ORDER_INTENT_INVALID")
		}
		request.Context["securitiesOrderIntent"] = *orderIntent
		contextReason := "selected_owned_activity"
		if len(selected) == 0 {
			contextReason = "not_selected"
			if !portfolio.ExplorerStatus.Available {
				contextReason = "explorer_unavailable"
			}
		}
		request.Context["chainActivityContext"] = map[string]any{"available": portfolio.ExplorerStatus.Available, "activityCount": len(selected), "reason": contextReason}
	} else if orderIntent != nil {
		return AIJob{}, errors.New("AI_ORDER_INTENT_NOT_ALLOWED")
	}
	provider, model, available, err := s.AI.Status(ctx)
	if err != nil || !available {
		if err == nil {
			err = errors.New("AI provider reports unavailable")
		}
		return AIJob{}, err
	}
	estimate, err := s.AI.Estimate(ctx, request)
	if err != nil {
		return AIJob{}, err
	}
	now := time.Now().UTC()
	job := AIJob{ID: newID("ai"), Account: account, Kind: kind, RecordIDs: requestRecordIDs, ContextClasses: requestClasses, Provider: provider, Model: model, EstimatedCost: estimate, OutputLocale: locale, Status: "running", CreatedAt: now, UpdatedAt: now}
	if err := s.Store.Update(account, "ai.started", job.ID, func(state *AccountState) error { state.AIJobs = append(state.AIJobs, job); return nil }); err != nil {
		return AIJob{}, err
	}
	jobCtx, cancel := context.WithCancel(context.Background())
	s.aiMu.Lock()
	if s.aiCancels == nil {
		s.aiCancels = map[string]context.CancelFunc{}
	}
	s.aiCancels[job.ID] = cancel
	s.aiMu.Unlock()
	go s.runAI(jobCtx, request, job.ID, account)
	return job, nil
}

func (s *Service) runAI(ctx context.Context, request AIRequest, jobID, account string) {
	result, err := s.AI.Stream(ctx, request, func(delta string) {
		_ = s.updateAIJob(account, jobID, func(job *AIJob) {
			job.Progress += delta
			if len(job.Progress) > 4000 {
				job.Progress = job.Progress[len(job.Progress)-4000:]
			}
			job.UpdatedAt = time.Now().UTC()
		})
	})
	_ = s.updateAIJob(account, jobID, func(job *AIJob) {
		job.UpdatedAt = time.Now().UTC()
		if err != nil {
			if errors.Is(err, context.Canceled) {
				job.Status = "cancelled"
			} else {
				job.Status = "failed"
			}
			job.Error = err.Error()
			return
		}
		if validationErr := validateAIResult(request.Kind, result); validationErr != nil {
			job.Status = "failed"
			job.Error = validationErr.Error()
			return
		}
		job.Status = "ready"
		job.Result = result
	})
	s.aiMu.Lock()
	delete(s.aiCancels, jobID)
	s.aiMu.Unlock()
}

func validAIOrderIntent(intent AISecuritiesOrderIntent) bool {
	return financeSymbolPattern.MatchString(intent.Symbol) &&
		(intent.Side == "buy" || intent.Side == "sell") &&
		financeQtyPattern.MatchString(intent.Qty) &&
		financePricePattern.MatchString(intent.LimitPrice)
}

func validateAIResult(kind string, result map[string]any) error {
	if kind != "draft_broker_order" {
		return nil
	}
	if result == nil {
		return errors.New("AI_RESULT_EMPTY")
	}
	rootAllowed := map[string]bool{"schemaVersion": true, "draftOnly": true, "orderDraft": true}
	if len(result) != len(rootAllowed) {
		return errors.New("AI_ORDER_DRAFT_SCHEMA_INVALID")
	}
	for key := range result {
		if !rootAllowed[key] {
			return errors.New("AI_ORDER_DRAFT_SCHEMA_INVALID")
		}
	}
	if result["schemaVersion"] != "finance.ai.broker-order-draft.v1" || result["draftOnly"] != true {
		return errors.New("AI_ORDER_DRAFT_SCHEMA_INVALID")
	}
	draft, ok := result["orderDraft"].(map[string]any)
	if !ok {
		return errors.New("AI_ORDER_DRAFT_SCHEMA_INVALID")
	}
	allowed := map[string]bool{"symbol": true, "side": true, "qty": true, "limitPrice": true, "timeInForce": true, "warnings": true}
	if len(draft) != len(allowed) {
		return errors.New("AI_ORDER_DRAFT_SCHEMA_INVALID")
	}
	for key := range draft {
		if !allowed[key] {
			return errors.New("AI_ORDER_DRAFT_SCHEMA_INVALID")
		}
	}
	intent := AISecuritiesOrderIntent{Symbol: stringValue(draft["symbol"]), Side: stringValue(draft["side"]), Qty: stringValue(draft["qty"]), LimitPrice: stringValue(draft["limitPrice"])}
	if !validAIOrderIntent(intent) || draft["timeInForce"] != "day" {
		return errors.New("AI_ORDER_DRAFT_FIELDS_INVALID")
	}
	warnings, ok := draft["warnings"].([]any)
	if !ok || len(warnings) == 0 || len(warnings) > 8 {
		return errors.New("AI_ORDER_DRAFT_WARNINGS_REQUIRED")
	}
	for _, warning := range warnings {
		text, ok := warning.(string)
		if !ok || strings.TrimSpace(text) == "" || len(text) > 240 {
			return errors.New("AI_ORDER_DRAFT_WARNINGS_INVALID")
		}
	}
	return nil
}

func stringValue(value any) string {
	text, _ := value.(string)
	return text
}

func (s *Service) CancelAI(account, id string) error {
	job, ok := s.aiJob(account, id)
	if !ok || job.Status != "running" {
		return errors.New("running AI job not found")
	}
	s.aiMu.Lock()
	cancel := s.aiCancels[id]
	s.aiMu.Unlock()
	if cancel == nil {
		return errors.New("AI job cannot be cancelled after restart")
	}
	cancel()
	return nil
}

func (s *Service) DeleteAI(account, id string) error {
	job, ok := s.aiJob(account, id)
	if !ok {
		return errors.New("AI job not found")
	}
	if job.Status == "running" {
		return errors.New("cancel a running AI job before deleting it")
	}
	return s.Store.Update(account, "ai.deleted", id, func(state *AccountState) error {
		for i := range state.AIJobs {
			if state.AIJobs[i].ID == id {
				state.AIJobs = append(state.AIJobs[:i], state.AIJobs[i+1:]...)
				return nil
			}
		}
		return errors.New("AI job not found")
	})
}

func (s *Service) DecideAI(account, id, decision string) error {
	if decision != "apply" && decision != "reject" {
		return errors.New("AI decision must be apply or reject")
	}
	job, ok := s.aiJob(account, id)
	if !ok || job.Status != "ready" {
		return errors.New("reviewable AI job not found")
	}
	if decision == "apply" && job.Kind == "categorize" {
		assignments, _ := job.Result["assignments"].([]any)
		if len(assignments) == 0 || len(assignments) > len(job.RecordIDs) {
			return errors.New("AI category draft has no bounded assignments")
		}
		return s.Store.Update(account, "ai.applied", id, func(state *AccountState) error {
			allowed := map[string]bool{}
			for _, record := range job.RecordIDs {
				allowed[record] = true
			}
			for _, raw := range assignments {
				item, _ := raw.(map[string]any)
				record, _ := item["recordId"].(string)
				category, _ := item["categoryId"].(string)
				if !allowed[record] || !categoryExists(*state, category) {
					return errors.New("AI result references an unauthorized record or category")
				}
				state.Classifications[record] = Classification{RecordID: record, CategoryID: category, Source: "ai-reviewed", UpdatedAt: time.Now().UTC()}
			}
			for i := range state.AIJobs {
				if state.AIJobs[i].ID == id {
					state.AIJobs[i].Status = "applied"
					state.AIJobs[i].Decision = decision
					state.AIJobs[i].UpdatedAt = time.Now().UTC()
				}
			}
			return nil
		})
	}
	if decision == "apply" && job.Kind == "draft_budget" {
		drafts, _ := job.Result["budgets"].([]any)
		if len(drafts) == 0 || len(drafts) > 10 {
			return errors.New("AI budget draft must contain between one and ten budgets")
		}
		return s.Store.Update(account, "ai.applied", id, func(state *AccountState) error {
			if len(state.Budgets)+len(drafts) > 64 {
				return errors.New("budget limit reached")
			}
			now := time.Now().UTC()
			for _, raw := range drafts {
				item, _ := raw.(map[string]any)
				name, _ := item["name"].(string)
				name = strings.TrimSpace(name)
				category, _ := item["categoryId"].(string)
				period, _ := item["period"].(string)
				limit := aiInt64(item["limitYnxt"])
				if name == "" || len(name) > 64 || !categoryExists(*state, category) || (period != "weekly" && period != "monthly") || limit <= 0 {
					return errors.New("AI budget draft contains invalid or unauthorized fields")
				}
				state.Budgets = append(state.Budgets, Budget{ID: newID("budget"), Name: name, CategoryID: category, LimitYNXT: limit, Period: period, StartsAt: now, CreatedAt: now, UpdatedAt: now, Source: "ai-reviewed"})
			}
			for i := range state.AIJobs {
				if state.AIJobs[i].ID == id {
					state.AIJobs[i].Status = "applied"
					state.AIJobs[i].Decision = decision
					state.AIJobs[i].UpdatedAt = now
				}
			}
			return nil
		})
	}
	return s.updateAIJob(account, id, func(job *AIJob) {
		job.Status = map[bool]string{true: "rejected", false: "applied"}[decision == "reject"]
		job.Decision = decision
		job.UpdatedAt = time.Now().UTC()
	})
}

func aiInt64(value any) int64 {
	switch v := value.(type) {
	case float64:
		return int64(v)
	case int64:
		return v
	case json.Number:
		parsed, _ := v.Int64()
		return parsed
	default:
		return 0
	}
}

func (s *Service) aiJob(account, id string) (AIJob, bool) {
	for _, job := range s.Store.Account(account).AIJobs {
		if job.ID == id {
			return job, true
		}
	}
	return AIJob{}, false
}

func (s *Service) updateAIJob(account, id string, fn func(*AIJob)) error {
	return s.Store.Update(account, "ai.updated", id, func(state *AccountState) error {
		for i := range state.AIJobs {
			if state.AIJobs[i].ID == id {
				fn(&state.AIJobs[i])
				return nil
			}
		}
		return errors.New("AI job not found")
	})
}
