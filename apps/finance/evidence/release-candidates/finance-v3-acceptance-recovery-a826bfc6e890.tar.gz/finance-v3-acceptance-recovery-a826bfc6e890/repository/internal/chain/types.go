package chain

import "time"

type NetworkConfig struct {
	Name                 string `json:"name"`
	Slug                 string `json:"slug"`
	ChainID              int64  `json:"chainId"`
	NativeCoinName       string `json:"nativeCoinName"`
	NativeCurrencySymbol string `json:"nativeCurrencySymbol"`
	Decimals             int    `json:"decimals"`
	IsPublicNet          bool   `json:"isPublicNet"`
	ChainIDConflictCheck string `json:"chainIdConflictCheck"`
}

type Account struct {
	Address       string           `json:"address"`
	Balance       int64            `json:"balance"`
	Staked        int64            `json:"staked"`
	Nonce         uint64           `json:"nonce"`
	ResourceUsage ResourceUsage    `json:"resourceUsage"`
	Lots          map[string]int64 `json:"lots"`
}

type ExplorerSummary struct {
	Network            NetworkConfig `json:"network"`
	Height             uint64        `json:"height"`
	LatestBlockHash    string        `json:"latestBlockHash"`
	LatestBlockTime    time.Time     `json:"latestBlockTime"`
	TotalBlocks        int           `json:"totalBlocks"`
	TotalTransactions  int           `json:"totalTransactions"`
	KnownAccounts      int           `json:"knownAccounts"`
	ValidatorCount     int           `json:"validatorCount"`
	PendingTxCount     int           `json:"pendingTxCount"`
	PayIntentCount     int           `json:"payIntentCount"`
	InvoiceCount       int           `json:"invoiceCount"`
	TrustEvidenceCount int           `json:"trustEvidenceCount"`
	GovernanceRequests int           `json:"governanceRequestCount"`
	AppealCount        int           `json:"appealCount"`
	TransparencyCount  int           `json:"transparencyReportCount"`
	ContractCount      int           `json:"contractCount"`
	PersistenceEnabled bool          `json:"persistenceEnabled"`
	PersistenceError   string        `json:"persistenceError,omitempty"`
	TruthfulStatus     string        `json:"truthfulStatus"`
}

type ResourceUsage struct {
	BandwidthUsed  int64 `json:"bandwidthUsed"`
	ComputeUsed    int64 `json:"computeUsed"`
	AICreditsUsed  int64 `json:"aiCreditsUsed"`
	TrustUsed      int64 `json:"trustUsed"`
	PayCreditsUsed int64 `json:"payCreditsUsed"`
}

type ResourceBalance struct {
	Address        string `json:"address"`
	BandwidthLimit int64  `json:"bandwidthLimit"`
	BandwidthUsed  int64  `json:"bandwidthUsed"`
	BandwidthLeft  int64  `json:"bandwidthLeft"`
	ComputeLimit   int64  `json:"computeLimit"`
	ComputeUsed    int64  `json:"computeUsed"`
	ComputeLeft    int64  `json:"computeLeft"`
	AICreditsLimit int64  `json:"aiCreditsLimit"`
	AICreditsUsed  int64  `json:"aiCreditsUsed"`
	AICreditsLeft  int64  `json:"aiCreditsLeft"`
	TrustLimit     int64  `json:"trustLimit"`
	TrustUsed      int64  `json:"trustUsed"`
	TrustLeft      int64  `json:"trustLeft"`
	PayCreditsUsed int64  `json:"payCreditsUsed"`
	Staked         int64  `json:"staked"`
}

type ResourceMarketPolicy struct {
	ID                    string   `json:"id"`
	Version               string   `json:"version"`
	GovernanceStatus      string   `json:"governanceStatus"`
	Currency              string   `json:"currency"`
	BandwidthUnit         int64    `json:"bandwidthUnit"`
	BandwidthUnitPrice    int64    `json:"bandwidthUnitPrice"`
	ComputeUnit           int64    `json:"computeUnit"`
	ComputeUnitPrice      int64    `json:"computeUnitPrice"`
	AICreditUnitPrice     int64    `json:"aiCreditUnitPrice"`
	TrustCreditUnitPrice  int64    `json:"trustCreditUnitPrice"`
	MinimumQuoteYNXT      int64    `json:"minimumQuoteYnxt"`
	QuoteTTLSeconds       int64    `json:"quoteTtlSeconds"`
	ProviderShareBps      int64    `json:"providerShareBps"`
	ProtocolFeeBps        int64    `json:"protocolFeeBps"`
	BaseBandwidth         int64    `json:"baseBandwidth"`
	BaseCompute           int64    `json:"baseCompute"`
	BaseAICredits         int64    `json:"baseAiCredits"`
	BaseTrustCredits      int64    `json:"baseTrustCredits"`
	BandwidthStakeDivisor int64    `json:"bandwidthStakeDivisor"`
	ComputeStakeDivisor   int64    `json:"computeStakeDivisor"`
	AICreditStakeDivisor  int64    `json:"aiCreditStakeDivisor"`
	TrustStakeDivisor     int64    `json:"trustStakeDivisor"`
	PolicyHash            string   `json:"policyHash"`
	Notes                 []string `json:"notes"`
}

type ResourcePriceComponent struct {
	Name      string `json:"name"`
	Quantity  int64  `json:"quantity"`
	Unit      int64  `json:"unit"`
	UnitPrice int64  `json:"unitPrice"`
	Amount    int64  `json:"amount"`
}

type ResourceDelegation struct {
	ID            string    `json:"id"`
	Provider      string    `json:"provider"`
	Beneficiary   string    `json:"beneficiary"`
	AmountYNXT    int64     `json:"amountYnxt"`
	Bandwidth     int64     `json:"bandwidth"`
	Compute       int64     `json:"compute"`
	AICredits     int64     `json:"aiCredits"`
	TrustCredits  int64     `json:"trustCredits"`
	PolicyID      string    `json:"policyId"`
	PolicyVersion string    `json:"policyVersion"`
	PolicyHash    string    `json:"policyHash"`
	Status        string    `json:"status"`
	CreatedAt     time.Time `json:"createdAt"`
}

type Block struct {
	Height       uint64        `json:"height"`
	Hash         string        `json:"hash"`
	ParentHash   string        `json:"parentHash"`
	Time         time.Time     `json:"time"`
	Validator    string        `json:"validator"`
	Transactions []Transaction `json:"transactions"`
}

type Transaction struct {
	Hash             string    `json:"hash"`
	Type             string    `json:"type"`
	From             string    `json:"from,omitempty"`
	To               string    `json:"to,omitempty"`
	Amount           int64     `json:"amount,omitempty"`
	Fee              int64     `json:"fee"`
	Nonce            uint64    `json:"nonce"`
	BlockHash        string    `json:"blockHash,omitempty"`
	BlockNum         uint64    `json:"blockNumber,omitempty"`
	Timestamp        time.Time `json:"timestamp"`
	LotFlows         []LotFlow `json:"lotFlows,omitempty"`
	Logs             []EVMLog  `json:"logs,omitempty"`
	Memo             string    `json:"memo,omitempty"`
	Sponsor          string    `json:"sponsor,omitempty"`
	SponsorPoolID    string    `json:"sponsorPoolId,omitempty"`
	ResourceSource   string    `json:"resourceSource,omitempty"`
	ResourceType     string    `json:"resourceType,omitempty"`
	ResourceConsumed int64     `json:"resourceConsumed,omitempty"`
	ActionReference  string    `json:"actionReference,omitempty"`
}

// SignedTransferInput is an already signature-verified native YNXT transfer.
// Signature decoding stays at the API boundary; state application rechecks all
// deterministic balance, nonce, fee, address, replay, and persistence rules.
type SignedTransferInput struct {
	Hash   string
	From   string
	To     string
	Amount int64
	Fee    int64
	Nonce  uint64
	// EthereumRaw is independently verified at state admission. It is preserved
	// in the existing authenticated Memo field, not mislabeled as a native signature.
	EthereumRaw []byte
}

type EVMLog struct {
	Address          string   `json:"address"`
	Topics           []string `json:"topics"`
	Data             string   `json:"data"`
	BlockHash        string   `json:"blockHash"`
	BlockNumber      uint64   `json:"blockNumber"`
	TransactionHash  string   `json:"transactionHash"`
	TransactionIndex uint64   `json:"transactionIndex"`
	LogIndex         uint64   `json:"logIndex"`
	Removed          bool     `json:"removed"`
}

type EVMLogFilter struct {
	FromBlock *uint64
	ToBlock   *uint64
	Addresses []string
	Topics    [][]string
}

type LotFlow struct {
	LotID  string `json:"lotId"`
	Amount int64  `json:"amount"`
	From   string `json:"from"`
	To     string `json:"to"`
}

type Validator struct {
	Address      string     `json:"address"`
	Moniker      string     `json:"moniker"`
	Host         string     `json:"host,omitempty"`
	Role         string     `json:"role,omitempty"`
	PeerID       string     `json:"peerId,omitempty"`
	VotingPower  int64      `json:"votingPower"`
	Active       bool       `json:"active"`
	PeerReady    bool       `json:"peerReady"`
	PeerStatus   string     `json:"peerStatus,omitempty"`
	LatestHeight uint64     `json:"latestHeight,omitempty"`
	LastSeenAt   *time.Time `json:"lastSeenAt,omitempty"`
	UpdatedAt    *time.Time `json:"updatedAt,omitempty"`
	PeerEvidence string     `json:"peerEvidence,omitempty"`
}

type ValidatorPeerHeartbeatInput struct {
	Address      string `json:"address,omitempty"`
	PeerID       string `json:"peerId,omitempty"`
	Host         string `json:"host,omitempty"`
	Ready        *bool  `json:"ready,omitempty"`
	Status       string `json:"status,omitempty"`
	LatestHeight uint64 `json:"latestHeight,omitempty"`
	Evidence     string `json:"evidence,omitempty"`
}

type ValidatorPeer struct {
	Address      string     `json:"address"`
	PeerID       string     `json:"peerId,omitempty"`
	Host         string     `json:"host,omitempty"`
	P2PAddress   string     `json:"p2pAddress,omitempty"`
	Role         string     `json:"role,omitempty"`
	Expected     bool       `json:"expected"`
	Observed     bool       `json:"observed"`
	Status       string     `json:"status"`
	Source       string     `json:"source"`
	LatestHeight uint64     `json:"latestHeight,omitempty"`
	LastSeenAt   *time.Time `json:"lastSeenAt,omitempty"`
	UpdatedAt    *time.Time `json:"updatedAt,omitempty"`
	Evidence     string     `json:"evidence,omitempty"`
}

type ValidatorPeerObservationInput struct {
	Address      string `json:"address,omitempty"`
	PeerID       string `json:"peerId,omitempty"`
	Host         string `json:"host,omitempty"`
	P2PAddress   string `json:"p2pAddress,omitempty"`
	Status       string `json:"status,omitempty"`
	LatestHeight uint64 `json:"latestHeight,omitempty"`
	Evidence     string `json:"evidence,omitempty"`
}

type ValidatorPeerSync struct {
	ID           string    `json:"id"`
	Source       string    `json:"source"`
	Target       string    `json:"target"`
	SourceHeight uint64    `json:"sourceHeight"`
	TargetHeight uint64    `json:"targetHeight"`
	LagBlocks    int64     `json:"lagBlocks"`
	Status       string    `json:"status"`
	Evidence     string    `json:"evidence,omitempty"`
	CreatedAt    time.Time `json:"createdAt"`
	UpdatedAt    time.Time `json:"updatedAt"`
}

type ValidatorPeerSyncInput struct {
	Source       string `json:"source,omitempty"`
	Target       string `json:"target"`
	SourceHeight uint64 `json:"sourceHeight"`
	TargetHeight uint64 `json:"targetHeight"`
	Status       string `json:"status,omitempty"`
	Evidence     string `json:"evidence,omitempty"`
}

type BuildInfo struct {
	Commit    string `json:"commit"`
	Release   string `json:"release"`
	BuildTime string `json:"buildTime"`
}

type NodeIdentityConfig struct {
	ValidatorAddress  string                    `json:"validatorAddress"`
	PeerSyncTargets   []ValidatorPeerSyncTarget `json:"peerSyncTargets,omitempty"`
	PeerSyncInterval  time.Duration             `json:"-"`
	StaleAfter        time.Duration             `json:"-"`
	BlockProduction   bool                      `json:"blockProductionEnabled"`
	ReplicationMode   string                    `json:"replicationMode,omitempty"`
	ReplicationSource string                    `json:"replicationSource,omitempty"`
	Build             BuildInfo                 `json:"build"`
}

type ValidatorPeerSyncTarget struct {
	Address string `json:"address"`
	URL     string `json:"url,omitempty"`
}

type NodeIdentity struct {
	Configured              bool                       `json:"configured"`
	ValidatorAddress        string                     `json:"validatorAddress,omitempty"`
	ValidatorMoniker        string                     `json:"validatorMoniker,omitempty"`
	ValidatorRole           string                     `json:"validatorRole,omitempty"`
	ValidatorHost           string                     `json:"validatorHost,omitempty"`
	ValidatorPeerID         string                     `json:"validatorPeerId,omitempty"`
	ExpectedValidatorCount  int                        `json:"expectedValidatorCount"`
	PeerSyncTargetCount     int                        `json:"peerSyncTargetCount"`
	PeerSyncTargetAddresses []string                   `json:"peerSyncTargetAddresses,omitempty"`
	PeerSyncInterval        string                     `json:"peerSyncInterval,omitempty"`
	BlockProductionEnabled  bool                       `json:"blockProductionEnabled"`
	ReplicationMode         string                     `json:"replicationMode,omitempty"`
	ReplicationSource       string                     `json:"replicationSource,omitempty"`
	RuntimeEvidence         string                     `json:"runtimeEvidence"`
	Build                   BuildInfo                  `json:"build"`
	PeerSyncFreshness       ValidatorPeerSyncFreshness `json:"peerSyncFreshness"`
	Replication             ReplicationRuntimeStatus   `json:"replication"`
}

type ReplicationRuntimeStatus struct {
	Configured          bool       `json:"configured"`
	Source              string     `json:"source,omitempty"`
	Status              string     `json:"status"`
	CatchingUp          bool       `json:"catchingUp"`
	Fresh               bool       `json:"fresh"`
	LocalHeight         uint64     `json:"localHeight"`
	LocalBlockHash      string     `json:"localBlockHash,omitempty"`
	SourceHeight        uint64     `json:"sourceHeight"`
	SourceBlockHash     string     `json:"sourceBlockHash,omitempty"`
	LagBlocks           int64      `json:"lagBlocks"`
	Attempts            uint64     `json:"attempts"`
	Successes           uint64     `json:"successes"`
	Failures            uint64     `json:"failures"`
	ConsecutiveFailures uint64     `json:"consecutiveFailures"`
	LastAttemptAt       *time.Time `json:"lastAttemptAt,omitempty"`
	LastSuccessAt       *time.Time `json:"lastSuccessAt,omitempty"`
	LastSnapshotAt      *time.Time `json:"lastSnapshotAt,omitempty"`
	LastErrorStage      string     `json:"lastErrorStage,omitempty"`
	LastError           string     `json:"lastError,omitempty"`
}

type ValidatorPeerSyncFreshness struct {
	Status            string                            `json:"status"`
	TargetCount       int                               `json:"targetCount"`
	Synced            int                               `json:"synced"`
	Lagging           int                               `json:"lagging"`
	Missing           int                               `json:"missing"`
	Stale             int                               `json:"stale"`
	Fresh             int                               `json:"fresh"`
	TotalRecords      int                               `json:"totalRecords"`
	StaleAfterSeconds int64                             `json:"staleAfterSeconds"`
	GeneratedAt       time.Time                         `json:"generatedAt"`
	Records           []ValidatorPeerSyncFreshnessEntry `json:"records"`
}

type ValidatorPeerSyncFreshnessEntry struct {
	Target     string     `json:"target"`
	Status     string     `json:"status"`
	LagBlocks  int64      `json:"lagBlocks,omitempty"`
	UpdatedAt  *time.Time `json:"updatedAt,omitempty"`
	AgeSeconds int64      `json:"ageSeconds,omitempty"`
	Fresh      bool       `json:"fresh"`
	Evidence   string     `json:"evidence,omitempty"`
}

type TrustTrace struct {
	Address string          `json:"address"`
	Lots    []TrustTraceLot `json:"lots"`
	Labels  []string        `json:"labels"`
	Summary string          `json:"summary"`
}

type TrustTraceLot struct {
	LotID       string `json:"lotId"`
	Amount      int64  `json:"amount"`
	Origin      string `json:"origin"`
	RiskWeight  int64  `json:"riskWeightBps"`
	LastInbound string `json:"lastInboundTx,omitempty"`
}

type PayIntent struct {
	ID             string    `json:"id"`
	Merchant       string    `json:"merchant"`
	PayoutAddress  string    `json:"payoutAddress,omitempty"`
	Amount         int64     `json:"amount"`
	Currency       string    `json:"currency"`
	Status         string    `json:"status"`
	RefundedAmount int64     `json:"refundedAmount,omitempty"`
	RefundStatus   string    `json:"refundStatus,omitempty"`
	CreatedAt      time.Time `json:"createdAt"`
	CallbackURL    string    `json:"callbackUrl,omitempty"`
	IdempotencyKey string    `json:"idempotencyKey,omitempty"`
}

type Invoice struct {
	ID             string    `json:"id"`
	IntentID       string    `json:"intentId"`
	Merchant       string    `json:"merchant"`
	PayoutAddress  string    `json:"payoutAddress,omitempty"`
	Amount         int64     `json:"amount"`
	Currency       string    `json:"currency"`
	Status         string    `json:"status"`
	RefundedAmount int64     `json:"refundedAmount,omitempty"`
	RefundStatus   string    `json:"refundStatus,omitempty"`
	DueAt          time.Time `json:"dueAt"`
	CreatedAt      time.Time `json:"createdAt"`
	PaymentLink    string    `json:"paymentLink,omitempty"`
	IdempotencyKey string    `json:"idempotencyKey,omitempty"`
}

type PaySettlement struct {
	ID              string    `json:"id"`
	IntentID        string    `json:"intentId"`
	InvoiceID       string    `json:"invoiceId"`
	Merchant        string    `json:"merchant"`
	PayoutAddress   string    `json:"payoutAddress"`
	Payer           string    `json:"payer"`
	Amount          int64     `json:"amount"`
	Currency        string    `json:"currency"`
	TransactionHash string    `json:"transactionHash"`
	BlockNumber     uint64    `json:"blockNumber"`
	Status          string    `json:"status"`
	IdempotencyKey  string    `json:"idempotencyKey"`
	AuditHash       string    `json:"auditHash"`
	CreatedAt       time.Time `json:"createdAt"`
}

type RefundRecord struct {
	ID                       string     `json:"id"`
	IntentID                 string     `json:"intentId"`
	InvoiceID                string     `json:"invoiceId,omitempty"`
	SettlementID             string     `json:"settlementId,omitempty"`
	Merchant                 string     `json:"merchant,omitempty"`
	PayoutAddress            string     `json:"payoutAddress,omitempty"`
	Payer                    string     `json:"payer,omitempty"`
	Amount                   int64      `json:"amount"`
	Currency                 string     `json:"currency"`
	Reason                   string     `json:"reason,omitempty"`
	Status                   string     `json:"status"`
	TransactionHash          string     `json:"transactionHash,omitempty"`
	BlockNumber              uint64     `json:"blockNumber,omitempty"`
	CreatedAt                time.Time  `json:"createdAt"`
	CompletedAt              *time.Time `json:"completedAt,omitempty"`
	IdempotencyKey           string     `json:"idempotencyKey,omitempty"`
	CompletionIdempotencyKey string     `json:"completionIdempotencyKey,omitempty"`
	AuditHash                string     `json:"auditHash,omitempty"`
}

type WebhookSignature struct {
	EventID        string    `json:"eventId"`
	IntentID       string    `json:"intentId"`
	EventType      string    `json:"eventType"`
	Signature      string    `json:"signature"`
	PayloadHash    string    `json:"payloadHash"`
	SignedAt       time.Time `json:"signedAt"`
	Algorithm      string    `json:"algorithm"`
	IdempotencyKey string    `json:"idempotencyKey,omitempty"`
	ReplaySafe     bool      `json:"replaySafe"`
}

type PayEvent struct {
	ID              string    `json:"id"`
	Type            string    `json:"type"`
	IntentID        string    `json:"intentId,omitempty"`
	InvoiceID       string    `json:"invoiceId,omitempty"`
	SettlementID    string    `json:"settlementId,omitempty"`
	ObjectID        string    `json:"objectId,omitempty"`
	Merchant        string    `json:"merchant,omitempty"`
	PayoutAddress   string    `json:"payoutAddress,omitempty"`
	Payer           string    `json:"payer,omitempty"`
	TransactionHash string    `json:"transactionHash,omitempty"`
	Amount          int64     `json:"amount,omitempty"`
	Currency        string    `json:"currency,omitempty"`
	IdempotencyKey  string    `json:"idempotencyKey,omitempty"`
	AuditHash       string    `json:"auditHash"`
	CreatedAt       time.Time `json:"createdAt"`
}

type RiskLabel struct {
	ID                               string     `json:"labelId"`
	Subject                          string     `json:"subject"`
	SubjectType                      string     `json:"subjectType"`
	Address                          string     `json:"address"`
	Label                            string     `json:"label"`
	LabelType                        string     `json:"labelType"`
	Severity                         string     `json:"severity"`
	RiskWeightBps                    int64      `json:"riskWeightBps"`
	ConfidenceBps                    int64      `json:"confidenceBps"`
	Source                           string     `json:"source"`
	EvidenceHash                     string     `json:"evidenceHash"`
	CreatedAt                        time.Time  `json:"createdAt"`
	UpdatedAt                        time.Time  `json:"updatedAt"`
	ExpiresAt                        *time.Time `json:"expiresAt,omitempty"`
	ReviewRequired                   bool       `json:"reviewRequired"`
	AppealAvailable                  bool       `json:"appealAvailable"`
	DisputeStatus                    string     `json:"disputeStatus"`
	LegalStatusUnderYNXChainLaw      string     `json:"legalStatusUnderYnxChainLaw"`
	RejectedExternalRequestReference string     `json:"rejectedExternalRequestReference,omitempty"`
	AssetEffect                      string     `json:"assetEffect"`
}

type RiskLabelInput struct {
	Subject                          string `json:"subject"`
	SubjectType                      string `json:"subjectType"`
	Address                          string `json:"address"`
	Label                            string `json:"label"`
	LabelType                        string `json:"labelType"`
	Severity                         string `json:"severity"`
	RiskWeightBps                    int64  `json:"riskWeightBps"`
	ConfidenceBps                    int64  `json:"confidenceBps"`
	Source                           string `json:"source"`
	EvidenceHash                     string `json:"evidenceHash"`
	ExpiryHours                      int64  `json:"expiryHours"`
	ReviewRequired                   bool   `json:"reviewRequired"`
	AppealAvailable                  *bool  `json:"appealAvailable"`
	DisputeStatus                    string `json:"disputeStatus"`
	LegalStatusUnderYNXChainLaw      string `json:"legalStatusUnderYnxChainLaw"`
	RejectedExternalRequestReference string `json:"rejectedExternalRequestReference"`
	AssetEffect                      string `json:"assetEffect"`
}

type EvidencePacket struct {
	ID          string           `json:"id"`
	Subject     string           `json:"subject"`
	Trace       TrustTrace       `json:"trace"`
	Labels      []RiskLabel      `json:"riskLabels"`
	RiskSummary TrustRiskSummary `json:"riskSummary"`
	RelatedTxs  []Transaction    `json:"relatedTransactions"`
	JSONHash    string           `json:"jsonHash"`
	GeneratedAt time.Time        `json:"generatedAt"`
	ExportNotes []string         `json:"exportNotes"`
}

type TrustRiskSummary struct {
	Subject                   string    `json:"subject"`
	EffectiveRiskWeightBps    int64     `json:"effectiveRiskWeightBps"`
	HighestLabelRiskWeightBps int64     `json:"highestLabelRiskWeightBps"`
	HighestConfidenceBps      int64     `json:"highestConfidenceBps"`
	ActiveLabelCount          int       `json:"activeLabelCount"`
	ExpiredLabelCount         int       `json:"expiredLabelCount"`
	LowConfidenceLabelCount   int       `json:"lowConfidenceLabelCount"`
	CorrectionLabelCount      int       `json:"correctionLabelCount"`
	HasOpenReview             bool      `json:"hasOpenReview"`
	AppealPath                string    `json:"appealPath"`
	AssetEffect               string    `json:"assetEffect"`
	Conclusion                string    `json:"conclusion"`
	GeneratedAt               time.Time `json:"generatedAt"`
	ReviewerNotes             []string  `json:"reviewerNotes"`
	NonConclusiveLabelIDs     []string  `json:"nonConclusiveLabelIds,omitempty"`
	ExpiredLabelIDs           []string  `json:"expiredLabelIds,omitempty"`
	ActiveEvidenceHashes      []string  `json:"activeEvidenceHashes,omitempty"`
}

type RequestValidityStatus string

const (
	RequestValidUnderYNXChainLaw RequestValidityStatus = "VALID_UNDER_YNX_CHAIN_LAW"
	RequestInsufficientEvidence  RequestValidityStatus = "INSUFFICIENT_EVIDENCE"
	RequestOutOfScope            RequestValidityStatus = "OUT_OF_SCOPE"
	RequestOverbroad             RequestValidityStatus = "OVERBROAD"
	RequestIllegalOrAbusive      RequestValidityStatus = "ILLEGAL_OR_ABUSIVE"
	RequestRequiresReview        RequestValidityStatus = "REQUIRES_GOVERNANCE_REVIEW"
	RequestRequiresUserNotice    RequestValidityStatus = "REQUIRES_USER_NOTICE"
	RequestRejected              RequestValidityStatus = "REJECTED"
)

type RequestValidityRule struct {
	ID                 string                `json:"id"`
	Name               string                `json:"name"`
	Classification     RequestValidityStatus `json:"classification"`
	Description        string                `json:"description"`
	RequiresEvidence   bool                  `json:"requiresEvidence"`
	RequiresUserNotice bool                  `json:"requiresUserNotice"`
	Keywords           []string              `json:"keywords,omitempty"`
}

type GovernanceRequest struct {
	ID                  string                `json:"id"`
	Requester           string                `json:"requester"`
	Subject             string                `json:"subject"`
	Action              string                `json:"action"`
	AssetType           string                `json:"assetType"`
	Scope               string                `json:"scope"`
	Description         string                `json:"description"`
	Evidence            []string              `json:"evidence"`
	Classification      RequestValidityStatus `json:"classification"`
	Status              string                `json:"status"`
	Reasons             []string              `json:"reasons"`
	RuleIDs             []string              `json:"ruleIds"`
	RequiresAppeal      bool                  `json:"requiresAppeal"`
	RequiresUserNotice  bool                  `json:"requiresUserNotice"`
	NativeYNXTProtected bool                  `json:"nativeYnxtProtected"`
	CreatedAt           time.Time             `json:"createdAt"`
	ReviewedAt          *time.Time            `json:"reviewedAt,omitempty"`
	RejectedAt          *time.Time            `json:"rejectedAt,omitempty"`
	TransparencyEntryID string                `json:"transparencyEntryId,omitempty"`
}

type GovernanceRequestInput struct {
	Requester   string   `json:"requester"`
	Subject     string   `json:"subject"`
	Action      string   `json:"action"`
	AssetType   string   `json:"assetType"`
	Scope       string   `json:"scope"`
	Description string   `json:"description"`
	Evidence    []string `json:"evidence"`
}

type TrustAppeal struct {
	ID                  string    `json:"id"`
	RequestID           string    `json:"requestId,omitempty"`
	LabelID             string    `json:"labelId,omitempty"`
	Subject             string    `json:"subject"`
	Appellant           string    `json:"appellant"`
	Claimant            string    `json:"claimant"`
	Reason              string    `json:"reason"`
	Evidence            []string  `json:"evidence"`
	Status              string    `json:"status"`
	Reviewer            string    `json:"reviewer,omitempty"`
	Decision            string    `json:"decision,omitempty"`
	CreatedAt           time.Time `json:"createdAt"`
	UpdatedAt           time.Time `json:"updatedAt"`
	ResolutionReason    string    `json:"resolutionReason,omitempty"`
	TransparencyEntryID string    `json:"transparencyEntryId"`
}

type TrustAppealInput struct {
	RequestID string   `json:"requestId"`
	LabelID   string   `json:"labelId"`
	Subject   string   `json:"subject"`
	Appellant string   `json:"appellant"`
	Claimant  string   `json:"claimant"`
	Reason    string   `json:"reason"`
	Evidence  []string `json:"evidence"`
}

type TrustAppealDecisionInput struct {
	Reviewer         string `json:"reviewer"`
	Decision         string `json:"decision"`
	ResolutionReason string `json:"resolutionReason"`
}

type TrackingPolicyReview struct {
	ID                  string                `json:"id"`
	Requester           string                `json:"requester"`
	Subject             string                `json:"subject"`
	Purpose             string                `json:"purpose"`
	QueryType           string                `json:"queryType"`
	Scope               string                `json:"scope"`
	Description         string                `json:"description"`
	Evidence            []string              `json:"evidence"`
	Institutional       bool                  `json:"institutional"`
	Sensitive           bool                  `json:"sensitive"`
	MinimumNecessary    bool                  `json:"minimumNecessary"`
	Classification      RequestValidityStatus `json:"classification"`
	Status              string                `json:"status"`
	Reasons             []string              `json:"reasons"`
	RuleIDs             []string              `json:"ruleIds"`
	ConfidenceBps       int64                 `json:"confidenceBps"`
	LabelExpiresAt      *time.Time            `json:"labelExpiresAt,omitempty"`
	AppealPath          string                `json:"appealPath"`
	CreatedAt           time.Time             `json:"createdAt"`
	TransparencyEntryID string                `json:"transparencyEntryId"`
}

type TrackingPolicyReviewInput struct {
	Requester        string   `json:"requester"`
	Subject          string   `json:"subject"`
	Purpose          string   `json:"purpose"`
	QueryType        string   `json:"queryType"`
	Scope            string   `json:"scope"`
	Description      string   `json:"description"`
	Evidence         []string `json:"evidence"`
	Institutional    bool     `json:"institutional"`
	Sensitive        bool     `json:"sensitive"`
	MinimumNecessary bool     `json:"minimumNecessary"`
	ConfidenceBps    int64    `json:"confidenceBps"`
	ExpiryHours      int64    `json:"expiryHours"`
}

type AIPermissionGrant struct {
	ID        string    `json:"id"`
	SessionID string    `json:"sessionId"`
	Requester string    `json:"requester"`
	Scope     string    `json:"scope"`
	Purpose   string    `json:"purpose"`
	Status    string    `json:"status"`
	CreatedAt time.Time `json:"createdAt"`
	ExpiresAt time.Time `json:"expiresAt"`
	AuditHash string    `json:"auditHash"`
}

type AIPermissionInput struct {
	SessionID   string `json:"sessionId"`
	Requester   string `json:"requester"`
	Scope       string `json:"scope"`
	Purpose     string `json:"purpose"`
	ExpiryHours int64  `json:"expiryHours"`
}

type AIActionProposal struct {
	ID                  string     `json:"id"`
	SessionID           string     `json:"sessionId"`
	Requester           string     `json:"requester"`
	Scope               string     `json:"scope"`
	ActionType          string     `json:"actionType"`
	Description         string     `json:"description"`
	PermissionID        string     `json:"permissionId,omitempty"`
	Status              string     `json:"status"`
	Executable          bool       `json:"executable"`
	Sensitive           bool       `json:"sensitive"`
	RequiresApproval    bool       `json:"requiresApproval"`
	Reasons             []string   `json:"reasons"`
	CreatedAt           time.Time  `json:"createdAt"`
	ExpiresAt           time.Time  `json:"expiresAt"`
	ApprovedAt          *time.Time `json:"approvedAt,omitempty"`
	ApprovedBy          string     `json:"approvedBy,omitempty"`
	RejectedAt          *time.Time `json:"rejectedAt,omitempty"`
	RejectedBy          string     `json:"rejectedBy,omitempty"`
	AuditHash           string     `json:"auditHash"`
	TransparencyEntryID string     `json:"transparencyEntryId,omitempty"`
}

type AIActionProposalInput struct {
	SessionID   string `json:"sessionId"`
	Requester   string `json:"requester"`
	Scope       string `json:"scope"`
	ActionType  string `json:"actionType"`
	Description string `json:"description"`
	ExpiryHours int64  `json:"expiryHours"`
}

type AIActionApprovalInput struct {
	Approver     string `json:"approver"`
	PermissionID string `json:"permissionId"`
}

type TransparencyEntry struct {
	ID             string                `json:"id"`
	Type           string                `json:"type"`
	RequestID      string                `json:"requestId,omitempty"`
	AppealID       string                `json:"appealId,omitempty"`
	Subject        string                `json:"subject,omitempty"`
	Action         string                `json:"action,omitempty"`
	Classification RequestValidityStatus `json:"classification,omitempty"`
	Status         string                `json:"status"`
	Reasons        []string              `json:"reasons"`
	CreatedAt      time.Time             `json:"createdAt"`
}

type TransparencyReport struct {
	Network        NetworkConfig       `json:"network"`
	GeneratedAt    time.Time           `json:"generatedAt"`
	EntryCount     int                 `json:"entryCount"`
	RejectedCount  int                 `json:"rejectedCount"`
	AppealCount    int                 `json:"appealCount"`
	ReviewCount    int                 `json:"reviewCount"`
	TruthfulStatus string              `json:"truthfulStatus"`
	Entries        []TransparencyEntry `json:"entries"`
}

type ResourceQuote struct {
	ID               string                   `json:"id"`
	Address          string                   `json:"address"`
	Bandwidth        int64                    `json:"bandwidth"`
	Compute          int64                    `json:"compute"`
	AICredits        int64                    `json:"aiCredits"`
	TrustCredits     int64                    `json:"trustCredits"`
	PriceYNXT        int64                    `json:"priceYnxt"`
	PolicyID         string                   `json:"policyId"`
	PolicyVersion    string                   `json:"policyVersion"`
	PolicyHash       string                   `json:"policyHash"`
	GovernanceStatus string                   `json:"governanceStatus"`
	PricingBreakdown []ResourcePriceComponent `json:"pricingBreakdown"`
	ExpiresAt        time.Time                `json:"expiresAt"`
	TruthfulNotes    []string                 `json:"truthfulNotes"`
}

type ResourceRental struct {
	ID                 string    `json:"id"`
	QuoteID            string    `json:"quoteId"`
	Address            string    `json:"address"`
	Provider           string    `json:"provider"`
	PriceYNXT          int64     `json:"priceYnxt"`
	ProviderIncomeYNXT int64     `json:"providerIncomeYnxt"`
	ProtocolFeeYNXT    int64     `json:"protocolFeeYnxt"`
	PolicyID           string    `json:"policyId"`
	PolicyVersion      string    `json:"policyVersion"`
	PolicyHash         string    `json:"policyHash"`
	GovernanceStatus   string    `json:"governanceStatus"`
	Status             string    `json:"status"`
	CreatedAt          time.Time `json:"createdAt"`
	Bandwidth          int64     `json:"bandwidth"`
	Compute            int64     `json:"compute"`
	AICredits          int64     `json:"aiCredits"`
	TrustCredits       int64     `json:"trustCredits"`
}

type ResourceIncomeRecord struct {
	ID            string    `json:"id"`
	Provider      string    `json:"provider"`
	RentalID      string    `json:"rentalId"`
	Source        string    `json:"source"`
	Amount        int64     `json:"amount"`
	Currency      string    `json:"currency"`
	PolicyID      string    `json:"policyId"`
	PolicyVersion string    `json:"policyVersion"`
	PolicyHash    string    `json:"policyHash"`
	CreatedAt     time.Time `json:"createdAt"`
}

type ResourceAnalytics struct {
	Network                   NetworkConfig        `json:"network"`
	ActiveDelegationCount     int                  `json:"activeDelegationCount"`
	ResourceRentalCount       int                  `json:"resourceRentalCount"`
	ResourceIncomeRecordCount int                  `json:"resourceIncomeRecordCount"`
	DelegatedYNXT             int64                `json:"delegatedYnxt"`
	RentalVolumeYNXT          int64                `json:"rentalVolumeYnxt"`
	ProviderIncomeYNXT        int64                `json:"providerIncomeYnxt"`
	ProtocolFeeYNXT           int64                `json:"protocolFeeYnxt"`
	MerchantPoolCount         int                  `json:"merchantPoolCount"`
	DAppPoolCount             int                  `json:"dappPoolCount"`
	ActiveSponsorPoolCount    int                  `json:"activeSponsorPoolCount"`
	SponsorshipCount          int                  `json:"sponsorshipCount"`
	SponsoredResources        ResourceUnits        `json:"sponsoredResources"`
	Policy                    ResourceMarketPolicy `json:"policy"`
	PolicyID                  string               `json:"policyId"`
	PolicyVersion             string               `json:"policyVersion"`
	PolicyHash                string               `json:"policyHash"`
	GovernanceStatus          string               `json:"governanceStatus"`
	TruthfulStatus            string               `json:"truthfulStatus"`
}

type ResourceUnits struct {
	Bandwidth    int64 `json:"bandwidth"`
	Compute      int64 `json:"compute"`
	AICredits    int64 `json:"aiCredits"`
	TrustCredits int64 `json:"trustCredits"`
}

type ResourceAuthorization struct {
	Version     int    `json:"version"`
	ChainID     int64  `json:"chainId"`
	Action      string `json:"action"`
	Signer      string `json:"signer"`
	Nonce       uint64 `json:"nonce"`
	PayloadHash string `json:"payloadHash"`
	PublicKey   string `json:"publicKey"`
	Signature   string `json:"signature"`
}

type ResourcePool struct {
	ID                   string        `json:"id"`
	PoolType             string        `json:"poolType"`
	Name                 string        `json:"name"`
	Owner                string        `json:"owner"`
	Public               bool          `json:"public"`
	AllowedBeneficiaries []string      `json:"allowedBeneficiaries,omitempty"`
	AllowedScopes        []string      `json:"allowedScopes"`
	AllowedResourceTypes []string      `json:"allowedResourceTypes"`
	PerActionLimit       ResourceUnits `json:"perActionLimit"`
	CumulativeAllowance  ResourceUnits `json:"cumulativeAllowance"`
	Consumed             ResourceUnits `json:"consumed"`
	ExpiresAt            time.Time     `json:"expiresAt"`
	Status               string        `json:"status"`
	PolicyHash           string        `json:"policyHash"`
	CreatedAt            time.Time     `json:"createdAt"`
	UpdatedAt            time.Time     `json:"updatedAt"`
}

type ResourcePoolCreateInput struct {
	PoolType             string                `json:"poolType"`
	Name                 string                `json:"name"`
	Public               bool                  `json:"public"`
	AllowedBeneficiaries []string              `json:"allowedBeneficiaries,omitempty"`
	AllowedScopes        []string              `json:"allowedScopes"`
	AllowedResourceTypes []string              `json:"allowedResourceTypes"`
	PerActionLimit       ResourceUnits         `json:"perActionLimit"`
	CumulativeAllowance  ResourceUnits         `json:"cumulativeAllowance"`
	ExpiresAt            time.Time             `json:"expiresAt"`
	IdempotencyKey       string                `json:"idempotencyKey"`
	Authorization        ResourceAuthorization `json:"authorization"`
}

type ResourcePoolFundInput struct {
	PoolID             string                `json:"poolId"`
	Additional         ResourceUnits         `json:"additional"`
	ExpectedPolicyHash string                `json:"expectedPolicyHash"`
	IdempotencyKey     string                `json:"idempotencyKey"`
	Authorization      ResourceAuthorization `json:"authorization"`
}

type ResourcePoolPolicyInput struct {
	PoolID               string                `json:"poolId"`
	Public               bool                  `json:"public"`
	AllowedBeneficiaries []string              `json:"allowedBeneficiaries,omitempty"`
	AllowedScopes        []string              `json:"allowedScopes"`
	AllowedResourceTypes []string              `json:"allowedResourceTypes"`
	PerActionLimit       ResourceUnits         `json:"perActionLimit"`
	ExpiresAt            time.Time             `json:"expiresAt"`
	ExpectedPolicyHash   string                `json:"expectedPolicyHash"`
	IdempotencyKey       string                `json:"idempotencyKey"`
	Authorization        ResourceAuthorization `json:"authorization"`
}

type ResourcePoolStatusInput struct {
	PoolID             string                `json:"poolId"`
	Status             string                `json:"status"`
	ExpectedPolicyHash string                `json:"expectedPolicyHash"`
	IdempotencyKey     string                `json:"idempotencyKey"`
	Authorization      ResourceAuthorization `json:"authorization"`
}

type ResourceSponsorshipInput struct {
	PoolID          string                `json:"poolId,omitempty"`
	Beneficiary     string                `json:"beneficiary"`
	Scope           string                `json:"scope"`
	ResourceType    string                `json:"resourceType"`
	Amount          int64                 `json:"amount"`
	ActionReference string                `json:"actionReference"`
	IdempotencyKey  string                `json:"idempotencyKey"`
	Authorization   ResourceAuthorization `json:"authorization"`
}

type ResourceSponsorship struct {
	ID              string    `json:"id"`
	PoolID          string    `json:"poolId"`
	PoolType        string    `json:"poolType"`
	Payer           string    `json:"payer"`
	Sponsor         string    `json:"sponsor"`
	Beneficiary     string    `json:"beneficiary"`
	Scope           string    `json:"scope"`
	ResourceType    string    `json:"resourceType"`
	ResourceSource  string    `json:"resourceSource"`
	Amount          int64     `json:"amount"`
	PolicyHash      string    `json:"policyHash"`
	ActionReference string    `json:"actionReference"`
	IdempotencyKey  string    `json:"idempotencyKey"`
	TransactionHash string    `json:"transactionHash"`
	CreatedAt       time.Time `json:"createdAt"`
}

type ResourceSponsorIdempotency struct {
	ID              string        `json:"id"`
	Signer          string        `json:"signer"`
	Key             string        `json:"key"`
	Action          string        `json:"action"`
	RequestHash     string        `json:"requestHash"`
	ObjectType      string        `json:"objectType"`
	ObjectID        string        `json:"objectId"`
	TransactionHash string        `json:"transactionHash,omitempty"`
	PoolSnapshot    *ResourcePool `json:"poolSnapshot,omitempty"`
}

type ResourceSponsorAuditEvent struct {
	ID           string    `json:"id"`
	Sequence     uint64    `json:"sequence"`
	Action       string    `json:"action"`
	Signer       string    `json:"signer"`
	PoolID       string    `json:"poolId,omitempty"`
	ObjectID     string    `json:"objectId"`
	RequestHash  string    `json:"requestHash"`
	PreviousHash string    `json:"previousHash,omitempty"`
	AuditHash    string    `json:"auditHash"`
	CreatedAt    time.Time `json:"createdAt"`
}

type ContractArtifact struct {
	Address                          string                    `json:"address"`
	Name                             string                    `json:"name"`
	Deployer                         string                    `json:"deployer"`
	SourceHash                       string                    `json:"sourceHash"`
	BytecodeHash                     string                    `json:"bytecodeHash"`
	DeployedBytecodeHash             string                    `json:"deployedBytecodeHash"`
	ArtifactHash                     string                    `json:"artifactHash"`
	ArtifactKind                     string                    `json:"artifactKind"`
	CompilerMode                     string                    `json:"compilerMode"`
	CompilerConfigHash               string                    `json:"compilerConfigHash"`
	Compiler                         ContractCompilerConfig    `json:"compiler"`
	CompilerArtifact                 *ContractCompilerArtifact `json:"compilerArtifact,omitempty"`
	CompilerExecutionStatus          string                    `json:"compilerExecutionStatus"`
	RuntimeMode                      string                    `json:"runtimeMode"`
	VerifierMode                     string                    `json:"verifierMode"`
	ReproducibleBuild                bool                      `json:"reproducibleBuild"`
	ReproducibilityStatus            string                    `json:"reproducibilityStatus"`
	DeployedBytecodeComparisonStatus string                    `json:"deployedBytecodeComparisonStatus"`
	ConstructorArgs                  []string                  `json:"constructorArgs,omitempty"`
	RuntimeStorage                   map[string]string         `json:"runtimeStorage,omitempty"`
	RuntimeStorageSlots              map[string]int            `json:"runtimeStorageSlots,omitempty"`
	ABI                              []ContractABIEntry        `json:"abi,omitempty"`
	Events                           []ContractEventABI        `json:"events,omitempty"`
	Functions                        []ContractFunctionABI     `json:"functions,omitempty"`
	Limitations                      []string                  `json:"limitations,omitempty"`
	Verified                         bool                      `json:"verified"`
	VerifierStatus                   string                    `json:"verifierStatus"`
	DeployedAt                       time.Time                 `json:"deployedAt"`
	VerifiedAt                       *time.Time                `json:"verifiedAt,omitempty"`
}

type ContractCompilerConfig struct {
	ID                        string   `json:"id"`
	Language                  string   `json:"language"`
	Version                   string   `json:"version"`
	Package                   string   `json:"package"`
	ConfigPath                string   `json:"configPath"`
	Source                    string   `json:"source"`
	PreferWasm                bool     `json:"preferWasm"`
	OptimizerEnabled          bool     `json:"optimizerEnabled"`
	OptimizerRuns             int      `json:"optimizerRuns"`
	Pinned                    bool     `json:"pinned"`
	ConfigHash                string   `json:"configHash"`
	ArtifactKind              string   `json:"artifactKind"`
	CompilerMode              string   `json:"compilerMode"`
	VerifierMode              string   `json:"verifierMode"`
	ProductionCompilerEnabled bool     `json:"productionCompilerEnabled"`
	ReproducibilityStatus     string   `json:"reproducibilityStatus"`
	Limitations               []string `json:"limitations,omitempty"`
}

type ContractCompilerArtifact struct {
	SourceName                      string                `json:"sourceName"`
	ContractName                    string                `json:"contractName"`
	BuildInfoID                     string                `json:"buildInfoId"`
	ArtifactPath                    string                `json:"artifactPath"`
	BytecodeHash                    string                `json:"bytecodeHash"`
	DeployedBytecodeHash            string                `json:"deployedBytecodeHash"`
	ABIHash                         string                `json:"abiHash"`
	RuntimeSelectorMode             string                `json:"runtimeSelectorMode"`
	RuntimeSelectors                []string              `json:"runtimeSelectors,omitempty"`
	DeployedBytecodeSelectorMatches int                   `json:"deployedBytecodeSelectorMatches"`
	ABIFunctions                    []ContractFunctionABI `json:"abiFunctions,omitempty"`
	ABIEvents                       []ContractEventABI    `json:"abiEvents,omitempty"`
	CompilerExecuted                bool                  `json:"compilerExecuted"`
	Status                          string                `json:"status"`
}

type ContractVerificationEvidence struct {
	Address                          string                    `json:"address"`
	Name                             string                    `json:"name"`
	Verified                         bool                      `json:"verified"`
	VerifierStatus                   string                    `json:"verifierStatus"`
	ArtifactKind                     string                    `json:"artifactKind"`
	SourceHash                       string                    `json:"sourceHash"`
	BytecodeHash                     string                    `json:"bytecodeHash"`
	DeployedBytecodeHash             string                    `json:"deployedBytecodeHash"`
	ArtifactHash                     string                    `json:"artifactHash"`
	CompilerConfigHash               string                    `json:"compilerConfigHash"`
	Compiler                         ContractCompilerConfig    `json:"compiler"`
	CompilerArtifact                 *ContractCompilerArtifact `json:"compilerArtifact,omitempty"`
	CompilerExecutionStatus          string                    `json:"compilerExecutionStatus"`
	VerifierMode                     string                    `json:"verifierMode"`
	ReproducibleBuild                bool                      `json:"reproducibleBuild"`
	ReproducibilityStatus            string                    `json:"reproducibilityStatus"`
	DeployedBytecodeComparisonStatus string                    `json:"deployedBytecodeComparisonStatus"`
	LocalServiceStatus               string                    `json:"localServiceStatus"`
	RemotePublicProofStatus          string                    `json:"remotePublicProofStatus"`
	Limitations                      []string                  `json:"limitations,omitempty"`
	GeneratedAt                      time.Time                 `json:"generatedAt"`
}

type ContractABIEntry struct {
	Type            string               `json:"type"`
	Name            string               `json:"name"`
	Signature       string               `json:"signature"`
	Topic           string               `json:"topic,omitempty"`
	Selector        string               `json:"selector,omitempty"`
	Inputs          []ContractEventInput `json:"inputs,omitempty"`
	Outputs         []string             `json:"outputs,omitempty"`
	StateMutability string               `json:"stateMutability,omitempty"`
}

type ContractEventABI struct {
	Name      string               `json:"name"`
	Signature string               `json:"signature"`
	Topic     string               `json:"topic"`
	Inputs    []ContractEventInput `json:"inputs"`
	Source    string               `json:"source"`
}

type ContractEventInput struct {
	Name    string `json:"name"`
	Type    string `json:"type"`
	Indexed bool   `json:"indexed"`
}

type ContractFunctionABI struct {
	Name                    string               `json:"name"`
	Signature               string               `json:"signature"`
	Selector                string               `json:"selector"`
	SelectorSource          string               `json:"selectorSource,omitempty"`
	BytecodeSelectorMatched bool                 `json:"bytecodeSelectorMatched,omitempty"`
	Inputs                  []ContractEventInput `json:"inputs,omitempty"`
	Outputs                 []string             `json:"outputs,omitempty"`
	StateMutability         string               `json:"stateMutability"`
	ReturnValue             string               `json:"returnValue,omitempty"`
}

type ContractCallResult struct {
	Address                 string         `json:"address"`
	Function                string         `json:"function"`
	Signature               string         `json:"signature"`
	Selector                string         `json:"selector"`
	ReturnValue             string         `json:"returnValue"`
	EncodedResult           string         `json:"encodedResult"`
	RuntimeMode             string         `json:"runtimeMode"`
	ArtifactKind            string         `json:"artifactKind"`
	ExecutionStatus         string         `json:"executionStatus"`
	ExecutionEngine         string         `json:"executionEngine,omitempty"`
	OpcodeStepCount         int            `json:"opcodeStepCount,omitempty"`
	TransactionHash         string         `json:"transactionHash,omitempty"`
	StateTransition         string         `json:"stateTransition,omitempty"`
	StorageWrites           []StorageWrite `json:"storageWrites,omitempty"`
	ExecutionLogs           []ExecutionLog `json:"executionLogs,omitempty"`
	LogCount                int            `json:"logCount,omitempty"`
	BytecodeSelectorMatched bool           `json:"bytecodeSelectorMatched"`
	Limitations             []string       `json:"limitations,omitempty"`
}

type ExecutionLog struct {
	Opcode  string   `json:"opcode"`
	Address string   `json:"address"`
	Topics  []string `json:"topics"`
	Data    string   `json:"data"`
}

type StorageWrite struct {
	Opcode        string `json:"opcode"`
	Slot          string `json:"slot"`
	PreviousValue string `json:"previousValue"`
	NewValue      string `json:"newValue"`
}
