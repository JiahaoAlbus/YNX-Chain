import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {generateKeyPairSync,randomBytes,sign} from 'node:crypto';
import {spawnSync,spawn} from 'node:child_process';
import {canonical,parseDocument,sha,payload,draftLease,signingBytes,issueLease,verifyLease,policy} from '../../../../scripts/ops/finance-lease-v2/lease.mjs';
import {verifierDigest,run} from '../../../../scripts/ops/finance-lease-v2/cli.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
const executor=path.join(here,'executor.py');
const python=process.env.FINANCE_FIXTURE_PYTHON??'/usr/bin/python3';
const P={lease:'/opt/ynx/leases/finance-v2',env:'/etc/ynx/finance.env',unit:'/etc/systemd/system/ynx-finance.service',caddy:'/etc/caddy/Caddyfile',trust:'/etc/ynx/finance-release-trust-v2.json',state:'/var/lib/ynx/finance/state.json',current:'/opt/ynx/finance-current',control:'/var/lib/ynx-finance-release-control-v2'};
const iso=x=>new Date(x).toISOString();
function fixture(t){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'finance-lease-fixture-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const p=x=>path.join(dir,x);const put=(x,b,mode=0o600)=>{fs.mkdirSync(path.dirname(p(x)),{recursive:true});fs.writeFileSync(p(x),b,{mode});fs.chmodSync(p(x),mode);};
 const json=(x,j)=>put(x,JSON.stringify(j));const get=x=>JSON.parse(fs.readFileSync(p(x),'utf8'));
 put('/FIXTURE_ONLY','test only');
 const {privateKey,publicKey}=generateKeyPairSync('ed25519');const now=Date.now();
 const root={schema:'ynx-finance-release-trust/v2',mode:'fixture',rootVersion:1,maxLeaseSeconds:300,keys:[{keyId:'fixture-key-01',algorithm:'Ed25519',publicKey:publicKey.export({format:'jwk'}).x,notBefore:iso(now-86400000),notAfter:iso(now+86400000),revoked:false}]};json(P.trust,root);
 put('/private-test-key.pem',privateKey.export({format:'pem',type:'pkcs8'}));
 const host={host:'fixture.invalid',machineIdSha256:sha('fixture-machine'),sshHostFingerprint:'SHA256:'+Buffer.from(sha('fixture-host-key'),'hex').toString('base64').replace(/=+$/,''),service:'ynx-finance.service'};json('/host.json',host);json('/service.json',{active:true,pid:101,nextPID:101,nrestarts:0});
 const old='/opt/ynx/releases/finance/fixture-old-01';const dest='/opt/ynx/releases/finance-v2/fixture-new-01';
 const env=web=>['YNX_CHAIN_ENV=testnet','FINANCE_TRADING_ENV=sandbox','FINANCE_TRADING_ENABLED=false','FINANCE_LIVE_ENABLED=false','FINANCE_SANDBOX_WRITES_ENABLED=false','YNX_FINANCE_WEB_DIR='+web+'/web','FIXTURE_NON_SECRET=not-a-credential',''].join('\n');
 put(P.env,env(old));put(P.unit,'[Service]\nExecStart=/opt/ynx/finance-current/ynx-finance\n');put(P.caddy,'finance.ynxweb4.com { respond "fixture maintenance" 503 }\n');put(P.state,'{"fixture":true,"records":[1,2,3]}');
 const oldFiles={'ynx-finance':Buffer.from('fixture old binary, never executed'),'web/index.html':Buffer.from('fixture old page')};
 const newFiles={'ynx-finance':Buffer.from('fixture candidate binary, never executed'),'web/index.html':Buffer.from('fixture candidate page')};
 for(const [f,b]of Object.entries(oldFiles))put(old+'/'+f,b,f==='ynx-finance'?0o755:0o644);
 fs.symlinkSync(old,p(P.current));
 const id='fixture-lease-01';const carrier=P.lease+'/'+id;
 function bundle(which,releaseId,source,files,envBytes){
  const manifest={schema:'ynx-finance-release-inventory/v2',source,tree:(which==='rollback'?'b':'d').repeat(40),releaseId,statePolicy:'preserve-existing-no-migration',files:Object.entries(files).map(([f,b])=>({path:f,sha256:sha(b),bytes:b.length,mode:f==='ynx-finance'?0o755:0o644}))};
  const spec=Object.entries(files).map(([f,b])=>({path:f,data:b.toString('base64'),mode:f==='ynx-finance'?0o755:0o644}));
  const tar=spawnSync(python,['-c',`import io,sys,tarfile,json,base64
out=io.BytesIO()
with tarfile.open(fileobj=out,mode='w',format=tarfile.USTAR_FORMAT) as t:
 for x in json.load(sys.stdin):
  b=base64.b64decode(x['data']);i=tarfile.TarInfo(x['path']);i.size=len(b);i.mode=x['mode'];t.addfile(i,io.BytesIO(b))
sys.stdout.buffer.write(out.getvalue())`],{input:JSON.stringify(spec),maxBuffer:2e6});assert.equal(tar.status,0,tar.stderr.toString());
  const m=JSON.stringify(manifest),sbom=JSON.stringify({bomFormat:'CycloneDX',specVersion:'1.5',version:1,metadata:{component:{type:'application',name:'ynx-finance',version:source}},components:[]});
  const names=which==='rollback'?['rollback.tar','rollback-manifest.json','rollback-sbom.json','rollback.env']:['candidate.tar','manifest.json','sbom.json','candidate.env'];
  for(const [i,b]of [tar.stdout,m,sbom,envBytes].entries())put(carrier+'/'+names[i],b);
  return {source,tree:manifest.tree,releaseId,artifactSha256:sha(tar.stdout),manifestSha256:sha(m),sbomSha256:sha(sbom),binarySha256:sha(files['ynx-finance']),envSha256:sha(envBytes)};
 }
 const rollback=bundle('rollback','fixture-old-01','a'.repeat(40),oldFiles,env(old));const candidate=bundle('candidate','fixture-new-01','c'.repeat(40),newFiles,env(dest));
 const fingerprint=x=>{const st=fs.statSync(p(x));return {absent:false,sha256:sha(fs.readFileSync(p(x))),uid:st.uid,gid:st.gid,mode:st.mode&511};};
 const baseline={currentRelease:old,binary:fingerprint(old+'/ynx-finance'),env:fingerprint(P.env),unit:fingerprint(P.unit),caddy:fingerprint(P.caddy),caddyFiles:[],dropins:[],state:fingerprint(P.state),active:true,pid:101,nrestarts:0};
 const receipt={schema:'ynx-finance-admission/v2',allFinanceIngressClosed:true,activeRequests:0,caddySha256:baseline.caddy.sha256,caddyFiles:[],leaseId:id};json(carrier+'/admission.json',receipt);
 const oldVersion=JSON.stringify({commit:rollback.source}),newVersion=JSON.stringify({commit:candidate.source});
 const http={'https://finance.ynxweb4.com/':{status:503,body:'fixture maintenance'},'http://127.0.0.1:6483/version':{byRelease:{[old]:{status:200,body:oldVersion},[dest]:{status:200,body:newVersion}}}};json('/http.json',http);
 let lease=draftLease({schema:'ynx-finance-deployment-lease/v2',mode:'fixture',leaseId:id,nonce:randomBytes(32).toString('hex'),operation:'deploy',recoveryOf:null,issuedAt:iso(now-1000),notBefore:iso(now-1000),expiresAt:iso(now+180000),singleUse:true,retryAllowed:false,target:host,candidate,baseline,rollback,admission:{url:'https://finance.ynxweb4.com/',status:503,bodySha256:sha('fixture maintenance'),configurationSha256:baseline.caddy.sha256,receiptSha256:sha(fs.readFileSync(p(carrier+'/admission.json')))},verification:{url:'http://127.0.0.1:6483/version',versionSha256:sha(newVersion),source:candidate.source,stateUnchanged:true},rollbackVerification:{url:'http://127.0.0.1:6483/version',versionSha256:sha(oldVersion),source:rollback.source,stateUnchanged:true},tooling:{verifierSha256:verifierDigest(),executorSha256:sha(fs.readFileSync(executor))}},{keyId:root.keys[0].keyId,rootVersion:1});
 const resign=()=>{lease.signature.payloadSha256=sha(payload(lease));lease.signature.value=sign(null,signingBytes(lease),privateKey).toString('base64url');json(carrier+'/lease.json',lease);};resign();
 const args=(mode,extra=[])=>[executor,mode,'--lease-id',id,'--fixture-root',dir,...extra];
 const exec=(mode='execute',extra=[])=>{const r=spawnSync(python,args(mode,extra),{encoding:'utf8',timeout:30000});return {...r,result:r.stdout?.trim()?JSON.parse(r.stdout.trim()):null};};
 return {dir,p,put,json,get,lease,root,host,now,old,dest,carrier,exec,args,resign,privateKey,bundle,oldFiles,newFiles,env,fingerprint};
}
test('canonical encoding and independent Ed25519 roundtrip',t=>{const f=fixture(t);assert.equal(canonical({z:1,a:{b:true,a:[]}}),canonical({a:{a:[],b:true},z:1}));assert.equal(verifyLease(f.lease,f.root,{nowMs:f.now,host:f.host}).leaseId,f.lease.leaseId);for(const x of [NaN,-0,1.5,undefined,'\ud800',{get x(){throw Error('must not execute accessor');}}])assert.throws(()=>canonical(x));});
test('tamper, relabeled key, unknown/revoked key and old root fail',t=>{const f=fixture(t),clone=x=>structuredClone(x);const bad=clone(f.lease);bad.candidate.tree='f'.repeat(40);assert.throws(()=>verifyLease(bad,f.root,{nowMs:f.now}));bad.signature.payloadSha256=sha(payload(bad));assert.throws(()=>verifyLease(bad,f.root,{nowMs:f.now}),/BAD_SIGNATURE/);const r=clone(f.root);r.keys.push({...r.keys[0],keyId:'another-key-01'});const relabel=clone(f.lease);relabel.signature.keyId='another-key-01';assert.throws(()=>verifyLease(relabel,r,{nowMs:f.now}),/BAD_SIGNATURE/);r.keys[0].revoked=true;assert.throws(()=>verifyLease(f.lease,r,{nowMs:f.now}),/REVOKED/);assert.throws(()=>verifyLease(f.lease,{...f.root,keys:[]},{nowMs:f.now}),/UNKNOWN/);assert.throws(()=>verifyLease(f.lease,f.root,{nowMs:f.now,minimumRootVersion:2}),/SIGNATURE_POLICY/);});
test('clock, host, operation, single use, rollback and unknown field guards',t=>{const f=fixture(t);for(const opts of [{},{nowMs:f.now+300000},{nowMs:f.now-300000},{nowMs:f.now,host:{...f.host,machineIdSha256:'f'.repeat(64)}}])assert.throws(()=>verifyLease(f.lease,f.root,opts));for(const edit of [x=>x.operation='exec',x=>x.singleUse=false,x=>x.retryAllowed=true,x=>x.rollback.binarySha256='f'.repeat(64),x=>x.command='sh',x=>x.leaseId='x; touch /tmp/evil']){const x=structuredClone(f.lease);edit(x);x.signature.payloadSha256=sha(payload(x));assert.throws(()=>policy(x,f.root,{nowMs:f.now}));}});
test('issuer guards run before key open and fixture key stays private',t=>{const f=fixture(t),key=f.p('/private-test-key.pem');for(const [l,r,extra,code]of [[f.lease,f.root,{approvedPayloadSha256:'0'.repeat(64)},/REVIEW_REQUIRED/],[{...f.lease,operation:'exec'},f.root,{},/SCHEMA/],[f.lease,{...f.root,keys:[]},{},/UNKNOWN/],[f.lease,f.root,{nowMs:f.now+300000},/EXPIRED/]])assert.throws(()=>issueLease(l,r,{nowMs:f.now,approvedPayloadSha256:f.lease.signature.payloadSha256,privateKeyFile:'/does-not-exist',...extra}),code);const issued=issueLease(f.lease,f.root,{nowMs:f.now,approvedPayloadSha256:f.lease.signature.payloadSha256,privateKeyFile:key});assert.equal(verifyLease(issued,f.root,{nowMs:f.now}).signature.value,f.lease.signature.value);fs.chmodSync(key,0o644);assert.throws(()=>issueLease(f.lease,f.root,{nowMs:f.now,approvedPayloadSha256:f.lease.signature.payloadSha256,privateKeyFile:key}),/PERMISSIONS/);});
test('doctor requires configured public key and never authorizes or opens private keys',t=>{const f=fixture(t);f.json('/empty-root.json',{...f.root,keys:[]});const x=run(['doctor','--trust-root',f.p('/empty-root.json')]);assert.equal(x.status,'BLOCKED_NO_PROTECTED_PUBLIC_KEY');assert.equal(x.secretAccess,false);assert.equal(f.exec('doctor').result.status,'NO_EXECUTION_LEDGER');assert.ok(!fs.existsSync(f.p(P.control)));});
test('dry run validates complete carrier without mutation or consumption',t=>{const f=fixture(t),r=f.exec('dry-run');assert.equal(r.status,0,JSON.stringify(r));assert.equal(r.result.mutations,false);assert.equal(fs.readlinkSync(f.p(P.current)),f.old);assert.ok(!fs.existsSync(f.p(P.control)));assert.ok(!fs.existsSync(f.p(f.dest)));});
test('deploy is single-use and records durable receipt with unchanged state',t=>{const f=fixture(t),state=fs.readFileSync(f.p(P.state));const r=f.exec();assert.equal(r.status,0,JSON.stringify(r));assert.equal(r.result.status,'SUCCEEDED_ADMISSION_REMAINS_CLOSED');assert.equal(fs.readlinkSync(f.p(P.current)),f.dest);assert.deepEqual(fs.readFileSync(f.p(P.state)),state);assert.equal(f.get(P.control+'/ledger.json').leases[f.lease.leaseId].state,'SUCCEEDED');assert.equal(f.exec().result.code,'ALREADY_CONSUMED');assert.equal(f.exec('dry-run').result.code,'ALREADY_CONSUMED');assert.equal(f.get('/http.json')['https://finance.ynxweb4.com/'].status,503);});
test('eight simultaneous processes consume at most once',async t=>{const f=fixture(t);const results=await Promise.all(Array.from({length:8},()=>new Promise(resolve=>{const c=spawn(python,f.args('execute'));let out='';c.stdout.on('data',b=>out+=b);c.on('close',status=>resolve({status,result:JSON.parse(out)}));})));assert.equal(results.filter(r=>r.status===0).length,1,JSON.stringify(results));assert.ok(results.filter(r=>r.status!==0).every(r=>['BUSY','ALREADY_CONSUMED'].includes(r.result.code)),JSON.stringify(results));assert.equal(Object.keys(f.get(P.control+'/ledger.json').leases).length,1);});
for(const target of ['candidate.tar','manifest.json','sbom.json','rollback.tar','rollback-manifest.json','rollback-sbom.json','rollback.env'])test('artifact binding rejects '+target,t=>{const f=fixture(t);fs.appendFileSync(f.p(f.carrier+'/'+target),'tamper');assert.notEqual(f.exec().status,0);assert.ok(!fs.existsSync(f.p(P.control+'/ledger.json')));assert.equal(fs.readlinkSync(f.p(P.current)),f.old);});
for(const target of [P.state,P.unit,P.caddy,P.env])test('baseline drift rejects '+target,t=>{const f=fixture(t);fs.appendFileSync(f.p(target),'drift');assert.notEqual(f.exec().status,0);assert.ok(!fs.existsSync(f.p(P.control+'/ledger.json')));});
test('new Caddy import, incomplete ingress receipt and open admission reject before stop',t=>{const f=fixture(t);f.put('/etc/caddy/extra.caddy','unexpected');assert.equal(f.exec().result.code,'CADDY_INCLUDE_SET');fs.unlinkSync(f.p('/etc/caddy/extra.caddy'));const j=f.get('/http.json');j['https://finance.ynxweb4.com/'].status=200;f.json('/http.json',j);assert.equal(f.exec().result.code,'ADMISSION_NOT_CLOSED');j['https://finance.ynxweb4.com/'].status=503;f.json('/http.json',j);const r=f.get(f.carrier+'/admission.json');r.allFinanceIngressClosed=false;f.json(f.carrier+'/admission.json',r);f.lease.admission.receiptSha256=sha(fs.readFileSync(f.p(f.carrier+'/admission.json')));f.resign();assert.equal(f.exec().result.code,'ADMISSION_POLICY');assert.equal(f.get('/service.json').pid,101);});
test('signed changes to secret or write flags still fail executor policy',t=>{const f=fixture(t);const env=fs.readFileSync(f.p(f.carrier+'/candidate.env'),'utf8').replace('FIXTURE_NON_SECRET=not-a-credential','FIXTURE_NON_SECRET=changed');f.put(f.carrier+'/candidate.env',env);f.lease.candidate.envSha256=sha(env);f.resign();assert.equal(f.exec().result.code,'SECRET_OR_CONFIG_CHANGE');});
test('symlink and unsafe archive paths fail before consumption',t=>{const f=fixture(t);fs.unlinkSync(f.p(f.carrier+'/candidate.tar'));fs.symlinkSync(f.p(f.carrier+'/rollback.tar'),f.p(f.carrier+'/candidate.tar'));assert.notEqual(f.exec().status,0);assert.ok(!fs.existsSync(f.p(P.control+'/ledger.json')));});
for(const phase of ['CONSUMED','STAGED','STOPPING','STOPPED','SWITCHING','SWITCHED','STARTED','VERIFIED'])test('crash '+phase+' remains spent and doctor cannot resume',t=>{const f=fixture(t),r=f.exec('execute',['--fixture-crash',phase]);assert.equal(r.status,77,JSON.stringify(r));assert.equal(f.get(P.control+'/ledger.json').leases[f.lease.leaseId].phase,phase);assert.equal(f.exec().result.code,'ALREADY_CONSUMED');const d=f.exec('doctor');assert.equal(d.status,0);assert.equal(d.result.mutations,false);assert.equal(d.result.leases[0].state,'CONSUMED');assert.equal(f.fingerprint(P.state).sha256,f.lease.baseline.state.sha256);});
test('failed candidate version automatically restores only signed bytes, never state',t=>{const f=fixture(t),http=f.get('/http.json');http['http://127.0.0.1:6483/version'].byRelease[f.dest].body='{"commit":"wrong"}';f.json('/http.json',http);const r=f.exec();assert.equal(r.result.code,'FAILED_ROLLED_BACK',JSON.stringify(r));assert.equal(fs.readlinkSync(f.p(P.current)),f.old);assert.equal(f.fingerprint(P.env).sha256,f.lease.rollback.envSha256);assert.equal(f.fingerprint(P.state).sha256,f.lease.baseline.state.sha256);assert.equal(f.exec().result.code,'ALREADY_CONSUMED');});
test('durable high-water blocks clock/root downgrade and nonce reuse across IDs',t=>{const f=fixture(t);f.json(P.control+'/ledger.json',{schema:'ynx-finance-consumed/v2',rootVersion:1,lastClockMs:Date.now()+1000000,leases:{}});fs.chmodSync(f.p(P.control),0o700);assert.equal(f.exec().result.code,'CLOCK_ROLLBACK');let j=f.get(P.control+'/ledger.json');j.lastClockMs=0;j.rootVersion=2;f.json(P.control+'/ledger.json',j);assert.equal(f.exec().result.code,'SIGNATURE_OR_POLICY');j.rootVersion=1;j.leases['different-lease']={nonce:f.lease.nonce};f.json(P.control+'/ledger.json',j);assert.equal(f.exec().result.code,'ALREADY_CONSUMED');});
test('fresh explicitly signed rollback operation is independently consumed',t=>{const f=fixture(t);f.lease.operation='rollback';f.resign();const r=f.exec();assert.equal(r.status,0,JSON.stringify(r));assert.equal(r.result.operation,'rollback');assert.equal(f.exec().result.code,'ALREADY_CONSUMED');});
test('local transport plan pins exact known host and emits argv without execution',t=>{const f=fixture(t),key=Buffer.from('synthetic-public-host-key');f.lease.target.sshHostFingerprint='SHA256:'+Buffer.from(sha(key),'hex').toString('base64').replace(/=+$/,'');f.resign();f.put('/known-hosts','fixture.invalid ssh-ed25519 '+key.toString('base64')+'\n');const args=['transport-plan','--lease',f.p(f.carrier+'/lease.json'),'--trust-root',f.p(P.trust),'--known-hosts',fs.realpathSync(f.p('/known-hosts')),'--identity-file',f.p('/not-opened-ssh-identity')];const r=run(args);assert.equal(r.executed,false);assert.ok(r.argv.includes('StrictHostKeyChecking=yes'));assert.ok(r.argv.includes('UpdateHostKeys=no'));assert.equal(r.argv.at(-1),f.lease.leaseId);f.put('/known-hosts','fixture.invalid ssh-ed25519 '+Buffer.from('wrong').toString('base64')+'\n');assert.throws(()=>run(args),/SSH_FINGERPRINT/);});

test('stop/start uncertainty becomes ambiguous and cannot be replayed',t=>{for(const action of ['stopError','startError']){const f=fixture(t),j=f.get('/service.json');j[action]=true;f.json('/service.json',j);const r=f.exec();assert.equal(r.result.code,'AMBIGUOUS_REQUIRES_NEW_RECOVERY_LEASE',JSON.stringify(r));assert.equal(f.exec().result.code,'ALREADY_CONSUMED');}});
test('candidate state mutation prevents automatic state rollback',t=>{const f=fixture(t),j=f.get('/service.json');j.onStartState={newActivity:'must survive'};f.json('/service.json',j);assert.equal(f.exec().result.code,'AMBIGUOUS_REQUIRES_NEW_RECOVERY_LEASE');assert.deepEqual(f.get(P.state),j.onStartState);assert.equal(fs.readlinkSync(f.p(P.current)),f.dest);});
test('fresh rollback recovery supports stopped writer and requires exact unresolved receipt',t=>{const f=fixture(t);const oldId='previous-crashed-lease';f.json(P.control+'/ledger.json',{schema:'ynx-finance-consumed/v2',rootVersion:1,lastClockMs:0,leases:{[oldId]:{nonce:'f'.repeat(64),state:'CONSUMED',phase:'STOPPED'}}});fs.chmodSync(f.p(P.control),0o700);assert.equal(f.exec().result.code,'UNRESOLVED_EXECUTION_REQUIRES_RECOVERY_LEASE');f.lease.operation='rollback';f.lease.recoveryOf=oldId;f.lease.baseline.active=false;f.lease.baseline.pid=0;f.json('/service.json',{active:false,pid:0,nextPID:101,nrestarts:0});f.resign();const r=f.exec();assert.equal(r.status,0,JSON.stringify(r));assert.equal(f.get(P.control+'/ledger.json').leases[oldId].recoveryLeaseId,f.lease.leaseId);assert.equal(f.exec().result.code,'ALREADY_CONSUMED');});
for(const kind of ['symlink','traversal','duplicate'])test('signed malicious tar '+kind+' fails before consuming',t=>{const f=fixture(t);const r=spawnSync(python,['-c',`import io,sys,tarfile
p=sys.argv[1];kind=sys.argv[2]
with tarfile.open(p,'r:') as t:
 members=[(x,t.extractfile(x).read()) for x in t.getmembers()]
with tarfile.open(p,'w',format=tarfile.USTAR_FORMAT) as t:
 for i,(m,b) in enumerate(members):
  if i==0 and kind=='symlink':m.type=tarfile.SYMTYPE;m.linkname='/etc/passwd';m.size=0
  if i==0 and kind=='traversal':m.name='../outside'
  t.addfile(m,io.BytesIO(b))
  if i==0 and kind=='duplicate':t.addfile(m,io.BytesIO(b))`,f.p(f.carrier+'/candidate.tar'),kind]);assert.equal(r.status,0);f.lease.candidate.artifactSha256=sha(fs.readFileSync(f.p(f.carrier+'/candidate.tar')));f.resign();assert.notEqual(f.exec().status,0);assert.ok(!fs.existsSync(f.p(P.control+'/ledger.json')));});
test('remote verifier rejects expired lease, wrong machine, legacy object and wrong executor',t=>{for(const kind of ['expired','machine','legacy','executor']){const f=fixture(t);if(kind==='expired'){f.lease.issuedAt=iso(f.now-100000);f.lease.notBefore=iso(f.now-100000);f.lease.expiresAt=iso(f.now-1);f.resign();}if(kind==='machine')f.json('/host.json',{...f.host,machineIdSha256:'e'.repeat(64)});if(kind==='legacy')f.json(f.carrier+'/lease.json',{leaseId:f.lease.leaseId,signed:true,operation:'deploy'});if(kind==='executor'){f.lease.tooling.executorSha256='0'.repeat(64);f.resign();}assert.notEqual(f.exec().status,0,kind);assert.ok(!fs.existsSync(f.p(P.control+'/ledger.json')),kind);assert.equal(f.get('/service.json').pid,101);}});
test('absent state stays absent and no state backup is invented',t=>{const f=fixture(t);fs.unlinkSync(f.p(P.state));f.lease.baseline.state={absent:true,sha256:null,uid:0,gid:0,mode:0};f.resign();const r=f.exec();assert.equal(r.status,0,JSON.stringify(r));assert.ok(!fs.existsSync(f.p(P.state)));assert.ok(!fs.existsSync(f.p(P.control+'/'+f.lease.leaseId+'/state')));});
test('wrong recovery receipt cannot clear a spent operation',t=>{const f=fixture(t);f.json(P.control+'/ledger.json',{schema:'ynx-finance-consumed/v2',rootVersion:1,lastClockMs:0,leases:{'correct-recovery-id':{nonce:'f'.repeat(64),state:'CONSUMED',phase:'STOPPED'}}});fs.chmodSync(f.p(P.control),0o700);f.lease.operation='rollback';f.lease.recoveryOf='unrelated-recovery';f.resign();assert.equal(f.exec().result.code,'RECOVERY_RECEIPT');assert.equal(f.get('/service.json').pid,101);});

test('duplicate JSON keys, including escaped spellings, are rejected',t=>{assert.throws(()=>parseDocument('{"a":1,"a":2}'),/DUPLICATE_KEY/);assert.throws(()=>parseDocument('{"a":1,"\\u0061":2}'),/DUPLICATE_KEY/);assert.deepEqual(parseDocument('{"a":[{"x":1},{"x":2}],"b":"\\\"{},"}'),{a:[{x:1},{x:2}],b:'"{},'});const f=fixture(t),raw=fs.readFileSync(f.p(f.carrier+'/lease.json'),'utf8');f.put(f.carrier+'/lease.json',raw.replace('{','{"singleUse":false,'));assert.notEqual(f.exec().status,0);assert.ok(!fs.existsSync(f.p(P.control+'/ledger.json')));});

function transportFixture(t){
 const f=fixture(t),key=Buffer.from('synthetic-public-host-key');
 f.lease.target.sshHostFingerprint='SHA256:'+Buffer.from(sha(key),'hex').toString('base64').replace(/=+$/,'');f.resign();
 const line='fixture.invalid ssh-ed25519 '+key.toString('base64')+'\n';f.put('/known-hosts',line);
 const known=fs.realpathSync(f.p('/known-hosts'));
 const args=p=>['transport-plan','--lease',f.p(f.carrier+'/lease.json'),'--trust-root',f.p(P.trust),'--known-hosts',p,'--identity-file',f.p('/not-opened-ssh-identity')];
 return {...f,line,known,args};
}
test('transport rejects SSH tokens, whitespace, controls and ambiguous path syntax before file access',t=>{
 const f=transportFixture(t),dir=path.dirname(f.known);
 for(const suffix of ['%h','%p','%d','%C','%%','${HOME}','$HOME','~','two files','tab\tfile','line\nfile','return\rfile','nul\0file','nbsp\u00a0file','quote"file',"quote'file",'slash\\file','glob*','[list]','semi;file','colon:file'])
  assert.throws(()=>run(f.args(dir+'/'+suffix)),/SSH_LITERAL_PATH/,JSON.stringify(suffix));
 for(const p of [dir+'//known-hosts',dir+'/./known-hosts',dir+'/../known-hosts',f.known+'/',dir+'/known-hosts '+f.known])
  assert.throws(()=>run(f.args(p)),/SSH_LITERAL_PATH/,p);
 const alias=dir+'/symlink-parent';fs.symlinkSync(dir,alias);
 assert.throws(()=>run(f.args(alias+'/known-hosts')),/SSH_CANONICAL_PATH/);
});
test('OpenSSH -G parses exactly the verified single literal known-hosts path without connecting',t=>{
 const f=transportFixture(t),plan=run(f.args(f.known));assert.equal(plan.argv[0],'/usr/bin/ssh');
 // -G prints effective configuration and exits before any connection/authentication.
 const parsed=spawnSync(plan.argv[0],['-G',...plan.argv.slice(1)],{encoding:'utf8',timeout:5000});
 assert.equal(parsed.status,0,parsed.stderr);assert.equal(parsed.signal,null);
 const lines=parsed.stdout.split('\n').filter(x=>x.startsWith('userknownhostsfile '));
 assert.deepEqual(lines,['userknownhostsfile '+f.known]);
 assert.ok(parsed.stdout.includes('globalknownhostsfile /dev/null\n'));
 // Demonstrate the rejected inputs really have different OpenSSH semantics.
 const unsafe=spawnSync('/usr/bin/ssh',['-G','-F','/dev/null','-T','-o','UserKnownHostsFile='+path.dirname(f.known)+'/%h','--','fixture.invalid'],{encoding:'utf8',timeout:5000});
 assert.equal(unsafe.status,0,unsafe.stderr);assert.ok(unsafe.stdout.includes('userknownhostsfile '+path.dirname(f.known)+'/fixture.invalid\n'));
 const multiple=spawnSync('/usr/bin/ssh',['-G','-F','/dev/null','-T','-o','UserKnownHostsFile='+f.known+' '+f.known+'-second','--','fixture.invalid'],{encoding:'utf8',timeout:5000});
 assert.equal(multiple.status,0,multiple.stderr);assert.ok(multiple.stdout.includes('userknownhostsfile '+f.known+' '+f.known+'-second\n'));
 f.put('/known-hosts',f.line+f.line);assert.throws(()=>run(f.args(f.known)),/EXACT_HOST_KEY/);
});
test('remote command uses only fixed absolute executables and safe exact lease ID',t=>{
 const f=transportFixture(t),plan=run(f.args(f.known));const hostIndex=plan.argv.indexOf('ubuntu@fixture.invalid');
 assert.ok(hostIndex>0);assert.equal(plan.argv[hostIndex-1],'--');
 const remote=plan.argv.slice(hostIndex+1);
 assert.deepEqual(remote,['/usr/bin/sudo','-n','/usr/bin/python3','/opt/ynx/finance-release-v2/executor.py','execute','--lease-id',f.lease.leaseId]);
 // OpenSSH joins remote arguments for the remote shell; this exact shape contains
 // no substitutions, quotes, options from a payload or PATH-dependent executable.
 assert.equal(remote.join(' '),'/usr/bin/sudo -n /usr/bin/python3 /opt/ynx/finance-release-v2/executor.py execute --lease-id fixture-lease-01');
 assert.ok(remote.every(x=>/^[A-Za-z0-9_./-]+$/.test(x)));assert.equal(plan.executed,false);
});
