// Actual original SDK cryptography/kernel with test-owned synthetic keys and
// transport only. No Wallet UI, account policy Source or live Auth is claimed.
import assert from 'node:assert/strict';
import {createECDH,randomBytes} from 'node:crypto';
import * as sdk from '@ynx-chain/wallet-auth';
import {readFile} from 'node:fs/promises';
import {createOriginalCloudFileSessionV2Server} from './file-session-v2-server.mjs';
import {openOriginalCloudFileSessionV2} from './file-session-v2-client.mjs';
const root=new URL('../',import.meta.resolve('@ynx-chain/wallet-auth'));
const registry=JSON.parse(await readFile(new URL('product-session-registry.json',root),'utf8'));
let now=new Date();const device=createECDH('prime256v1');device.generateKeys();const secret=device.getPrivateKey().toString('base64url');
const handler=new sdk.ProductSessionGatewayHttpHandler(registry,()=>randomBytes(32).toString('base64url'));
let calls=0,advance=false;const seen=[];
const fetch=async(url,init)=>{
 calls++;seen.push(init);const h=new Headers(init.headers);
 const reply=handler.handle({requestId:h.get('x-request-id'),method:init.method,path:new URL(url).pathname,contentType:h.get('content-type'),body:init.body,proofHeader:h.get('x-ynx-product-session-proof-v2'),networkAvailable:true},now);
 if(advance)now=new Date(now.getTime()+61000);
 return new Response(reply.body,{status:reply.status,headers:reply.headers});
};
const gateway=new sdk.ProductSessionGatewayFetchAdapter({endpoint:'https://auth.example.test',fetch,timeoutMs:5000,walletInstalled:()=>false,schemeRegistered:()=>false});
const request=sdk.createProductSessionRequest(registry,{productId:'cloud',platform:'web',deviceId:'PUBLIC_TEST_DEVICE_0001',deviceKey:device.getPublicKey(null,'compressed').toString('base64url'),scopes:['files.read','files.write'],purpose:'Synthetic original SDK file session test',nonce:randomBytes(32).toString('base64url'),state:randomBytes(32).toString('base64url')},now);
const approval=sdk.signProductSessionApproval(registry,request,{accountSecret:'11'.repeat(32),scopes:request.scopes,expiresAt:request.expiresAt},now);
const challenge=await gateway.challenge({requestId:'req_public_challenge_0001',request,approval});
const session=await gateway.complete({requestId:'req_public_complete_0001',request,approval,completion:sdk.signProductSessionChallenge(challenge,secret)});
const owner=await createOriginalCloudFileSessionV2Server({authorityEndpoint:'https://auth.example.test',cloudEndpoint:'https://web4.ynxweb4.com/api/v1',fetch,clock:()=>now});
const proof=scopes=>sdk.encodeProductSessionGatewayProofHeaderV2(sdk.createProductSessionProofV2(session,{method:'POST',path:'/v2/product-sessions/introspect',bodyDigest:sdk.httpBodyDigest(sdk.canonicalJSON({requiredScopes:scopes})),nonce:randomBytes(32).toString('base64url'),issuedAt:now.toISOString(),expiresAt:new Date(now.getTime()+30000).toISOString()},secret));
const input=header=>({proofHeader:header,origin:'https://web4.ynxweb4.com',method:'GET',path:'/api/v1/session',requiredScopes:['files.read']});
const first=proof(['files.read']);assert.equal((await owner.authorize(input(first))).sessionBinding,session.sessionBinding);
await assert.rejects(owner.authorize(input(first))); // consumed proof, no cached grant
let before=calls;await assert.rejects(owner.authorize({...input(proof(['files.read'])),origin:'https://other.invalid'}));assert.equal(calls,before);
await assert.rejects(owner.authorize({...input(proof(['files.read'])),requiredScopes:['permissions.manage']}));assert.equal(calls,before);
await assert.rejects(owner.authorize(input(proof(['files.write']))));assert.equal(calls,before);
advance=true;await assert.rejects(owner.authorize(input(proof(['files.read']))));advance=false;
assert.ok(seen.every(x=>!new Headers(x.headers).has('authorization')&&!new Headers(x.headers).has('cookie')&&x.credentials==='omit'&&x.redirect==='error'));
await assert.rejects(openOriginalCloudFileSessionV2({registry,authorityEndpoint:'https://auth.example.test',cloudEndpoint:'https://web4.ynxweb4.com/api/v1',environment:{isSecureContext:true,location:{origin:'http://localhost'}}}));
await assert.rejects(openOriginalCloudFileSessionV2({registry,authorityEndpoint:'https://auth.example.test',cloudEndpoint:'https://other.invalid/api/v1',environment:{isSecureContext:true,location:{origin:'https://web4.ynxweb4.com'}}}));
process.stdout.write(JSON.stringify({originalSDKKernelAndCrypto:true,syntheticKeysOnly:true,healthyIntrospection:true,replayRejected:true,originRejectedBeforeHTTP:true,scopeWideningRejectedBeforeHTTP:true,scopeProofMismatchRejectedBeforeHTTP:true,postAwaitExpiryRejected:true,noBearerOrCookie:true,CLIWebImpersonationRejected:true,actualWalletUI:false,actualEndpoints:false}));
