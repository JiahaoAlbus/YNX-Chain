import {ProductSessionGatewayFetchAdapter,productPlatformBinding} from '@ynx-chain/wallet-auth';
import {createBrowserProductSessionClient} from '@ynx-chain/wallet-auth/product-session-browser';

const owners=new WeakSet();
const scopesFor=(path,method)=>{
 const route=path.split('?')[0];
 if(method==='GET'&&(/^\/(session|quota|objects(?:\/[A-Za-z0-9_-]+(?:\/(content|versions))?)?|object-operations\/[A-Za-z0-9_-]+)$/.test(route)))return ['files.read'];
 if((method==='POST'&&route==='/objects')||(method==='PUT'&&/^\/objects\/[A-Za-z0-9_-]+\/content$/.test(route))||(method==='POST'&&/^\/objects\/[A-Za-z0-9_-]+\/versions\/[1-9][0-9]*\/restore$/.test(route)))return ['files.write'];
 throw Error('Cloud route is not registered for this file session');
};
export const isOriginalCloudFileSessionV2Owner=value=>owners.has(value);

// The original browser factory enforces the real HTTPS origin and protects
// the same non-extractable device/pending request/UNKNOWN/revocation lifetime.
// A standalone CLI cannot claim this registered web identity.
export async function openOriginalCloudFileSessionV2({registry,authorityEndpoint,cloudEndpoint,environment=globalThis,clock=()=>new Date(),accountPolicy}){
 const binding=productPlatformBinding(registry,'cloud','web'),url=new URL(cloudEndpoint);
 if(url.origin!==binding.origin||url.username||url.password||url.search||url.hash||!['/api/v1','/cloud/api/v1'].includes(url.pathname)||cloudEndpoint!==url.href)throw Error('Cloud endpoint differs from the registered product origin');
 if(environment.isSecureContext!==true||environment.location?.origin!==binding.origin)throw Error('Original registered Cloud web caller required');
 const transport=environment.fetch.bind(environment);
 const gateway=new ProductSessionGatewayFetchAdapter({endpoint:authorityEndpoint,fetch:transport,timeoutMs:5000,walletInstalled:()=>false,schemeRegistered:()=>false});
 const original=await createBrowserProductSessionClient({registry,productId:'cloud',scopes:['files.read','files.write'],purpose:'Read and update my explicitly authorized Cloud files.',gateway,environment,clock,...(accountPolicy===undefined?{}:{accountPolicy})});
 let closed=false;
 const current=()=>{if(closed)throw Error('Original Cloud file session owner is closed');return original.client.current;};
 const owner=Object.freeze({
  endpoint:cloudEndpoint,
  current,
  begin:()=>{current();return original.client.beginExplicit();},
  finish:url=>{current();return original.client.handleReturn(url);},
  restore:networkAvailable=>{current();return original.client.restore(networkAvailable);},
  retry:()=>{current();return original.client.retryDetected();},
  disconnect:()=>{current();return original.client.disconnect();},
  setNetworkAvailable:value=>{current();return original.client.setNetworkAvailable(value);},
  async request(path,{method='GET',headers={},body,signal}={}){
   if(typeof path!=='string'||!path.startsWith('/')||path.startsWith('//')||path.includes('#')||path.includes('..')||/[\r\n\\]/.test(path))throw Error('Original relative Cloud file route required');
   const selectedHeaders=new Headers(headers);for(const name of ['authorization','cookie','origin','x-ynx-product-session-proof-v2'])if(selectedHeaders.has(name))throw Error('Mixed Cloud authentication headers are not allowed');
   const selectedBody=body===undefined?undefined:typeof body==='string'?body:body instanceof Uint8Array?new Uint8Array(body):null;if(selectedBody===null||(typeof selectedBody==='string'?new TextEncoder().encode(selectedBody).length:selectedBody?.byteLength??0)>16777216)throw Error('Final bounded Cloud body bytes required');
   if(method==='GET'&&selectedBody!==undefined)throw Error('File GET requires an empty body');
   if(signal?.aborted)throw signal.reason;
   const selectedScopes=scopesFor(path,method),before=current();
   const proof=await original.createIntrospectionProof(selectedScopes);
   if(signal?.aborted)throw signal.reason;
   if(closed||current()!==before)throw Error('Original Cloud file session changed before request');
   selectedHeaders.set('x-ynx-product-session-proof-v2',proof.proofHeader);
   const response=await transport(cloudEndpoint+path,{method,headers:selectedHeaders,body:selectedBody,signal,credentials:'omit',redirect:'error',cache:'no-store'});
   if(signal?.aborted||closed||current()!==before){await response.body?.cancel();if(signal?.aborted)throw signal.reason;throw Error('Original Cloud file session changed during request');}
   return response;
  },
  close(){if(!closed){closed=true;original.close();}}
 });owners.add(owner);return owner;
}
