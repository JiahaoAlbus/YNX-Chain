import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {ProductSessionServerAuthorizer,productPlatformBinding} from '@ynx-chain/wallet-auth';

// Fixed original SDK implementation and registry, never a client-selected
// provider, caller identity, upstream URL or route-scope assertion.
const root=new URL('../',import.meta.resolve('@ynx-chain/wallet-auth'));
const pins=[['product-session-registry.json','9e5ad95a3b9761c539c4c8e72c21850cd75fcc60d9faa2c5017b90efe1148ee5'],['src/product-session-server.js','95f2997253fee5e6b6d8cf80aff47ff4ed14ac3fea33d20a4983fc542398d7c7']];
export async function createOriginalCloudFileSessionV2Server({authorityEndpoint,cloudEndpoint,fetch=globalThis.fetch,clock=()=>new Date()}){
 for(const [name,expected] of pins){const raw=await readFile(new URL(name,root));if(createHash('sha256').update(raw).digest('hex')!==expected)throw Error('CLOUD_FILE_SESSION_SDK_MISMATCH');}
 const registry=JSON.parse(await readFile(new URL('product-session-registry.json',root),'utf8'));
 const binding=productPlatformBinding(registry,'cloud','web'),url=new URL(cloudEndpoint);
 if(url.origin!==binding.origin||url.username||url.password||url.search||url.hash||!['/api/v1','/cloud/api/v1'].includes(url.pathname)||cloudEndpoint!==url.href)throw Error('CLOUD_FILE_SESSION_ENDPOINT_MISMATCH');
 const authorizer=new ProductSessionServerAuthorizer({registry,productId:'cloud',platform:'web',endpoint:authorityEndpoint,fetch,timeoutMs:5000,clock});
 return Object.freeze({binding,authorize:input=>authorizer.authorize(input)});
}
