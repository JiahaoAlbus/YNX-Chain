import {createOriginalCloudFileSessionV2Server} from './file-session-v2-server.mjs';
try{
 let raw='';for await(const b of process.stdin){raw+=b;if(Buffer.byteLength(raw)>65536)throw Error('CLOUD_FILE_SESSION_INPUT_LIMIT');}
 const input=JSON.parse(raw);
 const owner=await createOriginalCloudFileSessionV2Server({authorityEndpoint:process.argv[2],cloudEndpoint:process.argv[3]});
 if(input?.probe===true&&Object.keys(input).length===1)process.stdout.write(JSON.stringify({ok:true}));
 else{const session=await owner.authorize(input);process.stdout.write(JSON.stringify({ok:true,session}));}
}catch(error){process.stdout.write(JSON.stringify({ok:false,code:typeof error?.code==='string'&&/^[A-Z0-9_]{1,100}$/.test(error.code)?error.code:'CLOUD_FILE_SESSION_UNAVAILABLE'}));process.exitCode=1;}
