// Local wait/body lifecycle stand-ins only: PUBLIC_NOT_A_PROOF never reaches
// an Auth or Cloud server. SDK math/currentness is tested separately.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import * as sdk from '@ynx-chain/wallet-auth';
const registry=JSON.parse(await readFile(new URL('../product-session-registry.json',import.meta.resolve('@ynx-chain/wallet-auth')),'utf8'));
const code=await readFile(new URL('./file-session-v2-client.mjs',import.meta.url),'utf8');
let proofResolve,fetches=0,closed=0,delay=false;
const status=Object.freeze({status:'connected',session:{PUBLIC_NOT_AUTHORITY:true}});
const original={client:{get current(){return status;},beginExplicit:async()=>status,handleReturn:async()=>status,restore:async()=>status,retryDetected:async()=>status,disconnect:async()=>status,setNetworkAvailable:()=>status},async createIntrospectionProof(){if(delay)await new Promise(r=>proofResolve=r);return {proofHeader:'PUBLIC_NOT_A_PROOF'};},close(){closed++;}};
const sdkModule=new vm.SyntheticModule(['ProductSessionGatewayFetchAdapter','productPlatformBinding'],function(){this.setExport('ProductSessionGatewayFetchAdapter',sdk.ProductSessionGatewayFetchAdapter);this.setExport('productPlatformBinding',sdk.productPlatformBinding);});
const browserModule=new vm.SyntheticModule(['createBrowserProductSessionClient'],function(){this.setExport('createBrowserProductSessionClient',async()=>original);});
const m=new vm.SourceTextModule(code,{identifier:new URL('./file-session-v2-client.mjs',import.meta.url).href});await m.link(name=>name.endsWith('/product-session-browser')?browserModule:sdkModule);await m.evaluate();
const environment={isSecureContext:true,location:{origin:'https://web4.ynxweb4.com'},async fetch(url,init){fetches++;let c;const body=new ReadableStream({start(x){c=x;x.enqueue(new TextEncoder().encode('PUBLIC data'));}});init.signal.addEventListener('abort',()=>c.error(init.signal.reason),{once:true});return new Response(body,{headers:{'content-type':'application/octet-stream'}});}};
const open=()=>m.namespace.openOriginalCloudFileSessionV2({registry,authorityEndpoint:'https://auth.example.test',cloudEndpoint:'https://web4.ynxweb4.com/api/v1',environment});
delay=true;let owner=await open();const pending=owner.request('/session');for(let i=0;i<20&&!proofResolve;i++)await new Promise(r=>setImmediate(r));assert.ok(proofResolve);owner.close();proofResolve();await assert.rejects(pending);assert.equal(fetches,0);assert.equal(closed,1);
delay=false;owner=await open();const response=await owner.request('/objects/PUBLIC_file/content');const reader=response.body.getReader();assert.equal(new TextDecoder().decode((await reader.read()).value),'PUBLIC data');const waiting=reader.read();owner.close();await assert.rejects(waiting);owner.close();assert.equal(closed,2);
owner=await open();const before=fetches;await assert.rejects(owner.request('/objects/PUBLIC_file/links'));await assert.rejects(owner.request('/session',{headers:{authorization:'PUBLIC_NOT_A_TOKEN'}}));assert.equal(fetches,before);owner.close();
process.stdout.write(JSON.stringify({PUBLICLocalLifecycleOnly:true,closeDuringProofZeroFetch:true,closeDuringBodyRejectsLateData:true,idempotentClose:true,unregisteredSharingZeroFetch:true,mixedBearerZeroFetch:true,actualSessionOrAuthority:false}));
