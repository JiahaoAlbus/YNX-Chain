// Synthetic SDK authority + test storage port. Real non-extractable WebCrypto
// device signatures and original reference recovery; no Main UI/Root positive.
import assert from 'node:assert/strict';
import {webcrypto,randomBytes} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import * as sdk from '@ynx-chain/wallet-auth';
const registry=JSON.parse(await readFile(new URL('../product-session-registry.json',import.meta.resolve('@ynx-chain/wallet-auth')),'utf8'));
const tokens=()=>randomBytes(32).toString('base64url');let now=new Date();
let handler=new sdk.ProductSessionGatewayHttpHandler(registry,tokens),drop=true,completes=0,signs=0,introspections=0;
const fetch=async(url,init)=>{
 const h=new Headers(init.headers),path=new URL(url).pathname,id=h.get('x-request-id');
 if(path.endsWith('/time'))return new Response(sdk.canonicalJSON({ok:true,requestId:id,schemaVersion:2,result:{serverTime:now.toISOString()}}),{headers:{'content-type':'application/json','cache-control':'no-store','x-request-id':id}});
 const reply=handler.handle({requestId:id,method:init.method,path,contentType:h.get('content-type'),body:init.body,proofHeader:h.get('x-ynx-product-session-proof-v2'),networkAvailable:true},now);
 if(path.endsWith('/introspect'))introspections++;
 if(path.endsWith('/returns/complete')){completes++;if(drop&&reply.status===200){drop=false;throw Error('PUBLIC lost original complete response');}}
 return new Response(reply.body,{status:reply.status,headers:reply.headers});
};
const gateway=new sdk.ProductSessionGatewayFetchAdapter({endpoint:'https://auth.example.test',fetch,timeoutMs:5000,walletInstalled:()=>false,schemeRegistered:()=>false});
const pair=await webcrypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},false,['sign','verify']);assert.equal(pair.privateKey.extractable,false);
const raw=new Uint8Array(await webcrypto.subtle.exportKey('raw',pair.publicKey));const key=Buffer.from(Uint8Array.of(raw[64]%2?3:2,...raw.slice(1,33))).toString('base64url');
const integer=x=>{let a=x;while(a.length>1&&a[0]===0)a=a.slice(1);if(a[0]&128)a=Uint8Array.of(0,...a);return Uint8Array.of(2,a.length,...a);};
const device={id:'PUBLIC_REFERENCE_DEVICE_0001',key,scopes:['files.read','files.write'],purpose:'Synthetic original reference Cloud file session',async sign(input){signs++;const bytes=new Uint8Array(await webcrypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},pair.privateKey,Buffer.from(input.payload,'base64url')));const r=integer(bytes.slice(0,32)),s=integer(bytes.slice(32));return Buffer.from(Uint8Array.of(48,r.length+s.length,...r,...s)).toString('base64url');}};
const store=new Map(),storage={securityLevel:'webcrypto-nonextractable',async get(k){return store.get(k)??null;},async set(k,v){store.set(k,v);},async remove(k){store.delete(k);}};
const open=()=>new sdk.RecoverableProductSessionClient({registry,productId:'cloud',platform:'web',storage,gateway,device,tokenFactory:tokens,clock:()=>now});
let client=open();const pending=await client.beginExplicit();assert.ok(pending.request,pending.message);const request=pending.request;
const approval=sdk.signProductSessionApproval(registry,request,{accountSecret:'22'.repeat(32),scopes:request.scopes,expiresAt:request.expiresAt},now);
let publication;
try{publication=await gateway.publishReturn({requestId:'req_public_publication_0001',request,approval});}
catch(error){assert.equal(error.code,'ACCOUNT_POLICY_SOURCE_NOT_SUPPLIED');assert.equal(completes,0);process.stdout.write(JSON.stringify({referencePublicationCurrentPolicyRequired:true,actualSDKRefusal:error.code,fullReferencePositive:'NOT_SUPPLIED',noPolicyFabricated:true,actualWalletUI:false,realRootOrPQPolicy:false}));process.exit(0);}
const url=sdk.createProductSessionReferenceReturnURL(registry,request,publication,now);
const uncertain=await client.handleReturn(url);assert.equal(uncertain.status,'retry-required');assert.equal(uncertain.outcomeUnknown,true);assert.equal(completes,1);
const signsAfterLost=signs;assert.ok([...store.keys()].some(k=>k.endsWith(':completion')));
handler=new sdk.ProductSessionGatewayHttpHandler(registry,tokens,handler.snapshot());client=open();
const recovered=await client.restore(true);assert.equal(recovered.status,'connected',recovered.message);assert.equal(recovered.session.nonce,request.nonce);assert.equal(completes,1);assert.ok(introspections>=1);
// Recovery reads the same signed completion and does not sign it again.
// A fresh introspection HTTP proof is independently required after recovery.
assert.equal(signs,signsAfterLost+1);
const activeBinding=recovered.session.sessionBinding;const cold=open();assert.equal((await cold.restore(true)).session.sessionBinding,activeBinding);
const disconnected=await cold.disconnect();assert.equal(disconnected.revocationConfirmed,true);assert.equal((await open().restore(true)).status,'disconnected');assert.equal(completes,1);
process.stdout.write(JSON.stringify({originalReferenceReturn:true,actualSDKGatewayKernel:true,nonExtractableWebCryptoDevice:true,testOnlyStoragePort:true,completeResponseLostAfterCommit:true,coldGatewaySnapshotAndClientRecoveredSameSession:true,completionSentOnce:true,completionNotResigned:true,freshIntrospection:true,revokeConfirmed:true,actualMainUI:false,realRootOrPQPolicy:false}));
