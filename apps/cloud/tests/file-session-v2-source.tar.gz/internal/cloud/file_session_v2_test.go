package cloud

import (
	"context"
	"fmt"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func TestP04FileSessionV2RejectsBearerAndUnregistered(t *testing.T) {
	root := t.TempDir()
	s, err := New(Config{StatePath: filepath.Join(root, "state.json"), ObjectDir: filepath.Join(root, "objects")})
	if err != nil {
		t.Fatal(err)
	}
	envelope := testWalletEnvelope(t, s, "cloud", "v2_reject_legacy_original_0000000001", []string{"files.read"})
	s.cfg.WalletVerifier = acceptWallet{}
	token, _, err := s.CreateSession(context.Background(), envelope)
	if err != nil {
		t.Fatal(err)
	}
	server := NewServer(s)
	// PUBLIC unavailable adapter fixture. These cases must reject BEFORE any
	// process or network; the real SDK normal-case fixture is separate.
	v := &OriginalCloudFileSessionV2{code: "PUBLIC_UNAVAILABLE", host: "web4.ynxweb4.com"}
	if err := server.EnableOriginalCloudFileSessionV2(v); err != nil {
		t.Fatal(err)
	}
	h := server.Handler()
	for _, tc := range []struct {
		method, path string
		expected     int
	}{
		{"GET", "/api/v1/session", 401}, {"GET", "/api/v1/objects", 401}, {"POST", "/api/v1/session", 410}, {"POST", "/api/v1/session/challenge", 410}, {"DELETE", "/api/v1/session", 403}, {"GET", "/api/v1/objects/missing/links", 403}, {"GET", "/api/v1/metrics", 403},
	} {
		t.Run(tc.method+tc.path, func(t *testing.T) {
			r := httptest.NewRequest(tc.method, tc.path, nil)
			r.Host = "web4.ynxweb4.com"
			r.Header.Set("Authorization", "Bearer "+token)
			w := httptest.NewRecorder()
			h.ServeHTTP(w, r)
			if w.Code != tc.expected {
				t.Fatal(w.Code, w.Body.String())
			}
		})
	}
	if _, err := s.Authenticate(token); err != nil {
		t.Fatal("v2 refusal changed old preserved session", err)
	}
	if len(s.state.Sessions) != 1 {
		t.Fatal("v2 rejected request minted session")
	}
}

func TestP04FileSessionV2NormalPackageProbe(t *testing.T) {
	node, bridge := os.Getenv("YNX_CLOUD_FILE_V2_NODE"), os.Getenv("YNX_CLOUD_FILE_V2_BRIDGE")
	if node == "" || bridge == "" {
		t.Skip("original installed SDK/Node normal package not supplied to this source-only run")
	}
	cfg := OriginalCloudFileSessionV2Config{Node: node, Bridge: bridge, AuthorityEndpoint: "https://auth.example.test", CloudEndpoint: "https://web4.ynxweb4.com/api/v1"}
	if _, err := NewOriginalCloudFileSessionV2(context.Background(), cfg); err != nil {
		t.Fatal("normal SDK original implementation probe", err)
	}
	cfg.CloudEndpoint = "https://other.invalid/api/v1"
	if _, err := NewOriginalCloudFileSessionV2(context.Background(), cfg); err == nil {
		t.Fatal("cross-origin accepted")
	}
	cfg.CloudEndpoint = "https://web4.ynxweb4.com/api/v1"
	cfg.AuthorityEndpoint = "http://127.0.0.1"
	if _, err := NewOriginalCloudFileSessionV2(context.Background(), cfg); err == nil {
		t.Fatal("unqualified gateway accepted")
	}
}

func TestP04FileSessionV2UnavailableIsNotRevocation(t *testing.T) {
	root := t.TempDir()
	service, err := New(Config{StatePath: filepath.Join(root, "state.json"), ObjectDir: filepath.Join(root, "objects")})
	if err != nil {
		t.Fatal(err)
	}
	server := NewServer(service)
	server.fileSessionV2 = &OriginalCloudFileSessionV2{code: "PUBLIC_UNAVAILABLE", host: "web4.ynxweb4.com"}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	r := httptest.NewRequest("GET", "/api/v1/session", nil).WithContext(ctx)
	r.Host = "web4.ynxweb4.com"
	r.Header.Set("X-YNX-Product-Session-Proof-V2", "PUBLIC_NOT_AUTHORITY")
	w := httptest.NewRecorder()
	server.Handler().ServeHTTP(w, r)
	if w.Code != 503 || !strings.Contains(w.Body.String(), "retain the original operation") {
		t.Fatal(w.Code, w.Body.String())
	}
	if len(service.state.Sessions) != 0 || len(service.state.Nonces) != 0 {
		t.Fatal("unavailable verifier fabricated local state")
	}
}

func TestP04FileSessionV2AuthorityFailureDoesNotInventRevocation(t *testing.T) {
	node, err := exec.LookPath("node")
	if err != nil {
		t.Skip("Node normal runtime not supplied")
	}
	for _, tc := range []struct {
		code   string
		status int
	}{{"ACCOUNT_POLICY_SOURCE_NOT_SUPPLIED", 503}, {"NETWORK_UNAVAILABLE", 503}, {"SESSION_INACTIVE", 401}, {"INVALID_PROOF_HEADER", 401}} {
		t.Run(tc.code, func(t *testing.T) {
			root := t.TempDir()
			service, err := New(Config{StatePath: filepath.Join(root, "state.json"), ObjectDir: filepath.Join(root, "objects")})
			if err != nil {
				t.Fatal(err)
			}
			server := NewServer(service)
			// Negative IPC response fixture only; it can supply no successful identity.
			// The production constructor owns only the pinned original SDK source.
			server.fileSessionV2 = &OriginalCloudFileSessionV2{cfg: OriginalCloudFileSessionV2Config{Node: node, Bridge: filepath.Join(root, "PUBLIC_negative_fixture.mjs"), AuthorityEndpoint: "https://auth.example.test", CloudEndpoint: "https://web4.ynxweb4.com/api/v1"}, host: "web4.ynxweb4.com", code: fmt.Sprintf("process.stdout.write(JSON.stringify({ok:false,code:%q}));process.exitCode=1", tc.code)}
			r := httptest.NewRequest("GET", "/api/v1/session", nil)
			r.Host = "web4.ynxweb4.com"
			r.Header.Set("X-YNX-Product-Session-Proof-V2", "PUBLIC_NOT_AUTHORITY")
			w := httptest.NewRecorder()
			server.Handler().ServeHTTP(w, r)
			if w.Code != tc.status {
				t.Fatal(tc.code, w.Code, w.Body.String())
			}
			if tc.status == 503 && !strings.Contains(w.Body.String(), "retain the original operation") {
				t.Fatal("unknown authority failure declared revoked", w.Body.String())
			}
			if len(service.state.Sessions) != 0 || len(service.state.Nonces) != 0 {
				t.Fatal("failed authority fabricated session state")
			}
		})
	}
}
