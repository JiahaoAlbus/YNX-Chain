package cloud

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"time"
)

var ErrCloudFileSessionV2Unavailable = errors.New("original Cloud file Product Session v2 is unavailable")

type OriginalCloudFileSessionV2Config struct{ Node, Bridge, AuthorityEndpoint, CloudEndpoint string }
type OriginalCloudFileSessionV2 struct {
	cfg        OriginalCloudFileSessionV2Config
	code, host string
}

// Trusted normal package code paths only. Own the verified source bytes before
// executing; no request can supply code, a gateway URL, product or scopes.
func NewOriginalCloudFileSessionV2(ctx context.Context, cfg OriginalCloudFileSessionV2Config) (*OriginalCloudFileSessionV2, error) {
	if ctx == nil {
		return nil, ErrCloudFileSessionV2Unavailable
	}
	for _, p := range []string{cfg.Node, cfg.Bridge} {
		info, err := os.Lstat(p)
		if err != nil || !filepath.IsAbs(p) || !info.Mode().IsRegular() {
			return nil, ErrCloudFileSessionV2Unavailable
		}
	}
	u, err := url.Parse(cfg.CloudEndpoint)
	if err != nil || u.Scheme != "https" || u.Host != "web4.ynxweb4.com" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Path != "/api/v1" && u.Path != "/cloud/api/v1") {
		return nil, ErrCloudFileSessionV2Unavailable
	}
	gateway, err := url.Parse(cfg.AuthorityEndpoint)
	if err != nil || gateway.Scheme != "https" || gateway.Host == "" || gateway.User != nil || gateway.Port() != "" || gateway.Path != "" || gateway.RawQuery != "" || gateway.Fragment != "" {
		return nil, ErrCloudFileSessionV2Unavailable
	}
	entry, err := os.ReadFile(cfg.Bridge)
	if err != nil {
		return nil, ErrCloudFileSessionV2Unavailable
	}
	module, err := os.ReadFile(filepath.Join(filepath.Dir(cfg.Bridge), "file-session-v2-server.mjs"))
	if err != nil {
		return nil, ErrCloudFileSessionV2Unavailable
	}
	digest := func(b []byte) string { h := sha256.Sum256(b); return hex.EncodeToString(h[:]) }
	if digest(entry) != "541d5546e51639cf86fb2365569fda6265f28ad3dfc6472da9d61bee781e3bbb" || digest(module) != "7a1b775dcdd55b0ded2a0a94110ba9a357b30780fb91e4f7c49179e27d7dea0f" {
		return nil, ErrCloudFileSessionV2Unavailable
	}
	importLine := "import {createOriginalCloudFileSessionV2Server} from './file-session-v2-server.mjs';\n"
	if !bytes.HasPrefix(entry, []byte(importLine)) {
		return nil, ErrCloudFileSessionV2Unavailable
	}
	v := &OriginalCloudFileSessionV2{cfg: cfg, code: string(module) + "\n" + string(entry[len(importLine):]), host: u.Host}
	if _, err = v.call(ctx, map[string]any{"probe": true}); err != nil {
		return nil, err
	}
	return v, nil
}

type fileV2LimitedOutput struct{ bytes.Buffer }

func (w *fileV2LimitedOutput) Write(b []byte) (int, error) {
	if w.Len()+len(b) > 64<<10 {
		return 0, ErrCloudFileSessionV2Unavailable
	}
	return w.Buffer.Write(b)
}
func (v *OriginalCloudFileSessionV2) call(ctx context.Context, input any) (json.RawMessage, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	raw, err := json.Marshal(input)
	if err != nil || len(raw) > 64<<10 {
		return nil, ErrCloudFileSessionV2Unavailable
	}
	bounded, cancel := context.WithTimeout(ctx, 8*time.Second)
	defer cancel()
	cmd := exec.CommandContext(bounded, v.cfg.Node, "--input-type=module", "-e", v.code, "original-cloud-file-session-v2", v.cfg.AuthorityEndpoint, v.cfg.CloudEndpoint)
	cmd.Dir = filepath.Dir(v.cfg.Bridge)
	cmd.Env = []string{"PATH=/usr/bin:/bin"}
	cmd.Stdin = bytes.NewReader(raw)
	var out fileV2LimitedOutput
	cmd.Stdout = &out
	cmd.Stderr = io.Discard
	runErr := cmd.Run()

	if err = ctx.Err(); err != nil {
		return nil, err
	}
	var result struct {
		OK      bool            `json:"ok"`
		Code    string          `json:"code"`
		Session json.RawMessage `json:"session"`
	}
	if json.Unmarshal(out.Bytes(), &result) != nil {
		return nil, ErrCloudFileSessionV2Unavailable
	}
	if !result.OK {
		switch result.Code {
		case "ACCOUNT_POLICY_SOURCE_NOT_SUPPLIED", "NETWORK_UNAVAILABLE", "CLOCK_UNAVAILABLE", "INTERNAL", "INVALID_GATEWAY_RESPONSE", "ORIGINAL_PRIVATE_SERVICE_NOT_SUPPLIED", "ORIGINAL_PRIVATE_OUTCOME_UNKNOWN", "CLOUD_FILE_SESSION_UNAVAILABLE":
			return nil, ErrCloudFileSessionV2Unavailable
		}
		if result.Code != "" {
			return nil, ErrDenied
		}
		return nil, ErrCloudFileSessionV2Unavailable
	}
	if runErr != nil {
		return nil, ErrCloudFileSessionV2Unavailable
	}
	return result.Session, nil
}

func (v *OriginalCloudFileSessionV2) authorize(ctx context.Context, r *http.Request, scopes []string, now func() time.Time) (Session, error) {
	if r.Host != v.host || len(r.Header.Values("X-YNX-Product-Session-Proof-V2")) != 1 || len(r.Header.Values("Origin")) > 1 || r.Header.Get("Authorization") != "" {
		return Session{}, ErrDenied
	}
	before := now().UTC()
	var origin any
	if values := r.Header.Values("Origin"); len(values) == 1 {
		origin = values[0]
	}
	raw, err := v.call(ctx, map[string]any{"proofHeader": r.Header.Get("X-YNX-Product-Session-Proof-V2"), "origin": origin, "method": r.Method, "path": r.URL.EscapedPath(), "requiredScopes": scopes})
	if err != nil {
		return Session{}, err
	}
	var data struct {
		Version, SessionBinding, ProductID, ClientID, ApplicationID, Origin, Callback, Account, DeviceKey, RequestDigest, IssuedAt, ExpiresAt string
		Scopes                                                                                                                                []string
	}
	// JSON names containing ID are explicitly retained below; the SDK owns all
	// protocol versions and cryptographic/current validation, not this mapping.
	var doc map[string]json.RawMessage
	if json.Unmarshal(raw, &doc) != nil {
		return Session{}, ErrDenied
	}
	field := func(k string) string { var x string; json.Unmarshal(doc[k], &x); return x }
	data.SessionBinding = field("sessionBinding")
	data.Account = field("account")
	data.ProductID = field("productId")
	data.ClientID = field("clientId")
	data.ApplicationID = field("applicationId")
	data.Origin = field("origin")
	data.Callback = field("callback")
	data.DeviceKey = field("deviceKey")
	data.RequestDigest = field("requestDigest")
	data.IssuedAt = field("issuedAt")
	data.ExpiresAt = field("expiresAt")
	json.Unmarshal(doc["scopes"], &data.Scopes)
	issued, e1 := time.Parse(time.RFC3339Nano, data.IssuedAt)
	expires, e2 := time.Parse(time.RFC3339Nano, data.ExpiresAt)
	after := now().UTC()
	if e1 != nil || e2 != nil || ctx.Err() != nil || after.Before(before) || issued.After(after) || !expires.After(after) || !validAccount(data.Account) || data.SessionBinding == "" || data.ProductID != "cloud" || data.ClientID != "ynx-cloud-web-v1" || data.ApplicationID != "com.ynxweb4.cloud.web" || data.Origin != "https://web4.ynxweb4.com" || data.Callback != "https://web4.ynxweb4.com/wallet-auth/callback" {
		return Session{}, ErrDenied
	}
	for _, scope := range data.Scopes {
		if scope != "files.read" && scope != "files.write" {
			return Session{}, ErrDenied
		}
	}
	for _, required := range scopes {
		found := false
		for _, scope := range data.Scopes {
			found = found || scope == required
		}
		if !found {
			return Session{}, ErrDenied
		}
	}
	return Session{SessionBinding: data.SessionBinding, RequestDigest: data.RequestDigest, Account: data.Account, Product: "cloud", ClientID: data.ClientID, BundleID: data.ApplicationID, Callback: data.Callback, DeviceKey: data.DeviceKey, Scopes: append([]string(nil), data.Scopes...), IssuedAt: issued, ExpiresAt: expires}, nil
}

func (s *Server) EnableOriginalCloudFileSessionV2(v *OriginalCloudFileSessionV2) error {
	if v == nil || v.code == "" || s.fileSessionV2 != nil {
		return ErrCloudFileSessionV2Unavailable
	}
	s.fileSessionV2 = v
	return nil
}
func originalCloudFileV2Scopes(pattern string) []string {
	switch pattern {
	case "GET /api/v1/session", "GET /api/v1/objects", "GET /api/v1/objects/{id}", "GET /api/v1/objects/{id}/content", "GET /api/v1/objects/{id}/versions", "GET /api/v1/object-operations/{request}", "GET /api/v1/quota":
		return []string{"files.read"}
	case "POST /api/v1/objects", "PUT /api/v1/objects/{id}/content", "POST /api/v1/objects/{id}/versions/{version}/restore", "POST /api/v1/objects/{id}/star", "POST /api/v1/objects/{id}/trash", "POST /api/v1/objects/{id}/restore":
		return []string{"files.write"}
	default:
		return nil
	}
}
