package cloud

import (
	"context"
	"path/filepath"
	"testing"
	"time"
)

type p04WalletSessionVerifierFunc func(context.Context, WalletSessionEnvelope) (CentralSessionClaims, error)

func (f p04WalletSessionVerifierFunc) Verify(c context.Context, e WalletSessionEnvelope) (CentralSessionClaims, error) {
	return f(c, e)
}

func TestP04WalletSessionPostVerifyCurrent(t *testing.T) {
	for _, mode := range []string{"challenge-expired", "envelope-expired", "clock-regressed", "canceled", "pending-changed", "healthy"} {
		t.Run(mode, func(t *testing.T) {
			// PUBLIC verifier seam only. This is a currentness regression for the
			// original Cloud commit, not classic authorization or genuine Wallet proof.
			now := time.Date(2026, 11, 8, 0, 0, 0, 0, time.UTC)
			root := t.TempDir()
			s, err := New(Config{StatePath: filepath.Join(root, "state.json"), ObjectDir: filepath.Join(root, "objects"), Now: func() time.Time { return now }})
			if err != nil {
				t.Fatal(err)
			}
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			envelope := testWalletEnvelope(t, s, "cloud", "original_session_postverify_00000001", []string{"files.read"})
			s.cfg.WalletVerifier = p04WalletSessionVerifierFunc(func(c context.Context, e WalletSessionEnvelope) (CentralSessionClaims, error) {
				claims, err := (acceptWallet{}).Verify(c, e)
				switch mode {
				case "challenge-expired":
					now = now.Add(3*time.Minute + time.Nanosecond)
				case "envelope-expired":
					now = now.Add(5 * time.Minute)
				case "clock-regressed":
					now = now.Add(-time.Minute)
				case "canceled":
					cancel()
				case "pending-changed":
					p := s.state.WalletChallenges[e.GatewayCompletion.Challenge.Challenge]
					p.Nonce = "changed_original_nonce"
					s.state.WalletChallenges[e.GatewayCompletion.Challenge.Challenge] = p
				}
				return claims, err
			})
			token, _, err := s.CreateSession(ctx, envelope)
			if mode == "healthy" {
				if err != nil || token == "" {
					t.Fatal("healthy completion rejected", err)
				}
				return
			}
			if err == nil || token != "" || len(s.state.Sessions) != 0 || len(s.state.Nonces) != 0 {
				t.Fatal("stale remote verification minted original session", mode, err, len(s.state.Sessions), len(s.state.Nonces))
			}
			if _, ok := s.state.WalletChallenges[envelope.GatewayCompletion.Challenge.Challenge]; !ok {
				t.Fatal("rejected completion consumed pending original")
			}
		})
	}
}
