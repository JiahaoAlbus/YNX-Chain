package cloud
import("context";"strings";"testing";"time")
const owner = "ynx1qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqp7h6v"
const viewer = "ynx1pppppppppppppppppppppppppppppppp5f3cz"

type acceptWallet struct{}

func (acceptWallet) Verify(_ context.Context, e WalletSessionEnvelope) (CentralSessionClaims, error) {
	a := e.WalletApproval
	return CentralSessionClaims{VerifierVersion: "wallet-auth-v1", SessionBinding: strings.Repeat("b", 64), ProductClientID: a.ProductClientID, BundleID: a.BundleID, ProductDeviceAlgorithm: a.ProductDeviceAlgorithm, RequestDigest: a.RequestDigest, Account: a.Account, Scopes: a.GrantedScopes, IssuedAt: a.IssuedAt, ExpiresAt: a.ExpiresAt}, nil
}

func testWalletEnvelope(t *testing.T, s *Service, product, nonce string, scopes []string) WalletSessionEnvelope {
	t.Helper()
	now := s.cfg.Now().UTC().Truncate(time.Millisecond)
	client, bundle, callback := "ynx-cloud-mobile-v1", "com.ynxweb4.cloud", "ynxcloud://wallet-auth/callback"
	if product == "docs" {
		client, bundle, callback = "ynx-docs-mobile-v1", "com.ynxweb4.docs", "ynxdocs://wallet-auth/callback"
	}
	if len(nonce) < 32 {
		nonce += strings.Repeat("x", 32-len(nonce))
	}
	r := WalletAuthorizationRequest{Version: "1", Nonce: nonce, ChainID: ChainID, RequestingProduct: product, ProductClientID: client, BundleID: bundle, ProductDeviceAlgorithm: "p256-sha256", ProductDeviceKey: "AzrThhqVYhOSUWu1k-8FWD7S5YZvXLYmCjAXI3_Ym5Cv", Callback: callback, Scopes: scopes, Purpose: "Use explicitly authorized YNX content on this device.", IssuedAt: now.Add(-time.Second).Format("2006-01-02T15:04:05.000Z"), ExpiresAt: now.Add(4 * time.Minute).Format("2006-01-02T15:04:05.000Z")}
	digest, err := authorizationDigest(r)
	if err != nil {
		t.Fatal(err)
	}
	a := WalletApproval{Version: "1", RequestDigest: digest, Nonce: r.Nonce, ChainID: r.ChainID, RequestingProduct: r.RequestingProduct, ProductClientID: r.ProductClientID, BundleID: r.BundleID, ProductDeviceAlgorithm: r.ProductDeviceAlgorithm, ProductDeviceKey: r.ProductDeviceKey, Callback: r.Callback, Account: owner, AccountPublicKey: strings.Repeat("0", 66), GrantedScopes: r.Scopes, Purpose: r.Purpose, IssuedAt: now.Format("2006-01-02T15:04:05.000Z"), ExpiresAt: r.ExpiresAt, WalletSignature: strings.Repeat("0", 128)}
	c, err := s.CreateWalletChallenge(r, a)
	if err != nil {
		t.Fatal(err)
	}
	return WalletSessionEnvelope{AuthorizationRequest: r, WalletApproval: a, GatewayCompletion: GatewayCompletion{Challenge: c, DeviceSignature: strings.Repeat("A", 96)}}
}
