export type Product = "cloud" | "docs";
export type ObjectKind = "file" | "folder" | "doc";
export interface CloudObject { id: string; product: Product; owner: string; parentId?: string; kind: ObjectKind; name: string; mime?: string; size: number; hash?: string; version: number; starred: boolean; trashedAt?: string; createdAt: string; updatedAt: string }
export interface ObjectPage { items: CloudObject[]; nextCursor?: string; limit: number; scanned: number }
export interface ClientOptions { endpoint: string; product: Product; getAccessToken?: () => string | Promise<string>; getDeploymentRequestHeaders?: (request: Readonly<{ method: string; path: string; url: string; operationRequestId: string; bodyOriginal?: Uint8Array; contentType?: string }>, originalRequestContext?: Readonly<{signal: AbortSignal}>) => HeadersInit | Promise<HeadersInit>; fetch?: typeof fetch; maxRetries?: number }
export interface RequestOptions { method?: string; body?: unknown; headers?: HeadersInit; signal?: AbortSignal; response?: "json" | "response" | "bytes" | "text"; retry?: number; redirect?: RequestRedirect }
export interface IDEDeploymentBinding { projectId: string; version: string; contentDigest: string; publishPurpose: string; targetEnvironment: string; byteSize: number }
export interface IDEDeploymentOperation { requestId: string; binding: IDEDeploymentBinding; manifestSHA256: string; approvalSHA256: string; publisherId: string; resourceId: string; state: "unknown" | "running" | "completed" | "failed"; deploymentId?: string; runtimeUrl?: string; runtimeKind?: string; runtimeHandle?: string; runtimeSeconds?: number; resourceApprovalRef?: string; exitCode?: number; createdAt: string; updatedAt: string; logs: Array<{ at: string; source: "cloud-operation"; message: string }> }
export interface IDEDeploymentReadOptions { headers?: HeadersInit; signal?: AbortSignal; originalRequestContext?: Readonly<{signal: AbortSignal}> }
export declare class YNXCloudDeploymentUnknownError extends YNXCloudError { operationRequestId: string; state: "unknown" }
export interface ClientEncryptionContext { product: Product; account: string; contextId: string; version?: number }
export interface ClientEncryptionEnvelope { schemaVersion: 1; mediaType: "application/vnd.ynx.cloud-encrypted+json"; algorithm: "AES-256-GCM"; context: Required<ClientEncryptionContext>; nonce: string; ciphertext: string; ciphertextSha256: string; plaintextBytes: number }
export interface ClientEncryptionMetadata { clientSide: true; algorithm: "AES-256-GCM"; keyHint: string; recoveryPolicy: string }
export interface ClientEncryptionResult { content: Uint8Array; contentType: "application/vnd.ynx.cloud-encrypted+json"; encryption: ClientEncryptionMetadata; envelope: ClientEncryptionEnvelope }
export interface ClientRecoveryPackage { schemaVersion: 1; mediaType: "application/vnd.ynx.cloud-key-recovery+json"; algorithm: "AES-256-GCM"; context: Required<ClientEncryptionContext>; generation: number; recoveryPolicyId: string; keyHint: string; keyFingerprint: string; nonce: string; wrappedKey: string; wrappedKeySha256: string }
export interface ClientRecoveryPackageResult { content: Uint8Array; contentType: "application/vnd.ynx.cloud-key-recovery+json"; recoveryPackage: ClientRecoveryPackage }
export interface RecoveredClientKey { key: string; generation: number; recoveryPolicyId: string; keyHint: string; context: Required<ClientEncryptionContext> }
export interface RotatedClientEncryptionResult extends ClientEncryptionResult { previousContext: Required<ClientEncryptionContext>; nextContext: Required<ClientEncryptionContext>; previousKeyFingerprint: string; nextKeyFingerprint: string }
export declare function generateClientSideEncryptionKey(): Promise<string>;
export declare function generateClientSideRecoveryKey(): Promise<string>;
export declare function encryptClientSideContent(options: { content: string | ArrayBuffer | ArrayBufferView; key: string; context: ClientEncryptionContext; recoveryPolicy: string; keyHint?: string }): Promise<ClientEncryptionResult>;
export declare function decryptClientSideContent(options: { content: string | ArrayBuffer | ArrayBufferView; key: string; expectedContext: ClientEncryptionContext }): Promise<Uint8Array>;
export declare function createClientSideRecoveryPackage(options: { key: string; recoveryKey: string; context: ClientEncryptionContext; generation?: number; recoveryPolicyId: string; keyHint?: string }): Promise<ClientRecoveryPackageResult>;
export declare function recoverClientSideEncryptionKey(options: { recoveryPackage: string | ArrayBuffer | ArrayBufferView; recoveryKey: string; expectedContext: ClientEncryptionContext; expectedRecoveryPolicyId: string; minimumGeneration?: number }): Promise<RecoveredClientKey>;
export declare function rotateClientSideEncryptedContent(options: { content: string | ArrayBuffer | ArrayBufferView; currentKey: string; nextKey: string; expectedContext: ClientEncryptionContext; nextVersion: number; recoveryPolicy: string; keyHint?: string }): Promise<RotatedClientEncryptionResult>;
export declare class YNXCloudError extends Error { status: number; requestId: string; errorId: string; retryAfter: number; operationRequestId?: string }
export declare class YNXCloudClient {
  constructor(options: ClientOptions);
  readonly endpoint: string; readonly product: Product;
  request(path: string, options?: RequestOptions): Promise<any>;
  submitIDEDeployment(input: { requestId: string; manifest: string | ArrayBuffer | ArrayBufferView; artifact: Blob | ArrayBuffer | ArrayBufferView; approval: string | ArrayBuffer | ArrayBufferView; headers?: HeadersInit; signal?: AbortSignal }): Promise<IDEDeploymentOperation>;
  getIDEDeploymentStatus(requestId: string, options?: IDEDeploymentReadOptions): Promise<IDEDeploymentOperation>;
  getIDEDeploymentLogs(requestId: string, options?: IDEDeploymentReadOptions): Promise<{ requestId: string; operationLogs: IDEDeploymentOperation["logs"]; runtimeLogs: string; runtimeLogSource: "original-resource" }>;
  list(options?: Record<string, string | number | boolean | undefined>): Promise<ObjectPage>;
  getObject(id: string): Promise<CloudObject>; createObject(input: unknown): Promise<CloudObject>; deleteObject(id: string): Promise<unknown>;
  content(id: string, options?: { range?: string; signal?: AbortSignal }): Promise<Response>;
  versions(id: string): Promise<unknown[]>; restoreVersion(id: string, version: number): Promise<CloudObject>; saveDocument(id: string, input: unknown): Promise<CloudObject>;
  star(id: string, starred: boolean): Promise<CloudObject>; trash(id: string): Promise<CloudObject>; restore(id: string): Promise<CloudObject>;
  quota(): Promise<{ usedBytes: number; limitBytes: number; claim: string }>; usage(): Promise<UsageReport>; audit(): Promise<unknown[]>; exportData(): Promise<Response>;
  eraseProductData(): Promise<DataErasureReceipt>; erasureReceipts(): Promise<DataErasureReceipt[]>;
  deletionRecords(): Promise<unknown[]>; retryDeletion(id: string): Promise<unknown>;
  initiateMultipart(input: unknown): Promise<unknown>; multipartStatus(id: string): Promise<unknown>; putMultipartPart(id: string, part: number, bytes: ArrayBuffer | ArrayBufferView, sha256: string): Promise<unknown>; completeMultipart(id: string, parts: number[]): Promise<CloudObject>; cancelMultipart(id: string): Promise<unknown>;
  initiateDirectUpload(input: unknown): Promise<unknown>; directUploadStatus(id: string): Promise<unknown>; completeDirectUpload(id: string): Promise<CloudObject>; cancelDirectUpload(id: string): Promise<unknown>;
  createAIJob(input: unknown): Promise<unknown>; getAIJob(id: string): Promise<unknown>; cancelAIJob(id: string): Promise<unknown>; reviewAIJob(id: string, decision: "applied" | "rejected"): Promise<unknown>;
}

export interface UsageReport {
  schemaVersion: 2; source: string; authority: string; asOf: string; owner: string; product: Product; storageBytes: number; freeQuotaBytes: number;
  counters: { owner: string; product: Product; ingressBytes: number; egressBytes: number; scanBytes: number; aiInputUnits: number; aiJobs: number; backupBytes: number; replicaBytes: number; storageByteSeconds: number; storageMeteredAt?: string; storageCoverageStartsAt?: string; updatedAt: string };
  pricingStatus: "not-configured-no-charge"; providerCostMinor: 0; protocolFeeMinor: 0; treasuryMinor: 0; burnMinor: 0; userChargeMinor: 0; refundMinor: 0;
  coverage: Record<string, string>;
}

export interface DataErasureReceipt {
  schemaVersion: 1; id: string; ownerHash: string; product: Product; status: "logical-erasure-complete-known-provider-deletions-complete" | "logical-erasure-complete-provider-deletion-pending";
  source: string; authority: string; requestedAt: string; updatedAt: string; deleted: Record<string, number>; completedBlobs: number; pendingBlobs: number; retained: Record<string, string>; coverage: string;
}
