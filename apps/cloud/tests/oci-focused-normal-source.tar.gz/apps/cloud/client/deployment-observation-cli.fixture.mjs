import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {YNXCloudClient,YNXCloudDeploymentUnknownError} from '../sdk/index.js';
import {CloudDeploymentClient} from './deployment-client.mjs';
import {submitDeploymentReceipt,runDeploymentCommand} from './deployment-workflow.mjs';
let input='';for await(const b of process.stdin)input+=b;
const {base,root,stage,actualOCI=false}=JSON.parse(input),file=join(root,'original.json');
const client=new CloudDeploymentClient(new YNXCloudClient({endpoint:base,product:'cloud',maxRetries:0,getDeploymentRequestHeaders:async()=>(actualOCI?{'X-P04-CI-Identity':'PUBLIC_OWNER'}:{'X-Public-Fixture':'PUBLIC_NOT_AUTHORITY'})}));
if(stage==='lost'){
 const artifact=Buffer.from(actualOCI?"import http from 'node:http';import fs from 'node:fs';import crypto from 'node:crypto';const body=JSON.stringify({version:'A',artifactSHA256:crypto.createHash('sha256').update(fs.readFileSync('/app/artifact.mjs')).digest('hex')});const s=http.createServer((q,r)=>r.end(body));console.log('P04_J23_ACTUAL_VERSION_A');s.listen(18081,'127.0.0.1');setTimeout(()=>s.close(),90000);":'PUBLIC fixture, not an actual runtime');
 const manifest=Buffer.from(JSON.stringify({projectId:'PUBLIC_PROJECT',version:'A',contentDigest:createHash('sha256').update(artifact).digest('hex'),publishPurpose:'deploy',targetEnvironment:actualOCI?'PUBLIC_ISOLATED_CI':'PUBLIC_ENV',byteSize:artifact.length}));
 const prepared=client.prepare({requestId:'req_observation_original_0001',manifest,artifact,approval:Buffer.from(actualOCI?'PUBLIC_AUTHORED_APPROVAL:req_observation_original_0001':'PUBLIC_NOT_A_SIGNATURE'),expectedSlotRevision:'0'});
 await assert.rejects(submitDeploymentReceipt(client,prepared,file),e=>e instanceof YNXCloudDeploymentUnknownError);
 assert.equal(JSON.parse(await readFile(file,'utf8')).state,'UNKNOWN');
}else if(stage==='cold'||stage==='records-cold'){
 const status=await runDeploymentCommand(client,['reconcile',file]);assert.equal(status.state,'running');
 if(stage==='cold')await runDeploymentCommand(client,['usage',file]);
 const before=await readFile(file);
 const result=await runDeploymentCommand(client,['inspect',file]);
 assert.equal(result.operation.deploymentId,status.deploymentId);assert.equal(result.logs.deploymentId,status.deploymentId);assert.equal(result.usage.instanceId,status.deploymentId);
 assert.equal(result.operation.binding.version,'A');assert.equal(result.publicReadiness,'NOT_ASSERTED');assert.equal(result.SourceAdmission,false);
 const stored=await runDeploymentCommand(client,['usage-records',file]);assert.equal(stored.latest.sampleSeq,result.usage.latest.sampleSeq);
 if(!actualOCI)assert.equal(stored.latest.sampleSeq,'1793491200000000000');
 assert.deepEqual(await readFile(file),before);
}else if(['artifact-denied','logs-denied','usage-denied'].includes(stage)){
 const before=await readFile(file);
 const commands=stage==='artifact-denied'?['runtime','logs','usage']:stage==='logs-denied'?['logs']:['usage-records'];
 for(const command of commands)await assert.rejects(runDeploymentCommand(client,[command,file]));
 assert.deepEqual(await readFile(file),before);
}else if(stage==='unavailable'){
 const before=await readFile(file);const status=await runDeploymentCommand(client,['status',file]);assert.equal(status.state,'running');
 await assert.rejects(runDeploymentCommand(client,['runtime',file]),e=>e.status===503);
 await assert.rejects(runDeploymentCommand(client,['inspect',file]),e=>e.status===503);
 const after=JSON.parse(await readFile(file));assert.equal(after.operation.deploymentId,JSON.parse(before).operation.deploymentId);
}else throw Error('Unknown observation stage');
process.stdout.write(JSON.stringify({stage,publicFixture:true,actualOCI}));
