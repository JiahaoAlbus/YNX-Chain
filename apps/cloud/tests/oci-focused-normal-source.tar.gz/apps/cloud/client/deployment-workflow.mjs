import {constants} from 'node:fs';
import {open,lstat,rename,unlink} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {CloudDeploymentClient} from './deployment-client.mjs';
import {YNXCloudDeploymentUnknownError} from '../sdk/index.js';

const LIMIT=32768;
async function privateParent(path){const p=dirname(resolve(path)),s=await lstat(p);if(!s.isDirectory()||s.isSymbolicLink()||(s.mode&0o077)!==0||process.getuid&&s.uid!==process.getuid())throw Error('Private original deployment directory required');return p;}
async function syncDirectory(path){const f=await open(await privateParent(path),constants.O_RDONLY|constants.O_NOFOLLOW);try{await f.sync();}finally{await f.close();}}
async function create(path,value){const bytes=JSON.stringify(value)+'\n';if(Buffer.byteLength(bytes)>LIMIT)throw Error('Deployment receipt exceeds bound');await privateParent(path);const f=await open(path,constants.O_CREAT|constants.O_EXCL|constants.O_WRONLY|constants.O_NOFOLLOW,0o600);try{await f.writeFile(bytes);await f.sync();}finally{await f.close();}await syncDirectory(path);}
async function replace(path,value){const temp=path+'.'+randomUUID()+'.tmp';try{await create(temp,value);await rename(temp,path);await syncDirectory(path);}finally{await unlink(temp).catch(e=>{if(e.code!=='ENOENT')throw e;});}}
async function readRaw(path){
 await privateParent(path);const f=await open(path,constants.O_RDONLY|constants.O_NOFOLLOW|constants.O_NONBLOCK);
 try{const s=await f.stat();if(!s.isFile()||s.size>LIMIT||s.nlink!==1||(s.mode&0o077)!==0||(process.getuid&&s.uid!==process.getuid()))throw Error('Private original deployment receipt required');
  const buffer=Buffer.alloc(LIMIT+1);let size=0;while(size<buffer.length){const {bytesRead}=await f.read(buffer,size,buffer.length-size,null);if(!bytesRead)break;size+=bytesRead;}
  const after=await f.stat(),named=await lstat(path);
  if(size>LIMIT||named.isSymbolicLink()||named.dev!==s.dev||named.ino!==s.ino||named.nlink!==1||after.size!==s.size||after.mtimeMs!==s.mtimeMs||after.ctimeMs!==s.ctimeMs)throw Error('Original deployment receipt changed during read');return JSON.parse(buffer.subarray(0,size).toString('utf8'));
 }finally{await f.close();}
}
function terminalMatches(receipt,terminal){
 if(terminal?.schema!=='cloud-original-deployment-terminal/2'||terminal.endpoint!==receipt.endpoint||!isDeepStrictEqual(terminal.selection,receipt.selection)||terminal.operation?.requestId!==receipt.selection.requestId||!['completed','failed'].includes(terminal.operation.state))throw Error('Original deployment terminal record differs');
 return terminal;
}
async function terminalFor(file,receipt){
 if(receipt.schema!=='cloud-original-deployment-receipt/2')return null;
 try{return terminalMatches(receipt,await readRaw(file+'.terminal'));}catch(e){if(e.code==='ENOENT')return null;throw e;}
}
async function read(path){
 let value;
 try{value=await readRaw(path);}catch(e){
  if(e.code!=='ENOENT')throw e;
  const terminal=await readRaw(path+'.terminal');
  value={schema:'cloud-original-deployment-receipt/2',endpoint:terminal.endpoint,selection:terminal.selection,state:'OBSERVED',operation:terminal.operation};
 }
 const terminal=await terminalFor(path,value);
 return terminal?{...value,state:'OBSERVED',operation:terminal.operation}:value;
}
async function clientVersion(client){
 if(client instanceof CloudDeploymentClient)return '1';
 // Keep the legacy standalone caller independent of the V2 DATA package.
 // This is a fixed owned module, never a request-selected provider.
 const {CloudDeploymentV2Client}=await import('./deployment-v2-client.mjs');
 if(client instanceof CloudDeploymentV2Client)return '2';
 throw Error('Original deployment client required');
}
async function receiptFor(client,value){
 const version=await clientVersion(client);
 if(value?.schema!==`cloud-original-deployment-receipt/${version}`||value.endpoint!==client.endpoint||!['PREPARED','UNKNOWN','OBSERVED'].includes(value.state)||!value.selection||typeof value.selection.requestId!=='string'||(version==='2'?value.selection.manifestVersion!=='2':value.selection.manifestVersion!==undefined))throw Error('Receipt is not the original Cloud endpoint/operation version');
 return value;
}
function observation(operation){
 // Full immutable selection is already retained once. Keep logs and duplicate
 // manifests out of the bounded receipt; normal reads return the full result.
 const result={};for(const key of ['requestId','state','deploymentId','resourceId','slotRevision','runtimeKind','runtimeUrl','exitCode','createdAt','updatedAt'])if(operation[key]!==undefined)result[key]=operation[key];return result;
}
function observedReceipt(receipt,operation){
 const value={...receipt,state:'OBSERVED',operation:receipt.schema.endsWith('/2')?observation(operation):operation};
 // Preserve ordinary V1 snapshots. A large response must not corrupt the
 // bounded recovery file; the complete result still returns to the caller.
 if(Buffer.byteLength(JSON.stringify(value)+'\n')>LIMIT)value.operation=observation(operation);
 return value;
}
const observedIdentity=op=>JSON.stringify(['requestId','state','deploymentId','resourceId','slotRevision','runtimeKind','runtimeUrl','exitCode'].map(k=>op[k]));
async function saveObserved(file,receipt,operation){
 if(receipt.schema==='cloud-original-deployment-receipt/2'&&['completed','failed'].includes(operation.state)){
  const terminal={schema:'cloud-original-deployment-terminal/2',endpoint:receipt.endpoint,selection:receipt.selection,operation:observation(operation)};
  try{await create(file+'.terminal',terminal);}catch(e){if(e.code!=='EEXIST')throw e;}
 }
 const terminal=await terminalFor(file,receipt);
 if(terminal&&observedIdentity(terminal.operation)!==observedIdentity(operation))throw new YNXCloudDeploymentUnknownError(receipt.selection.requestId);
 await replace(file,observedReceipt(receipt,operation));
 // An overlapping terminal publication can win after the first check.
 // Restore its immutable metadata and refuse the stale return, without locks,
 // signer acquisition, server writes or cached authorization success.
 const after=await terminalFor(file,receipt);
 if(after&&observedIdentity(after.operation)!==observedIdentity(operation)){
  await replace(file,observedReceipt(receipt,after.operation));
  throw new YNXCloudDeploymentUnknownError(receipt.selection.requestId);
 }
}

// Receipt is DATA for recovery, never an approval. It contains no signer,
// token, Source or raw approval/manifest/artifact bytes. New submission owns an
// exclusive file; every existing receipt, including PREPARED, is query-only.
export async function submitDeploymentReceipt(client,prepared,file,{signal}={}){
 if(signal?.aborted)throw signal.reason;
 const version=await clientVersion(client);
 const receipt={schema:`cloud-original-deployment-receipt/${version}`,endpoint:client.endpoint,selection:structuredClone(prepared.selection),state:'PREPARED'};
 await receiptFor(client,receipt);
 if(signal?.aborted)throw signal.reason;
 try{
  const saved=await receiptFor(client,await read(file));
  if(!isDeepStrictEqual(saved.selection,receipt.selection))throw Error('Original deployment receipt selection changed; no resubmission');
  return reconcileDeploymentReceipt(client,file,{signal});
 }catch(e){if(e.code!=='ENOENT')throw e;}
 try{await create(file,receipt);}catch(e){if(e.code!=='EEXIST')throw e;const saved=await receiptFor(client,await read(file));if(!isDeepStrictEqual(saved.selection,receipt.selection))throw Error('Original deployment receipt selection changed; no resubmission');return reconcileDeploymentReceipt(client,file,{signal});}
 receipt.state='UNKNOWN';await replace(file,receipt); // durable BEFORE any foreign Source/HTTP action
 const returned=version==='2'?await client.submitOriginalE11(prepared,{signal}):await client.submitPrepared(prepared,{signal});
 const operation=version==='2'?returned:returned.operation;
 if(signal?.aborted)throw signal.reason;
 await saveObserved(file,receipt,operation);return operation;
}
export async function reconcileDeploymentReceipt(client,file,{signal,originalRequestContext}={}){
 if(signal?.aborted)throw signal.reason;
 const receipt=await receiptFor(client,await read(file));
 const operation=await client.lookupOriginal(receipt.selection,{signal,originalRequestContext});
 if(signal?.aborted)throw signal.reason;
 await saveObserved(file,receipt,operation);return operation;
}

// Adopt only an already selected original operation (for example from the
// IDE's existing outbox). This cannot prepare/sign/send a deployment. A 404
// retains UNKNOWN and never turns recovery into a fresh submission.
export async function recoverDeploymentReceipt(client,selection,file,{signal,originalRequestContext}={}){
 if(signal?.aborted)throw signal.reason;
 const version=await clientVersion(client);
 const receipt={schema:`cloud-original-deployment-receipt/${version}`,endpoint:client.endpoint,selection:structuredClone(selection),state:'UNKNOWN'};
 await receiptFor(client,receipt);
 if(signal?.aborted)throw signal.reason;
 try{await create(file,receipt);}catch(e){
  if(e.code!=='EEXIST')throw e;
  const saved=await receiptFor(client,await read(file));
  if(!isDeepStrictEqual(saved.selection,receipt.selection))throw Error('Original deployment receipt selection changed; no recovery substitution');
 }
 return reconcileDeploymentReceipt(client,file,{signal,originalRequestContext});
}

// Same-process CLI entry for the original normal IDE/Wallet bootstrap. It
// requires the actual original SDK client, and does not load arbitrary provider
// modules or convert an ordinary session into a deployment proof factory.
export async function runDeploymentCommand(client,args,{signal,originalRequestContext}={}){
 if(signal?.aborted)throw signal.reason;
 const [command,file,...rest]=args;if(!file)throw Error('Original deployment command and private receipt required');
 const receipt=await receiptFor(client,await read(file));
 if(command==='bill-original'){
  if(rest.length!==1)throw Error('bill-original PRIVATE_RECEIPT UTC_DAY');
  return await clientVersion(client)==='2'?client.billOriginal(receipt.selection,rest[0],{signal,originalRequestContext}):client.bill(receipt.selection,rest[0],{signal});
 }
 if(command==='native-intent-original'){
  if(rest.length!==3||await clientVersion(client)!=='2')throw Error('native-intent-original V2_PRIVATE_RECEIPT UTC_DAY PRODUCT_ID SOURCE_ORDER');
  return client.nativeInvoiceIntentOriginal(receipt.selection,rest[0],{signal,originalRequestContext,productId:rest[1],sourceOrder:rest[2]});
 }
 if(rest.length)throw Error('Unexpected original deployment command arguments');
 if(command==='status'||command==='reconcile')return reconcileDeploymentReceipt(client,file,{signal,originalRequestContext});
 if(command==='logs')return client.logs(receipt.selection,{signal,originalRequestContext});
 if(command==='runtime'){
  const op=await client.runtime(receipt.selection,{signal,originalRequestContext}),terminal=await terminalFor(file,receipt);
  if(terminal&&observedIdentity(terminal.operation)!==observedIdentity(op))throw new YNXCloudDeploymentUnknownError(receipt.selection.requestId);
  return op;
 }
 if(command==='inspect'){
  const result=await client.inspect(receipt.selection,{signal,originalRequestContext}),terminal=await terminalFor(file,receipt);
  if(terminal&&observedIdentity(terminal.operation)!==observedIdentity(result.operation))throw new YNXCloudDeploymentUnknownError(receipt.selection.requestId);
  return result;
 }
 if(command==='usage-records')return client.usage(receipt.selection,{signal,originalRequestContext,observe:false});
 if(command==='usage')return client.usage(receipt.selection,{signal,originalRequestContext});
 throw Error('Original deployment status, reconcile, runtime, logs, usage, usage-records or inspect command required');
}
