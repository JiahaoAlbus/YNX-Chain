package cloud

import (
	"net/http"
	"reflect"
)

// Request/operation identity only. This neither authenticates a caller nor
// turns a runtime handle into permission. Existing original Auth is still
// required on both sides of the same journal observation.
func (d *ideDeploymentService) originalProjectRuntimeFence(r *http.Request, initial IDEDeploymentOperation, origin string, executor IDEProjectRuntimeExecutor, authority IDEProjectRuntimeAuthority) func() error {
	var first error
	if r == nil || r.URL == nil {
		return func() error { return ErrDenied }
	}
	original, ctx := r, r.Context()
	target := *r.URL
	headers := r.Header.Clone()
	method, host, uri, pattern := r.Method, r.Host, r.RequestURI, r.Pattern
	selected := cloneIDEReadOperation(initial)
	if initial.Logs != nil && len(initial.Logs) == 0 {
		selected.Logs = []IDEDeploymentLog{}
	}
	requestCurrent := func() error {
		if r != original || r.URL == nil || !reflect.ValueOf(ctx).Comparable() || !reflect.ValueOf(r.Context()).Comparable() || ctx != r.Context() || ctx.Err() != nil || *r.URL != target || r.Method != method || r.Host != host || r.RequestURI != uri || r.Pattern != pattern || !reflect.DeepEqual(r.Header, headers) || executor.ProjectRuntimeOrigin() != origin {
			return ErrDenied
		}
		observed, err := d.journal.lookupRuntime(selected.RuntimeHandle)
		if err != nil || !sameIDEReadObservation(selected, observed) || observed.State != "running" || observed.RuntimeKind != "node-http-project" {
			return ErrIDEDeploymentConflict
		}
		return nil
	}
	return func() (err error) {
		if first != nil {
			return first
		}
		defer func() {
			if err != nil {
				first = err
			}
		}()
		if err = requestCurrent(); err != nil {
			return err
		}
		if err = d.authority.AssertCurrent(ctx); err != nil {
			return err
		}
		if err = authority.AssertProjectRuntimeOrigin(ctx, origin); err != nil {
			return err
		}
		if err = authority.AuthorizeProjectRuntime(ctx, original, cloneIDEReadOperation(selected), origin); err != nil {
			return err
		}
		return requestCurrent()
	}
}
