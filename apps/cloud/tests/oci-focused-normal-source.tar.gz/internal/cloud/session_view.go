package cloud

import (
	"io"
	"net/http"
	"time"
)

// Own authenticated session only. Never serialize the stored Session: it also
// contains token hash, original binding/digest, device key and callback.
type CurrentSessionView struct {
	SchemaVersion int       `json:"schemaVersion"`
	Account       string    `json:"account"`
	Product       string    `json:"product"`
	Scopes        []string  `json:"scopes"`
	IssuedAt      time.Time `json:"issuedAt"`
	ExpiresAt     time.Time `json:"expiresAt"`
}

// An uncertain snapshot commit cannot be reported as a definite missing or
// revoked session. Keep the existing readonly file paths independent; this
// fence applies only to reconciliation of this session lifecycle observation.
func (s *Server) currentSessionEntry(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	// Wire-version discovery only; never a session/Source or permission grant.
	w.Header().Set("X-Cloud-Object-Protocols", "create-once-v1 version-once-v1 access-once-v1 link-custody-v1 trash-once-v1")
	if err := s.service.objectWriteFence(); err != nil {
		writeServiceError(w, err)
		return
	}
	s.auth(s.currentSession)(w, r)
}

func (s *Server) currentSession(w http.ResponseWriter, r *http.Request, session Session) {
	w.Header().Set("Cache-Control", "no-store")
	var body []byte
	var err error
	if r.Body != nil {
		body, err = io.ReadAll(io.LimitReader(r.Body, 1))
	}
	if err != nil || r.URL.RawQuery != "" || len(body) > 0 {
		writeError(w, 400, "session status requires an empty GET")
		return
	}
	writeJSON(w, http.StatusOK, CurrentSessionView{SchemaVersion: 1, Account: session.Account, Product: session.Product, Scopes: append([]string(nil), session.Scopes...), IssuedAt: session.IssuedAt, ExpiresAt: session.ExpiresAt})
}
