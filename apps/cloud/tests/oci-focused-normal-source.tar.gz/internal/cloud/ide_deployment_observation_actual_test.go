//go:build cloud_oci_recovery

package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestP04ActualOCIOriginalRuntimeReadbackAndMissingInstance(t *testing.T) {
	p04ActualOCIOriginalObservation(t, false)
}

func TestP04ActualOCIArtifactAndStoredUsageIntegrity(t *testing.T) {
	p04ActualOCIOriginalObservation(t, true)
}

func p04ActualOCIOriginalObservation(t *testing.T, integrityDelta bool) {
	ctx := context.Background()
	binary, socket, image := os.Getenv("YNX_ACTUAL_OCI_BINARY"), os.Getenv("YNX_ACTUAL_OCI_SOCKET"), os.Getenv("YNX_ACTUAL_OCI_IMAGE")
	if ready, err := CheckIDEExistingOCI(ctx, binary, socket, image); err != nil || !ready.Available {
		t.Fatal("existing actual OCI required", ready, err)
	}
	root := t.TempDir()
	cfg := OriginalPrivateHostConfig{Cloud: Config{StatePath: filepath.Join(root, "state.json"), ObjectDir: filepath.Join(root, "objects")}, Limits: ServerLimits{MaxConcurrent: 32, RequestsPerMinute: 10000}}
	oci := IDEExistingOCIConfig{Binary: binary, Socket: socket, StorageRoot: filepath.Join(root, "runtime"), ResourceID: "PUBLIC_J23_QA_RESOURCE", TargetEnvironment: "PUBLIC_ISOLATED_CI", ImageDigest: image, ServerOrigin: "https://cloud.invalid", RuntimeOrigin: "https://versions.example.test", HTTPPort: 18081, MaxSeconds: 120}
	a := &p04ActualRecoveryAuth{resource: oci.ResourceID, origin: oci.RuntimeOrigin}
	var host *OriginalPrivateHost
	var handler http.Handler
	var executor *OCIIDEDeploymentExecutor
	var mu sync.RWMutex
	var creates, starts, posts atomic.Int32
	open := func() {
		t.Helper()
		h, err := OpenOriginalPrivateHost(ctx, cfg)
		if err != nil {
			t.Fatal(err)
		}
		s, _ := h.Server()
		e, err := NewOCIIDEDeploymentExecutor(oci)
		if err != nil {
			t.Fatal(err)
		}
		originalRun := e.run
		e.run = func(c context.Context, args ...string) ([]byte, error) {
			if len(args) > 0 {
				if args[0] == "create" {
					creates.Add(1)
				}
				if args[0] == "start" {
					starts.Add(1)
				}
			}
			return originalRun(c, args...)
		}
		if err = s.EnableIDEDeployments(a, e); err != nil {
			t.Fatal(err)
		}
		next, _ := h.Handler()
		mu.Lock()
		host, handler, executor = h, next, e
		mu.Unlock()
	}
	closeHost := func() {
		t.Helper()
		host.Retire()
		bounded, cancel := context.WithTimeout(ctx, 5*time.Second)
		defer cancel()
		if err := host.Join(bounded); err != nil {
			t.Fatal(err)
		}
		if err := host.Close(); err != nil {
			t.Fatal(err)
		}
	}
	open()
	defer closeHost()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		defer mu.RUnlock()
		if r.Method == "POST" && posts.Add(1) == 1 {
			reply := httptest.NewRecorder()
			handler.ServeHTTP(reply, r)
			if reply.Code != 201 {
				t.Errorf("actual create %d %s", reply.Code, reply.Body.String())
			}
			conn, _, err := w.(http.Hijacker).Hijack()
			if err == nil {
				_ = conn.Close()
			}
			return
		}
		handler.ServeHTTP(w, r)
	}))
	defer srv.Close()
	cliRoot := filepath.Join(root, "cli")
	if err := os.Mkdir(cliRoot, 0700); err != nil {
		t.Fatal(err)
	}
	node, err := exec.LookPath("node")
	if err != nil {
		t.Fatal(err)
	}
	script, _ := filepath.Abs("../../apps/cloud/client/deployment-observation-cli.fixture.mjs")
	run := func(stage string) {
		t.Helper()
		in, _ := json.Marshal(map[string]any{"base": srv.URL + "/api/v1", "root": cliRoot, "stage": stage, "actualOCI": true})
		cmd := exec.Command(node, script)
		cmd.Stdin = bytes.NewReader(in)
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("actual %s %v %s", stage, err, out)
		}
		if !json.Valid(out) {
			t.Fatal("invalid actual CLI result")
		}
	}
	run("lost")
	server, _ := host.Server()
	op, err := server.ideDeployments.journal.lookup("PUBLIC_OWNER", "req_observation_original_0001")
	if err != nil || !ideOCIDigest.MatchString("sha256:"+op.DeploymentID) {
		t.Fatal("exact actual instance unavailable", err)
	}
	removed := false
	defer func() {
		if !removed {
			if _, err := executor.run(ctx, "rm", "--force", op.DeploymentID); err != nil {
				t.Errorf("exact QA instance cleanup %v", err)
			}
		}
	}()
	closeHost()
	open()
	run("cold")
	u, err := url.Parse(op.RuntimeURL)
	if err != nil {
		t.Fatal(err)
	}
	req, _ := http.NewRequest("GET", srv.URL+"/", nil)
	req.Host = u.Host
	req.Header.Set("X-P04-CI-Identity", "PUBLIC_OWNER")
	response, err := srv.Client().Do(req)
	if err != nil {
		t.Fatal(err)
	}
	raw, readErr := io.ReadAll(io.LimitReader(response.Body, 4097))
	response.Body.Close()
	if response.StatusCode != 200 || readErr != nil || len(raw) > 4096 {
		t.Fatal("actual artifact runtime", response.StatusCode, readErr)
	}
	var actual struct {
		Version string `json:"version"`
		SHA256  string `json:"artifactSHA256"`
	}
	if json.Unmarshal(raw, &actual) != nil || actual.Version != "A" || actual.SHA256 != op.Binding.ContentDigest {
		t.Fatal("actual version/artifact mismatch")
	}
	closeHost()
	open()
	run("records-cold")
	if integrityDelta {
		// Only PUBLIC synthetic inputs; real engine, normal service and original
		// CLI. Corruption must not cause another POST/create/start or repair DATA.
		artifactFile := filepath.Join(oci.StorageRoot, executor.name(op.RequestID, op.ApprovalSHA256), "artifact.mjs")
		originalArtifact, err := os.ReadFile(artifactFile)
		if err != nil {
			t.Fatal(err)
		}
		corrupt := append([]byte(nil), originalArtifact...)
		corrupt[0] ^= 1
		writeArtifact := func(raw []byte) {
			t.Helper()
			// Test-owned host fault injection only. Normal artifacts stay 0444;
			// the actual nonprivileged runner correctly refuses direct writes.
			if err := os.Chmod(artifactFile, 0600); err != nil {
				t.Fatal(err)
			}
			if err := os.WriteFile(artifactFile, raw, 0600); err != nil {
				t.Fatal(err)
			}
			if err := os.Chmod(artifactFile, 0444); err != nil {
				t.Fatal(err)
			}
		}
		writeArtifact(corrupt)
		if _, err := executor.ObserveOriginal(ctx, op); err == nil {
			t.Fatal("actual status observation accepted corrupt artifact")
		}
		run("artifact-denied")
		writeArtifact(originalArtifact)
		// Mutate after actual Docker has read logs, before final identity check.
		originalRun := executor.run
		var injected bool
		executor.run = func(c context.Context, args ...string) ([]byte, error) {
			out, err := originalRun(c, args...)
			if len(args) > 0 && args[0] == "logs" && err == nil {
				injected = true
				writeArtifact(corrupt)
			}
			return out, err
		}
		run("logs-denied")
		executor.run = originalRun
		if !injected {
			t.Fatal("actual Docker logs mutation not reached")
		}
		writeArtifact(originalArtifact)
		run("records-cold")
		server, _ := host.Server()
		usageFile := server.ideDeployments.journal.file("PUBLIC_OWNER", op.RequestID) + ".usage"
		originalUsage, err := os.ReadFile(usageFile)
		if err != nil {
			t.Fatal(err)
		}
		var record IDEUsageRecord
		if err := json.Unmarshal(originalUsage, &record); err != nil || len(record.Samples) == 0 {
			t.Fatal("actual stored usage missing", err)
		}
		record.Latest.SampleSeq = "1"
		badUsage, _ := json.Marshal(record)
		if err := os.WriteFile(usageFile, badUsage, 0600); err != nil {
			t.Fatal(err)
		}
		closeHost()
		open()
		run("usage-denied")
		after, err := os.ReadFile(usageFile)
		if err != nil || !bytes.Equal(after, badUsage) {
			t.Fatal("rejected usage was repaired or overwritten", err)
		}
		if err := os.WriteFile(usageFile, originalUsage, 0600); err != nil {
			t.Fatal(err)
		}
		run("records-cold")
		t.Log("ACTUAL OCI delta: corrupt artifact status/runtime/logs/usage refused; mutation after real Docker logs refused; corrupt cold usage refused unchanged; original healthy readback restored; no extra POST/create/start")
	}
	// Remove only the independently observed QA instance. Original operation
	// records remain; a missing resource must not become historical running200.
	if _, err = executor.run(ctx, "rm", "--force", op.DeploymentID); err != nil {
		t.Fatal("exact QA cleanup", err)
	}
	removed = true
	run("unavailable")
	if creates.Load() != 1 || starts.Load() != 1 || posts.Load() != 1 {
		t.Fatal("actual original replay", creates.Load(), starts.Load(), posts.Load())
	}
	t.Logf("ACTUAL OCI instance=%s version=A artifact=%s cold2 POST1 create1 start1 exactRemoved=true missingRuntime503 historicalStatus200; PUBLIC approval only, no Source admission", op.DeploymentID, actual.SHA256)
}
