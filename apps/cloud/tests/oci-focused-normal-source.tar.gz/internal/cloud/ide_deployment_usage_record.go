package cloud

import "sort"

// Validate original meter DATA before publishing it after a cold open. This
// neither prices usage nor grants access; the original read/current fence is
// still required. A corrupt record remains untouched for reconciliation.
func validateOriginalIDEUsageRecord(record IDEUsageRecord, owner string, op IDEDeploymentOperation, allowEmpty bool) error {
	if record.Version != 1 || record.OwnerHash != productHash([]byte(owner)) || record.RequestID != op.RequestID || record.InstanceID != op.DeploymentID || record.Samples == nil || len(record.Samples) > 1024 {
		return ErrIDEDeploymentConflict
	}
	if len(record.Samples) == 0 {
		if allowEmpty && record.Latest == (IDEUsageSample{}) && len(record.Bills) == 0 && record.BillingState == "UNPRICED" {
			return nil
		}
		return ErrInvalid
	}
	samples := make([]IDEUsageSample, 0, len(record.Samples))
	for key, sample := range record.Samples {
		if key != sample.Period+"/"+sample.SampleSeq || validateIDEUsage(sample, op) != nil {
			return ErrInvalid
		}
		samples = append(samples, sample)
	}
	sort.Slice(samples, func(i, j int) bool { return samples[i].ObservedAt.Before(samples[j].ObservedAt) })
	var cpu, egress uint64
	for i, sample := range samples {
		nextCPU, _ := ideSlotNumber(sample.CPUNanos)
		nextEgress, _ := ideSlotNumber(sample.EgressBytes)
		if i > 0 && (!sample.ObservedAt.After(samples[i-1].ObservedAt) || nextCPU < cpu || nextEgress < egress) {
			return ErrIDEDeploymentConflict
		}
		cpu, egress = nextCPU, nextEgress
	}
	if record.Latest != samples[len(samples)-1] {
		return ErrInvalid
	}
	return nil
}
