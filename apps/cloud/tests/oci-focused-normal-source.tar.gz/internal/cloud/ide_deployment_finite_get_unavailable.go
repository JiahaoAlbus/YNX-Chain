//go:build !cloud_auth_finite_get

package cloud

func isIDEFiniteGETRequestUnavailable(error) bool { return false }

// Existing pre-V4 compositions keep their own legacy authorization boundary.
// They do not have the new normal finite-GET factory or its activation path.
func (s *Server) RefuseOriginalIDEFiniteGETReads() {}
