package cloud

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"time"
)

var errOriginalLinkCancelled = errors.New("original link request is cancelled; no link may be created")

// Both legacy and original-custody callers use the same link/hash publication.
// Caller holds the Service lock and has validated its normal owner/expiry path.
func (s *Service) publishShareLinkLocked(actor, id, tokenHash, role string, expiry time.Time) ShareLink {
	link := ShareLink{ID: newID("link"), ObjectID: id, TokenHash: tokenHash, Role: role, ExpiresAt: expiry, CreatedBy: actor, CreatedAt: s.cfg.Now()}
	s.state.Links[link.ID] = link
	if s.state.LinkTokenHashes == nil {
		s.state.LinkTokenHashes = map[string]string{}
	}
	s.state.LinkTokenHashes[link.ID] = tokenHash
	return link
}

func originalLinkSelection(id string, expected uint64, tokenHash, role string, expiry time.Time) (ObjectMutationSelection, error) {
	b, err := hex.DecodeString(tokenHash)
	if err != nil || len(b) != 32 || hex.EncodeToString(b) != tokenHash || expected == 0 || role != "viewer" || expiry.IsZero() || !expiry.Equal(expiry.Truncate(time.Millisecond)) {
		return ObjectMutationSelection{}, ErrInvalid
	}
	return ObjectMutationSelection{Action: "link-create", ObjectID: id, ExpectedRevision: strconv.FormatUint(expected, 10), TokenSHA256: tokenHash, Role: role, ExpiresAt: expiry.UTC().Format("2006-01-02T15:04:05.000Z")}, nil
}

// The caller already holds a random capability in private durable custody.
// Only its digest crosses this API. The server never receives/reconstructs it.
func (s *Service) CreateLinkOnce(ctx context.Context, actor, id, requestID, tokenHash, role string, expiry time.Time, expected uint64) (ShareLink, error) {
	if ctx == nil || !objectRequestID.MatchString(requestID) {
		return ShareLink{}, ErrInvalid
	}
	selection, err := originalLinkSelection(id, expected, tokenHash, role, expiry)
	if err != nil {
		return ShareLink{}, err
	}
	s.mu.Lock()
	defer s.unlockObjectState()
	obj, err := s.require(actor, id, 3)
	if err != nil {
		return ShareLink{}, err
	}
	if err = ctx.Err(); err != nil {
		return ShareLink{}, err
	}
	if s.objectWriteErr != nil {
		return ShareLink{}, s.objectWriteErr
	}
	raw, _ := json.Marshal(selection)
	fingerprint := hashBytes(raw)
	key := objectOperationKey(actor, obj.Product, requestID)
	if prior, ok := s.state.ObjectOperations[key]; ok {
		if prior.Fingerprint != fingerprint || prior.Selection == nil {
			return ShareLink{}, errObjectOperationConflict
		}
		if prior.Cancelled {
			return ShareLink{}, errOriginalLinkCancelled
		}
		link, exists := s.state.Links[prior.LinkID]
		if !exists {
			return ShareLink{}, errObjectOperationRetired
		}
		if link.ObjectID != id || s.linkTokenHashLocked(link) != tokenHash {
			return ShareLink{}, errObjectOperationConflict
		}
		if link.RevokedAt != nil {
			at := *link.RevokedAt
			link.RevokedAt = &at
		}
		return link, nil // Never renew expiry, undo revocation or create another ID.
	}
	if objectRevision(obj) != expected {
		return ShareLink{}, ConflictError{Current: obj}
	}
	if !s.objectVisibleInTreeLocked(obj) || obj.Kind == KindFolder || !expiry.After(s.cfg.Now()) || expiry.After(s.cfg.Now().Add(30*24*time.Hour)) {
		return ShareLink{}, ErrInvalid
	}
	// Refuse digest reuse, including retired/cancelled new-protocol originals.
	for _, link := range s.state.Links {
		if s.linkTokenHashLocked(link) == tokenHash {
			return ShareLink{}, errObjectOperationConflict
		}
	}
	for _, op := range s.state.ObjectOperations {
		if op.Selection != nil && op.Selection.TokenSHA256 == tokenHash {
			return ShareLink{}, errObjectOperationConflict
		}
	}
	before, err := snapshotObjectState(s.state)
	if err != nil {
		return ShareLink{}, err
	}
	link := s.publishShareLinkLocked(actor, id, tokenHash, role, expiry.UTC())
	if s.state.ObjectOperations == nil {
		s.state.ObjectOperations = map[string]objectCreateOperation{}
	}
	var binding *ObjectBinding
	if obj.Binding != nil {
		b := *obj.Binding
		binding = &b
	}
	s.state.ObjectOperations[key] = objectCreateOperation{Fingerprint: fingerprint, ObjectID: id, Selection: &selection, Version: obj.Version, Revision: strconv.FormatUint(objectRevision(obj), 10), Binding: binding, LinkID: link.ID}
	if err = s.persistObjectState(before, "link.create", actor, id, map[string]any{"linkId": link.ID, "originalRequest": requestID, "expiresAt": expiry}); err != nil {
		return ShareLink{}, err
	}
	return link, nil
}

// Atomically retires the SAME request even if its create has not arrived yet.
// A delayed create sees the tombstone. An issued original is revoked in place.
func (s *Service) CancelOriginalLink(ctx context.Context, actor, id, requestID, tokenHash, role string, expiry time.Time, expected uint64) error {
	if ctx == nil || !objectRequestID.MatchString(requestID) {
		return ErrInvalid
	}
	selection, err := originalLinkSelection(id, expected, tokenHash, role, expiry)
	if err != nil {
		return err
	}
	s.mu.Lock()
	defer s.unlockObjectState()
	obj, err := s.require(actor, id, 3)
	if err != nil {
		return err
	}
	if err = ctx.Err(); err != nil {
		return err
	}
	if s.objectWriteErr != nil {
		return s.objectWriteErr
	}
	raw, _ := json.Marshal(selection)
	fingerprint := hashBytes(raw)
	key := objectOperationKey(actor, obj.Product, requestID)
	prior, exists := s.state.ObjectOperations[key]
	if exists && (prior.Selection == nil || prior.Fingerprint != fingerprint) {
		return errObjectOperationConflict
	}
	if exists && prior.Cancelled {
		return nil
	}
	before, err := snapshotObjectState(s.state)
	if err != nil {
		return err
	}
	if exists {
		link, ok := s.state.Links[prior.LinkID]
		if !ok {
			return errObjectOperationRetired
		}
		if link.ObjectID != id || s.linkTokenHashLocked(link) != tokenHash {
			return errObjectOperationConflict
		}
		if link.RevokedAt != nil {
			return nil
		}
		now := s.cfg.Now()
		link.RevokedAt = &now
		s.state.Links[link.ID] = link
	} else {
		if s.state.ObjectOperations == nil {
			s.state.ObjectOperations = map[string]objectCreateOperation{}
		}
		s.state.ObjectOperations[key] = objectCreateOperation{Fingerprint: fingerprint, ObjectID: id, Selection: &selection, Cancelled: true}
	}
	return s.persistObjectState(before, "link.cancel-original", actor, id, map[string]any{"originalRequest": requestID})
}

func (s *Server) createOriginalLink(w http.ResponseWriter, r *http.Request, a Session) {
	s.originalLinkMutation(w, r, a, false)
}
func (s *Server) cancelOriginalLink(w http.ResponseWriter, r *http.Request, a Session) {
	s.originalLinkMutation(w, r, a, true)
}
func (s *Server) originalLinkMutation(w http.ResponseWriter, r *http.Request, a Session, cancel bool) {
	if a.Product != "cloud" || !requireScope(w, a, "permissions.manage") {
		return
	}
	expected, ok := objectExpectedRevision(w, r)
	if !ok {
		return
	}
	var req struct {
		TokenSHA256 string    `json:"tokenSHA256"`
		Role        string    `json:"role"`
		ExpiresAt   time.Time `json:"expiresAt"`
	}
	if !decode(w, r, &req, 4096) {
		return
	}
	id := r.PathValue("request")
	var err error
	if cancel {
		err = s.service.CancelOriginalLink(r.Context(), a.Account, r.PathValue("id"), id, req.TokenSHA256, req.Role, req.ExpiresAt, expected)
	} else {
		_, err = s.service.CreateLinkOnce(r.Context(), a.Account, r.PathValue("id"), id, req.TokenSHA256, req.Role, req.ExpiresAt, expected)
	}
	if err != nil {
		writeServiceError(w, err)
		return
	}
	observation, err := s.service.GetObjectOperation(a.Account, a.Product, id)
	writeResult(w, observation, err)
}
