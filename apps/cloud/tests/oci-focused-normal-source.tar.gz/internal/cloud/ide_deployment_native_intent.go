package cloud

import (
	"encoding/json"
	"io"
	"net/http"
	"regexp"
)

// Matches the original Pay product DATA contract. This is neither Core terms
// nor a Native ProductSource. Cloud has no original StoreID and never fills it
// from ProjectID, merchant, tenant or another caller-supplied value.
type IDEUsageNativeInvoiceIntentDATA struct {
	ProductID     string          `json:"productId"`
	StoreID       string          `json:"storeId,omitempty"`
	SourceOrder   string          `json:"sourceOrder"`
	Merchant      string          `json:"merchant"`
	Recipient     string          `json:"recipient"`
	Genesis       string          `json:"genesis"`
	NativeChainID string          `json:"nativeChainId"`
	AssetID       string          `json:"assetId"`
	UnitVersion   string          `json:"unitVersion"`
	AmountAtoms   string          `json:"amountAtoms"`
	DomainData    json.RawMessage `json:"domainData"`
}

var originalNativeAccount = regexp.MustCompile(`^0x[0-9a-f]{40}$`)

// NativeInvoiceIntentDATA maps only this already-held, validated original bill.
// Exact json.Marshal(Request) preserves Auth's original DomainData contract.
// No live tariff, new quote, invoice lookup or journal mutation is performed.
func (h *IDEUsageBillProvenance) NativeInvoiceIntentDATA(productID, sourceOrder string) (IDEUsageNativeInvoiceIntentDATA, error) {
	var empty IDEUsageNativeInvoiceIntentDATA
	d, err := h.DATA()
	if err != nil {
		return empty, err
	}
	r := d.Bill.Request
	if productID != "cloud.ide-usage" || sourceOrder != r.BillID || !validIDEUsageBillState(d.Bill) || d.Bill.State == "NO_CHARGE" ||
		!originalNativeAccount.MatchString(r.Merchant) || !originalNativeAccount.MatchString(r.Recipient) || !usageAssetValid(r.Asset) || r.Asset.AssetID != "YNXT" || r.Asset.UnitVersion != "1" {
		return empty, ErrDenied
	}
	amount, err := ideSlotNumber(r.Atoms)
	if err != nil || amount == 0 {
		return empty, ErrDenied
	}
	for _, original := range []string{r.BillID, r.RequestID, r.InstanceID, r.Period, r.ScheduleID, r.ScheduleRevision, r.RegistrationRef, r.ApprovalRef} {
		if original == "" {
			return empty, ErrDenied
		}
	}
	raw, err := json.Marshal(r)
	if err != nil || len(raw) > 64<<10 {
		return empty, ErrInvalid
	}
	out := IDEUsageNativeInvoiceIntentDATA{ProductID: productID, SourceOrder: r.BillID, Merchant: r.Merchant, Recipient: r.Recipient, Genesis: r.Asset.Genesis, NativeChainID: r.Asset.NativeChainID, AssetID: r.Asset.AssetID, UnitVersion: r.Asset.UnitVersion, AmountAtoms: r.Atoms, DomainData: raw}
	if err = h.Current(); err != nil {
		return empty, err
	}
	return out, nil
}

// The normal Source authorizes the SAME original operation before capture and
// again before returning detached DATA. A locator is not a Pay caller/Root.
// This route bypasses billUsage: even an existing UNKNOWN is strictly read-only,
// without Pay lookup/confirm/reconcile and without requiring pricing startup.
func (s *Server) ideUsageNativeInvoiceIntent(w http.ResponseWriter, r *http.Request) {
	d, owner, ok := s.ideDeploymentCaller(w, r)
	if !ok {
		return
	}
	if r.Body != nil {
		body, err := io.ReadAll(io.LimitReader(r.Body, 1))
		if err != nil || len(body) > 0 {
			productReadFailure(w, 400, "IDE_BILLING_BODY_NOT_ALLOWED")
			return
		}
	}
	if r.URL.RawQuery != "" {
		productReadFailure(w, 400, "IDE_BILLING_QUERY_NOT_ALLOWED")
		return
	}
	op, err := d.journal.lookup(owner, r.PathValue("request"))
	if err != nil {
		productReadFailure(w, 404, "IDE_DEPLOYMENT_NOT_FOUND")
		return
	}
	current := func() error {
		if err := r.Context().Err(); err != nil {
			return err
		}
		if err := d.authority.AssertCurrent(r.Context()); err != nil {
			return err
		}
		return d.authorizeOperationRead(r.Context(), r, op)
	}
	if current() != nil {
		productReadFailure(w, 403, "IDE_DEPLOYMENT_READ_DENIED")
		return
	}
	reader, err := s.OpenOriginalIDEUsageBillReader()
	if err != nil {
		productReadFailure(w, 503, "IDE_ORIGINAL_BILL_UNAVAILABLE")
		return
	}
	held, err := reader.Capture(r.Context(), owner, op.RequestID, r.PathValue("period"))
	if held != nil {
		defer held.Close()
	}
	if err != nil || held == nil {
		productReadFailure(w, 404, "IDE_ORIGINAL_BILL_UNAVAILABLE")
		return
	}
	data, err := held.DATA()
	if err != nil {
		productReadFailure(w, 403, "IDE_ORIGINAL_BILL_READ_DENIED")
		return
	}
	intent, err := held.NativeInvoiceIntentDATA("cloud.ide-usage", data.Bill.Request.BillID)
	if err != nil {
		productReadFailure(w, 409, "IDE_ORIGINAL_NATIVE_INTENT_UNAVAILABLE")
		return
	}
	digest, err := held.SHA256()
	if err != nil || current() != nil || held.Current() != nil {
		productReadFailure(w, 403, "IDE_DEPLOYMENT_READ_DENIED")
		return
	}
	writeJSON(w, 200, struct {
		Request        IDEUsageNativeInvoiceIntentDATA `json:"request"`
		Original       IDEUsageBillProvenanceDATA      `json:"original"`
		OriginalSHA256 string                          `json:"originalSHA256"`
	}{intent, data, digest})
}
