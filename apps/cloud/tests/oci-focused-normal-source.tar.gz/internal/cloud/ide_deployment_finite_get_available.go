//go:build cloud_auth_finite_get

package cloud

import (
	"errors"
	"github.com/JiahaoAlbus/YNX-Chain/internal/developerauthority"
)

func isIDEFiniteGETRequestUnavailable(err error) bool {
	return errors.Is(err, developerauthority.ErrFiniteGETNotSupplied)
}

// A failed normal attachment must not leave an already-held/legacy Source
// authenticating reads behind an unqualified listener. This only denies; no
// public ready flag or setter can manufacture permission or clear this latch.
func (s *Server) RefuseOriginalIDEFiniteGETReads() {
	if s != nil && s.ideDeployments != nil {
		s.ideDeployments.finiteGETRefused = true
	}
}
