package cloud

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strconv"
)

// Immutable original request facts, not a signing codec or authority. These
// contain no content, names, session credential or plaintext ACL target.
type ObjectMutationSelection struct {
	Action            string         `json:"action"`
	ObjectID          string         `json:"objectId"`
	ExpectedRevision  string         `json:"expectedRevision"`
	ContentBinding    *ObjectBinding `json:"contentBinding,omitempty"`
	HistoricalVersion int            `json:"historicalVersion,omitempty"`
	TargetSHA256      string         `json:"targetSHA256,omitempty"`
	Allow             *bool          `json:"allow,omitempty"`
	TokenSHA256       string         `json:"tokenSHA256,omitempty"`
	Role              string         `json:"role,omitempty"`
	ExpiresAt         string         `json:"expiresAt,omitempty"`
}

// Preserve the original version consumer's type name and wire field order.
type ObjectVersionMutationSelection = ObjectMutationSelection
type objectVersionMutation struct {
	id        string
	selection ObjectVersionMutationSelection
}
type objectVersionMutationKey struct{}

func (s *Service) PutObjectVersionOnce(ctx context.Context, actor, id string, expectedRev uint64, requestID string, input io.Reader, expected *ObjectBinding) (Object, error) {
	if ctx == nil || !objectRequestID.MatchString(requestID) || expectedRev == 0 {
		return Object{}, ErrInvalid
	}
	body, binding, err := readObjectInput(ctx, input)
	if err != nil {
		return Object{}, err
	}
	if expected != nil && *expected != binding {
		return Object{}, ErrInvalid
	}
	m := objectVersionMutation{requestID, ObjectVersionMutationSelection{Action: "put", ObjectID: id, ExpectedRevision: strconv.FormatUint(expectedRev, 10), ContentBinding: &binding}}
	return s.PutObjectVersion(context.WithValue(ctx, objectVersionMutationKey{}, m), actor, id, expectedRev, bytes.NewReader(body), &binding)
}
func (s *Service) RestoreObjectVersionOnce(ctx context.Context, actor, id string, historical int, expectedRev uint64, requestID string) (Object, error) {
	if ctx == nil || !objectRequestID.MatchString(requestID) || expectedRev == 0 || historical < 1 {
		return Object{}, ErrInvalid
	}
	m := objectVersionMutation{requestID, ObjectVersionMutationSelection{Action: "restore", ObjectID: id, ExpectedRevision: strconv.FormatUint(expectedRev, 10), HistoricalVersion: historical}}
	return s.RestoreObjectVersion(context.WithValue(ctx, objectVersionMutationKey{}, m), actor, id, historical, expectedRev)
}

func objectAccessTargetBinding(target string) string {
	return hashBytes([]byte("cloud.object.access.target/v1\x00" + target))
}

// Original ACL intent only: it delegates all actual permission and revocation
// work to the existing SetShareAccess implementation and its owner/CAS checks.
func (s *Service) SetShareAccessOnce(ctx context.Context, actor, id, target string, allow bool, expectedRev uint64, requestID string) (Object, error) {
	if ctx == nil || !validAccount(target) || !objectRequestID.MatchString(requestID) || expectedRev == 0 {
		return Object{}, ErrInvalid
	}
	m := objectVersionMutation{requestID, ObjectMutationSelection{Action: "access", ObjectID: id, ExpectedRevision: strconv.FormatUint(expectedRev, 10), TargetSHA256: objectAccessTargetBinding(target), Allow: &allow}}
	return s.SetShareAccess(context.WithValue(ctx, objectVersionMutationKey{}, m), actor, id, target, allow, expectedRev)
}

// Caller holds the original Service lock and has checked current object ACL.
// Test identity before stale CAS so an exact old original can only read back.
func (s *Service) originalVersionMutationLocked(ctx context.Context, actor string, obj Object) (bool, error) {
	if err := ctx.Err(); err != nil {
		return false, err
	}
	m, ok := ctx.Value(objectVersionMutationKey{}).(objectVersionMutation)
	if !ok {
		return false, nil
	}
	if s.objectWriteErr != nil {
		return false, s.objectWriteErr
	}
	if m.selection.ObjectID != obj.ID {
		return false, ErrInvalid
	}
	raw, err := json.Marshal(m.selection)
	if err != nil {
		return false, err
	}
	prior, exists := s.state.ObjectOperations[objectOperationKey(actor, obj.Product, m.id)]
	if !exists {
		return false, nil
	}
	if prior.Selection == nil || prior.Fingerprint != hashBytes(raw) || prior.ObjectID != obj.ID {
		return false, errObjectOperationConflict
	}
	return true, nil
}

// Stored in the SAME snapshot as version publication. A failed durable commit
// restores both together; an uncertain commit keeps the inherited UNKNOWN fence.
func (s *Service) recordVersionMutationLocked(ctx context.Context, actor string, obj Object) error {
	m, ok := ctx.Value(objectVersionMutationKey{}).(objectVersionMutation)
	if !ok {
		return nil
	}
	raw, err := json.Marshal(m.selection)
	if err != nil {
		return err
	}
	selection := m.selection
	if selection.ContentBinding != nil {
		b := *selection.ContentBinding
		selection.ContentBinding = &b
	}
	if selection.Allow != nil {
		allow := *selection.Allow
		selection.Allow = &allow
	}
	var binding *ObjectBinding
	if obj.Binding != nil {
		b := *obj.Binding
		binding = &b
	}
	if s.state.ObjectOperations == nil {
		s.state.ObjectOperations = map[string]objectCreateOperation{}
	}
	s.state.ObjectOperations[objectOperationKey(actor, obj.Product, m.id)] = objectCreateOperation{Fingerprint: hashBytes(raw), ObjectID: obj.ID, Selection: &selection, Version: obj.Version, Revision: strconv.FormatUint(objectRevision(obj), 10), Binding: binding}
	return nil
}
func objectOptionalRequest(w http.ResponseWriter, r *http.Request) (string, bool) {
	values := r.Header.Values("Idempotency-Key")
	if len(values) == 0 {
		return "", true
	}
	if len(values) != 1 || !objectRequestID.MatchString(values[0]) {
		writeError(w, 400, "invalid original object request identity")
		return "", false
	}
	return values[0], true
}
