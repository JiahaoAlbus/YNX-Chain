package cloud

import (
	"context"
	"path/filepath"
)

// Held original public artifact and inspected instance only. Authorization is
// still provided by the normal request's Source/current fence, never by this
// filesystem/container observation. No create/start/stop/retry is performed.
type ideOriginalRuntimeObservation struct {
	executor   *OCIIDEDeploymentExecutor
	operation  IDEDeploymentOperation
	inspection ideOCIInspection
	artifact   *ideStagedArtifact
}

func (e *OCIIDEDeploymentExecutor) beginOriginalRuntimeObservation(ctx context.Context, op IDEDeploymentOperation) (*ideOriginalRuntimeObservation, error) {
	if ctx == nil {
		return nil, ErrInvalid
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	op = cloneIDEReadOperation(op)
	inspected, err := e.inspect(ctx, op)
	if err != nil {
		return nil, err
	}
	staged, err := openIDEStagedOperation(filepath.Join(e.cfg.StorageRoot, e.name(op.RequestID, op.ApprovalSHA256), "artifact.mjs"), op)
	if err != nil {
		return nil, err
	}
	staged.contentBinding = op.ContentBinding
	if err = staged.verify(); err == nil {
		err = ctx.Err()
	}
	if err != nil {
		staged.file.Close()
		return nil, err
	}
	return &ideOriginalRuntimeObservation{executor: e, operation: op, inspection: inspected, artifact: staged}, nil
}

func (o *ideOriginalRuntimeObservation) finish(ctx context.Context, stableState bool) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := o.artifact.assertVerifiedIdentity(); err != nil {
		return err
	}
	after, err := o.executor.inspect(ctx, o.operation)
	if err != nil {
		return err
	}
	if after.ID != o.inspection.ID || stableState && after.State != o.inspection.State {
		return ErrIDEExistingRuntimeUnavailable
	}
	if err = ctx.Err(); err != nil {
		return err
	}
	return o.artifact.assertVerifiedIdentity()
}
