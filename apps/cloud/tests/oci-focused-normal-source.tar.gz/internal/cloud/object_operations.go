package cloud

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"regexp"
	"strings"
)

var objectRequestID = regexp.MustCompile(`^[A-Za-z0-9_-]{16,128}$`)
var errObjectOperationConflict = errors.New("object request identity is already bound to different input")
var errObjectOperationRetired = errors.New("original object was deleted; this request cannot create another object")

// This is a single-authoritative-snapshot replay tombstone, not a grant or a
// multi-instance uniqueness claim. It contains no content, name, token or account.
type objectCreateOperation struct {
	Fingerprint string                          `json:"fingerprint"`
	ObjectID    string                          `json:"objectId"`
	Selection   *ObjectVersionMutationSelection `json:"selection,omitempty"`
	Version     int                             `json:"version,omitempty"`
	Revision    string                          `json:"revision,omitempty"`
	Binding     *ObjectBinding                  `json:"binding,omitempty"`
	LinkID      string                          `json:"linkId,omitempty"`
	Cancelled   bool                            `json:"cancelled,omitempty"`
	Kind        ObjectKind                      `json:"kind,omitempty"`
	ParentID    string                          `json:"parentId,omitempty"`
}

type ObjectOperationObservation struct {
	Outcome         string                          `json:"outcome"`
	ObjectID        string                          `json:"objectId,omitempty"`
	Version         int                             `json:"version,omitempty"`
	Binding         *ObjectBinding                  `json:"binding,omitempty"`
	Deleted         bool                            `json:"deleted,omitempty"`
	Selection       *ObjectVersionMutationSelection `json:"selection,omitempty"`
	Revision        string                          `json:"revision,omitempty"`
	Link            *ShareLink                      `json:"link,omitempty"`
	LinkUnavailable bool                            `json:"linkUnavailable,omitempty"`
	Kind            ObjectKind                      `json:"kind,omitempty"`
	ParentID        string                          `json:"parentId,omitempty"`
}

type objectCreateRequestKey struct{}

// CreateObjectOnce only adds stable request identity to the normal Create path.
// Current authenticated actor/product and every existing ACL/scanner/quota check
// still apply. No separate write engine or account admission is introduced.
func (s *Service) CreateObjectOnce(ctx context.Context, actor, requestID string, req CreateObjectRequest) (Object, error) {
	if ctx == nil || !objectRequestID.MatchString(requestID) || len(req.Content) > MaxUploadBytes {
		return Object{}, ErrInvalid
	}
	// Retain owned input while scanner/provider run outside client control.
	req.Content = append([]byte(nil), req.Content...)
	if req.Artifact != nil {
		raw, err := json.Marshal(req.Artifact)
		if err != nil {
			return Object{}, err
		}
		var artifact Artifact
		if err = json.Unmarshal(raw, &artifact); err != nil {
			return Object{}, err
		}
		req.Artifact = &artifact
	}
	return s.Create(context.WithValue(ctx, objectCreateRequestKey{}, requestID), actor, req)
}

func objectOperationKey(actor, product, requestID string) string {
	return hashBytes([]byte("cloud.object.create/v1\x00" + actor + "\x00" + product + "\x00" + requestID))
}

func (s *Service) prepareObjectCreateLocked(ctx context.Context, actor string, req CreateObjectRequest) (objectCreateOperation, string, error) {
	requestID, _ := ctx.Value(objectCreateRequestKey{}).(string)
	if requestID == "" {
		return objectCreateOperation{}, "", nil
	}
	binding := bindObjectBytes(req.Content)
	req.Content = nil
	req.Name = strings.TrimSpace(req.Name)
	input, err := json.Marshal(struct {
		Request CreateObjectRequest
		Binding ObjectBinding
	}{req, binding})
	if err != nil {
		return objectCreateOperation{}, "", err
	}
	key := objectOperationKey(actor, req.Product, requestID)
	operation := objectCreateOperation{Fingerprint: hashBytes(input), Kind: req.Kind, ParentID: req.ParentID}
	if original, ok := s.state.ObjectOperations[key]; ok {
		if original.Selection != nil || original.Fingerprint != operation.Fingerprint {
			return objectCreateOperation{}, "", errObjectOperationConflict
		}
		return original, key, nil
	}
	return operation, key, nil
}

// Observation never writes, retries, signs, changes ACL or returns body bytes.
// UNKNOWN remains UNKNOWN until original durable reconciliation succeeds.
func (s *Service) GetObjectOperation(actor, product, requestID string) (ObjectOperationObservation, error) {
	if !validAccount(actor) || (product != "cloud" && product != "docs") || !objectRequestID.MatchString(requestID) {
		return ObjectOperationObservation{}, ErrInvalid
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	original, ok := s.state.ObjectOperations[objectOperationKey(actor, product, requestID)]
	if s.objectWriteErr != nil {
		return ObjectOperationObservation{Outcome: "UNKNOWN"}, nil
	}
	if !ok {
		return ObjectOperationObservation{}, ErrNotFound
	}
	observation := ObjectOperationObservation{Outcome: "COMMITTED", ObjectID: original.ObjectID, Version: 1}
	observation.Kind = original.Kind
	if original.Kind == KindFolder {
		observation.Version = 0
	}
	observation.ParentID = original.ParentID
	if original.Cancelled {
		observation.Outcome = "CANCELLED"
	}
	if original.Selection != nil {
		selection := *original.Selection
		if selection.ContentBinding != nil {
			b := *selection.ContentBinding
			selection.ContentBinding = &b
		}
		if selection.Allow != nil {
			allow := *selection.Allow
			selection.Allow = &allow
		}
		observation.Selection = &selection
		observation.Version = original.Version
		observation.Revision = original.Revision
		if original.Binding != nil {
			b := *original.Binding
			observation.Binding = &b
		}
	}
	obj, exists := s.state.Objects[original.ObjectID]
	if !exists {
		observation.Deleted = true
		return observation, nil
	}
	if obj.Product != product {
		return ObjectOperationObservation{}, ErrDenied
	}
	if original.Selection != nil {
		minimum := 1
		if original.Selection.Action == "access" || original.Selection.Action == "link-create" {
			minimum = 3
		}
		if _, err := s.require(actor, obj.ID, minimum); err != nil {
			return ObjectOperationObservation{}, err
		}
		if original.Selection.Action == "link-create" && !original.Cancelled {
			link, ok := s.state.Links[original.LinkID]
			if !ok {
				observation.LinkUnavailable = true
			} else {
				if link.ObjectID != obj.ID || s.linkTokenHashLocked(link) != original.Selection.TokenSHA256 || link.Role != original.Selection.Role || link.ExpiresAt.UTC().Format("2006-01-02T15:04:05.000Z") != original.Selection.ExpiresAt {
					return ObjectOperationObservation{}, errObjectOperationConflict
				}
				if link.RevokedAt != nil {
					at := *link.RevokedAt
					link.RevokedAt = &at
				}
				observation.Link = &link
			}
		}
		return observation, nil
	}
	if obj.Owner != actor {
		return ObjectOperationObservation{}, ErrDenied
	}
	observation.Kind = obj.Kind
	if obj.Kind == KindFolder {
		observation.Version = 0
	}
	if versions := s.state.Versions[obj.ID]; len(versions) > 0 {
		if versions[0].Binding != nil {
			binding := *versions[0].Binding
			observation.Binding = &binding
		}
	}
	return observation, nil
}

func (s *Service) linkTokenHashLocked(link ShareLink) string {
	if hash := s.state.LinkTokenHashes[link.ID]; hash != "" {
		return hash
	}
	return link.TokenHash // Existing in-memory legacy link; missing persisted hash fails closed.
}

func (s *Server) objectOperation(w http.ResponseWriter, r *http.Request, session Session) {
	writeScope := "files.write"
	if session.Product == "docs" {
		writeScope = "documents.write"
	}
	hasWrite, hasManage := false, false
	for _, scope := range session.Scopes {
		if scope == writeScope {
			hasWrite = true
		}
		if session.Product == "cloud" && scope == "permissions.manage" {
			hasManage = true
		}
	}
	if !hasWrite && !hasManage {
		writeError(w, 403, "session scope does not allow original operation read")
		return
	}
	observation, err := s.service.GetObjectOperation(session.Account, session.Product, r.PathValue("request"))
	if err == nil && observation.Outcome != "UNKNOWN" {
		access := observation.Selection != nil && (observation.Selection.Action == "access" || observation.Selection.Action == "link-create")
		if access && !hasManage || !access && !hasWrite {
			writeError(w, 403, "session scope does not allow this original operation")
			return
		}
	}
	writeResult(w, observation, err)
}
