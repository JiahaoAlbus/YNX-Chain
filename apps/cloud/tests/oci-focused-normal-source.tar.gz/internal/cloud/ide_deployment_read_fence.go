package cloud

import (
	"context"
	"net/http"
	"net/url"
	"reflect"
)

// A product DATA fence, not a proof decoder, nonce store or Source. Never
// serializes credentials or grants a principal from a captured HTTP object.
type originalIDEReadRequest struct {
	request                                       *http.Request
	ctx                                           context.Context
	url                                           url.URL
	header                                        http.Header
	method, host, uri, pattern, operation, period string
	retired                                       bool
}

func captureOriginalIDEReadRequest(r *http.Request) *originalIDEReadRequest {
	if r == nil || r.URL == nil || r.Method != http.MethodGet {
		return nil
	}
	return &originalIDEReadRequest{request: r, ctx: r.Context(), url: *r.URL, header: r.Header.Clone(), method: r.Method, host: r.Host, uri: r.RequestURI, pattern: r.Pattern, operation: r.PathValue("request"), period: r.PathValue("period")}
}

func (s *originalIDEReadRequest) current(r *http.Request) error {
	if s == nil {
		return ErrDenied
	}
	if s.retired || r != s.request || r == nil || r.URL == nil || !reflect.TypeOf(s.ctx).Comparable() || r.Context() != s.ctx || s.ctx.Err() != nil || *r.URL != s.url || r.Method != s.method || r.Host != s.host || r.RequestURI != s.uri || r.Pattern != s.pattern || r.PathValue("request") != s.operation || r.PathValue("period") != s.period || !reflect.DeepEqual(r.Header, s.header) || !originalIDEDeploymentReadTarget(r) {
		s.retired = true
		return ErrDenied
	}
	return nil
}

func cloneIDEReadOperation(op IDEDeploymentOperation) IDEDeploymentOperation {
	if op.ManifestV2 != nil {
		v := *op.ManifestV2
		op.ManifestV2 = &v
	}
	if op.ManifestBinding != nil {
		v := *op.ManifestBinding
		op.ManifestBinding = &v
	}
	if op.ContentBinding != nil {
		v := *op.ContentBinding
		op.ContentBinding = &v
	}
	if op.ExitCode != nil {
		v := *op.ExitCode
		op.ExitCode = &v
	}
	op.Logs = append([]IDEDeploymentLog(nil), op.Logs...)
	return op
}

func sameIDEReadIdentity(a, b IDEDeploymentOperation) bool {
	return sameIDETransition(a, b) && a.RequestID == b.RequestID && a.Binding == b.Binding && a.ManifestSHA256 == b.ManifestSHA256 && a.ApprovalSHA256 == b.ApprovalSHA256 && a.PublisherID == b.PublisherID && a.ResourceID == b.ResourceID && a.ResourceApprovalRef == b.ResourceApprovalRef && a.RuntimeHandle == b.RuntimeHandle && a.RuntimeSeconds == b.RuntimeSeconds && a.CreatedAt.Equal(b.CreatedAt)
}

func sameIDEReadObservation(a, b IDEDeploymentOperation) bool {
	return sameIDEReadIdentity(a, b) && a.State == b.State && a.DeploymentID == b.DeploymentID && a.RuntimeURL == b.RuntimeURL && a.RuntimeKind == b.RuntimeKind && a.SlotRevision == b.SlotRevision && a.UpdatedAt.Equal(b.UpdatedAt) && reflect.DeepEqual(a.ExitCode, b.ExitCode) && reflect.DeepEqual(a.Logs, b.Logs)
}

// Check both sides of the SAME original Source/current call. Reborrow existing
// request custody through AuthorizeRead; do not authenticate/consume its nonce
// again. No worker is detached: an ignoring executor remains owned by its HTTP
// handler until it returns, and a late response cannot bypass this final fence.
func (d *ideDeploymentService) originalReadFence(r *http.Request, owner string, initial IDEDeploymentOperation) func(IDEDeploymentOperation) error {
	selected := captureOriginalIDEReadRequest(r)
	base := cloneIDEReadOperation(initial)
	var first error
	return func(observed IDEDeploymentOperation) (err error) {
		if first != nil {
			return first
		}
		defer func() {
			if err != nil {
				first = err
			}
		}()
		if selected.current(r) != nil || !sameIDEReadIdentity(base, observed) || base.DeploymentID != "" && (base.DeploymentID != observed.DeploymentID || base.SlotRevision != observed.SlotRevision || base.RuntimeURL != observed.RuntimeURL) {
			return ErrDenied
		}
		check := func() error {
			stored, err := d.journal.lookup(owner, base.RequestID)
			if err != nil || !sameIDEReadObservation(stored, observed) {
				return ErrIDEDeploymentConflict
			}
			return selected.current(r)
		}
		if err := check(); err != nil {
			return err
		}
		if err := d.authority.AssertCurrent(selected.ctx); err != nil {
			return err
		}
		if err := d.authorizeOperationRead(selected.ctx, r, observed); err != nil {
			return err
		}
		return check()
	}
}
