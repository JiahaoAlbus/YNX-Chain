package cloud

import (
	"context"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"time"
)

// Resource observations only, never Source/execute admission or proof that a
// sandbox/application was created. No pull/create/start/stop/exec is performed.
type IDEOCIReadiness struct {
	Available           bool   `json:"available"`
	Code                string `json:"code"`
	ServerVersion       string `json:"serverVersion,omitempty"`
	ImagePresent        bool   `json:"imagePresent"`
	ExecutionAuthorized bool   `json:"executionAuthorized"`
	ApplicationRunning  bool   `json:"applicationRunning"`
}

// CheckIDEExistingOCI reads only the selected existing Unix daemon and pinned
// image. It does not construct an executor, create storage or consult Docker's
// ambient context/config. A working CLI executable alone is not availability.
func CheckIDEExistingOCI(ctx context.Context, binary, socket, image string) (IDEOCIReadiness, error) {
	r := IDEOCIReadiness{Code: "OCI_CONFIG_INVALID"}
	fail := func(code string) (IDEOCIReadiness, error) { r.Code = code; return r, ErrIDEExistingRuntimeUnavailable }
	if ctx == nil || !filepath.IsAbs(binary) || filepath.Clean(binary) != binary || !filepath.IsAbs(socket) || filepath.Clean(socket) != socket || !ideOCIDigest.MatchString(image) {
		return r, ErrInvalid
	}
	if err := ctx.Err(); err != nil {
		return fail("OCI_CHECK_CANCELLED")
	}
	b, err := os.Stat(binary)
	if err != nil || !b.Mode().IsRegular() || b.Mode().Perm()&0111 == 0 {
		return fail("OCI_BINARY_UNAVAILABLE")
	}
	s, err := os.Lstat(socket)
	if err != nil || s.Mode()&os.ModeSocket == 0 {
		return fail("OCI_SOCKET_UNAVAILABLE")
	}
	bounded, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	transport := &http.Transport{Proxy: nil, DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
		return (&net.Dialer{}).DialContext(ctx, "unix", socket)
	}}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	read := func(path string, out any) error {
		req, err := http.NewRequestWithContext(bounded, "GET", "http://oci-local"+path, nil)
		if err != nil {
			return err
		}
		response, err := client.Do(req)
		if err != nil {
			return err
		}
		defer response.Body.Close()
		if response.StatusCode != http.StatusOK {
			return ErrIDEExistingRuntimeUnavailable
		}
		raw, err := io.ReadAll(io.LimitReader(response.Body, 65537))
		if err != nil || len(raw) > 65536 {
			return ErrInvalid
		}
		return json.Unmarshal(raw, out)
	}
	var version struct {
		Version string `json:"Version"`
		API     string `json:"ApiVersion"`
		OS      string `json:"Os"`
	}
	if err = read("/version", &version); err != nil {
		return fail("OCI_SERVER_UNAVAILABLE")
	}
	if version.Version == "" || len(version.Version) > 128 || version.API == "" || version.OS != "linux" {
		return fail("OCI_SERVER_INVALID")
	}
	r.ServerVersion = version.Version
	var info struct {
		ID string `json:"Id"`
	}
	if err = read("/images/"+image+"/json", &info); err != nil {
		return fail("OCI_IMAGE_UNAVAILABLE")
	}
	if info.ID != image {
		return fail("OCI_IMAGE_MISMATCH")
	}
	if err = bounded.Err(); err != nil {
		return fail("OCI_CHECK_CANCELLED")
	}
	r.Available = true
	r.ImagePresent = true
	r.Code = "OCI_RESOURCE_OBSERVED_NOT_AUTHORIZED"
	return r, nil
}
