package cloud

import (
	"io"
	"net/http"
	"time"
)

// Product route selection only. Auth still verifies the original proof,
// principal and current registered operation; this does not interpret headers.
// None of these existing read routes implements query parameters.
func originalIDEDeploymentReadTarget(r *http.Request) bool {
	if r == nil || r.URL == nil || r.Method != http.MethodGet || r.URL.RawQuery != "" || r.URL.ForceQuery || r.URL.Fragment != "" || r.URL.Opaque != "" {
		return false
	}
	id := r.PathValue("request")
	if !productWriteKey.MatchString(id) {
		return false
	}
	path := "/api/v1/ide/deployments/" + id
	switch r.Pattern {
	case "GET /api/v1/ide/deployments/{request}":
	case "GET /api/v1/ide/deployments/{request}/logs":
		path += "/logs"
	case "GET /api/v1/ide/deployments/{request}/runtime":
		path += "/runtime"
	case "GET /api/v1/ide/deployments/{request}/usage":
		path += "/usage"
	case "GET /api/v1/ide/deployments/{request}/usage/records":
		path += "/usage/records"
	case "GET /api/v1/ide/deployments/{request}/billing/{period}", "GET /api/v1/ide/deployments/{request}/billing/{period}/native-intent":
		period := r.PathValue("period")
		day, err := time.Parse("2006-01-02", period)
		if err != nil || day.Format("2006-01-02") != period {
			return false
		}
		path += "/billing/" + period
		if r.Pattern == "GET /api/v1/ide/deployments/{request}/billing/{period}/native-intent" {
			path += "/native-intent"
		}
	default:
		return false
	}
	if r.URL.EscapedPath() != path || r.RequestURI != path || r.ContentLength != 0 || len(r.TransferEncoding) != 0 || len(r.Trailer) != 0 {
		return false
	}
	if r.Body != nil {
		body, err := io.ReadAll(io.LimitReader(r.Body, 1))
		if err != nil || len(body) != 0 {
			return false
		}
	}
	return true
}
