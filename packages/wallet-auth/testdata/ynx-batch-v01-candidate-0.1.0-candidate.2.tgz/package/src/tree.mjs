import {createHash} from 'node:crypto';
import {VERSION, u32, encodeFields, requireThat} from './codec.mjs';
import {createPortableHash} from './portable.mjs';

// Both implementations absorb exactly the same complete E encoding.
export function createHasher(C, N, optimized = true, provider = 'native') {
  requireThat(typeof optimized === 'boolean', 'invalid optimization flag');
  requireThat(provider === 'native' || provider === 'portable', 'unknown hash provider');
  const createDigest = provider === 'native' ? createHash : createPortableHash;
  const states = {};
  const suffix = (...parts) => encodeFields(parts).subarray(4);
  for (const b of ['A', 'B']) {
    const algorithm = b === 'A' ? 'sha3-512' : 'sha512';
    const leafTag = VERSION + '/LEAF/' + b, nodeTag = VERSION + '/NODE/' + b;
    const leafPrefix = Buffer.concat([u32(5), suffix(leafTag, C, u32(N))]);
    const nodePrefix = Buffer.concat([u32(7), suffix(nodeTag, C, u32(N))]);
    const leafState = createDigest(algorithm).update(leafPrefix), nodeState = createDigest(algorithm).update(nodePrefix);
    states[b] = {
      leaf: (i, m) => optimized ? leafState.copy().update(suffix(u32(i), m)).digest()
        : createDigest(algorithm).update(encodeFields([leafTag, C, u32(N), u32(i), m])).digest(),
      node: (l, j, left, right) => optimized ? nodeState.copy().update(suffix(u32(l), u32(j), left, right)).digest()
        : createDigest(algorithm).update(encodeFields([nodeTag, C, u32(N), u32(l), u32(j), left, right])).digest(),
    };
  }
  return states;
}
export function buildTree(hash, messages) {
  const levels = [messages.map((m, i) => hash.leaf(i, m))];
  for (let level = 1; levels[level - 1].length > 1; level++) {
    const children = levels[level - 1], parents = [];
    for (let j = 0; j < children.length / 2; j++) parents.push(hash.node(level, j, children[2 * j], children[2 * j + 1]));
    levels.push(parents);
  }
  return levels;
}
export function extractPath(levels, index) {
  const result = [];
  for (let l = 0; l < levels.length - 1; l++) { result.push(Buffer.from(levels[l][index ^ 1])); index = Math.floor(index / 2); }
  return result;
}
export function pathRoot(hash, index, message, path) {
  let value = hash.leaf(index, message);
  for (let l = 1; l <= path.length; l++) {
    const up = Math.floor(index / 2);
    value = index % 2 === 0 ? hash.node(l, up, value, path[l - 1]) : hash.node(l, up, path[l - 1], value);
    index = up;
  }
  return value;
}
