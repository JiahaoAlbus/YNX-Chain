// Explicit Node/Electron provider. This is not yet a browser/mobile hash adapter.
import {randomBytes, timingSafeEqual} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {ml_dsa87} from '@noble/post-quantum/ml-dsa.js';
import {slh_dsa_sha2_256f} from '@noble/post-quantum/slh-dsa.js';
import {createNobleHash, verifyNoble} from './public-noble.mjs';
import {exact, requireThat} from './codec.mjs';
import {copyKeyMaterial, decodePrivateDER, encodePrivateDER, materialRecord, requirePublicMatch} from './native.mjs';

const actualVersion = JSON.parse(readFileSync(new URL('./package.json', import.meta.resolve('@noble/post-quantum/ml-dsa.js')), 'utf8')).version;
const actualHashVersion = JSON.parse(readFileSync(new URL('./package.json', import.meta.resolve('@noble/hashes/sha3.js')), 'utf8')).version;
const algorithms = Object.freeze({A: ml_dsa87, B: slh_dsa_sha2_256f});
function assertLibrary() {
  requireThat(actualVersion === '0.6.1' && actualHashVersion === '2.2.0', 'unvalidated portable crypto library');
}
export function createPortableHash(algorithm) {
  assertLibrary();
  return createNobleHash(algorithm, value => Buffer.from(value));
}
function generate() {
  assertLibrary();
  // Independent native CSPRNG requests, never derived from account/network data.
  const seedA = randomBytes(32), seedB = randomBytes(96);
  let A, B;
  try {
    A = ml_dsa87.keygen(seedA); B = slh_dsa_sha2_256f.keygen(seedB);
    return {A, B, seedA: Buffer.from(seedA)};
  } catch (error) { A?.secretKey.fill(0); B?.secretKey.fill(0); throw error; }
  finally { seedA.fill(0); seedB.fill(0); }
}
function publicBytes(keys) {
  return {pkA: Buffer.from(exact(Buffer.from(keys.A.publicKey), 2592, 'pkA')),
    pkB: Buffer.from(exact(Buffer.from(keys.B.publicKey), 64, 'pkB'))};
}
function destroy(keys) { keys.A.secretKey.fill(0); keys.B.secretKey.fill(0); keys.seedA.fill(0); }
function exportKeys(keys) {
  assertLibrary();
  const rawB = Buffer.from(keys.B.secretKey);
  const A = encodePrivateDER('A', keys.seedA), B = encodePrivateDER('B', rawB);
  try { return materialRecord(A, B, publicBytes(keys)); }
  finally { rawB.fill(0); A.fill(0); B.fill(0); }
}
function importKeys(material) {
  assertLibrary();
  const saved = copyKeyMaterial(material);
  let seedA, rawB, A, B, keys;
  try {
    seedA = decodePrivateDER('A', saved.pkcs8A); rawB = decodePrivateDER('B', saved.pkcs8B);
    A = ml_dsa87.keygen(seedA);
    // getPublicKey(SLH) only extracts the embedded key; recompute the root from
    // SK.seed || SK.prf || PK.seed and require the entire expanded key to match.
    B = slh_dsa_sha2_256f.keygen(rawB.subarray(0, 96));
    requireThat(timingSafeEqual(B.secretKey, rawB), 'inconsistent SLH private key');
    keys = {A, B, seedA: Buffer.from(seedA)};
    requirePublicMatch(publicBytes(keys), saved);
    return keys;
  } catch (error) {
    A?.secretKey.fill(0); B?.secretKey.fill(0); keys?.seedA.fill(0); throw error;
  } finally { seedA?.fill(0); rawB?.fill(0); saved.pkcs8A.fill(0); saved.pkcs8B.fill(0); }
}
export const portableProvider = Object.freeze({
  generate, publicBytes, destroy, exportKeys, importKeys,
  sign(keys, branch, message) {
    assertLibrary();
    return Buffer.from(algorithms[branch].sign(message, keys[branch].secretKey, {context: new Uint8Array()}));
  },
  importPublic(certificate) {
    assertLibrary();
    return {A: Buffer.from(exact(certificate.pkA, 2592, 'pkA')), B: Buffer.from(exact(certificate.pkB, 64, 'pkB'))};
  },
  verify(keys, branch, message, signature) {
    assertLibrary();
    return verifyNoble(keys, branch, message, signature);
  },
  info() {
    assertLibrary();
    return Object.freeze({provider: 'portable', library: '@noble/post-quantum', version: actualVersion,
      hashes: '@noble/hashes', hashesVersion: actualHashVersion,
      node: process.versions.node, openssl: process.versions.openssl});
  },
});
