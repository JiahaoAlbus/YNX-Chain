# YNX BATCH v0.1 candidate module

This private candidate implements the fixed `YNX-BATCH/v0.1` bytes and dual authentication in an isolated JavaScript package. It is not connected to Chain, Wallet, Social, consensus, or a network. Every generated identity in the tests is research-only. A valid signature or member proof is not permission to execute a transaction.

## Reproduce

The native provider is pinned to **Node 26.7.0 / OpenSSL 3.6.4** and fails closed on a different pair. Explicit `{provider: 'portable'}` uses runtime dependencies `@noble/post-quantum` 0.6.1 and `@noble/hashes` 2.2.0, with curves/ciphers 2.2.0 pinned transitively. Portable was also tested in the actual R24 Wallet executable: Electron 42.10.0 / Node 24.18.1 / reported OpenSSL 0.0.0. There is no silent provider fallback. Candidate 3 adds an explicit Node-free, public verification entry; its new browser execution qualification is pending normal CI. The frozen candidate 2 package and its evidence are unchanged. `package-lock.json` records npmjs tarball integrity values, checked against the original registry after the initial local npm mirror download.

```sh
npm ci --ignore-scripts --no-audit --no-fund --registry=https://registry.npmjs.org
node --max-old-space-size=128 --test --test-isolation=none --test-concurrency=1 test/*.test.mjs
```

On this host, the measured command wrapper is:

```sh
/Users/huangjiahao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 scripts/run-bounded.py final-tests --test test/codec.test.mjs test/crypto.test.mjs test/interop.test.mjs test/nist.test.mjs
```

The wrapper uses one Node process, a 128 MiB V8 heap limit, 25 CPU seconds and 30 wall seconds; it terminates its owned process group on timeout. Native/Buffer allocations are not covered by the V8 heap limit. `/usr/bin/time -l` records actual RSS. No persistent server or worker is started.

## Interface

Import `src/index.mjs` or the package root. Buffers must use ordinary, non-shared backing memory.

For public verification in a browser, explicitly import `@ynx/batch-v01-candidate/browser`.
Its codec accepts ordinary `Uint8Array` values and returns detached `Uint8Array`
values. It shares the framing, dual-tree and trusted-registry verifier with the
Node entry. It exports `createVerifier`, `browserProviderInfo` and the public
codec; it does not export key generation, signing, key material or provider
selection. It has no Node-global shim or Node module dependency. The normal ESM
loader/bundler must resolve the exact lockfile dependencies; no CDN, runtime
download, automatic provider fallback or alternate signature algorithm is used.

`browserProviderInfo().releaseDependencies` declares the fixed release versions.
`dependencyVersionVerified` is **false**: browser ESM cannot inspect the loaded
dependency package metadata or attest to the loader's source integrity. Bind
the actual package/dependency bytes through the consumer's normal release
process. This information is not Source registration, a trusted resolver or
Root authorization. `createVerifier` still requires the independently trusted
network, full key pair, purpose and current synchronous registry record at each
explicit execution height; passing any `provider` option is rejected.

`npm run test:public` checks the original codec and explicit portable Node
Buffer versus Uint8Array verification, including the official public NIST
signature-verification cases. `BROWSER_BINARY=/absolute/path/to/chrome npm run
test:browser` loads the same public vectors through actual headless browser
ESM, with no Buffer/process shim. The fixture generator and Node verifier both
explicitly select the original portable provider; they do not attempt native
signing and then fall back. A missing browser or failed module load is a
failure, not a skipped browser qualification. Adding this source does not
claim that either command has executed.

The unchanged `npm test` command retains all original native/private tests and
requires the exact native runtime above. The normal CI job classifies an
unavailable native runtime as **BLOCKED**, with `nativeTestsExecuted=false` and
`nativeQualified=false`; it runs that full command only when both actual
versions match. Public `./browser` qualification is independent and cannot
qualify the package root's native provider, private-key handling, an install or
Source authority. In particular, the official Node 26.7.0 CI archive observed
OpenSSL 3.5.7; that is not the original 3.6.4 runtime, and the native guard is
unchanged.

| API | Result and boundary |
| --- | --- |
| `keyGen({provider})` / `KeyGen()` | Independent standard key generations; returns private capability plus copied dual public keys. |
| `batchSign(privateKey, metadata, messages, {optimized})` / `BatchSign` | Snapshots full ordered messages and metadata, generates a random batch ID, builds both trees, returns both signatures together. |
| `extract(batch, index)` / `Extract` | Detached certificate/message/proof. `batch` is the returned local capability. |
| `exportKeyMaterial(handle)`, `importKeyMaterial(material, {provider})` | Strict fixed dual PKCS8 interchange; see [ABI](docs/KEY_MATERIAL_ABI.md). Wallet owns encryption and trusted recovery binding. |
| `createVerifier(options)` | Binds a trusted network, purpose and application-owned current registry resolver. |
| `verifier.authenticateCertificate(wire, {height})` | Strict parsing, full public-key binding and both signatures; returns an opaque crypto capability or `null`. |
| `verifier.verifyMember(handle, member, {height})` | Checks current registration and both paths, returns boolean. Certificate is fixed by the handle; the optional `member.certificate` object is not used. |
| `verifier.verifyOne(memberWire, {height})` | Standalone full certificate authentication and member verification. |
| `verifier.verifyWholeBatch(certificateWire, messages, {height})` | Full message bounds and ordered double-tree reconstruction. |
| `verifier.verifyWhole(wholeWire, {height})` | Strict Whole decoding followed by full verification. |
| `encode/decodeContext`, `Descriptor`, `Certificate`, `Proof`, `Whole`, `Member` | Strict syntax/resource checks only; never an authenticated handle. |
| `verifier.clear()` | Clears both bounded caches and invalidates all handles from that verifier. |
| `discardBatch`, `destroyKey` | Drop private references. Native key memory erasure timing is managed by Node/OpenSSL; immediate zeroization is not guaranteed. |

Metadata is `{chainId: Buffer(32), owner: printableASCII, purpose: printableASCII}`. Supplying a `batchId` is refused; public keys are derived from the signing capability. This API signs the full messages its caller has authorized. Chain integration must validate that all decoded transactions have the same registered sender and use complete canonical transaction bytes, never a shared 32-byte transaction digest.

`createVerifier({chainId, purpose, resolveTrustedOwner, cacheEntries: 8, optimized: true})` calls the synchronous trusted resolver with `{chainId, owner, purpose, height}`. It must return the current record or `null`. Request bodies must never provide this resolver or its answers. Async resolvers are rejected; obtain an immutable authoritative state snapshot before calling the synchronous verifier.

```js
{
  algorithmVersion: 'YNX-BATCH/v0.1',
  chainId, owner, purpose, pkA, pkB,
  enabled: true,
  policyRevision: 'application-owned-exact-revision',
  activeFrom: 123,
  revokedAt: null // or first height at which use is forbidden
}
```

This record shape is a local adapter contract, **not** a new consensus/state encoding. Policy revisions, keys, identity, activation and revocation fields are all bound to the handle and rechecked on every use. Reauthentication is required after any of them changes. There is no clock-based account-policy cache. Full certificate and trust bytes key the bounded LRU (0–64 entries); public-key imports have a separate equally bounded cache and are stored only after successful AND authentication. Neither cache is indexed by batch ID alone. Caller-retained handles own their state until garbage collection; consumers must also bound outstanding handles and input queues.

`TX-BATCH` authorizes members individually; it does not provide atomic execution. Signature validity is replayable by design. The test suite explicitly accepts the same valid proof twice to demonstrate why ledger nonce checks are still mandatory. Application execution must check current policy, sender, nonce, balance, fee, action rules, and activation state for **every** execution inside the authoritative state transition. The authorized migration design requires current lawful authorization plus both new-key possession proofs; after activation the account requires the dual PQ signature and no additional classic signature. Historical validation uses its historical rules. This crypto module alone does not establish that account policy.

## Implemented and tested

- Exact fixed labels, 4-byte big-endian framing, strict field counts/lengths/tails, printable ASCII without normalization, N=1..1024 powers of two, 1 MiB messages, 8 MiB whole batches and 65,536-byte certificates.
- SHA3-512 and SHA-512 independently consume complete messages and position-bound tree encodings. Original and prefix-state-copy implementations remain available for differential tests.
- ML-DSA-87 AND SLH-DSA-SHA2-256f pure signatures, empty standard context. Both branches sign their own domain plus the same full descriptor.
- Reference codec byte comparisons; original and optimized trees at every legal N; all N=128 member paths; real signing/Whole/Member at every legal N; malicious parser corpus; 3,000 deterministic fuzz mutations; detached-buffer and unforgeable-handle checks.
- Both directions between OpenSSL and Noble, including rejection of nonempty-context reinterpretation. Reference functions are loaded only after SHA-256 pin verification and before their benchmark boundary.
- Official NIST ACVP data from revision `975de31eb83d87039ec88934fdc47d8c312b892d`: 29 external pure signature-verification cases (5 positive, 24 negative) run against both providers; 35 deterministic key-generation cases checked against Noble, including exact secret/public test bytes; 25 ML-DSA native seed-import public-key checks. These are selected parameter groups, not the entire ACVP validation suite or certification.
- Revocation/activation heights, policy revisions, key rotation, missing/throwing/async resolvers, success-only bounded caches, handle clear, signature/root/path/message/index tampering, cross-batch mixing and unchanged-proof replay boundary.

Official vectors are in `test/vectors/nist-acvp.json`. `scripts/fetch-acvp.mjs` and `scripts/select-acvp.mjs` reconstruct the selected groups from the pinned official repository; `evidence/acvp-sources.json` records source hashes. Tests run offline once `npm ci` has completed. Public NIST test secret keys are fixtures and never account authorization.

## Precise size reproduction

For owner `ynx-test-owner-001` (18 bytes), purpose `TX-BATCH` (8), N=128 and 1,024-byte messages:

| Object | Bytes |
| --- | ---: |
| Context | 2,836 |
| Descriptor | 3,017 |
| Certificate | 57,516 |
| Proof | 980 |
| WholeWire | 189,140 |
| MemberWire | 59,561 |
| Whole overhead per member | 453.65625 |

Independent MemberWire carries the full certificate. It cannot establish the hidden total size of all other messages. The 8 MiB aggregate bound is enforced for construction and WholeWire; a members-only Chain admission path requiring that bound needs a separately authenticated complete-batch record or a future protocol version.

## Scope still pending

The user has authorized parallel native transaction, Wallet and validator-consensus implementation and an upgrade of the existing public testnet. Migrated accounts require ML-DSA-87 AND SLH-DSA-SHA2-256f only after activation; migration first requires the current lawful authorization and possession of both new keys. Newly independent random keys need encrypted backup and an independent recovery credential, with actual clean recovery and comparison against original and trusted registered public keys. Chain identity, addresses, balances, nonces, contracts and history must remain intact. The 24-hour runnable-flow and 72-hour public-upgrade targets are sprint targets, not measured guarantees.

This package is the crypto component for those integrations, not a completed network upgrade. Actual R24 portable key/signature tests passed 6/6 and Node 26 complete regressions passed 28/28. The SDK/App owners are integrating encrypted backup and clean recovery. The separate Go implementation and Chain account-policy/consensus code still need their own compilation, tests, installation, replay, multi-node and activation evidence. No live network activation height is selected by this package.

Inventory every native/EVM/action/recovery/legacy entry point against authoritative account policy. Register both complete PQ keys with full network/account/version/revision/nonce/activation binding. Recheck the active policy during execution and preserve historical verification. Synchronous crypto needs protected process scheduling, cancellation, bounded queues and worker-result revalidation in each product. Three reference timing samples do not establish P95/P99, confirmation latency or Chain TPS. Social confidentiality remains separate.

## Sources

The two original DOCX files and reference archive are pinned in `PROVENANCE.json`; extracted text includes Office Math text. The supplied reference files remain byte-identical.

- [NIST FIPS 204](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.204.pdf)
- [NIST FIPS 205](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.205.pdf)
- [Official ACVP source revision](https://github.com/usnistgov/ACVP-Server/tree/975de31eb83d87039ec88934fdc47d8c312b892d/gen-val/json-files)
- [Node crypto interface](https://nodejs.org/download/release/v26.3.0/docs/api/crypto.html)
- [Noble post-quantum implementation](https://github.com/paulmillr/noble-post-quantum)

YNX is an experimental combination of standardized primitives. It is not NIST-certified, a proven new security theorem, a novelty claim, a confidentiality protocol, or evidence of multi-account transaction throughput.
